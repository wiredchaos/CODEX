"use client"

import { GlassCard } from "./ui/glass-card"
import type { StorySeed, ExpandedStory, PublishedData, StoryStatus } from "@/lib/types"
import { BookOpen, Sparkles, CheckCircle } from "lucide-react"

interface StoryPreviewProps {
  seed: StorySeed | null
  expandedStory: ExpandedStory | null
  publishedData: PublishedData | null
  status: StoryStatus
}

export function StoryPreview({ seed, expandedStory, publishedData, status }: StoryPreviewProps) {
  if (status === "idle") {
    return (
      <GlassCard className="p-8 flex flex-col items-center justify-center min-h-[300px] text-center">
        <BookOpen className="w-12 h-12 text-muted-foreground/50 mb-4" />
        <h3 className="text-lg font-medium text-muted-foreground">No story yet</h3>
        <p className="text-sm text-muted-foreground/70 mt-2 max-w-md">
          Enter a prompt above and click Generate Seed to begin the creative pipeline.
        </p>
      </GlassCard>
    )
  }

  return (
    <div className="space-y-4">
      {/* Seed Preview */}
      {seed && (
        <GlassCard glow="cyan" className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="w-5 h-5 text-primary" />
            <h3 className="font-semibold text-primary">Story Seed</h3>
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Arc:</span>
              <p className="text-foreground font-medium">{seed.arc}</p>
            </div>
            <div>
              <span className="text-muted-foreground">Genre:</span>
              <p className="text-foreground font-medium">{seed.genre}</p>
            </div>
            <div>
              <span className="text-muted-foreground">Tone:</span>
              <p className="text-foreground font-medium">{seed.tone}</p>
            </div>
            <div>
              <span className="text-muted-foreground">Character:</span>
              <p className="text-foreground font-medium">{seed.character}</p>
            </div>
          </div>
          <div className="mt-4">
            <span className="text-muted-foreground text-sm">Story Beats:</span>
            <ul className="mt-2 space-y-1">
              {seed.beats.map((beat, i) => (
                <li key={i} className="text-sm text-foreground/80 flex items-start gap-2">
                  <span className="text-primary font-mono text-xs mt-0.5">{i + 1}.</span>
                  {beat}
                </li>
              ))}
            </ul>
          </div>
        </GlassCard>
      )}

      {/* Expanded Story Preview */}
      {expandedStory && (
        <GlassCard glow="magenta" className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <BookOpen className="w-5 h-5 text-accent" />
            <h3 className="font-semibold text-accent">Expanded Novella</h3>
          </div>
          <div className="space-y-4">
            <div>
              <h4 className="text-xl font-bold text-foreground">{expandedStory.title}</h4>
              <p className="text-sm text-muted-foreground mt-1">{expandedStory.tagline}</p>
            </div>
            <div className="prose prose-invert prose-sm max-w-none">
              {expandedStory.chapters.map((chapter, i) => (
                <div key={i} className="mb-4">
                  <h5 className="text-sm font-semibold text-primary/80">
                    Chapter {i + 1}: {chapter.title}
                  </h5>
                  <p className="text-foreground/80 text-sm leading-relaxed mt-2">{chapter.content.slice(0, 300)}...</p>
                </div>
              ))}
            </div>
            <div className="flex gap-4 text-xs text-muted-foreground">
              <span>~{expandedStory.wordCount.toLocaleString()} words</span>
              <span>{expandedStory.chapters.length} chapters</span>
            </div>
          </div>
        </GlassCard>
      )}

      {publishedData && (
        <GlassCard className="p-6 border-[oklch(0.85_0.2_90)]/30">
          <div className="flex items-center gap-2 mb-4">
            <CheckCircle className="w-5 h-5 text-[oklch(0.85_0.2_90)]" />
            <h3 className="font-semibold text-[oklch(0.85_0.2_90)]">Draft Ready</h3>
          </div>
          <div className="space-y-3 text-sm">
            <div>
              <span className="text-muted-foreground">Status:</span>
              <p className="text-foreground font-medium">{publishedData.status}</p>
            </div>
            {publishedData.handoffReceiptId && (
              <div>
                <span className="text-muted-foreground">Handoff Receipt:</span>
                <p className="text-foreground font-mono text-xs">{publishedData.handoffReceiptId}</p>
              </div>
            )}
            <p className="text-muted-foreground/80 text-xs pt-2 border-t border-border">
              This draft has been submitted to Creator Codex for self-publishing workflow.
            </p>
          </div>
        </GlassCard>
      )}
    </div>
  )
}
