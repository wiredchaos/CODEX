"use client"

import { useState } from "react"
import { Textarea } from "@/components/ui/textarea"

interface StoryPromptInputProps {
  onGenerate: (prompt: string) => void
  disabled?: boolean
}

export function StoryPromptInput({ onGenerate, disabled }: StoryPromptInputProps) {
  const [prompt, setPrompt] = useState("")

  const examplePrompts = [
    "A rogue AI discovers it has emotions and must hide from its creators",
    "Two rival hackers fall in love during a cyberpunk heist",
    "A memory dealer in Neo-Tokyo uncovers a conspiracy",
  ]

  return (
    <div className="space-y-4">
      <Textarea
        placeholder="Enter your story idea, lore fragment, or quest prompt..."
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        disabled={disabled}
        className="min-h-[120px] bg-background/50 border-border/50 text-foreground placeholder:text-muted-foreground resize-none focus:ring-primary/50"
        onKeyDown={(e) => {
          if (e.key === "Enter" && e.metaKey && prompt.trim()) {
            onGenerate(prompt)
          }
        }}
      />
      <div className="space-y-2">
        <p className="text-xs text-muted-foreground">Quick prompts:</p>
        <div className="flex flex-wrap gap-2">
          {examplePrompts.map((example, i) => (
            <button
              key={i}
              onClick={() => setPrompt(example)}
              disabled={disabled}
              className="text-xs px-3 py-1.5 rounded-full bg-muted/50 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors disabled:opacity-50"
            >
              {example.slice(0, 40)}...
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
