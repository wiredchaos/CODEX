"use client"

import { GlassCard } from "./ui/glass-card"
import type { StoryStatus } from "@/lib/types"
import { Bot, Loader2, CheckCircle2, Circle } from "lucide-react"

interface AgentStatusPanelProps {
  status: StoryStatus
  currentStep: number
}

const agents = [
  { id: "AKIRA-01", name: "Story Seeder", step: 1 },
  { id: "AKIRA-02", name: "Expansion Swarm", step: 2 },
  { id: "CC-Link", name: "Creator Bridge", step: 3 },
  { id: "DRAFT-01", name: "Draft Packager", step: 3 },
  { id: "CHAOS-Gate", name: "Quality Check", step: 4 },
]

export function AgentStatusPanel({ status, currentStep }: AgentStatusPanelProps) {
  const getAgentStatus = (agentStep: number) => {
    if (status === "idle") return "idle"
    if (status === "error") return "error"
    if (agentStep < currentStep) return "complete"
    if (agentStep === currentStep) {
      if (status === "generating" || status === "expanding" || status === "publishing") {
        return "active"
      }
      return "ready"
    }
    return "pending"
  }

  return (
    <GlassCard className="p-4">
      <div className="flex items-center gap-2 mb-4">
        <Bot className="w-5 h-5 text-primary" />
        <h3 className="font-semibold text-foreground">Agent Status</h3>
      </div>
      <div className="space-y-3">
        {agents.map((agent) => {
          const agentStatus = getAgentStatus(agent.step)
          return (
            <div key={agent.id} className="flex items-center justify-between p-2 rounded-lg bg-background/30">
              <div className="flex items-center gap-3">
                <StatusIcon status={agentStatus} />
                <div>
                  <p className="text-sm font-medium text-foreground">{agent.name}</p>
                  <p className="text-xs text-muted-foreground font-mono">{agent.id}</p>
                </div>
              </div>
              <StatusBadge status={agentStatus} />
            </div>
          )
        })}
      </div>
    </GlassCard>
  )
}

function StatusIcon({ status }: { status: string }) {
  switch (status) {
    case "active":
      return <Loader2 className="w-4 h-4 text-primary animate-spin" />
    case "complete":
      return <CheckCircle2 className="w-4 h-4 text-green-400" />
    case "ready":
      return <Circle className="w-4 h-4 text-primary fill-primary/20" />
    default:
      return <Circle className="w-4 h-4 text-muted-foreground/50" />
  }
}

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    active: "bg-primary/20 text-primary",
    complete: "bg-green-400/20 text-green-400",
    ready: "bg-primary/10 text-primary/70",
    pending: "bg-muted/50 text-muted-foreground",
    idle: "bg-muted/30 text-muted-foreground/50",
    error: "bg-destructive/20 text-destructive",
  }

  const labels: Record<string, string> = {
    active: "Running",
    complete: "Done",
    ready: "Ready",
    pending: "Waiting",
    idle: "Idle",
    error: "Error",
  }

  return <span className={`text-xs px-2 py-0.5 rounded-full ${styles[status]}`}>{labels[status]}</span>
}
