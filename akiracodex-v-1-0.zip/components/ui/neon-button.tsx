import { cn } from "@/lib/utils"
import { Button, type ButtonProps } from "@/components/ui/button"

interface NeonButtonProps extends ButtonProps {
  variant?: "cyan" | "magenta" | "yellow" | "ghost"
}

export function NeonButton({ className, variant = "cyan", children, disabled, ...props }: NeonButtonProps) {
  const variants = {
    cyan: "bg-primary/20 text-primary border-primary/50 hover:bg-primary/30 hover:neon-glow-cyan disabled:opacity-50",
    magenta: "bg-accent/20 text-accent border-accent/50 hover:bg-accent/30 hover:neon-glow-magenta disabled:opacity-50",
    yellow:
      "bg-[oklch(0.85_0.2_90)]/20 text-[oklch(0.85_0.2_90)] border-[oklch(0.85_0.2_90)]/50 hover:bg-[oklch(0.85_0.2_90)]/30 disabled:opacity-50",
    ghost: "bg-transparent text-muted-foreground border-muted hover:bg-muted/20 hover:text-foreground",
  }

  return (
    <Button
      className={cn("border font-medium transition-all duration-300", variants[variant], className)}
      disabled={disabled}
      {...props}
    >
      {children}
    </Button>
  )
}
