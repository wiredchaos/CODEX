import type React from "react"
import { cn } from "@/lib/utils"

interface GlassCardProps extends React.HTMLAttributes<HTMLDivElement> {
  glow?: "cyan" | "magenta" | "none"
}

export function GlassCard({ className, glow = "none", children, ...props }: GlassCardProps) {
  return (
    <div
      className={cn(
        "glass rounded-xl",
        glow === "cyan" && "neon-glow-cyan",
        glow === "magenta" && "neon-glow-magenta",
        className,
      )}
      {...props}
    >
      {children}
    </div>
  )
}
