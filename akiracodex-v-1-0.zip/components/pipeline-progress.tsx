"use client"

import type { StoryStatus } from "@/lib/types"

interface PipelineProgressProps {
  currentStep: number
  status: StoryStatus
}

const steps = [
  { id: 1, label: "Seed", description: "Generate story schema" },
  { id: 2, label: "Expand", description: "Build novella" },
  { id: 3, label: "Convert", description: "Format for handoff" },
  { id: 4, label: "Complete", description: "Draft ready" },
]

export function PipelineProgress({ currentStep, status }: PipelineProgressProps) {
  return (
    <div className="glass rounded-xl p-4">
      <div className="flex items-center justify-between">
        {steps.map((step, index) => (
          <div key={step.id} className="flex items-center flex-1">
            <div className="flex flex-col items-center">
              <div
                className={`
                  w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-all duration-300
                  ${
                    step.id < currentStep
                      ? "bg-green-400/20 text-green-400 border-2 border-green-400/50"
                      : step.id === currentStep
                        ? status === "generating" || status === "expanding" || status === "publishing"
                          ? "bg-primary/20 text-primary border-2 border-primary animate-pulse"
                          : "bg-primary/20 text-primary border-2 border-primary"
                        : "bg-muted/30 text-muted-foreground border-2 border-muted"
                  }
                `}
              >
                {step.id < currentStep ? "✓" : step.id}
              </div>
              <div className="mt-2 text-center">
                <p
                  className={`text-sm font-medium ${
                    step.id <= currentStep ? "text-foreground" : "text-muted-foreground"
                  }`}
                >
                  {step.label}
                </p>
                <p className="text-xs text-muted-foreground hidden sm:block">{step.description}</p>
              </div>
            </div>
            {index < steps.length - 1 && (
              <div
                className={`flex-1 h-0.5 mx-4 transition-colors duration-300 ${
                  step.id < currentStep ? "bg-green-400/50" : "bg-muted/30"
                }`}
              />
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
