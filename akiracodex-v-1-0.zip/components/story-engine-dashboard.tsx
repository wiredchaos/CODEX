"use client"

import { useState } from "react"
import { GlassCard } from "./ui/glass-card"
import { NeonButton } from "./ui/neon-button"
import { StoryPromptInput } from "./story-prompt-input"
import { StoryPreview } from "./story-preview"
import { AgentStatusPanel } from "./agent-status-panel"
import { PipelineProgress } from "./pipeline-progress"
import type { StorySeed, StoryState } from "@/lib/types"

export function StoryEngineDashboard() {
  const [storyState, setStoryState] = useState<StoryState>({
    status: "idle",
    currentStep: 0,
    seed: null,
    expandedStory: null,
    publishedData: null,
  })

  const [handoffReceipt, setHandoffReceipt] = useState<{
    handoffReceiptId: string
    draftId: string
    nextUrl: string
  } | null>(null)

  const handleGenerate = async (prompt: string) => {
    setStoryState((prev) => ({ ...prev, status: "generating", currentStep: 1 }))

    try {
      const response = await fetch("/api/akira/seed", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      })
      const seed: StorySeed = await response.json()
      setStoryState((prev) => ({
        ...prev,
        status: "seeded",
        currentStep: 1,
        seed,
      }))
    } catch {
      setStoryState((prev) => ({ ...prev, status: "error" }))
    }
  }

  const handleExpand = async () => {
    if (!storyState.seed) return
    setStoryState((prev) => ({ ...prev, status: "expanding", currentStep: 2 }))

    try {
      const response = await fetch("/api/akira/expand", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ seed: storyState.seed }),
      })
      const expandedStory = await response.json()
      setStoryState((prev) => ({
        ...prev,
        status: "expanded",
        currentStep: 2,
        expandedStory,
      }))
    } catch {
      setStoryState((prev) => ({ ...prev, status: "error" }))
    }
  }

  const handleSubmitToCreatorCodex = async () => {
    if (!storyState.expandedStory) return
    setStoryState((prev) => ({ ...prev, status: "publishing", currentStep: 3 }))

    try {
      const response = await fetch("/api/akira-engine/handoff", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: storyState.expandedStory.title,
          body: storyState.expandedStory.chapters.map((ch) => `# ${ch.title}\n\n${ch.content}`).join("\n\n"),
          excerpt: storyState.expandedStory.tagline,
          tags: storyState.expandedStory.metadata.themes,
          ageTier: storyState.expandedStory.metadata.ageRating,
        }),
      })
      const result = await response.json()
      setHandoffReceipt(result)
      setStoryState((prev) => ({
        ...prev,
        status: "published",
        currentStep: 4,
        publishedData: { status: "draft-ready", handoffReceiptId: result.handoffReceiptId },
      }))
    } catch {
      setStoryState((prev) => ({ ...prev, status: "error" }))
    }
  }

  const resetPipeline = () => {
    setStoryState({
      status: "idle",
      currentStep: 0,
      seed: null,
      expandedStory: null,
      publishedData: null,
    })
    setHandoffReceipt(null)
  }

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Background effects */}
      <div className="fixed inset-0 bg-[radial-gradient(ellipse_at_top,oklch(0.15_0.05_280),transparent_50%)]" />
      <div className="fixed inset-0 bg-[radial-gradient(ellipse_at_bottom_right,oklch(0.12_0.08_330),transparent_50%)]" />
      <div className="fixed inset-0 scanlines pointer-events-none opacity-50" />

      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Header */}
        <header className="mb-8">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center neon-glow-cyan">
              <span className="text-2xl font-bold text-primary">A</span>
            </div>
            <div>
              <h1 className="text-3xl font-bold tracking-tight text-foreground neon-text-cyan">AKIRA ENGINE</h1>
              <p className="text-muted-foreground text-sm">Draft Runtime — Generate. Expand. Convert. Complete.</p>
            </div>
          </div>
        </header>

        {/* Pipeline Progress */}
        <PipelineProgress currentStep={storyState.currentStep} status={storyState.status} />

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
          {/* Left Column - Input & Controls */}
          <div className="lg:col-span-2 space-y-6">
            <GlassCard className="p-6">
              <h2 className="text-lg font-semibold mb-4 text-primary">Story Prompt</h2>
              <StoryPromptInput onGenerate={handleGenerate} disabled={storyState.status === "generating"} />
            </GlassCard>

            {/* Story Preview */}
            <StoryPreview
              seed={storyState.seed}
              expandedStory={storyState.expandedStory}
              publishedData={storyState.publishedData}
              status={storyState.status}
            />

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-4">
              <NeonButton
                variant="cyan"
                onClick={() => {
                  const input = document.querySelector("textarea") as HTMLTextAreaElement
                  if (input?.value) handleGenerate(input.value)
                }}
                disabled={storyState.status === "generating"}
              >
                {storyState.status === "generating" ? "Seeding..." : "Generate Seed"}
              </NeonButton>

              <NeonButton
                variant="magenta"
                onClick={handleExpand}
                disabled={!storyState.seed || storyState.status === "expanding"}
              >
                {storyState.status === "expanding" ? "Expanding..." : "Expand Story"}
              </NeonButton>

              <NeonButton
                variant="yellow"
                onClick={handleSubmitToCreatorCodex}
                disabled={!storyState.expandedStory || storyState.status === "publishing"}
              >
                {storyState.status === "publishing" ? "Submitting..." : "Submit to Creator Codex"}
              </NeonButton>

              {storyState.status !== "idle" && (
                <NeonButton variant="ghost" onClick={resetPipeline}>
                  Reset
                </NeonButton>
              )}
            </div>

            {handoffReceipt && (
              <GlassCard className="p-4 border-primary/50">
                <h3 className="text-sm font-semibold text-primary mb-2">Draft Handoff Complete</h3>
                <div className="text-xs text-muted-foreground space-y-1">
                  <p>Receipt ID: {handoffReceipt.handoffReceiptId}</p>
                  <p>Draft ID: {handoffReceipt.draftId}</p>
                  <p className="text-primary">Next: {handoffReceipt.nextUrl}</p>
                </div>
              </GlassCard>
            )}
          </div>

          {/* Right Column - Agent Status */}
          <div className="space-y-6">
            <AgentStatusPanel status={storyState.status} currentStep={storyState.currentStep} />

            {/* Spotify Embed */}
            <GlassCard className="p-4">
              <h3 className="text-sm font-medium text-muted-foreground mb-3">CHAOS OS Radio</h3>
              <iframe
                style={{ borderRadius: "12px" }}
                src="https://open.spotify.com/embed/playlist/2VwOYrB1C93gNIPiBZNxhH?utm_source=generator&theme=0"
                width="100%"
                height="152"
                frameBorder="0"
                allowFullScreen
                allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
                loading="lazy"
                className="opacity-80 hover:opacity-100 transition-opacity"
              />
            </GlassCard>
          </div>
        </div>
      </div>
    </div>
  )
}
