export interface StorySeed {
  arc: string
  character: string
  tone: string
  genre: string
  beats: string[]
  sentiment: string
}

export interface Chapter {
  title: string
  content: string
}

export interface ExpandedStory {
  title: string
  tagline: string
  chapters: Chapter[]
  wordCount: number
  coverPrompt: string
  metadata: {
    genre: string
    themes: string[]
    targetAudience: string
  }
}

export interface PublishedData {
  asin: string
  storefrontUrl: string
  price: number
  format: string
  publishedAt: string
}

export type StoryStatus =
  | "idle"
  | "generating"
  | "seeded"
  | "expanding"
  | "expanded"
  | "publishing"
  | "published"
  | "error"

export interface StoryState {
  status: StoryStatus
  currentStep: number
  seed: StorySeed | null
  expandedStory: ExpandedStory | null
  publishedData: PublishedData | null
}
