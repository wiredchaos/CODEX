import { NextResponse } from "next/server"

interface AssessmentRequest {
  avatarId: string
  storyCount: number
  totalWordCount: number
  communityRatings: number[]
  publicationHistory: string[]
}

export async function POST(request: Request) {
  try {
    const data: AssessmentRequest = await request.json()

    // CHAOS-Gate Assessment Algorithm
    // Score = Lore coherence × creative ethic × authorship time index

    const avgRating =
      data.communityRatings.length > 0
        ? data.communityRatings.reduce((a, b) => a + b, 0) / data.communityRatings.length
        : 5

    const loreCoherence = Math.min(1, data.storyCount / 10) * 10
    const creativeEthic = avgRating
    const authorshipIndex = Math.min(1, data.totalWordCount / 50000) * 10

    const totalScore = loreCoherence * 0.3 + creativeEthic * 0.4 + authorshipIndex * 0.3

    const tier =
      totalScore >= 9
        ? "APEX_CREATOR"
        : totalScore >= 7.5
          ? "MASTER_AUTHOR"
          : totalScore >= 5
            ? "JOURNEYMAN"
            : "INITIATE"

    const privileges =
      tier === "APEX_CREATOR"
        ? ["world-building", "co-author-events", "cinematic-rights", "merch-integration"]
        : tier === "MASTER_AUTHOR"
          ? ["world-building", "co-author-events", "merch-integration"]
          : tier === "JOURNEYMAN"
            ? ["co-author-events"]
            : []

    return NextResponse.json({
      avatarId: data.avatarId,
      scores: {
        loreCoherence: Math.round(loreCoherence * 10) / 10,
        creativeEthic: Math.round(creativeEthic * 10) / 10,
        authorshipIndex: Math.round(authorshipIndex * 10) / 10,
        total: Math.round(totalScore * 10) / 10,
      },
      tier,
      privileges,
      nextTierThreshold: tier === "INITIATE" ? 5 : tier === "JOURNEYMAN" ? 7.5 : tier === "MASTER_AUTHOR" ? 9 : null,
      assessedAt: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Assessment error:", error)
    return NextResponse.json({ error: "Failed to assess avatar" }, { status: 500 })
  }
}
