import { NextResponse } from "next/server"
import type { ExpandedStory } from "@/lib/types"

export async function POST(request: Request) {
  try {
    const { story }: { story: ExpandedStory } = await request.json()

    if (!story) {
      return NextResponse.json({ error: "Story is required" }, { status: 400 })
    }

    // Generate markdown format
    let markdown = `# ${story.title}\n\n`
    markdown += `*${story.tagline}*\n\n---\n\n`

    for (const chapter of story.chapters) {
      markdown += `## ${chapter.title}\n\n`
      markdown += `${chapter.content}\n\n---\n\n`
    }

    // Generate metadata for EPUB
    const epubMetadata = {
      title: story.title,
      author: "AKIRA CODEX",
      language: "en",
      genre: story.metadata.genre,
      description: story.tagline,
      keywords: story.metadata.themes,
      wordCount: story.wordCount,
    }

    return NextResponse.json({
      markdown,
      epubMetadata,
      formats: ["EPUB", "PDF", "MOBI"],
      coverPrompt: story.coverPrompt,
      status: "converted",
    })
  } catch (error) {
    console.error("Conversion error:", error)
    return NextResponse.json({ error: "Failed to convert story" }, { status: 500 })
  }
}
