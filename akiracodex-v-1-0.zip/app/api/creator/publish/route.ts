import { NextResponse } from "next/server"
import type { ExpandedStory } from "@/lib/types"

function generateSlug(title: string): string {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
}

function generateASIN(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
  let asin = "B0"
  for (let i = 0; i < 8; i++) {
    asin += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return asin
}

export async function POST(request: Request) {
  try {
    const { story }: { story: ExpandedStory } = await request.json()

    if (!story) {
      return NextResponse.json({ error: "Story is required" }, { status: 400 })
    }

    const slug = generateSlug(story.title)
    const asin = generateASIN()

    // Simulated publishing data (in production, this would integrate with KDP API)
    const publishedData = {
      asin,
      storefrontUrl: `/books/${slug}`,
      price: 2.99,
      format: "Kindle eBook",
      publishedAt: new Date().toISOString(),
      royaltyRate: 0.7,
      status: "published",
      metadata: {
        title: story.title,
        tagline: story.tagline,
        genre: story.metadata.genre,
        themes: story.metadata.themes,
        wordCount: story.wordCount,
        chapters: story.chapters.length,
      },
    }

    return NextResponse.json(publishedData)
  } catch (error) {
    console.error("Publishing error:", error)
    return NextResponse.json({ error: "Failed to publish story" }, { status: 500 })
  }
}
