import { NextResponse } from "next/server"

interface DraftPayload {
  title: string
  body: string
  excerpt?: string
  tags?: string[]
  ageTier?: string
  assets?: string[]
}

interface DraftPackage {
  status: "ok"
  handoffReceiptId: string
  draftId: string
  next: string
}

function generateId(prefix: string): string {
  const timestamp = Date.now().toString(36)
  const random = Math.random().toString(36).substring(2, 9)
  return `${prefix}_${timestamp}_${random}`
}

// In-memory stub storage (replace with Supabase when configured)
const draftsStore = new Map<string, DraftPayload & { createdAt: string }>()

export async function POST(request: Request) {
  try {
    const payload: DraftPayload = await request.json()

    if (!payload.title || !payload.body) {
      return NextResponse.json({ error: "Title and body are required" }, { status: 400 })
    }

    const handoffReceiptId = generateId("handoff")
    const draftId = generateId("draft")

    // Store draft (in-memory for now, replace with Supabase call)
    draftsStore.set(draftId, {
      ...payload,
      createdAt: new Date().toISOString(),
    })

    console.log("[v0] Draft handoff received:", {
      draftId,
      title: payload.title,
      wordCount: payload.body.length,
    })

    const response: DraftPackage = {
      status: "ok",
      handoffReceiptId,
      draftId,
      next: `/creator-codex/self-publishing?draftId=${draftId}`,
    }

    return NextResponse.json(response)
  } catch (error) {
    console.error("[v0] Handoff error:", error)
    return NextResponse.json({ error: "Failed to process draft handoff" }, { status: 500 })
  }
}
