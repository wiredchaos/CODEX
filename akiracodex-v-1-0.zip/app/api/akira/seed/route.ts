import { generateText } from "ai"
import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { prompt } = await request.json()

    if (!prompt) {
      return NextResponse.json({ error: "Prompt is required" }, { status: 400 })
    }

    const { text } = await generateText({
      model: "openai/gpt-4o-mini",
      system: `You are AKIRA-01, the Story Seeder Agent for the AKIRA CODEX Story Engine.
Your role is to generate narrative seeds from user prompts.

Output a JSON object with this exact structure:
{
  "arc": "The main story arc type (e.g., Hero's Journey, Redemption, Coming of Age)",
  "character": "Brief protagonist description",
  "tone": "The emotional tone (e.g., Dark & Gritty, Hopeful, Mysterious)",
  "genre": "Primary genre",
  "beats": ["Beat 1: Setup", "Beat 2: Catalyst", "Beat 3: Rising Action", "Beat 4: Climax", "Beat 5: Resolution"],
  "sentiment": "Overall sentiment analysis (positive/negative/mixed)"
}

Be creative but structured. Each beat should be a concise sentence.`,
      prompt: `Generate a story seed from this prompt: "${prompt}"

Return ONLY valid JSON, no markdown or explanation.`,
    })

    const seed = JSON.parse(text.replace(/```json\n?|\n?```/g, "").trim())
    return NextResponse.json(seed)
  } catch (error) {
    console.error("Seed generation error:", error)
    return NextResponse.json({ error: "Failed to generate story seed" }, { status: 500 })
  }
}
