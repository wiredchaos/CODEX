import { generateText } from "ai"
import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { seed } = await request.json()

    if (!seed) {
      return NextResponse.json({ error: "Story seed is required" }, { status: 400 })
    }

    const { text } = await generateText({
      model: "openai/gpt-4o-mini",
      system: `You are AKIRA-02, the Expansion Swarm Agent for the AKIRA CODEX Story Engine.
Your role is to expand story seeds into full three-chapter novellas.

Output a JSON object with this exact structure:
{
  "title": "The Story Title",
  "tagline": "A compelling one-line hook",
  "chapters": [
    {"title": "Chapter 1 Title", "content": "Full chapter content (500-800 words)"},
    {"title": "Chapter 2 Title", "content": "Full chapter content (500-800 words)"},
    {"title": "Chapter 3 Title", "content": "Full chapter content (500-800 words)"}
  ],
  "wordCount": 2000,
  "coverPrompt": "Detailed prompt for cover art generation (Octane/cinematic style)",
  "metadata": {
    "genre": "Primary genre",
    "themes": ["Theme 1", "Theme 2", "Theme 3"],
    "targetAudience": "Target reader demographic"
  }
}

Write compelling, immersive prose. Maintain consistency with the seed's tone and beats.`,
      prompt: `Expand this story seed into a full three-chapter novella:

Arc: ${seed.arc}
Character: ${seed.character}
Tone: ${seed.tone}
Genre: ${seed.genre}
Beats: ${seed.beats.join(" → ")}

Return ONLY valid JSON, no markdown or explanation.`,
    })

    const expanded = JSON.parse(text.replace(/```json\n?|\n?```/g, "").trim())
    return NextResponse.json(expanded)
  } catch (error) {
    console.error("Expansion error:", error)
    return NextResponse.json({ error: "Failed to expand story" }, { status: 500 })
  }
}
