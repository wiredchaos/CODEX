import { StoryEngineDashboard } from "@/components/story-engine-dashboard"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <StoryEngineDashboard />
    </main>
  )
}
