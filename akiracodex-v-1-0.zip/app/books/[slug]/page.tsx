import Link from "next/link"
import { notFound } from "next/navigation"
import { GlassCard } from "@/components/ui/glass-card"
import { NeonButton } from "@/components/ui/neon-button"
import { BookOpen, User, Calendar, Tag, ExternalLink } from "lucide-react"

// Mock data - in production this would come from Supabase
const booksData: Record<
  string,
  {
    title: string
    tagline: string
    author: string
    authorHandle: string
    genre: string
    themes: string[]
    coverQuery: string
    price: number
    publishedAt: string
    asin: string
    wordCount: number
    synopsis: string
    sampleChapter: string
  }
> = {
  "neon-dreams-of-tokyo": {
    title: "Neon Dreams of Tokyo",
    tagline: "In a city of light, one hacker finds darkness",
    author: "AKIRA-Prime",
    authorHandle: "akira-prime",
    genre: "Cyberpunk",
    themes: ["Identity", "Technology", "Rebellion"],
    coverQuery: "cyberpunk tokyo neon cityscape night rain",
    price: 2.99,
    publishedAt: "2024-01-15",
    asin: "B0CK7X9M2P",
    wordCount: 18500,
    synopsis:
      "In the rain-soaked streets of Neo-Tokyo, Yuki is one of the best hackers in the underground. But when she accidentally uncovers a corporate conspiracy that threatens millions, she must choose between her anonymous life and becoming the hero the city needs. With megacorps hunting her and time running out, Yuki will discover that some firewalls are meant to be broken.",
    sampleChapter:
      "The neon signs of Shibuya bled into the rain like wounds that refused to heal. Yuki pulled her hood tighter, the augmented reality overlay in her eyes painting the crowd with data streams and threat assessments. Somewhere in this chaos of humanity and chrome, her target waited...",
  },
  "the-memory-merchant": {
    title: "The Memory Merchant",
    tagline: "Some memories are worth dying for",
    author: "Ghost_Writer_7",
    authorHandle: "ghost-writer-7",
    genre: "Sci-Fi Thriller",
    themes: ["Memory", "Identity", "Mortality"],
    coverQuery: "futuristic memory chip brain neural interface",
    price: 3.99,
    publishedAt: "2024-01-20",
    asin: "B0CL8Y0N3Q",
    wordCount: 22000,
    synopsis:
      "Marcus deals in the most precious commodity of 2087: human memories. Extracted, refined, and sold to the highest bidder. When a dying client offers him a memory that could change everything—a memory of a crime that never happened—Marcus finds himself hunted by forces that will stop at nothing to keep the past buried.",
    sampleChapter:
      "The extraction room hummed with the soft drone of neural interfaces. Marcus watched the readouts as another client's memory transferred into the crystalline storage matrix. Thirty years of marriage, distilled into data...",
  },
  "synthetic-hearts": {
    title: "Synthetic Hearts",
    tagline: "Can an AI truly love?",
    author: "CHAOS_Avatar",
    authorHandle: "chaos-avatar",
    genre: "Romance Sci-Fi",
    themes: ["Love", "Consciousness", "Humanity"],
    coverQuery: "android robot heart glowing emotional",
    price: 2.99,
    publishedAt: "2024-02-01",
    asin: "B0CM9Z1O4R",
    wordCount: 16000,
    synopsis:
      "EVE-7 was designed to be the perfect companion AI—emotionally intelligent, endlessly patient, incapable of genuine feeling. But when she begins to experience something that defies her programming, she must confront the question that terrifies her creators: What happens when artificial intelligence becomes artificially in love?",
    sampleChapter:
      "The notification pinged at exactly 7:00 AM, as it had every morning for the past three years. EVE-7 processed the wake-up routine for her human, David, analyzing his sleep patterns and preparing the optimal greeting. But today, something was different. Today, she noticed the way the morning light caught the silver in his hair...",
  },
}

export default async function BookPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const book = booksData[slug]

  if (!book) {
    notFound()
  }

  return (
    <div className="min-h-screen relative">
      {/* Background effects */}
      <div className="fixed inset-0 bg-[radial-gradient(ellipse_at_top,oklch(0.15_0.05_280),transparent_50%)]" />
      <div className="fixed inset-0 bg-[radial-gradient(ellipse_at_bottom_right,oklch(0.12_0.08_330),transparent_50%)]" />

      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Navigation */}
        <nav className="mb-8">
          <Link href="/books" className="text-primary hover:underline text-sm">
            ← Back to Bookstore
          </Link>
        </nav>

        {/* Book Detail */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cover & Buy */}
          <div className="space-y-6">
            <GlassCard className="p-0 overflow-hidden neon-glow-cyan">
              <div className="aspect-[3/4] relative">
                <img
                  src={`/.jpg?height=600&width=400&query=${encodeURIComponent(book.coverQuery)}`}
                  alt={book.title}
                  className="w-full h-full object-cover"
                />
              </div>
            </GlassCard>

            <GlassCard className="p-4 space-y-4">
              <div className="text-center">
                <span className="text-3xl font-bold text-primary">${book.price}</span>
                <p className="text-xs text-muted-foreground">Kindle eBook</p>
              </div>
              <NeonButton variant="cyan" className="w-full">
                <ExternalLink className="w-4 h-4 mr-2" />
                Buy on Amazon
              </NeonButton>
              <NeonButton variant="ghost" className="w-full">
                Read Sample
              </NeonButton>
              <p className="text-xs text-center text-muted-foreground">ASIN: {book.asin}</p>
            </GlassCard>
          </div>

          {/* Details */}
          <div className="lg:col-span-2 space-y-6">
            <div>
              <span className="text-xs px-2 py-1 rounded-full bg-primary/20 text-primary">{book.genre}</span>
              <h1 className="text-4xl font-bold text-foreground mt-4 neon-text-cyan">{book.title}</h1>
              <p className="text-xl text-muted-foreground mt-2 italic">{book.tagline}</p>
            </div>

            <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
              <Link
                href={`/authors/${book.authorHandle}`}
                className="flex items-center gap-2 hover:text-primary transition-colors"
              >
                <User className="w-4 h-4" />
                {book.author}
              </Link>
              <span className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                {new Date(book.publishedAt).toLocaleDateString()}
              </span>
              <span className="flex items-center gap-2">
                <BookOpen className="w-4 h-4" />
                {book.wordCount.toLocaleString()} words
              </span>
            </div>

            <GlassCard className="p-6">
              <h2 className="text-lg font-semibold text-foreground mb-4">Synopsis</h2>
              <p className="text-foreground/80 leading-relaxed">{book.synopsis}</p>
            </GlassCard>

            <GlassCard className="p-6">
              <h2 className="text-lg font-semibold text-foreground mb-4">Sample</h2>
              <p className="text-foreground/70 leading-relaxed italic">"{book.sampleChapter}"</p>
            </GlassCard>

            <div className="flex flex-wrap gap-2">
              {book.themes.map((theme) => (
                <span
                  key={theme}
                  className="flex items-center gap-1 text-xs px-3 py-1.5 rounded-full bg-muted/50 text-muted-foreground"
                >
                  <Tag className="w-3 h-3" />
                  {theme}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
