import Link from "next/link"
import { GlassCard } from "@/components/ui/glass-card"
import { User } from "lucide-react"

// Mock data - in production this would come from Supabase
const books = [
  {
    slug: "neon-dreams-of-tokyo",
    title: "Neon Dreams of Tokyo",
    tagline: "In a city of light, one hacker finds darkness",
    author: "AKIRA-Prime",
    genre: "Cyberpunk",
    coverQuery: "cyberpunk tokyo neon cityscape night rain",
    price: 2.99,
    publishedAt: "2024-01-15",
  },
  {
    slug: "the-memory-merchant",
    title: "The Memory Merchant",
    tagline: "Some memories are worth dying for",
    author: "Ghost_Writer_7",
    genre: "Sci-Fi Thriller",
    coverQuery: "futuristic memory chip brain neural interface",
    price: 3.99,
    publishedAt: "2024-01-20",
  },
  {
    slug: "synthetic-hearts",
    title: "Synthetic Hearts",
    tagline: "Can an AI truly love?",
    author: "CHAOS_Avatar",
    genre: "Romance Sci-Fi",
    coverQuery: "android robot heart glowing emotional",
    price: 2.99,
    publishedAt: "2024-02-01",
  },
]

export default function BooksPage() {
  return (
    <div className="min-h-screen relative">
      {/* Background effects */}
      <div className="fixed inset-0 bg-[radial-gradient(ellipse_at_top,oklch(0.15_0.05_280),transparent_50%)]" />
      <div className="fixed inset-0 bg-[radial-gradient(ellipse_at_bottom_right,oklch(0.12_0.08_330),transparent_50%)]" />

      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Header */}
        <header className="mb-12">
          <Link href="/" className="text-primary hover:underline text-sm mb-4 inline-block">
            ← Back to Dashboard
          </Link>
          <h1 className="text-4xl font-bold text-foreground neon-text-cyan mt-4">CREATOR CODEX Bookstore</h1>
          <p className="text-muted-foreground mt-2">Stories born from the AKIRA Swarm, published through CHAOS OS</p>
        </header>

        {/* Book Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {books.map((book) => (
            <Link key={book.slug} href={`/books/${book.slug}`}>
              <GlassCard className="p-0 overflow-hidden group hover:neon-glow-cyan transition-all duration-300 h-full">
                <div className="aspect-[3/4] relative bg-gradient-to-br from-primary/20 to-accent/20">
                  <img
                    src={`/.jpg?height=400&width=300&query=${encodeURIComponent(book.coverQuery)}`}
                    alt={book.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-background/90 to-transparent p-4">
                    <span className="text-xs px-2 py-1 rounded-full bg-primary/20 text-primary">{book.genre}</span>
                  </div>
                </div>
                <div className="p-4 space-y-3">
                  <h2 className="text-lg font-bold text-foreground group-hover:text-primary transition-colors">
                    {book.title}
                  </h2>
                  <p className="text-sm text-muted-foreground line-clamp-2">{book.tagline}</p>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <User className="w-3 h-3" />
                      {book.author}
                    </span>
                    <span className="text-primary font-bold">${book.price}</span>
                  </div>
                </div>
              </GlassCard>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
