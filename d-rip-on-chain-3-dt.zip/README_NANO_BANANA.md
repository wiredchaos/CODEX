# WIRED CHAOS META - Nano Banana Master Build

## Overview

This is the production-ready Next.js 14 implementation of the **WIRED CHAOS Answer + 3D Video + Avatar System** as specified in the Nano Banana Master Build prompt.

## Core Capabilities

### 1. NPC Answer + Video System
- **Route**: `/npc/console`
- **API**: `POST /api/npc/answer-video`
- Every agent response includes:
  - Structured TEXT ANSWER
  - VIDEO METADATA (3-12 seconds)
  - AVATAR configuration (pose, expression, environment)
  - Attention-optimized hooks

### 2. Story Engine (AKIRA-CREATOR Pipeline)
- **Route**: `/akira/story-engine`
- **APIs**:
  - `POST /api/akira/seed` - Generate story seed
  - `POST /api/akira/expand` - Expand to novella
  - `POST /api/creator/convert` - Convert to ebook
  - `POST /api/creator/publish` - Publish to KDP
  - `POST /api/creator/microsite` - Generate microsite

### 3. Business 3D Meetings
- **Route**: `/business/meetings`
- **API**: `GET /api/environment/[environmentId]`
- 4 meeting environments:
  - Neon Boardroom
  - Executive Atrium
  - Creator Studio
  - Financial Observatory

### 4. Creator Codex Bookstore
- **Route**: `/bookstore`
- Publication listings with genre collections
- Author profiles and press kits
- Integration with Story Engine

## Technology Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS v4 + shadcn/ui
- **Database**: Supabase (Postgres)
- **ORM**: Prisma
- **Deployment**: Vercel

## Data Models

Located in `/types/index.ts`:
- `AvatarId` - 11 canonical avatars
- `AvatarStyle` - Visual configuration
- `EnvironmentId` - 10+ environments
- `EnvironmentConfig` - Environment specs
- `NpcMessage` - Chat messages
- `StorySeed` - Story foundations
- `Novella` - Expanded stories
- `Publication` - Published works
- `AvatarStoryStats` - Creator progression

## API Endpoints

### Answer + Video
- `POST /api/npc/answer-video` - Generate text + video response
- `POST /api/video/generate` - Video generation proxy
- `GET /api/avatar/[avatarId]/style` - Avatar style config
- `POST /api/avatar/render` - Avatar render config
- `GET /api/environment/[environmentId]` - Environment config

### Story Engine
- `POST /api/akira/seed` - Story seed generation
- `POST /api/akira/expand` - Novella expansion
- `POST /api/creator/convert` - Ebook conversion
- `POST /api/creator/publish` - KDP publishing
- `POST /api/creator/microsite` - Microsite generation

### Assessment
- `POST /api/chaos/assess` - Avatar progression assessment

## Config Files

### `/config/video-engine.ts`
- `AVATARS` - All 11 avatar definitions
- `ENVIRONMENTS` - All environment configurations
- Lighting profiles, motion seeds, expressions

### `/config/story-engine.ts`
- Story seed schemas
- Novella structure
- Publication metadata
- Agent definitions

## UI Pages

### Core Navigation
- `/` - Home hub with patch selector
- `/npc/console` - NPC chat interface
- `/akira/story-engine` - 3-stage story pipeline
- `/bookstore` - Published works
- `/business/meetings` - 3D environment dashboard

### Supporting Pages
- `/books/[slug]` - Individual book pages
- `/authors/[handle]` - Author profiles
- `/presskit/[slug]` - Press kits
- `/avatar-advancement` - Creator progression

## Attention Optimization

Every video response includes:
1. **Hook Expression** (0.3s) - Eye flash, dramatic reveal
2. **Speaking Expression** - Animated mouth sync
3. **Motion Profile** - Micro-gestures, stance shifts
4. **Attention Summary** - "Close-up neon shot + avatar entrance"

Video preview panel:
- Auto-scrolls on response
- Animated glow for 1.5 seconds
- Highlights hook summary

## Integration Points

### TODO: Real Video Generation
- Currently uses placeholder URLs
- Integration points marked with TODO comments
- Ready for Runway, Pika, Spline, Kaiber connections

### TODO: Real KDP Publishing
- Mock KDP queue system in place
- Ready for Amazon KDP API integration

### TODO: 3D Scene Embedding
- Placeholder 3D preview panels
- Ready for Spline/Hyperfy integration

## Development

```bash
# Install dependencies
npm install

# Run Prisma migrations
npx prisma db push

# Seed database (optional)
npx prisma db seed

# Start development server
npm run dev
```

## Deployment

```bash
# Build for production
npm run build

# Deploy to Vercel
vercel deploy
```

## Environment Variables

Required in Vercel/`.env`:
- `DATABASE_URL` - Supabase Postgres connection
- `SUPABASE_URL` - Supabase project URL
- `SUPABASE_ANON_KEY` - Supabase anonymous key
- `LURKY_API_KEY` - Lurky analytics (optional)
- `X_CLIENT_ID` - X OAuth (optional)
- `X_CLIENT_SECRET` - X OAuth (optional)

## Extension Points

Engineers can extend this system by:
1. Connecting real video generation services to `/api/video/generate`
2. Implementing actual KDP publishing in `/api/creator/publish`
3. Embedding 3D scenes in `/business/meetings`
4. Adding real AI text generation to `/api/npc/answer-video`
5. Implementing user authentication and sessions

## Architecture Notes

- **Modular design** - Each domain (NPC, AKIRA, CREATOR, BUSINESS) is isolated
- **Type-safe** - Full TypeScript coverage with strict types
- **Extensible** - Clear TODO markers for integration points
- **Production-ready** - Error handling, validation, structured responses
- **Mobile-optimized** - All UI is responsive and touch-friendly

## Support

For issues or questions about the Nano Banana implementation, refer to:
- `/types/index.ts` - Core type definitions
- `/config/video-engine.ts` - Avatar and environment configs
- `/config/story-engine.ts` - Story system configs
- This README

---

**WIRED CHAOS META** - Answer + 3D Video + Avatar System v1.0
