/**
 * WIRED CHAOS META - TWO-TIER FIREWALL SYSTEM
 *
 * Tier 1: Business Firewall - Blocks Akashic/ARG/Lore content
 * Tier 2: Akashic Firewall - Blocks business from seeing metaphysics
 *
 * NFT holders bypass all restrictions with reduced rates
 */

export type AccessTier = "BUSINESS" | "AKASHIC" | "FULL_ACCESS" | "GUEST"

export type NFTType = "WIRED_CHAOS_META_NFT" | "PATCH_NFT" | "AKASHIC_NFT" | "FOUNDER_NFT" | "NONE"

export interface UserAccess {
  userId: string
  tier: AccessTier
  nftType: NFTType
  ownedPatches: string[]
  isFounder: boolean
  isAdmin: boolean
}

// Content categories for firewall filtering
export const BUSINESS_BLOCKED_CONTENT = [
  "akashic",
  "arg",
  "rogue-frequency",
  "vault-33",
  "589-theory",
  "vrg33589",
  "clockfall",
  "neuro-triplets",
  "bloodlines",
  "pantheons",
  "sacred-geometry",
] as const

export const AKASHIC_BLOCKED_CONTENT = [
  // Akashic users see simplified business, not full business logic
  "business-admin",
  "white-label-config",
  "seat-management",
  "billing-admin",
] as const

export const BUSINESS_ALLOWED_PATCHES = [
  "business",
  "education",
  "npc", // Limited unless NFT holder
] as const

export const AKASHIC_ALLOWED_PATCHES = [
  "akira-codex",
  "neteru",
  "vrg33589",
  "vault33",
  "rogue-frequency",
  "589-magazine",
  "789-studios",
  "npc",
  "business", // Simplified view
] as const

/**
 * Determine user access tier based on NFT ownership
 */
export function determineAccessTier(user: Partial<UserAccess>): AccessTier {
  // Admin always has full access
  if (user.isAdmin) return "FULL_ACCESS"

  // Founder NFT = full access
  if (user.isFounder || user.nftType === "FOUNDER_NFT") return "FULL_ACCESS"

  // WIRED CHAOS META NFT = full access
  if (user.nftType === "WIRED_CHAOS_META_NFT") return "FULL_ACCESS"

  // Akashic NFT = Akashic tier
  if (user.nftType === "AKASHIC_NFT") return "AKASHIC"

  // Patch NFT = depends on which patch
  if (user.nftType === "PATCH_NFT" && user.ownedPatches?.length) {
    const hasAkashicPatch = user.ownedPatches.some((p) =>
      ["akira-codex", "neteru", "vrg33589", "vault33", "589-magazine"].includes(p),
    )
    if (hasAkashicPatch) return "AKASHIC"
    return "BUSINESS"
  }

  // No NFT = guest (most restricted)
  if (user.nftType === "NONE" || !user.nftType) return "GUEST"

  return "BUSINESS"
}

/**
 * Check if user can access specific content
 */
export function canAccessContent(user: UserAccess, contentType: string): boolean {
  const tier = determineAccessTier(user)

  // Full access bypasses all firewalls
  if (tier === "FULL_ACCESS") return true

  // Business tier - blocked from Akashic content
  if (tier === "BUSINESS") {
    return !BUSINESS_BLOCKED_CONTENT.includes(contentType as any)
  }

  // Akashic tier - blocked from business admin content
  if (tier === "AKASHIC") {
    return !AKASHIC_BLOCKED_CONTENT.includes(contentType as any)
  }

  // Guest - very limited access
  if (tier === "GUEST") {
    const guestAllowed = ["business", "education", "public"]
    return guestAllowed.includes(contentType)
  }

  return false
}

/**
 * Check if user can access specific patch
 */
export function canAccessPatch(user: UserAccess, patchSlug: string): boolean {
  const tier = determineAccessTier(user)

  // Full access = all patches
  if (tier === "FULL_ACCESS") return true

  // Check if user owns this specific patch NFT
  if (user.ownedPatches?.includes(patchSlug)) return true

  // NPC special case - token-gated unless NFT holder
  if (patchSlug === "npc") {
    return user.nftType !== "NONE" && user.nftType !== undefined
  }

  // Business tier
  if (tier === "BUSINESS") {
    return BUSINESS_ALLOWED_PATCHES.includes(patchSlug as any)
  }

  // Akashic tier
  if (tier === "AKASHIC") {
    return AKASHIC_ALLOWED_PATCHES.includes(patchSlug as any)
  }

  // Guest - business and education only
  if (tier === "GUEST") {
    return ["business", "education"].includes(patchSlug)
  }

  return false
}

/**
 * Get filtered navigation based on access tier
 */
export function getFilteredNavigation(user: UserAccess): string[] {
  const tier = determineAccessTier(user)

  const baseNav = ["dashboard", "profile", "settings"]

  if (tier === "FULL_ACCESS") {
    return [
      ...baseNav,
      "business",
      "education",
      "npc",
      "akira-codex",
      "neteru",
      "789-studios",
      "589-magazine",
      "vrg33589",
      "vault33",
      "rogue-frequency",
      "33fm",
      "swarm",
      "gallery",
    ]
  }

  if (tier === "AKASHIC") {
    return [
      ...baseNav,
      "akira-codex",
      "neteru",
      "789-studios",
      "589-magazine",
      "npc",
      "business", // Simplified
    ]
  }

  if (tier === "BUSINESS") {
    return [...baseNav, "business", "education"]
  }

  // Guest
  return [...baseNav, "business"]
}

/**
 * Firewall middleware check
 */
export function firewallCheck(
  user: UserAccess,
  requestedPath: string,
): { allowed: boolean; redirectTo?: string; reason?: string } {
  // Extract patch/content from path
  const pathParts = requestedPath.split("/").filter(Boolean)
  const primarySegment = pathParts[0]

  // Public paths always allowed
  const publicPaths = ["", "login", "register", "about", "pricing"]
  if (publicPaths.includes(primarySegment)) {
    return { allowed: true }
  }

  // Check patch access
  if (!canAccessPatch(user, primarySegment)) {
    // Determine redirect based on tier
    const tier = determineAccessTier(user)

    if (tier === "GUEST") {
      return {
        allowed: false,
        redirectTo: "/pricing",
        reason: "NFT_REQUIRED",
      }
    }

    if (tier === "BUSINESS") {
      return {
        allowed: false,
        redirectTo: "/business",
        reason: "AKASHIC_CONTENT_BLOCKED",
      }
    }

    return {
      allowed: false,
      redirectTo: "/dashboard",
      reason: "ACCESS_DENIED",
    }
  }

  return { allowed: true }
}
