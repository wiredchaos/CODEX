// 789 STUDIOS & WIRED CHAOS SOCIAL CONFIGURATION

export interface SocialAccount {
  id: string
  platform: "x" | "instagram" | "youtube" | "tiktok" | "twitch"
  name: string
  handle: string
  url: string
  description: string
  category: "wired-chaos" | "789-studios" | "33fm" | "crew"
  verified: boolean
  followers?: string
}

export const SOCIAL_ACCOUNTS: SocialAccount[] = [
  // WIRED CHAOS META
  {
    id: "wired-chaos-meta",
    platform: "x",
    name: "WIRED CHAOS META",
    handle: "@wiredchaosmeta",
    url: "https://x.com/wiredchaosmeta",
    description: "Official WIRED CHAOS META ecosystem account",
    category: "wired-chaos",
    verified: true,
  },
  // 789 STUDIOS
  {
    id: "789-studios",
    platform: "x",
    name: "789 Studios",
    handle: "@789studios",
    url: "https://x.com/789studios",
    description: "Official 789 Studios production hub",
    category: "789-studios",
    verified: true,
  },
  // 33.3FM
  {
    id: "33fm-dogechain",
    platform: "x",
    name: "33.3FM DOGECHAIN",
    handle: "@33fmDOGECHAIN",
    url: "https://x.com/33fmDOGECHAIN",
    description: "The frequency of the future",
    category: "33fm",
    verified: true,
  },
  // CREW
  {
    id: "neuro-meta-x",
    platform: "x",
    name: "NEURO META X",
    handle: "@neurometax",
    url: "https://x.com/neurometax",
    description: "Architect of WIRED CHAOS",
    category: "crew",
    verified: true,
  },
  {
    id: "vibes-meta-x",
    platform: "x",
    name: "VIBES META X",
    handle: "@Vibesmetax",
    url: "https://x.com/Vibesmetax",
    description: "Creative Director",
    category: "crew",
    verified: true,
  },
]

export function getSocialsByCategory(category: SocialAccount["category"]): SocialAccount[] {
  return SOCIAL_ACCOUNTS.filter((s) => s.category === category)
}

export function getAllSocials(): SocialAccount[] {
  return SOCIAL_ACCOUNTS
}
