// 789 STUDIOS CREW REGISTRY
// Official crew member database for 789 Studios

export type CrewRole = "founder" | "creative-director" | "producer" | "engineer" | "artist" | "host" | "advisor"

export type SocialPlatform = "x" | "instagram" | "youtube" | "tiktok" | "twitch"

export interface CrewMember {
  id: string
  name: string
  handle: string
  role: CrewRole
  title: string
  bio: string
  avatar: string
  socials: {
    platform: SocialPlatform
    url: string
    handle: string
  }[]
  featured: boolean
  joinedAt: string
  badges: string[]
}

export const CREW_REGISTRY: CrewMember[] = [
  {
    id: "neuro-meta-x",
    name: "NEURO META X",
    handle: "@neurometax",
    role: "founder",
    title: "Chief Architect & Visionary",
    bio: "Architect of the WIRED CHAOS META ecosystem. Builder of systems, creator of worlds, guardian of the signal.",
    avatar: "/avatars/neuro-meta-x.png",
    socials: [{ platform: "x", url: "https://x.com/neurometax", handle: "@neurometax" }],
    featured: true,
    joinedAt: "2024-01-01",
    badges: ["founder", "architect", "visionary"],
  },
  {
    id: "vibes-meta-x",
    name: "VIBES META X",
    handle: "@Vibesmetax",
    role: "creative-director",
    title: "Creative Director & Vibe Curator",
    bio: "Master of aesthetics and atmosphere. Curating the energy that flows through every 789 production.",
    avatar: "/avatars/vibes-meta-x.png",
    socials: [{ platform: "x", url: "https://x.com/Vibesmetax", handle: "@Vibesmetax" }],
    featured: true,
    joinedAt: "2024-01-01",
    badges: ["creative", "curator", "vibe-master"],
  },
]

export function getCrewMember(id: string): CrewMember | undefined {
  return CREW_REGISTRY.find((m) => m.id === id)
}

export function getFeaturedCrew(): CrewMember[] {
  return CREW_REGISTRY.filter((m) => m.featured)
}

export function getCrewByRole(role: CrewRole): CrewMember[] {
  return CREW_REGISTRY.filter((m) => m.role === role)
}
