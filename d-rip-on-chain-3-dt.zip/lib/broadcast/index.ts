/**
 * WIRED CHAOS META — AVATAR LIVE MODE v33
 * Complete Broadcast Network Export
 */

// Types
export * from "./types"

// Phase 1: Neural Auto-Animator
export * from "./auto-animator"

// Phase 2: Voiceprint Masquerade
export * from "./voice-mask"

// Phase 3: Timeline-Synced FX
export * from "./timeline-fx"

// Phase 4: Viewer-Triggered Avatar Control
export * from "./viewer-control"

// Phase 5: Cross-System Automation
export * from "./cross-system"

// Phase 6: Broadcast Quality Enhancement
export * from "./quality"

// Session Manager
export * from "./session"

// Version
export const BROADCAST_VERSION = "v33"
export const BROADCAST_CODENAME = "Avatar Live Mode"
