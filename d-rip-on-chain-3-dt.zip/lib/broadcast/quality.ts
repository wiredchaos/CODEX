/**
 * PHASE 6 — BROADCAST QUALITY ENHANCEMENT
 * 1080p60 rendering, adaptive bitrate, latency tiers
 */

import type { BroadcastQualityConfig, StreamConfig, LatencyTier, Resolution } from "./types"

// ============================================
// DEFAULT CONFIGURATIONS
// ============================================

export const DEFAULT_QUALITY_CONFIG: BroadcastQualityConfig = {
  resolution: "1080p60",
  bitrate: 6000,
  latencyTier: "standard",
  adaptiveBitrate: true,
  persistenceCache: true,
  hardwareAcceleration: true,
}

export const DEFAULT_STREAM_CONFIG: StreamConfig = {
  rtmpUrl: "",
  streamKey: "",
  backup: true,
  failoverNodes: [],
  encryption: false,
}

// ============================================
// RESOLUTION PRESETS
// ============================================

export interface ResolutionPreset {
  id: Resolution
  width: number
  height: number
  fps: number
  minBitrate: number
  maxBitrate: number
  recommendedBitrate: number
}

export const RESOLUTION_PRESETS: ResolutionPreset[] = [
  {
    id: "720p30",
    width: 1280,
    height: 720,
    fps: 30,
    minBitrate: 2500,
    maxBitrate: 4000,
    recommendedBitrate: 3000,
  },
  {
    id: "1080p30",
    width: 1920,
    height: 1080,
    fps: 30,
    minBitrate: 4000,
    maxBitrate: 6000,
    recommendedBitrate: 4500,
  },
  {
    id: "1080p60",
    width: 1920,
    height: 1080,
    fps: 60,
    minBitrate: 5000,
    maxBitrate: 8000,
    recommendedBitrate: 6000,
  },
  {
    id: "4k30",
    width: 3840,
    height: 2160,
    fps: 30,
    minBitrate: 12000,
    maxBitrate: 20000,
    recommendedBitrate: 15000,
  },
]

// ============================================
// LATENCY CONFIGURATIONS
// ============================================

export interface LatencyConfig {
  tier: LatencyTier
  name: string
  description: string
  targetLatency: number // milliseconds
  bufferSize: number // seconds
  keyframeInterval: number // seconds
  useCases: string[]
}

export const LATENCY_CONFIGS: LatencyConfig[] = [
  {
    tier: "ultra_low",
    name: "Ultra Low Latency",
    description: "For interviews and real-time interaction",
    targetLatency: 1000,
    bufferSize: 0.5,
    keyframeInterval: 1,
    useCases: ["interviews", "live Q&A", "gaming", "auctions"],
  },
  {
    tier: "standard",
    name: "Standard",
    description: "Balanced quality and latency for live shows",
    targetLatency: 4000,
    bufferSize: 2,
    keyframeInterval: 2,
    useCases: ["live shows", "podcasts", "tutorials", "performances"],
  },
  {
    tier: "secure_encrypted",
    name: "Secure Encrypted",
    description: "For sensitive lore transmissions and private content",
    targetLatency: 8000,
    bufferSize: 4,
    keyframeInterval: 4,
    useCases: ["private meetings", "lore reveals", "secure broadcasts"],
  },
]

// ============================================
// BROADCAST QUALITY ENGINE
// ============================================

export class BroadcastQualityEngine {
  private config: BroadcastQualityConfig
  private streamConfig: StreamConfig
  private currentBitrate: number
  private bandwidthHistory: number[] = []

  constructor(qualityConfig: Partial<BroadcastQualityConfig> = {}, streamConfig: Partial<StreamConfig> = {}) {
    this.config = { ...DEFAULT_QUALITY_CONFIG, ...qualityConfig }
    this.streamConfig = { ...DEFAULT_STREAM_CONFIG, ...streamConfig }
    this.currentBitrate = this.config.bitrate
  }

  getResolutionPreset(): ResolutionPreset {
    return RESOLUTION_PRESETS.find((p) => p.id === this.config.resolution) || RESOLUTION_PRESETS[2]
  }

  getLatencyConfig(): LatencyConfig {
    return LATENCY_CONFIGS.find((c) => c.tier === this.config.latencyTier) || LATENCY_CONFIGS[1]
  }

  measureBandwidth(sampleKbps: number): void {
    this.bandwidthHistory.push(sampleKbps)
    if (this.bandwidthHistory.length > 30) {
      this.bandwidthHistory.shift()
    }

    if (this.config.adaptiveBitrate) {
      this.adjustBitrate()
    }
  }

  private adjustBitrate(): void {
    if (this.bandwidthHistory.length < 5) return

    const avgBandwidth = this.bandwidthHistory.reduce((a, b) => a + b, 0) / this.bandwidthHistory.length

    const preset = this.getResolutionPreset()
    const targetBitrate = Math.min(Math.max(avgBandwidth * 0.8, preset.minBitrate), preset.maxBitrate)

    // Smooth adjustment
    const diff = targetBitrate - this.currentBitrate
    this.currentBitrate += diff * 0.3

    console.log(`[Quality] Adjusted bitrate: ${Math.round(this.currentBitrate)} kbps`)
  }

  getEncoderSettings(): EncoderSettings {
    const resolution = this.getResolutionPreset()
    const latency = this.getLatencyConfig()

    return {
      // Video settings
      width: resolution.width,
      height: resolution.height,
      fps: resolution.fps,
      bitrate: Math.round(this.currentBitrate),
      codec: "h264",
      profile: resolution.fps > 30 ? "high" : "main",
      preset: this.config.hardwareAcceleration ? "nvenc" : "medium",
      keyframeInterval: latency.keyframeInterval,

      // Buffer settings
      bufferSize: latency.bufferSize,
      maxBFrames: latency.tier === "ultra_low" ? 0 : 2,

      // Audio settings
      audioCodec: "aac",
      audioBitrate: 192,
      audioSampleRate: 48000,

      // Advanced
      hardwareAcceleration: this.config.hardwareAcceleration,
      persistenceCache: this.config.persistenceCache,
    }
  }

  generateFFmpegCommand(): string {
    const settings = this.getEncoderSettings()
    const latency = this.getLatencyConfig()

    return `ffmpeg -f lavfi -i testsrc=size=${settings.width}x${settings.height}:rate=${settings.fps} \\
  -c:v libx264 \\
  -preset ${settings.preset === "nvenc" ? "p4" : settings.preset} \\
  -profile:v ${settings.profile} \\
  -b:v ${settings.bitrate}k \\
  -maxrate ${Math.round(settings.bitrate * 1.2)}k \\
  -bufsize ${Math.round(settings.bitrate * settings.bufferSize)}k \\
  -g ${settings.fps * settings.keyframeInterval} \\
  -bf ${settings.maxBFrames} \\
  -c:a ${settings.audioCodec} \\
  -b:a ${settings.audioBitrate}k \\
  -ar ${settings.audioSampleRate} \\
  -f flv "${this.streamConfig.rtmpUrl}/${this.streamConfig.streamKey}"`
  }

  setupFailover(primaryUrl: string, backupUrls: string[]): void {
    this.streamConfig.rtmpUrl = primaryUrl
    this.streamConfig.failoverNodes = backupUrls
    this.streamConfig.backup = backupUrls.length > 0
  }

  getHealthStatus(): StreamHealth {
    const avgBandwidth =
      this.bandwidthHistory.length > 0
        ? this.bandwidthHistory.reduce((a, b) => a + b, 0) / this.bandwidthHistory.length
        : 0

    const preset = this.getResolutionPreset()
    const stability =
      this.bandwidthHistory.length > 0
        ? 1 - Math.min(this.calculateVariance(this.bandwidthHistory) / avgBandwidth, 1)
        : 1

    return {
      status:
        avgBandwidth > preset.recommendedBitrate * 1.2
          ? "excellent"
          : avgBandwidth > preset.minBitrate
            ? "good"
            : "poor",
      currentBitrate: Math.round(this.currentBitrate),
      avgBandwidth: Math.round(avgBandwidth),
      stability: Math.round(stability * 100),
      failoverReady: this.streamConfig.backup,
      activeNodes: this.streamConfig.failoverNodes.length + 1,
    }
  }

  private calculateVariance(arr: number[]): number {
    const mean = arr.reduce((a, b) => a + b, 0) / arr.length
    return Math.sqrt(arr.reduce((sq, n) => sq + Math.pow(n - mean, 2), 0) / arr.length)
  }

  getConfig(): BroadcastQualityConfig {
    return { ...this.config }
  }

  getStreamConfig(): StreamConfig {
    return { ...this.streamConfig }
  }

  updateConfig(updates: Partial<BroadcastQualityConfig>): void {
    this.config = { ...this.config, ...updates }
    if (updates.bitrate) {
      this.currentBitrate = updates.bitrate
    }
  }
}

export interface EncoderSettings {
  width: number
  height: number
  fps: number
  bitrate: number
  codec: string
  profile: string
  preset: string
  keyframeInterval: number
  bufferSize: number
  maxBFrames: number
  audioCodec: string
  audioBitrate: number
  audioSampleRate: number
  hardwareAcceleration: boolean
  persistenceCache: boolean
}

export interface StreamHealth {
  status: "excellent" | "good" | "poor"
  currentBitrate: number
  avgBandwidth: number
  stability: number
  failoverReady: boolean
  activeNodes: number
}

export function createBroadcastQuality(
  qualityConfig?: Partial<BroadcastQualityConfig>,
  streamConfig?: Partial<StreamConfig>,
): BroadcastQualityEngine {
  return new BroadcastQualityEngine(qualityConfig, streamConfig)
}

export function getResolutionPreset(id: Resolution): ResolutionPreset | undefined {
  return RESOLUTION_PRESETS.find((p) => p.id === id)
}

export function getLatencyConfig(tier: LatencyTier): LatencyConfig | undefined {
  return LATENCY_CONFIGS.find((c) => c.tier === tier)
}
