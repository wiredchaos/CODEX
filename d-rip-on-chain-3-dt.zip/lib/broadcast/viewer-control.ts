/**
 * PHASE 4 — VIEWER-TRIGGERED AVATAR CONTROL
 * Interactive engagement with rate-limited control
 */

import type { ViewerControlConfig, ViewerTrigger, ViewerTriggerAction } from "./types"

// ============================================
// DEFAULT CONFIGURATION
// ============================================

export const DEFAULT_VIEWER_CONTROL_CONFIG: ViewerControlConfig = {
  enabled: true,
  allowedActions: ["wave", "head_nod", "power_glyph", "glitch_burst", "hype_gesture"],
  rateLimit: 30,
  cooldownSeconds: 5,
  requiresSubscriber: false,
  costPerAction: 0,
}

// ============================================
// VIEWER TRIGGER DEFINITIONS
// ============================================

export const VIEWER_TRIGGERS: ViewerTrigger[] = [
  {
    action: "wave",
    animation: "avatar-wave",
    duration: 1.5,
    visualFx: "friendly-glow",
    restricted: false,
    subscriberOnly: false,
  },
  {
    action: "head_nod",
    animation: "avatar-nod",
    duration: 1.0,
    visualFx: "subtle-pulse",
    restricted: false,
    subscriberOnly: false,
  },
  {
    action: "power_glyph",
    animation: "avatar-power-glyph",
    duration: 2.5,
    visualFx: "glyph-projection",
    audioFx: "power-charge",
    restricted: false,
    subscriberOnly: false,
  },
  {
    action: "glitch_burst",
    animation: "avatar-glitch",
    duration: 1.5,
    visualFx: "33fm-glitch",
    audioFx: "static-burst",
    restricted: false,
    subscriberOnly: false,
  },
  {
    action: "mic_drop",
    animation: "redfang-mic-drop",
    duration: 3.0,
    visualFx: "bass-shockwave",
    audioFx: "mic-drop-boom",
    restricted: true,
    subscriberOnly: true,
  },
  {
    action: "blade_flare",
    animation: "kiba-blade-flare",
    duration: 2.0,
    visualFx: "red-blade-trail",
    audioFx: "blade-swing",
    restricted: true,
    subscriberOnly: true,
  },
  {
    action: "spectral_shift",
    animation: "shadowlux-shift",
    duration: 2.5,
    visualFx: "shadow-phase",
    audioFx: "void-whisper",
    restricted: true,
    subscriberOnly: true,
  },
  {
    action: "beat_drop",
    animation: "redfang-beat-drop",
    duration: 4.0,
    visualFx: "frequency-shockwave",
    audioFx: "massive-bass-drop",
    restricted: true,
    subscriberOnly: true,
  },
  {
    action: "hype_gesture",
    animation: "avatar-hype",
    duration: 2.0,
    visualFx: "crowd-energy",
    audioFx: "hype-sfx",
    restricted: false,
    subscriberOnly: false,
  },
]

// ============================================
// VIEWER CONTROL ENGINE
// ============================================

export class ViewerControlEngine {
  private config: ViewerControlConfig
  private actionHistory: Map<string, number[]> = new Map()
  private globalCooldown: Map<ViewerTriggerAction, number> = new Map()

  constructor(config: Partial<ViewerControlConfig> = {}) {
    this.config = { ...DEFAULT_VIEWER_CONTROL_CONFIG, ...config }
  }

  canTrigger(
    viewerId: string,
    action: ViewerTriggerAction,
    isSubscriber: boolean,
  ): { allowed: boolean; reason?: string } {
    if (!this.config.enabled) {
      return { allowed: false, reason: "Viewer control is disabled" }
    }

    // Check if action is allowed
    if (!this.config.allowedActions.includes(action)) {
      return { allowed: false, reason: "Action not allowed" }
    }

    // Get trigger definition
    const trigger = VIEWER_TRIGGERS.find((t) => t.action === action)
    if (!trigger) {
      return { allowed: false, reason: "Unknown action" }
    }

    // Check subscriber requirement
    if (trigger.subscriberOnly && !isSubscriber) {
      return { allowed: false, reason: "Subscriber only" }
    }

    // Check global cooldown
    const lastGlobal = this.globalCooldown.get(action) || 0
    if (Date.now() - lastGlobal < this.config.cooldownSeconds * 1000) {
      const remaining = Math.ceil((this.config.cooldownSeconds * 1000 - (Date.now() - lastGlobal)) / 1000)
      return { allowed: false, reason: `Cooldown: ${remaining}s` }
    }

    // Check per-viewer rate limit
    const viewerHistory = this.actionHistory.get(viewerId) || []
    const recentActions = viewerHistory.filter((t) => Date.now() - t < 60000).length

    if (recentActions >= this.config.rateLimit) {
      return { allowed: false, reason: "Rate limit exceeded" }
    }

    return { allowed: true }
  }

  executeTrigger(viewerId: string, action: ViewerTriggerAction, isSubscriber: boolean): ViewerTrigger | null {
    const check = this.canTrigger(viewerId, action, isSubscriber)
    if (!check.allowed) {
      console.log(`[ViewerControl] Denied: ${check.reason}`)
      return null
    }

    const trigger = VIEWER_TRIGGERS.find((t) => t.action === action)
    if (!trigger) return null

    // Record action
    const history = this.actionHistory.get(viewerId) || []
    history.push(Date.now())
    this.actionHistory.set(viewerId, history)

    // Set global cooldown
    this.globalCooldown.set(action, Date.now())

    // Emit trigger
    this.emitTrigger(viewerId, trigger)

    return trigger
  }

  private emitTrigger(viewerId: string, trigger: ViewerTrigger): void {
    console.log(`[ViewerControl] Triggered: ${trigger.action}`, {
      viewer: viewerId,
      animation: trigger.animation,
      visualFx: trigger.visualFx,
      duration: trigger.duration,
    })
  }

  getAvailableActions(isSubscriber: boolean): ViewerTrigger[] {
    return VIEWER_TRIGGERS.filter((t) => {
      if (!this.config.allowedActions.includes(t.action)) return false
      if (t.subscriberOnly && !isSubscriber) return false
      return true
    })
  }

  getActionCooldown(action: ViewerTriggerAction): number {
    const last = this.globalCooldown.get(action) || 0
    const elapsed = Date.now() - last
    const cooldownMs = this.config.cooldownSeconds * 1000

    if (elapsed >= cooldownMs) return 0
    return Math.ceil((cooldownMs - elapsed) / 1000)
  }

  getConfig(): ViewerControlConfig {
    return { ...this.config }
  }

  updateConfig(updates: Partial<ViewerControlConfig>): void {
    this.config = { ...this.config, ...updates }
  }

  // Clean up old history entries
  pruneHistory(): void {
    const cutoff = Date.now() - 60000 // 1 minute

    this.actionHistory.forEach((history, viewerId) => {
      const pruned = history.filter((t) => t > cutoff)
      if (pruned.length === 0) {
        this.actionHistory.delete(viewerId)
      } else {
        this.actionHistory.set(viewerId, pruned)
      }
    })
  }
}

export function createViewerControl(config?: Partial<ViewerControlConfig>): ViewerControlEngine {
  return new ViewerControlEngine(config)
}

export function getTriggerByAction(action: ViewerTriggerAction): ViewerTrigger | undefined {
  return VIEWER_TRIGGERS.find((t) => t.action === action)
}

export function getAllViewerTriggers(): ViewerTrigger[] {
  return [...VIEWER_TRIGGERS]
}
