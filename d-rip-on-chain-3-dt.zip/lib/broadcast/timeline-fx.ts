/**
 * PHASE 3 — TIMELINE-SYNCED FX
 * ARG × AI × Metaverse × 589-coded transmission effects
 */

import type { TimelineFxConfig, TimelineFx, TimelineFxEvent } from "./types"

// ============================================
// DEFAULT CONFIGURATION
// ============================================

export const DEFAULT_TIMELINE_FX_CONFIG: TimelineFxConfig = {
  enabled: true,
  activeEvents: [],
  intensityMultiplier: 1.0,
  syncToLore: true,
  autoTrigger: true,
  triggerThreshold: 0.7,
}

// ============================================
// TIMELINE FX DEFINITIONS
// ============================================

export const TIMELINE_FX_LIBRARY: TimelineFx[] = [
  {
    id: "rfp-001",
    event: "red_fang_pulse",
    visualEffect: "red-pulse-overlay",
    audioEffect: "bass-pulse-thump",
    duration: 2.5,
    intensity: 0.8,
    colorOverlay: ["#FF003C", "#8B0000"],
    particleSystem: "ember-burst",
  },
  {
    id: "v33-001",
    event: "vault_33_shift",
    visualEffect: "gold-sigil-rotation",
    audioEffect: "vault-resonance",
    duration: 4.0,
    intensity: 0.6,
    colorOverlay: ["#D4AF37", "#1A1A1A"],
    particleSystem: "golden-dust",
  },
  {
    id: "m589-001",
    event: "merovingian_589",
    visualEffect: "fibonacci-spiral-overlay",
    audioEffect: "frequency-589hz",
    duration: 5.89,
    intensity: 0.9,
    colorOverlay: ["#4A0033", "#D4AF37", "#FF003C"],
    particleSystem: "sacred-geometry",
  },
  {
    id: "npc-001",
    event: "npc_labyrinth_glow",
    visualEffect: "cyan-circuit-trace",
    audioEffect: "digital-maze-ambient",
    duration: 3.0,
    intensity: 0.5,
    colorOverlay: ["#00F0FF", "#0A0A0A"],
    particleSystem: "data-stream",
  },
  {
    id: "net-001",
    event: "neteru_divination",
    visualEffect: "hieroglyph-projection",
    audioEffect: "ancestral-chant",
    duration: 6.0,
    intensity: 0.7,
    colorOverlay: ["#4A0033", "#D4AF37", "#000000"],
    particleSystem: "divine-symbols",
  },
  {
    id: "dc-001",
    event: "dogechain_glitch",
    visualEffect: "frequency-distortion",
    audioEffect: "radio-static-burst",
    duration: 1.5,
    intensity: 0.85,
    colorOverlay: ["#FF1493", "#00F0FF"],
    particleSystem: "pixel-scatter",
  },
  {
    id: "echo-001",
    event: "echo_distortion",
    visualEffect: "timeline-ripple",
    audioEffect: "echo-void-whisper",
    duration: 2.0,
    intensity: 0.4,
    colorOverlay: ["#1A1A1A", "#3A3A3A"],
    particleSystem: "void-particles",
  },
  {
    id: "sg-001",
    event: "stargate_sync",
    visualEffect: "portal-ring-activation",
    audioEffect: "stargate-harmonic",
    duration: 8.0,
    intensity: 1.0,
    colorOverlay: ["#D4AF37", "#00F0FF", "#FF003C"],
    particleSystem: "wormhole-energy",
  },
]

// ============================================
// LORE TRIGGER CONDITIONS
// ============================================

export interface LoreTrigger {
  event: TimelineFxEvent
  keywords: string[]
  timeConditions?: { hour: number; minute: number }[]
  dateConditions?: { month: number; day: number }[]
  randomChance: number
}

export const LORE_TRIGGERS: LoreTrigger[] = [
  {
    event: "red_fang_pulse",
    keywords: ["red fang", "neuro", "kiba", "pulse", "signal"],
    randomChance: 0.15,
  },
  {
    event: "vault_33_shift",
    keywords: ["vault", "33", "akashic", "artifact", "layer"],
    timeConditions: [{ hour: 3, minute: 33 }],
    randomChance: 0.1,
  },
  {
    event: "merovingian_589",
    keywords: ["589", "fibonacci", "merovingian", "code", "sequence"],
    timeConditions: [{ hour: 5, minute: 8 }],
    randomChance: 0.08,
  },
  {
    event: "npc_labyrinth_glow",
    keywords: ["npc", "labyrinth", "prompt", "training", "maze"],
    randomChance: 0.2,
  },
  {
    event: "neteru_divination",
    keywords: ["neteru", "apinaya", "ancestor", "divination", "bloodline"],
    randomChance: 0.12,
  },
  {
    event: "dogechain_glitch",
    keywords: ["33.3", "radio", "frequency", "doge", "broadcast"],
    randomChance: 0.18,
  },
  {
    event: "echo_distortion",
    keywords: ["echo", "triplet", "timeline", "anomaly", "classified"],
    randomChance: 0.05,
  },
  {
    event: "stargate_sync",
    keywords: ["stargate", "portal", "layer 4", "sync", "gateway"],
    dateConditions: [
      { month: 5, day: 8 },
      { month: 5, day: 9 },
    ],
    randomChance: 0.03,
  },
]

// ============================================
// TIMELINE FX ENGINE
// ============================================

export class TimelineFxEngine {
  private config: TimelineFxConfig
  private activeFx: Map<string, TimelineFx> = new Map()
  private fxQueue: TimelineFx[] = []

  constructor(config: Partial<TimelineFxConfig> = {}) {
    this.config = { ...DEFAULT_TIMELINE_FX_CONFIG, ...config }
  }

  triggerFx(event: TimelineFxEvent): TimelineFx | null {
    if (!this.config.enabled) return null

    const fx = TIMELINE_FX_LIBRARY.find((f) => f.event === event)
    if (!fx) return null

    const scaledFx: TimelineFx = {
      ...fx,
      intensity: fx.intensity * this.config.intensityMultiplier,
    }

    this.activeFx.set(fx.id, scaledFx)
    this.emitFx(scaledFx)

    // Auto-remove after duration
    setTimeout(() => {
      this.activeFx.delete(fx.id)
    }, fx.duration * 1000)

    return scaledFx
  }

  checkLoreTriggers(text: string): TimelineFxEvent[] {
    if (!this.config.syncToLore) return []

    const triggered: TimelineFxEvent[] = []
    const lowerText = text.toLowerCase()

    for (const trigger of LORE_TRIGGERS) {
      const hasKeyword = trigger.keywords.some((kw) => lowerText.includes(kw))

      if (hasKeyword) {
        // Check random chance
        if (Math.random() < trigger.randomChance * this.config.triggerThreshold) {
          triggered.push(trigger.event)
        }
      }
    }

    return triggered
  }

  checkTimeTriggers(): TimelineFxEvent[] {
    if (!this.config.autoTrigger) return []

    const now = new Date()
    const triggered: TimelineFxEvent[] = []

    for (const trigger of LORE_TRIGGERS) {
      // Check time conditions
      if (trigger.timeConditions) {
        for (const tc of trigger.timeConditions) {
          if (now.getHours() === tc.hour && now.getMinutes() === tc.minute) {
            triggered.push(trigger.event)
          }
        }
      }

      // Check date conditions
      if (trigger.dateConditions) {
        for (const dc of trigger.dateConditions) {
          if (now.getMonth() + 1 === dc.month && now.getDate() === dc.day) {
            triggered.push(trigger.event)
          }
        }
      }
    }

    return triggered
  }

  private emitFx(fx: TimelineFx): void {
    console.log(`[TimelineFx] Triggered: ${fx.event}`, {
      visual: fx.visualEffect,
      audio: fx.audioEffect,
      duration: fx.duration,
      intensity: fx.intensity,
    })
  }

  generateFxShader(fx: TimelineFx): string {
    return `
// Timeline FX Shader: ${fx.event}
// ID: ${fx.id}

uniform float u_time;
uniform float u_intensity;
uniform vec3 u_color1;
uniform vec3 u_color2;

void main() {
  vec2 uv = gl_FragCoord.xy / u_resolution.xy;
  
  // Base color from palette
  vec3 color1 = vec3(${this.hexToRgb(fx.colorOverlay[0])});
  vec3 color2 = vec3(${this.hexToRgb(fx.colorOverlay[1] || fx.colorOverlay[0])});
  
  // Intensity-based mix
  float mixFactor = sin(u_time * 2.0) * 0.5 + 0.5;
  vec3 baseColor = mix(color1, color2, mixFactor);
  
  // Apply effect intensity
  float alpha = u_intensity * ${fx.intensity};
  
  gl_FragColor = vec4(baseColor, alpha);
}
`
  }

  private hexToRgb(hex: string): string {
    const r = Number.parseInt(hex.slice(1, 3), 16) / 255
    const g = Number.parseInt(hex.slice(3, 5), 16) / 255
    const b = Number.parseInt(hex.slice(5, 7), 16) / 255
    return `${r.toFixed(3)}, ${g.toFixed(3)}, ${b.toFixed(3)}`
  }

  getActiveFx(): TimelineFx[] {
    return Array.from(this.activeFx.values())
  }

  getConfig(): TimelineFxConfig {
    return { ...this.config }
  }

  updateConfig(updates: Partial<TimelineFxConfig>): void {
    this.config = { ...this.config, ...updates }
  }
}

export function createTimelineFxEngine(config?: Partial<TimelineFxConfig>): TimelineFxEngine {
  return new TimelineFxEngine(config)
}

export function getFxByEvent(event: TimelineFxEvent): TimelineFx | undefined {
  return TIMELINE_FX_LIBRARY.find((fx) => fx.event === event)
}

export function getAllTimelineFx(): TimelineFx[] {
  return [...TIMELINE_FX_LIBRARY]
}
