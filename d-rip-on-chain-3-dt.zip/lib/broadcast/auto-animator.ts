/**
 * PHASE 1 — NEURAL AUTO-ANIMATOR
 * Maintains avatar vitality without requiring continuous user input
 */

import type { AutoAnimatorConfig, IdleAnimation, IdleAnimationType, PersonaTick, EmotionalState } from "./types"

// ============================================
// DEFAULT CONFIGURATIONS
// ============================================

export const DEFAULT_AUTO_ANIMATOR_CONFIG: AutoAnimatorConfig = {
  enabled: true,
  microGestures: true,
  breathSimulation: true,
  eyeTracking: true,
  autonomousPersonaTicks: true,
  emotionalStateWeight: 0.6,
  idleVariance: 0.3,
}

// ============================================
// IDLE ANIMATION DEFINITIONS
// ============================================

export const IDLE_ANIMATIONS: Record<IdleAnimationType, IdleAnimation> = {
  micro_gesture: {
    type: "micro_gesture",
    intensity: 0.15,
    frequency: 8,
    duration: 0.8,
    variance: 0.4,
  },
  breath_simulation: {
    type: "breath_simulation",
    intensity: 0.1,
    frequency: 15,
    duration: 4,
    variance: 0.1,
  },
  eye_tracking: {
    type: "eye_tracking",
    intensity: 0.2,
    frequency: 12,
    duration: 0.5,
    variance: 0.5,
  },
  head_tilt: {
    type: "head_tilt",
    intensity: 0.12,
    frequency: 4,
    duration: 1.2,
    variance: 0.35,
  },
  blink: {
    type: "blink",
    intensity: 1.0,
    frequency: 18,
    duration: 0.15,
    variance: 0.3,
  },
  persona_tick: {
    type: "persona_tick",
    intensity: 0.25,
    frequency: 2,
    duration: 1.5,
    variance: 0.6,
  },
}

// ============================================
// PERSONA TICKS BY AVATAR
// ============================================

export const PERSONA_TICKS: PersonaTick[] = [
  // NEURO META
  {
    avatarId: "neuro-meta",
    behavior: "data_scan",
    trigger: "time",
    interval: 30,
    animation: "meta-data-scan",
  },
  {
    avatarId: "neuro-meta",
    behavior: "red_eye_pulse",
    trigger: "silence",
    interval: 15,
    animation: "meta-eye-pulse",
  },
  // NEURO KIBA
  {
    avatarId: "neuro-kiba",
    behavior: "blade_check",
    trigger: "random",
    interval: 45,
    animation: "kiba-blade-check",
  },
  {
    avatarId: "neuro-kiba",
    behavior: "hood_adjust",
    trigger: "time",
    interval: 60,
    animation: "kiba-hood-adjust",
  },
  // DJ RED FANG
  {
    avatarId: "dj-red-fang",
    behavior: "beat_nod",
    trigger: "time",
    interval: 8,
    animation: "redfang-beat-nod",
  },
  {
    avatarId: "dj-red-fang",
    behavior: "deck_touch",
    trigger: "silence",
    interval: 20,
    animation: "redfang-deck-touch",
  },
  // SHADOWLUX
  {
    avatarId: "shadowlux",
    behavior: "shadow_flicker",
    trigger: "random",
    interval: 25,
    animation: "shadowlux-flicker",
  },
  {
    avatarId: "shadowlux",
    behavior: "encryption_pulse",
    trigger: "time",
    interval: 40,
    animation: "shadowlux-encrypt",
  },
  // GRYMM
  {
    avatarId: "grymm",
    behavior: "stance_shift",
    trigger: "time",
    interval: 50,
    animation: "grymm-stance",
  },
  {
    avatarId: "grymm",
    behavior: "mask_glow",
    trigger: "silence",
    interval: 30,
    animation: "grymm-mask-glow",
  },
]

// ============================================
// EMOTIONAL STATE MODIFIERS
// ============================================

export const EMOTIONAL_MODIFIERS: Record<EmotionalState, Record<string, number>> = {
  neutral: {
    gestureIntensity: 1.0,
    blinkRate: 1.0,
    breathDepth: 1.0,
    headMovement: 1.0,
  },
  engaged: {
    gestureIntensity: 1.4,
    blinkRate: 0.8,
    breathDepth: 1.1,
    headMovement: 1.3,
  },
  contemplative: {
    gestureIntensity: 0.6,
    blinkRate: 1.2,
    breathDepth: 1.3,
    headMovement: 0.5,
  },
  energized: {
    gestureIntensity: 1.8,
    blinkRate: 0.7,
    breathDepth: 1.4,
    headMovement: 1.6,
  },
  mysterious: {
    gestureIntensity: 0.4,
    blinkRate: 0.6,
    breathDepth: 0.8,
    headMovement: 0.3,
  },
  commanding: {
    gestureIntensity: 1.2,
    blinkRate: 0.5,
    breathDepth: 1.2,
    headMovement: 0.8,
  },
  playful: {
    gestureIntensity: 1.6,
    blinkRate: 1.1,
    breathDepth: 1.0,
    headMovement: 1.5,
  },
}

// ============================================
// AUTO-ANIMATOR ENGINE
// ============================================

export class AutoAnimatorEngine {
  private config: AutoAnimatorConfig
  private currentState: EmotionalState = "neutral"
  private activeAnimations: Map<string, NodeJS.Timeout> = new Map()
  private lastActivity: number = Date.now()

  constructor(config: Partial<AutoAnimatorConfig> = {}) {
    this.config = { ...DEFAULT_AUTO_ANIMATOR_CONFIG, ...config }
  }

  start(avatarId: string): void {
    if (!this.config.enabled) return

    // Start breath simulation
    if (this.config.breathSimulation) {
      this.startBreathCycle()
    }

    // Start micro gestures
    if (this.config.microGestures) {
      this.startMicroGestures()
    }

    // Start eye tracking
    if (this.config.eyeTracking) {
      this.startEyeTracking()
    }

    // Start persona ticks
    if (this.config.autonomousPersonaTicks) {
      this.startPersonaTicks(avatarId)
    }
  }

  stop(): void {
    this.activeAnimations.forEach((timer) => clearInterval(timer))
    this.activeAnimations.clear()
  }

  setEmotionalState(state: EmotionalState): void {
    this.currentState = state
  }

  recordActivity(): void {
    this.lastActivity = Date.now()
  }

  private startBreathCycle(): void {
    const breath = IDLE_ANIMATIONS.breath_simulation
    const interval = (60 / breath.frequency) * 1000

    const timer = setInterval(() => {
      const modifier = EMOTIONAL_MODIFIERS[this.currentState]
      this.emitAnimation("breath", {
        intensity: breath.intensity * modifier.breathDepth,
        duration: breath.duration,
      })
    }, interval)

    this.activeAnimations.set("breath", timer)
  }

  private startMicroGestures(): void {
    const gesture = IDLE_ANIMATIONS.micro_gesture
    const baseInterval = (60 / gesture.frequency) * 1000

    const timer = setInterval(() => {
      const variance = 1 + (Math.random() - 0.5) * gesture.variance * 2
      const modifier = EMOTIONAL_MODIFIERS[this.currentState]

      this.emitAnimation("micro_gesture", {
        intensity: gesture.intensity * modifier.gestureIntensity * variance,
        duration: gesture.duration * variance,
        type: this.selectGestureType(),
      })
    }, baseInterval)

    this.activeAnimations.set("micro_gesture", timer)
  }

  private startEyeTracking(): void {
    const eye = IDLE_ANIMATIONS.eye_tracking
    const interval = (60 / eye.frequency) * 1000

    const timer = setInterval(() => {
      // Simulate eye movement based on elapsed time since last activity
      const silenceDuration = Date.now() - this.lastActivity
      const wanderFactor = Math.min(silenceDuration / 10000, 1)

      this.emitAnimation("eye_track", {
        x: (Math.random() - 0.5) * wanderFactor,
        y: (Math.random() - 0.5) * wanderFactor * 0.5,
        duration: eye.duration,
      })
    }, interval)

    this.activeAnimations.set("eye_tracking", timer)
  }

  private startPersonaTicks(avatarId: string): void {
    const avatarTicks = PERSONA_TICKS.filter((t) => t.avatarId === avatarId)

    avatarTicks.forEach((tick) => {
      const interval = tick.interval * 1000

      const timer = setInterval(() => {
        if (tick.trigger === "silence") {
          const silenceDuration = Date.now() - this.lastActivity
          if (silenceDuration < 5000) return
        }

        if (tick.trigger === "random" && Math.random() > 0.3) return

        this.emitAnimation("persona_tick", {
          behavior: tick.behavior,
          animation: tick.animation,
        })
      }, interval)

      this.activeAnimations.set(`tick_${tick.behavior}`, timer)
    })
  }

  private selectGestureType(): string {
    const gestures = ["subtle_nod", "slight_tilt", "shoulder_shift", "hand_adjust", "weight_shift"]
    return gestures[Math.floor(Math.random() * gestures.length)]
  }

  private emitAnimation(type: string, data: Record<string, unknown>): void {
    // This would emit to the 3D rendering system
    console.log(`[AutoAnimator] ${type}:`, data)
  }

  getConfig(): AutoAnimatorConfig {
    return { ...this.config }
  }

  updateConfig(updates: Partial<AutoAnimatorConfig>): void {
    this.config = { ...this.config, ...updates }
  }
}

export function createAutoAnimator(config?: Partial<AutoAnimatorConfig>): AutoAnimatorEngine {
  return new AutoAnimatorEngine(config)
}

export function getPersonaTicksForAvatar(avatarId: string): PersonaTick[] {
  return PERSONA_TICKS.filter((t) => t.avatarId === avatarId)
}
