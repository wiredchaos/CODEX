/**
 * AVATAR LIVE MODE v33 — BROADCAST SESSION MANAGER
 * Orchestrates all phases into a unified broadcast experience
 */

import type {
  BroadcastSession,
  BroadcastEvent,
  AutoAnimatorConfig,
  VoiceMaskConfig,
  TimelineFxConfig,
  ViewerControlConfig,
  CrossSystemConfig,
  BroadcastQualityConfig,
  StreamConfig,
} from "./types"
import { type AutoAnimatorEngine, createAutoAnimator } from "./auto-animator"
import { type VoiceMaskEngine, createVoiceMask } from "./voice-mask"
import { type TimelineFxEngine, createTimelineFxEngine } from "./timeline-fx"
import { type ViewerControlEngine, createViewerControl } from "./viewer-control"
import { type CrossSystemEngine, createCrossSystem } from "./cross-system"
import { type BroadcastQualityEngine, createBroadcastQuality } from "./quality"

// ============================================
// SESSION MANAGER
// ============================================

export class BroadcastSessionManager {
  private session: BroadcastSession
  private autoAnimator: AutoAnimatorEngine
  private voiceMask: VoiceMaskEngine
  private timelineFx: TimelineFxEngine
  private viewerControl: ViewerControlEngine
  private crossSystem: CrossSystemEngine
  private quality: BroadcastQualityEngine
  private eventLog: BroadcastEvent[] = []

  constructor(
    userId: string,
    avatarId: string,
    config?: {
      autoAnimator?: Partial<AutoAnimatorConfig>
      voiceMask?: Partial<VoiceMaskConfig>
      timelineFx?: Partial<TimelineFxConfig>
      viewerControl?: Partial<ViewerControlConfig>
      crossSystem?: Partial<CrossSystemConfig>
      quality?: Partial<BroadcastQualityConfig>
      stream?: Partial<StreamConfig>
    },
  ) {
    // Initialize all engines
    this.autoAnimator = createAutoAnimator(config?.autoAnimator)
    this.voiceMask = createVoiceMask(config?.voiceMask)
    this.timelineFx = createTimelineFxEngine(config?.timelineFx)
    this.viewerControl = createViewerControl(config?.viewerControl)
    this.crossSystem = createCrossSystem(config?.crossSystem)
    this.quality = createBroadcastQuality(config?.quality, config?.stream)

    // Initialize session
    this.session = {
      id: this.generateSessionId(),
      userId,
      avatarId,
      status: "idle",
      autoAnimator: this.autoAnimator.getConfig(),
      voiceMask: this.voiceMask.getConfig(),
      timelineFx: this.timelineFx.getConfig(),
      viewerControl: this.viewerControl.getConfig(),
      crossSystem: this.crossSystem.getConfig(),
      quality: this.quality.getConfig(),
      stream: this.quality.getStreamConfig(),
      viewerCount: 0,
      peakViewers: 0,
      totalInteractions: 0,
    }
  }

  private generateSessionId(): string {
    return `WCM-LIVE-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
  }

  // ============================================
  // SESSION LIFECYCLE
  // ============================================

  async start(): Promise<void> {
    if (this.session.status === "live") {
      throw new Error("Session already live")
    }

    this.session.status = "preparing"
    this.session.startedAt = new Date()

    // Start all engines
    this.autoAnimator.start(this.session.avatarId)

    // Log start event
    await this.logEvent("start", { avatarId: this.session.avatarId })

    this.session.status = "live"
    console.log(`[Session] Started: ${this.session.id}`)
  }

  async pause(): Promise<void> {
    if (this.session.status !== "live") return

    this.session.status = "paused"
    this.autoAnimator.stop()

    await this.logEvent("system", { action: "pause" })
  }

  async resume(): Promise<void> {
    if (this.session.status !== "paused") return

    this.autoAnimator.start(this.session.avatarId)
    this.session.status = "live"

    await this.logEvent("system", { action: "resume" })
  }

  async end(): Promise<void> {
    if (this.session.status === "ended") return

    this.autoAnimator.stop()
    this.session.status = "ended"
    this.session.endedAt = new Date()

    // Generate VOD if enabled
    if (this.session.crossSystem.vodGeneration && this.session.startedAt) {
      const duration = (this.session.endedAt.getTime() - this.session.startedAt.getTime()) / 1000
      await this.crossSystem.generateVod(this.session.id, duration)
    }

    // Flush cross-system queue
    await this.crossSystem.flushQueue()

    // Log end event
    await this.logEvent("stop", {
      duration: this.session.startedAt ? (this.session.endedAt.getTime() - this.session.startedAt.getTime()) / 1000 : 0,
      peakViewers: this.session.peakViewers,
      totalInteractions: this.session.totalInteractions,
    })

    console.log(`[Session] Ended: ${this.session.id}`)
  }

  // ============================================
  // ENGINE INTERACTIONS
  // ============================================

  triggerTimelineFx(event: Parameters<TimelineFxEngine["triggerFx"]>[0]): void {
    const fx = this.timelineFx.triggerFx(event)
    if (fx) {
      this.logEvent("fx", { event, fx })
    }
  }

  processViewerTrigger(
    viewerId: string,
    action: Parameters<ViewerControlEngine["executeTrigger"]>[1],
    isSubscriber: boolean,
  ): void {
    const trigger = this.viewerControl.executeTrigger(viewerId, action, isSubscriber)
    if (trigger) {
      this.session.totalInteractions++
      this.logEvent("interaction", {
        viewerId,
        action,
        trigger,
        highlight: trigger.subscriberOnly,
      })
    }
  }

  updateViewerCount(count: number): void {
    this.session.viewerCount = count
    if (count > this.session.peakViewers) {
      this.session.peakViewers = count
    }
  }

  recordActivity(): void {
    this.autoAnimator.recordActivity()
  }

  // ============================================
  // CONFIGURATION
  // ============================================

  getSession(): BroadcastSession {
    return { ...this.session }
  }

  getEngines() {
    return {
      autoAnimator: this.autoAnimator,
      voiceMask: this.voiceMask,
      timelineFx: this.timelineFx,
      viewerControl: this.viewerControl,
      crossSystem: this.crossSystem,
      quality: this.quality,
    }
  }

  getEventLog(): BroadcastEvent[] {
    return [...this.eventLog]
  }

  getStreamHealth() {
    return this.quality.getHealthStatus()
  }

  // ============================================
  // EVENT LOGGING
  // ============================================

  private async logEvent(type: BroadcastEvent["type"], payload: Record<string, unknown>): Promise<void> {
    const event: BroadcastEvent = {
      id: `${this.session.id}-${this.eventLog.length}`,
      sessionId: this.session.id,
      timestamp: new Date(),
      type,
      payload,
    }

    this.eventLog.push(event)

    // Process through cross-system automation
    await this.crossSystem.processEvent(event)
  }
}

// ============================================
// FACTORY FUNCTIONS
// ============================================

export function createBroadcastSession(
  userId: string,
  avatarId: string,
  config?: Parameters<typeof BroadcastSessionManager>[2],
): BroadcastSessionManager {
  return new BroadcastSessionManager(userId, avatarId, config)
}
