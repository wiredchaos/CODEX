/**
 * WIRED CHAOS META — AVATAR LIVE MODE v33
 * Complete Broadcast Network Type Definitions
 */

// ============================================
// PHASE 1: NEURAL AUTO-ANIMATOR TYPES
// ============================================

export type IdleAnimationType =
  | "micro_gesture"
  | "breath_simulation"
  | "eye_tracking"
  | "head_tilt"
  | "blink"
  | "persona_tick"

export type EmotionalState =
  | "neutral"
  | "engaged"
  | "contemplative"
  | "energized"
  | "mysterious"
  | "commanding"
  | "playful"

export interface AutoAnimatorConfig {
  enabled: boolean
  microGestures: boolean
  breathSimulation: boolean
  eyeTracking: boolean
  autonomousPersonaTicks: boolean
  emotionalStateWeight: number // 0-1 timeline influence
  idleVariance: number // 0-1 randomness factor
}

export interface IdleAnimation {
  type: IdleAnimationType
  intensity: number
  frequency: number // per minute
  duration: number // seconds
  variance: number
}

export interface PersonaTick {
  avatarId: string
  behavior: string
  trigger: "time" | "silence" | "random"
  interval: number
  animation: string
}

// ============================================
// PHASE 2: VOICEPRINT MASQUERADE TYPES
// ============================================

export type VoiceProfileId =
  | "neuro-meta-x"
  | "neuro-kiba-human"
  | "dj-red-fang"
  | "shadowlux-whisper"
  | "grymm-echo"
  | "neutral-broadcast"

export interface VoiceMaskConfig {
  profileId: VoiceProfileId
  noiseSuppression: boolean
  clarityCompression: boolean
  pitchShift: number // -12 to +12 semitones
  formantShift: number // -1 to +1
  genderNeutralFilter: boolean
  reverbLevel: number // 0-1
  warmth: number // 0-1
}

export interface VoiceProfile {
  id: VoiceProfileId
  name: string
  description: string
  basePitch: number
  formant: number
  reverb: number
  warmth: number
  compression: number
  characteristics: string[]
}

// ============================================
// PHASE 3: TIMELINE-SYNCED FX TYPES
// ============================================

export type TimelineFxEvent =
  | "red_fang_pulse"
  | "vault_33_shift"
  | "merovingian_589"
  | "npc_labyrinth_glow"
  | "neteru_divination"
  | "dogechain_glitch"
  | "echo_distortion"
  | "stargate_sync"

export interface TimelineFxConfig {
  enabled: boolean
  activeEvents: TimelineFxEvent[]
  intensityMultiplier: number
  syncToLore: boolean
  autoTrigger: boolean
  triggerThreshold: number
}

export interface TimelineFx {
  id: string
  event: TimelineFxEvent
  visualEffect: string
  audioEffect: string
  duration: number
  intensity: number
  colorOverlay: string[]
  particleSystem?: string
}

// ============================================
// PHASE 4: VIEWER INTERACTION TYPES
// ============================================

export type ViewerTriggerAction =
  | "wave"
  | "head_nod"
  | "power_glyph"
  | "glitch_burst"
  | "mic_drop"
  | "blade_flare"
  | "spectral_shift"
  | "beat_drop"
  | "hype_gesture"

export interface ViewerControlConfig {
  enabled: boolean
  allowedActions: ViewerTriggerAction[]
  rateLimit: number // actions per minute
  cooldownSeconds: number
  requiresSubscriber: boolean
  costPerAction: number // in platform currency
}

export interface ViewerTrigger {
  action: ViewerTriggerAction
  animation: string
  duration: number
  visualFx: string
  audioFx?: string
  restricted: boolean
  subscriberOnly: boolean
}

// ============================================
// PHASE 5: CROSS-SYSTEM AUTOMATION TYPES
// ============================================

export type IntegratedSystem = "creator_codex" | "akira_codex" | "npc" | "ott_789" | "dogechain_33fm" | "fen_vault"

export interface CrossSystemConfig {
  enabledSystems: IntegratedSystem[]
  autoClipCreation: boolean
  loreEntryGeneration: boolean
  npcLessonCapture: boolean
  vodGeneration: boolean
  radioStingerInsertion: boolean
  signalLogging: boolean
}

export interface SystemIntegration {
  system: IntegratedSystem
  endpoint: string
  autoSync: boolean
  dataTransform: string
  webhookUrl?: string
}

// ============================================
// PHASE 6: BROADCAST QUALITY TYPES
// ============================================

export type LatencyTier = "ultra_low" | "standard" | "secure_encrypted"

export type Resolution = "720p30" | "1080p30" | "1080p60" | "4k30"

export interface BroadcastQualityConfig {
  resolution: Resolution
  bitrate: number // kbps
  latencyTier: LatencyTier
  adaptiveBitrate: boolean
  persistenceCache: boolean
  hardwareAcceleration: boolean
}

export interface StreamConfig {
  rtmpUrl: string
  streamKey: string
  backup: boolean
  failoverNodes: string[]
  encryption: boolean
}

// ============================================
// MASTER BROADCAST SESSION
// ============================================

export interface BroadcastSession {
  id: string
  userId: string
  avatarId: string
  status: "idle" | "preparing" | "live" | "paused" | "ended"
  startedAt?: Date
  endedAt?: Date
  autoAnimator: AutoAnimatorConfig
  voiceMask: VoiceMaskConfig
  timelineFx: TimelineFxConfig
  viewerControl: ViewerControlConfig
  crossSystem: CrossSystemConfig
  quality: BroadcastQualityConfig
  stream: StreamConfig
  viewerCount: number
  peakViewers: number
  totalInteractions: number
}

export interface BroadcastEvent {
  id: string
  sessionId: string
  timestamp: Date
  type: "start" | "stop" | "fx" | "interaction" | "system" | "error"
  payload: Record<string, unknown>
}
