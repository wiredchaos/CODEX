/**
 * PHASE 2 — VOICEPRINT MASQUERADE
 * Voice consistency across timelines, channels, and avatar identities
 */

import type { VoiceMaskConfig, VoiceProfile, VoiceProfileId } from "./types"

// ============================================
// VOICE PROFILES
// ============================================

export const VOICE_PROFILES: VoiceProfile[] = [
  {
    id: "neuro-meta-x",
    name: "NEURO META X Voice",
    description: "Precise, analytical authority with subtle digital undertones",
    basePitch: 0,
    formant: 0,
    reverb: 0.15,
    warmth: 0.4,
    compression: 0.7,
    characteristics: ["precise", "analytical", "authoritative", "digital-edge"],
  },
  {
    id: "neuro-kiba-human",
    name: "NEURO KIBA (Human)",
    description: "Calm blade-like precision with confident undertone",
    basePitch: 2,
    formant: 0.2,
    reverb: 0.1,
    warmth: 0.5,
    compression: 0.6,
    characteristics: ["calm", "confident", "sharp", "controlled"],
  },
  {
    id: "dj-red-fang",
    name: "DJ RED FANG (Primary Broadcast Host)",
    description: "Energetic radio presence, timeline constant",
    basePitch: -1,
    formant: -0.1,
    reverb: 0.25,
    warmth: 0.7,
    compression: 0.8,
    characteristics: ["energetic", "charismatic", "rhythmic", "broadcast-ready"],
  },
  {
    id: "shadowlux-whisper",
    name: "Shadowlux Whisper Channel",
    description: "Mysterious, encrypted whisper with shadow resonance",
    basePitch: -3,
    formant: -0.3,
    reverb: 0.4,
    warmth: 0.2,
    compression: 0.5,
    characteristics: ["mysterious", "whispered", "encrypted", "shadowy"],
  },
  {
    id: "grymm-echo",
    name: "Grymm Echo-Mask",
    description: "Heavy, disciplined voice with metallic undertone",
    basePitch: -5,
    formant: -0.4,
    reverb: 0.2,
    warmth: 0.3,
    compression: 0.9,
    characteristics: ["heavy", "disciplined", "metallic", "commanding"],
  },
  {
    id: "neutral-broadcast",
    name: "Neutral Broadcast Voice",
    description: "Clean, professional broadcast standard",
    basePitch: 0,
    formant: 0,
    reverb: 0.1,
    warmth: 0.5,
    compression: 0.6,
    characteristics: ["neutral", "professional", "clear", "broadcast"],
  },
]

// ============================================
// DEFAULT CONFIGURATION
// ============================================

export const DEFAULT_VOICE_MASK_CONFIG: VoiceMaskConfig = {
  profileId: "neutral-broadcast",
  noiseSuppression: true,
  clarityCompression: true,
  pitchShift: 0,
  formantShift: 0,
  genderNeutralFilter: false,
  reverbLevel: 0.1,
  warmth: 0.5,
}

// ============================================
// VOICE MASK ENGINE
// ============================================

export class VoiceMaskEngine {
  private config: VoiceMaskConfig
  private activeProfile: VoiceProfile

  constructor(config: Partial<VoiceMaskConfig> = {}) {
    this.config = { ...DEFAULT_VOICE_MASK_CONFIG, ...config }
    this.activeProfile = this.getProfileById(this.config.profileId)
  }

  private getProfileById(id: VoiceProfileId): VoiceProfile {
    return VOICE_PROFILES.find((p) => p.id === id) || VOICE_PROFILES[5]
  }

  setProfile(profileId: VoiceProfileId): void {
    this.config.profileId = profileId
    this.activeProfile = this.getProfileById(profileId)
    this.applyProfileDefaults()
  }

  private applyProfileDefaults(): void {
    this.config.pitchShift = this.activeProfile.basePitch
    this.config.formantShift = this.activeProfile.formant
    this.config.reverbLevel = this.activeProfile.reverb
    this.config.warmth = this.activeProfile.warmth
  }

  getProcessingParams(): VoiceProcessingParams {
    return {
      // Noise reduction
      noiseGate: this.config.noiseSuppression ? -40 : -60,
      noiseReduction: this.config.noiseSuppression ? 0.8 : 0,

      // Pitch and formant
      pitchShift: this.config.pitchShift,
      formantShift: this.config.formantShift,

      // Compression for broadcast clarity
      compressorThreshold: this.config.clarityCompression ? -18 : -30,
      compressorRatio: this.config.clarityCompression ? this.activeProfile.compression * 6 : 2,
      compressorAttack: 0.003,
      compressorRelease: 0.25,

      // Gender neutral processing
      genderNeutral: this.config.genderNeutralFilter,
      neutralFormant: this.config.genderNeutralFilter ? 0 : this.config.formantShift,

      // Reverb and space
      reverbMix: this.config.reverbLevel,
      reverbDecay: 1.5,
      reverbPreDelay: 0.02,

      // Warmth (low-mid boost)
      warmthLevel: this.config.warmth,
      warmthFrequency: 250,
      warmthQ: 0.7,

      // High-frequency clarity
      presenceBoost: 0.3,
      presenceFrequency: 3000,
      deEsser: 0.4,
    }
  }

  generateAudioGraph(): string {
    const params = this.getProcessingParams()
    return `
// Voice Mask Audio Processing Graph
// Profile: ${this.activeProfile.name}

const audioContext = new AudioContext();

// Input node
const input = audioContext.createMediaStreamSource(stream);

// Noise Gate
const noiseGate = createNoiseGate(${params.noiseGate});

// Pitch Shifter
const pitchShifter = createPitchShifter(${params.pitchShift});

// Formant Shifter
const formantShifter = createFormantShifter(${params.formantShift});

// Compressor
const compressor = audioContext.createDynamicsCompressor();
compressor.threshold.value = ${params.compressorThreshold};
compressor.ratio.value = ${params.compressorRatio};
compressor.attack.value = ${params.compressorAttack};
compressor.release.value = ${params.compressorRelease};

// Warmth EQ
const warmthEQ = audioContext.createBiquadFilter();
warmthEQ.type = 'peaking';
warmthEQ.frequency.value = ${params.warmthFrequency};
warmthEQ.Q.value = ${params.warmthQ};
warmthEQ.gain.value = ${params.warmthLevel * 6};

// Reverb
const reverb = createConvolver(${params.reverbMix}, ${params.reverbDecay});

// Connect graph
input
  .connect(noiseGate)
  .connect(pitchShifter)
  .connect(formantShifter)
  .connect(compressor)
  .connect(warmthEQ)
  .connect(reverb)
  .connect(audioContext.destination);
`
  }

  getConfig(): VoiceMaskConfig {
    return { ...this.config }
  }

  updateConfig(updates: Partial<VoiceMaskConfig>): void {
    this.config = { ...this.config, ...updates }
    if (updates.profileId) {
      this.activeProfile = this.getProfileById(updates.profileId)
    }
  }

  getActiveProfile(): VoiceProfile {
    return { ...this.activeProfile }
  }
}

export interface VoiceProcessingParams {
  noiseGate: number
  noiseReduction: number
  pitchShift: number
  formantShift: number
  compressorThreshold: number
  compressorRatio: number
  compressorAttack: number
  compressorRelease: number
  genderNeutral: boolean
  neutralFormant: number
  reverbMix: number
  reverbDecay: number
  reverbPreDelay: number
  warmthLevel: number
  warmthFrequency: number
  warmthQ: number
  presenceBoost: number
  presenceFrequency: number
  deEsser: number
}

export function createVoiceMask(config?: Partial<VoiceMaskConfig>): VoiceMaskEngine {
  return new VoiceMaskEngine(config)
}

export function getVoiceProfile(id: VoiceProfileId): VoiceProfile | undefined {
  return VOICE_PROFILES.find((p) => p.id === id)
}

export function getAllVoiceProfiles(): VoiceProfile[] {
  return [...VOICE_PROFILES]
}
