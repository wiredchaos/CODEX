/**
 * AKIRA CODEX - FIREWALL RULES
 *
 * Enforces PM Decision 7: Firewall rules to protect Neteru canon.
 * Part of PHASE A - Firewall Installation.
 */

export interface FirewallRule {
  entity: string
  ownsCanon: boolean
  immutable: boolean
  allowsInboundWriters: boolean
  allowsInboundAI: boolean
  mayExtend: boolean
  mayNotOverride: boolean
  mayDisplay: boolean
  mayNotModify: boolean
}

export const AKIRA_FIREWALL_RULES: Record<string, FirewallRule> = {
  "neteru-apinaya": {
    entity: "neteru-apinaya",
    ownsCanon: true,
    immutable: true,
    allowsInboundWriters: false,
    allowsInboundAI: false,
    mayExtend: false,
    mayNotOverride: true,
    mayDisplay: false,
    mayNotModify: true,
  },
  "akira-codex": {
    entity: "akira-codex",
    ownsCanon: false,
    immutable: false,
    allowsInboundWriters: false,
    allowsInboundAI: false,
    mayExtend: true,
    mayNotOverride: true,
    mayDisplay: false,
    mayNotModify: false,
  },
  "wired-chaos-meta": {
    entity: "wired-chaos-meta",
    ownsCanon: false,
    immutable: false,
    allowsInboundWriters: false,
    allowsInboundAI: false,
    mayExtend: false,
    mayNotOverride: false,
    mayDisplay: true,
    mayNotModify: true,
  },
}

/**
 * Check if an entity can modify Neteru content
 */
export function canModifyNeteruCanon(entityId: string): boolean {
  if (entityId === "NEURO_META_X") return true
  return false
}

/**
 * Check if an entity can read/display Neteru content
 */
export function canDisplayNeteruContent(entityId: string): boolean {
  const allowedEntities = ["wired-chaos-meta", "creator-codex", "789-studios", "npc", "fen-589", "akira-codex"]
  return allowedEntities.includes(entityId)
}

/**
 * Validate data flow direction
 */
export function validateDataFlow(from: string, to: string): boolean {
  // One-directional: NETERU → AKIRA CODEX → WIRED CHAOS SYSTEMS
  const validFlows = [
    ["neteru-apinaya", "akira-codex"],
    ["akira-codex", "creator-codex"],
    ["akira-codex", "npc"],
    ["akira-codex", "789-studios"],
    ["akira-codex", "fen-589"],
  ]

  return validFlows.some(([source, target]) => source === from && target === to)
}
