/**
 * NETERU ENGINE REGISTRY
 *
 * Central export point for all Neteru engines.
 * Part of PHASE A - Engine Installation.
 */

import { neteruStoryEngine } from "./story-engine"
import { neteruBloodlineEngine } from "./bloodline-engine"
import { neteruPantheonEngine } from "./pantheon-engine"
import { neteruTimelineEngine } from "./timeline-engine"
import { neteruGeometryEngine } from "./geometry-engine"
import { neteruARGEngine } from "./arg-engine"

export type { StoryGenerationRequest, StoryOutput } from "./story-engine"
export type { BloodlineActivationEvent, BloodlineProfile } from "./bloodline-engine"
export type { PantheonQuery } from "./pantheon-engine"
export type { TimelineQuery, TimelineBranch } from "./timeline-engine"
export type { GeometryPattern, SigilRequest } from "./geometry-engine"
export type { ARGMission, ClueChain } from "./arg-engine"

/**
 * Engine status check
 */
export function getEngineStatus() {
  return {
    storyEngine: neteruStoryEngine.getStatus(),
    bloodlineEngine: neteruBloodlineEngine.getStatus(),
    pantheonEngine: neteruPantheonEngine.getStatus(),
    timelineEngine: neteruTimelineEngine.getStatus(),
    geometryEngine: neteruGeometryEngine.getStatus(),
    argEngine: neteruARGEngine.getStatus(),
  }
}
