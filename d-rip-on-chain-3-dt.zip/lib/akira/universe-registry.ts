/**
 * AKIRA CODEX - UNIVERSE REGISTRY
 *
 * Central registry for all universes hosted within Akira Codex.
 * Neteru Apinaya is designated as PRIMARY/DEFAULT universe per PM Decision 1.
 */

export interface UniverseRegistryEntry {
  id: string
  name: string
  slug: string
  featured: boolean
  default: boolean
  universeType: "prime_storyworld" | "secondary" | "experimental" | "archived"
  author: string
  publisher: string
  studio: string
  visibility: "public" | "private" | "restricted"
  status: "active" | "development" | "planned"
}

export const AKIRA_UNIVERSE_REGISTRY: UniverseRegistryEntry[] = [
  {
    id: "neteru-apinaya",
    name: "NETERU APINAYA",
    slug: "neteru-apinaya",
    featured: true,
    default: true,
    universeType: "prime_storyworld",
    author: "NEURO META X",
    publisher: "CHAOS PUBLICATIONS",
    studio: "NETERU STUDIOS",
    visibility: "public",
    status: "active",
  },
  {
    id: "vault-33-chronicles",
    name: "VAULT 33 CHRONICLES",
    slug: "vault-33-chronicles",
    featured: false,
    default: false,
    universeType: "secondary",
    author: "COLLECTIVE",
    publisher: "CHAOS PUBLICATIONS",
    studio: "VAULT STUDIOS",
    visibility: "public",
    status: "planned",
  },
  {
    id: "frequency-wars",
    name: "FREQUENCY WARS",
    slug: "frequency-wars",
    featured: false,
    default: false,
    universeType: "secondary",
    author: "TBD",
    publisher: "CHAOS PUBLICATIONS",
    studio: "789 STUDIOS",
    visibility: "public",
    status: "planned",
  },
]

export function getDefaultUniverse(): UniverseRegistryEntry | undefined {
  return AKIRA_UNIVERSE_REGISTRY.find((u) => u.default)
}

export function getFeaturedUniverse(): UniverseRegistryEntry | undefined {
  return AKIRA_UNIVERSE_REGISTRY.find((u) => u.featured)
}

export function getUniverseById(id: string): UniverseRegistryEntry | undefined {
  return AKIRA_UNIVERSE_REGISTRY.find((u) => u.id === id)
}

export function getUniverseBySlug(slug: string): UniverseRegistryEntry | undefined {
  return AKIRA_UNIVERSE_REGISTRY.find((u) => u.slug === slug)
}
