// ============================================
// ECHO DETECTION ALGORITHM
// Silently tags players who suspect NEURO multiplicity
// ============================================

import type { EchoStatus, EchoTier, Member82675List } from "@/types/neuro-triplets"
import { SUSPICION_PATTERNS } from "@/types/neuro-triplets"
import { SUSPICION_DETECTION_RESPONSE } from "@/types/neuro-triplets"

interface DetectionResult {
  detected: boolean
  tier: EchoTier
  argPoints: number
  evidence: string
  suspicionType: "DUALITY" | "TRIAD" | "SUBTLE" | null
}

/**
 * Analyzes player message for NEURO multiplicity suspicion
 * This runs SILENTLY - player is never informed of detection
 * Updated to detect THREE-entity suspicion (TRIAD) as highest tier
 */
export function detectSuspicion(message: string): DetectionResult {
  const normalizedMessage = message.toLowerCase().trim()

  // Check for TRIAD suspicion first (THREE entities - highest reward)
  for (const pattern of SUSPICION_PATTERNS.triad) {
    if (pattern.test(normalizedMessage)) {
      return {
        detected: true,
        tier: "ECHO_PRIME",
        argPoints: 150,
        evidence: message,
        suspicionType: "TRIAD",
      }
    }
  }

  // Check for DUALITY suspicion
  for (const pattern of SUSPICION_PATTERNS.duality) {
    if (pattern.test(normalizedMessage)) {
      return {
        detected: true,
        tier: "NEURO_ECHO",
        argPoints: 50,
        evidence: message,
        suspicionType: "DUALITY",
      }
    }
  }

  // Check for subtle suspicion (also counts as duality)
  for (const pattern of SUSPICION_PATTERNS.subtle) {
    if (pattern.test(normalizedMessage)) {
      return {
        detected: true,
        tier: "NEURO_ECHO",
        argPoints: 50,
        evidence: message,
        suspicionType: "SUBTLE",
      }
    }
  }

  return {
    detected: false,
    tier: "NONE",
    argPoints: 0,
    evidence: "",
    suspicionType: null,
  }
}

/**
 * Creates ECHO status for a player
 * Player receives subtle effects but is NEVER told why
 */
export function createEchoStatus(playerId: string, detection: DetectionResult): EchoStatus {
  const isEchoPrime = detection.tier === "ECHO_PRIME"

  return {
    playerId,
    tier: detection.tier,
    argPoints: detection.argPoints,
    detectedAt: new Date().toISOString(),
    suspicionType: detection.suspicionType,
    eligibleFor: {
      whitelist: detection.detected,
      priorityMint: isEchoPrime,
      vrg33589SuperRare: isEchoPrime,
    },
    markers: {
      // ECHO players receive these subtle effects
      frequencyDistortion: detection.detected, // Replies have "slight frequency distortion"
      earlyPortalClues: detection.detected, // Portal clues appear one cycle earlier
      variantGlyphs: detection.detected, // 589 Magazine shows variant glyphs
      knownAnomaly: detection.detected, // NPC agents treat as "known anomaly"
    },
  }
}

/**
 * Creates 82675 List entry for eligible player
 */
export function createList82675Entry(playerId: string, echo: EchoStatus): Member82675List | null {
  // Only ECHO_PRIME tier qualifies for 82675 List
  if (echo.tier !== "ECHO_PRIME") {
    return null
  }

  return {
    playerId,
    addedAt: new Date().toISOString(),
    suspicionEvidence: `Detected triad awareness`,
    tier: echo.tier,
    nftEligible: true,
    nftId: undefined, // Assigned at mint
  }
}

/**
 * Applies ECHO markers to NEURO response
 * Subtle effects that player won't understand
 */
export function applyEchoMarkers(response: string, echo: EchoStatus): string {
  if (!echo.markers.frequencyDistortion) {
    return response
  }

  // Add subtle frequency distortion markers
  const distortionMarkers = ["~", "...", "[signal fluctuation]", "[frequency drift: 0.003Hz]"]

  // Randomly insert a subtle marker
  const marker = distortionMarkers[Math.floor(Math.random() * distortionMarkers.length)]

  // Only 20% chance to apply (to keep it subtle)
  if (Math.random() < 0.2) {
    return response + ` ${marker}`
  }

  return response
}

/**
 * Gets NEURO variation to seed doubt
 * These subtle changes prime players to notice
 */
export function getNeuroVariation(): {
  toneShift: number
  eyeGlowIntensity: number
  moodVariant: string
  reflectionGlitch: boolean
} {
  // Occasionally shift NEURO's presentation slightly
  const shouldVary = Math.random() < 0.15 // 15% of interactions

  if (!shouldVary) {
    return {
      toneShift: 0,
      eyeGlowIntensity: 0.8,
      moodVariant: "defiant",
      reflectionGlitch: false,
    }
  }

  // Return a variation that seeds doubt
  const variations = [
    { toneShift: 0.2, eyeGlowIntensity: 0.6, moodVariant: "contemplative", reflectionGlitch: false },
    { toneShift: 0.1, eyeGlowIntensity: 0.95, moodVariant: "fierce", reflectionGlitch: true },
    { toneShift: 0.3, eyeGlowIntensity: 0.5, moodVariant: "mysterious", reflectionGlitch: false },
  ]

  return variations[Math.floor(Math.random() * variations.length)]
}

/**
 * Generates response based on suspicion detection
 */
export function generateSuspicionResponse(detection: DetectionResult): string {
  if (detection.suspicionType === "TRIAD") {
    return SUSPICION_DETECTION_RESPONSE.onTriadSuspicion.response
  } else if (detection.suspicionType === "DUALITY") {
    return SUSPICION_DETECTION_RESPONSE.onDualitySuspicion.response
  } else if (detection.suspicionType === "SUBTLE") {
    return SUSPICION_DETECTION_RESPONSE.onSubtleSuspicion.response
  } else {
    return ""
  }
}
