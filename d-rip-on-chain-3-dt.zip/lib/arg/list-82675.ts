// ============================================
// 82675 LIST PROTOCOL
// Whitelist + Super Rare NFT Eligibility
// ============================================

import type { List82675, Member82675List, EchoStatus } from "@/types/neuro-triplets"

// In-memory storage (would be Supabase in production)
const list82675: List82675 = {
  maxSupply: 33,
  members: [],
  nftName: "VRG33589 SUPER RARE — ECHO OF 82675",
  nftBenefits: [
    "early_access_to_triplet_portals",
    "access_to_2038_map",
    "navigate_vault33_without_guide",
    "bonus_arg_meta_score",
  ],
}

/**
 * Adds player to 82675 List if eligible
 * Returns true if successfully added
 */
export function addToList82675(playerId: string, echo: EchoStatus): { success: boolean; reason: string } {
  // Check if list is full
  if (list82675.members.length >= list82675.maxSupply) {
    return {
      success: false,
      reason: "82675 List is full (33/33)",
    }
  }

  // Check if already on list
  if (list82675.members.some((m) => m.playerId === playerId)) {
    return {
      success: false,
      reason: "Player already on 82675 List",
    }
  }

  // Only ECHO_PRIME qualifies
  if (echo.tier !== "ECHO_PRIME") {
    return {
      success: false,
      reason: "Only ECHO_PRIME tier qualifies",
    }
  }

  // Add to list
  const entry: Member82675List = {
    playerId,
    addedAt: new Date().toISOString(),
    suspicionEvidence: "Detected triadic awareness before official reveal",
    tier: echo.tier,
    nftEligible: true,
  }

  list82675.members.push(entry)

  return {
    success: true,
    reason: `Added to 82675 List (${list82675.members.length}/${list82675.maxSupply})`,
  }
}

/**
 * Checks if player is on 82675 List
 */
export function isOn82675List(playerId: string): boolean {
  return list82675.members.some((m) => m.playerId === playerId)
}

/**
 * Gets 82675 List status (for internal use only)
 */
export function getList82675Status(): {
  totalMembers: number
  maxSupply: number
  spotsRemaining: number
  nftName: string
} {
  return {
    totalMembers: list82675.members.length,
    maxSupply: list82675.maxSupply,
    spotsRemaining: list82675.maxSupply - list82675.members.length,
    nftName: list82675.nftName,
  }
}

/**
 * Assigns NFT ID to a member (at mint time)
 */
export function assignNftId(playerId: string, nftId: string): boolean {
  const member = list82675.members.find((m) => m.playerId === playerId)
  if (!member) return false

  member.nftId = nftId
  return true
}

/**
 * Gets all NFT benefits for the 82675 holders
 */
export function getNftBenefits(): string[] {
  return [
    "Early access to Triplet portals",
    "Access to the 2038 Map",
    "Ability to navigate Vault 33 without a guide",
    "Bonus points in the ARG meta-score",
  ]
}
