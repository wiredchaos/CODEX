import type { AgenticAction, ActionCategoryId } from "./types"

export const AGENTIC_ACTIONS: Record<ActionCategoryId, AgenticAction> = {
  ANALYTICAL: {
    category: "ANALYTICAL",
    description: "Diagnostic and evaluative reasoning actions",
    actions: [
      "Diagnose problems and identify root causes",
      "Interpret technical or legal specifications",
      "Evaluate solutions against multiple criteria",
      "Score alternatives using weighted metrics",
      "Conduct structured debates on complex issues",
      "Predict outcomes based on historical patterns",
    ],
  },

  CONSTRUCTIVE: {
    category: "CONSTRUCTIVE",
    description: "Creation and generation of artifacts",
    actions: [
      "Draft technical documentation and specifications",
      "Generate smart contracts with safety validation",
      "Produce CAD-ready architectural or engineering output",
      "Build workflows and automation pipelines",
      "Create SOWs, RFP responses, and compliance forms",
      "Redline and improve existing documents",
    ],
  },

  ROUTING: {
    category: "ROUTING",
    description: "Task delegation and swarm coordination",
    actions: [
      "Summon sub-swarms (CAD, Tax, Insurance, Compliance, Smart Contracts)",
      "Assign tasks to specialized agents",
      "Request verification from domain experts",
      "Escalate contradictions to oversight systems",
      "Coordinate cross-functional efforts",
    ],
  },

  MONITORING: {
    category: "MONITORING",
    description: "Continuous validation and risk assessment",
    actions: [
      "Detect data inconsistencies and anomalies",
      "Perform ongoing risk assessment",
      "Identify unrealistic assumptions",
      "Maintain internal memory (patch-local only)",
      "Track compliance status",
      "Monitor system health metrics",
    ],
  },

  TRANSLATION: {
    category: "TRANSLATION",
    description: "Web2 to Web3 transformation",
    actions: [
      "Convert traditional concepts to Web3 equivalents",
      "Map smart contract opportunities in any industry",
      "Identify cross-industry blockchain applications",
      "Design tokenized job markets",
      "Create decentralized income pathways",
    ],
  },
}

export function getActionsForCategory(category: ActionCategoryId): string[] {
  return AGENTIC_ACTIONS[category].actions
}

export function getAllActions(): string[] {
  return Object.values(AGENTIC_ACTIONS).flatMap((action) => action.actions)
}
