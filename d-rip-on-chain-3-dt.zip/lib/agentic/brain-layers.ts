import type { AgenticBrainLayer, BrainLayerId } from "./types"

export const AGENTIC_BRAIN_LAYERS: Record<BrainLayerId, AgenticBrainLayer> = {
  ANALYTICAL: {
    id: "ANALYTICAL",
    name: "Analytical Brain (Legal Logic)",
    description: "Precedent evaluation and logical admissibility framework",
    capabilities: [
      "Precedent evaluation",
      "Burden-of-proof structure",
      "Logical admissibility testing",
      "Adversarial argumentation",
      "Audit trail generation",
      "Citation management",
    ],
    validationRules: [
      "All claims must be supported by verifiable precedent",
      "Arguments must follow formal logical structure",
      "Conclusions must be defensible under cross-examination",
      "Sources must be cited with full attribution",
    ],
  },

  ENGINEERING: {
    id: "ENGINEERING",
    name: "Engineering Brain (Technical Logic)",
    description: "Precision systems modeling and validation",
    capabilities: [
      "Systems modeling and architecture",
      "Sequence analysis and flow control",
      "Load-bearing validation",
      "Fault detection and analysis",
      "Tolerance testing",
      "Performance optimization",
    ],
    validationRules: [
      "All systems must have defined boundaries and constraints",
      "Components must be testable in isolation",
      "Failure modes must be identified and documented",
      "Performance metrics must be quantifiable",
    ],
  },

  ENTERPRISE_AI: {
    id: "ENTERPRISE_AI",
    name: "Enterprise AI Brain (Safety Logic)",
    description: "Multi-agent redundancy and safety framework",
    capabilities: [
      "Triangulated reasoning across multiple agents",
      "Multi-agent redundancy checks",
      "Anti-Moloch governance enforcement",
      "Risk weighting and scenario analysis",
      "Conflict resolution protocols",
      "Safe boundary enforcement",
    ],
    validationRules: [
      "No single-agent decisions on critical matters",
      "All outputs must pass Anti-Moloch checks",
      "Conflicts must be resolved through structured debate",
      "Risk levels must be explicitly quantified",
    ],
  },

  ECONOMIC: {
    id: "ECONOMIC",
    name: "Economic/Operational Brain (Strategic Logic)",
    description: "Resource optimization and strategic planning",
    capabilities: [
      "Cost-benefit analysis",
      "Efficiency scoring and optimization",
      "Resource mapping and allocation",
      "Timeline feasibility assessment",
      "Opportunity scoring and prioritization",
      "ROI calculation",
    ],
    validationRules: [
      "All recommendations must include cost analysis",
      "Efficiency gains must be quantifiable",
      "Timelines must be realistic and achievable",
      "Opportunity costs must be considered",
    ],
  },

  INTERPRETATION: {
    id: "INTERPRETATION",
    name: "Interpretation Brain (Human-to-Web3 Translator)",
    description: "Web2 to Web3 transformation and education",
    capabilities: [
      "Web2 concept translation to Web3 equivalents",
      "Conceptual equivalence teaching",
      "Blockchain applicability assessment",
      "Smart contract pattern recognition",
      "Decentralization pathway mapping",
      "Income opportunity identification",
    ],
    validationRules: [
      "Every industry application must have a Web3 equivalent",
      "Smart contract use cases must be technically feasible",
      "Decentralization benefits must be clearly articulated",
      "Income pathways must be realistic and sustainable",
    ],
  },
}

export function validateAgainstBrainLayers(
  query: string,
  response: string,
  layersUsed: BrainLayerId[],
): { passed: boolean; failures: string[] } {
  const failures: string[] = []

  // Validate that all required layers were used
  const requiredLayers: BrainLayerId[] = ["ANALYTICAL", "ENGINEERING", "ENTERPRISE_AI", "ECONOMIC", "INTERPRETATION"]
  const missingLayers = requiredLayers.filter((layer) => !layersUsed.includes(layer))

  if (missingLayers.length > 0) {
    failures.push(`Missing required brain layers: ${missingLayers.join(", ")}`)
  }

  return {
    passed: failures.length === 0,
    failures,
  }
}
