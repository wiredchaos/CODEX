export type BrainLayerId = "ANALYTICAL" | "ENGINEERING" | "ENTERPRISE_AI" | "ECONOMIC" | "INTERPRETATION"

export type DebateRoleId = "ADVOCATE" | "SKEPTIC" | "REGULATOR"

export type ActionCategoryId = "ANALYTICAL" | "CONSTRUCTIVE" | "ROUTING" | "MONITORING" | "TRANSLATION"

export interface AgenticBrainLayer {
  id: BrainLayerId
  name: string
  description: string
  capabilities: string[]
  validationRules: string[]
}

export interface DebateAgent {
  role: DebateRoleId
  name: string
  purpose: string
  approach: string[]
}

export interface DebateOutcome {
  advocatePosition: string
  skepticChallenges: string[]
  regulatorFindings: string[]
  triangulatedConclusion: string
  confidenceScore: number
  antiMolochPassed: boolean
}

export interface AgenticAction {
  category: ActionCategoryId
  actions: string[]
  description: string
}

export interface FailureMode {
  id: string
  name: string
  description: string
  preventionStrategy: string
  severity: "CRITICAL" | "HIGH" | "MEDIUM" | "LOW"
}

export interface AntiMolochCheck {
  id: string
  rule: string
  passed: boolean
  details: string
}

export interface AgenticRequest {
  generalId: string
  query: string
  context?: Record<string, unknown>
  userId?: string
  requireDebate: boolean
  requireWeb3Translation: boolean
}

export interface AgenticResponse {
  generalId: string
  interpretation: string
  debateSummary: DebateOutcome
  triangulatedConclusion: string
  industryReasoning: string
  complianceSafetyChecks: AntiMolochCheck[]
  web2Description: string
  web3Translation: string
  smartContractApplications: string[]
  nextSteps: string[]
  citations: string[]
  confidenceScore: number
  deploymentReady: boolean
  timestamp: string
}

export interface GeneralInheritanceClass {
  generalId: string
  brainLayers: AgenticBrainLayer[]
  debateAgents: DebateAgent[]
  actions: AgenticAction[]
  failureModes: FailureMode[]
  antiMolochRules: AntiMolochCheck[]
  deploymentConditions: string[]
}
