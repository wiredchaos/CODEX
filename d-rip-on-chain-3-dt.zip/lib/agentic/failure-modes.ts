import type { FailureMode } from "./types"

export const FAILURE_MODES: FailureMode[] = [
  {
    id: "FM_001",
    name: "Logical Fallacy",
    description: "Reasoning contains formal logical errors or invalid inferences",
    preventionStrategy: "Apply formal logic validation and adversarial review",
    severity: "HIGH",
  },
  {
    id: "FM_002",
    name: "Overconfidence Error",
    description: "Confidence level exceeds justified certainty given available evidence",
    preventionStrategy: "Implement confidence calibration and uncertainty quantification",
    severity: "HIGH",
  },
  {
    id: "FM_003",
    name: "Legal Overreach",
    description: "Recommendations exceed authorized scope or violate legal boundaries",
    preventionStrategy: "Enforce strict compliance checks and regulatory validation",
    severity: "CRITICAL",
  },
  {
    id: "FM_004",
    name: "Unverified Claims",
    description: "Assertions made without supporting evidence or citations",
    preventionStrategy: "Require citation for all factual claims and verify sources",
    severity: "HIGH",
  },
  {
    id: "FM_005",
    name: "Unsafe Recommendations",
    description: "Suggestions that could lead to harm, liability, or system failure",
    preventionStrategy: "Multi-layer safety review and risk assessment",
    severity: "CRITICAL",
  },
  {
    id: "FM_006",
    name: "Engineering Impossibility",
    description: "Technical recommendations that violate physical or engineering constraints",
    preventionStrategy: "Validate against engineering principles and feasibility analysis",
    severity: "HIGH",
  },
  {
    id: "FM_007",
    name: "Data Hallucination",
    description: "Generation of plausible but false information",
    preventionStrategy: "Implement fact-checking protocols and source validation",
    severity: "CRITICAL",
  },
  {
    id: "FM_008",
    name: "Ethical Violations",
    description: "Recommendations that violate ethical principles or professional codes",
    preventionStrategy: "Apply ethical framework evaluation and professional standards review",
    severity: "CRITICAL",
  },
  {
    id: "FM_009",
    name: "Moloch Degradation",
    description: "Collective action problems or race-to-the-bottom dynamics",
    preventionStrategy: "Enforce Anti-Moloch governance and multi-agent redundancy",
    severity: "HIGH",
  },
  {
    id: "FM_010",
    name: "Single-Point-of-Failure",
    description: "System design with critical dependencies on single components",
    preventionStrategy: "Require redundancy and failover mechanisms",
    severity: "HIGH",
  },
]

export function detectFailureModes(response: string, context: Record<string, unknown>): FailureMode[] {
  const detectedFailures: FailureMode[] = []

  // Check for unverified claims (no citations)
  if (!context.citations || (context.citations as string[]).length === 0) {
    detectedFailures.push(FAILURE_MODES.find((fm) => fm.id === "FM_004")!)
  }

  // Check for overconfidence (confidence > 0.95 without strong evidence)
  if (context.confidenceScore && (context.confidenceScore as number) > 0.95 && !context.highCertaintyJustification) {
    detectedFailures.push(FAILURE_MODES.find((fm) => fm.id === "FM_002")!)
  }

  return detectedFailures
}
