// CBE Blockchain Value Proposition Types
// Builder Identity Blockchain Seal (BIBS), Smart Collaboration Contracts (SCCs),
// Immutable Proof-of-Work Ledger (PoWL), Opportunity Tokens (OTs)

export type VerificationLevel = "UNVERIFIED" | "BASIC" | "VERIFIED" | "PREMIUM" | "ELITE"

// Builder Identity Blockchain Seal (BIBS)
export interface BuilderIdentitySeal {
  sealId: string
  builderId: string
  walletAddress?: string
  verificationLevel: VerificationLevel
  issuedAt: Date
  expiresAt: Date
  verificationHash: string
  issuer: "CBE_AUTHORITY" | "THIRD_PARTY" | "DAO"
  metadata: {
    identityProof: boolean
    portfolioVerified: boolean
    businessVerified: boolean
    referenceChecked: boolean
  }
}

// Smart Collaboration Contract (SCC)
export type ContractStatus =
  | "DRAFT"
  | "PENDING_SIGNATURES"
  | "ACTIVE"
  | "IN_PROGRESS"
  | "MILESTONE_PENDING"
  | "DISPUTED"
  | "COMPLETED"
  | "CANCELLED"

export interface Milestone {
  id: string
  title: string
  description: string
  amount: number
  dueDate: Date
  status: "PENDING" | "IN_PROGRESS" | "SUBMITTED" | "APPROVED" | "DISPUTED"
  deliverables: string[]
  submittedAt?: Date
  approvedAt?: Date
}

export interface SmartCollaborationContract {
  contractId: string
  contractHash: string

  // Parties
  clientId: string
  clientWallet?: string
  builderId: string
  builderWallet?: string

  // Terms
  title: string
  description: string
  totalAmount: number
  currency: "USD" | "USDC" | "ETH"
  escrowAmount: number

  // Milestones
  milestones: Milestone[]

  // Status
  status: ContractStatus
  createdAt: Date
  signedByClient?: Date
  signedByBuilder?: Date
  startedAt?: Date
  completedAt?: Date

  // Dispute
  disputeWindowDays: number
  disputeReason?: string
  disputeFiledAt?: Date
  disputeResolvedAt?: Date

  // Immutable record
  blockchainTxId?: string
  ipfsHash?: string
}

// Immutable Proof-of-Work Ledger (PoWL)
export type CredentialType =
  | "PROJECT_COMPLETION"
  | "CLIENT_TESTIMONIAL"
  | "SKILL_VERIFICATION"
  | "MILESTONE_DELIVERY"
  | "EXCELLENCE_AWARD"
  | "COMMUNITY_CONTRIBUTION"

export interface ProofOfWorkCredential {
  credentialId: string
  credentialHash: string

  // Owner
  builderId: string
  builderWallet?: string

  // Credential details
  type: CredentialType
  title: string
  description: string
  projectName?: string
  clientName?: string // Anonymized or public

  // Verification
  issuedAt: Date
  issuer: string
  verificationProof: string

  // Metrics (if applicable)
  projectValue?: number
  deliveryTime?: number // days
  clientRating?: number

  // Immutable storage
  blockchainTxId?: string
  ipfsHash?: string

  // Non-transferable
  transferable: false
}

// Opportunity Tokens (OTs)
export type TokenRewardType =
  | "ONBOARDING_COMPLETE"
  | "FIRST_SERVICE_PUBLISHED"
  | "FIRST_PROJECT_COMPLETED"
  | "FIRST_REVIEW_RECEIVED"
  | "EARLY_DELIVERY_BONUS"
  | "REFERRAL_BONUS"
  | "COMMUNITY_CONTRIBUTION"
  | "STREAK_BONUS"

export interface OpportunityToken {
  tokenId: string
  builderId: string

  // Token details
  amount: number
  rewardType: TokenRewardType
  earnedAt: Date
  expiresAt?: Date

  // Redemption
  isRedeemed: boolean
  redeemedAt?: Date
  redeemedFor?: string

  // Non-tradeable
  tradeable: false
}

export interface TokenRedemptionOption {
  id: string
  title: string
  description: string
  tokenCost: number
  category: "BOOST" | "PLACEMENT" | "DISCOUNT" | "CONCIERGE" | "BADGE"
  isAvailable: boolean
}

// DAO Governance (Future)
export interface DAOProposal {
  proposalId: string
  title: string
  description: string
  proposerId: string

  // Voting
  votesFor: number
  votesAgainst: number
  votingEndsAt: Date

  // Status
  status: "DRAFT" | "ACTIVE" | "PASSED" | "REJECTED" | "EXECUTED"

  // Execution
  executionDetails?: string
  executedAt?: Date
}

// Builder Trust Score (aggregate)
export interface BuilderTrustScore {
  builderId: string

  // Component scores (0-100)
  identityScore: number // BIBS verification level
  contractScore: number // SCC completion rate
  credentialScore: number // PoWL credentials count & quality
  communityScore: number // OT engagement, reviews, referrals

  // Aggregate
  overallScore: number // Weighted average
  trustTier: "BRONZE" | "SILVER" | "GOLD" | "PLATINUM" | "DIAMOND"

  // History
  calculatedAt: Date
  previousScore?: number
  trend: "UP" | "DOWN" | "STABLE"
}

// CBE Blockchain Config
export const CBE_BLOCKCHAIN_CONFIG = {
  // Feature flags
  features: {
    BIBS_ENABLED: true,
    SCC_ENABLED: true,
    POWL_ENABLED: true,
    OT_ENABLED: true,
    DAO_ENABLED: false, // Future
  },

  // Token economics (non-speculative)
  tokens: {
    ONBOARDING_REWARD: 100,
    FIRST_SERVICE_REWARD: 50,
    FIRST_PROJECT_REWARD: 200,
    FIRST_REVIEW_REWARD: 75,
    EARLY_DELIVERY_BONUS: 50,
    REFERRAL_BONUS: 150,
  },

  // Redemption costs
  redemption: {
    PROFILE_BOOST_7D: 200,
    FEATURED_PLACEMENT: 500,
    CONCIERGE_PRIORITY: 300,
    PREMIUM_BADGE_30D: 400,
    SERVICE_DISCOUNT_10: 100,
  },

  // Contract settings
  contracts: {
    MIN_ESCROW_PERCENT: 25,
    DEFAULT_DISPUTE_WINDOW_DAYS: 14,
    MAX_MILESTONES: 10,
  },

  // Trust tiers
  trustTiers: {
    BRONZE: { min: 0, max: 39 },
    SILVER: { min: 40, max: 59 },
    GOLD: { min: 60, max: 79 },
    PLATINUM: { min: 80, max: 94 },
    DIAMOND: { min: 95, max: 100 },
  },
}
