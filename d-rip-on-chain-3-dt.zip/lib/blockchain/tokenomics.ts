// CBE Regulatory-Safe Tokenomics Model
// Non-speculative, utility-only token architecture

export type TokenType = "OT" | "BIS" | "PWK"

// Opportunity Tokens (OT) - Internal Utility Credits
export interface OpportunityTokenConfig {
  type: "OT"
  name: "Opportunity Token"
  symbol: "OT"
  transferable: false
  tradeable: false
  speculative: false

  // Earning methods
  earnMethods: {
    ONBOARDING_COMPLETE: 100
    FIRST_SERVICE_PUBLISHED: 50
    FIRST_PROJECT_COMPLETED: 200
    FIRST_REVIEW_RECEIVED: 75
    EARLY_DELIVERY_BONUS: 50
    REFERRAL_BONUS: 150
    SEASONAL_EVENT: 100
    COMMUNITY_CONTRIBUTION: 25
  }

  // Utility uses
  utilities: {
    SERVICE_BOOST: { cost: 200; duration: "7 days" }
    PROFILE_PROMOTION: { cost: 300; duration: "14 days" }
    PRIORITY_PLACEMENT: { cost: 500; duration: "30 days" }
    EARLY_ACCESS_CONCIERGE: { cost: 400; duration: "per request" }
    TEMPLATE_UNLOCK: { cost: 150; duration: "permanent" }
    PREMIUM_DASHBOARD: { cost: 250; duration: "30 days" }
  }
}

// Builder Identity Seal (BIS) - Verification Token
export interface BuilderIdentitySealConfig {
  type: "BIS"
  name: "Builder Identity Seal"
  symbol: "BIS"
  transferable: false
  tradeable: false
  speculative: false

  // Verification requirements
  verification: {
    IDENTITY_PROOF: "Government ID or equivalent"
    PORTFOLIO_VERIFICATION: "Authenticated work samples"
    BUSINESS_VERIFICATION: "Business registration (optional)"
    REFERENCE_CHECK: "Client references verified"
  }

  // Benefits
  benefits: [
    "Trust badge on profile",
    "Premium search placement",
    "Higher conversion rates",
    "Access to enterprise clients",
    "Concierge tier eligibility",
  ]

  // Revocation conditions
  revocationConditions: ["Fraud detection", "Identity mismatch", "Terms violation", "Repeated contract disputes"]
}

// Proof-of-Work Ledger Keys (PWK) - Reputation Assets
export interface ProofOfWorkKeyConfig {
  type: "PWK"
  name: "Proof-of-Work Key"
  symbol: "PWK"
  transferable: false
  tradeable: false
  speculative: false

  // Generation triggers
  generatedOn: {
    CONTRACT_COMPLETION: "Each completed SCC generates a PWK"
    MILESTONE_DELIVERY: "Major milestones generate mini-PWKs"
    CLIENT_REVIEW: "Positive reviews enhance PWK value"
  }

  // PWK metadata
  metadata: {
    projectHash: "Immutable deliverable fingerprint"
    builderId: "Linked builder identity"
    clientId: "Anonymized or public client"
    timestamp: "Blockchain-verified time"
    rating: "Client satisfaction score"
    deliveryTime: "Actual vs estimated"
  }

  // Reputation impact
  reputationWeight: {
    BASE_COMPLETION: 10
    ON_TIME_BONUS: 5
    EXCELLENT_RATING: 10
    REPEAT_CLIENT: 15
  }
}

// Full tokenomics configuration
export const CBE_TOKENOMICS = {
  // Core principles
  principles: {
    NO_SPECULATION: "Tokens have no external market value",
    NO_TRADING: "Tokens cannot be transferred between users",
    UTILITY_ONLY: "Tokens provide platform features only",
    REGULATORY_SAFE: "Compliant with securities regulations",
  },

  // Token distribution
  distribution: {
    OT: {
      method: "EARNED",
      sources: ["Activity", "Milestones", "Referrals", "Events"],
      purchasable: false,
      tradeable: false,
    },
    BIS: {
      method: "ISSUED",
      sources: ["Verification completion"],
      purchasable: false,
      tradeable: false,
    },
    PWK: {
      method: "GENERATED",
      sources: ["Contract completion"],
      purchasable: false,
      tradeable: false,
    },
  },

  // Utility pricing (internal credits)
  utilityPricing: {
    PROFILE_BOOST_7D: 200,
    FEATURED_PLACEMENT_30D: 500,
    CONCIERGE_PRIORITY: 300,
    PREMIUM_TEMPLATES: 150,
    EARLY_ACCESS: 400,
    SERVICE_DISCOUNT_10: 100,
  },

  // Regulatory compliance
  compliance: {
    framework: "Utility Token Model",
    securities: "Not a security - no profit expectation",
    transferability: "Non-transferable, non-tradeable",
    governance: "Platform-controlled issuance",
  },
}

// Smart Contract Flow Types
export type SCCFlowStep =
  | "CLIENT_SELECTS_SERVICE"
  | "SCC_CREATED"
  | "FUNDS_ESCROWED"
  | "BUILDER_ACCEPTS"
  | "CONTRACT_ACTIVE"
  | "MILESTONE_SUBMITTED"
  | "CLIENT_REVIEWS"
  | "APPROVED_RELEASE"
  | "DISPUTED_MEDIATION"
  | "CONTRACT_COMPLETE"

export type PWKFlowStep =
  | "SCC_COMPLETES"
  | "PWK_GENERATED"
  | "HASH_CREATED"
  | "METADATA_ATTACHED"
  | "STORED_ONCHAIN"
  | "REPUTATION_UPDATED"

export type BISFlowStep =
  | "DOCUMENTS_SUBMITTED"
  | "KYC_VERIFICATION"
  | "VERIFICATION_RESULT"
  | "BIS_MINTED"
  | "BADGE_ACTIVE"

export interface ContractFlowDiagram {
  id: string
  name: string
  steps: {
    step: string
    description: string
    next: string[]
    isDecision?: boolean
    outcomes?: { condition: string; next: string }[]
  }[]
}

export const SCC_FLOW: ContractFlowDiagram = {
  id: "scc-flow",
  name: "Service Booking Smart Contract",
  steps: [
    { step: "CLIENT_SELECTS_SERVICE", description: "Client selects a Service Listing", next: ["SCC_CREATED"] },
    { step: "SCC_CREATED", description: "CBE creates Smart Collaboration Contract", next: ["FUNDS_ESCROWED"] },
    { step: "FUNDS_ESCROWED", description: "Deposits funds into escrow", next: ["BUILDER_ACCEPTS"] },
    { step: "BUILDER_ACCEPTS", description: "Builder accepts contract", next: ["CONTRACT_ACTIVE"] },
    { step: "CONTRACT_ACTIVE", description: "Contract becomes ACTIVE", next: ["MILESTONE_SUBMITTED"] },
    { step: "MILESTONE_SUBMITTED", description: "Builder submits milestone", next: ["CLIENT_REVIEWS"] },
    {
      step: "CLIENT_REVIEWS",
      description: "Client approves OR disputes",
      next: [],
      isDecision: true,
      outcomes: [
        { condition: "Approved", next: "FUNDS_RELEASED" },
        { condition: "Disputed", next: "MEDIATION" },
      ],
    },
    { step: "FUNDS_RELEASED", description: "Funds auto-release to builder", next: ["CONTRACT_COMPLETE"] },
    { step: "MEDIATION", description: "Timer + mediation process", next: ["CONTRACT_COMPLETE"] },
    { step: "CONTRACT_COMPLETE", description: "Contract finalized, PWK generated", next: [] },
  ],
}

export const PWK_FLOW: ContractFlowDiagram = {
  id: "pwk-flow",
  name: "Proof-of-Work Ledger Creation",
  steps: [
    { step: "SCC_COMPLETES", description: "SCC contract completes", next: ["PWK_GENERATED"] },
    { step: "PWK_GENERATED", description: "CBE generates PWK", next: ["HASH_CREATED"] },
    { step: "HASH_CREATED", description: "Hash of deliverables created", next: ["METADATA_ATTACHED"] },
    {
      step: "METADATA_ATTACHED",
      description: "Builder ID, Client ID, Timestamp, Rating attached",
      next: ["STORED_ONCHAIN"],
    },
    { step: "STORED_ONCHAIN", description: "PWK stored on-chain", next: ["REPUTATION_UPDATED"] },
    { step: "REPUTATION_UPDATED", description: "Builder Reputation Score updates", next: [] },
  ],
}

export const BIS_FLOW: ContractFlowDiagram = {
  id: "bis-flow",
  name: "Builder Identity Seal Issuance",
  steps: [
    {
      step: "DOCUMENTS_SUBMITTED",
      description: "Builder submits identity verification documents",
      next: ["KYC_VERIFICATION"],
    },
    { step: "KYC_VERIFICATION", description: "CBE KYC Module processes verification", next: ["VERIFICATION_RESULT"] },
    {
      step: "VERIFICATION_RESULT",
      description: "Verification successful or failed",
      next: [],
      isDecision: true,
      outcomes: [
        { condition: "Successful", next: "BIS_MINTED" },
        { condition: "Failed", next: "REJECTED" },
      ],
    },
    { step: "BIS_MINTED", description: "BIS minted to Builder's wallet", next: ["BADGE_ACTIVE"] },
    { step: "BADGE_ACTIVE", description: "Verification badge active on profile", next: [] },
    { step: "REJECTED", description: "Verification rejected, can resubmit", next: [] },
  ],
}
