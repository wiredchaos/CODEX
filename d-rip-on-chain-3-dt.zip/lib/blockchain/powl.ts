// Immutable Proof-of-Work Ledger (PoWL) Service
// Non-transferable credentials for verified achievements

import crypto from "crypto"
import type { ProofOfWorkCredential, CredentialType } from "./types"

// Generate credential hash
export function generateCredentialHash(builderId: string, type: CredentialType, title: string, issuedAt: Date): string {
  const payload = JSON.stringify({
    builderId,
    type,
    title,
    issuedAt: issuedAt.toISOString(),
    nonce: crypto.randomBytes(16).toString("hex"),
  })

  return crypto.createHash("sha256").update(payload).digest("hex")
}

// Issue new proof-of-work credential
export async function issueCredential(params: {
  builderId: string
  builderWallet?: string
  type: CredentialType
  title: string
  description: string
  projectName?: string
  clientName?: string
  projectValue?: number
  deliveryTime?: number
  clientRating?: number
  issuer: string
}): Promise<ProofOfWorkCredential> {
  const now = new Date()
  const credentialId = `POWL_${crypto.randomBytes(8).toString("hex").toUpperCase()}`

  const credentialHash = generateCredentialHash(params.builderId, params.type, params.title, now)

  // Generate verification proof (in production: merkle proof or ZK proof)
  const verificationProof = crypto
    .createHash("sha256")
    .update(`${credentialId}:${credentialHash}:${params.issuer}`)
    .digest("hex")

  const credential: ProofOfWorkCredential = {
    credentialId,
    credentialHash,
    builderId: params.builderId,
    builderWallet: params.builderWallet,
    type: params.type,
    title: params.title,
    description: params.description,
    projectName: params.projectName,
    clientName: params.clientName,
    issuedAt: now,
    issuer: params.issuer,
    verificationProof,
    projectValue: params.projectValue,
    deliveryTime: params.deliveryTime,
    clientRating: params.clientRating,
    transferable: false, // Non-transferable by design
  }

  // In production: mint to blockchain (non-transferable token)
  return credential
}

// Verify credential authenticity
export function verifyCredential(credential: ProofOfWorkCredential): boolean {
  const expectedProof = crypto
    .createHash("sha256")
    .update(`${credential.credentialId}:${credential.credentialHash}:${credential.issuer}`)
    .digest("hex")

  return credential.verificationProof === expectedProof
}

// Get credential badge icon by type
export function getCredentialIcon(type: CredentialType): string {
  const icons: Record<CredentialType, string> = {
    PROJECT_COMPLETION: "🏆",
    CLIENT_TESTIMONIAL: "💬",
    SKILL_VERIFICATION: "✓",
    MILESTONE_DELIVERY: "🎯",
    EXCELLENCE_AWARD: "⭐",
    COMMUNITY_CONTRIBUTION: "🤝",
  }
  return icons[type]
}

// Get credential display name
export function getCredentialTypeName(type: CredentialType): string {
  const names: Record<CredentialType, string> = {
    PROJECT_COMPLETION: "Project Completion",
    CLIENT_TESTIMONIAL: "Client Testimonial",
    SKILL_VERIFICATION: "Verified Skill",
    MILESTONE_DELIVERY: "Milestone Delivery",
    EXCELLENCE_AWARD: "Excellence Award",
    COMMUNITY_CONTRIBUTION: "Community Contribution",
  }
  return names[type]
}

// Calculate total credential value for builder
export function calculateCredentialScore(credentials: ProofOfWorkCredential[]): number {
  if (credentials.length === 0) return 0

  const weights: Record<CredentialType, number> = {
    PROJECT_COMPLETION: 10,
    CLIENT_TESTIMONIAL: 8,
    SKILL_VERIFICATION: 5,
    MILESTONE_DELIVERY: 3,
    EXCELLENCE_AWARD: 15,
    COMMUNITY_CONTRIBUTION: 4,
  }

  const totalWeight = credentials.reduce((sum, c) => sum + weights[c.type], 0)
  const avgRating =
    credentials.filter((c) => c.clientRating).reduce((sum, c) => sum + (c.clientRating || 0), 0) /
    (credentials.filter((c) => c.clientRating).length || 1)

  // Score: weighted credentials + rating bonus
  return Math.min(100, Math.round(totalWeight / 2 + avgRating * 10))
}
