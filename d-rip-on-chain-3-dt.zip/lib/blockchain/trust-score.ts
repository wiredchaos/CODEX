// Builder Trust Score Calculator
// Aggregate reputation from BIBS, SCC, PoWL, and OT

import type {
  BuilderTrustScore,
  BuilderIdentitySeal,
  SmartCollaborationContract,
  ProofOfWorkCredential,
  OpportunityToken,
  VerificationLevel,
} from "./types"
import { CBE_BLOCKCHAIN_CONFIG } from "./types"
import { calculateCredentialScore } from "./powl"
import { getTokenBalance } from "./tokens"

// Calculate identity score from BIBS
function calculateIdentityScore(seal?: BuilderIdentitySeal): number {
  if (!seal) return 0

  const levelScores: Record<VerificationLevel, number> = {
    UNVERIFIED: 0,
    BASIC: 25,
    VERIFIED: 50,
    PREMIUM: 75,
    ELITE: 100,
  }

  return levelScores[seal.verificationLevel]
}

// Calculate contract score from SCCs
function calculateContractScore(contracts: SmartCollaborationContract[]): number {
  if (contracts.length === 0) return 50 // Neutral if no contracts

  const completed = contracts.filter((c) => c.status === "COMPLETED").length
  const disputed = contracts.filter((c) => c.status === "DISPUTED").length
  const total = contracts.length

  const completionRate = completed / total
  const disputeRate = disputed / total

  // Score: high completion, low disputes
  return Math.round(completionRate * 80 - disputeRate * 30 + 20)
}

// Calculate community score from OT engagement
function calculateCommunityScore(tokens: OpportunityToken[], reviewCount: number, referralCount: number): number {
  const tokenBalance = getTokenBalance(tokens)
  const earnedTokens = tokens.length

  // Score based on activity
  const tokenScore = Math.min(30, earnedTokens * 3)
  const reviewScore = Math.min(40, reviewCount * 4)
  const referralScore = Math.min(30, referralCount * 10)

  return tokenScore + reviewScore + referralScore
}

// Determine trust tier from overall score
function determineTrustTier(score: number): BuilderTrustScore["trustTier"] {
  const { trustTiers } = CBE_BLOCKCHAIN_CONFIG

  if (score >= trustTiers.DIAMOND.min) return "DIAMOND"
  if (score >= trustTiers.PLATINUM.min) return "PLATINUM"
  if (score >= trustTiers.GOLD.min) return "GOLD"
  if (score >= trustTiers.SILVER.min) return "SILVER"
  return "BRONZE"
}

// Calculate full trust score
export function calculateTrustScore(params: {
  builderId: string
  seal?: BuilderIdentitySeal
  contracts: SmartCollaborationContract[]
  credentials: ProofOfWorkCredential[]
  tokens: OpportunityToken[]
  reviewCount: number
  referralCount: number
  previousScore?: number
}): BuilderTrustScore {
  const identityScore = calculateIdentityScore(params.seal)
  const contractScore = calculateContractScore(params.contracts)
  const credentialScore = calculateCredentialScore(params.credentials)
  const communityScore = calculateCommunityScore(params.tokens, params.reviewCount, params.referralCount)

  // Weighted average (identity most important for trust)
  const weights = { identity: 0.35, contract: 0.3, credential: 0.2, community: 0.15 }
  const overallScore = Math.round(
    identityScore * weights.identity +
      contractScore * weights.contract +
      credentialScore * weights.credential +
      communityScore * weights.community,
  )

  const trustTier = determineTrustTier(overallScore)

  // Determine trend
  let trend: BuilderTrustScore["trend"] = "STABLE"
  if (params.previousScore !== undefined) {
    if (overallScore > params.previousScore + 2) trend = "UP"
    else if (overallScore < params.previousScore - 2) trend = "DOWN"
  }

  return {
    builderId: params.builderId,
    identityScore,
    contractScore,
    credentialScore,
    communityScore,
    overallScore,
    trustTier,
    calculatedAt: new Date(),
    previousScore: params.previousScore,
    trend,
  }
}

// Get trust tier badge color
export function getTrustTierColor(tier: BuilderTrustScore["trustTier"]): string {
  const colors: Record<BuilderTrustScore["trustTier"], string> = {
    BRONZE: "#CD7F32",
    SILVER: "#C0C0C0",
    GOLD: "#FFD700",
    PLATINUM: "#E5E4E2",
    DIAMOND: "#B9F2FF",
  }
  return colors[tier]
}

// Get trust tier description
export function getTrustTierDescription(tier: BuilderTrustScore["trustTier"]): string {
  const descriptions: Record<BuilderTrustScore["trustTier"], string> = {
    BRONZE: "New builder establishing reputation",
    SILVER: "Active builder with growing track record",
    GOLD: "Established builder with proven results",
    PLATINUM: "Elite builder with exceptional reputation",
    DIAMOND: "Top-tier builder with outstanding credentials",
  }
  return descriptions[tier]
}
