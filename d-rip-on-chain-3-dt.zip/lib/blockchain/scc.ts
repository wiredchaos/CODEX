// Smart Collaboration Contract (SCC) Service
// Automated agreements with escrow and milestone tracking

import crypto from "crypto"
import type { SmartCollaborationContract, Milestone } from "./types"
import { CBE_BLOCKCHAIN_CONFIG } from "./types"

// Generate contract hash
export function generateContractHash(contract: Omit<SmartCollaborationContract, "contractHash">): string {
  const payload = JSON.stringify({
    contractId: contract.contractId,
    clientId: contract.clientId,
    builderId: contract.builderId,
    title: contract.title,
    totalAmount: contract.totalAmount,
    milestones: contract.milestones.map((m) => m.id),
    createdAt: contract.createdAt.toISOString(),
  })

  return crypto.createHash("sha256").update(payload).digest("hex")
}

// Create new smart contract
export async function createSCC(params: {
  clientId: string
  clientWallet?: string
  builderId: string
  builderWallet?: string
  title: string
  description: string
  totalAmount: number
  currency?: SmartCollaborationContract["currency"]
  milestones: Omit<Milestone, "id" | "status">[]
}): Promise<SmartCollaborationContract> {
  const now = new Date()
  const contractId = `SCC_${crypto.randomBytes(8).toString("hex").toUpperCase()}`

  // Calculate escrow (minimum 25%)
  const escrowPercent = Math.max(CBE_BLOCKCHAIN_CONFIG.contracts.MIN_ESCROW_PERCENT, 25)
  const escrowAmount = (params.totalAmount * escrowPercent) / 100

  // Generate milestone IDs
  const milestones: Milestone[] = params.milestones.map((m, index) => ({
    ...m,
    id: `MS_${contractId}_${index + 1}`,
    status: "PENDING",
  }))

  const contract: Omit<SmartCollaborationContract, "contractHash"> = {
    contractId,
    clientId: params.clientId,
    clientWallet: params.clientWallet,
    builderId: params.builderId,
    builderWallet: params.builderWallet,
    title: params.title,
    description: params.description,
    totalAmount: params.totalAmount,
    currency: params.currency || "USD",
    escrowAmount,
    milestones,
    status: "DRAFT",
    createdAt: now,
    disputeWindowDays: CBE_BLOCKCHAIN_CONFIG.contracts.DEFAULT_DISPUTE_WINDOW_DAYS,
  }

  const contractHash = generateContractHash(contract)

  return {
    ...contract,
    contractHash,
  }
}

// Sign contract (client or builder)
export async function signContract(
  contract: SmartCollaborationContract,
  signerId: string,
  role: "CLIENT" | "BUILDER",
): Promise<SmartCollaborationContract> {
  const now = new Date()

  if (role === "CLIENT" && signerId === contract.clientId) {
    contract.signedByClient = now
  } else if (role === "BUILDER" && signerId === contract.builderId) {
    contract.signedByBuilder = now
  } else {
    throw new Error("Invalid signer")
  }

  // If both signed, activate contract
  if (contract.signedByClient && contract.signedByBuilder) {
    contract.status = "ACTIVE"
    contract.startedAt = now
  } else {
    contract.status = "PENDING_SIGNATURES"
  }

  return contract
}

// Submit milestone
export async function submitMilestone(
  contract: SmartCollaborationContract,
  milestoneId: string,
  builderId: string,
): Promise<SmartCollaborationContract> {
  if (contract.builderId !== builderId) {
    throw new Error("Only builder can submit milestones")
  }

  const milestone = contract.milestones.find((m) => m.id === milestoneId)
  if (!milestone) {
    throw new Error("Milestone not found")
  }

  milestone.status = "SUBMITTED"
  milestone.submittedAt = new Date()
  contract.status = "MILESTONE_PENDING"

  return contract
}

// Approve milestone (releases funds)
export async function approveMilestone(
  contract: SmartCollaborationContract,
  milestoneId: string,
  clientId: string,
): Promise<SmartCollaborationContract> {
  if (contract.clientId !== clientId) {
    throw new Error("Only client can approve milestones")
  }

  const milestone = contract.milestones.find((m) => m.id === milestoneId)
  if (!milestone) {
    throw new Error("Milestone not found")
  }

  milestone.status = "APPROVED"
  milestone.approvedAt = new Date()

  // Check if all milestones complete
  const allApproved = contract.milestones.every((m) => m.status === "APPROVED")
  if (allApproved) {
    contract.status = "COMPLETED"
    contract.completedAt = new Date()
  } else {
    contract.status = "IN_PROGRESS"
  }

  // In production: trigger escrow release
  return contract
}

// File dispute
export async function fileDispute(
  contract: SmartCollaborationContract,
  filedBy: string,
  reason: string,
): Promise<SmartCollaborationContract> {
  if (filedBy !== contract.clientId && filedBy !== contract.builderId) {
    throw new Error("Only contract parties can file disputes")
  }

  contract.status = "DISPUTED"
  contract.disputeReason = reason
  contract.disputeFiledAt = new Date()

  return contract
}

// Calculate contract completion percentage
export function getContractProgress(contract: SmartCollaborationContract): number {
  if (contract.milestones.length === 0) return 0

  const approved = contract.milestones.filter((m) => m.status === "APPROVED").length
  return Math.round((approved / contract.milestones.length) * 100)
}
