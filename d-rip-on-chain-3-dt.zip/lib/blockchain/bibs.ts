// Builder Identity Blockchain Seal (BIBS) Service
// Cryptographic verification for legitimate entrepreneurs

import crypto from "crypto"
import type { BuilderIdentitySeal, VerificationLevel } from "./types"

// Generate verification hash for identity seal
export function generateSealHash(
  builderId: string,
  walletAddress: string | undefined,
  verificationLevel: VerificationLevel,
  issuedAt: Date,
): string {
  const payload = JSON.stringify({
    builderId,
    walletAddress: walletAddress || "NO_WALLET",
    verificationLevel,
    issuedAt: issuedAt.toISOString(),
    nonce: crypto.randomBytes(16).toString("hex"),
  })

  return crypto.createHash("sha256").update(payload).digest("hex")
}

// Verify seal authenticity
export function verifySealHash(seal: BuilderIdentitySeal, expectedHash: string): boolean {
  // In production, this would verify against blockchain
  return seal.verificationHash === expectedHash
}

// Calculate verification level based on completed checks
export function calculateVerificationLevel(metadata: {
  identityProof: boolean
  portfolioVerified: boolean
  businessVerified: boolean
  referenceChecked: boolean
}): VerificationLevel {
  const { identityProof, portfolioVerified, businessVerified, referenceChecked } = metadata

  const checks = [identityProof, portfolioVerified, businessVerified, referenceChecked]
  const completedCount = checks.filter(Boolean).length

  if (completedCount === 0) return "UNVERIFIED"
  if (completedCount === 1) return "BASIC"
  if (completedCount === 2) return "VERIFIED"
  if (completedCount === 3) return "PREMIUM"
  return "ELITE"
}

// Issue new identity seal
export async function issueBIBS(
  builderId: string,
  walletAddress?: string,
  metadata?: Partial<BuilderIdentitySeal["metadata"]>,
): Promise<BuilderIdentitySeal> {
  const now = new Date()
  const expiresAt = new Date(now)
  expiresAt.setFullYear(expiresAt.getFullYear() + 1) // 1 year validity

  const fullMetadata = {
    identityProof: metadata?.identityProof ?? false,
    portfolioVerified: metadata?.portfolioVerified ?? false,
    businessVerified: metadata?.businessVerified ?? false,
    referenceChecked: metadata?.referenceChecked ?? false,
  }

  const verificationLevel = calculateVerificationLevel(fullMetadata)
  const verificationHash = generateSealHash(builderId, walletAddress, verificationLevel, now)

  const seal: BuilderIdentitySeal = {
    sealId: `BIBS_${crypto.randomBytes(8).toString("hex").toUpperCase()}`,
    builderId,
    walletAddress,
    verificationLevel,
    issuedAt: now,
    expiresAt,
    verificationHash,
    issuer: "CBE_AUTHORITY",
    metadata: fullMetadata,
  }

  // In production: store on blockchain and database
  return seal
}

// Check if seal is valid (not expired)
export function isSealValid(seal: BuilderIdentitySeal): boolean {
  return new Date() < seal.expiresAt
}

// Get trust badge color based on verification level
export function getSealBadgeColor(level: VerificationLevel): string {
  const colors: Record<VerificationLevel, string> = {
    UNVERIFIED: "#6B7280", // gray
    BASIC: "#10B981", // green
    VERIFIED: "#00F0FF", // cyan
    PREMIUM: "#FFD16F", // gold
    ELITE: "#FF003C", // red (exclusive)
  }
  return colors[level]
}
