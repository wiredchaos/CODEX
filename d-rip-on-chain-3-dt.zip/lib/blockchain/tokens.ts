// Opportunity Tokens (OTs) Service
// Non-tradeable internal incentive tokens

import crypto from "crypto"
import type { OpportunityToken, TokenRewardType, TokenRedemptionOption } from "./types"
import { CBE_BLOCKCHAIN_CONFIG } from "./types"

// Issue reward token
export async function issueOpportunityToken(
  builderId: string,
  rewardType: TokenRewardType,
  customAmount?: number,
): Promise<OpportunityToken> {
  const now = new Date()
  const expiresAt = new Date(now)
  expiresAt.setFullYear(expiresAt.getFullYear() + 1) // 1 year expiry

  // Get reward amount from config or use custom
  const rewardKey = rewardType.replace(/_/g, "_") as keyof typeof CBE_BLOCKCHAIN_CONFIG.tokens
  const amount = customAmount ?? CBE_BLOCKCHAIN_CONFIG.tokens[rewardKey] ?? 50

  const token: OpportunityToken = {
    tokenId: `OT_${crypto.randomBytes(8).toString("hex").toUpperCase()}`,
    builderId,
    amount,
    rewardType,
    earnedAt: now,
    expiresAt,
    isRedeemed: false,
    tradeable: false, // Non-tradeable by design
  }

  return token
}

// Get total available token balance
export function getTokenBalance(tokens: OpportunityToken[]): number {
  return tokens
    .filter((t) => !t.isRedeemed && (!t.expiresAt || new Date() < t.expiresAt))
    .reduce((sum, t) => sum + t.amount, 0)
}

// Redeem tokens for reward
export async function redeemTokens(
  tokens: OpportunityToken[],
  option: TokenRedemptionOption,
  builderId: string,
): Promise<{ success: boolean; remainingBalance: number; redeemedTokens: string[] }> {
  const balance = getTokenBalance(tokens.filter((t) => t.builderId === builderId))

  if (balance < option.tokenCost) {
    return { success: false, remainingBalance: balance, redeemedTokens: [] }
  }

  // Mark tokens as redeemed (FIFO)
  let costRemaining = option.tokenCost
  const redeemedTokenIds: string[] = []
  const now = new Date()

  for (const token of tokens) {
    if (token.builderId !== builderId || token.isRedeemed) continue
    if (costRemaining <= 0) break

    if (token.amount <= costRemaining) {
      token.isRedeemed = true
      token.redeemedAt = now
      token.redeemedFor = option.id
      costRemaining -= token.amount
      redeemedTokenIds.push(token.tokenId)
    }
  }

  return {
    success: true,
    remainingBalance: balance - option.tokenCost,
    redeemedTokens: redeemedTokenIds,
  }
}

// Get available redemption options
export function getRedemptionOptions(): TokenRedemptionOption[] {
  const { redemption } = CBE_BLOCKCHAIN_CONFIG

  return [
    {
      id: "PROFILE_BOOST_7D",
      title: "7-Day Profile Boost",
      description: "Your profile appears higher in search results for 7 days",
      tokenCost: redemption.PROFILE_BOOST_7D,
      category: "BOOST",
      isAvailable: true,
    },
    {
      id: "FEATURED_PLACEMENT",
      title: "Featured Builder Placement",
      description: "Appear in the Featured Builders section on the homepage",
      tokenCost: redemption.FEATURED_PLACEMENT,
      category: "PLACEMENT",
      isAvailable: true,
    },
    {
      id: "CONCIERGE_PRIORITY",
      title: "Concierge Priority Access",
      description: "Skip the queue for Concierge services",
      tokenCost: redemption.CONCIERGE_PRIORITY,
      category: "CONCIERGE",
      isAvailable: true,
    },
    {
      id: "PREMIUM_BADGE_30D",
      title: "30-Day Premium Badge",
      description: "Display a premium badge on your profile for 30 days",
      tokenCost: redemption.PREMIUM_BADGE_30D,
      category: "BADGE",
      isAvailable: true,
    },
    {
      id: "SERVICE_DISCOUNT_10",
      title: "10% Service Fee Discount",
      description: "Reduce your next service fee by 10%",
      tokenCost: redemption.SERVICE_DISCOUNT_10,
      category: "DISCOUNT",
      isAvailable: true,
    },
  ]
}

// Get reward type display name
export function getRewardTypeName(type: TokenRewardType): string {
  const names: Record<TokenRewardType, string> = {
    ONBOARDING_COMPLETE: "Welcome Bonus",
    FIRST_SERVICE_PUBLISHED: "First Service",
    FIRST_PROJECT_COMPLETED: "First Project",
    FIRST_REVIEW_RECEIVED: "First Review",
    EARLY_DELIVERY_BONUS: "Early Delivery",
    REFERRAL_BONUS: "Referral Reward",
    COMMUNITY_CONTRIBUTION: "Community Contribution",
    STREAK_BONUS: "Activity Streak",
  }
  return names[type]
}
