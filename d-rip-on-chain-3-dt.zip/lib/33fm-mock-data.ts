// Mock data provider for 33.3FM DOGECHAIN
// This allows the system to work without database setup
// To enable real database: run scripts/001_create_33fm_tables.sql

export const mockStats = {
  tracks: 1247,
  videos: 342,
  podcasts: 89,
  audiobooks: 45,
  creators: 156,
  liveListeners: 342,
}

export const mockTracks = [
  {
    id: "mock_1",
    title: "Neon Frequencies",
    creator: {
      handle: "djredfang",
      user: { displayName: "DJ Red Fang" },
    },
    genre: "Electronic",
    duration: 245,
    playCount: 1523,
    boostCount: 23,
    coverArtUrl: "/neon-album-art.jpg",
    audioUrl: "/placeholder-audio.mp3",
    mintChain: "DOGE",
    createdAt: new Date().toISOString(),
  },
  {
    id: "mock_2",
    title: "Chaos Protocol",
    creator: {
      handle: "neurometax",
      user: { displayName: "NeuroMetaX" },
    },
    genre: "Cyberpunk",
    duration: 198,
    playCount: 2891,
    boostCount: 45,
    coverArtUrl: "/neon-album-art.jpg",
    audioUrl: "/placeholder-audio.mp3",
    mintChain: "SOL",
    createdAt: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: "mock_3",
    title: "Digital Uprising",
    creator: {
      handle: "shadowlux",
      user: { displayName: "Shadow Lux" },
    },
    genre: "Industrial",
    duration: 223,
    playCount: 1234,
    boostCount: 12,
    coverArtUrl: "/neon-album-art.jpg",
    audioUrl: "/placeholder-audio.mp3",
    mintChain: "ETH",
    createdAt: new Date(Date.now() - 172800000).toISOString(),
  },
]

export const mockPodcasts = [
  {
    id: "pod_1",
    title: "The Chaos Frequency",
    creator: { handle: "neurometax", user: { displayName: "NeuroMetaX" } },
    description: "Deep dive into the cyberpunk reality",
    episodeNum: 42,
    seasonNum: 2,
    duration: 3600,
    playCount: 892,
    coverArtUrl: "/neon-album-art.jpg",
    audioUrl: "/placeholder-audio.mp3",
    createdAt: new Date(Date.now() - 259200000).toISOString(),
  },
  {
    id: "pod_2",
    title: "Red Fang Chronicles",
    creator: { handle: "djredfang", user: { displayName: "DJ Red Fang" } },
    description: "Stories from the neon underground",
    episodeNum: 15,
    seasonNum: 1,
    duration: 2700,
    playCount: 543,
    coverArtUrl: "/neon-album-art.jpg",
    audioUrl: "/placeholder-audio.mp3",
    createdAt: new Date(Date.now() - 345600000).toISOString(),
  },
]

export const mockAudiobooks = [
  {
    id: "book_1",
    title: "The Black Ledger Chronicles",
    author: "Anonymous Scribe",
    narrator: "NeuroMetaX",
    chapters: [
      { title: "Chapter 1: The Awakening", audioUrl: "/placeholder-audio.mp3", duration: 1800 },
      { title: "Chapter 2: The Network", audioUrl: "/placeholder-audio.mp3", duration: 2100 },
      { title: "Chapter 3: Digital Shadows", audioUrl: "/placeholder-audio.mp3", duration: 1950 },
    ],
    totalDuration: 5850,
    playCount: 234,
    coverArtUrl: "/neon-album-art.jpg",
    mintChain: "DOGE",
    createdAt: new Date(Date.now() - 432000000).toISOString(),
  },
]

export const mockVideos = [
  {
    id: "vid_1",
    title: "Neon Frequencies (Official Video)",
    creator: {
      handle: "djredfang",
      user: { displayName: "DJ Red Fang" },
    },
    description: "Official music video for Neon Frequencies",
    duration: 245,
    viewCount: 3421,
    boostCount: 67,
    coverArtUrl: "/neon-album-art.jpg",
    videoUrl: "/placeholder-video.mp4",
    mintChain: "DOGE",
    createdAt: new Date().toISOString(),
  },
  {
    id: "vid_2",
    title: "Chaos Protocol (Visualizer)",
    creator: {
      handle: "neurometax",
      user: { displayName: "NeuroMetaX" },
    },
    description: "Cyberpunk visualizer for Chaos Protocol",
    duration: 198,
    viewCount: 5234,
    boostCount: 89,
    coverArtUrl: "/neon-album-art.jpg",
    videoUrl: "/placeholder-video.mp4",
    mintChain: "SOL",
    createdAt: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: "vid_3",
    title: "Digital Uprising (Live Performance)",
    creator: {
      handle: "shadowlux",
      user: { displayName: "Shadow Lux" },
    },
    description: "Live 3D venue performance at The Neon Void",
    duration: 223,
    viewCount: 2156,
    boostCount: 34,
    coverArtUrl: "/neon-album-art.jpg",
    videoUrl: "/placeholder-video.mp4",
    mintChain: "ETH",
    createdAt: new Date(Date.now() - 172800000).toISOString(),
  },
]

export const mockNowPlaying = {
  id: "mock_1",
  title: "Neon Frequencies",
  creator: "DJ Red Fang",
  coverArt: "/neon-album-art.jpg",
  audioUrl: "/placeholder-audio.mp3",
  duration: 245,
  currentTime: 0,
  genre: "Electronic",
}

export function getMockStats() {
  return mockStats
}

export function getMockTracks() {
  return mockTracks
}

export function getMockPodcasts() {
  return mockPodcasts
}

export function getMockAudiobooks() {
  return mockAudiobooks
}

export function getMockVideos() {
  return mockVideos
}

export function getMockNowPlaying() {
  return {
    track: {
      id: mockTracks[0].id,
      title: mockTracks[0].title,
      creatorHandle: mockTracks[0].creator.handle,
      creatorName: mockTracks[0].creator.user.displayName,
      coverArtUrl: mockTracks[0].coverArtUrl,
      duration: mockTracks[0].duration,
      currentTime: Math.floor(Math.random() * mockTracks[0].duration),
      genre: mockTracks[0].genre,
    },
    nextUp: mockTracks.slice(1).map((t) => ({
      id: t.id,
      title: t.title,
      creatorHandle: t.creator.handle,
      duration: t.duration,
    })),
    listeners: mockStats.liveListeners,
    show: {
      title: "33.3FM Non-Stop Mix",
      host: "AI DJ",
    },
  }
}
