import { CrewCard } from "../../components/CrewCard"
import { crewMembers } from "../../content/crew"
import { colors, spacing, radius } from "../../design-system/tokens"

export default function ProfilesPage() {
  return (
    <main style={{ minHeight: "100vh", padding: spacing.spacingLg }}>
      <div style={{ maxWidth: "1400px", margin: "0 auto" }}>
        <div
          style={{
            background: "rgba(255,23,68,0.1)",
            border: `1px solid ${colors.neonRed}`,
            borderRadius: radius.radiusMd,
            padding: "1.5rem",
            marginBottom: spacing.spacingLg,
          }}
        >
          <h1 style={{ fontSize: "2.5rem", fontWeight: 700, marginBottom: "0.5rem", color: colors.softWhite }}>
            789 CREW
          </h1>
          <p style={{ fontSize: "1rem", color: colors.slateGray, lineHeight: "1.6" }}>
            Meet the team behind the signal. Each crew member brings their unique frequency to the 789 Studios
            ecosystem. From morning vibes to late-night sessions, we're broadcasting 24/7.
          </p>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(350px, 1fr))", gap: "1.5rem" }}>
          {crewMembers.map((member) => (
            <CrewCard key={member.id} member={member} />
          ))}
        </div>
      </div>
    </main>
  )
}
