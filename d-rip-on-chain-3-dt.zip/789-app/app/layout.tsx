import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import { colors, typography } from "../design-system/tokens"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "789 Studios - OTT Platform",
  description: "Premium content streaming from 789 Studios. Watch originals, CSN broadcasts, and Film3 documentaries.",
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" style={{ background: colors.studioBlack }}>
      <body
        className={inter.className}
        style={{
          fontFamily: typography.fontPrimary,
          backgroundColor: colors.studioBlack,
          color: colors.softWhite,
          margin: 0,
          padding: 0,
        }}
      >
        <nav
          style={{
            background: "rgba(2,3,10,0.95)",
            backdropFilter: "blur(12px)",
            borderBottom: `1px solid ${colors.cardBorder}`,
            padding: "1rem 2rem",
            position: "sticky",
            top: 0,
            zIndex: 1000,
          }}
        >
          <div style={{ maxWidth: "1400px", margin: "0 auto", display: "flex", alignItems: "center", gap: "2rem" }}>
            <a
              href="/789-app"
              style={{ textDecoration: "none", color: colors.neonRed, fontSize: "1.5rem", fontWeight: 700 }}
            >
              789 STUDIOS
            </a>
            <div style={{ display: "flex", gap: "1.5rem", flex: 1 }}>
              <a href="/789-app" style={{ color: colors.softWhite, textDecoration: "none", fontSize: "0.875rem" }}>
                Lobby
              </a>
              <a
                href="/789-app/watch"
                style={{ color: colors.softWhite, textDecoration: "none", fontSize: "0.875rem" }}
              >
                Watch
              </a>
              <a
                href="/789-app/create"
                style={{ color: colors.softWhite, textDecoration: "none", fontSize: "0.875rem" }}
              >
                Create
              </a>
              <a href="/789-app/csn" style={{ color: colors.softWhite, textDecoration: "none", fontSize: "0.875rem" }}>
                CSN
              </a>
              <a
                href="/789-app/film3"
                style={{ color: colors.softWhite, textDecoration: "none", fontSize: "0.875rem" }}
              >
                Film3
              </a>
              <a
                href="/789-app/profiles"
                style={{ color: colors.softWhite, textDecoration: "none", fontSize: "0.875rem" }}
              >
                Crew
              </a>
            </div>
            <button
              style={{
                background: colors.neonCyan,
                color: colors.studioBlack,
                padding: "0.5rem 1.25rem",
                borderRadius: "0.5rem",
                border: "none",
                fontSize: "0.875rem",
                fontWeight: 600,
                cursor: "pointer",
              }}
            >
              Help
            </button>
          </div>
        </nav>
        {children}
      </body>
    </html>
  )
}
