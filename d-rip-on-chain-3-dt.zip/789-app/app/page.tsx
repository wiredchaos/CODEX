import { HeroBanner } from "../components/HeroBanner"
import { ShowCard } from "../components/ShowCard"
import { shows789 } from "../content/shows"
import { colors, spacing } from "../design-system/tokens"

export default function LobbyPage() {
  const originals = shows789.filter((s) => s.category === "originals")
  const csnShows = shows789.filter((s) => s.category === "csn")
  const film3Shows = shows789.filter((s) => s.category === "film3")

  return (
    <main style={{ minHeight: "100vh", padding: spacing.spacingLg }}>
      <div style={{ maxWidth: "1400px", margin: "0 auto" }}>
        <div
          style={{
            background: "rgba(0,229,255,0.1)",
            border: `1px solid ${colors.neonCyan}`,
            borderRadius: "0.75rem",
            padding: "1.5rem",
            marginBottom: spacing.spacingLg,
          }}
        >
          <h2 style={{ fontSize: "1.25rem", fontWeight: 600, marginBottom: "0.5rem", color: colors.neonCyan }}>
            Welcome to 789 Studios
          </h2>
          <p style={{ fontSize: "0.875rem", color: colors.slateGray, lineHeight: "1.6" }}>
            This interface helps you explore shows, CSN broadcasts, Film3 content, and creator tools. Everything is
            simplified. Click on any show to watch, browse the crew profiles, or dive into CSN schedule.
          </p>
        </div>

        <HeroBanner
          title="789 STUDIOS OTT"
          subtitle="Premium content. Zero filters. Pure signal."
          ctaText="Start Watching"
          backgroundImage="/placeholder.svg?height=600&width=1400&text=789+Studios+Hero"
        />

        <section style={{ marginBottom: spacing.spacingXl }}>
          <h2 style={{ fontSize: "2rem", fontWeight: 700, marginBottom: spacing.spacingMd, color: colors.softWhite }}>
            789 Originals
          </h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: "1.5rem" }}>
            {originals.map((show) => (
              <ShowCard key={show.id} show={show} />
            ))}
          </div>
        </section>

        <section style={{ marginBottom: spacing.spacingXl }}>
          <h2 style={{ fontSize: "2rem", fontWeight: 700, marginBottom: spacing.spacingMd, color: colors.neonCyan }}>
            Crypto Spaces Network
          </h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: "1.5rem" }}>
            {csnShows.map((show) => (
              <ShowCard key={show.id} show={show} />
            ))}
          </div>
        </section>

        <section>
          <h2 style={{ fontSize: "2rem", fontWeight: 700, marginBottom: spacing.spacingMd, color: colors.film3Gold }}>
            Film3 Documentaries
          </h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: "1.5rem" }}>
            {film3Shows.map((show) => (
              <ShowCard key={show.id} show={show} />
            ))}
          </div>
        </section>
      </div>
    </main>
  )
}
