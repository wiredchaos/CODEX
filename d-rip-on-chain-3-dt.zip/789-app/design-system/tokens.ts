export const colors = {
  studioBlack: "#02030A",
  neonRed: "#ff1744",
  neonCyan: "#00e5ff",
  film3Gold: "#f6c453",
  slateGray: "#7a7f87",
  softWhite: "#f3f3f3",
  cardGlass: "rgba(255,255,255,0.04)",
  cardBorder: "rgba(255,255,255,0.08)",
  glowRed: "rgba(255,23,68,0.65)",
  glowCyan: "rgba(0,229,255,0.65)",
  glowGold: "rgba(246,196,83,0.6)",
} as const

export const typography = {
  fontPrimary: "Inter, sans-serif",
  fontWeightBold: 700,
  fontWeightMedium: 500,
  fontWeightNormal: 400,
} as const

export const spacing = {
  spacingSm: "0.5rem",
  spacingMd: "1rem",
  spacingLg: "2rem",
  spacingXl: "3rem",
} as const

export const radius = {
  radiusLg: "1rem",
  radiusMd: "0.75rem",
  radiusSm: "0.5rem",
} as const

export const shadows = {
  shadowGlowRed: "0 0 20px rgba(255,23,68,0.45)",
  shadowGlowCyan: "0 0 20px rgba(0,229,255,0.45)",
  shadowGlowGold: "0 0 18px rgba(246,196,83,0.45)",
} as const

export const effects = {
  glassCard: {
    background: "rgba(255,255,255,0.03)",
    border: "1px solid rgba(255,255,255,0.06)",
    backdropFilter: "blur(12px)",
  },
} as const
