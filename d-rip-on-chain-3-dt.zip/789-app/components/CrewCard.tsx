import { colors, radius, effects } from "../design-system/tokens"
import type { CrewMember } from "../content/crew"

interface CrewCardProps {
  member: CrewMember
}

export function CrewCard({ member }: CrewCardProps) {
  return (
    <div
      style={{
        ...effects.glassCard,
        borderRadius: radius.radiusMd,
        borderColor: member.pfpColor,
        borderWidth: "2px",
        boxShadow: `0 0 20px ${member.glowColor}`,
        padding: "1.5rem",
        position: "relative",
        overflow: "hidden",
      }}
    >
      <div
        style={{
          position: "absolute",
          top: "0.75rem",
          right: "0.75rem",
          background: colors.neonRed,
          color: colors.studioBlack,
          fontSize: "0.625rem",
          fontWeight: 700,
          padding: "0.25rem 0.5rem",
          borderRadius: radius.radiusSm,
          letterSpacing: "0.05em",
        }}
      >
        789 CREW
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: "1rem", marginBottom: "1rem" }}>
        <img
          src={member.avatarUrl || "/placeholder.svg"}
          alt={member.name}
          style={{
            width: "64px",
            height: "64px",
            borderRadius: "50%",
            border: `3px solid ${member.pfpColor}`,
            boxShadow: `0 0 15px ${member.glowColor}`,
          }}
        />
        <div>
          <h3 style={{ fontSize: "1.25rem", fontWeight: 700, color: colors.softWhite, marginBottom: "0.25rem" }}>
            {member.name}
          </h3>
          <p style={{ fontSize: "0.875rem", color: colors.slateGray }}>{member.role}</p>
        </div>
      </div>

      {member.timeSlot && (
        <div
          style={{
            background: "rgba(255,255,255,0.05)",
            padding: "0.5rem",
            borderRadius: radius.radiusSm,
            marginBottom: "0.75rem",
            fontSize: "0.75rem",
            color: colors.neonCyan,
            fontWeight: 500,
          }}
        >
          {member.timeSlot}
        </div>
      )}

      <p style={{ fontSize: "0.875rem", color: colors.slateGray, lineHeight: "1.5" }}>{member.bio}</p>

      <a
        href={`https://x.com/${member.handle.replace("@", "")}`}
        target="_blank"
        rel="noopener noreferrer"
        style={{
          display: "inline-block",
          marginTop: "1rem",
          color: member.pfpColor,
          fontSize: "0.875rem",
          fontWeight: 500,
          textDecoration: "none",
        }}
      >
        {member.handle} →
      </a>
    </div>
  )
}
