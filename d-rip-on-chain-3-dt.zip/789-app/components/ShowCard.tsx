"use client"

import { colors, shadows, radius, effects } from "../design-system/tokens"
import type { Show } from "../content/shows"

interface ShowCardProps {
  show: Show
  onClick?: () => void
}

export function ShowCard({ show, onClick }: ShowCardProps) {
  return (
    <div
      onClick={onClick}
      style={{
        ...effects.glassCard,
        borderRadius: radius.radiusMd,
        overflow: "hidden",
        cursor: "pointer",
        transition: "all 0.3s ease",
        position: "relative",
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.transform = "translateY(-4px)"
        e.currentTarget.style.boxShadow = shadows.shadowGlowCyan
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.transform = "translateY(0)"
        e.currentTarget.style.boxShadow = "none"
      }}
    >
      {show.status === "live" && (
        <div
          style={{
            position: "absolute",
            top: "0.75rem",
            right: "0.75rem",
            background: colors.neonRed,
            color: colors.softWhite,
            fontSize: "0.625rem",
            fontWeight: 700,
            padding: "0.25rem 0.5rem",
            borderRadius: radius.radiusSm,
            display: "flex",
            alignItems: "center",
            gap: "0.25rem",
            zIndex: 10,
          }}
        >
          <span
            style={{
              width: "6px",
              height: "6px",
              borderRadius: "50%",
              background: colors.softWhite,
              animation: "pulse 2s infinite",
            }}
          />
          LIVE
        </div>
      )}

      <img
        src={show.thumbnail || "/placeholder.svg"}
        alt={show.title}
        style={{
          width: "100%",
          height: "200px",
          objectFit: "cover",
        }}
      />

      <div style={{ padding: "1rem" }}>
        <h3 style={{ fontSize: "1.125rem", fontWeight: 600, color: colors.softWhite, marginBottom: "0.5rem" }}>
          {show.title}
        </h3>
        <p style={{ fontSize: "0.875rem", color: colors.slateGray, lineHeight: "1.5", marginBottom: "0.75rem" }}>
          {show.description}
        </p>

        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          {show.creator && (
            <span style={{ fontSize: "0.75rem", color: colors.neonCyan, fontWeight: 500 }}>{show.creator}</span>
          )}
          {show.duration && <span style={{ fontSize: "0.75rem", color: colors.slateGray }}>{show.duration}</span>}
        </div>
      </div>
    </div>
  )
}
