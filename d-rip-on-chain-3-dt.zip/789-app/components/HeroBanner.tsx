"use client"

import { colors, shadows, spacing, radius } from "../design-system/tokens"

interface HeroBannerProps {
  title: string
  subtitle: string
  ctaText?: string
  onCtaClick?: () => void
  backgroundImage?: string
}

export function HeroBanner({ title, subtitle, ctaText, onCtaClick, backgroundImage }: HeroBannerProps) {
  return (
    <div
      style={{
        position: "relative",
        minHeight: "400px",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: radius.radiusLg,
        overflow: "hidden",
        marginBottom: spacing.spacingLg,
      }}
    >
      {backgroundImage && (
        <img
          src={backgroundImage || "/placeholder.svg"}
          alt=""
          style={{
            position: "absolute",
            inset: 0,
            width: "100%",
            height: "100%",
            objectFit: "cover",
            opacity: 0.3,
          }}
        />
      )}

      <div
        style={{
          position: "absolute",
          inset: 0,
          background: `linear-gradient(135deg, ${colors.studioBlack}00 0%, ${colors.studioBlack} 100%)`,
        }}
      />

      <div style={{ position: "relative", zIndex: 10, textAlign: "center", padding: spacing.spacingLg }}>
        <h1
          style={{
            fontSize: "3rem",
            fontWeight: 700,
            color: colors.softWhite,
            marginBottom: spacing.spacingMd,
            textShadow: shadows.shadowGlowRed,
          }}
        >
          {title}
        </h1>
        <p
          style={{
            fontSize: "1.25rem",
            color: colors.slateGray,
            marginBottom: spacing.spacingLg,
          }}
        >
          {subtitle}
        </p>

        {ctaText && (
          <button
            onClick={onCtaClick}
            style={{
              background: colors.neonRed,
              color: colors.softWhite,
              fontSize: "1rem",
              fontWeight: 600,
              padding: "0.75rem 2rem",
              borderRadius: radius.radiusMd,
              border: "none",
              cursor: "pointer",
              boxShadow: shadows.shadowGlowRed,
              transition: "all 0.3s ease",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = "scale(1.05)"
              e.currentTarget.style.boxShadow = `0 0 30px ${colors.glowRed}`
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = "scale(1)"
              e.currentTarget.style.boxShadow = shadows.shadowGlowRed
            }}
          >
            {ctaText}
          </button>
        )}
      </div>
    </div>
  )
}
