export interface CrewMember {
  id: string
  name: string
  handle: string
  role: string
  pfpColor: string
  glowColor: string
  timeSlot?: string
  bio: string
  avatarUrl?: string
}

export const crewMembers: CrewMember[] = [
  {
    id: "vibes",
    name: "VIBES",
    handle: "@vibes789",
    role: "Vibe Curator",
    pfpColor: "#ff1744",
    glowColor: "rgba(255,23,68,0.6)",
    timeSlot: "Weekdays 6-9 AM",
    bio: "Setting the frequency for your morning. Curated chaos before coffee.",
    avatarUrl: "/placeholder.svg?height=200&width=200&text=VIBES",
  },
  {
    id: "neuro",
    name: "NEURO",
    handle: "@neuro789",
    role: "Signal Architect",
    pfpColor: "#00e5ff",
    glowColor: "rgba(0,229,255,0.6)",
    timeSlot: "Prime Time 7-10 PM",
    bio: "Decoding the signal. Broadcasting truth through the static.",
    avatarUrl: "/placeholder.svg?height=200&width=200&text=NEURO",
  },
  {
    id: "gator",
    name: "GATOR",
    handle: "@gator789",
    role: "Content Hunter",
    pfpColor: "#4caf50",
    glowColor: "rgba(76,175,80,0.6)",
    timeSlot: "Late Night 11 PM - 2 AM",
    bio: "Hunting stories in the swamp of content. Always hungry.",
    avatarUrl: "/placeholder.svg?height=200&width=200&text=GATOR",
  },
  {
    id: "wooki",
    name: "WOOKI",
    handle: "@wooki789",
    role: "Sound Engineer",
    pfpColor: "#8d6e63",
    glowColor: "rgba(141,110,99,0.6)",
    timeSlot: "Studio Sessions",
    bio: "Crafting the sonic landscape. Every frequency matters.",
    avatarUrl: "/placeholder.svg?height=200&width=200&text=WOOKI",
  },
  {
    id: "artsy",
    name: "ARTSY",
    handle: "@artsy789",
    role: "Visual Director",
    pfpColor: "#f6c453",
    glowColor: "rgba(246,196,83,0.6)",
    timeSlot: "Creative Hours",
    bio: "Painting with pixels and light. Every frame tells a story.",
    avatarUrl: "/placeholder.svg?height=200&width=200&text=ARTSY",
  },
  {
    id: "jeep",
    name: "JEEP",
    handle: "@jeep789",
    role: "Executive Producer",
    pfpColor: "#9c27b0",
    glowColor: "rgba(156,39,176,0.6)",
    timeSlot: "Command Center 24/7",
    bio: "Steering the vision. Making it all happen, on time, on brand.",
    avatarUrl: "/placeholder.svg?height=200&width=200&text=JEEP",
  },
]
