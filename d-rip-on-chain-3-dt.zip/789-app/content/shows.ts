export interface Show {
  id: string
  title: string
  description: string
  thumbnail: string
  category: "originals" | "csn" | "film3"
  creator?: string
  duration?: string
  status: "live" | "upcoming" | "available"
}

export const shows789: Show[] = [
  {
    id: "red-fang-sessions",
    title: "Red Fang Sessions",
    description: "DJ Red Fang broadcasts live from the neon tunnel. Pure frequency, zero filters.",
    thumbnail: "/placeholder.svg?height=400&width=600&text=Red+Fang+Sessions",
    category: "originals",
    creator: "DJ Red Fang",
    duration: "45 min",
    status: "live",
  },
  {
    id: "clockfall-chronicles",
    title: "Clockfall Chronicles",
    description: "Exploring the 2038 event and its ripples across timelines.",
    thumbnail: "/placeholder.svg?height=400&width=600&text=Clockfall+Chronicles",
    category: "originals",
    creator: "NEURO",
    duration: "30 min",
    status: "available",
  },
  {
    id: "csn-live",
    title: "Crypto Spaces Network LIVE",
    description: "Real-time coverage of X Spaces with crypto leaders and builders.",
    thumbnail: "/placeholder.svg?height=400&width=600&text=CSN+LIVE",
    category: "csn",
    duration: "varies",
    status: "live",
  },
  {
    id: "film3-showcase",
    title: "Film3 Documentary Showcase",
    description: "Decentralized filmmaking. Stories that matter, owned by the community.",
    thumbnail: "/placeholder.svg?height=400&width=600&text=Film3+Showcase",
    category: "film3",
    duration: "60 min",
    status: "upcoming",
  },
]
