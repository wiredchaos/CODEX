# X OAuth + Lurky Integration for WIRED CHAOS META LAB

## Overview

This implementation provides:
1. **Pattern-Safe Patch Registry** - No more "string did not match pattern" errors
2. **X OAuth (Twitter Login)** - Shared auth for Akira Codex + 33.3FM DOGECHAIN
3. **Lurky Profile Enrichment** - Read-only profile data overlay

---

## 1. Pattern-Safe Patch Registry

### File: `lib/patches/registry.ts`

All patch IDs use safe naming:
- `patch_akira_codex`
- `patch_33_3fm_dogechain`
- `patch_npc`
- etc.

Slugs are kebab-case:
- `akira-codex`
- `33-3fm-dogechain`
- `789-studios`

**No dots in folder names** - use `app/33fm/` not `app/33.3fm/`

---

## 2. X OAuth Setup

### Environment Variables

Add to Vercel project:

```env
NEXTAUTH_URL=https://your-domain.vercel.app
NEXTAUTH_SECRET=your_random_secret_here

X_CLIENT_ID=your_x_client_id
X_CLIENT_SECRET=your_x_client_secret
```

### Generate NEXTAUTH_SECRET

```bash
openssl rand -base64 32
```

### X Developer Portal Setup

1. Go to https://developer.twitter.com/
2. Create a new app
3. Enable OAuth 2.0
4. Add callback URL: `https://your-domain.vercel.app/api/auth/callback/twitter`
5. Copy Client ID and Client Secret

### Usage in Components

```tsx
import { useSession, signIn, signOut } from 'next-auth/react'

export default function Component() {
  const { data: session } = useSession()
  
  if (session?.xHandle) {
    return <div>Welcome @{session.xHandle}!</div>
  }
  
  return <button onClick={() => signIn('twitter')}>Login with X</button>
}
```

### Server-Side Usage

```tsx
import { getServerSession } from 'next-auth'
import { authOptions } from '@/app/api/auth/[...nextauth]/route'

export default async function Page() {
  const session = await getServerSession(authOptions)
  
  return <div>X Handle: {session?.xHandle}</div>
}
```

---

## 3. Lurky Profile Enrichment

### Environment Variables

```env
LURKY_API_BASE_URL=https://api.lurky.app
LURKY_API_KEY=your_lurky_api_key
```

### Read-Only Profile Fetching

The system automatically enriches creator pages with Lurky profile data:

```typescript
import { fetchLurkyProfileByHandle } from '@/lib/lurky/profiles'

const profile = await fetchLurkyProfileByHandle('neurometax')
// Returns: { handle, displayName, avatarUrl, followers, verified, etc. }
```

### API Endpoint

```
GET /api/lurky/profiles/[handle]
```

Example:
```
GET /api/lurky/profiles/neurometax
```

Response:
```json
{
  "id": "123456789",
  "handle": "neurometax",
  "displayName": "NeuroMetaX",
  "avatarUrl": "https://...",
  "description": "...",
  "followers": 15000,
  "following": 500,
  "platform": "x",
  "verified": true
}
```

### Automatic Enrichment

Creator pages at `/33fm/creator/[handle]` automatically overlay Lurky data when available.

---

## 4. Firewall Between Patches

Akira Codex and 33.3FM DOGECHAIN are completely separate:

- **Shared**: Auth session (X handle, X ID)
- **Separate**: Business logic, data models, UI components
- **No Cross-Wiring**: Each patch has its own layouts and routes

---

## 5. Testing Checklist

- [ ] X OAuth login works
- [ ] Session persists across page navigation
- [ ] Lurky profiles display on creator pages
- [ ] No "string did not match pattern" errors
- [ ] Akira Codex and 33.3FM remain isolated

---

## 6. Troubleshooting

### "string did not match pattern"

- Check folder names: use `33fm` not `33.3fm`
- Check patch IDs: use underscores (`patch_33_3fm_dogechain`)
- Check slugs: use kebab-case (`33-3fm-dogechain`)

### X OAuth not working

- Verify `NEXTAUTH_URL` matches your domain exactly
- Check X Developer Portal callback URL
- Ensure `X_CLIENT_ID` and `X_CLIENT_SECRET` are set

### Lurky profiles not loading

- Verify `LURKY_API_KEY` is set
- Check API endpoint: https://api.lurky.app/profiles/[handle]
- System gracefully degrades if Lurky unavailable

---

## Next Steps

1. Deploy to Vercel
2. Add environment variables
3. Test X OAuth flow
4. Verify Lurky enrichment on creator pages
5. Continue building Akira Codex and 33.3FM features independently
