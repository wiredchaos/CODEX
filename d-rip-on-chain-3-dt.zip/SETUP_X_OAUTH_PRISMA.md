# X Profile OAuth + Prisma + Lurky Setup Guide

This guide walks you through setting up X (Twitter) OAuth authentication with Prisma ORM and Lurky analytics integration for the WIRED CHAOS META system.

## Prerequisites

- Supabase project connected (already configured)
- X (Twitter) Developer Account with OAuth 2.0 app
- Lurky API account and API key (optional for analytics)

## Step 1: Install Dependencies

```bash
npm install prisma @prisma/client
npm install -D prisma
```

## Step 2: Initialize Prisma

The schema is already created at `prisma/schema.prisma`. Generate the Prisma client:

```bash
npx prisma generate
```

## Step 3: Run Database Migration

Create the `x_profiles` table in your Supabase database:

```bash
npx prisma db push
```

This will create the table based on the schema without creating migration files.

## Step 4: Seed Default X Profiles (Optional)

Run the seed script to pre-populate your database with 789 Studios accounts:

```bash
npx prisma db seed
```

Add this to your `package.json` if not already present:

```json
{
  "prisma": {
    "seed": "tsx prisma/seed.ts"
  }
}
```

## Step 5: Configure Environment Variables

Add these variables to your Vercel project or `.env.local`:

```env
# X (Twitter) OAuth
X_CLIENT_ID=your_x_client_id
X_CLIENT_SECRET=your_x_client_secret
NEXT_PUBLIC_X_CLIENT_ID=your_x_client_id
NEXT_PUBLIC_URL=http://localhost:3000  # or your production URL

# Lurky API (Optional)
LURKY_API_KEY=your_lurky_api_key
LURKY_API_URL=https://api.lurky.io/v1

# Supabase (Already configured)
DATABASE_URL=your_supabase_connection_string
POSTGRES_PRISMA_URL=your_supabase_pooled_connection
POSTGRES_URL_NON_POOLING=your_supabase_direct_connection
```

## Step 6: Set Up X OAuth App

1. Go to [Twitter Developer Portal](https://developer.twitter.com/en/portal/dashboard)
2. Create a new OAuth 2.0 app
3. Set the callback URL to: `https://yourdomain.com/api/x/connect/callback`
4. Enable these permissions:
   - `tweet.read`
   - `users.read`
   - `offline.access`
5. Copy your Client ID and Client Secret

## Step 7: Test the Integration

### Connect an X Account

1. Navigate to `/x-connect` in your app
2. Click "Connect X Account"
3. Authorize the app on X
4. You'll be redirected back with the account connected

### View Analytics

1. Go to `/789-studios` to see the dashboard
2. Go to `/lurky-analytics` to see detailed Space analytics
3. All connected X profiles will automatically feed into Lurky queries

## API Endpoints

### X Profile Management

- `GET /api/x/profiles` - List all connected X profiles
- `GET /api/x/connect/callback` - OAuth callback handler

### Lurky Analytics

- `GET /api/lurky/spaces` - Fetch X Spaces data for connected profiles
  - Query params: `page`, `limit`, `state` (analyzed, live, scheduled, ended)

## Database Schema

```prisma
model XProfile {
  id           String   @id @default(cuid())
  twitterId    String   @unique
  handle       String
  name         String
  avatarUrl    String?
  accessToken  String
  refreshToken String?
  expiresAt    Int?
  namespace    String   @default("789studios")
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt
}
```

## Usage in Code

### Save X Profile After OAuth

```typescript
import { saveXProfile } from "@/lib/x/save-profile"

await saveXProfile({
  twitterId: "1234567890",
  handle: "neurometax",
  name: "NEURO META X",
  avatarUrl: "https://pbs.twimg.com/profile_images/...",
  accessToken: "token_here",
  refreshToken: "refresh_token_here",
  expiresAt: Math.floor(Date.now() / 1000) + 7200,
  namespace: "789studios",
})
```

### Query X Profiles

```typescript
import { prisma } from "@/lib/prisma"

const profiles = await prisma.xProfile.findMany({
  where: { namespace: "789studios" },
})
```

### Fetch Lurky Spaces

```typescript
import { getLurkyClient } from "@/lib/lurky/client"

const client = getLurkyClient()
const { spaces } = await client.listSpaces({
  creator_ids: ["1234567890", "0987654321"],
  state: "analyzed",
  page: 0,
  limit: 20,
})
```

## Troubleshooting

### "No connected X profiles" error

- Ensure you've run the seed script or connected at least one account via `/x-connect`
- Check that `DATABASE_URL` is correctly configured

### OAuth callback fails

- Verify your X app callback URL matches exactly
- Check that `X_CLIENT_ID` and `X_CLIENT_SECRET` are set
- Ensure `NEXT_PUBLIC_URL` matches your deployment URL

### Lurky API errors

- Verify `LURKY_API_KEY` is set
- Check that connected X profiles have valid `twitterId` values
- Ensure the Lurky API is accessible from your deployment

## Security Notes

1. Never commit `.env` files to version control
2. Use Vercel environment variables for production
3. Rotate X OAuth tokens regularly
4. Enable RLS (Row Level Security) if storing user-specific profiles
5. The `accessToken` field stores sensitive data - ensure proper access controls

## Next Steps

1. Add token refresh logic for expired X tokens
2. Implement webhook handlers for real-time Space updates
3. Add more Lurky endpoints (speakers, coins, mentions)
4. Create analytics dashboards with charts and visualizations
5. Integrate with the Story Engine for content generation based on Space analytics
