// Barbed Wired Broadcast Types & Data

export type BroadcastRealm = "VRG33589" | "Vault33" | "Neteru" | "Akira" | "WCU" | "789Studios"
export type EventCategory = "Market" | "Conflict" | "AI" | "Culture" | "Anomaly" | "Prophecy"

export interface BroadcastClue {
  type: "visible" | "semi-hidden" | "deep"
  description: string
  artifactType?: string
  hint: string
}

export interface BroadcastEpisode {
  id: string
  title: string
  datetime: string
  primaryAvatar: "BrainDesk" | "AnchorAvatar"
  realms: BroadcastRealm[]
  category: EventCategory
  script: {
    open: string
    loreFrame: string
    questHook: string
    cta: string
  }
  clues: BroadcastClue[]
  status: "Upcoming" | "Live" | "Archived"
}

export const BROADCAST_AVATARS = {
  BrainDesk: {
    name: "Neural News at Night",
    description: "Nightly world signal report covering macro events, culture, and markets",
    scene: "brain-desk-studio",
  },
  AnchorAvatar: {
    name: "Barbed Wired Anchor",
    description: "NEURO-style chibi host for short, auto-generated video briefs",
    scene: "anchor-studio",
  },
}

export const SAMPLE_EPISODES: BroadcastEpisode[] = [
  {
    id: "bwb-001",
    title: "Signal 589: Market Anomaly Detected",
    datetime: "2025-01-15T22:00:00Z",
    primaryAvatar: "BrainDesk",
    realms: ["VRG33589", "Vault33"],
    category: "Market",
    script: {
      open: "The frequency bands are fluctuating. Something stirs in the 589 towers.",
      loreFrame:
        "VRG33589 sensors detect an unusual pattern in the market data streams. Vault33 archives show similar signatures from the 82675 loop.",
      questHook: "A Neural Key fragment has materialized somewhere in the broadcast. Find it before the signal fades.",
      cta: "Tag #VRG33589 with your findings. Report anomalies to WCU house channel.",
    },
    clues: [
      { type: "visible", description: "Key icon in lower third", artifactType: "NeuralKey", hint: "Watch the corners" },
      {
        type: "semi-hidden",
        description: "589 pattern in background static",
        hint: "Numbers hide in noise",
      },
      { type: "deep", description: "Frame 33 contains encoded message", hint: "Time is a spiral" },
    ],
    status: "Archived",
  },
  {
    id: "bwb-002",
    title: "Apinaya Time-Loop: Cycle 82675 Update",
    datetime: "2025-01-20T22:00:00Z",
    primaryAvatar: "AnchorAvatar",
    realms: ["Neteru", "Akira", "WCU"],
    category: "Prophecy",
    script: {
      open: "The loop continues. We are approaching convergence point 1.19.2038.",
      loreFrame:
        "Neteru archives reveal the Apinaya cycle is accelerating. The Akira Codex has unlocked new narrative branches.",
      questHook: "An Ancestral Scroll awaits those who can decipher the loop sequence.",
      cta: "Study the Neteru Primer. Report your loop progress to your WCU house.",
    },
    clues: [
      {
        type: "visible",
        description: "Scroll symbol in title card",
        artifactType: "AncestralScroll",
        hint: "Ancient wisdom surfaces",
      },
      { type: "semi-hidden", description: "Merovingian sigil in presenter's badge", hint: "Bloodlines remember" },
      { type: "deep", description: "Audio contains reversed prophecy", hint: "Play time backwards" },
    ],
    status: "Upcoming",
  },
  {
    id: "bwb-003",
    title: "Mint Factory: 589 Circuit Drop Incoming",
    datetime: "2025-01-18T20:00:00Z",
    primaryAvatar: "BrainDesk",
    realms: ["VRG33589", "789Studios"],
    category: "Culture",
    script: {
      open: "The factory fires are burning. New circuits are being forged.",
      loreFrame:
        "789 Studios has partnered with VRG33589 to release a limited batch of Chaos Chips. Access requires proof of broadcast engagement.",
      questHook: "Chaos Chips will unlock when you prove your signal loyalty.",
      cta: "Watch the full broadcast. Your engagement is being tracked for eligibility.",
    },
    clues: [
      {
        type: "visible",
        description: "Chip count in factory display",
        artifactType: "ChaosChip",
        hint: "Count the circuits",
      },
      { type: "semi-hidden", description: "Factory coordinates hidden in smoke", hint: "Where there's smoke..." },
      { type: "deep", description: "File name contains drop code", hint: "Names carry meaning" },
    ],
    status: "Live",
  },
]

export const getCategoryColor = (category: EventCategory): string => {
  switch (category) {
    case "Market":
      return "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
    case "Conflict":
      return "bg-red-500/20 text-red-400 border-red-500/30"
    case "AI":
      return "bg-cyan-500/20 text-cyan-400 border-cyan-500/30"
    case "Culture":
      return "bg-fuchsia-500/20 text-fuchsia-400 border-fuchsia-500/30"
    case "Anomaly":
      return "bg-orange-500/20 text-orange-400 border-orange-500/30"
    case "Prophecy":
      return "bg-purple-500/20 text-purple-400 border-purple-500/30"
  }
}

export const getStatusColor = (status: BroadcastEpisode["status"]): string => {
  switch (status) {
    case "Upcoming":
      return "bg-blue-500/20 text-blue-400"
    case "Live":
      return "bg-red-500/20 text-red-400 animate-pulse"
    case "Archived":
      return "bg-zinc-500/20 text-zinc-400"
  }
}
