// CBE Brand Kit - Official Design System
// Color Palette, Typography, Voice Guidelines

export const CBE_BRAND = {
  // Primary Colors (Neon Motherboard DNA)
  colors: {
    primary: {
      chaosCyan: "#00F0FF",
      infraRedFlux: "#FF003C",
      deepVoidBlack: "#0A0A0A",
      electricGraphite: "#1A1D1F",
    },
    secondary: {
      signalWhite: "#F2F9FB",
      neonAshGrey: "#5E6C72",
      circuitGold: "#FFD16F",
    },
    gradients: {
      cyanGlow: "linear-gradient(135deg, #00F0FF 0%, #0080FF 100%)",
      redFlux: "linear-gradient(135deg, #FF003C 0%, #FF6B6B 100%)",
      goldAccent: "linear-gradient(135deg, #FFD16F 0%, #FFA500 100%)",
      voidDepth: "linear-gradient(180deg, #0A0A0A 0%, #1A1D1F 100%)",
    },
  },

  // Typography
  typography: {
    headlines: {
      fontFamily: "'Neue Machina', 'Inter', sans-serif",
      weights: ["700", "800"],
    },
    body: {
      fontFamily: "'Inter', sans-serif",
      weights: ["400", "500", "600"],
    },
    accents: {
      fontFamily: "'JetBrains Mono', 'MonoLisa', monospace",
      weights: ["400", "500"],
    },
  },

  // Brand Voice
  voice: {
    tone: [
      "Modern executive tone",
      "Builder-forward",
      "Strategic, crisp, authoritative",
      "Future-tech, clean language",
      "No hype, only capability",
    ],
    avoid: ["Buzzwords", "Hyperbole", "Casual slang", "Over-promising"],
  },

  // Logo Concept
  logo: {
    description:
      '"CBE" letters embedded in a hexagonal grid cell with glowing cyan borders, thin red flux lines, and slight holographic depth',
    symbol: "A stylized bridge made from neon circuitry - representing 'bridging & building'",
    variants: ["full", "icon-only", "wordmark"],
  },
} as const

// Pricing Tiers (Entrepreneur-Optimized)
export const CBE_PRICING_TIERS = [
  {
    id: "free",
    name: "FREE",
    price: 0,
    billingPeriod: null,
    description: "Get started and explore the exchange",
    features: ["Basic profile", "1 service listing", "Apply to opportunities", "Community access"],
    limitations: ["No Streamlabs integration", "Standard support"],
    cta: "Get Started",
    highlighted: false,
  },
  {
    id: "pro",
    name: "PRO BUILDER",
    price: 19,
    billingPeriod: "month",
    description: "For serious builders ready to scale",
    features: [
      "Verified badge",
      "Unlimited listings",
      "Full portfolio showcase",
      "Streamlabs LIVE badge",
      "0% platform fee for first 3 clients/month",
      "Priority search placement",
      "Analytics dashboard",
    ],
    limitations: [],
    cta: "Upgrade to Pro",
    highlighted: true,
  },
  {
    id: "enterprise",
    name: "ENTERPRISE BUILDER",
    price: 49,
    billingPeriod: "month",
    description: "For established builders and agencies",
    features: [
      "Everything in Pro",
      "Premium placement",
      "Lower platform fee (5%)",
      "Advanced analytics",
      "Concierge booking module",
      "Team member slots (up to 5)",
      "Custom branding options",
      "Priority support",
    ],
    limitations: [],
    cta: "Go Enterprise",
    highlighted: false,
  },
  {
    id: "couture",
    name: "COUTURE BUILDER",
    price: 199,
    billingPeriod: "month",
    description: "For NEURO META X-style premium creators",
    features: [
      "Everything in Enterprise",
      "Done-for-you profile optimization",
      "High-end service templates",
      "Custom pitch deck templates",
      "Streamlabs setup concierge",
      "Featured placement across platform",
      "White-glove onboarding",
      "Direct line to CBE team",
      "Exclusive networking events",
    ],
    limitations: [],
    cta: "Apply for Couture",
    highlighted: false,
    badge: "EXCLUSIVE",
  },
] as const

export type CBEPricingTier = (typeof CBE_PRICING_TIERS)[number]
