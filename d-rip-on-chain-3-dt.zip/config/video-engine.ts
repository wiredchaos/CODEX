// ============================================
// WC META ANSWER + VIDEO ENGINE v1.0
// NAMESPACE: WC META LABS / CORE SYSTEMS
// SECURITY CLASS: RED SEAL (Critical Infrastructure)
// ============================================

// ============================================
// I. AVATAR DEFINITIONS
// ============================================
export interface Avatar {
  id: string
  name: string
  codename: string
  role: string
  signature_pose: AvatarPose
  lighting_profile: LightingProfile
  motion_seed: MotionSeed
  expressions: AvatarExpression[]
  intro_animation: IntroAnimation
  default_environment: string
  voice_profile?: VoiceProfile
  lore_connection: string[]
}

export type AvatarPose =
  | "standing_authority"
  | "seated_wisdom"
  | "leaning_casual"
  | "arms_crossed_power"
  | "gesture_teaching"
  | "shadow_emergence"
  | "floating_ethereal"
  | "combat_ready"

export interface LightingProfile {
  primary_color: string
  secondary_color: string
  rim_light: string
  ambient_intensity: number
  shadow_depth: "soft" | "medium" | "harsh"
}

export interface MotionSeed {
  idle_loop: string
  breathing_rate: "slow" | "normal" | "tense"
  micro_gestures: boolean
  stance_shifts: boolean
}

export interface AvatarExpression {
  name: string
  trigger: string
  duration_ms: number
  intensity: number
}

export interface IntroAnimation {
  type: "fade" | "glitch" | "silhouette_reveal" | "data_stream" | "portal" | "frequency_materialize"
  duration_ms: number
  sound_cue?: string
}

export interface VoiceProfile {
  tone: "deep" | "neutral" | "ethereal" | "mechanical" | "warm"
  speed: number
  reverb: number
}

export const AVATARS: Avatar[] = [
  {
    id: "neuro-meta",
    name: "NEURO META",
    codename: "THE ARCHITECT",
    role: "Primary System Guide / Narrative Director",
    signature_pose: "standing_authority",
    lighting_profile: {
      primary_color: "#00FFFF",
      secondary_color: "#FF3B3B",
      rim_light: "#A855F7",
      ambient_intensity: 0.6,
      shadow_depth: "harsh",
    },
    motion_seed: {
      idle_loop: "confident_stance",
      breathing_rate: "slow",
      micro_gestures: true,
      stance_shifts: true,
    },
    expressions: [
      { name: "hook_reveal", trigger: "message_start", duration_ms: 300, intensity: 1.0 },
      { name: "speaking", trigger: "text_output", duration_ms: 0, intensity: 0.8 },
      { name: "emphasis", trigger: "important_point", duration_ms: 500, intensity: 1.0 },
    ],
    intro_animation: {
      type: "silhouette_reveal",
      duration_ms: 800,
      sound_cue: "frequency_pulse",
    },
    default_environment: "neon_tunnel",
    voice_profile: { tone: "deep", speed: 1.0, reverb: 0.3 },
    lore_connection: ["The Architect Protocol", "CHAOS OS Core"],
  },
  {
    id: "neuro-kiba",
    name: "NEURO KIBA",
    codename: "THE HUNTER",
    role: "Tactical Operations / Combat Training",
    signature_pose: "combat_ready",
    lighting_profile: {
      primary_color: "#FF3B3B",
      secondary_color: "#FF6B00",
      rim_light: "#FFAA00",
      ambient_intensity: 0.4,
      shadow_depth: "harsh",
    },
    motion_seed: {
      idle_loop: "alert_stance",
      breathing_rate: "tense",
      micro_gestures: true,
      stance_shifts: true,
    },
    expressions: [
      { name: "threat_scan", trigger: "message_start", duration_ms: 400, intensity: 1.0 },
      { name: "intensity", trigger: "warning", duration_ms: 600, intensity: 1.0 },
    ],
    intro_animation: {
      type: "glitch",
      duration_ms: 500,
      sound_cue: "static_burst",
    },
    default_environment: "combat_arena",
    voice_profile: { tone: "deep", speed: 1.1, reverb: 0.1 },
    lore_connection: ["Kiba Protocol", "Shadow Operations"],
  },
  {
    id: "kiba-neuro",
    name: "KIBA NEURO",
    codename: "THE SHADOW",
    role: "Covert Intelligence / Deep Lore",
    signature_pose: "shadow_emergence",
    lighting_profile: {
      primary_color: "#A855F7",
      secondary_color: "#6B21A8",
      rim_light: "#00FFFF",
      ambient_intensity: 0.3,
      shadow_depth: "harsh",
    },
    motion_seed: {
      idle_loop: "lurking_presence",
      breathing_rate: "slow",
      micro_gestures: false,
      stance_shifts: true,
    },
    expressions: [
      { name: "emergence", trigger: "message_start", duration_ms: 600, intensity: 0.9 },
      { name: "knowing", trigger: "lore_reveal", duration_ms: 800, intensity: 1.0 },
    ],
    intro_animation: {
      type: "portal",
      duration_ms: 1000,
      sound_cue: "void_whisper",
    },
    default_environment: "shadow_realm",
    voice_profile: { tone: "ethereal", speed: 0.9, reverb: 0.5 },
    lore_connection: ["The Shadow Protocol", "Vault 33 Archives"],
  },
  {
    id: "uplink",
    name: "UPLINK",
    codename: "THE CONNECTOR",
    role: "System Integration / Network Operations",
    signature_pose: "gesture_teaching",
    lighting_profile: {
      primary_color: "#00FF88",
      secondary_color: "#00FFFF",
      rim_light: "#FFFFFF",
      ambient_intensity: 0.7,
      shadow_depth: "soft",
    },
    motion_seed: {
      idle_loop: "data_flow",
      breathing_rate: "normal",
      micro_gestures: true,
      stance_shifts: false,
    },
    expressions: [
      { name: "connection", trigger: "message_start", duration_ms: 300, intensity: 0.8 },
      { name: "processing", trigger: "calculation", duration_ms: 400, intensity: 0.7 },
    ],
    intro_animation: {
      type: "data_stream",
      duration_ms: 600,
      sound_cue: "data_sync",
    },
    default_environment: "data_corridor",
    voice_profile: { tone: "mechanical", speed: 1.2, reverb: 0.2 },
    lore_connection: ["Network Protocol", "System Integration"],
  },
  {
    id: "oyalan-shako",
    name: "Oyalán Shàkó",
    codename: "THE ANCESTOR",
    role: "Ancestral Wisdom / Neteru Connection",
    signature_pose: "floating_ethereal",
    lighting_profile: {
      primary_color: "#FFD700",
      secondary_color: "#FF8C00",
      rim_light: "#FFF8DC",
      ambient_intensity: 0.8,
      shadow_depth: "soft",
    },
    motion_seed: {
      idle_loop: "ancestral_presence",
      breathing_rate: "slow",
      micro_gestures: true,
      stance_shifts: false,
    },
    expressions: [
      { name: "blessing", trigger: "message_start", duration_ms: 500, intensity: 0.9 },
      { name: "wisdom", trigger: "teaching", duration_ms: 700, intensity: 1.0 },
    ],
    intro_animation: {
      type: "frequency_materialize",
      duration_ms: 1200,
      sound_cue: "ancestral_drums",
    },
    default_environment: "ancestral_temple",
    voice_profile: { tone: "warm", speed: 0.85, reverb: 0.4 },
    lore_connection: ["Neteru Protocol", "Ancestral Archives"],
  },
  {
    id: "shadowlux",
    name: "SHADOWLUX",
    codename: "THE ILLUMINATOR",
    role: "Shadow Economics / Hidden Markets",
    signature_pose: "leaning_casual",
    lighting_profile: {
      primary_color: "#8B5CF6",
      secondary_color: "#EC4899",
      rim_light: "#00FFFF",
      ambient_intensity: 0.5,
      shadow_depth: "medium",
    },
    motion_seed: {
      idle_loop: "calculating_pose",
      breathing_rate: "normal",
      micro_gestures: true,
      stance_shifts: true,
    },
    expressions: [
      { name: "intrigue", trigger: "message_start", duration_ms: 400, intensity: 0.85 },
      { name: "reveal", trigger: "secret", duration_ms: 600, intensity: 1.0 },
    ],
    intro_animation: {
      type: "silhouette_reveal",
      duration_ms: 700,
      sound_cue: "market_pulse",
    },
    default_environment: "shadow_market",
    voice_profile: { tone: "neutral", speed: 1.05, reverb: 0.25 },
    lore_connection: ["Shadow Economics", "Hidden Ledger"],
  },
  {
    id: "grymm",
    name: "GRYMM",
    codename: "THE ENFORCER",
    role: "Security Protocol / System Defense",
    signature_pose: "arms_crossed_power",
    lighting_profile: {
      primary_color: "#DC2626",
      secondary_color: "#7F1D1D",
      rim_light: "#FCA5A5",
      ambient_intensity: 0.4,
      shadow_depth: "harsh",
    },
    motion_seed: {
      idle_loop: "guard_stance",
      breathing_rate: "tense",
      micro_gestures: false,
      stance_shifts: false,
    },
    expressions: [
      { name: "warning", trigger: "threat", duration_ms: 300, intensity: 1.0 },
      { name: "enforcement", trigger: "rule_break", duration_ms: 500, intensity: 1.0 },
    ],
    intro_animation: {
      type: "glitch",
      duration_ms: 400,
      sound_cue: "system_alert",
    },
    default_environment: "security_hub",
    voice_profile: { tone: "deep", speed: 0.95, reverb: 0.15 },
    lore_connection: ["Security Protocol", "Firewall Systems"],
  },
  {
    id: "degen-sith",
    name: "DeGenSith",
    codename: "THE CHAOS AGENT",
    role: "Market Chaos / Degen Philosophy",
    signature_pose: "leaning_casual",
    lighting_profile: {
      primary_color: "#22C55E",
      secondary_color: "#EF4444",
      rim_light: "#FDE047",
      ambient_intensity: 0.6,
      shadow_depth: "medium",
    },
    motion_seed: {
      idle_loop: "restless_energy",
      breathing_rate: "normal",
      micro_gestures: true,
      stance_shifts: true,
    },
    expressions: [
      { name: "mania", trigger: "gains", duration_ms: 300, intensity: 1.0 },
      { name: "despair", trigger: "loss", duration_ms: 400, intensity: 0.9 },
    ],
    intro_animation: {
      type: "glitch",
      duration_ms: 350,
      sound_cue: "chart_ding",
    },
    default_environment: "trading_floor",
    voice_profile: { tone: "neutral", speed: 1.3, reverb: 0.1 },
    lore_connection: ["Degen Protocol", "Market Chaos"],
  },
  {
    id: "neurolux-drae",
    name: "Neurolux Drae",
    codename: "THE VISIONARY",
    role: "Creative Direction / Vision Mapping",
    signature_pose: "gesture_teaching",
    lighting_profile: {
      primary_color: "#F472B6",
      secondary_color: "#A855F7",
      rim_light: "#FFFFFF",
      ambient_intensity: 0.7,
      shadow_depth: "soft",
    },
    motion_seed: {
      idle_loop: "creative_flow",
      breathing_rate: "normal",
      micro_gestures: true,
      stance_shifts: true,
    },
    expressions: [
      { name: "inspiration", trigger: "idea", duration_ms: 500, intensity: 0.95 },
      { name: "presentation", trigger: "showcase", duration_ms: 600, intensity: 1.0 },
    ],
    intro_animation: {
      type: "fade",
      duration_ms: 800,
      sound_cue: "creative_spark",
    },
    default_environment: "creator_studio",
    voice_profile: { tone: "warm", speed: 1.0, reverb: 0.3 },
    lore_connection: ["Creator Codex", "Vision Protocol"],
  },
  {
    id: "fm-persona-33",
    name: "33.3 FM HOST",
    codename: "THE BROADCASTER",
    role: "Radio Personality / News Anchor",
    signature_pose: "seated_wisdom",
    lighting_profile: {
      primary_color: "#F59E0B",
      secondary_color: "#DC2626",
      rim_light: "#00FFFF",
      ambient_intensity: 0.65,
      shadow_depth: "medium",
    },
    motion_seed: {
      idle_loop: "broadcast_ready",
      breathing_rate: "normal",
      micro_gestures: true,
      stance_shifts: false,
    },
    expressions: [
      { name: "breaking_news", trigger: "alert", duration_ms: 300, intensity: 1.0 },
      { name: "commentary", trigger: "analysis", duration_ms: 500, intensity: 0.85 },
    ],
    intro_animation: {
      type: "frequency_materialize",
      duration_ms: 600,
      sound_cue: "radio_static",
    },
    default_environment: "broadcast_studio",
    voice_profile: { tone: "warm", speed: 1.1, reverb: 0.2 },
    lore_connection: ["Barbed Wired Broadcast", "33.3 FM"],
  },
  {
    id: "dog-1787",
    name: "Dog #1787",
    codename: "THE GUARDIAN",
    role: "Canonical WC META Avatar / Community Symbol",
    signature_pose: "standing_authority",
    lighting_profile: {
      primary_color: "#00FFFF",
      secondary_color: "#FFD700",
      rim_light: "#FF3B3B",
      ambient_intensity: 0.7,
      shadow_depth: "medium",
    },
    motion_seed: {
      idle_loop: "guardian_watch",
      breathing_rate: "slow",
      micro_gestures: true,
      stance_shifts: true,
    },
    expressions: [
      { name: "alert", trigger: "notification", duration_ms: 250, intensity: 0.9 },
      { name: "approval", trigger: "success", duration_ms: 400, intensity: 1.0 },
    ],
    intro_animation: {
      type: "silhouette_reveal",
      duration_ms: 700,
      sound_cue: "guardian_howl",
    },
    default_environment: "neon_boardroom",
    voice_profile: { tone: "neutral", speed: 1.0, reverb: 0.25 },
    lore_connection: ["Original Protocol", "Community Genesis"],
  },
]

// ============================================
// II. ENVIRONMENT DEFINITIONS
// ============================================
export interface Environment {
  id: string
  name: string
  category: EnvironmentCategory
  description: string
  lighting: EnvironmentLighting
  elements: string[]
  ambient_sound?: string
  interaction_modes: InteractionMode[]
}

export type EnvironmentCategory = "business" | "akira" | "creator" | "npc" | "fen" | "vault33" | "broadcast"

export type InteractionMode = "meeting" | "npc" | "story" | "training" | "broadcast"

export interface EnvironmentLighting {
  base_color: string
  accent_color: string
  fog_density: number
  bloom_intensity: number
}

export const ENVIRONMENTS: Environment[] = [
  // Business Patch Environments
  {
    id: "neon_boardroom",
    name: "Neon Boardroom",
    category: "business",
    description: "Floating KPI screens, avatar chairs auto-size, holographic document sharing",
    lighting: { base_color: "#0A0A0F", accent_color: "#00FFFF", fog_density: 0.3, bloom_intensity: 0.6 },
    elements: ["floating_kpi_screens", "holographic_table", "avatar_chairs", "document_projector"],
    ambient_sound: "corporate_hum",
    interaction_modes: ["meeting", "training"],
  },
  {
    id: "glass_atrium",
    name: "Executive Atrium",
    category: "business",
    description: "Corporate glass, reflective floors, training modules auto-load",
    lighting: { base_color: "#0F0F14", accent_color: "#A855F7", fog_density: 0.2, bloom_intensity: 0.4 },
    elements: ["glass_walls", "reflective_floor", "training_pods", "executive_desk"],
    ambient_sound: "atrium_ambience",
    interaction_modes: ["meeting", "training"],
  },
  {
    id: "creator_studio",
    name: "Creator Studio",
    category: "creator",
    description: "Script walls, Canva-style visual boards, whiteboard with auto transcription",
    lighting: { base_color: "#0A0A12", accent_color: "#F472B6", fog_density: 0.15, bloom_intensity: 0.5 },
    elements: ["script_walls", "visual_boards", "transcription_whiteboard", "render_station"],
    ambient_sound: "creative_pulse",
    interaction_modes: ["story", "training"],
  },
  {
    id: "financial_observatory",
    name: "Financial Observatory",
    category: "business",
    description: "Org charts projected in space, tax simulations, entity mapping network",
    lighting: { base_color: "#050510", accent_color: "#FFE066", fog_density: 0.4, bloom_intensity: 0.7 },
    elements: ["orbital_org_charts", "tax_simulator", "entity_network", "data_streams"],
    ambient_sound: "market_data",
    interaction_modes: ["meeting", "training"],
  },
  // AKIRA Codex Environments
  {
    id: "rupture_library",
    name: "Rupture Neon Library",
    category: "akira",
    description: "Cinematic noir space with glowing codex shelves and narrative streams",
    lighting: { base_color: "#000000", accent_color: "#FF3B3B", fog_density: 0.5, bloom_intensity: 0.8 },
    elements: ["codex_shelves", "narrative_streams", "glitch_portals", "story_pedestals"],
    ambient_sound: "library_whispers",
    interaction_modes: ["story", "npc"],
  },
  {
    id: "vault_33_chamber",
    name: "Vault 33 Chamber",
    category: "vault33",
    description: "Ancient-futuristic vault with cipher walls and artifact pedestals",
    lighting: { base_color: "#020208", accent_color: "#A855F7", fog_density: 0.6, bloom_intensity: 0.9 },
    elements: ["cipher_walls", "artifact_pedestals", "frequency_gates", "memory_pools"],
    ambient_sound: "vault_resonance",
    interaction_modes: ["story", "npc"],
  },
  {
    id: "lore_stream_room",
    name: "Lore Stream Room",
    category: "akira",
    description: "Flowing data rivers of narrative, story fragments floating in space",
    lighting: { base_color: "#000005", accent_color: "#00FFFF", fog_density: 0.4, bloom_intensity: 0.7 },
    elements: ["data_rivers", "story_fragments", "character_holograms", "timeline_spiral"],
    ambient_sound: "data_flow",
    interaction_modes: ["story", "npc"],
  },
  // NPC Environments
  {
    id: "neon_tunnel",
    name: "Neon Tunnel",
    category: "npc",
    description: "Infinite corridor with pulsing neon walls and data streams",
    lighting: { base_color: "#000000", accent_color: "#00FFFF", fog_density: 0.5, bloom_intensity: 0.8 },
    elements: ["neon_walls", "data_streams", "floor_lights", "portal_end"],
    ambient_sound: "tunnel_pulse",
    interaction_modes: ["npc", "story"],
  },
  {
    id: "data_corridor",
    name: "Data Stream Corridor",
    category: "npc",
    description: "Holographic data flowing through transparent walls",
    lighting: { base_color: "#000508", accent_color: "#00FF88", fog_density: 0.3, bloom_intensity: 0.6 },
    elements: ["data_walls", "holographic_panels", "system_nodes", "access_terminals"],
    ambient_sound: "system_hum",
    interaction_modes: ["npc", "training"],
  },
  {
    id: "core_memory_node",
    name: "Core Memory Node",
    category: "npc",
    description: "Central nervous system of WIRED CHAOS META",
    lighting: { base_color: "#020202", accent_color: "#FF3B3B", fog_density: 0.6, bloom_intensity: 0.9 },
    elements: ["memory_core", "neural_pathways", "access_rings", "data_fountains"],
    ambient_sound: "core_heartbeat",
    interaction_modes: ["npc", "story"],
  },
  // FEN / Vault33 Environments
  {
    id: "xr_key_room",
    name: "XR Key Room",
    category: "fen",
    description: "Floating keys in dimensional space, each unlocking different realities",
    lighting: { base_color: "#000000", accent_color: "#FFD700", fog_density: 0.7, bloom_intensity: 1.0 },
    elements: ["floating_keys", "reality_portals", "frequency_markers", "cipher_locks"],
    ambient_sound: "key_resonance",
    interaction_modes: ["story", "npc"],
  },
  {
    id: "artifact_pedestal",
    name: "Artifact Pedestal Chamber",
    category: "fen",
    description: "Sacred space for artifact examination and lore revelation",
    lighting: { base_color: "#050005", accent_color: "#A855F7", fog_density: 0.5, bloom_intensity: 0.8 },
    elements: ["central_pedestal", "lore_inscriptions", "frequency_scanner", "artifact_display"],
    ambient_sound: "artifact_hum",
    interaction_modes: ["story"],
  },
  {
    id: "stargate_environment",
    name: "Stargate Environment",
    category: "vault33",
    description: "Ancient portal space with cosmic frequency alignment",
    lighting: { base_color: "#000008", accent_color: "#00FFFF", fog_density: 0.8, bloom_intensity: 1.0 },
    elements: ["stargate_ring", "frequency_pillars", "cosmic_backdrop", "alignment_markers"],
    ambient_sound: "cosmic_gate",
    interaction_modes: ["story", "npc"],
  },
  // Broadcast Environments
  {
    id: "broadcast_studio",
    name: "33.3 FM Broadcast Studio",
    category: "broadcast",
    description: "Retro-futuristic radio station with live feed monitors",
    lighting: { base_color: "#0A0505", accent_color: "#F59E0B", fog_density: 0.2, bloom_intensity: 0.5 },
    elements: ["broadcast_desk", "live_monitors", "soundwave_visualizer", "on_air_sign"],
    ambient_sound: "radio_static_ambient",
    interaction_modes: ["broadcast", "npc"],
  },
  // Additional Combat/Training Environments
  {
    id: "combat_arena",
    name: "Combat Training Arena",
    category: "npc",
    description: "Holographic training space with adaptive difficulty",
    lighting: { base_color: "#080000", accent_color: "#FF3B3B", fog_density: 0.4, bloom_intensity: 0.7 },
    elements: ["training_ring", "target_drones", "stats_display", "weapon_rack"],
    ambient_sound: "arena_pulse",
    interaction_modes: ["training"],
  },
  {
    id: "shadow_realm",
    name: "Shadow Realm",
    category: "vault33",
    description: "Liminal space between realities, where secrets are revealed",
    lighting: { base_color: "#000000", accent_color: "#6B21A8", fog_density: 0.9, bloom_intensity: 0.6 },
    elements: ["shadow_tendrils", "truth_mirrors", "void_floor", "whisper_sources"],
    ambient_sound: "void_whispers",
    interaction_modes: ["story", "npc"],
  },
  {
    id: "shadow_market",
    name: "Shadow Market",
    category: "business",
    description: "Hidden economic zone with encrypted transactions",
    lighting: { base_color: "#050008", accent_color: "#8B5CF6", fog_density: 0.5, bloom_intensity: 0.6 },
    elements: ["trade_stalls", "encrypted_boards", "deal_rooms", "vault_doors"],
    ambient_sound: "market_murmur",
    interaction_modes: ["meeting", "npc"],
  },
  {
    id: "trading_floor",
    name: "Chaos Trading Floor",
    category: "business",
    description: "High-energy market space with real-time data feeds",
    lighting: { base_color: "#000A00", accent_color: "#22C55E", fog_density: 0.2, bloom_intensity: 0.5 },
    elements: ["chart_walls", "ticker_tape", "trading_terminals", "alert_beacons"],
    ambient_sound: "market_chaos",
    interaction_modes: ["training", "npc"],
  },
  {
    id: "ancestral_temple",
    name: "Ancestral Temple",
    category: "akira",
    description: "Sacred space connecting to Neteru wisdom",
    lighting: { base_color: "#0A0800", accent_color: "#FFD700", fog_density: 0.4, bloom_intensity: 0.8 },
    elements: ["ancestor_statues", "wisdom_flames", "offering_altar", "memory_pool"],
    ambient_sound: "ancestral_drums",
    interaction_modes: ["story", "npc"],
  },
  {
    id: "security_hub",
    name: "Security Hub",
    category: "npc",
    description: "Central security monitoring and enforcement station",
    lighting: { base_color: "#080000", accent_color: "#DC2626", fog_density: 0.3, bloom_intensity: 0.5 },
    elements: ["monitor_wall", "threat_display", "lockdown_controls", "alert_systems"],
    ambient_sound: "security_pulse",
    interaction_modes: ["npc", "training"],
  },
]

// ============================================
// III. VIDEO OUTPUT SCHEMA
// ============================================
export interface VideoOutput {
  id: string
  text_answer: string
  video_url: string
  thumbnail_url: string
  avatar_id: string
  avatar_pose: AvatarPose
  environment_id: string
  duration_seconds: number
  hook_type: HookType
  emotion: AvatarEmotion
  created_at: string
}

export type HookType = "sudden_motion" | "bright_spark" | "red_pulse" | "lens_flare" | "silhouette_cut" | "glitch_burst"

export type AvatarEmotion = "neutral" | "intensity" | "wisdom" | "warning" | "excitement" | "mystery" | "authority"

// ============================================
// IV. API REQUEST/RESPONSE SCHEMAS
// ============================================
export interface AnswerVideoRequest {
  prompt: string
  avatar: string
  emotion?: AvatarEmotion
  environment?: string
}

export interface AnswerVideoResponse {
  text_answer: string
  video_url: string
  thumbnail: string
  avatar_pose: AvatarPose
  environment: string
  duration_seconds: number
}

export interface VideoGenerateRequest {
  seed_json: Record<string, unknown>
  avatar_style: string
  motion_type: string
  duration: "3" | "6" | "9" | "12"
  environment: string
}

export interface AvatarRenderRequest {
  avatar: string
  expression: string
  pose: AvatarPose
  lighting: string
  environment: string
}

export interface EnvironmentLoadRequest {
  environment_id: string
  detail_level: "low" | "medium" | "high"
  interaction_mode: InteractionMode
}

// ============================================
// V. ATTENTION OPTIMIZATION CONFIG
// ============================================
export interface AttentionHook {
  type: HookType
  trigger_ms: number
  intensity: number
  color?: string
}

export const ATTENTION_HOOKS: AttentionHook[] = [
  { type: "sudden_motion", trigger_ms: 0, intensity: 1.0 },
  { type: "bright_spark", trigger_ms: 100, intensity: 0.9, color: "#FFFFFF" },
  { type: "red_pulse", trigger_ms: 0, intensity: 0.85, color: "#FF3B3B" },
  { type: "lens_flare", trigger_ms: 150, intensity: 0.8, color: "#00FFFF" },
  { type: "silhouette_cut", trigger_ms: 0, intensity: 1.0 },
  { type: "glitch_burst", trigger_ms: 50, intensity: 0.95 },
]

// Scene Density Rule: Max 2 objects in frame, 1 strong visual idea per shot
export const SCENE_RULES = {
  max_objects: 2,
  max_visual_ideas: 1,
  hook_duration_ms: 300,
  min_video_duration: 3,
  max_video_duration: 12,
}

// ============================================
// VI. WC META LABS MODULE REGISTRATION
// ============================================
export const VIDEO_ENGINE_MODULE = {
  module: "wc_meta_answer_video_engine",
  version: "1.0",
  namespace: "wc_meta_labs.core",
  binds_to: ["npc", "akira_codex", "creator_codex", "chaos_os", "business_patch", "fen", "vault33"],
  capabilities: ["text_generation", "3d_video_generation", "avatar_rendering", "environment_loading"],
  requirements: {
    video_length: "3-12",
    attention_hook: true,
    avatar_expression: true,
    environment_context: true,
  },
}
