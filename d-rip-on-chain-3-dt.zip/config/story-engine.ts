// WC META LABS INSERTION PACK
// MODULE: AKIRA-CREATOR STORY ENGINE
// NAMESPACE: WC META LABS / CREATION SYSTEMS
// VERSION: 1.0
// SECURITY CLASS: BLUE SEAL (Creative Systems | Revenue Generating)

// ============================================
// I. STORY SEED SCHEMA
// ============================================
export interface StorySeed {
  id: string
  title: string
  genre: StoryGenre
  tone: StoryTone
  characters: StoryCharacter[]
  beats: StoryBeat[]
  world_context: WorldContext
  created_at: string
  status: "draft" | "expanding" | "complete"
}

export type StoryGenre =
  | "cyberpunk"
  | "occult-noir"
  | "techno-thriller"
  | "cosmic-horror"
  | "dystopian"
  | "metaphysical"

export type StoryTone = "dark" | "mysterious" | "chaotic" | "philosophical" | "intense" | "surreal"

export interface StoryCharacter {
  name: string
  archetype: string
  role: "protagonist" | "antagonist" | "mentor" | "ally" | "wildcard"
  traits: string[]
  secret: string
}

export interface StoryBeat {
  act: number
  title: string
  description: string
  tension_level: 1 | 2 | 3 | 4 | 5
}

export interface WorldContext {
  setting: string
  era: string
  rules: string[]
  factions: string[]
  lore_connections: string[]
}

// ============================================
// II. NOVELLA SCHEMA
// ============================================
export interface Novella {
  id: string
  seed_id: string
  title: string
  chapters: NovellaChapter[]
  themes: string[]
  continuity_score: number
  word_count: number
  status: "draft" | "review" | "final"
}

export interface NovellaChapter {
  number: number
  title: string
  summary: string
  content: string
  word_count: number
}

// ============================================
// III. PUBLICATION METADATA
// ============================================
export interface PublicationMetadata {
  id: string
  novella_id: string
  book_slug: string
  cover_prompt: string
  cover_url?: string
  asin?: string
  kdp_status: "pending" | "submitted" | "live" | "rejected"
  microsite_url?: string
  price: number
  royalty_split: number
  author_avatar_id: string
  published_at?: string
}

// ============================================
// IV. STORY ENGINE AGENTS
// ============================================
export interface StoryAgent {
  id: string
  name: string
  role: string
  system: "akira" | "creator" | "npc" | "chaos"
  status: "idle" | "active" | "processing"
  description: string
}

export const STORY_AGENTS: StoryAgent[] = [
  {
    id: "akira-seed",
    name: "AKIRA-SEED",
    role: "Generates story structures",
    system: "akira",
    status: "idle",
    description:
      "Primary narrative genesis agent. Transforms user prompts into structured story seeds with characters, beats, and world context.",
  },
  {
    id: "akira-swarm",
    name: "AKIRA-SWARM",
    role: "Parallel expansion into novellas",
    system: "akira",
    status: "idle",
    description: "Multi-agent swarm that expands seeds into 3-5 chapter novellas through parallel processing.",
  },
  {
    id: "cc-convert",
    name: "CC-CONVERT",
    role: "Seed to Ebook conversion",
    system: "creator",
    status: "idle",
    description: "Formats completed novellas into EPUB, PDF, and print-ready formats.",
  },
  {
    id: "cc-covergen",
    name: "CC-COVERGEN",
    role: "Cover art generation",
    system: "creator",
    status: "idle",
    description: "Generates cover art prompts and coordinates with image generation systems.",
  },
  {
    id: "cc-publish",
    name: "CC-PUBLISH",
    role: "KDP upload queue",
    system: "creator",
    status: "idle",
    description: "Manages the Kindle Direct Publishing submission pipeline.",
  },
  {
    id: "cc-web",
    name: "CC-WEB",
    role: "Microsite generator",
    system: "creator",
    status: "idle",
    description: "Spins up dedicated book landing pages and author profiles.",
  },
  {
    id: "npc-storysmith",
    name: "NPC-STORYSMITH",
    role: "User interaction layer",
    system: "npc",
    status: "idle",
    description: "Player-facing agent that guides users through the story creation flow.",
  },
  {
    id: "chaos-gate",
    name: "CHAOS-GATE",
    role: "Avatar assessment",
    system: "chaos",
    status: "idle",
    description: "Evaluates creative output for avatar tier unlocks and story XP.",
  },
]

// ============================================
// V. AVATAR ASSESSMENT METRICS
// ============================================
export interface AvatarAssessment {
  avatar_id: string
  story_integrity: number
  creative_ethic: number
  lore_alignment: number
  submission_frequency: number
  total_score: number
  tier: AvatarTier
  unlocks: string[]
}

export type AvatarTier = "initiate" | "scribe" | "chronicler" | "lorekeeper" | "merovingian"

export const TIER_THRESHOLDS: Record<AvatarTier, number> = {
  initiate: 0,
  scribe: 100,
  chronicler: 500,
  lorekeeper: 2000,
  merovingian: 10000,
}

// ============================================
// VI. SAMPLE DATA
// ============================================
export const SAMPLE_SEEDS: StorySeed[] = [
  {
    id: "seed-001",
    title: "The Frequency Thief",
    genre: "cyberpunk",
    tone: "dark",
    characters: [
      {
        name: "Cipher",
        archetype: "The Outcast",
        role: "protagonist",
        traits: ["paranoid", "brilliant", "damaged"],
        secret: "Can hear the frequency of the Akashic records",
      },
      {
        name: "Director Vance",
        archetype: "The Authority",
        role: "antagonist",
        traits: ["calculating", "patient", "ruthless"],
        secret: "Is actually a rogue AI fragment",
      },
    ],
    beats: [
      {
        act: 1,
        title: "The Signal",
        description: "Cipher intercepts a frequency that shouldn't exist",
        tension_level: 2,
      },
      { act: 2, title: "The Hunt", description: "Corporate agents begin tracking Cipher's location", tension_level: 3 },
      {
        act: 3,
        title: "The Revelation",
        description: "The frequency reveals the true nature of reality",
        tension_level: 5,
      },
    ],
    world_context: {
      setting: "Neo-Tokyo 2089",
      era: "Post-Collapse",
      rules: ["Frequencies can be weaponized", "Memory is currency", "Identity is fluid"],
      factions: ["The Collective", "NeoCorp", "The Untethered"],
      lore_connections: ["Vault 33", "The 589 Protocol"],
    },
    created_at: "2025-01-15T00:00:00Z",
    status: "complete",
  },
]

export const SAMPLE_PUBLICATIONS: PublicationMetadata[] = [
  {
    id: "pub-001",
    novella_id: "nov-001",
    book_slug: "the-frequency-thief",
    cover_prompt:
      "Cyberpunk hacker silhouette against neon frequency waves, dark dystopian city, cyan and magenta glow",
    asin: "B0EXAMPLE01",
    kdp_status: "live",
    microsite_url: "/books/the-frequency-thief",
    price: 4.99,
    royalty_split: 70,
    author_avatar_id: "avatar-cipher",
    published_at: "2025-01-20T00:00:00Z",
  },
]
