// NETERU APINAYA — PRIMARY UNIVERSE CONFIGURATION
// HOST: AKIRA CODEX | AUTHOR: NEURO META X
// PUBLISHER: CHAOS PUBLICATIONS | STUDIO: NETERU STUDIOS

export interface NeteruUniverse {
  id: string
  name: string
  slug: string
  featured: boolean
  default: boolean
  description: string
  author: AuthorMetadata
  publisher: PublisherMetadata
  studio: StudioMetadata
  creditLine: string
}

export interface AuthorMetadata {
  name: string
  penName: string
  roles: string[]
}

export interface PublisherMetadata {
  name: string
  type: string
  imprint: string
}

export interface StudioMetadata {
  name: string
  type: string
  capabilities: string[]
}

export const NETERU_UNIVERSE: NeteruUniverse = {
  id: "neteru-apinaya",
  name: "NETERU APINAYA",
  slug: "neteru-apinaya",
  featured: true,
  default: true,
  description:
    "Main demo and flagship universe of Akira Codex, used to showcase WIRED CHAOS applications for books → graphic novels → animation → ARG → world-building.",
  author: {
    name: "NEURO META X",
    penName: "NEURO META X",
    roles: ["creator", "showrunner", "head_lore_engineer"],
  },
  publisher: {
    name: "CHAOS PUBLICATIONS",
    type: "transmedia publishing imprint",
    imprint: "chaos-publications",
  },
  studio: {
    name: "NETERU STUDIOS",
    type: "animation + game + ARG production studio",
    capabilities: ["animation", "game_design", "arg_production", "worldbuilding"],
  },
  creditLine: "Storyworld NETERU APINAYA by NEURO META X, published by CHAOS PUBLICATIONS, produced by NETERU STUDIOS.",
}

// ============================================
// PANTHEONS & SHADOW COUNTERPARTS
// ============================================
export interface Pantheon {
  id: string
  name: string
  domain: string
  shadowCounterpart?: string
  geopoliticalNode?: string
  artifacts: string[]
  powers: string[]
}

export const NETERU_PANTHEONS: Pantheon[] = [
  {
    id: "sekhmet",
    name: "Sekhmet",
    domain: "Fire, War, Protection",
    shadowCounterpart: "Apep",
    geopoliticalNode: "Upper Egypt",
    artifacts: ["Eye of Ra", "Lioness Crown"],
    powers: ["Solar Fury", "Plague Control", "Warrior Blessing"],
  },
  {
    id: "nebwet",
    name: "Nebwet (Nephthys)",
    domain: "Void, Night Geometry, Dissolution",
    shadowCounterpart: "Set",
    geopoliticalNode: "Lower Egypt / Underworld Gates",
    artifacts: ["Basket of Night", "Dissolution Ankh"],
    powers: ["Shadow Walk", "Death Transition", "Night Vision"],
  },
  {
    id: "maat",
    name: "Ma'at",
    domain: "Balance, Ratio, Revelation",
    shadowCounterpart: "Isfet",
    geopoliticalNode: "Hall of Two Truths",
    artifacts: ["Feather of Truth", "Scales of Balance"],
    powers: ["Truth Sight", "Cosmic Balance", "Justice Decree"],
  },
  {
    id: "thoth",
    name: "Thoth",
    domain: "Knowledge, Writing, Magic",
    shadowCounterpart: "Chaos Scribe",
    geopoliticalNode: "Hermopolis / Akashic Library",
    artifacts: ["Emerald Tablets", "Ibis Staff"],
    powers: ["Akashic Access", "Time Manipulation", "Language Mastery"],
  },
  {
    id: "osiris",
    name: "Osiris",
    domain: "Resurrection, Afterlife, Cycles",
    shadowCounterpart: "Set",
    geopoliticalNode: "Duat / Underworld",
    artifacts: ["Crook and Flail", "Djed Pillar"],
    powers: ["Resurrection", "Judgment", "Vegetation Control"],
  },
  {
    id: "isis",
    name: "Isis",
    domain: "Magic, Motherhood, Healing",
    shadowCounterpart: "Lilith (borrowed)",
    geopoliticalNode: "Philae / Global Sisterhood",
    artifacts: ["Throne Headdress", "Knot of Isis"],
    powers: ["High Magic", "Resurrection Aid", "Protection Spells"],
  },
  {
    id: "horus",
    name: "Horus",
    domain: "Kingship, Sky, Vengeance",
    shadowCounterpart: "Set",
    geopoliticalNode: "All of Kemet",
    artifacts: ["Eye of Horus", "Falcon Crown"],
    powers: ["Divine Sight", "Warrior King", "Solar Flight"],
  },
  {
    id: "anubis",
    name: "Anubis",
    domain: "Death, Mummification, Transition",
    shadowCounterpart: "Ammit",
    geopoliticalNode: "Necropolis",
    artifacts: ["Jackal Mask", "Embalming Tools"],
    powers: ["Soul Guide", "Preservation", "Underworld Navigation"],
  },
]

// ============================================
// BLOODLINES
// ============================================
export interface Bloodline {
  id: string
  name: string
  origin: string
  traits: string[]
  abilities: string[]
  antagonists: string[]
  modernDescendants?: string[]
}

export const NETERU_BLOODLINES: Bloodline[] = [
  {
    id: "neteru",
    name: "NeTeRu Bloodline",
    origin: "Original divine lineage from pre-dynastic Kemet",
    traits: ["Melanin resonance", "Akashic sensitivity", "Solar alignment"],
    abilities: ["Eternal Sight", "Ancestral Memory", "Divine Communion"],
    antagonists: ["Reptilian Hunters", "Papal Inquisitors"],
    modernDescendants: ["Malachai AZain", "Califia", "Salem Seers"],
  },
  {
    id: "marzain",
    name: "Marzain",
    origin: "Lost civilization destroyed by timeline manipulation",
    traits: ["Temporal sensitivity", "589 frequency attunement", "Memory preservation"],
    abilities: ["Timeline Navigation", "Frequency Manipulation", "Ancestral Unlocking"],
    antagonists: ["Vatican Archives", "CERN Operators"],
    modernDescendants: ["The Awakened", "Frequency Seekers"],
  },
  {
    id: "atlantean",
    name: "Atlantean",
    origin: "Pre-flood advanced civilization",
    traits: ["Crystal technology affinity", "Water breathing (latent)", "Geometric vision"],
    abilities: ["Ether Tech Operation", "Sacred Geometry", "Energy Manipulation"],
    antagonists: ["Merovingian Bloodline", "Shadow Councils"],
  },
  {
    id: "seraphic",
    name: "Seraphic / Papal",
    origin: "Hybrid bloodline claiming divine right through manipulation",
    traits: ["Political cunning", "Religious authority", "Historical revision"],
    abilities: ["Narrative Control", "Institutional Power", "Timeline Editing"],
    antagonists: ["NeTeRu Bloodline", "Truth Seekers"],
  },
  {
    id: "reptilian-hunters",
    name: "Reptilian Hunters",
    origin: "Ancient predator class that infiltrated human institutions",
    traits: ["Shapeshifting", "Cold-blooded logic", "Hierarchy obsession"],
    abilities: ["Identity Theft", "Institutional Control", "Memory Suppression"],
    antagonists: ["All awakened bloodlines"],
  },
]

// ============================================
// STORY ARCS
// ============================================
export interface StoryArc {
  id: string
  title: string
  status: "complete" | "in-progress" | "planned"
  chapters: number
  synopsis: string
  primaryCharacters: string[]
  themes: string[]
  timelineEra: string
}

export const NETERU_ARCS: StoryArc[] = [
  {
    id: "eternal-sight",
    title: "The Eternal Sight",
    status: "in-progress",
    chapters: 12,
    synopsis:
      "Malachai AZain discovers his latent Neteru abilities after a near-death experience reveals the hidden history of his bloodline.",
    primaryCharacters: ["Malachai AZain", "Sekhmet (guide)", "The Watcher"],
    themes: ["Awakening", "Hidden History", "Ancestral Power"],
    timelineEra: "Present Day",
  },
  {
    id: "nilotic-marzain",
    title: "Nilotic & Marzain",
    status: "in-progress",
    chapters: 8,
    synopsis:
      "The destruction of Marzain civilization and its connection to the Nile Delta mysteries. How timeline manipulation erased an entire people.",
    primaryCharacters: ["The Archivist", "Kalifia", "Darius Thrane"],
    themes: ["Lost Civilizations", "Timeline Warfare", "Cultural Erasure"],
    timelineEra: "Ancient / Multi-temporal",
  },
  {
    id: "33-thomas-street",
    title: "33 Thomas Street",
    status: "planned",
    chapters: 6,
    synopsis:
      "The windowless tower in Manhattan serves as a nexus for surveillance, frequency manipulation, and interdimensional communication.",
    primaryCharacters: ["Agent Null", "The Frequency Thief", "Director Vance"],
    themes: ["Surveillance State", "Hidden Technology", "Urban Occultism"],
    timelineEra: "Present Day",
  },
  {
    id: "salem-seers",
    title: "Salem Seers",
    status: "planned",
    chapters: 5,
    synopsis:
      "The true history of the Salem witch trials: a coordinated attack on seer bloodlines by reptilian-infiltrated colonial authorities.",
    primaryCharacters: ["Rebecca Nurse", "The Silent Coven", "Cotton Mather (antagonist)"],
    themes: ["Historical Revision", "Seer Persecution", "Colonial Conspiracy"],
    timelineEra: "1692 Salem / Present echoes",
  },
  {
    id: "na-geometry",
    title: "NA Geometry Arc",
    status: "in-progress",
    chapters: 7,
    synopsis:
      "The sacred geometry underlying Neteru Apinaya reality. The 589 grid, sigil systems, and the mathematical language of creation.",
    primaryCharacters: ["Thoth (guide)", "The Geometer", "Pythagorean Remnants"],
    themes: ["Sacred Geometry", "Reality Code", "Mathematical Magic"],
    timelineEra: "Trans-temporal",
  },
]

// ============================================
// KEY CHARACTERS
// ============================================
export interface NeteruCharacter {
  id: string
  name: string
  title: string
  bloodline: string
  abilities: string[]
  role: "protagonist" | "antagonist" | "guide" | "ally" | "wildcard"
  arc: string
  description: string
}

export const NETERU_CHARACTERS: NeteruCharacter[] = [
  {
    id: "malachai-azain",
    name: "Malachai AZain",
    title: "The Awakened",
    bloodline: "neteru",
    abilities: ["Eternal Sight", "Ancestral Memory", "Frequency Sensitivity"],
    role: "protagonist",
    arc: "eternal-sight",
    description:
      "A modern man who discovers his Neteru heritage after a near-death experience unlocks the Eternal Sight, revealing the hidden war for human consciousness.",
  },
  {
    id: "califia",
    name: "Califia",
    title: "Queen of the Western Isle",
    bloodline: "neteru",
    abilities: ["Warrior Spirit", "Land Communion", "Ancestral Summoning"],
    role: "ally",
    arc: "nilotic-marzain",
    description:
      "Legendary warrior queen whose name gives California its title. Guardian of western Neteru bloodlines and keeper of coastal portals.",
  },
  {
    id: "sekhmet-guide",
    name: "Sekhmet",
    title: "The Lioness of War",
    bloodline: "divine",
    abilities: ["Solar Fury", "Protection", "Plague/Healing"],
    role: "guide",
    arc: "eternal-sight",
    description:
      "Neteru deity who serves as Malachai's primary guide, teaching him to channel his awakened powers while warning of the hunters.",
  },
  {
    id: "darius-thrane",
    name: "Darius Thrane",
    title: "The Architect",
    bloodline: "seraphic",
    abilities: ["Timeline Editing", "Ancestry Manipulation", "Institutional Control"],
    role: "antagonist",
    arc: "nilotic-marzain",
    description:
      "High-ranking operative who uses Ancestry.com as a front for bloodline surveillance and DNA manipulation, tracking awakened individuals.",
  },
  {
    id: "rominus",
    name: "Rominus",
    title: "The Watcher",
    bloodline: "atlantean",
    abilities: ["Ether Vision", "Ancient Memory", "Crystal Technology"],
    role: "wildcard",
    arc: "33-thomas-street",
    description:
      "An immortal Atlantean survivor who has observed human civilization since the flood, maintaining neutrality while gathering intelligence.",
  },
]

// ============================================
// TIMELINES
// ============================================
export interface TimelineEvent {
  id: string
  date: string
  era: "ancient" | "medieval" | "colonial" | "modern" | "future"
  title: string
  description: string
  manipulated: boolean
  trueHistory?: string
  connectedArcs: string[]
}

export const NETERU_TIMELINE: TimelineEvent[] = [
  {
    id: "marzain-destruction",
    date: "~10,500 BCE",
    era: "ancient",
    title: "Destruction of Marzain",
    description: "Official history: natural cataclysm destroyed an unknown civilization",
    manipulated: true,
    trueHistory:
      "Timeline warfare by proto-Merovingian forces using CERN-precursor technology erased Marzain from most historical records",
    connectedArcs: ["nilotic-marzain"],
  },
  {
    id: "bc-ad-split",
    date: "0 CE",
    era: "ancient",
    title: "BC/AD Calendar Fabrication",
    description: "Implementation of the Christian calendar system",
    manipulated: true,
    trueHistory:
      "The Veil of Time ritual that separated human consciousness from direct Akashic access, using the calendar as a frequency anchor",
    connectedArcs: ["eternal-sight", "na-geometry"],
  },
  {
    id: "salem-trials",
    date: "1692 CE",
    era: "colonial",
    title: "Salem Witch Trials",
    description: "Mass hysteria leading to execution of accused witches",
    manipulated: true,
    trueHistory:
      "Coordinated elimination of seer bloodlines by reptilian-infiltrated colonial authorities using manufactured hysteria",
    connectedArcs: ["salem-seers"],
  },
  {
    id: "33-thomas-construction",
    date: "1974 CE",
    era: "modern",
    title: "33 Thomas Street Construction",
    description: "AT&T Long Lines Building completed in Manhattan",
    manipulated: false,
    trueHistory:
      "Windowless tower designed as frequency nexus and interdimensional communication hub, not just telecommunications",
    connectedArcs: ["33-thomas-street"],
  },
  {
    id: "cern-activation",
    date: "2008 CE",
    era: "modern",
    title: "CERN LHC Activation",
    description: "Large Hadron Collider begins operations",
    manipulated: false,
    trueHistory: "Timeline manipulation device disguised as particle physics research, enabling subtle reality edits",
    connectedArcs: ["nilotic-marzain", "33-thomas-street"],
  },
  {
    id: "clockfall-2038",
    date: "2038-01-19",
    era: "future",
    title: "The Clockfall",
    description: "Unix timestamp overflow event",
    manipulated: false,
    trueHistory:
      "The moment time fractures into triadic sequence, 589 portals open, and the Veil of Time weakens permanently",
    connectedArcs: ["eternal-sight", "na-geometry", "33-thomas-street"],
  },
]

// ============================================
// AKASHIC MECHANICS
// ============================================
export interface AkashicMechanic {
  id: string
  name: string
  description: string
  requirements: string[]
  effects: string[]
}

export const AKASHIC_MECHANICS: AkashicMechanic[] = [
  {
    id: "eternal-sight",
    name: "Eternal Sight",
    description:
      "The ability to perceive Akashic records and hidden realities, typically unlocked through near-death experience or bloodline awakening",
    requirements: ["Neteru bloodline (active)", "Trauma trigger or ritual initiation", "589 frequency exposure"],
    effects: ["See through illusions", "Access ancestral memories", "Perceive timeline manipulations"],
  },
  {
    id: "veil-of-time",
    name: "Veil of Time",
    description:
      "The artificial barrier separating human consciousness from direct Akashic access, maintained through calendar systems and frequency suppression",
    requirements: ["Institutional power", "Calendar control", "Frequency towers (modern)"],
    effects: ["Mass amnesia", "Historical revision acceptance", "Spiritual disconnection"],
  },
  {
    id: "589-frequency",
    name: "589 Frequency",
    description: "The stabilizing harmonic that can pierce the Veil of Time and enable portal activation",
    requirements: ["Knowledge of the sequence", "Proper geometric alignment", "Bloodline attunement"],
    effects: ["Portal opening", "Timeline stabilization", "Veil weakening"],
  },
  {
    id: "ancestral-unlocking",
    name: "Ancestral Unlocking",
    description:
      "The process of awakening dormant bloodline abilities through DNA activation, often triggered by specific frequencies or trauma",
    requirements: ["Dormant bloodline markers", "Activation trigger", "Guide or self-discovery"],
    effects: ["Ability manifestation", "Memory recovery", "Physical enhancement"],
  },
]

// ============================================
// ARTIFACTS
// ============================================
export interface NeteruArtifact {
  id: string
  name: string
  origin: string
  currentLocation: string
  powers: string[]
  connectedTo: string[]
}

export const NETERU_ARTIFACTS: NeteruArtifact[] = [
  {
    id: "emerald-tablets",
    name: "Emerald Tablets of Thoth",
    origin: "Atlantis / Pre-flood",
    currentLocation: "Scattered / Akashic Library",
    powers: ["Complete Akashic access", "Reality code manipulation", "Immortality secrets"],
    connectedTo: ["thoth", "na-geometry"],
  },
  {
    id: "papal-bulls",
    name: "Doctrine of Discovery Bulls",
    origin: "Vatican 1452-1493",
    currentLocation: "Vatican Archives",
    powers: ["Legal fiction of ownership", "Indigenous dispossession", "Spiritual jurisdiction claims"],
    connectedTo: ["seraphic", "salem-seers"],
  },
  {
    id: "tesla-coil-original",
    name: "Tesla's Original Coil",
    origin: "Wardenclyffe 1901",
    currentLocation: "33 Thomas Street (rumored)",
    powers: ["Free energy transmission", "Frequency manipulation", "Interdimensional communication"],
    connectedTo: ["33-thomas-street", "589-frequency"],
  },
  {
    id: "ankh-of-dissolution",
    name: "Ankh of Dissolution",
    origin: "Temple of Nebwet",
    currentLocation: "Unknown / Void dimension",
    powers: ["Matter dissolution", "Shadow walking", "Death transition"],
    connectedTo: ["nebwet", "eternal-sight"],
  },
]

// ============================================
// ENGINE CONFIGURATION
// ============================================
export interface NeteruEngine {
  id: string
  name: string
  description: string
  inputs: string[]
  outputs: string[]
  connectedPatches: string[]
}

export const NETERU_ENGINES: NeteruEngine[] = [
  {
    id: "story-engine",
    name: "Story Engine",
    description: "Generate → Expand → Visualize → Animate → Publish pipeline",
    inputs: ["prompts", "arc_ids", "character_ids"],
    outputs: ["chapters", "scenes", "scripts", "storyboards"],
    connectedPatches: ["creator-codex", "789-studios"],
  },
  {
    id: "bloodline-engine",
    name: "Bloodline Engine",
    description: "Tracks DNA markers, seer activation, and ancestry manipulation",
    inputs: ["character_data", "bloodline_markers", "activation_events"],
    outputs: ["character_flags", "quest_hooks", "arg_eligibility", "nft_traits"],
    connectedPatches: ["arg-system", "vrg33589"],
  },
  {
    id: "pantheon-engine",
    name: "Pantheon Engine",
    description: "Maps pantheons, shadow counterparts, and geopolitical nodes",
    inputs: ["deity_data", "faction_alignments", "ritual_requests"],
    outputs: ["boss_designs", "faction_designs", "ritual_scenes", "power_systems"],
    connectedPatches: ["npc", "789-studios"],
  },
  {
    id: "timeline-engine",
    name: "Timeline Engine",
    description: "Manages BC/AD fabrication, CERN edits, and timeline branches",
    inputs: ["historical_events", "manipulation_data", "branch_requests"],
    outputs: ["branching_timelines", "flashback_episodes", "time_locked_content"],
    connectedPatches: ["arg-system", "589-magazine"],
  },
  {
    id: "arg-engine",
    name: "ARG Engine",
    description: "Defines missions, clue chains, and real-world artifact paths",
    inputs: ["mission_templates", "location_data", "qr_nfc_configs"],
    outputs: ["missions", "clue_chains", "artifact_paths", "operation_modules"],
    connectedPatches: ["vrg33589", "fen", "npc"],
  },
  {
    id: "geometry-engine",
    name: "Geometry Engine",
    description: "Sacred geometry, 589 grid, sigils, and mathematical magic",
    inputs: ["geometric_patterns", "sigil_requests", "grid_coordinates"],
    outputs: ["card_layouts", "tarot_visuals", "map_overlays", "vault_keys"],
    connectedPatches: ["589-magazine", "vault33"],
  },
]
