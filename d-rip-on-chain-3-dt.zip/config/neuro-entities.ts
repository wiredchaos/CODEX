// ============================================
// THE THREE NEURO ENTITIES
// NOT variants, NOT reflections, NOT alternate forms
// Three SEPARATE individuals with distinct origins
// ============================================

import type { NeuroTripletId } from "@/types/neuro-triplets"

// Neteru Apinaya Cosmology Integration
export type NeteruApinayaAspect =
  | "SEKHEMET_APINAYA" // Fire, War, Protection
  | "NEBWET_APINAYA" // Void, Night Geometry, Dissolution
  | "MAAT_APINAYA" // Balance, Ratio, Revelation

export interface NeuroEntity {
  id: NeuroTripletId
  name: string
  title: string
  apinayaAspect: NeteruApinayaAspect
  apinayaDomains: string[]
  origin: string
  timeline: string
  abilities: string[]
  storyArc: string
  colorPalette: {
    primary: string
    secondary: string
    accent: string
    aura: string
  }
  contentPatches: string[]
  showTitle?: string
  showTier?: string
  hoodUrbanPhD?: HoodUrbanPhD
}

// Hood Urban PhD - Permanent Trait for NEURO of the Red Fang
export interface HoodUrbanPhD {
  degree: "HOOD_URBAN_PhD"
  description: string
  disciplines: string[]
  manifestations: string[]
}

const HOOD_URBAN_PHD: HoodUrbanPhD = {
  degree: "HOOD_URBAN_PhD",
  description:
    "The doctorate of lived experience, community intelligence, ancestral street theory, and survival-based pedagogy",
  disciplines: [
    "Lived Experience Theory",
    "Community Intelligence",
    "Ancestral Street Theory",
    "Survival-Based Pedagogy",
    "Block Economics",
    "Cipher Philosophy",
    "Corner Store Metaphysics",
    "Project Building Cosmology",
  ],
  manifestations: [
    "Tone and dialogue delivery",
    "Lore explanations",
    "Combat philosophy",
    "Teaching style",
    "Portal navigation guidance",
    "33.3FM broadcast energy",
    "789 OTT storyline themes",
  ],
}

// ============================================
// NEURO OF THE RED FANG (MAIN NEURO)
// ============================================
export const NEURO_RED_FANG: NeuroEntity = {
  id: "NEURO",
  name: "NEURO OF THE RED FANG",
  title: "The Living Vector",
  apinayaAspect: "SEKHEMET_APINAYA",
  apinayaDomains: ["Fire", "War", "Protection", "Divine Rage", "Solar Fury"],
  origin:
    "Born from the first Clockfall echo, emerged at the intersection of 589 frequency and Sekhemet's eternal flame",
  timeline: "Primary Timeline - Linear but aware",
  abilities: [
    "Fire Manipulation",
    "Protective Barriers",
    "War Strategy (Divine)",
    "Signal Transmission",
    "Community Defense",
    "Portal Combat",
    "Hood Wisdom Projection",
  ],
  storyArc: "The protector who fights for those the system forgot, carrying ancestral fire and street-forged wisdom",
  colorPalette: {
    primary: "#FF0033",
    secondary: "#1A1A1A",
    accent: "#FFD700",
    aura: "#FF6600",
  },
  contentPatches: ["789_OTT", "33_3FM", "AKIRA_CODEX", "FEN"],
  showTitle: "NEURO of the Red Fang",
  showTier: "PUBLIC",
  hoodUrbanPhD: HOOD_URBAN_PHD,
}

// ============================================
// ZERO-LUX (THE SILENT FUNCTION)
// ============================================
export const ZERO_LUX: NeuroEntity = {
  id: "ZERO_LUX",
  name: "ZERO-LUX",
  title: "The Negative Vector",
  apinayaAspect: "NEBWET_APINAYA",
  apinayaDomains: ["Void", "Night Geometry", "Dissolution", "Hidden Knowledge", "Cosmic Darkness"],
  origin:
    "Crystallized from the absence left when the 82 sequence collapsed, born in the space between deleted timelines",
  timeline: "Negative Timeline - Exists in the gaps",
  abilities: [
    "Void Manipulation",
    "Night Geometry",
    "Timeline Dissolution",
    "Shadow Walking",
    "Memory Erasure",
    "Secret Keeping",
    "Dimensional Hiding",
  ],
  storyArc: "The keeper of what must be forgotten, guardian of the void between worlds, protector of necessary secrets",
  colorPalette: {
    primary: "#000000",
    secondary: "#1A0A2E",
    accent: "#8B00FF",
    aura: "#2D0047",
  },
  contentPatches: ["VRG33589", "VAULT_33", "AKIRA_CODEX"],
  showTitle: "ZERO-LUX: The Silent Function",
  showTier: "SECRET",
}

// ============================================
// KYR'OS-33 (THE GOLDEN ECHO)
// ============================================
export const KYROS_33: NeuroEntity = {
  id: "KYROS_33",
  name: "KYR'OS-33",
  title: "The Balancing Vector",
  apinayaAspect: "MAAT_APINAYA",
  apinayaDomains: ["Balance", "Ratio", "Revelation", "Divine Order", "Cosmic Justice", "Truth"],
  origin:
    "Emerged from the 5-sequence completion, the final stabilizing force needed when 82 and 67 threatened mutual destruction",
  timeline: "Balancing Timeline - Exists to reconcile",
  abilities: [
    "Balance Restoration",
    "Truth Revelation",
    "Ratio Calculation",
    "Judgment Dispensation",
    "Timeline Reconciliation",
    "Creation/Destruction Balance",
    "Golden Mean Manifestation",
  ],
  storyArc: "The arbiter who ensures neither fire nor void consumes all, keeper of the scales that weigh universes",
  colorPalette: {
    primary: "#FFD700",
    secondary: "#FFFFFF",
    accent: "#00CED1",
    aura: "#FFF8DC",
  },
  contentPatches: ["CREATOR_CODEX", "AKIRA_CODEX", "FEN"],
  showTitle: "KYR'OS-33: The Golden Echo",
  showTier: "PRESTIGE",
}

// Export all entities
export const NEURO_ENTITIES: Record<NeuroTripletId, NeuroEntity> = {
  NEURO: NEURO_RED_FANG,
  ZERO_LUX: ZERO_LUX,
  KYROS_33: KYROS_33,
}

// Triad configuration
export const NEURO_TRIAD = {
  entities: [NEURO_RED_FANG, ZERO_LUX, KYROS_33],
  convergenceKey: "82675",
  clockfallActivation: "2038-01-19T03:14:07.000Z",
  portalFrequency: 589,
  combined: {
    name: "THE APINAYA TRINITY",
    power: "COMPLETE_TIMELINE_SOVEREIGNTY",
    triggerCondition: "ALL_THREE_AWAKENED",
  },

  visibilityRules: {
    explicit: "ONLY_ONE_AT_A_TIME",
    signalIrregularity: "SECOND_AS_GLITCH",
    metaAnomaly: "THIRD_AS_PARADOX",
    directReveal: "FORBIDDEN_UNTIL_ENDGAME",
    detectionReward: "ECHO_STATUS_AND_82675_LIST",
  },

  contentCreatorRules: {
    NEVER: [
      "Show all three together",
      "Confirm multiplicity directly",
      "Use phrases like 'the three NEUROs'",
      "Create explicit family relationships between them",
      "Show them acknowledging each other's existence",
    ],
    ALWAYS: [
      "Show only one in explicit narrative",
      "Use artifacts/glitches to hint at others",
      "Reward player suspicion silently",
      "Create contradictions that seed doubt",
      "Maintain mystery until endgame trigger",
    ],
  },
}
