export interface FMTrack {
  id: string
  creatorId: string
  creatorHandle: string
  title: string
  audioUrl: string
  coverArtUrl?: string
  duration: number
  genre?: string
  mintTxHash?: string
  mintChain: string
  playCount: number
  boostCount: number
  rotationWeight: number
}

export interface FMVideo {
  id: string
  creatorId: string
  creatorHandle: string
  title: string
  videoUrl: string
  thumbnailUrl?: string
  duration: number
  viewCount: number
  boostCount: number
  priority: number
}

export interface FMCreator {
  id: string
  handle: string
  displayName: string
  bio?: string
  avatarUrl?: string
  tierLevel: "free" | "pro"
  venueType: "lounge" | "concertHall" | "outdoorStage"
  productionRooms: {
    neonBooth: boolean
    beatLab: boolean
    audiobookStudio: boolean
  }
  socialLinks?: Record<string, string>
}

export interface FMShow {
  id: string
  title: string
  host: string
  schedule: string
  description: string
  type: "dj" | "creator" | "afterDark"
}

export const FM_SHOWS: FMShow[] = [
  {
    id: "red-fang",
    title: "DJ Red Fang Morning Mix",
    host: "DJ Red Fang",
    schedule: "Mon-Fri 6AM-10AM PST",
    description: "Wake up to curated chaos. Fresh tracks, hot takes, and neon vibes.",
    type: "dj",
  },
  {
    id: "creator-spotlight",
    title: "Creator Spotlight",
    host: "Rotating Hosts",
    schedule: "Daily 2PM-4PM PST",
    description: "Deep dives with 33.3FM creators. Stories, demos, and exclusive previews.",
    type: "creator",
  },
  {
    id: "after-dark",
    title: "After Dark Frequencies",
    host: "DJ Red Fang",
    schedule: "Fri-Sat 10PM-2AM PST",
    description: "Late night experimental sounds. Dark ambient, glitch, and underground.",
    type: "afterDark",
  },
]

export interface BoostType {
  id: string
  name: string
  description: string
  baseCost: number // in DOGE
  duration?: number // minutes
}

export const BOOST_TYPES: BoostType[] = [
  {
    id: "queue-jump",
    name: "Queue Jump",
    description: "Move your track to play within the next 3 songs",
    baseCost: 100,
  },
  {
    id: "top-of-hour",
    name: "Top of Hour Feature",
    description: "Your track plays at the top of the next hour with DJ intro",
    baseCost: 500,
  },
  {
    id: "video-spotlight",
    name: "Video Spotlight",
    description: "Feature your video in the Jukebox for 30 minutes",
    baseCost: 250,
    duration: 30,
  },
  {
    id: "creator-highlight",
    name: "Creator Highlight",
    description: "Full creator profile feature for 1 hour",
    baseCost: 750,
    duration: 60,
  },
  {
    id: "playlist-takeover",
    name: "Playlist Takeover",
    description: "Control the rotation for 15 minutes",
    baseCost: 1000,
    duration: 15,
  },
]

export const ACCEPTED_CHAINS = ["DOGE", "SOL", "ETH", "BTC", "HBAR", "XRP"] as const
export type AcceptedChain = (typeof ACCEPTED_CHAINS)[number]

export const MINT_FEES = {
  nonHolder: 0.05, // 5%
  nftHolder: 0.015, // 1.5%
} as const

export const TIER_LIMITS = {
  free: {
    listener: {
      ads: true,
      skipLimit: 6,
      threeDAccess: false,
    },
    creator: {
      mintFee: MINT_FEES.nonHolder,
      audiobooksPerMonth: 1,
      productionRooms: ["neonBooth"],
      venueType: "lounge",
    },
  },
  premium: {
    listener: {
      ads: false,
      skipLimit: Number.POSITIVE_INFINITY,
      threeDAccess: true,
    },
  },
  pro: {
    creator: {
      mintFee: MINT_FEES.nftHolder,
      audiobooksPerMonth: Number.POSITIVE_INFINITY,
      productionRooms: ["neonBooth", "beatLab", "audiobookStudio"],
      venueType: "all",
    },
  },
} as const
