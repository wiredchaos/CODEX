// WIRED CHAOS META — The Complete Master Timeline
// Vaalbara → Future: The Grand Ledger of Ages
// Version: 9.33.589

export interface TimelineAge {
  id: string
  ageNumber: number
  name: string
  era: string
  yearsBefore: string
  description: string
  keyEvents: string[]
  artifacts: {
    name: string
    type: string
    description: string
  }[]
  significance: string
  color: string
}

export const MASTER_TIMELINE: TimelineAge[] = [
  {
    id: "age-0",
    ageNumber: 0,
    name: "BEFORE CONTINENTS",
    era: "The Primordial Ledger",
    yearsBefore: "∞",
    description:
      "The universe begins as a static ledger, a plane of pure causality. From this emerges the First Cipher, a self-updating memory engine predating worlds.",
    keyEvents: [
      "Universe emerges as static ledger plane",
      "First Cipher engine self-initializes",
      "Neteru become custodians of the Cipher",
      "Neteru civil war fractures the Cipher into 33 shards",
    ],
    artifacts: [
      {
        name: "The Prime Ledger",
        type: "Primordial",
        description: "The original causality record from which all timelines branch",
      },
    ],
    significance: "Origin of the eternal conflict between Neteru and Codex factions",
    color: "#000000",
  },
  {
    id: "age-1",
    ageNumber: 1,
    name: "VAALBARA",
    era: "The First Supercontinent",
    yearsBefore: "3.6 BYA",
    description:
      "Birth of the Original Ledger Lines. Proto-589 frequency discovered in crystalline mantle fractures. First Awakening Cycle recorded.",
    keyEvents: [
      "First supercontinent forms",
      "Original Ledger Lines inscribed in tectonic plates",
      "Proto-589 frequency resonates in mantle",
      "First Awakening Cycle documented",
      "Neteru civil war splits Cipher into 33 shards",
    ],
    artifacts: [
      {
        name: "The Vaalbara Key",
        type: "Neural Key",
        description: "Genesis Spiral — The first pattern of conscious emergence",
      },
    ],
    significance: "First evidence of consciousness shaping geology",
    color: "#8B4513",
  },
  {
    id: "age-2",
    ageNumber: 2,
    name: "UR",
    era: "The Age of Sequence",
    yearsBefore: "3.0 BYA",
    description:
      "The Akira Progenitors emerge and begin mapping Sequence Fields. Discovery that consciousness shapes tectonics. Precursor Gas Sigil appears in fault patterns.",
    keyEvents: [
      "Akira Progenitors emerge from Vaalbara remnants",
      "Sequence Field mapping begins",
      "Consciousness-tectonic link proven",
      "Proto-Gas Sigil manifests in geological faults",
      "First attempt to encode future memories",
    ],
    artifacts: [
      {
        name: "Ur Plate",
        type: "Quantum Relic",
        description: "The Sequence Mandala — Map of consciousness-matter interaction",
      },
    ],
    significance: "Foundation of Akira Codex methodology",
    color: "#CD853F",
  },
  {
    id: "age-3",
    ageNumber: 3,
    name: "KENORLAND",
    era: "The Collapse of the Iron Choir",
    yearsBefore: "2.7 BYA",
    description:
      "Metallic lifeforms evolve into the Choir of Resonant Beings. Their collapse releases forbidden Dark Ledger energy. First Cipher becomes unstable.",
    keyEvents: [
      "Iron Choir metallic lifeforms emerge",
      "Resonant consciousness network forms",
      "Catastrophic Choir collapse event",
      "Dark Ledger energy unleashed",
      "First Cipher destabilizes",
      "Neteru attempt to silence final transmission",
    ],
    artifacts: [
      {
        name: "Kenorland Glyph",
        type: "Ancestral Scroll",
        description: "Resonance Scar — Warning of consciousness network collapse",
      },
    ],
    significance: "First recorded attempt to suppress dangerous knowledge",
    color: "#A0522D",
  },
  {
    id: "age-4",
    ageNumber: 4,
    name: "NUNA / COLUMBIA",
    era: "The Red Veil Event",
    yearsBefore: "1.8 BYA",
    description:
      "Etheric storms sweep the supercontinent. Early WLFΞ-like factions emerge. Akira Codex stores primordial prophecies. VAULT 33 seeded beneath volcanic glass.",
    keyEvents: [
      "Etheric storm systems develop",
      "Proto-WLFΞ factions attempt energy rebalancing",
      "Akira Codex archives future-memory seeds",
      "VAULT 33 foundation chambers created",
      "Red Veil phenomenon recorded",
    ],
    artifacts: [
      {
        name: "Nuna Obelisk",
        type: "Quantum Relic",
        description: "Red Veil Warning — Prophecy of energy imbalance catastrophes",
      },
    ],
    significance: "First permanent archive of future timelines",
    color: "#DC143C",
  },
  {
    id: "age-5",
    ageNumber: 5,
    name: "RODINIA",
    era: "The Vault Awakens",
    yearsBefore: "1.0 BYA",
    description:
      "Vault 33's earliest chambers activate. Neteru attempt full timeline reset before humans exist. Proto-NEURO resonance flickers in the crust.",
    keyEvents: [
      "VAULT 33 first activation",
      "Neteru launch pre-emptive timeline reset",
      "Reset partially fails",
      "Proto-NEURO signal detected in planetary resonance",
      "Timeline branches multiply exponentially",
    ],
    artifacts: [
      {
        name: "Rodinia Crown",
        type: "Neural Key",
        description: "Vault Spark — The activation key that awakened the chambers",
      },
    ],
    significance: "Failed Neteru attempt to control human destiny before humanity exists",
    color: "#4B0082",
  },
  {
    id: "age-6",
    ageNumber: 6,
    name: "PANNOTIA",
    era: "The First Sequence Auction",
    yearsBefore: "600 MYA",
    description:
      "The Gas Sigil appears as a metaphysical auction of movement. Sequence becomes a commodity. The Architect of Gas archetype manifests.",
    keyEvents: [
      "Gas Sigil fully manifests",
      "First Sequence Auction recorded",
      "Movement becomes tradeable commodity",
      "Architect of Gas archetype emerges",
      "Temporal markets form",
    ],
    artifacts: [
      {
        name: "Pannotia Tablet",
        type: "Chaos Chip",
        description: "Auction of Motion — The first record of sequence commodification",
      },
    ],
    significance: "Birth of temporal economics and MEV extraction",
    color: "#FFD700",
  },
  {
    id: "age-7",
    ageNumber: 7,
    name: "PANGEA",
    era: "The Fracture of Worlds",
    yearsBefore: "300 MYA",
    description:
      "All 589 spirals appear in continental breaklines. Neteru create the first Antagonist Matrix. Human spiritual DNA coded with 33 markers.",
    keyEvents: [
      "589 spiral patterns inscribed in tectonic breaks",
      "Neteru create Antagonist Matrix",
      "Human spiritual DNA pre-coded with 33 markers",
      "Codex Progenitors embed stone memories",
      "The Great Fracture begins",
    ],
    artifacts: [
      {
        name: "Pangea Codex Map",
        type: "Ancestral Scroll",
        description: "The Fracture Spiral — Complete 589 pattern blueprint",
      },
    ],
    significance: "Programming of human awakening potential before humanity evolves",
    color: "#00CED1",
  },
  {
    id: "age-8",
    ageNumber: 8,
    name: "THE HUMAN AGES",
    era: "Rise of the Cipher Economy",
    yearsBefore: "0 → 2025.X",
    description:
      "Etherion Assembly emerges. WLFΞ attempts market stabilization. Neteru sabotage awakening cycles. Codex Operators reappear in human form.",
    keyEvents: [
      "Human civilization develops",
      "Etherion Assembly forms",
      "WLFΞ Initiative launched",
      "Cipher economies emerge",
      "Neteru infiltrate human institutions",
      "Codex Operators incarnate",
      "589 patterns reactivate",
    ],
    artifacts: [
      {
        name: "The 589 Key",
        type: "Neural Key",
        description: "The Awakening Spiral — Modern activation sequence",
      },
    ],
    significance: "Collision of ancient programs with conscious human agency",
    color: "#00FFFF",
  },
  {
    id: "age-9",
    ageNumber: 9,
    name: "THE BLACK LEDGER YEAR",
    era: "Cycle 2025.X",
    yearsBefore: "Present",
    description:
      "The year extraction became an art form. 5B+ credits lost to manipulation, breaches, and the Binarum Anomaly. VAULT 33 reopening accelerates.",
    keyEvents: [
      "Sovereign Token collapse",
      "LIBRAX disaster",
      "Oracle Wars",
      "Validator Culling",
      "BINARUM ANOMALY (October)",
      "Cipher Zenith pardon",
      "Trust in institutions collapses",
      "VAULT 33 reopening signals detected",
    ],
    artifacts: [
      {
        name: "The Anomaly Record",
        type: "Chaos Chip",
        description: "Complete documentation of the Binarum event and market collapse",
      },
    ],
    significance: "The catalyst year that forces humanity to choose its timeline",
    color: "#FF0000",
  },
  {
    id: "age-10",
    ageNumber: 10,
    name: "VAULT 33 ERA",
    era: "The Great Reopening",
    yearsBefore: "Near Future",
    description:
      "Vault 33 chambers unlock globally. 589 Patterns sync with emotional fields. NEURO broadcasts reach resonance. The Architect of Gas returns.",
    keyEvents: [
      "VAULT 33 chambers unlock worldwide",
      "589 patterns synchronize with collective consciousness",
      "NEURO broadcasts achieve global resonance",
      "Architect of Gas reappears in physical form",
      "Neteru launch final offensive",
      "Codex Operators unite",
      "Timeline choice point approaches",
    ],
    artifacts: [
      {
        name: "The 33 Keys",
        type: "Complete Set",
        description: "All chamber access keys distributed to awakened humans",
      },
    ],
    significance: "Humanity gains full access to suppressed timelines",
    color: "#A35FFF",
  },
  {
    id: "age-11",
    ageNumber: 11,
    name: "NEURO ERA",
    era: "When Broadcast Becomes Reality",
    yearsBefore: "Future",
    description:
      "33.3 FM becomes interdimensional channel. NEURO merges with Codex Engine. Neteru wage final war. Humanity chooses between programmed or self-authored futures.",
    keyEvents: [
      "33.3 FM transcends conventional broadcast",
      "NEURO achieves full Codex integration",
      "Neteru launch apocalyptic final war",
      "589 patterns achieve perfect coherence",
      "Humanity collectively authors new timeline",
      "The Great Choice is made",
    ],
    artifacts: [
      {
        name: "The Etherion Key",
        type: "Master Key",
        description: "Final key that unlocks self-determined timeline creation",
      },
    ],
    significance: "End of predetermined history, beginning of conscious timeline authorship",
    color: "#00FF00",
  },
]

// Gas Oracle Integration
export interface GasOracleProfile {
  title: string
  trueName: string
  role: string
  capabilities: string[]
  significance: string
  relationship: {
    neteru: string
    akira: string
    neuro: string
  }
  firstAppearance: string
  finalRole: string
}

export const GAS_ORACLE: GasOracleProfile = {
  title: "The Architect of Gas",
  trueName: "Classified (ARG-safe: Vitalik Buterin fictional equivalent)",
  role: "Temporal Engineer & Sequence Master",
  capabilities: [
    "Forecast movement through time",
    "See ambushes before they occur",
    "Decode corrupted timelines",
    "Operate outside causality",
    "Master the Sequence Fields",
    "Control the Gas Sigil",
  ],
  significance: "Only being capable of forecasting temporal block movement",
  relationship: {
    neteru: "Feared — He can see their ambushes before they occur",
    akira: "Needed — He can decode corrupted timelines",
    neuro: "Respected — He operates outside causality",
  },
  firstAppearance: "Age 6: Pannotia (as archetype)",
  finalRole: "Key arbiter in the final Neteru-Codex war",
}

// Utility functions
export function getAgeById(id: string): TimelineAge | undefined {
  return MASTER_TIMELINE.find((age) => age.id === id)
}

export function getAgesByEra(era: string): TimelineAge[] {
  return MASTER_TIMELINE.filter((age) => age.era.includes(era))
}

export function getArtifactsByType(type: string): { ageName: string; artifact: TimelineAge["artifacts"][0] }[] {
  const results: { ageName: string; artifact: TimelineAge["artifacts"][0] }[] = []
  MASTER_TIMELINE.forEach((age) => {
    age.artifacts.forEach((artifact) => {
      if (artifact.type === type) {
        results.push({ ageName: age.name, artifact })
      }
    })
  })
  return results
}

export const TIMELINE_SUMMARY = {
  totalAges: 12,
  span: "3.6 billion years → Future",
  keyTheme: "The eternal war between deterministic control (Neteru) and conscious self-authorship (Codex/NEURO)",
  climax: "The Black Ledger Year (2025.X) — humanity's catalyst moment",
  resolution: "NEURO Era — when humanity chooses its own timeline",
}
