// Artifact System Types & Data

export type ArtifactType = "NeuralKey" | "QuantumRelic" | "ChaosChip" | "AncestralScroll"
export type ArtifactRarity = "Common" | "Rare" | "Epic" | "Legendary"
export type ArtifactSource = "Broadcast" | "Game" | "Quest" | "Event"

export interface Artifact {
  id: string
  name: string
  type: ArtifactType
  rarity: ArtifactRarity
  source: ArtifactSource
  description: string
  unlocks: string
  imageQuery: string
}

export const ARTIFACT_CLASSES: Record<ArtifactType, { name: string; description: string; icon: string }> = {
  NeuralKey: {
    name: "Neural Keys",
    description: "Unlock AI tools, private betas, and system access",
    icon: "🔑",
  },
  QuantumRelic: {
    name: "Quantum Relics",
    description: "XP multipliers and progression boosts",
    icon: "⚛️",
  },
  ChaosChip: {
    name: "Chaos Chips",
    description: "Merch drops, secret levels, 589 Mint Factory access",
    icon: "🎰",
  },
  AncestralScroll: {
    name: "Ancestral Scrolls",
    description: "Lore fragments, Neteru hints, Merovingian secrets",
    icon: "📜",
  },
}

export const SAMPLE_ARTIFACTS: Artifact[] = [
  {
    id: "nk-001",
    name: "Genesis Key",
    type: "NeuralKey",
    rarity: "Rare",
    source: "Quest",
    description: "The first key granted to Initiates who complete onboarding.",
    unlocks: "Basic NPC Prompt Lab access",
    imageQuery: "digital key neural network cyan glow",
  },
  {
    id: "qr-001",
    name: "Temporal Fragment",
    type: "QuantumRelic",
    rarity: "Epic",
    source: "Broadcast",
    description: "A shard of compressed time from the 82675 loop.",
    unlocks: "2x XP multiplier for 24 hours",
    imageQuery: "quantum crystal time fragment purple glow",
  },
  {
    id: "cc-001",
    name: "589 Circuit",
    type: "ChaosChip",
    rarity: "Common",
    source: "Game",
    description: "Standard currency chip from the Mint Factory.",
    unlocks: "Entry to secret merch drops",
    imageQuery: "circuit chip neon magenta futuristic",
  },
  {
    id: "as-001",
    name: "Scroll of Apinaya",
    type: "AncestralScroll",
    rarity: "Legendary",
    source: "Quest",
    description: "Ancient wisdom from the Neteru archives.",
    unlocks: "Advanced Neteru Apinaya courses",
    imageQuery: "ancient scroll glowing hieroglyphs amber light",
  },
]

export const getArtifactTypeColor = (type: ArtifactType): string => {
  switch (type) {
    case "NeuralKey":
      return "bg-cyan-500/20 text-cyan-400 border-cyan-500/30"
    case "QuantumRelic":
      return "bg-purple-500/20 text-purple-400 border-purple-500/30"
    case "ChaosChip":
      return "bg-fuchsia-500/20 text-fuchsia-400 border-fuchsia-500/30"
    case "AncestralScroll":
      return "bg-amber-500/20 text-amber-400 border-amber-500/30"
  }
}

export const getRarityColor = (rarity: ArtifactRarity): string => {
  switch (rarity) {
    case "Common":
      return "text-zinc-400"
    case "Rare":
      return "text-blue-400"
    case "Epic":
      return "text-purple-400"
    case "Legendary":
      return "text-amber-400"
  }
}
