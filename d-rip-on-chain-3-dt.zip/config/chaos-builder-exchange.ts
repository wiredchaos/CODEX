// CHAOS BUILDER EXCHANGE (CBE) - Configuration
// Entrepreneur-to-Entrepreneur Marketplace for Bridging, Building, and Scaling

export const CBE_CONFIG = {
  name: "Chaos Builder Exchange",
  slug: "chaos-builder-exchange",
  tagline: "Where Builders Bridge Opportunity.",
  description:
    "A high-assurance entrepreneurial network designed for individuals who build companies, strategies, systems, brands, creative projects, and emerging technologies.",

  // Service categories
  categories: [
    { id: "ai-automation", name: "AI & Automation", icon: "Brain" },
    { id: "web3-blockchain", name: "Web3 & Blockchain", icon: "Coins" },
    { id: "design-creative", name: "Design & Creative", icon: "Palette" },
    { id: "development", name: "Development", icon: "Code" },
    { id: "marketing", name: "Marketing & Growth", icon: "TrendingUp" },
    { id: "strategy", name: "Strategy & Consulting", icon: "Target" },
    { id: "content", name: "Content & Media", icon: "Video" },
    { id: "finance", name: "Finance & Legal", icon: "Scale" },
  ],

  // Expertise levels
  expertiseLevels: [
    { id: "emerging", name: "Emerging Builder", minProjects: 0 },
    { id: "established", name: "Established Builder", minProjects: 5 },
    { id: "expert", name: "Expert Builder", minProjects: 15 },
    { id: "master", name: "Master Builder", minProjects: 30 },
  ],

  // Trust badge types
  trustBadges: [
    { id: "verified", name: "Verified Identity", icon: "BadgeCheck" },
    { id: "top-rated", name: "Top Rated", icon: "Star" },
    { id: "fast-delivery", name: "Fast Delivery", icon: "Zap" },
    { id: "repeat-clients", name: "Repeat Clients", icon: "Users" },
    { id: "neuro-certified", name: "NEURO Certified", icon: "Award" },
  ],

  // Pricing tiers
  pricingTiers: [
    { id: "starter", name: "Starter", range: "$100 - $500" },
    { id: "professional", name: "Professional", range: "$500 - $2,500" },
    { id: "enterprise", name: "Enterprise", range: "$2,500 - $10,000" },
    { id: "concierge", name: "Concierge", range: "$10,000+" },
  ],

  // Opportunity types
  opportunityTypes: [
    { id: "gig", name: "One-Time Gig" },
    { id: "partnership", name: "Partnership" },
    { id: "collaboration", name: "Collaboration" },
    { id: "retainer", name: "Retainer" },
    { id: "equity", name: "Equity Opportunity" },
  ],
}

// Types for CBE
export interface BuilderProfile {
  id: string
  userId: string
  displayName: string
  headline: string
  bio: string
  avatarUrl?: string
  bannerUrl?: string
  categories: string[]
  skills: string[]
  industries: string[]
  expertiseLevel: string
  hourlyRate?: number
  portfolioItems: PortfolioItem[]
  socialLinks: SocialLinks
  trustBadges: string[]
  rating: number
  reviewCount: number
  completedProjects: number
  responseTime: string
  isVerified: boolean
  isConcierge: boolean
  createdAt: Date
  updatedAt: Date
}

export interface PortfolioItem {
  id: string
  title: string
  description: string
  imageUrl?: string
  videoUrl?: string
  linkUrl?: string
  category: string
  tags: string[]
}

export interface SocialLinks {
  twitter?: string
  linkedin?: string
  github?: string
  website?: string
  discord?: string
}

export interface ServiceListing {
  id: string
  builderId: string
  title: string
  description: string
  category: string
  subcategory?: string
  deliverables: string[]
  pricingTier: string
  basePrice: number
  timeline: string
  revisions: number
  tags: string[]
  imageUrl?: string
  isFeatured: boolean
  isActive: boolean
  orderCount: number
  rating: number
  reviewCount: number
  createdAt: Date
  updatedAt: Date
}

export interface Opportunity {
  id: string
  posterId: string
  title: string
  description: string
  type: string
  category: string
  budget?: string
  timeline?: string
  requirements: string[]
  preferredSkills: string[]
  isRemote: boolean
  location?: string
  applicationCount: number
  status: "open" | "in-progress" | "closed"
  createdAt: Date
  updatedAt: Date
  expiresAt?: Date
}

export interface Review {
  id: string
  reviewerId: string
  revieweeId: string
  listingId?: string
  opportunityId?: string
  rating: number
  comment: string
  tags: string[]
  createdAt: Date
}

export interface Booking {
  id: string
  clientId: string
  builderId: string
  listingId?: string
  opportunityId?: string
  status: "pending" | "accepted" | "in-progress" | "completed" | "cancelled"
  totalPrice: number
  milestones: Milestone[]
  messages: Message[]
  createdAt: Date
  updatedAt: Date
}

export interface Milestone {
  id: string
  title: string
  description: string
  dueDate: Date
  price: number
  status: "pending" | "in-progress" | "completed"
}

export interface Message {
  id: string
  senderId: string
  content: string
  attachments?: string[]
  createdAt: Date
}

// Mock data for demo
export const MOCK_BUILDERS: BuilderProfile[] = [
  {
    id: "builder-1",
    userId: "user-1",
    displayName: "NEURO META X",
    headline: "AI Strategy Architect & Transmedia Producer",
    bio: "Creator of WIRED CHAOS META. Specializing in AI-powered storytelling, transmedia production, and founder strategy. Hood Urban PhD certified.",
    avatarUrl: "/neuro-profile-picture-red-theme.jpg",
    categories: ["ai-automation", "strategy", "content"],
    skills: ["AI Strategy", "Transmedia", "World-Building", "Prompt Engineering", "Creator Economy"],
    industries: ["Entertainment", "Tech", "Web3"],
    expertiseLevel: "master",
    hourlyRate: 500,
    portfolioItems: [
      {
        id: "p1",
        title: "WIRED CHAOS META",
        description: "Full transmedia universe with AI, ARG, and entertainment layers",
        category: "ai-automation",
        tags: ["AI", "Transmedia", "Universe Building"],
      },
    ],
    socialLinks: { twitter: "@neurometa", website: "wiredchaos.meta" },
    trustBadges: ["verified", "top-rated", "neuro-certified"],
    rating: 5.0,
    reviewCount: 47,
    completedProjects: 89,
    responseTime: "< 1 hour",
    isVerified: true,
    isConcierge: true,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: "builder-2",
    userId: "user-2",
    displayName: "CryptoForge Labs",
    headline: "Web3 Development & Smart Contract Auditing",
    bio: "Full-stack Web3 development team specializing in DeFi, NFTs, and cross-chain solutions. 50+ projects deployed across 8 chains.",
    avatarUrl: "/crypto-developer-avatar.png",
    categories: ["web3-blockchain", "development"],
    skills: ["Solidity", "Rust", "Smart Contracts", "DeFi", "NFT Infrastructure"],
    industries: ["DeFi", "Gaming", "Finance"],
    expertiseLevel: "expert",
    hourlyRate: 250,
    portfolioItems: [],
    socialLinks: { twitter: "@cryptoforge", github: "cryptoforge-labs" },
    trustBadges: ["verified", "fast-delivery", "repeat-clients"],
    rating: 4.9,
    reviewCount: 124,
    completedProjects: 156,
    responseTime: "< 2 hours",
    isVerified: true,
    isConcierge: false,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: "builder-3",
    userId: "user-3",
    displayName: "Brand Velocity Studio",
    headline: "Growth Marketing & Brand Strategy",
    bio: "We help founders 10x their reach. Specializing in viral content, community building, and conversion optimization.",
    avatarUrl: "/marketing-agency-avatar.jpg",
    categories: ["marketing", "design-creative"],
    skills: ["Growth Hacking", "Brand Strategy", "Content Marketing", "Community Building", "Paid Ads"],
    industries: ["SaaS", "Consumer", "Web3"],
    expertiseLevel: "expert",
    hourlyRate: 175,
    portfolioItems: [],
    socialLinks: { twitter: "@brandvelocity", linkedin: "brandvelocity" },
    trustBadges: ["verified", "top-rated"],
    rating: 4.8,
    reviewCount: 89,
    completedProjects: 112,
    responseTime: "< 4 hours",
    isVerified: true,
    isConcierge: false,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
]

export const MOCK_LISTINGS: ServiceListing[] = [
  {
    id: "listing-1",
    builderId: "builder-1",
    title: "NEURO META X Couture Prompting Session",
    description:
      "One-on-one strategy session to architect your AI-powered business or creative project. Includes custom prompt templates and implementation roadmap.",
    category: "ai-automation",
    deliverables: ["90-min strategy call", "Custom prompt library", "Implementation guide", "30-day follow-up"],
    pricingTier: "enterprise",
    basePrice: 2500,
    timeline: "1 week",
    revisions: 2,
    tags: ["AI Strategy", "Prompt Engineering", "Business"],
    isFeatured: true,
    isActive: true,
    orderCount: 34,
    rating: 5.0,
    reviewCount: 28,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: "listing-2",
    builderId: "builder-2",
    title: "Smart Contract Development & Audit",
    description:
      "End-to-end smart contract development with comprehensive security audit. Supports EVM chains, Solana, and more.",
    category: "web3-blockchain",
    deliverables: ["Smart contract code", "Security audit report", "Gas optimization", "Deployment support"],
    pricingTier: "enterprise",
    basePrice: 5000,
    timeline: "2-4 weeks",
    revisions: 3,
    tags: ["Smart Contracts", "Security", "DeFi"],
    isFeatured: true,
    isActive: true,
    orderCount: 67,
    rating: 4.9,
    reviewCount: 52,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: "listing-3",
    builderId: "builder-3",
    title: "Viral Launch Campaign Package",
    description:
      "Complete launch strategy to maximize your product debut. Includes content calendar, influencer outreach, and community activation.",
    category: "marketing",
    deliverables: ["Launch strategy doc", "30-day content calendar", "Influencer list", "Community playbook"],
    pricingTier: "professional",
    basePrice: 1500,
    timeline: "2 weeks",
    revisions: 2,
    tags: ["Launch", "Growth", "Community"],
    isFeatured: false,
    isActive: true,
    orderCount: 45,
    rating: 4.8,
    reviewCount: 38,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
]

export const MOCK_OPPORTUNITIES: Opportunity[] = [
  {
    id: "opp-1",
    posterId: "user-4",
    title: "AI Copilot for Legal Documents",
    description:
      "Looking for an AI/ML expert to build a document analysis copilot for a legal tech startup. Must have experience with LLMs and RAG systems.",
    type: "partnership",
    category: "ai-automation",
    budget: "$15,000 - $25,000",
    timeline: "3 months",
    requirements: ["Experience with LLMs", "RAG implementation", "Legal/compliance background preferred"],
    preferredSkills: ["Python", "LangChain", "Vector DBs", "NLP"],
    isRemote: true,
    applicationCount: 12,
    status: "open",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: "opp-2",
    posterId: "user-5",
    title: "NFT Marketplace UI/UX Redesign",
    description:
      "Seeking a design team to completely redesign our NFT marketplace. Looking for modern, intuitive design that sets us apart from competitors.",
    type: "gig",
    category: "design-creative",
    budget: "$8,000 - $12,000",
    timeline: "6 weeks",
    requirements: ["Strong portfolio in Web3", "Figma expertise", "Experience with marketplace UX"],
    preferredSkills: ["Figma", "UI/UX", "Web3", "Motion Design"],
    isRemote: true,
    applicationCount: 24,
    status: "open",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: "opp-3",
    posterId: "user-6",
    title: "Fractional CMO for DeFi Protocol",
    description:
      "DeFi protocol seeking experienced marketing leader for fractional CMO role. 10-15 hours/week. Equity available.",
    type: "retainer",
    category: "marketing",
    budget: "$5,000/month + equity",
    timeline: "6+ months",
    requirements: ["DeFi marketing experience", "Track record of growth", "Community building expertise"],
    preferredSkills: ["DeFi", "Community", "Growth", "Strategy"],
    isRemote: true,
    applicationCount: 8,
    status: "open",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
]
