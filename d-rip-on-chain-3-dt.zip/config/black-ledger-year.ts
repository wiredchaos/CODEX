// The Black Ledger Year — Cycle 2025.X
// Fictionalized disaster timeline for WIRED CHAOS META
// Version: 1.1 (AURON PACT Update)

export interface TimelineEvent {
  month: string
  title: string
  description: string
  losses?: string
  keyEvents: string[]
  factions: string[]
  category: "Collapse" | "Breach" | "Manipulation" | "War" | "Anomaly"
  storyHooks: string[]
}

export const BLACK_LEDGER_TIMELINE: TimelineEvent[] = [
  {
    month: "January",
    title: "The Sovereign Tokens Collapse",
    description: "The Sovereign Candidate's supporters launch two political cipher-tokens that explode then collapse.",
    losses: "73M Sovereign Credits",
    keyEvents: [
      "Political cipher-tokens launched",
      "Inner Circle Agents drain liquidity",
      "Eastern Directorate suppresses cross-border gateways",
      "Phemexium Vault breached (69M credits)",
    ],
    factions: ["auron_pact", "eastern_directorate", "undernet_syndicates"],
    category: "Collapse",
    storyHooks: [
      "Who were the Inner Circle Agents?",
      "What was the true purpose of the tokens?",
      "Where did the 69M credits go?",
    ],
  },
  {
    month: "February",
    title: "The Rise and Fall of LIBRAX",
    description: "LIBRAX social-token experiment hits 4B valuation before catastrophic supply siphons.",
    losses: "1.6B+ credits",
    keyEvents: [
      "LIBRAX reaches 4B valuation",
      "Hidden Supply Siphons activate (100M drained)",
      "Bybond Exchange suffers largest breach in history (1.5B)",
      "AI-generated identity illusions overwhelm citizens",
      "Global phishing exceeds 600M losses",
    ],
    factions: ["legacy_houses", "undernet_syndicates"],
    category: "Breach",
    storyHooks: ["What are Supply Siphons?", "Who controlled LIBRAX?", "How were identity illusions created?"],
  },
  {
    month: "March",
    title: "The Collapsing Bridges",
    description: "Political meme-tokens crumble as transit-bridges freeze and oracles are compromised.",
    losses: "70M+ credits",
    keyEvents: [
      "Political meme-tokens implode",
      "Impersonator Cells drain millions",
      "UPC-X Bridge fractured (70M lost)",
      "Multiple transit-bridges freeze",
      "Oracles compromised by false time-stamps",
    ],
    factions: ["undernet_syndicates", "etherion_assembly"],
    category: "Manipulation",
    storyHooks: ["What are transit-bridges?", "Who controls the Oracles?", "Where are the Impersonator Cells based?"],
  },
  {
    month: "April",
    title: "The Great Solara Purge",
    description: "Thousands of micro-tokens on Solara Chainworks disappear overnight in coordinated purge.",
    losses: "500M+ credits",
    keyEvents: [
      "Mass token disappearances on Solara",
      "Celebrity puppet-operator Shade Harrow exposed",
      "Fake audits and AI-written manifestos revealed",
      "Mantra Consortium collapses",
      "Directorate expands Data Censorship Protocol",
    ],
    factions: ["eastern_directorate", "undernet_syndicates"],
    category: "Collapse",
    storyHooks: ["Who is Shade Harrow?", "What is the Mantra Consortium?", "How does Data Censorship work?"],
  },
  {
    month: "May",
    title: "The Oracle Wars",
    description: "DeFi infrastructure spirals as manipulated Oracles send false signals across multiple chains.",
    losses: "40M+ credits",
    keyEvents: [
      "Solara presale freefall",
      "Cross-transit ruptures on multiple chains",
      "GMX Protocol drained (40M)",
      "Coinhold Gatehouse breached by social engineering",
      "The Auron Pact launches token, immediately destabilizes",
    ],
    factions: ["auron_pact", "etherion_assembly", "undernet_syndicates"],
    category: "War",
    storyHooks: [
      "What ignited the Oracle Wars?",
      "Why did the Auron Pact destabilize immediately?",
      "Who regulates the GMX Protocol breach vector?",
    ],
  },
  {
    month: "June",
    title: "The Validator Culling",
    description: "Smaller Layer-1 chains suffer validator wipeouts as stablecoins permanently lose peg.",
    losses: "90M+ credits",
    keyEvents: [
      "Mass validator elimination on small chains",
      "Anchor Tokens permanently lose peg",
      "Nobitexium breach (90M lost)",
      "AI-powered hacks increase 1000%",
      "Half-year losses exceed 2.1B",
    ],
    factions: ["legacy_houses", "undernet_syndicates"],
    category: "Collapse",
    storyHooks: ["What are validators?", "Why did Anchor Tokens fail?", "How did AI hacks multiply?"],
  },
  {
    month: "July",
    title: "The Endless Drain",
    description: "Daily protocol siphonings continue as fake presale factories dominate all major chains.",
    losses: "2.37B total exploits",
    keyEvents: [
      "Continuous daily protocol drains",
      "Fake presale factories mimic entire UIs",
      "SlowMist Guild reports 2.37B in exploits",
      "Global scam volume crosses 2.1B",
    ],
    factions: ["undernet_syndicates"],
    category: "Breach",
    storyHooks: ["Who is the SlowMist Guild?", "How do presale factories operate?", "Where does the drained value go?"],
  },
  {
    month: "August",
    title: "The Grand Drainage",
    description: "Wallet-drainer illusions bypass all safeguards as MEV predators exploit congested lanes.",
    losses: "783 units of PrimeCoin",
    keyEvents: [
      "Fake launchpads dominate Solara, BaseLayer, Etherion",
      "Wallet-drainer illusions bypass safeguards",
      "MEV predators (Temporal Extraction) surge",
      "783 units of PrimeCoin stolen in single attack",
    ],
    factions: ["undernet_syndicates", "etherion_assembly"],
    category: "Breach",
    storyHooks: ["What is PrimeCoin?", "How do wallet-drainers work?", "Who are the MEV predators?"],
  },
  {
    month: "September",
    title: "False Update Protocol",
    description: "Fake hardware wallets and CEX synthetic volume rituals expose systemic manipulation.",
    keyEvents: [
      "Fake hardware wallets leak seed fragments",
      "CEX Houses exposed engaging in Synthetic Volume Rituals",
      "Thousands of identities compromised",
    ],
    factions: ["legacy_houses", "undernet_syndicates"],
    category: "Manipulation",
    storyHooks: ["What are Synthetic Volume Rituals?", "How were identities stolen?", "Which CEX Houses were exposed?"],
  },
  {
    month: "October",
    title: "THE BINARUM ANOMALY",
    description:
      "Binarum's algorithm malfunctions catastrophically, causing market-wide chaos and the Sovereign pardon.",
    losses: "Multi-trillion credit wipeout",
    keyEvents: [
      "430 trading pairings corrupted",
      "103 pairs trade 30% below baseline",
      "30+ pairs trade 100%+ below baseline",
      "First Cipher collapses from 122k → 104k",
      "Sovereign Candidate pardons Cipher Zenith",
    ],
    factions: ["binarum_exchange", "auron_pact", "sovereign_candidate"],
    category: "Anomaly",
    storyHooks: [
      "What caused the Anomaly?",
      "Why was Cipher Zenith pardoned?",
      "Where is Cipher Zenith now?",
      "KEY VAULT 33 EVENT",
    ],
  },
  {
    month: "November",
    title: "The Crumbling Market",
    description: "Institutional cartels exposed as second wave of political tokens implode.",
    losses: "1T credits wiped",
    keyEvents: [
      "Institutional volume manipulation exposed",
      "Second wave of political tokens implode",
      "Small Anchor Tokens destabilize",
      "1T credits wiped from market",
      "First Cipher drops 30% from yearly high",
    ],
    factions: ["legacy_houses", "sovereign_candidate"],
    category: "Collapse",
    storyHooks: ["Which institutions were caught?", "What were the political tokens?", "How did retail respond?"],
  },
  {
    month: "December",
    title: "The Year Ends in Ruin",
    description: "Trust in Central Houses reaches historic low as validator grids fail across three continents.",
    keyEvents: [
      "Central Houses trust at historic low",
      "Validator grids fail (3 continents)",
      "Offshore liquidity evaporates",
      "Yearnforge Protocol collapses",
      "Cloud mining illusions trap thousands",
    ],
    factions: ["legacy_houses", "eastern_directorate", "etherion_assembly"],
    category: "Collapse",
    storyHooks: ["What happens next?", "Who will restore trust?", "Is Cycle 2026.X any different?"],
  },
]

export const CYCLE_SUMMARY = {
  year: "Cycle 2025.X",
  title: "The Black Ledger Year",
  tagline: "It was the year extraction became an art form.",
  attribution: "— NEURO 33.3 FM",
  totalLosses: "5B+ Sovereign Credits",
  keyThemes: [
    "Political manipulation",
    "Inner Circle siphons",
    "Illusion economics",
    "False innovation",
    "Contorted ledgers",
    "Broken oracles",
  ],
  aftermath: [
    "This is why The Auron Pact forms the backbone of the coming resistance.",
    "This is why VAULT 33 awakens.",
    "This is why NEURO speaks.",
  ],
}

export function getEventsByCategory(category: TimelineEvent["category"]): TimelineEvent[] {
  return BLACK_LEDGER_TIMELINE.filter((e) => e.category === category)
}

export function getEventsByFaction(factionId: string): TimelineEvent[] {
  return BLACK_LEDGER_TIMELINE.filter((e) => e.factions.includes(factionId))
}

export function getEventByMonth(month: string): TimelineEvent | undefined {
  return BLACK_LEDGER_TIMELINE.find((e) => e.month === month)
}
