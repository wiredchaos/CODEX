// ============================================
// 589 MAGAZINE SWARM ENGINE - CONFIGURATION
// WIRED CHAOS META FORMAT - Patch Firewalled
// ============================================

import type { MagazineTheme, BillboardConfig, SwarmAgentRole } from "@/types/magazine"

// Theme definitions with signal triggers
export const MAGAZINE_THEMES: Record<
  MagazineTheme,
  {
    label: string
    signalTriggers: string[]
    loreKeywords: string[]
    colorAccent: string
  }
> = {
  "akashic-surge": {
    label: "Akashic Surge",
    signalTriggers: ["consciousness", "awakening", "frequency shift"],
    loreKeywords: ["akashic records", "soul memory", "cosmic library"],
    colorAccent: "#00FFFF",
  },
  "ledger-fracture": {
    label: "Ledger Fracture",
    signalTriggers: ["blockchain disruption", "DeFi crisis", "protocol breach"],
    loreKeywords: ["ledger mythology", "chain of custody", "digital covenant"],
    colorAccent: "#FF0040",
  },
  "589-reset": {
    label: "589 Reset",
    signalTriggers: ["XRP", "ISO 20022", "SWIFT replacement"],
    loreKeywords: ["589 prophecy", "trojan horse", "ripple effect"],
    colorAccent: "#FFD700",
  },
  "trojan-ripple-thesis": {
    label: "Trojan Ripple Thesis",
    signalTriggers: ["XRP lawsuit", "SEC", "institutional adoption"],
    loreKeywords: ["trojan theory", "hidden protocol", "sleeper activation"],
    colorAccent: "#8B00FF",
  },
  "tinfoil-confirmation-event": {
    label: "Tinfoil Confirmation Event",
    signalTriggers: ["conspiracy confirmed", "disclosure", "truth revealed"],
    loreKeywords: ["tinfoil archives", "pattern recognition", "signal noise"],
    colorAccent: "#C0C0C0",
  },
  "wlfi-sector-shift": {
    label: "WLFI Sector Shift",
    signalTriggers: ["World Liberty", "Trump crypto", "political finance"],
    loreKeywords: ["WLFI prophecy", "political ledger", "power transfer"],
    colorAccent: "#FF6600",
  },
  "timeline-collision": {
    label: "Timeline Collision",
    signalTriggers: ["multiverse", "quantum event", "reality shift"],
    loreKeywords: ["timeline convergence", "parallel threads", "temporal anchor"],
    colorAccent: "#00FF88",
  },
  "frequency-breach": {
    label: "Frequency Breach",
    signalTriggers: ["signal detected", "broadcast anomaly", "wave interference"],
    loreKeywords: ["33.3 FM", "frequency lock", "carrier wave"],
    colorAccent: "#FF00FF",
  },
}

// Billboard rendering standards
export const BILLBOARD_CONFIG: BillboardConfig = {
  resolution: "4096x2160",
  aspectRatio: "16:9",
  perspectiveTilt: 27.5, // Sweet spot between 22-33
  lighting: "neon-cyan-rim",
  watermark: "@neurometax",
  glowPulse: true,
  rotateOnInteract: true,
}

// Swarm agent definitions
export const SWARM_AGENTS: Record<
  SwarmAgentRole,
  {
    name: string
    function: string
    dependencies: SwarmAgentRole[]
  }
> = {
  artist: {
    name: "Swarm Artist",
    function: "Layout, typography, neon motherboard overlays",
    dependencies: [],
  },
  archivist: {
    name: "Swarm Archivist",
    function: "Pulls lore attachments (Vault33 → Akira → WLFI → XRPL theory)",
    dependencies: [],
  },
  composer: {
    name: "Swarm Composer",
    function: "Integrates LORE + NEWS layers",
    dependencies: ["artist", "archivist"],
  },
  fabricator: {
    name: "Swarm Fabricator",
    function: "Builds 4K PNG + 3D billboard frame",
    dependencies: ["composer"],
  },
  deployer: {
    name: "Swarm Deployer",
    function: "Sends billboard into 3D environment",
    dependencies: ["fabricator"],
  },
}

// Deployment targets for 3D environments
export const DEPLOYMENT_TARGETS = [
  {
    id: "gate-33-3",
    name: "Gate 33.3 Boards",
    environment: "gate-33-3-plaza",
  },
  {
    id: "vrg33589",
    name: "VRG33589 Dimension Walls",
    environment: "vrg33589-core",
  },
  {
    id: "vault33",
    name: "Vault 33 Landing Atrium",
    environment: "vault33-entrance",
  },
  {
    id: "chaos-os-dashboard",
    name: "CHAOS OS Dashboard Panels",
    environment: "chaos-os-main",
  },
]

// Color palette for covers
export const COVER_PALETTE = {
  primary: {
    cyan: "#00FFFF",
    red: "#FF0040",
    black: "#0A0A0A",
    white: "#F0F0F0",
  },
  accents: {
    neonPink: "#FF00FF",
    electricBlue: "#0066FF",
    acidGreen: "#00FF88",
    warningOrange: "#FF6600",
    gold589: "#FFD700",
  },
  shadows: {
    deepVoid: "#000000",
    midShadow: "#1A1A2E",
    softShadow: "#2D2D44",
  },
}

// 589 Sigil watermark configuration
export const SIGIL_CONFIG = {
  opacity: 0.15,
  position: "bottom-right",
  scale: 0.25,
  glow: true,
  glowColor: "#FFD700",
  glowRadius: 8,
}
