export type DesignMode = "akashic" | "corporate"

// Routes that trigger AKASHIC (RUPTURE cinematic) mode
export const AKASHIC_ROUTES = [
  "/akira",
  "/vault33",
  "/vrg33589",
  "/neteru",
  "/lpr589",
  "/artifact-hunt",
  "/broadcast",
  "/motherboard", // Added motherboard route
  "/rogue-frequency/vault-33",
  "/rogue-frequency/cipher-engine",
  "/rogue-frequency/lore-drops",
  "/rogue-frequency/puzzle-chamber",
  "/university",
]

// Routes that trigger LITE CORPORATE mode
export const CORPORATE_ROUTES = ["/", "/business", "/education", "/patches", "/789-studios", "/npc", "/rogue-frequency"]

export const AKASHIC_KEYWORDS = [
  "narrative",
  "lore",
  "story",
  "film3",
  "cinematic",
  "codex",
  "vault",
  "cipher",
  "chapter",
  "act",
  "docudrama",
]

export const CORPORATE_KEYWORDS = [
  "business",
  "dashboard",
  "tax",
  "trust",
  "infrastructure",
  "workflow",
  "professional",
  "tools",
  "operational",
]

export function detectMode(pathname: string): DesignMode {
  // Check exact route matches first
  if (AKASHIC_ROUTES.some((route) => pathname.startsWith(route))) {
    return "akashic"
  }

  if (CORPORATE_ROUTES.some((route) => pathname === route || pathname.startsWith(route + "/"))) {
    return "corporate"
  }

  // Default to corporate for unknown routes
  return "corporate"
}

export function getModeConfig(mode: DesignMode) {
  if (mode === "akashic") {
    return {
      name: "AKASHIC",
      theme: "rupture",
      colors: {
        primary: "#00FFFF",
        accent: "#FF3131",
        background: "#000000",
      },
      typography: {
        headline: "cinematic-extended",
        body: "monospace",
      },
      effects: ["scanlines", "film-grain", "glitch"],
      uxPatterns: {
        layout: "centered film-frame, wide aspect (21:9)",
        navigation: "left vertical data-rail with blinking node icons",
        scroll: "parallax with glitch-reveal sections",
        cursor: "cyan crosshair / flicker effect",
        sound: "low hum + static fade (toggleable)",
        transitions: "CRT blink / color separation",
      },
      copyTone: {
        buttons: ["ENTER MEMORY", "EXECUTE PATCH", "SCAN TIMELINE"],
        style: "terminal verbs, dramatic",
      },
    }
  }

  return {
    name: "LITE",
    theme: "corporate",
    colors: {
      primary: "#00FFFF",
      accent: "#A35FFF",
      background: "#0B0E11",
    },
    typography: {
      headline: "sans-serif",
      body: "sans-serif",
    },
    effects: [],
    uxPatterns: {
      layout: "standard container, 12-col responsive",
      navigation: "fixed top bar",
      scroll: "smooth native scroll",
      cursor: "default pointer",
      sound: "none",
      transitions: "fade / slide",
    },
    copyTone: {
      buttons: ["Get Started", "Learn More", "View Details"],
      style: "clear, structured, strategic",
    },
  }
}
