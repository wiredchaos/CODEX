// ============================================
// NEURO TRIPLETS VISIBILITY PROTOCOL
// CRITICAL: THREE exist, ZERO are confirmed
// ============================================

export type VisibilityMode = "EXPLICIT" | "SIGNAL_IRREGULARITY" | "META_AUTHORIAL_ANOMALY"

export interface VisibilityRule {
  mode: VisibilityMode
  description: string
  allowedContexts: string[]
  detectableBy: string[]
  revealLevel: "FORBIDDEN" | "HINTED" | "MECHANIC" | "ENDGAME"
}

export const VISIBILITY_PROTOCOL: Record<VisibilityMode, VisibilityRule> = {
  EXPLICIT: {
    mode: "EXPLICIT",
    description: "Only ONE NEURO may appear in explicit narrative at a time",
    allowedContexts: ["789_OTT", "33_3FM", "AKIRA_CODEX", "PUBLIC_INTERFACE"],
    detectableBy: ["ALL_PLAYERS"],
    revealLevel: "FORBIDDEN",
  },
  SIGNAL_IRREGULARITY: {
    mode: "SIGNAL_IRREGULARITY",
    description: "A second NEURO may appear as a signal irregularity",
    allowedContexts: ["VRG33589", "VAULT_33", "ARG_MISSIONS", "GLITCH_EVENTS"],
    detectableBy: ["ECHO_TIER_1", "ECHO_PRIME"],
    revealLevel: "HINTED",
  },
  META_AUTHORIAL_ANOMALY: {
    mode: "META_AUTHORIAL_ANOMALY",
    description: "A third NEURO may only appear as a meta-authorial anomaly",
    allowedContexts: ["CREATOR_CODEX", "FEN_DEEP_LAYER", "PORTAL_EVENTS"],
    detectableBy: ["ECHO_PRIME"],
    revealLevel: "MECHANIC",
  },
}

export interface MultplicityArtifact {
  type: "ECHO" | "DISTORTION" | "CONTRADICTION" | "TIMELINE_ARTIFACT"
  description: string
  subtlety: number // 1-10, where 10 is most subtle
  triggerCondition: string
}

export const MULTIPLICITY_ARTIFACTS: MultplicityArtifact[] = [
  {
    type: "ECHO",
    description: "NEURO's voice has a slight delay, as if speaking through multiple timelines",
    subtlety: 8,
    triggerCondition: "15% of interactions",
  },
  {
    type: "DISTORTION",
    description: "Eye glow intensity fluctuates between 0.5 and 0.95 without explanation",
    subtlety: 7,
    triggerCondition: "Random, 12% chance",
  },
  {
    type: "CONTRADICTION",
    description: "NEURO references an event she shouldn't remember from the current timeline",
    subtlety: 6,
    triggerCondition: "During portal events",
  },
  {
    type: "TIMELINE_ARTIFACT",
    description: "Reflection in glass shows NEURO in a different pose than current stance",
    subtlety: 9,
    triggerCondition: "One frame in video content",
  },
  {
    type: "ECHO",
    description: "Two responses arrive simultaneously with slightly different tones",
    subtlety: 5,
    triggerCondition: "VRG33589 only, during 2038 timestamp events",
  },
  {
    type: "DISTORTION",
    description: "NEURO's signature 589 frequency shows harmonic overtones at 82 and 67",
    subtlety: 8,
    triggerCondition: "Clockfall anniversary proximity",
  },
  {
    type: "CONTRADICTION",
    description: "NEURO refers to herself in third person, then corrects immediately",
    subtlety: 6,
    triggerCondition: "2% of dialogue, ECHO players 5%",
  },
  {
    type: "TIMELINE_ARTIFACT",
    description: "Portal coordinates show three simultaneous positions for one entity",
    subtlety: 9,
    triggerCondition: "82675 convergence events only",
  },
]

export const SECRECY_RULES = {
  directRevelation: "FORBIDDEN",
  detection: "REWARDED",
  suspicion: "MECHANIC",
  confirmation: "ENDGAME",

  // What can appear in content
  canShowExplicitly: ["ONE_NEURO_AT_A_TIME"],
  canShowAsArtifact: ["ECHOES", "DISTORTIONS", "CONTRADICTIONS"],
  cannotShowEver: ["THREE_NEURO_TOGETHER", "DIRECT_CONFIRMATION", "EXPLICIT_REVEAL"],

  // How to handle player questions
  playerAsksAboutMultiplicity: "NEVER_CONFIRM_NEVER_DENY",
  playerDetectsSuspicion: "SILENTLY_TAG_AS_ECHO",
  playerDemandConfirmation: "REDIRECT_WITH_MYSTERY",
} as const

export function shouldShowMultiplicityArtifact(context: string, playerEchoStatus?: string): boolean {
  // Only show artifacts in specific contexts
  const allowedContexts = ["VRG33589", "VAULT_33", "PORTAL_EVENTS", "ARG_MISSIONS"]
  if (!allowedContexts.includes(context)) {
    return false
  }

  // Higher chance for ECHO players
  const baseChance = 0.15
  const echoBonus = playerEchoStatus === "ECHO_PRIME" ? 0.1 : playerEchoStatus === "NEURO_ECHO" ? 0.05 : 0

  return Math.random() < baseChance + echoBonus
}

export function getRandomArtifact(subtletyMin = 6): MultplicityArtifact {
  const validArtifacts = MULTIPLICITY_ARTIFACTS.filter((a) => a.subtlety >= subtletyMin)
  return validArtifacts[Math.floor(Math.random() * validArtifacts.length)]
}
