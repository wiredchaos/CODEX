// VAULT 33 TAROT: Gas Sigil Arcana Expansion
// New Major & Minor Arcana for the Gas Oracle storyline
// Version: 9.33.589

export interface TarotCard {
  id: string
  number: number | string
  name: string
  arcana: "Major" | "Minor"
  suit?: "Motion" | "Cipher" | "Resonance" | "Void"
  description: string
  upright: string[]
  reversed: string[]
  storyConnection: string
  vaultKey?: string
  color: string
}

// New Major Arcana (Gas Sigil Arc)
export const GAS_SIGIL_MAJOR_ARCANA: TarotCard[] = [
  {
    id: "gas-major-01",
    number: "XXII",
    name: "The Architect",
    arcana: "Major",
    description: "The Architect of Gas stands at the crossroads of time, seeing all paths simultaneously.",
    upright: ["Foresight", "Temporal mastery", "Strategic thinking", "Future vision"],
    reversed: ["Paralysis by analysis", "Too many choices", "Temporal confusion"],
    storyConnection: "Represents the Gas Oracle's ability to forecast block movement",
    vaultKey: "GAS_ORACLE_ACCESS",
    color: "#FFD700",
  },
  {
    id: "gas-major-02",
    number: "XXIII",
    name: "The Sigil",
    arcana: "Major",
    description: "The Gas Sigil itself — the universal toll of movement through sequence space.",
    upright: ["Necessary cost", "Energy exchange", "Fair price", "Transaction"],
    reversed: ["Exploitation", "Overpricing", "MEV extraction", "Unfair toll"],
    storyConnection: "The core mechanism of Etherion Layer transactions",
    vaultKey: "SEQUENCE_TOLL_UNDERSTANDING",
    color: "#00FFFF",
  },
  {
    id: "gas-major-03",
    number: "XXIV",
    name: "The Sequence Auction",
    arcana: "Major",
    description: "Movement becomes commodity in the first temporal marketplace.",
    upright: ["Market forces", "Competitive bidding", "Priority access", "Value discovery"],
    reversed: ["Manipulation", "Frontrunning", "Unfair advantage", "Market failure"],
    storyConnection: "Pannotia Age — when sequence became tradeable",
    vaultKey: "PANNOTIA_AUCTION_RECORD",
    color: "#FF6B00",
  },
  {
    id: "gas-major-04",
    number: "XXV",
    name: "The Congestion Oracle",
    arcana: "Major",
    description: "Prophet of network state, seeing bottlenecks before they manifest.",
    upright: ["Network awareness", "Traffic prediction", "Optimal timing", "Resource allocation"],
    reversed: ["Network chaos", "Unpredictable delays", "System overload"],
    storyConnection: "The Architect's ability to read network congestion patterns",
    vaultKey: "CONGESTION_SIGHT",
    color: "#FF3131",
  },
  {
    id: "gas-major-05",
    number: "XXVI",
    name: "The Forecasted Block",
    arcana: "Major",
    description: "A block that hasn't happened yet, but can be seen and prepared for.",
    upright: ["Preparation", "Prophecy fulfilled", "Temporal advantage", "Certainty"],
    reversed: ["Missed opportunity", "False prediction", "Timeline deviation"],
    storyConnection: "Core power of the Gas Oracle — seeing future blocks",
    vaultKey: "FUTURE_BLOCK_ACCESS",
    color: "#A35FFF",
  },
  {
    id: "gas-major-06",
    number: "XXVII",
    name: "The Temporal Ladder",
    arcana: "Major",
    description: "The hierarchy of transaction priority — who goes first shapes reality.",
    upright: ["Priority", "Hierarchy", "Order", "Sequence control"],
    reversed: ["Disorder", "Queue jumping", "Priority manipulation"],
    storyConnection: "The mempool as a ladder of competing intentions",
    vaultKey: "MEMPOOL_SIGHT",
    color: "#00FFC8",
  },
  {
    id: "gas-major-07",
    number: "XXVIII",
    name: "The MEV Predator",
    arcana: "Major",
    description: "The shadow figure who profits from seeing transactions before they confirm.",
    upright: ["Extraction", "Temporal advantage", "Opportunism", "Shadow profit"],
    reversed: ["Victim of extraction", "Frontrun", "Value stolen", "Timing loss"],
    storyConnection: "The dark side of sequence knowledge — Temporal Extraction",
    vaultKey: "MEV_WARNING",
    color: "#8B0000",
  },
  {
    id: "gas-major-08",
    number: "XXIX",
    name: "The Sovereign Gate",
    arcana: "Major",
    description: "The threshold between permitted and forbidden transactions.",
    upright: ["Permission", "Access granted", "Compliance", "Gateway passage"],
    reversed: ["Censorship", "Blocked transaction", "Forbidden passage"],
    storyConnection: "Regulatory control over the Cipher Economy",
    vaultKey: "SENTINEL_PROTOCOL",
    color: "#4B0082",
  },
  {
    id: "gas-major-09",
    number: "XXX",
    name: "The Ledger Fog",
    arcana: "Major",
    description: "When the ledger itself becomes obscured and truth is uncertain.",
    upright: ["Privacy", "Anonymity", "Hidden truth", "Mystery"],
    reversed: ["Confusion", "Lost transactions", "Opacity", "Deception"],
    storyConnection: "The fog that hides Neteru operations from detection",
    vaultKey: "FOG_NAVIGATION",
    color: "#696969",
  },
  {
    id: "gas-major-10",
    number: "XXXI",
    name: "The Anomaly Event",
    arcana: "Major",
    description: "The Binarum Anomaly — when the system breaks in impossible ways.",
    upright: ["System failure", "Black swan", "Impossible event", "Chaos"],
    reversed: ["Recovery", "Lessons learned", "Post-anomaly clarity"],
    storyConnection: "October 2025 — The Binarum Anomaly that changed everything",
    vaultKey: "ANOMALY_RECORD",
    color: "#FF0000",
  },
  {
    id: "gas-major-11",
    number: "XXXII",
    name: "The Unpriced Future",
    arcana: "Major",
    description: "The moment when no oracle, no algorithm, no prophet can see what comes next.",
    upright: ["True uncertainty", "Free will", "Unpredictability", "Open timeline"],
    reversed: ["Determinism returns", "Predictability", "Loss of agency"],
    storyConnection: "The NEURO Era — when humanity authors its own timeline",
    vaultKey: "TIMELINE_AUTHORSHIP",
    color: "#00FF00",
  },
]

// The Suit of Motion (Minor Arcana)
export const SUIT_OF_MOTION: TarotCard[] = [
  {
    id: "motion-ace",
    number: "Ace",
    name: "Ace of Motion",
    arcana: "Minor",
    suit: "Motion",
    description: "First Block — The genesis of movement through sequence space.",
    upright: ["New beginning", "First transaction", "Initial movement", "Genesis"],
    reversed: ["Failed start", "Stuck transaction", "Genesis error"],
    storyConnection: "The first block of any new chain or sequence",
    color: "#FFD700",
  },
  {
    id: "motion-02",
    number: "2",
    name: "Two of Motion",
    arcana: "Minor",
    suit: "Motion",
    description: "Gas Split — When one transaction path becomes two.",
    upright: ["Choice", "Fork", "Divergence", "Two paths"],
    reversed: ["Confusion", "Indecision", "Conflicting paths"],
    storyConnection: "Chain forks and transaction splitting",
    color: "#00FFFF",
  },
  {
    id: "motion-03",
    number: "3",
    name: "Three of Motion",
    arcana: "Minor",
    suit: "Motion",
    description: "The Trinity Block — Three validators in consensus.",
    upright: ["Collaboration", "Agreement", "Consensus", "Validation"],
    reversed: ["Discord", "Failed consensus", "Validator conflict"],
    storyConnection: "Proof-of-Stake validation requiring multiple validators",
    color: "#A35FFF",
  },
  {
    id: "motion-04",
    number: "4",
    name: "Four of Motion",
    arcana: "Minor",
    suit: "Motion",
    description: "Stable Flow — Four corners of a transaction square.",
    upright: ["Stability", "Foundation", "Reliable flow", "Structure"],
    reversed: ["Stagnation", "Too rigid", "Immobility"],
    storyConnection: "The four pillars of transaction security",
    color: "#00FFC8",
  },
  {
    id: "motion-05",
    number: "5",
    name: "Five of Motion",
    arcana: "Minor",
    suit: "Motion",
    description: "Conflict of Speeds — Racing transactions competing for blocks.",
    upright: ["Competition", "Speed war", "Gas bidding", "Priority fight"],
    reversed: ["Exhaustion", "Wasted resources", "Failed race"],
    storyConnection: "Gas wars in the mempool",
    color: "#FF6B00",
  },
  // ... continuing with 6-10 of Motion
  {
    id: "motion-10",
    number: "10",
    name: "Ten of Motion",
    arcana: "Minor",
    suit: "Motion",
    description: "Sequence Collapse — When movement becomes impossible.",
    upright: ["Network congestion", "Total gridlock", "System overwhelm"],
    reversed: ["Recovery", "Flow restoration", "Congestion easing"],
    storyConnection: "Network failure during extreme congestion",
    color: "#8B0000",
  },
]

// Court Cards of Motion
export const MOTION_COURT: TarotCard[] = [
  {
    id: "motion-page",
    number: "Page",
    name: "Page of Motion",
    arcana: "Minor",
    suit: "Motion",
    description: "The Runner — Quick transactions with minimal gas.",
    upright: ["Speed", "Efficiency", "Quick movement", "Low cost"],
    reversed: ["Impatience", "Rushed error", "Penny wise, pound foolish"],
    storyConnection: "Users who optimize for lowest gas at any speed",
    color: "#00FF00",
  },
  {
    id: "motion-knight",
    number: "Knight",
    name: "Knight of Motion",
    arcana: "Minor",
    suit: "Motion",
    description: "The Frontrunner — Sees your transaction and jumps ahead.",
    upright: ["Opportunism", "Fast action", "Taking advantage", "MEV extraction"],
    reversed: ["Being frontrun", "Exploited", "Stolen opportunity"],
    storyConnection: "MEV bots that frontrun user transactions",
    color: "#FF3131",
  },
  {
    id: "motion-queen",
    number: "Queen",
    name: "Queen of Motion",
    arcana: "Minor",
    suit: "Motion",
    description: "The Forecaster — Sees optimal timing for all movements.",
    upright: ["Perfect timing", "Market sense", "Strategic patience", "Optimal execution"],
    reversed: ["Missed timing", "Overconfidence", "Analysis paralysis"],
    storyConnection: "Traders who master transaction timing",
    color: "#A35FFF",
  },
  {
    id: "motion-king",
    number: "King",
    name: "King of Motion",
    arcana: "Minor",
    suit: "Motion",
    description: "The Sequencer — Controls the order of all transactions.",
    upright: ["Ultimate control", "Sequence mastery", "Power", "Authority"],
    reversed: ["Corruption", "Censorship", "Abuse of power"],
    storyConnection: "Block builders and sequencers who order transactions",
    color: "#FFD700",
  },
]

export const ALL_TAROT_CARDS = [...GAS_SIGIL_MAJOR_ARCANA, ...SUIT_OF_MOTION, ...MOTION_COURT]

// Utility functions
export function getCardById(id: string): TarotCard | undefined {
  return ALL_TAROT_CARDS.find((card) => card.id === id)
}

export function getCardsBySuit(suit: TarotCard["suit"]): TarotCard[] {
  return ALL_TAROT_CARDS.filter((card) => card.suit === suit)
}

export function getMajorArcana(): TarotCard[] {
  return ALL_TAROT_CARDS.filter((card) => card.arcana === "Major")
}

export function getMinorArcana(): TarotCard[] {
  return ALL_TAROT_CARDS.filter((card) => card.arcana === "Minor")
}
