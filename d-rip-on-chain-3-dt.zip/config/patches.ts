export type PatchCategory = "Education" | "Lore" | "ARG" | "OTT" | "System"
export type PatchStatus = "Prototype" | "Alpha" | "Live"

export interface PatchDefinition {
  slug: string
  name: string
  shortDescription: string
  longDescription: string
  howItFits: string
  startSteps: string[]
  roadmap: string[]
  category: PatchCategory
  status: PatchStatus
}

export const PATCHES: PatchDefinition[] = [
  {
    slug: "npc",
    name: "NEURO PROMPT COMMAND",
    shortDescription: "Prompt training and game-like prompt challenges.",
    longDescription:
      "A game-like prompt training system where users learn to craft effective prompts through challenges, levels, and rewards. Master the art of AI communication through structured exercises.",
    howItFits:
      "NPC serves as the educational backbone of WIRED CHAOS META, training operatives in the fundamental skill of prompt engineering before they venture into other patches.",
    startSteps: [
      "Complete the onboarding tutorial",
      "Choose your first prompt challenge tier",
      "Earn your initial Prompt Mastery badge",
    ],
    roadmap: [
      "Full prompt-lab with live AI feedback",
      "Multiplayer prompt battles",
      "Certification system integration",
    ],
    category: "Education",
    status: "Prototype",
  },
  {
    slug: "akira",
    name: "AKIRA CODEX",
    shortDescription: "Interactive story fragments and narrative engine.",
    longDescription:
      "A living codex of interconnected story fragments that weave together the lore of WIRED CHAOS META. Each entry unlocks deeper narrative threads and hidden connections.",
    howItFits:
      "Akira Codex is the narrative heart of the system—every patch references its lore, and completing quests in other patches unlocks new codex entries.",
    startSteps: ["Read the Origin Fragment", "Unlock your first story branch", "Discover a hidden connection"],
    roadmap: ["Branching narrative paths", "Community-driven story submissions", "Audio narration integration"],
    category: "Lore",
    status: "Prototype",
  },
  {
    slug: "neteru",
    name: "NETERU APINAYA",
    shortDescription: "Deep lore codex and mythological archives.",
    longDescription:
      "An extensive mythological database drawing from ancient wisdom traditions. Explore the Neteru—cosmic principles that underpin the WIRED CHAOS META universe.",
    howItFits:
      "Neteru Apinaya provides the philosophical and mythological foundation. Understanding these concepts enhances comprehension of all other patches.",
    startSteps: [
      "Begin with the Primer of Elements",
      "Study your first Neteru archetype",
      "Link a concept to another patch",
    ],
    roadmap: ["Interactive relationship maps", "Meditation and reflection modules", "Scholar certification track"],
    category: "Lore",
    status: "Prototype",
  },
  {
    slug: "vrg33589",
    name: "VRG33589",
    shortDescription: "Frequency dashboard and 3D market realm.",
    longDescription:
      "A virtual reality gateway combining frequency visualization with market intelligence. Navigate 3D spaces that represent real-world data streams and energy patterns.",
    howItFits:
      "VRG33589 is the sensory interface of WIRED CHAOS META—where abstract data becomes tangible and explorable in immersive 3D environments.",
    startSteps: ["Calibrate your frequency baseline", "Enter the Overview Chamber", "Identify your first data anomaly"],
    roadmap: ["Full Spline 3D scene integration", "Real-time market data feeds", "Collaborative virtual spaces"],
    category: "ARG",
    status: "Prototype",
  },
  {
    slug: "vault33",
    name: "VAULT 33",
    shortDescription: "Cipher-gated game realm and puzzle archive.",
    longDescription:
      "An encrypted vault containing puzzles, ciphers, and challenges. Only those who prove their worth through problem-solving gain access to deeper levels and hidden rewards.",
    howItFits:
      "Vault 33 is the ultimate test within WIRED CHAOS META. Skills learned in NPC, lore from Akira and Neteru, and data from VRG all converge here.",
    startSteps: ["Solve the Entry Cipher", "Access Level 1 Archives", "Decode your first Vault fragment"],
    roadmap: ["Multi-layer cipher gating system", "Collaborative puzzle raids", "Physical merch unlock rewards"],
    category: "ARG",
    status: "Prototype",
  },
  {
    slug: "lpr589",
    name: "LPR / REX-589",
    shortDescription: "ARG mission control and quest coordination.",
    longDescription:
      "The operational command center for all ARG activities. Track missions, coordinate with other operatives, and receive real-time updates on the evolving meta-narrative.",
    howItFits:
      "LPR589 is mission control—coordinating activities across all patches and providing the quest structure that ties the entire WIRED CHAOS META experience together.",
    startSteps: ["Register your operative callsign", "Accept your first mission briefing", "Report status to command"],
    roadmap: ["Interactive mission map", "Team formation and coordination", "Live event integration"],
    category: "ARG",
    status: "Prototype",
  },
  {
    slug: "789-studios",
    name: "789 STUDIOS",
    shortDescription: "OTT content grid and show archive.",
    longDescription:
      "The entertainment production wing of WIRED CHAOS META. Access exclusive shows, behind-the-scenes content, and community-created media that expands the universe.",
    howItFits:
      "789 Studios brings the WIRED CHAOS META narrative to life through video content, serving as the public-facing media arm that draws new operatives into the system.",
    startSteps: ["Browse the Show Directory", "Watch the Introduction Series", "Join the Creator Community"],
    roadmap: ["Full OTT streaming platform", "Interactive episode experiences", "Creator tools and distribution"],
    category: "OTT",
    status: "Prototype",
  },
]

export const getCategoryColor = (category: PatchCategory): string => {
  switch (category) {
    case "Education":
      return "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
    case "Lore":
      return "bg-amber-500/20 text-amber-400 border-amber-500/30"
    case "ARG":
      return "bg-cyan-500/20 text-cyan-400 border-cyan-500/30"
    case "OTT":
      return "bg-fuchsia-500/20 text-fuchsia-400 border-fuchsia-500/30"
    case "System":
      return "bg-zinc-500/20 text-zinc-400 border-zinc-500/30"
  }
}

export const getStatusColor = (status: PatchStatus): string => {
  switch (status) {
    case "Prototype":
      return "bg-orange-500/20 text-orange-400"
    case "Alpha":
      return "bg-blue-500/20 text-blue-400"
    case "Live":
      return "bg-green-500/20 text-green-400"
  }
}
