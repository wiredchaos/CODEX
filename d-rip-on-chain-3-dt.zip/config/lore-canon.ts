// WIRED CHAOS META — Official ARG-Safe Canon
// All real-world entities mapped to fictional equivalents
// Version: 1.1 (Black Ledger Year - AURON PACT Update)

export type FactionType = "Institution" | "Character" | "Technology" | "Location" | "Event"

export interface LoreEntity {
  id: string
  type: FactionType
  realWorld: string
  fictional: string
  description: string
  category: string
  aliases?: string[]
}

// Master Dictionary: Real → ARG Mappings
export const LORE_DICTIONARY: LoreEntity[] = [
  // CHARACTERS
  {
    id: "architect_gas",
    type: "Character",
    realWorld: "Vitalik Buterin",
    fictional: "The Architect of Gas",
    description: "A visionary coder who introduces the Gas Sigil, enabling the forecasting of future block movement.",
    category: "Character",
    aliases: ["Architect", "Gas Oracle"],
  },
  {
    id: "sovereign_candidate",
    type: "Character",
    realWorld: "Trump",
    fictional: "The Sovereign Candidate",
    description: "A political waveform that distorts economic energy fields.",
    category: "Character",
    aliases: ["Sovereign", "The Candidate"],
  },
  {
    id: "cipher_zenith",
    type: "Character",
    realWorld: "CZ (Binance founder)",
    fictional: "Cipher Zenith",
    description: "Exiled founder of Binarum who holds forbidden knowledge of the Anomaly Event.",
    category: "Character",
    aliases: ["Zenith", "CZ"],
  },

  // INSTITUTIONS
  {
    id: "etherion_assembly",
    type: "Institution",
    realWorld: "Ethereum Foundation",
    fictional: "The Etherion Assembly",
    description:
      "A secretive council that governs the flow of Etheric Charge, the energy that fuels the Cipher Economies.",
    category: "Institution",
    aliases: ["Etherion", "Assembly"],
  },
  {
    id: "first_cipher",
    type: "Technology",
    realWorld: "Bitcoin",
    fictional: "The First Cipher",
    description:
      "An ancient ledger older than known civilization, discovered in seismic fault lines beneath the supercontinent Rodinia.",
    category: "Technology",
    aliases: ["First", "Cipher One"],
  },
  {
    id: "auron_pact",
    type: "Institution",
    realWorld: "WLFI",
    fictional: "The Auron Pact",
    description:
      "A covert alliance formed to stabilize Layer-1 consensus after the Oracle Wars. Instead of stabilizing the chain, the Pact fractured internally, triggering the Validator Culling and the Stablecoin Peg Collapse.",
    category: "Institution",
    aliases: ["Auron", "The Pact", "Auron Directive", "Auron Signal Chain"],
  },
  {
    id: "eastern_directorate",
    type: "Institution",
    realWorld: "China",
    fictional: "The Eastern Directorate",
    description: "A continental power controlling digital gateways, sequence archives, and neural identity networks.",
    category: "Location",
    aliases: ["Directorate", "Eastern Coalition"],
  },
  {
    id: "legacy_houses",
    type: "Institution",
    realWorld: "Traditional Banks/Regulators",
    fictional: "The Legacy Houses",
    description:
      "A baroque guild of ancient economic families that manipulate world markets through secret Stability Mandates.",
    category: "Institution",
    aliases: ["Houses", "Legacy Guild"],
  },
  {
    id: "undernet_syndicates",
    type: "Institution",
    realWorld: "Hackers/Blackhat Collectives",
    fictional: "The Undernet Syndicates",
    description: "Fragments of forbidden intelligences formed from old Akashic sparkstone.",
    category: "Institution",
    aliases: ["Undernet", "Syndicates", "Raiders"],
  },

  // TECHNOLOGIES
  {
    id: "etherion_layer",
    type: "Technology",
    realWorld: "Ethereum",
    fictional: "Etherion Layer",
    description: "The primary smart contract platform governed by the Etherion Assembly.",
    category: "Technology",
  },
  {
    id: "solara_chainworks",
    type: "Technology",
    realWorld: "Solana",
    fictional: "Solara Chainworks",
    description: "High-speed transaction layer known for validator instability.",
    category: "Technology",
    aliases: ["Solara"],
  },
  {
    id: "binarum_exchange",
    type: "Institution",
    realWorld: "Binance",
    fictional: "Binarum Exchange",
    description: "Major trading house that experienced the catastrophic Anomaly Event.",
    category: "Institution",
    aliases: ["Binarum"],
  },
  {
    id: "coinhold_gatehouse",
    type: "Institution",
    realWorld: "Coinbase",
    fictional: "Coinhold Gatehouse",
    description: "Regulated exchange serving as gateway between traditional and cipher economies.",
    category: "Institution",
    aliases: ["Coinhold"],
  },

  // EVENTS & CONCEPTS
  {
    id: "gas_sigil",
    type: "Technology",
    realWorld: "Gas fees",
    fictional: "Sequence Tolls",
    description: "Fees required to process transactions on the Etherion Layer.",
    category: "Technology",
    aliases: ["Gas", "Tolls"],
  },
  {
    id: "mev_extraction",
    type: "Event",
    realWorld: "MEV (Maximal Extractable Value)",
    fictional: "Temporal Extraction",
    description: "The practice of extracting value by manipulating transaction ordering.",
    category: "Technology",
    aliases: ["MEV", "Extraction"],
  },
  {
    id: "anchor_tokens",
    type: "Technology",
    realWorld: "Stablecoins",
    fictional: "Anchor Tokens",
    description: "Tokens designed to maintain stable value but often lose their peg.",
    category: "Technology",
    aliases: ["Anchors", "Stable"],
  },
  {
    id: "synthetic_intelligences",
    type: "Technology",
    realWorld: "AI",
    fictional: "Synthetic Intelligences",
    description: "Artificial consciousness systems used for automation and prediction.",
    category: "Technology",
    aliases: ["SI", "Synthetics"],
  },
  {
    id: "sentinel_council",
    type: "Institution",
    realWorld: "SEC",
    fictional: "Sentinel Enforcement Council",
    description: "Regulatory body that enforces compliance in the cipher economy.",
    category: "Institution",
    aliases: ["Sentinel", "Council"],
  },
  {
    id: "western_coalition",
    type: "Location",
    realWorld: "United States",
    fictional: "Western Coalition",
    description: "Democratic alliance of states with complex regulatory frameworks.",
    category: "Location",
    aliases: ["Coalition", "West"],
  },
]

// The Six Fictional Institutions (Core Factions)
export interface CoreFaction {
  id: string
  name: string
  description: string
  role: string
  connectedPatches: string[]
  color: string
}

export const CORE_FACTIONS: CoreFaction[] = [
  {
    id: "etherion_assembly",
    name: "The Etherion Assembly",
    description: "Secretive council governing the flow of Etheric Charge.",
    role: "Technological Governance",
    connectedPatches: ["vrg33589", "vault33"],
    color: "#00FFFF",
  },
  {
    id: "first_cipher",
    name: "The First Cipher",
    description: "Ancient ledger older than civilization itself.",
    role: "Original Technology",
    connectedPatches: ["vault33", "akira"],
    color: "#FFE066",
  },
  {
    id: "auron_pact",
    name: "The Auron Pact",
    description: "Covert alliance that fractured after attempting to stabilize Layer-1 consensus.",
    role: "Economic Disruption",
    connectedPatches: ["vrg33589", "lpr589"],
    color: "#FF3131",
  },
  {
    id: "eastern_directorate",
    name: "The Eastern Directorate",
    description: "Continental power controlling digital gateways.",
    role: "Infrastructure Control",
    connectedPatches: ["vault33", "neteru"],
    color: "#A35FFF",
  },
  {
    id: "legacy_houses",
    name: "The Legacy Houses",
    description: "Ancient economic families manipulating markets.",
    role: "Financial Manipulation",
    connectedPatches: ["vrg33589", "789-studios"],
    color: "#00FFC8",
  },
  {
    id: "undernet_syndicates",
    name: "The Undernet Syndicates",
    description: "Forbidden intelligences formed from Akashic sparkstone.",
    role: "Shadow Operations",
    connectedPatches: ["vault33", "lpr589", "akira"],
    color: "#FF6B00",
  },
]

// Utility function to translate real-world terms to fictional
export function toFictional(realWorldTerm: string): string {
  const entity = LORE_DICTIONARY.find(
    (e) =>
      e.realWorld.toLowerCase() === realWorldTerm.toLowerCase() ||
      e.aliases?.some((alias) => alias.toLowerCase() === realWorldTerm.toLowerCase()),
  )
  return entity ? entity.fictional : realWorldTerm
}

// Reverse lookup: fictional to real (for dev reference only)
export function toRealWorld(fictionalTerm: string): string {
  const entity = LORE_DICTIONARY.find((e) => e.fictional.toLowerCase() === fictionalTerm.toLowerCase())
  return entity ? entity.realWorld : fictionalTerm
}

// Get all entities by category
export function getEntitiesByCategory(category: string): LoreEntity[] {
  return LORE_DICTIONARY.filter((e) => e.category.toLowerCase() === category.toLowerCase())
}

// Get faction by ID
export function getFactionById(id: string): CoreFaction | undefined {
  return CORE_FACTIONS.find((f) => f.id === id)
}
