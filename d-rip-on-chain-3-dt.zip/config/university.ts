// Wired Chaos University System — "The Akashic Motherboard"
// Complete node architecture with metadata for storytelling + technical layers

export type NodeId = "WCU" | "BCU" | "POS" | "SOC" | "WUU"
export type BadgeRank = "Initiate" | "Adept" | "Keeper" | "Merovingian"
export type MediaType = "show" | "tutorial" | "promo" | "game" | "course" | "drama"

// Metadata structure for each university node
export interface UniversityNode {
  nodeId: string
  name: string
  fullName: string
  visualAssetRef: string
  discipline: string
  loreTagline: string
  mediaTypes: MediaType[]
  connectedNodes: string[]
  akashicRoute: string
  description: string
  color: string
  glowColor: string
  crestSymbol: string
}

// The Five Colleges of the University Network
export const UNIVERSITY_NODES: UniversityNode[] = [
  {
    nodeId: "WCU_001",
    name: "WCU",
    fullName: "Wired Chaos University",
    visualAssetRef: "/assets/wcu_brain.svg",
    discipline: "Signal Engineering / Media Arts",
    loreTagline: "Knowledge is a broadcast.",
    mediaTypes: ["tutorial", "promo", "course"],
    connectedNodes: ["BCU_001", "AI_ACADEMY", "POS_001"],
    akashicRoute: "motherboard://ai_academy/wcu",
    description: "Central access hub; controls curriculum, shows, and onboarding tutorials. The brain of the network.",
    color: "#00FFFF",
    glowColor: "rgba(0, 255, 255, 0.5)",
    crestSymbol: "brain",
  },
  {
    nodeId: "BCU_001",
    name: "BCU",
    fullName: "Blockchain Chaos University",
    visualAssetRef: "/assets/bcu_chain.svg",
    discipline: "Finance / Economics / Validation",
    loreTagline: "Trust the chain, not the throne.",
    mediaTypes: ["show", "tutorial", "game"],
    connectedNodes: ["WCU_001", "POS_001", "SOC_001"],
    akashicRoute: "motherboard://blockchain/bcu",
    description: "Finance, economics, coding, validation. Where decentralized systems are mastered.",
    color: "#A35FFF",
    glowColor: "rgba(163, 95, 255, 0.5)",
    crestSymbol: "chain",
  },
  {
    nodeId: "POS_001",
    name: "Proof of School",
    fullName: "Proof of School",
    visualAssetRef: "/assets/pos_emblem.svg",
    discipline: "Verification / Credentials",
    loreTagline: "Validate or vanish.",
    mediaTypes: ["tutorial", "promo"],
    connectedNodes: ["WCU_001", "BCU_001", "WUU_001"],
    akashicRoute: "motherboard://credentials/pos",
    description: "Verification and credential system. NFT badges = proof-of-learning. Your achievements, immutable.",
    color: "#FFE066",
    glowColor: "rgba(255, 224, 102, 0.5)",
    crestSymbol: "badge",
  },
  {
    nodeId: "SOC_001",
    name: "School of Chaos",
    fullName: "School of Chaos",
    visualAssetRef: "/assets/soc_eye.svg",
    discipline: "Experimental R&D / Psychology",
    loreTagline: "Disorder teaches better.",
    mediaTypes: ["show", "drama", "game"],
    connectedNodes: ["BCU_001", "WUU_001", "WCU_001"],
    akashicRoute: "motherboard://experimental/soc",
    description: "Experimental R&D, psychology, culture. The avant-garde laboratory of the network.",
    color: "#FF3131",
    glowColor: "rgba(255, 49, 49, 0.5)",
    crestSymbol: "eye",
  },
  {
    nodeId: "WUU_001",
    name: "WU University",
    fullName: "WU University",
    visualAssetRef: "/assets/wuu_hood.svg",
    discipline: "Narrative / Lore Faculty",
    loreTagline: "Every signal tells a story.",
    mediaTypes: ["drama", "show", "promo"],
    connectedNodes: ["SOC_001", "POS_001", "WCU_001"],
    akashicRoute: "motherboard://narrative/wuu",
    description: "Narrative & lore faculty—produces dramas and films. The storytelling arm of chaos.",
    color: "#00FFC8",
    glowColor: "rgba(0, 255, 200, 0.5)",
    crestSymbol: "hood",
  },
]

// Motherboard Subsystems (from the final Akashic image)
export interface MotherboardSubsystem {
  id: string
  name: string
  description: string
  route: string
  status: "active" | "standby" | "offline"
  color: string
}

export const MOTHERBOARD_SUBSYSTEMS: MotherboardSubsystem[] = [
  {
    id: "wired_chaos",
    name: "WIRED CHAOS",
    description: "Core operating system",
    route: "/",
    status: "active",
    color: "#00FFFF",
  },
  {
    id: "mint_factory",
    name: "589 MINT FACTORY",
    description: "NFT and artifact generation",
    route: "/vrg33589",
    status: "active",
    color: "#FF3131",
  },
  {
    id: "fm_dogechain",
    name: "33.3 FM DOGECHAIN",
    description: "Broadcast transmission layer",
    route: "/broadcast",
    status: "active",
    color: "#FFE066",
  },
  {
    id: "ai_academy",
    name: "AI ACADEMY",
    description: "Machine learning modules",
    route: "/education/ai-academy",
    status: "active",
    color: "#A35FFF",
  },
  {
    id: "vault_33",
    name: "VAULT 33",
    description: "Encrypted archives",
    route: "/vault33",
    status: "standby",
    color: "#00FFC8",
  },
  {
    id: "789_studios",
    name: "789 STUDIOS",
    description: "Content production",
    route: "/789-studios",
    status: "active",
    color: "#FF6B00",
  },
]

// Legacy HOUSES export for backward compatibility
export type HouseId = NodeId
export interface House {
  id: HouseId
  name: string
  fullName: string
  description: string
  focus: string
  color: string
  borderColor: string
  requirements: string[]
}

export const HOUSES: House[] = UNIVERSITY_NODES.map((node) => ({
  id: node.name as HouseId,
  name: node.name,
  fullName: node.fullName,
  description: node.description,
  focus: node.discipline,
  color: `bg-[${node.color}]/20`,
  borderColor: `border-[${node.color}]/50`,
  requirements: ["Complete onboarding", "Earn 1 artifact"],
}))

export const BADGE_PROGRESSION: { rank: BadgeRank; tier: string; requirements: string[]; perks: string[] }[] = [
  {
    rank: "Initiate",
    tier: "Entry",
    requirements: ["Earn any 1 artifact", "Complete onboarding tutorial"],
    perks: ["Basic WL points", "Access to general WCU server", "Artifact inventory"],
  },
  {
    rank: "Adept",
    tier: "WL Tier 1",
    requirements: ["Collect 3 different artifact types", "Complete house entrance exam"],
    perks: ["AI tools access", "Deeper artifact map", "Private modules"],
  },
  {
    rank: "Keeper",
    tier: "WL Tier 2",
    requirements: ["Complete specific broadcast questlines", "Pass Keeper trials"],
    perks: ["Early 589 Mint Factory previews", "Exclusive courses", "Mentorship access"],
  },
  {
    rank: "Merovingian",
    tier: "Inner Circle",
    requirements: ["Obtain rare Merovingian-tagged artifacts", "Complete 82675 time-loop", "Master all houses"],
    perks: ["Governance rights", "Lore shaping privileges", "Full system access", "Revenue sharing"],
  },
]

export const getRankColor = (rank: BadgeRank): string => {
  switch (rank) {
    case "Initiate":
      return "text-zinc-400 border-zinc-500/30"
    case "Adept":
      return "text-blue-400 border-blue-500/30"
    case "Keeper":
      return "text-purple-400 border-purple-500/30"
    case "Merovingian":
      return "text-amber-400 border-amber-500/30"
  }
}
