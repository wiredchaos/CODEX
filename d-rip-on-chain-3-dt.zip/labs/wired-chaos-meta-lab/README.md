# WIRED CHAOS META LAB

## Overview

The WIRED CHAOS META LAB is a non-destructive testing environment where all WIRED CHAOS META components can be explored, tested, and understood without affecting production systems.

## Structure

```
/labs
  /wired-chaos-meta-lab
    /789-studios          # Lab copy of 789 Studios OTT platform
      /dashboard          # Analytics and account management
      /ott                # Netflix-style streaming interface (coming soon)
      /csn                # Crypto Spaces Network scheduling (coming soon)
      /film3              # Film3 documentary tools (coming soon)
      /profiles           # Creator profile showcases (coming soon)
    /shared               # Shared utilities for lab modules
```

## Routes

- `/lab` - Main lab homepage
- `/lab/789` - 789 Studios lab overview
- `/lab/789/dashboard` - Dashboard analytics (active)
- `/lab/789/ott` - OTT interface (coming soon)
- `/lab/789/csn` - CSN schedule (coming soon)
- `/lab/789/film3` - Film3 tools (coming soon)
- `/lab/789/profiles` - Creator profiles (coming soon)

## 789 Studios Lab Components

### Current Implementation

The 789 Studios lab currently includes:

1. **Dashboard** (`/lab/789/dashboard`)
   - Connected X account management
   - Lurky Spaces analytics
   - Engagement metrics
   - Quick action links

### Production Source Files

The lab is a non-destructive copy of production files:

- Source: `/app/789-studios/page.tsx`
- Lab Copy: `/app/lab/789/dashboard/page.tsx`
- Additional: `/app/789-studios/spaces-panel.tsx` (component)

### Key Differences from Production

1. All lab routes are prefixed with `/lab/`
2. Visual indicators show "Lab Mode" throughout
3. Breadcrumb navigation helps users understand context
4. Clear messaging that changes won't affect production

## Safety Guarantees

- **Non-Destructive**: No production files are modified
- **Isolated**: All lab code lives in `/labs/` and `/app/lab/`
- **Safe to Explore**: Users can click anywhere without risk
- **No Side Effects**: Lab actions don't trigger production APIs

## Future Expansion

Additional lab modules planned:

- 33.3FM Lab (DOGECHAIN radio system)
- NEURO Swarm Lab (content generation engine)
- VRG33589 Lab (3D frequency dashboard)
- Vault 33 Lab (cipher puzzle system)

## For Engineers

### Adding New Lab Modules

1. Create directory under `/labs/wired-chaos-meta-lab/[module-name]`
2. Add route under `/app/lab/[module-name]`
3. Copy source files maintaining folder structure
4. Update imports to reference lab copies
5. Add visual lab indicators
6. Update `/app/lab/page.tsx` with new module card

### Import Path Strategy

- Prefer importing from shared `/components/ui/*` and `/lib/*`
- Copy module-specific helpers to `/labs/.../shared/`
- Update relative imports to absolute where possible
- Maintain clear separation from production code

## Non-Technical User Guide

The lab is designed to be accessible to non-technical users:

- **Plain language** explanations throughout
- **Visual workflows** showing how components connect
- **Safe exploration** with clear "Lab Mode" indicators
- **Step-by-step guides** for each module
- **No jargon** in user-facing text

Visit `/lab` to start exploring!
