# 33.3FM DOGECHAIN Setup Guide

## Database Setup

The 33.3FM system requires database tables to be created in your Supabase Postgres instance.

### Step 1: Run the Migration Script

The migration script is located at: `scripts/001_create_33fm_tables.sql`

**Option A: Run from v0 UI**
1. The script is already in your project
2. v0 can execute it directly for you
3. Click "Run Script" in the Scripts section

**Option B: Run from Supabase Dashboard**
1. Go to your Supabase project dashboard
2. Navigate to SQL Editor
3. Copy the contents of `scripts/001_create_33fm_tables.sql`
4. Paste and execute

**Option C: Run via Prisma**
```bash
# Generate Prisma Client
npx prisma generate

# Push schema to database
npx prisma db push
```

### Step 2: Verify Tables

After running the migration, verify these tables exist:
- `fm_users`
- `fm_creators`
- `fm_tracks`
- `fm_videos`
- `fm_podcasts`
- `fm_audiobooks`
- `fm_boosts`
- `fm_payments`
- `fm_user_auth`
- `fm_wallets`
- `fm_creator_stats`

### Step 3: Seed Sample Data (Optional)

Create a few sample creators and tracks to test the system:

```sql
-- Insert a test user
INSERT INTO fm_users (id, display_name, tier_level)
VALUES ('user_test_001', 'DJ Red Fang', 'premium');

-- Insert a test creator
INSERT INTO fm_creators (id, user_id, handle, bio, tier_level)
VALUES ('creator_test_001', 'user_test_001', 'djredfang', 'Electronic music producer', 'pro');

-- Insert a test track
INSERT INTO fm_tracks (id, creator_id, title, audio_url, cover_art_url, duration, genre, mint_chain)
VALUES (
  'track_test_001',
  'creator_test_001',
  'Neon Frequencies',
  '/sample-audio.mp3',
  '/neon-album-art.jpg',
  245,
  'Electronic',
  'DOGE'
);
```

## Environment Variables

Make sure these are set in your Vercel project (already configured via integration):

```
POSTGRES_URL=<your-supabase-connection-string>
POSTGRES_PRISMA_URL=<your-supabase-prisma-url>
POSTGRES_URL_NON_POOLING=<your-supabase-non-pooling-url>
```

## API Routes

Once the database is set up, these endpoints will work:

- `GET /api/33fm/dashboard` - Dashboard stats and recent content
- `GET /api/33fm/tracks` - List all tracks (with pagination)
- `POST /api/33fm/tracks` - Upload new track
- `GET /api/33fm/now-playing` - Current radio broadcast
- `POST /api/33fm/mint` - Mint content to blockchain
- `POST /api/33fm/boost` - Boost content visibility

## UI Pages

- `/33fm` - Homepage with feature grid
- `/33fm/radio` - Live radio player
- `/33fm/jukebox` - Video jukebox
- `/33fm/audiobooks` - Audiobook library
- `/33fm/podcasts` - Podcast directory
- `/33fm/studio` - Creator production studio
- `/33fm/mint` - Content minting interface

## Troubleshooting

### Error: "The string did not match the expected pattern"

This means the database tables don't exist yet. Run the migration script.

### Error: "relation 'fm_tracks' does not exist"

Same as above - tables need to be created via migration.

### Empty Dashboard

If the dashboard loads but shows zeros, you need to seed some sample data (see Step 3 above).
