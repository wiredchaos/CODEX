import { CinematicHeader } from "@/components/akashic/cinematic-header"
import type { AvatarTier } from "@/config/story-engine"

export const metadata = {
  title: "Avatar Advancement | WIRED CHAOS META",
  description: "CHAOS OS Creative Tier System",
}

const TIER_DATA: {
  tier: AvatarTier
  title: string
  description: string
  unlocks: string[]
  xpRequired: number
}[] = [
  {
    tier: "initiate",
    title: "INITIATE",
    description: "Entry level. Begin your creative journey.",
    unlocks: ["Basic Story Templates", "Single Chapter Stories", "Standard Genres"],
    xpRequired: 0,
  },
  {
    tier: "scribe",
    title: "SCRIBE",
    description: "Proven storyteller. Access expanded tools.",
    unlocks: ["Advanced Characters", "Custom Worlds", "Multi-tone Blending", "Character Relationship Maps"],
    xpRequired: 100,
  },
  {
    tier: "chronicler",
    title: "CHRONICLER",
    description: "Master of narratives. Unlock publishing.",
    unlocks: ["Multi-Chapter Expansion", "Cover Generation", "EPUB/PDF Export", "Author Profile Page"],
    xpRequired: 500,
  },
  {
    tier: "lorekeeper",
    title: "LOREKEEPER",
    description: "Guardian of stories. Full publishing access.",
    unlocks: ["KDP Direct Publish", "Microsite Generator", "Press Kit Access", "Revenue Dashboard"],
    xpRequired: 2000,
  },
  {
    tier: "merovingian",
    title: "MEROVINGIAN",
    description: "Legendary creator. Shape the canon.",
    unlocks: ["Unlimited Stories", "70% Revenue Share", "Lore Canon Access", "Mentor Badge", "Custom Agent Training"],
    xpRequired: 10000,
  },
]

export default function AvatarAdvancementPage() {
  const currentTier = "initiate"
  const currentXP = 45

  return (
    <div className="min-h-screen bg-black">
      <div className="fixed inset-0 pointer-events-none z-50 bg-[url('/textures/scanlines.png')] opacity-5" />

      <div className="relative z-10">
        <CinematicHeader
          title="AVATAR ADVANCEMENT"
          subtitle="CHAOS-GATE Assessment System"
          classification="CHAOS OS // CREATIVE TIERS"
        />

        <main className="max-w-5xl mx-auto px-6 py-12 space-y-16">
          {/* Current Status */}
          <section className="p-6 border border-cyan-500/30 rounded-lg bg-cyan-500/5">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-xs text-zinc-500 uppercase tracking-widest mb-1">Current Rank</h3>
                <div className="text-3xl font-mono text-cyan-400">INITIATE</div>
              </div>
              <div className="text-right">
                <h3 className="text-xs text-zinc-500 uppercase tracking-widest mb-1">Story XP</h3>
                <div className="text-3xl font-mono text-amber-400">{currentXP}</div>
              </div>
            </div>
            {/* XP Progress Bar */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs text-zinc-500">
                <span>Progress to SCRIBE</span>
                <span>{currentXP} / 100 XP</span>
              </div>
              <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-cyan-500 to-fuchsia-500 transition-all"
                  style={{ width: `${(currentXP / 100) * 100}%` }}
                />
              </div>
            </div>
          </section>

          {/* Tier Tree */}
          <section>
            <h2 className="text-xs uppercase tracking-[0.3em] text-red-500 mb-8">Advancement Tree</h2>
            <div className="relative">
              {/* Vertical connection line */}
              <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-cyan-500 via-fuchsia-500 to-amber-500 opacity-30" />

              <div className="space-y-6">
                {TIER_DATA.map((tier, index) => {
                  const isActive = tier.tier === currentTier
                  const isUnlocked = currentXP >= tier.xpRequired
                  return (
                    <div key={tier.tier} className="relative pl-20">
                      {/* Node */}
                      <div
                        className={`absolute left-4 w-8 h-8 rounded-full flex items-center justify-center border-2 transition-all ${
                          isActive
                            ? "bg-cyan-500 border-cyan-400 shadow-[0_0_20px_rgba(0,255,255,0.5)]"
                            : isUnlocked
                              ? "bg-zinc-800 border-cyan-500"
                              : "bg-zinc-900 border-zinc-700"
                        }`}
                      >
                        <span className="text-xs font-bold">{index + 1}</span>
                      </div>

                      {/* Card */}
                      <div
                        className={`p-6 rounded-lg border transition-all ${
                          isActive
                            ? "border-cyan-500/50 bg-cyan-500/10"
                            : isUnlocked
                              ? "border-zinc-700 bg-zinc-900/50"
                              : "border-zinc-800/50 bg-zinc-900/30 opacity-60"
                        }`}
                      >
                        <div className="flex items-center justify-between mb-3">
                          <h3
                            className={`text-xl font-mono ${
                              isActive ? "text-cyan-400" : isUnlocked ? "text-zinc-200" : "text-zinc-500"
                            }`}
                          >
                            {tier.title}
                          </h3>
                          <span className="text-xs text-zinc-500 font-mono">{tier.xpRequired} XP</span>
                        </div>
                        <p className="text-sm text-zinc-400 mb-4">{tier.description}</p>
                        <div>
                          <h4 className="text-xs text-zinc-500 uppercase mb-2">Unlocks</h4>
                          <div className="flex flex-wrap gap-2">
                            {tier.unlocks.map((unlock) => (
                              <span
                                key={unlock}
                                className={`px-2 py-1 text-xs rounded ${
                                  isUnlocked
                                    ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                                    : "bg-zinc-800 text-zinc-500"
                                }`}
                              >
                                {unlock}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          </section>

          {/* Assessment Metrics */}
          <section>
            <h2 className="text-xs uppercase tracking-[0.3em] text-red-500 mb-6">Assessment Metrics</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: "Story Integrity", value: 78, color: "cyan" },
                { label: "Creative Ethic", value: 65, color: "fuchsia" },
                { label: "Lore Alignment", value: 82, color: "amber" },
                { label: "Submission Freq", value: 45, color: "emerald" },
              ].map((metric) => (
                <div key={metric.label} className="p-4 border border-zinc-800 rounded-lg bg-zinc-900/50">
                  <h4 className="text-xs text-zinc-500 mb-2">{metric.label}</h4>
                  <div className="text-2xl font-mono text-zinc-200 mb-2">{metric.value}%</div>
                  <div className="h-1 bg-zinc-800 rounded-full overflow-hidden">
                    <div
                      className={`h-full bg-${metric.color}-500`}
                      style={{
                        width: `${metric.value}%`,
                        backgroundColor:
                          metric.color === "cyan"
                            ? "#00FFFF"
                            : metric.color === "fuchsia"
                              ? "#D946EF"
                              : metric.color === "amber"
                                ? "#F59E0B"
                                : "#10B981",
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* How XP is Earned */}
          <section className="p-6 border border-zinc-800 rounded-lg bg-zinc-900/50">
            <h2 className="text-xs uppercase tracking-[0.3em] text-red-500 mb-6">How to Earn XP</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              {[
                { action: "Generate Story Seed", xp: "+5 XP" },
                { action: "Complete Novella Expansion", xp: "+25 XP" },
                { action: "Convert to Ebook", xp: "+10 XP" },
                { action: "Publish to KDP", xp: "+50 XP" },
                { action: "First Sale", xp: "+100 XP" },
                { action: "Lore Canon Contribution", xp: "+200 XP" },
              ].map((item) => (
                <div key={item.action} className="flex items-center justify-between p-3 bg-black/30 rounded">
                  <span className="text-zinc-300">{item.action}</span>
                  <span className="text-emerald-400 font-mono">{item.xp}</span>
                </div>
              ))}
            </div>
          </section>
        </main>
      </div>
    </div>
  )
}
