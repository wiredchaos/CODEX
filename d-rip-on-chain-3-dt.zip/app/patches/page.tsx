import { PATCHES, getCategoryColor } from "@/config/patches"
import { PatchGrid } from "@/components/patch/patch-grid"

const categories = ["Education", "Lore", "ARG", "OTT"] as const

export default function PatchesPage() {
  return (
    <div className="space-y-10">
      {/* Header */}
      <section>
        <h1 className="text-3xl font-bold tracking-tight mb-2">Patch Directory</h1>
        <p className="text-muted-foreground">
          Browse all available patches in the WIRED CHAOS META ecosystem. Each patch is a firewalled subsystem with its
          own purpose and progression.
        </p>
      </section>

      {/* Category Legend */}
      <section className="flex flex-wrap gap-2">
        {categories.map((cat) => (
          <span key={cat} className={`px-3 py-1.5 text-xs font-medium rounded border ${getCategoryColor(cat)}`}>
            {cat}
          </span>
        ))}
      </section>

      {/* All Patches */}
      <section>
        <PatchGrid patches={PATCHES} />
      </section>
    </div>
  )
}
