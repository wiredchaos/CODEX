import { CinematicHeader } from "@/components/akashic/cinematic-header"
import { SAMPLE_PUBLICATIONS } from "@/config/story-engine"
import Link from "next/link"

export default async function AuthorPage({ params }: { params: Promise<{ handle: string }> }) {
  const { handle } = await params

  // Sample author data
  const author = {
    handle,
    displayName: handle.charAt(0).toUpperCase() + handle.slice(1),
    tier: "chronicler" as const,
    xp: 1250,
    bio: "A digital wanderer crafting narratives from the chaos. Specializes in cyberpunk and occult noir.",
    publications: SAMPLE_PUBLICATIONS.filter((p) => p.author_avatar_id === `avatar-${handle}`),
    stats: {
      totalStories: 3,
      totalWords: 45000,
      avgRating: 4.2,
    },
  }

  return (
    <div className="min-h-screen bg-black">
      <div className="fixed inset-0 pointer-events-none z-50 bg-[url('/textures/scanlines.png')] opacity-5" />

      <div className="relative z-10">
        <CinematicHeader
          title={author.displayName.toUpperCase()}
          subtitle={`${author.tier.toUpperCase()} // CREATOR PROFILE`}
          classification="CREATOR CODEX // AUTHOR"
        />

        <main className="max-w-4xl mx-auto px-6 py-12 space-y-12">
          {/* Profile Header */}
          <section className="flex items-center gap-8 p-6 border border-cyan-500/20 rounded-lg bg-cyan-500/5">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-cyan-500 to-fuchsia-500 flex items-center justify-center shrink-0">
              <span className="text-4xl font-bold text-black">{author.displayName[0]}</span>
            </div>
            <div className="flex-1">
              <h2 className="text-2xl font-mono text-cyan-400 mb-1">@{author.handle}</h2>
              <div className="flex items-center gap-3 mb-3">
                <span className="px-2 py-1 text-xs bg-fuchsia-500/20 text-fuchsia-400 rounded uppercase">
                  {author.tier}
                </span>
                <span className="text-sm text-zinc-400">{author.xp.toLocaleString()} XP</span>
              </div>
              <p className="text-sm text-zinc-400">{author.bio}</p>
            </div>
          </section>

          {/* Stats */}
          <section className="grid grid-cols-3 gap-4">
            <div className="p-4 border border-zinc-800 rounded-lg text-center">
              <div className="text-2xl font-mono text-cyan-400">{author.stats.totalStories}</div>
              <div className="text-xs text-zinc-500">Publications</div>
            </div>
            <div className="p-4 border border-zinc-800 rounded-lg text-center">
              <div className="text-2xl font-mono text-amber-400">{(author.stats.totalWords / 1000).toFixed(1)}k</div>
              <div className="text-xs text-zinc-500">Total Words</div>
            </div>
            <div className="p-4 border border-zinc-800 rounded-lg text-center">
              <div className="text-2xl font-mono text-emerald-400">{author.stats.avgRating}</div>
              <div className="text-xs text-zinc-500">Avg Rating</div>
            </div>
          </section>

          {/* Publications */}
          <section>
            <h3 className="text-xs uppercase tracking-[0.3em] text-red-500 mb-4">Publications</h3>
            <div className="space-y-4">
              {author.publications.length > 0 ? (
                author.publications.map((pub) => (
                  <Link
                    key={pub.id}
                    href={`/books/${pub.book_slug}`}
                    className="block p-4 border border-zinc-800 rounded-lg hover:border-cyan-500/30 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-zinc-200">{pub.book_slug.replace(/-/g, " ").toUpperCase()}</span>
                      <span className="text-xs text-emerald-400">${pub.price}</span>
                    </div>
                  </Link>
                ))
              ) : (
                <div className="p-8 border border-zinc-800 rounded-lg text-center text-zinc-500">
                  No publications yet
                </div>
              )}
            </div>
          </section>
        </main>
      </div>
    </div>
  )
}
