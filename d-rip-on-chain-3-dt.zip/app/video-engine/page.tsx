import { NPCVideoTerminal } from "@/components/video-engine/npc-video-terminal"
import { AVATARS, ENVIRONMENTS, VIDEO_ENGINE_MODULE } from "@/config/video-engine"

export default function VideoEnginePage() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Scanline Overlay */}
      <div className="fixed inset-0 pointer-events-none z-50 opacity-[0.03]">
        <div className="absolute inset-0 bg-[repeating-linear-gradient(0deg,transparent,transparent_2px,rgba(0,255,255,0.03)_2px,rgba(0,255,255,0.03)_4px)]" />
      </div>

      <div className="container mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-block px-3 py-1 bg-red-500/10 border border-red-500/30 rounded text-xs font-mono text-red-400 mb-4">
            WC META LABS // CORE SYSTEMS // RED SEAL
          </div>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-cyan-300 to-cyan-400">
              ANSWER + VIDEO ENGINE
            </span>
          </h1>
          <p className="text-zinc-400 max-w-2xl mx-auto">
            Transform queries into cinematic avatar responses. Text + 3D Video output with attention-optimized hooks and
            environment context.
          </p>
        </div>

        {/* Stats Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-lg p-4 text-center">
            <p className="text-2xl font-bold text-cyan-400">{AVATARS.length}</p>
            <p className="text-xs font-mono text-zinc-500 uppercase">Avatars</p>
          </div>
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-lg p-4 text-center">
            <p className="text-2xl font-bold text-cyan-400">{ENVIRONMENTS.length}</p>
            <p className="text-xs font-mono text-zinc-500 uppercase">Environments</p>
          </div>
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-lg p-4 text-center">
            <p className="text-2xl font-bold text-cyan-400">{VIDEO_ENGINE_MODULE.binds_to.length}</p>
            <p className="text-xs font-mono text-zinc-500 uppercase">System Bindings</p>
          </div>
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-lg p-4 text-center">
            <p className="text-2xl font-bold text-cyan-400">3-12s</p>
            <p className="text-xs font-mono text-zinc-500 uppercase">Video Duration</p>
          </div>
        </div>

        {/* Main Terminal */}
        <NPCVideoTerminal />

        {/* System Info */}
        <div className="mt-12 grid md:grid-cols-2 gap-6">
          {/* Bound Systems */}
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-lg p-6">
            <h3 className="text-sm font-mono text-cyan-400 uppercase tracking-wider mb-4">Bound Systems</h3>
            <div className="flex flex-wrap gap-2">
              {VIDEO_ENGINE_MODULE.binds_to.map((system) => (
                <span key={system} className="px-3 py-1 bg-zinc-800 text-zinc-300 text-xs font-mono rounded">
                  {system.toUpperCase().replace("_", " ")}
                </span>
              ))}
            </div>
          </div>

          {/* Capabilities */}
          <div className="bg-zinc-900/50 border border-zinc-800 rounded-lg p-6">
            <h3 className="text-sm font-mono text-cyan-400 uppercase tracking-wider mb-4">Capabilities</h3>
            <div className="flex flex-wrap gap-2">
              {VIDEO_ENGINE_MODULE.capabilities.map((cap) => (
                <span
                  key={cap}
                  className="px-3 py-1 bg-cyan-500/10 text-cyan-400 text-xs font-mono rounded border border-cyan-500/20"
                >
                  {cap.replace("_", " ").toUpperCase()}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* API Endpoints */}
        <div className="mt-6 bg-zinc-900/50 border border-zinc-800 rounded-lg p-6">
          <h3 className="text-sm font-mono text-cyan-400 uppercase tracking-wider mb-4">API Endpoints</h3>
          <div className="grid sm:grid-cols-2 gap-3 font-mono text-sm">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 text-xs rounded">POST</span>
              <span className="text-zinc-400">/api/npc/answer-video</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 text-xs rounded">POST</span>
              <span className="text-zinc-400">/api/video/generate</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 text-xs rounded">POST</span>
              <span className="text-zinc-400">/api/avatar/render</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 text-xs rounded">POST</span>
              <span className="text-zinc-400">/api/environment/load</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
