"use client"

import { useState } from "react"
import Link from "next/link"
import { Building2, GraduationCap, Briefcase, ArrowRight, Shield, Zap, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

/**
 * WIRED CHAOS LITE OS
 *
 * Simplified entry portal for business users
 * - No Akashic elements
 * - No 589 Theory
 * - No ARG systems
 * - Clean, professional UI
 */

const LITE_PATCHES = [
  {
    id: "business",
    name: "Business Suite",
    description: "Complete business management tools, entity builder, tax wizard, and more",
    icon: Building2,
    href: "/business",
    features: ["Entity Builder", "Tax Wizard", "Trust & Estate", "Global Dashboard"],
    status: "ACTIVE" as const,
  },
  {
    id: "education",
    name: "Education Hub",
    description: "Learning resources, courses, and certification programs",
    icon: GraduationCap,
    href: "/education",
    features: ["Courses", "Certifications", "Resources", "Community"],
    status: "ACTIVE" as const,
  },
  {
    id: "cbe",
    name: "Builder Exchange",
    description: "Connect with entrepreneurs, find collaborators, and scale your ventures",
    icon: Briefcase,
    href: "/business/chaos-builder-exchange",
    features: ["Find Builders", "Post Opportunities", "Concierge Services", "Matching"],
    status: "ACTIVE" as const,
  },
]

export default function LiteOSPage() {
  const [hoveredPatch, setHoveredPatch] = useState<string | null>(null)

  return (
    <div className="min-h-screen bg-background">
      {/* Clean Header */}
      <header className="border-b border-border/50 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Zap className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="font-bold text-lg">WIRED CHAOS</h1>
              <p className="text-xs text-muted-foreground">LITE EDITION</p>
            </div>
          </div>
          <nav className="flex items-center gap-4">
            <Link href="/pricing" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Pricing
            </Link>
            <Link href="/about" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              About
            </Link>
            <Button variant="outline" size="sm" asChild>
              <Link href="/login">Sign In</Link>
            </Button>
            <Button size="sm" asChild>
              <Link href="/register">Get Started</Link>
            </Button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-4xl text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm mb-6">
            <Shield className="w-4 h-4" />
            Enterprise-Ready Platform
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-6 tracking-tight">
            Business Tools for
            <span className="text-primary"> Modern Entrepreneurs</span>
          </h1>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Streamlined business management, education, and networking tools. Built for founders who need to move fast
            without the complexity.
          </p>
          <div className="flex items-center justify-center gap-4">
            <Button size="lg" asChild>
              <Link href="/register">
                Start Free <ArrowRight className="ml-2 w-4 h-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/pricing">View Pricing</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Patches Grid */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-bold mb-3">Available Modules</h2>
            <p className="text-muted-foreground">Select a module to begin. All tools work together seamlessly.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {LITE_PATCHES.map((patch) => {
              const Icon = patch.icon
              return (
                <Card
                  key={patch.id}
                  className={`relative overflow-hidden transition-all duration-300 cursor-pointer group ${
                    hoveredPatch === patch.id ? "border-primary shadow-lg scale-[1.02]" : ""
                  }`}
                  onMouseEnter={() => setHoveredPatch(patch.id)}
                  onMouseLeave={() => setHoveredPatch(null)}
                >
                  <Link href={patch.href} className="block">
                    <CardHeader>
                      <div className="flex items-center justify-between mb-2">
                        <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                          <Icon className="w-6 h-6 text-primary" />
                        </div>
                        <span
                          className={`text-xs px-2 py-1 rounded-full ${
                            patch.status === "ACTIVE"
                              ? "bg-green-500/10 text-green-500"
                              : "bg-amber-500/10 text-amber-500"
                          }`}
                        >
                          {patch.status}
                        </span>
                      </div>
                      <CardTitle className="text-xl">{patch.name}</CardTitle>
                      <CardDescription>{patch.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {patch.features.map((feature, i) => (
                          <li key={i} className="flex items-center text-sm text-muted-foreground">
                            <ChevronRight className="w-4 h-4 mr-2 text-primary" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                      <div className="mt-4 flex items-center text-primary font-medium text-sm group-hover:translate-x-1 transition-transform">
                        Enter Module <ArrowRight className="ml-2 w-4 h-4" />
                      </div>
                    </CardContent>
                  </Link>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Quick Stats */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { label: "Active Users", value: "2,500+" },
              { label: "Businesses Built", value: "890+" },
              { label: "Courses Available", value: "45" },
              { label: "Builder Connections", value: "5,800+" },
            ].map((stat, i) => (
              <div key={i}>
                <div className="text-3xl font-bold text-primary">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 px-4 bg-primary/5">
        <div className="container mx-auto max-w-3xl text-center">
          <h2 className="text-2xl font-bold mb-4">Ready to Build?</h2>
          <p className="text-muted-foreground mb-6">
            Join thousands of entrepreneurs using WIRED CHAOS to streamline their business operations.
          </p>
          <div className="flex items-center justify-center gap-4">
            <Button size="lg" asChild>
              <Link href="/register">Create Free Account</Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/">View Full Platform</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 py-8 px-4">
        <div className="container mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-primary" />
            <span className="font-semibold">WIRED CHAOS LITE</span>
          </div>
          <div className="flex items-center gap-6 text-sm text-muted-foreground">
            <Link href="/terms" className="hover:text-foreground transition-colors">
              Terms
            </Link>
            <Link href="/privacy" className="hover:text-foreground transition-colors">
              Privacy
            </Link>
            <Link href="/support" className="hover:text-foreground transition-colors">
              Support
            </Link>
          </div>
          <p className="text-sm text-muted-foreground">© 2025 WIRED CHAOS META. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
