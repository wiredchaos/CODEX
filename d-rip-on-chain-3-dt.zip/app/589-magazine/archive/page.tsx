"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Eye, Download, Search, Calendar } from "lucide-react"
import Link from "next/link"

// Mock archive data - in production this would come from database
const MOCK_ISSUES = [
  {
    issueNumber: "2412-01",
    theme: "589-reset",
    headline: "XRP BREAKOUT: Price Action Validates 589 Theory",
    hiddenThread: "The ledger remembers what the world forgets.",
    createdAt: "2024-12-01T00:00:00Z",
    colorAccent: "#FFD700",
  },
  {
    issueNumber: "2412-02",
    theme: "akashic-surge",
    headline: "GLOBAL AWAKENING: Consciousness Metrics Spike Worldwide",
    hiddenThread: "589 encoded in the silence between transactions.",
    createdAt: "2024-12-03T00:00:00Z",
    colorAccent: "#00FFFF",
  },
  {
    issueNumber: "2412-03",
    theme: "trojan-ripple-thesis",
    headline: "INSTITUTIONAL ADOPTION: Central Banks Quietly Accumulate XRP",
    hiddenThread: "The trojan sleeps until the signal aligns.",
    createdAt: "2024-12-05T00:00:00Z",
    colorAccent: "#8B00FF",
  },
  {
    issueNumber: "2411-08",
    theme: "ledger-fracture",
    headline: "BLOCKCHAIN CRISIS: Major Protocol Vulnerability Exposed",
    hiddenThread: "What ripples through cannot be stopped.",
    createdAt: "2024-11-28T00:00:00Z",
    colorAccent: "#FF0040",
  },
  {
    issueNumber: "2411-07",
    theme: "wlfi-sector-shift",
    headline: "POLITICAL CRYPTO: World Liberty Financial Announces Major Initiative",
    hiddenThread: "The frequency was never lost—only waiting.",
    createdAt: "2024-11-25T00:00:00Z",
    colorAccent: "#FF6600",
  },
  {
    issueNumber: "2411-06",
    theme: "frequency-breach",
    headline: "SIGNAL DETECTED: Unknown Broadcast Penetrates Global Networks",
    hiddenThread: "Every node carries the echo of the original transmission.",
    createdAt: "2024-11-22T00:00:00Z",
    colorAccent: "#FF00FF",
  },
]

export default function MagazineArchivePage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedTheme, setSelectedTheme] = useState<string | null>(null)

  const filteredIssues = MOCK_ISSUES.filter((issue) => {
    const matchesSearch =
      !searchQuery ||
      issue.headline.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.hiddenThread.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.issueNumber.includes(searchQuery)

    const matchesTheme = !selectedTheme || issue.theme === selectedTheme

    return matchesSearch && matchesTheme
  })

  const themes = [...new Set(MOCK_ISSUES.map((i) => i.theme))]

  return (
    <main className="min-h-screen bg-black text-white">
      <header className="border-b border-neutral-800 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/589-magazine" className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-red-500 rounded flex items-center justify-center font-bold">
                589
              </div>
              <div>
                <h1 className="text-xl font-bold">589 MAGAZINE</h1>
                <p className="text-xs text-neutral-400">ISSUE ARCHIVE</p>
              </div>
            </Link>
          </div>
          <nav className="flex items-center gap-4">
            <Link href="/589-magazine" className="text-sm text-neutral-400 hover:text-white">
              Generator
            </Link>
            <Link href="/589-magazine/billboards" className="text-sm text-neutral-400 hover:text-white">
              3D Billboards
            </Link>
          </nav>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8 space-y-6">
        {/* Search and Filter */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search issues by headline, lore, or issue number..."
              className="pl-10 bg-neutral-950 border-neutral-800"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button
              variant={selectedTheme === null ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedTheme(null)}
              className="text-xs"
            >
              All Themes
            </Button>
            {themes.map((theme) => (
              <Button
                key={theme}
                variant={selectedTheme === theme ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedTheme(theme)}
                className="text-xs"
              >
                {theme.replace(/-/g, " ")}
              </Button>
            ))}
          </div>
        </div>

        {/* Issues Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredIssues.map((issue) => (
            <Card key={issue.issueNumber} className="border-neutral-800 bg-neutral-950 overflow-hidden group">
              {/* Cover Preview */}
              <div
                className="aspect-video relative"
                style={{
                  background: `linear-gradient(135deg, #0A0A0A 0%, ${issue.colorAccent}22 50%, #0A0A0A 100%)`,
                }}
              >
                <div className="absolute inset-0 p-4 flex flex-col justify-between">
                  <div className="flex items-start justify-between">
                    <div className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-red-500">
                      589
                    </div>
                    <Badge className="text-[10px]" style={{ backgroundColor: issue.colorAccent, color: "#000" }}>
                      {issue.theme.toUpperCase().replace(/-/g, " ")}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-sm font-bold leading-tight line-clamp-2">{issue.headline}</p>
                  </div>
                </div>
                <div className="absolute bottom-2 right-2 text-4xl font-black text-yellow-500/10">589</div>

                {/* Hover overlay */}
                <div className="absolute inset-0 bg-black/80 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                  <Button size="sm" variant="outline" className="text-xs bg-transparent">
                    <Eye className="w-3 h-3 mr-1" />
                    View
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs bg-transparent">
                    <Download className="w-3 h-3 mr-1" />
                    4K PNG
                  </Button>
                </div>
              </div>

              <CardContent className="p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-mono text-neutral-400">#{issue.issueNumber}</span>
                  <div className="flex items-center gap-1 text-xs text-neutral-500">
                    <Calendar className="w-3 h-3" />
                    {new Date(issue.createdAt).toLocaleDateString()}
                  </div>
                </div>
                <p className="text-xs text-purple-300 italic line-clamp-2">"{issue.hiddenThread}"</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredIssues.length === 0 && (
          <div className="text-center py-12">
            <p className="text-neutral-500">No issues match your search criteria.</p>
          </div>
        )}

        {/* Archive Stats */}
        <Card className="border-neutral-800 bg-neutral-950">
          <CardHeader>
            <CardTitle className="text-sm">ARCHIVE STATISTICS</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-cyan-400">{MOCK_ISSUES.length}</div>
                <div className="text-xs text-neutral-500">Total Issues</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-red-400">{themes.length}</div>
                <div className="text-xs text-neutral-500">Theme Categories</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-yellow-400">4</div>
                <div className="text-xs text-neutral-500">3D Deployments</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-purple-400">589</div>
                <div className="text-xs text-neutral-500">Prophecy Code</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  )
}
