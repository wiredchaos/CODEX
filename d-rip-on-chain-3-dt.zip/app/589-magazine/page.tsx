"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Loader2, Zap, Radio, BookOpen, Eye, Download } from "lucide-react"
import Link from "next/link"

type MagazineTheme =
  | "akashic-surge"
  | "ledger-fracture"
  | "589-reset"
  | "trojan-ripple-thesis"
  | "tinfoil-confirmation-event"
  | "wlfi-sector-shift"
  | "timeline-collision"
  | "frequency-breach"

interface ThemeConfig {
  id: string
  label: string
  signalTriggers: string[]
  colorAccent: string
}

interface MagazineCover {
  issueNumber: string
  theme: MagazineTheme
  loreLayer: {
    hiddenThread: string
    distortionLayer: string
    ledgerFrequencyNotes: string
    timelineCollisions: string[]
    akashicOverlay: string
  }
  newsLayer: {
    headlineTier: string[]
    signalTier: string[]
    riskTier: string[]
    counterNarrativeTier: string[]
  }
  narrativeHook: string
  timelineMarker: string
  vault33Connection: string
}

export default function Magazine589Page() {
  const [themes, setThemes] = useState<ThemeConfig[]>([])
  const [selectedTheme, setSelectedTheme] = useState<string>("")
  const [generating, setGenerating] = useState(false)
  const [currentCover, setCurrentCover] = useState<MagazineCover | null>(null)
  const [systemStatus, setSystemStatus] = useState<any>(null)

  useEffect(() => {
    // Fetch available themes
    fetch("/api/magazine/themes")
      .then((r) => r.json())
      .then((data) => {
        setThemes(data.themes || [])
        if (data.themes?.length > 0) {
          setSelectedTheme(data.themes[0].id)
        }
      })
      .catch(console.error)

    // Fetch system status
    fetch("/api/magazine/status")
      .then((r) => r.json())
      .then(setSystemStatus)
      .catch(console.error)
  }, [])

  const generateIssue = async () => {
    setGenerating(true)
    try {
      const res = await fetch("/api/magazine/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ theme: selectedTheme }),
      })
      const data = await res.json()
      if (data.cover) {
        setCurrentCover(data.cover)
      }
    } catch (error) {
      console.error("Generation failed:", error)
    } finally {
      setGenerating(false)
    }
  }

  const selectedThemeConfig = themes.find((t) => t.id === selectedTheme)

  return (
    <main className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="border-b border-neutral-800 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-red-500 rounded flex items-center justify-center font-bold">
              589
            </div>
            <div>
              <h1 className="text-xl font-bold">589 MAGAZINE</h1>
              <p className="text-xs text-neutral-400">SWARM ENGINE v1.0</p>
            </div>
          </div>
          <nav className="flex items-center gap-4">
            <Link href="/" className="text-sm text-neutral-400 hover:text-white">
              Home
            </Link>
            <Link href="/vault33" className="text-sm text-neutral-400 hover:text-white">
              Vault 33
            </Link>
            <Link href="/vrg33589" className="text-sm text-neutral-400 hover:text-white">
              VRG33589
            </Link>
          </nav>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
        {/* System Status Banner */}
        {systemStatus && (
          <div className="flex items-center justify-between p-4 border border-neutral-800 rounded-lg bg-neutral-950">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                <span className="text-sm text-neutral-400">{systemStatus.swarmEngine?.status}</span>
              </div>
              <Badge variant="outline" className="border-cyan-500/50 text-cyan-400">
                PATCH FIREWALL: {systemStatus.patchFirewall?.status}
              </Badge>
            </div>
            <div className="flex items-center gap-2 text-xs text-neutral-500">
              <span>Agents: {systemStatus.swarmEngine?.agents?.length || 5}</span>
              <span>|</span>
              <span>Themes: {systemStatus.swarmEngine?.availableThemes?.length || 8}</span>
            </div>
          </div>
        )}

        {/* Generation Controls */}
        <Card className="border-neutral-800 bg-neutral-950">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-yellow-500" />
              Issue Generator
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <label className="text-sm text-neutral-400">Select Theme</label>
                <Select value={selectedTheme} onValueChange={setSelectedTheme}>
                  <SelectTrigger className="bg-black border-neutral-700">
                    <SelectValue placeholder="Choose theme..." />
                  </SelectTrigger>
                  <SelectContent>
                    {themes.map((theme) => (
                      <SelectItem key={theme.id} value={theme.id}>
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: theme.colorAccent }} />
                          {theme.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedThemeConfig && (
                <div className="md:col-span-2 space-y-2">
                  <label className="text-sm text-neutral-400">Signal Triggers</label>
                  <div className="flex flex-wrap gap-2">
                    {selectedThemeConfig.signalTriggers.map((trigger, i) => (
                      <Badge key={i} variant="outline" className="border-neutral-700 text-neutral-300">
                        {trigger}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <Button
              onClick={generateIssue}
              disabled={generating || !selectedTheme}
              className="w-full bg-gradient-to-r from-cyan-600 to-red-600 hover:from-cyan-500 hover:to-red-500"
            >
              {generating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  SWARM GENERATING...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 mr-2" />
                  GENERATE ISSUE
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Generated Cover Display */}
        {currentCover && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Cover Preview */}
            <Card className="border-neutral-800 bg-neutral-950 overflow-hidden">
              <div
                className="aspect-video relative"
                style={{
                  background: `linear-gradient(135deg, #0A0A0A 0%, ${selectedThemeConfig?.colorAccent}22 50%, #0A0A0A 100%)`,
                }}
              >
                {/* Cover mockup */}
                <div className="absolute inset-0 p-6 flex flex-col justify-between">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="text-6xl font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-red-500">
                        589
                      </div>
                      <div className="text-sm font-mono text-neutral-500">ISSUE #{currentCover.issueNumber}</div>
                    </div>
                    <Badge
                      className="text-xs"
                      style={{
                        backgroundColor: selectedThemeConfig?.colorAccent,
                        color: "#000",
                      }}
                    >
                      {currentCover.theme.toUpperCase().replace(/-/g, " ")}
                    </Badge>
                  </div>

                  <div className="space-y-2">
                    <h2 className="text-2xl font-bold leading-tight">{currentCover.newsLayer.headlineTier[0]}</h2>
                    <p className="text-sm text-neutral-400 italic">"{currentCover.loreLayer.hiddenThread}"</p>
                  </div>

                  <div className="flex items-center justify-between text-xs text-neutral-500">
                    <span>{currentCover.timelineMarker}</span>
                    <span>@neurometax</span>
                  </div>
                </div>

                {/* 589 Sigil watermark */}
                <div className="absolute bottom-4 right-4 text-6xl font-black text-yellow-500/10">589</div>
              </div>

              <CardContent className="p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                    <Eye className="w-4 h-4 mr-2" />
                    Preview 3D
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                    <Download className="w-4 h-4 mr-2" />
                    Export 4K
                  </Button>
                </div>
                <p className="text-xs text-neutral-500 text-center">{currentCover.vault33Connection}</p>
              </CardContent>
            </Card>

            {/* Content Layers */}
            <div className="space-y-4">
              {/* Lore Layer */}
              <Card className="border-neutral-800 bg-neutral-950">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-purple-400" />
                    NEURO LORE BOT OUTPUT
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <div>
                    <span className="text-neutral-500">Hidden Thread:</span>
                    <p className="text-purple-300 italic">"{currentCover.loreLayer.hiddenThread}"</p>
                  </div>
                  <div>
                    <span className="text-neutral-500">Distortion Layer:</span>
                    <p className="text-neutral-300">{currentCover.loreLayer.distortionLayer}</p>
                  </div>
                  <div>
                    <span className="text-neutral-500">Akashic Overlay:</span>
                    <p className="text-cyan-300">{currentCover.loreLayer.akashicOverlay}</p>
                  </div>
                  <div>
                    <span className="text-neutral-500">Timeline Collisions:</span>
                    <ul className="list-disc list-inside text-neutral-400 text-xs">
                      {currentCover.loreLayer.timelineCollisions.map((tc, i) => (
                        <li key={i}>{tc}</li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>

              {/* News Layer */}
              <Card className="border-neutral-800 bg-neutral-950">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Radio className="w-4 h-4 text-red-400" />
                    NEURO NEWS BOT OUTPUT
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <div>
                    <span className="text-neutral-500">Headlines:</span>
                    <ul className="space-y-1">
                      {currentCover.newsLayer.headlineTier.map((h, i) => (
                        <li key={i} className="text-red-300 font-medium">
                          {h}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <span className="text-neutral-500">Signals:</span>
                    <ul className="list-disc list-inside text-neutral-400 text-xs">
                      {currentCover.newsLayer.signalTier.map((s, i) => (
                        <li key={i}>{s}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <span className="text-neutral-500">Risk Assessment:</span>
                    <ul className="space-y-1">
                      {currentCover.newsLayer.riskTier.map((r, i) => (
                        <li key={i} className="text-yellow-400 text-xs">
                          {r}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {/* Swarm Agents Status */}
        <Card className="border-neutral-800 bg-neutral-950">
          <CardHeader>
            <CardTitle className="text-sm">SWARM AGENTS</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {[
                { name: "Artist", fn: "Layout & Typography" },
                { name: "Archivist", fn: "Lore Attachments" },
                { name: "Composer", fn: "Layer Integration" },
                { name: "Fabricator", fn: "4K + 3D Render" },
                { name: "Deployer", fn: "3D Environment" },
              ].map((agent, i) => (
                <div key={i} className="p-3 border border-neutral-800 rounded-lg text-center">
                  <div className="w-8 h-8 mx-auto mb-2 bg-gradient-to-br from-cyan-500/20 to-red-500/20 rounded-full flex items-center justify-center">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full" />
                  </div>
                  <div className="text-sm font-medium">{agent.name}</div>
                  <div className="text-[10px] text-neutral-500">{agent.fn}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  )
}
