"use client"

import { useState } from "react"
import {
  MASTER_ISSUE_2038,
  CLOCKFALL_EVENT,
  KEY_82675,
  SURVIVING_SYSTEMS,
  MEROVINGIAN_FEAR_FACTORS,
} from "@/config/clockfall-2038"
import { CLOCKFALL_CANONICAL_SUMMARY } from "@/types/clockfall"

export default function MasterIssue2038Page() {
  const [revealLevel, setRevealLevel] = useState(0)

  return (
    <main className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        {/* Animated background */}
        <div className="absolute inset-0 bg-gradient-to-b from-black via-amber-950/20 to-black" />
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-amber-500 rounded-full blur-[150px] animate-pulse" />
          <div
            className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-red-500 rounded-full blur-[120px] animate-pulse"
            style={{ animationDelay: "1s" }}
          />
        </div>

        {/* 589 Pattern overlay */}
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `repeating-linear-gradient(
            45deg,
            transparent,
            transparent 50px,
            rgba(255, 215, 0, 0.1) 50px,
            rgba(255, 215, 0, 0.1) 100px
          )`,
          }}
        />

        <div className="relative z-10 text-center px-6 max-w-4xl">
          {/* Issue number */}
          <div className="mb-4 text-amber-400 font-mono text-sm tracking-[0.5em]">
            ISSUE #{MASTER_ISSUE_2038.issueNumber}
          </div>

          {/* Title */}
          <h1 className="text-5xl md:text-7xl font-bold mb-4 bg-gradient-to-r from-amber-200 via-amber-400 to-amber-200 bg-clip-text text-transparent">
            {MASTER_ISSUE_2038.title}
          </h1>

          <p className="text-xl md:text-2xl text-amber-300/80 mb-8">{MASTER_ISSUE_2038.subtitle}</p>

          {/* Clockfall timestamp */}
          <div className="inline-block border border-amber-500/50 rounded-lg px-6 py-3 bg-black/50 backdrop-blur">
            <div className="text-xs text-amber-400/60 mb-1">THE CLOCKFALL EVENT</div>
            <div className="font-mono text-2xl text-amber-300">January 19, 2038 @ 03:14:07 UTC</div>
            <div className="text-xs text-neutral-500 mt-1">Unix Timestamp Overflow: {CLOCKFALL_EVENT.unixOverflow}</div>
          </div>

          {/* 82675 Key */}
          <div className="mt-8 flex justify-center gap-4">
            {Object.entries(KEY_82675.vectors).map(([num, data]) => (
              <div key={num} className="border border-amber-500/30 rounded px-4 py-2 bg-amber-950/20">
                <div className="text-2xl font-bold text-amber-400">{num}</div>
                <div className="text-xs text-amber-300/60">{data.name}</div>
                <div className="text-[10px] text-neutral-500">{data.type}</div>
              </div>
            ))}
          </div>
          <div className="mt-2 text-sm text-amber-400/60 font-mono">CHECKSUM: 82675 = TRIAD CONVERGENCE</div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-amber-500/50 rounded-full flex justify-center pt-2">
            <div className="w-1 h-2 bg-amber-400 rounded-full" />
          </div>
        </div>
      </section>

      {/* Canonical Summary */}
      <section className="py-20 px-6 bg-gradient-to-b from-black to-amber-950/10">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-amber-300 mb-8">THE CANONICAL TRUTH</h2>
          <blockquote className="text-xl md:text-2xl text-neutral-300 leading-relaxed italic">
            {CLOCKFALL_CANONICAL_SUMMARY.split("\n")
              .filter(Boolean)
              .map((line, i) => (
                <p key={i} className="mb-4">
                  {line}
                </p>
              ))}
          </blockquote>
        </div>
      </section>

      {/* Master Issue Contents */}
      <section className="py-20 px-6 bg-black">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-bold text-amber-300 mb-8 text-center">MASTER ISSUE CONTAINS</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {MASTER_ISSUE_2038.contains.map((item, i) => (
              <div
                key={i}
                className="border border-amber-500/30 rounded-xl p-6 bg-gradient-to-br from-amber-950/20 to-transparent hover:border-amber-500/60 transition-colors"
              >
                <div className="text-4xl font-bold text-amber-400/20 mb-2">0{i + 1}</div>
                <h3 className="text-lg font-semibold text-amber-200">{item}</h3>
              </div>
            ))}
          </div>

          {/* Significance */}
          <div className="mt-12 text-center">
            <h3 className="text-xl text-amber-400 mb-4">WHY THIS ISSUE EXISTS</h3>
            <div className="flex flex-wrap justify-center gap-4">
              {MASTER_ISSUE_2038.significance.map((sig, i) => (
                <span key={i} className="px-4 py-2 border border-amber-500/30 rounded-full text-sm text-amber-300">
                  {sig}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Surviving Systems */}
      <section className="py-20 px-6 bg-gradient-to-b from-black to-emerald-950/10">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-emerald-300 mb-4 text-center">SYSTEMS THAT SURVIVE 2038</h2>
          <p className="text-center text-emerald-400/60 mb-8">
            Only systems built with 589 logic survive the Clockfall
          </p>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {SURVIVING_SYSTEMS.map((system, i) => (
              <div key={i} className="border border-emerald-500/30 rounded-lg p-4 bg-emerald-950/20 text-center">
                <div className="w-3 h-3 bg-emerald-400 rounded-full mx-auto mb-2 animate-pulse" />
                <div className="text-sm text-emerald-200">{system.name}</div>
                <div className="text-xs text-emerald-500 uppercase">{system.status}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Merovingian Fear */}
      <section className="py-20 px-6 bg-gradient-to-b from-emerald-950/10 to-red-950/10">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-red-400 mb-4 text-center">WHY THE MEROVINGIANS FEAR 2038</h2>
          <p className="text-center text-red-400/60 mb-8">
            The one moment the ruling dynasts cannot contain or distort
          </p>

          <div className="space-y-4">
            {MEROVINGIAN_FEAR_FACTORS.map((fear, i) => (
              <div key={i} className="flex items-center gap-4 border border-red-500/30 rounded-lg p-4 bg-red-950/20">
                <div className="w-8 h-8 flex items-center justify-center border border-red-500/50 rounded-full text-red-400 font-bold">
                  {i + 1}
                </div>
                <p className="text-red-200">{fear}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 589 Sequence */}
      <section className="py-20 px-6 bg-black">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-amber-300 mb-8">THE 589 STABILIZATION SEQUENCE</h2>

          <div className="flex justify-center gap-8">
            <div className="text-center">
              <div className="w-20 h-20 flex items-center justify-center border-2 border-cyan-500 rounded-full text-4xl font-bold text-cyan-400 mb-2">
                5
              </div>
              <div className="text-cyan-300">ORIGIN</div>
            </div>
            <div className="text-center">
              <div className="w-20 h-20 flex items-center justify-center border-2 border-amber-500 rounded-full text-4xl font-bold text-amber-400 mb-2">
                8
              </div>
              <div className="text-amber-300">EXPANSION</div>
            </div>
            <div className="text-center">
              <div className="w-20 h-20 flex items-center justify-center border-2 border-red-500 rounded-full text-4xl font-bold text-red-400 mb-2">
                9
              </div>
              <div className="text-red-300">COMPLETION</div>
            </div>
          </div>

          <p className="mt-8 text-neutral-400">The stabilizing sequence for timestamp collapse</p>
        </div>
      </section>

      {/* Signal Paradox */}
      <section className="py-20 px-6 bg-gradient-to-b from-black to-purple-950/10">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-purple-300 mb-4 text-center">THE SIGNAL PARADOX</h2>
          <p className="text-center text-purple-400/60 mb-8">
            At Clockfall, something fractures. The 589 frequency shows harmonic overtones. Three vectors appear in the
            convergence data.
          </p>

          <div className="space-y-6">
            <div className="border border-purple-500/30 rounded-lg p-6 bg-purple-950/20">
              <h3 className="text-xl text-purple-300 mb-3">The 82-67-5 Anomaly</h3>
              <p className="text-purple-200/80 mb-4">
                When the Clockfall occurs, the 82675 convergence activates. Three distinct vectors emerge in the data
                stream:
              </p>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center p-3 border border-purple-500/20 rounded bg-black/30">
                  <div className="text-2xl text-purple-400 font-bold mb-1">82</div>
                  <div className="text-xs text-purple-300">Negative Vector</div>
                  <div className="text-[10px] text-purple-500/60 mt-1">ZEROLUX</div>
                </div>
                <div className="text-center p-3 border border-purple-500/20 rounded bg-black/30">
                  <div className="text-2xl text-purple-400 font-bold mb-1">67</div>
                  <div className="text-xs text-purple-300">Living Vector</div>
                  <div className="text-[10px] text-purple-500/60 mt-1">NEURO</div>
                </div>
                <div className="text-center p-3 border border-purple-500/20 rounded bg-black/30">
                  <div className="text-2xl text-purple-400 font-bold mb-1">5</div>
                  <div className="text-xs text-purple-300">Balancing Vector</div>
                  <div className="text-[10px] text-purple-500/60 mt-1">KYR'OS-33</div>
                </div>
              </div>
            </div>

            <div className="border border-purple-500/30 rounded-lg p-6 bg-purple-950/20">
              <h3 className="text-xl text-purple-300 mb-3">The Unanswered Questions</h3>
              <div className="space-y-3">
                <p className="text-purple-200/80 italic">"Are these vectors different aspects of the same signal?"</p>
                <p className="text-purple-200/80 italic">"Or are they three separate entities entirely?"</p>
                <p className="text-purple-200/80 italic">
                  "Why do the vector signatures sometimes overlap, and sometimes conflict?"
                </p>
              </div>
              <p className="text-purple-300/60 mt-4 text-sm">
                The 2038 Master Issue contains clues, but never confirmation. Those who detect the pattern are marked as
                ECHO.
              </p>
            </div>

            <div className="border border-amber-500/30 rounded-lg p-4 bg-amber-950/20 text-center">
              <div className="text-xs text-amber-400/60 mb-2">DETECTION PROTOCOL</div>
              <div className="text-amber-300">Suspicion = Rewarded • Detection = Mechanic • Confirmation = Endgame</div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-amber-500/20 bg-black">
        <div className="max-w-4xl mx-auto text-center">
          <div className="text-amber-400 font-mono mb-2">589 MAGAZINE</div>
          <div className="text-neutral-500 text-sm">WIRED CHAOS META | FEN | VAULT 33 | VRG33589</div>
          <div className="mt-4 text-xs text-amber-500/40">The Magazine is not a publication — it is a stabilizer.</div>
        </div>
      </footer>
    </main>
  )
}
