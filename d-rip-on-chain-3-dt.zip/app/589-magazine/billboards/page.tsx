"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Monitor, Box, Zap, Eye, Settings } from "lucide-react"
import Link from "next/link"

const DEPLOYMENT_TARGETS = [
  {
    id: "gate-33-3",
    name: "Gate 33.3 Boards",
    environment: "gate-33-3-plaza",
    description: "Primary entrance billboards in the Gate 33.3 plaza",
    status: "ACTIVE",
    boardCount: 4,
    lastDeployed: "2024-12-07T10:30:00Z",
  },
  {
    id: "vrg33589",
    name: "VRG33589 Dimension Walls",
    environment: "vrg33589-core",
    description: "Floating billboard panels in the VRG33589 dimensional space",
    status: "ACTIVE",
    boardCount: 8,
    lastDeployed: "2024-12-07T09:15:00Z",
  },
  {
    id: "vault33",
    name: "Vault 33 Landing Atrium",
    environment: "vault33-entrance",
    description: "Welcome screens in the Vault 33 secure atrium",
    status: "ACTIVE",
    boardCount: 2,
    lastDeployed: "2024-12-06T22:45:00Z",
  },
  {
    id: "chaos-os-dashboard",
    name: "CHAOS OS Dashboard Panels",
    environment: "chaos-os-main",
    description: "Live magazine feed on CHAOS OS system dashboards",
    status: "ACTIVE",
    boardCount: 6,
    lastDeployed: "2024-12-07T11:00:00Z",
  },
]

const BILLBOARD_CONFIG = {
  resolution: "4096 × 2160",
  aspectRatio: "16:9",
  perspectiveTilt: "22–33°",
  lighting: "Neon cyan rim-light + shadow cast",
  watermark: "@neurometax",
  behaviors: ["Rotate on interact", "Glow pulse on new issue", "NEURO whisper on hover"],
}

export default function BillboardsPage() {
  const [selectedTarget, setSelectedTarget] = useState<string | null>(null)

  return (
    <main className="min-h-screen bg-black text-white">
      <header className="border-b border-neutral-800 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/589-magazine" className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-red-500 rounded flex items-center justify-center font-bold">
                589
              </div>
              <div>
                <h1 className="text-xl font-bold">589 MAGAZINE</h1>
                <p className="text-xs text-neutral-400">3D BILLBOARD DEPLOYMENT</p>
              </div>
            </Link>
          </div>
          <nav className="flex items-center gap-4">
            <Link href="/589-magazine" className="text-sm text-neutral-400 hover:text-white">
              Generator
            </Link>
            <Link href="/589-magazine/archive" className="text-sm text-neutral-400 hover:text-white">
              Archive
            </Link>
          </nav>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
        {/* Billboard Standards */}
        <Card className="border-neutral-800 bg-neutral-950">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5 text-cyan-400" />
              Billboard Render Standards
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-3 border border-neutral-800 rounded-lg">
                <div className="text-xs text-neutral-500 mb-1">Resolution</div>
                <div className="text-sm font-mono text-cyan-400">{BILLBOARD_CONFIG.resolution}</div>
              </div>
              <div className="p-3 border border-neutral-800 rounded-lg">
                <div className="text-xs text-neutral-500 mb-1">Aspect Ratio</div>
                <div className="text-sm font-mono text-cyan-400">{BILLBOARD_CONFIG.aspectRatio}</div>
              </div>
              <div className="p-3 border border-neutral-800 rounded-lg">
                <div className="text-xs text-neutral-500 mb-1">Perspective Tilt</div>
                <div className="text-sm font-mono text-cyan-400">{BILLBOARD_CONFIG.perspectiveTilt}</div>
              </div>
              <div className="p-3 border border-neutral-800 rounded-lg">
                <div className="text-xs text-neutral-500 mb-1">Watermark</div>
                <div className="text-sm font-mono text-cyan-400">{BILLBOARD_CONFIG.watermark}</div>
              </div>
            </div>
            <div className="mt-4 p-3 border border-neutral-800 rounded-lg">
              <div className="text-xs text-neutral-500 mb-2">Interactive Behaviors</div>
              <div className="flex flex-wrap gap-2">
                {BILLBOARD_CONFIG.behaviors.map((behavior, i) => (
                  <Badge key={i} variant="outline" className="border-neutral-700 text-neutral-300">
                    {behavior}
                  </Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Deployment Targets */}
        <div className="space-y-4">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <Box className="w-5 h-5 text-purple-400" />
            3D Environment Deployment Targets
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {DEPLOYMENT_TARGETS.map((target) => (
              <Card
                key={target.id}
                className={`border-neutral-800 bg-neutral-950 cursor-pointer transition-all ${
                  selectedTarget === target.id ? "ring-2 ring-cyan-500" : "hover:border-neutral-700"
                }`}
                onClick={() => setSelectedTarget(selectedTarget === target.id ? null : target.id)}
              >
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base">{target.name}</CardTitle>
                    <Badge
                      variant="outline"
                      className={
                        target.status === "ACTIVE"
                          ? "border-emerald-500/50 text-emerald-400"
                          : "border-yellow-500/50 text-yellow-400"
                      }
                    >
                      {target.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-neutral-400">{target.description}</p>

                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-4">
                      <span className="text-neutral-500">
                        <Monitor className="w-3 h-3 inline mr-1" />
                        {target.boardCount} boards
                      </span>
                      <span className="text-neutral-500 font-mono">{target.environment}</span>
                    </div>
                    <span className="text-neutral-600">Last: {new Date(target.lastDeployed).toLocaleTimeString()}</span>
                  </div>

                  {selectedTarget === target.id && (
                    <div className="pt-3 border-t border-neutral-800 space-y-2">
                      <div className="flex gap-2">
                        <Button size="sm" className="flex-1 bg-cyan-600 hover:bg-cyan-500">
                          <Zap className="w-3 h-3 mr-1" />
                          Deploy Latest Issue
                        </Button>
                        <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                          <Eye className="w-3 h-3 mr-1" />
                          Preview Environment
                        </Button>
                      </div>
                      <p className="text-[10px] text-neutral-600 text-center">
                        3D environment preview will embed Spline/Hyperfy viewer when connected
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* 3D Preview Placeholder */}
        <Card className="border-neutral-800 bg-neutral-950">
          <CardHeader>
            <CardTitle className="text-sm">3D ENVIRONMENT PREVIEW</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="aspect-video bg-gradient-to-br from-neutral-900 to-neutral-950 rounded-lg flex items-center justify-center border border-neutral-800">
              <div className="text-center space-y-3">
                <Box className="w-12 h-12 mx-auto text-neutral-700" />
                <div>
                  <p className="text-neutral-500">3D Billboard Preview</p>
                  <p className="text-xs text-neutral-600">
                    This will embed real 3D scenes (Spline/Hyperfy) when connected
                  </p>
                </div>
                <Button variant="outline" size="sm" disabled>
                  Connect 3D Provider
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Deployment Log */}
        <Card className="border-neutral-800 bg-neutral-950">
          <CardHeader>
            <CardTitle className="text-sm">RECENT DEPLOYMENTS</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-xs font-mono">
              {[
                { time: "11:00:33", target: "chaos-os-dashboard", issue: "2412-03", status: "SUCCESS" },
                { time: "10:30:17", target: "gate-33-3", issue: "2412-03", status: "SUCCESS" },
                { time: "09:15:42", target: "vrg33589", issue: "2412-02", status: "SUCCESS" },
                { time: "08:45:01", target: "vault33", issue: "2412-02", status: "SUCCESS" },
              ].map((log, i) => (
                <div key={i} className="flex items-center justify-between p-2 bg-neutral-900 rounded">
                  <div className="flex items-center gap-3">
                    <span className="text-neutral-600">{log.time}</span>
                    <span className="text-neutral-400">{log.target}</span>
                    <span className="text-cyan-400">#{log.issue}</span>
                  </div>
                  <Badge
                    variant="outline"
                    className={
                      log.status === "SUCCESS"
                        ? "border-emerald-500/50 text-emerald-400"
                        : "border-red-500/50 text-red-400"
                    }
                  >
                    {log.status}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  )
}
