"use client"

import { useEffect, useState } from "react"
import { Twitter, Youtube, Music2, Radio, Users, Zap, ExternalLink, Hash } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

const SOCIAL_ACCOUNTS = {
  twitter: {
    main: "wiredchaosmeta",
    neuro: "neurometax",
  },
  hashtags: ["#wiredchaos", "#vault33", "#neuro589", "#33fm", "#akiracodex"],
}

export default function SocialPage() {
  const [twitterLoaded, setTwitterLoaded] = useState(false)

  useEffect(() => {
    // Load Twitter embed script once
    if (typeof window !== "undefined" && !twitterLoaded) {
      const script = document.createElement("script")
      script.setAttribute("src", "https://platform.twitter.com/widgets.js")
      script.setAttribute("async", "true")
      script.onload = () => setTwitterLoaded(true)
      document.body.appendChild(script)
    }
  }, [twitterLoaded])

  return (
    <div className="min-h-screen w-full bg-black text-white">
      {/* Hero Header */}
      <div className="relative border-b border-cyan-900/50 bg-gradient-to-b from-cyan-950/20 to-black">
        <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-5" />
        <div className="relative max-w-7xl mx-auto px-6 py-12">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 rounded-lg bg-cyan-500/10 border border-cyan-500/30">
              <Radio className="h-8 w-8 text-cyan-400" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-cyan-400 tracking-tight">WIRED CHAOS SOCIAL HUB</h1>
              <p className="text-sm text-cyan-200/70">Live transmissions from across the WIRED CHAOS META ecosystem</p>
            </div>
          </div>

          {/* Hashtag Ticker */}
          <div className="flex items-center gap-2 mt-6 overflow-x-auto pb-2">
            <Hash className="h-4 w-4 text-cyan-500 flex-shrink-0" />
            {SOCIAL_ACCOUNTS.hashtags.map((tag) => (
              <Badge
                key={tag}
                variant="outline"
                className="border-cyan-700 text-cyan-300 bg-cyan-950/30 hover:bg-cyan-900/50 cursor-pointer whitespace-nowrap"
              >
                {tag}
              </Badge>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-10 space-y-10">
        {/* Main Social Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Twitter Feed - Main Account */}
          <Card className="bg-black/60 border-cyan-700/50 backdrop-blur-sm shadow-lg shadow-cyan-600/10 col-span-1 lg:col-span-2">
            <CardHeader className="border-b border-cyan-900/50">
              <CardTitle className="flex items-center gap-2 text-cyan-300">
                <Twitter className="h-5 w-5" />
                @wiredchaosmeta • Main Broadcast
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="rounded-lg overflow-hidden min-h-[400px]">
                <a
                  className="twitter-timeline"
                  data-theme="dark"
                  data-chrome="noheader nofooter noborders transparent"
                  data-height="400"
                  href={`https://twitter.com/${SOCIAL_ACCOUNTS.twitter.main}`}
                >
                  Loading @wiredchaosmeta...
                </a>
              </div>
            </CardContent>
          </Card>

          {/* NEURO Twitter Feed */}
          <Card className="bg-black/60 border-cyan-700/50 backdrop-blur-sm shadow-lg shadow-cyan-600/10">
            <CardHeader className="border-b border-cyan-900/50">
              <CardTitle className="flex items-center gap-2 text-cyan-300">
                <Twitter className="h-5 w-5" />
                @neurometax • NEURO Signal
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="rounded-lg overflow-hidden min-h-[400px]">
                <a
                  className="twitter-timeline"
                  data-theme="dark"
                  data-chrome="noheader nofooter noborders transparent"
                  data-height="400"
                  href={`https://twitter.com/${SOCIAL_ACCOUNTS.twitter.neuro}`}
                >
                  Loading @neurometax...
                </a>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Secondary Grid - YouTube, TikTok, Live Spaces */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* YouTube Feed */}
          <Card className="bg-black/60 border-red-700/50 backdrop-blur-sm shadow-lg shadow-red-600/10">
            <CardHeader className="border-b border-red-900/50">
              <CardTitle className="flex items-center gap-2 text-red-400">
                <Youtube className="h-5 w-5" />
                YouTube Feed
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 space-y-4">
              <p className="text-xs text-red-200/70">
                WIRED CHAOS Meta video drops, breakdowns, tutorials, and transmissions.
              </p>
              <div className="aspect-video bg-red-950/20 rounded-lg border border-red-900/30 flex items-center justify-center">
                <div className="text-center">
                  <Youtube className="h-12 w-12 text-red-500/50 mx-auto mb-2" />
                  <p className="text-sm text-red-300/50">Coming Soon</p>
                </div>
              </div>
              <Button
                variant="outline"
                className="w-full border-red-700 text-red-300 hover:bg-red-950/50 bg-transparent"
                disabled
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                Connect YouTube Channel
              </Button>
            </CardContent>
          </Card>

          {/* TikTok / Reels */}
          <Card className="bg-black/60 border-pink-700/50 backdrop-blur-sm shadow-lg shadow-pink-600/10">
            <CardHeader className="border-b border-pink-900/50">
              <CardTitle className="flex items-center gap-2 text-pink-400">
                <Music2 className="h-5 w-5" />
                TikTok / Reels
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 space-y-4">
              <p className="text-xs text-pink-200/70">
                Short-form clips, viral edits, and neuro-encoded social content.
              </p>
              <div className="aspect-video bg-pink-950/20 rounded-lg border border-pink-900/30 flex items-center justify-center">
                <div className="text-center">
                  <Music2 className="h-12 w-12 text-pink-500/50 mx-auto mb-2" />
                  <p className="text-sm text-pink-300/50">Coming Soon</p>
                </div>
              </div>
              <Button
                variant="outline"
                className="w-full border-pink-700 text-pink-300 hover:bg-pink-950/50 bg-transparent"
                disabled
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                Connect TikTok
              </Button>
            </CardContent>
          </Card>

          {/* Live Spaces */}
          <Card className="bg-black/60 border-purple-700/50 backdrop-blur-sm shadow-lg shadow-purple-600/10">
            <CardHeader className="border-b border-purple-900/50">
              <CardTitle className="flex items-center gap-2 text-purple-400">
                <Users className="h-5 w-5" />
                Live X Spaces
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 space-y-4">
              <p className="text-xs text-purple-200/70">Current or scheduled X Spaces from WIRED CHAOS hosts.</p>
              <div className="space-y-2">
                <div className="p-3 rounded-lg bg-purple-950/30 border border-purple-900/30">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
                    <span className="text-xs text-purple-300 font-medium">No Active Space</span>
                  </div>
                  <p className="text-xs text-purple-400/60">Check back for live transmissions</p>
                </div>
              </div>
              <Button
                variant="outline"
                className="w-full border-purple-700 text-purple-300 hover:bg-purple-950/50 bg-transparent"
                asChild
              >
                <a href="https://twitter.com/wiredchaosmeta" target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  View on X
                </a>
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Agent Post Generator Teaser */}
        <Card className="bg-gradient-to-r from-cyan-950/40 to-purple-950/40 border-cyan-700/30 backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-cyan-500/10 border border-cyan-500/30">
                  <Zap className="h-6 w-6 text-cyan-400" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-cyan-300">WIRED CHAOS Agent Post Generator</h3>
                  <p className="text-sm text-cyan-200/60">Generate social posts using NPC / NEURO prompt engines</p>
                </div>
              </div>
              <Button
                variant="outline"
                className="border-cyan-700 text-cyan-300 hover:bg-cyan-950/50 bg-transparent"
                asChild
              >
                <a href="/npc/console">Open NPC Console</a>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Quick Links */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: "33.3 FM Radio", href: "/33fm/radio", icon: Radio },
            { label: "Lurky Analytics", href: "/lurky-analytics", icon: Users },
            { label: "789 Studios", href: "/789-studios", icon: Youtube },
            { label: "NPC Console", href: "/npc/console", icon: Zap },
          ].map((link) => (
            <Button
              key={link.href}
              variant="outline"
              className="h-auto py-4 border-cyan-800/50 text-cyan-300 hover:bg-cyan-950/30 flex flex-col items-center gap-2 bg-transparent"
              asChild
            >
              <a href={link.href}>
                <link.icon className="h-5 w-5" />
                <span className="text-xs">{link.label}</span>
              </a>
            </Button>
          ))}
        </div>
      </div>
    </div>
  )
}
