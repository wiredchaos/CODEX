import Link from "next/link"
import { ArrowLeft, Shield, Users, FileText, Lock } from "lucide-react"

const features = [
  { name: "Trust Formation", icon: Shield },
  { name: "Beneficiary Management", icon: Users },
  { name: "Document Vault", icon: FileText },
  { name: "Access Control", icon: Lock },
]

export default function TrustEstatePage() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <Link
        href="/business"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors mb-8"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Business Patch
      </Link>

      <div className="mb-12">
        <div className="flex items-center gap-4 mb-4">
          <div className="p-4 rounded-xl bg-primary/10">
            <Shield className="h-8 w-8 text-primary" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-primary">Trust/Estate Control</h1>
            <p className="text-muted-foreground">Wealth protection and succession planning</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
        {features.map((feature) => (
          <div key={feature.name} className="p-6 rounded-xl border border-border bg-card/50">
            <div className="p-2 rounded-lg bg-primary/10 w-fit mb-4">
              <feature.icon className="h-5 w-5 text-primary" />
            </div>
            <h3 className="text-lg font-semibold">{feature.name}</h3>
          </div>
        ))}
      </div>

      <div className="p-6 rounded-xl border border-primary/30 bg-primary/5">
        <h2 className="text-lg font-bold mb-2">Coming Soon</h2>
        <p className="text-sm text-muted-foreground">
          Comprehensive trust administration with smart contract integration.
        </p>
      </div>
    </div>
  )
}
