"use client"

import { useState } from "react"
import type { EnvironmentId } from "@/types"

const BUSINESS_ENVIRONMENTS = [
  {
    id: "business-neon-boardroom" as EnvironmentId,
    name: "Neon Boardroom",
    description: "Floating KPI screens, avatar chairs auto-size, holographic document sharing",
    icon: "🏢",
    features: ["KPI Screens", "Holographic Table", "Avatar Chairs", "Document Projector"],
  },
  {
    id: "business-glass-atrium" as EnvironmentId,
    name: "Executive Atrium",
    description: "Corporate glass, reflective floors, training modules auto-load",
    icon: "🏛️",
    features: ["Glass Walls", "Reflective Floor", "Training Pods", "Executive Desk"],
  },
  {
    id: "business-creator-studio" as EnvironmentId,
    name: "Creator Studio",
    description: "Script walls, Canva-style visual boards, whiteboard with auto transcription",
    icon: "🎨",
    features: ["Script Walls", "Visual Boards", "Transcription Whiteboard", "Render Station"],
  },
  {
    id: "business-financial-observatory" as EnvironmentId,
    name: "Financial Observatory",
    description: "Org charts projected in space, tax simulations, entity mapping network",
    icon: "📊",
    features: ["Orbital Org Charts", "Tax Simulator", "Entity Network", "Data Streams"],
  },
]

export default function BusinessMeetingsPage() {
  const [selectedEnvironment, setSelectedEnvironment] = useState<EnvironmentId | null>(null)
  const [environmentData, setEnvironmentData] = useState<any>(null)

  const handleEnterEnvironment = async (envId: EnvironmentId) => {
    setSelectedEnvironment(envId)
    try {
      const res = await fetch(`/api/environment/${envId}`)
      const data = await res.json()
      setEnvironmentData(data)
    } catch (error) {
      console.error("[v0] Failed to load environment:", error)
    }
  }

  return (
    <div className="min-h-screen bg-background text-foreground p-6">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-cyan-400">Business 3D Meetings</h1>
          <p className="text-sm text-neutral-400 mt-2">
            Immersive 3D environments for sales calls, courses, coaching, strategy, and workshops
          </p>
          <p className="text-xs text-yellow-500 mt-1">⚠️ Note: This will later embed real 3D scenes (Spline/Hyperfy)</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {BUSINESS_ENVIRONMENTS.map((env) => (
            <div
              key={env.id}
              className="border border-neutral-800 rounded-xl p-6 bg-black/40 hover:border-cyan-600 transition-all cursor-pointer"
              onClick={() => handleEnterEnvironment(env.id)}
            >
              <div className="text-4xl mb-3">{env.icon}</div>
              <h3 className="text-xl font-semibold text-cyan-400 mb-2">{env.name}</h3>
              <p className="text-sm text-neutral-400 mb-4">{env.description}</p>
              <div className="flex flex-wrap gap-2">
                {env.features.map((feature) => (
                  <span
                    key={feature}
                    className="text-xs bg-cyan-950/30 text-cyan-300 px-2 py-1 rounded border border-cyan-800/50"
                  >
                    {feature}
                  </span>
                ))}
              </div>
              <button className="mt-4 w-full bg-cyan-600 hover:bg-cyan-700 px-4 py-2 rounded-lg text-sm font-medium transition-colors">
                Enter Environment
              </button>
            </div>
          ))}
        </div>

        {selectedEnvironment && environmentData && (
          <div className="border border-cyan-600 rounded-xl p-6 bg-cyan-950/10">
            <h2 className="text-2xl font-bold text-cyan-400 mb-4">Environment: {environmentData.label}</h2>
            <div className="aspect-video bg-neutral-900 rounded-lg flex items-center justify-center border border-neutral-700 mb-4">
              <div className="text-center space-y-2">
                <div className="text-6xl">🌐</div>
                <div className="text-neutral-500 text-sm">3D Scene Placeholder</div>
                <div className="text-xs text-neutral-600">Spline/Hyperfy integration point</div>
              </div>
            </div>
            <div className="space-y-2 text-sm">
              <div>
                <span className="text-neutral-400">Patch:</span>{" "}
                <span className="text-cyan-400">{environmentData.patch}</span>
              </div>
              <div>
                <span className="text-neutral-400">Default Avatars:</span>{" "}
                <span className="text-cyan-400">{environmentData.defaultAvatarIds?.join(", ")}</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
