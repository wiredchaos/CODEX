import Link from "next/link"
import { ArrowLeft, Zap, TrendingUp, Target, Users, BarChart3, Sparkles } from "lucide-react"
import { FUNNEL_TEMPLATES } from "@/lib/funnel-engine"

const features = [
  {
    name: "AI-Powered Optimization",
    description: "Real-time analysis and recommendations to boost conversion rates",
    icon: Sparkles,
  },
  {
    name: "Smart Triggers",
    description: "Behavioral, time-based, and engagement triggers for perfect timing",
    icon: Zap,
  },
  {
    name: "Multi-Stage Analytics",
    description: "Track drop-off and conversion at every funnel stage",
    icon: BarChart3,
  },
  {
    name: "Industry Templates",
    description: "Pre-built funnels for SaaS, E-commerce, Services, and more",
    icon: Target,
  },
]

const metrics = [
  { label: "Avg Conversion Lift", value: "+34%", color: "text-green-400" },
  { label: "Active Funnels", value: "12", color: "text-cyan-400" },
  { label: "Optimization Score", value: "87/100", color: "text-yellow-400" },
]

export default function FunnelEnginePage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <Link
          href="/business"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors mb-8"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Business Patch
        </Link>

        {/* Header */}
        <div className="mb-12">
          <div className="flex items-center gap-4 mb-6">
            <div className="relative">
              <div className="p-4 rounded-xl bg-primary/10">
                <TrendingUp className="h-8 w-8 text-primary" />
              </div>
              <div className="absolute inset-0 bg-primary/20 blur-xl rounded-xl" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-primary">Universal Funnel Engine</h1>
              <p className="text-muted-foreground">AI-powered sales funnel automation and optimization</p>
            </div>
          </div>

          {/* Metrics Bar */}
          <div className="grid grid-cols-3 gap-4 p-6 rounded-xl border border-primary/20 bg-primary/5">
            {metrics.map((metric) => (
              <div key={metric.label} className="text-center">
                <div className={`text-2xl font-bold ${metric.color} mb-1`}>{metric.value}</div>
                <div className="text-xs text-muted-foreground">{metric.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Features Grid */}
        <div className="mb-12">
          <h2 className="text-xl font-bold mb-6">Core Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {features.map((feature) => (
              <div
                key={feature.name}
                className="p-6 rounded-xl border border-border bg-card/50 hover:border-primary/50 hover:bg-primary/5 transition-all"
              >
                <div className="p-3 rounded-lg bg-primary/10 w-fit mb-4">
                  <feature.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">{feature.name}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Funnel Templates */}
        <div className="mb-12">
          <h2 className="text-xl font-bold mb-6">Industry Funnel Templates</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {FUNNEL_TEMPLATES.map((template) => (
              <Link
                key={template.id}
                href={`/business/funnel-engine/template/${template.id}`}
                className="group p-6 rounded-xl border border-border bg-card/50 hover:border-primary/50 hover:bg-primary/5 transition-all"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="text-xs px-2 py-1 rounded bg-primary/20 text-primary font-medium">
                    {template.industry}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {(template.averageConversion * 100).toFixed(0)}% avg CVR
                  </div>
                </div>
                <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors">
                  {template.name}
                </h3>
                <p className="text-sm text-muted-foreground mb-4">{template.description}</p>
                <div className="flex items-center gap-2 text-xs text-primary">
                  <Users className="h-3 w-3" />
                  <span>{template.stages.length} stages configured</span>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="p-8 rounded-xl border border-primary/30 bg-gradient-to-br from-primary/10 to-primary/5">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-2xl font-bold mb-2">Build Your Custom Funnel</h2>
              <p className="text-muted-foreground mb-6 max-w-2xl">
                Start with a proven template or build from scratch. Our AI engine analyzes user behavior and
                automatically optimizes conversion at every stage.
              </p>
              <div className="flex gap-4">
                <Link
                  href="/business/funnel-engine/builder"
                  className="px-6 py-3 rounded-lg bg-primary text-primary-foreground font-semibold hover:bg-primary/90 transition-colors"
                >
                  Launch Funnel Builder
                </Link>
                <Link
                  href="/business/funnel-engine/analytics"
                  className="px-6 py-3 rounded-lg border border-primary text-primary font-semibold hover:bg-primary/10 transition-colors"
                >
                  View Analytics
                </Link>
              </div>
            </div>
            <Sparkles className="h-16 w-16 text-primary/30" />
          </div>
        </div>
      </div>
    </div>
  )
}
