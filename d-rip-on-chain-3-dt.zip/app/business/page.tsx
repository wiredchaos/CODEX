import Link from "next/link"
import { ArrowLeft, Briefcase, Calculator, Megaphone, Palette, GraduationCap, Users, Gamepad2 } from "lucide-react"
import { cn } from "@/lib/utils"

const businessModules = [
  {
    slug: "chaos-builder-exchange",
    name: "Chaos Builder Exchange",
    description:
      "Entrepreneur-to-entrepreneur marketplace for bridging opportunities, exchanging services, and scaling ventures.",
    icon: Users,
    featured: true,
  },
  {
    slug: "../neuro-node",
    name: "NEURO NODE ID + HRM Games",
    description: "Professional skill passport with gamified training. LinkedIn meets skill-building arcade.",
    icon: Gamepad2,
    featured: true,
  },
  {
    slug: "funnel-engine",
    name: "Universal Funnel Engine",
    description: "Build automated sales funnels with AI-powered optimization and conversion tracking.",
    icon: Briefcase,
  },
  {
    slug: "tax-suite",
    name: "Tax Suite Intelligence",
    description: "Smart tax optimization wizard with entity structuring and blockchain bookkeeping.",
    icon: Calculator,
  },
  {
    slug: "marketing-swarm",
    name: "Marketing Swarm",
    description: "Multi-agent marketing automation with campaign orchestration and analytics.",
    icon: Megaphone,
  },
  {
    slug: "creator-codex",
    name: "Creator Codex",
    description: "Content creation toolkit with brand voice management and distribution systems.",
    icon: Palette,
  },
  {
    slug: "ascent-school",
    name: "Business Ascent School",
    description: "Structured business education from startup foundations to enterprise scaling.",
    icon: GraduationCap,
  },
]

export default function BusinessPatchPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <Link
        href="/"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors mb-8"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Patch Selection
      </Link>

      <div className="mb-12">
        <div className="flex items-center gap-4 mb-4">
          <div className="relative">
            <div className="w-16 h-16 rounded-full bg-primary/80" />
            <div className="absolute inset-0 w-16 h-16 rounded-full bg-primary/40 blur-lg" />
          </div>
          <div>
            <h1 className="text-3xl sm:text-4xl font-bold text-primary">BUSINESS PATCH</h1>
            <p className="text-muted-foreground">Strategic operations. Professional workflows.</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {businessModules.map((module) => (
          <Link
            key={module.slug}
            href={`/business/${module.slug}`}
            className={cn(
              "group p-6 rounded-xl border bg-card/50 hover:border-primary/50 hover:bg-primary/5 transition-all duration-300",
              module.featured ? "border-cyan-500/50 bg-cyan-500/5" : "border-border",
            )}
          >
            {module.featured && (
              <div className="text-xs font-medium text-cyan-400 uppercase tracking-wide mb-2">Featured</div>
            )}
            <div className="p-3 rounded-lg bg-primary/10 w-fit mb-4 group-hover:bg-primary/20 transition-colors">
              <module.icon className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors">{module.name}</h3>
            <p className="text-sm text-muted-foreground">{module.description}</p>
          </Link>
        ))}
      </div>

      <div className="mt-12 p-6 rounded-xl border border-border bg-card/30">
        <h2 className="text-xl font-bold mb-4">Business Patch Roadmap</h2>
        <ul className="space-y-2 text-sm text-muted-foreground">
          <li className="flex items-start gap-2">
            <span className="text-primary mt-1">→</span>
            <span>Global dashboard with cross-module analytics</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-primary mt-1">→</span>
            <span>Entity builder with jurisdiction optimization</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-primary mt-1">→</span>
            <span>Trust/Estate control panel integration</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-primary mt-1">→</span>
            <span>AI-powered financial forecasting</span>
          </li>
        </ul>
      </div>
    </div>
  )
}
