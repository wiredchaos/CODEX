"use client"

import Link from "next/link"
import {
  ArrowLeft,
  Award,
  BadgeCheck,
  Calendar,
  CheckCircle,
  Crown,
  MessageSquare,
  Sparkles,
  Star,
  Zap,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MOCK_BUILDERS } from "@/config/chaos-builder-exchange"

const conciergeServices = [
  {
    id: "neuro-couture",
    name: "NEURO META X Couture Prompting",
    description:
      "One-on-one strategy sessions with NEURO META X. Architect your AI-powered business, creative project, or transmedia universe with expert guidance.",
    features: [
      "90-minute strategy session",
      "Custom prompt library tailored to your needs",
      "Implementation roadmap",
      "30-day follow-up support",
      "Access to exclusive WIRED CHAOS resources",
    ],
    price: "$2,500",
    availability: "Limited slots",
  },
  {
    id: "founder-accelerator",
    name: "Founder Accelerator Package",
    description:
      "Comprehensive 30-day program to launch or scale your venture. Includes strategy, branding, tech setup, and go-to-market execution.",
    features: [
      "Weekly strategy calls",
      "Brand identity development",
      "Tech stack consultation",
      "Marketing launch plan",
      "Investor pitch review",
    ],
    price: "$10,000",
    availability: "2 slots/month",
  },
  {
    id: "enterprise-builder",
    name: "Enterprise Builder Retainer",
    description:
      "Ongoing access to our top-tier builders for complex, multi-phase projects. Perfect for funded startups and established companies.",
    features: [
      "Dedicated project manager",
      "Priority access to all builders",
      "Monthly strategy reviews",
      "Unlimited revisions",
      "24/7 support channel",
    ],
    price: "$25,000/mo",
    availability: "By application",
  },
]

export default function ConciergePage() {
  const conciergeBuilders = MOCK_BUILDERS.filter((b) => b.isConcierge)

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <div className="relative overflow-hidden border-b border-amber-500/30">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(245,158,11,0.15),transparent_50%)]" />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background" />

        <div className="relative max-w-6xl mx-auto px-4 py-16">
          <Link
            href="/business/chaos-builder-exchange"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-amber-400 transition-colors mb-8"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Exchange
          </Link>

          <div className="flex items-center gap-3 mb-4">
            <Crown className="h-10 w-10 text-amber-500" />
            <Badge className="bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0 text-lg px-4 py-1">
              CONCIERGE
            </Badge>
          </div>

          <h1 className="text-4xl sm:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-amber-400 via-orange-400 to-amber-400 bg-clip-text text-transparent">
              White-Glove Builder Services
            </span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mb-8">
            Premium, high-touch services for founders who demand excellence. Personal attention, top-tier talent, and
            guaranteed results.
          </p>

          <div className="flex flex-wrap gap-6 text-sm">
            <div className="flex items-center gap-2">
              <BadgeCheck className="h-5 w-5 text-amber-500" />
              <span>Vetted Top 1% Builders</span>
            </div>
            <div className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-amber-500" />
              <span>Priority Response</span>
            </div>
            <div className="flex items-center gap-2">
              <Award className="h-5 w-5 text-amber-500" />
              <span>Satisfaction Guaranteed</span>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-4 py-12">
        {/* Services */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold mb-8">Concierge Packages</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {conciergeServices.map((service) => (
              <Card
                key={service.id}
                className="relative overflow-hidden border-amber-500/30 bg-gradient-to-br from-amber-500/5 to-transparent"
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-3xl" />

                <CardHeader>
                  <div className="flex items-center justify-between mb-2">
                    <Sparkles className="h-6 w-6 text-amber-500" />
                    <Badge variant="outline" className="border-amber-500/30 text-amber-400">
                      {service.availability}
                    </Badge>
                  </div>
                  <CardTitle className="text-xl">{service.name}</CardTitle>
                  <CardDescription>{service.description}</CardDescription>
                </CardHeader>

                <CardContent className="space-y-6">
                  <ul className="space-y-2">
                    {service.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-amber-500 mt-0.5 flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <div className="pt-4 border-t border-amber-500/20">
                    <div className="text-3xl font-bold text-amber-400 mb-4">{service.price}</div>
                    <Button className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white">
                      <Calendar className="mr-2 h-4 w-4" />
                      Book Consultation
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Concierge Builders */}
        <section>
          <h2 className="text-2xl font-bold mb-8">Concierge-Level Builders</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {conciergeBuilders.map((builder) => (
              <Link key={builder.id} href={`/business/chaos-builder-exchange/profile/${builder.id}`}>
                <Card className="h-full border-amber-500/30 bg-gradient-to-br from-amber-500/5 to-transparent hover:border-amber-500/50 transition-colors cursor-pointer">
                  <CardHeader>
                    <div className="flex items-start gap-4">
                      <div className="relative">
                        <img
                          src={builder.avatarUrl || "/placeholder.svg?height=64&width=64&query=avatar"}
                          alt={builder.displayName}
                          className="w-16 h-16 rounded-full object-cover border-2 border-amber-500/30"
                        />
                        <Crown className="absolute -bottom-1 -right-1 h-5 w-5 text-amber-500 bg-background rounded-full p-0.5" />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{builder.displayName}</CardTitle>
                        <CardDescription className="line-clamp-1">{builder.headline}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-4 text-sm mb-4">
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                        <span className="font-medium">{builder.rating}</span>
                      </div>
                      <span className="text-muted-foreground">{builder.completedProjects} projects</span>
                    </div>
                    <Button
                      variant="outline"
                      className="w-full border-amber-500/30 hover:bg-amber-500/10 text-amber-400 bg-transparent"
                    >
                      <MessageSquare className="mr-2 h-4 w-4" />
                      Request Consultation
                    </Button>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>

        {/* CTA */}
        <section className="mt-16">
          <Card className="border-amber-500/30 bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-amber-500/10">
            <CardContent className="py-12 text-center">
              <Crown className="h-12 w-12 mx-auto text-amber-500 mb-4" />
              <h3 className="text-2xl font-bold mb-2">Not Sure Which Package Fits?</h3>
              <p className="text-muted-foreground mb-6 max-w-lg mx-auto">
                Schedule a free 15-minute call to discuss your needs and we&apos;ll recommend the perfect solution.
              </p>
              <Button
                size="lg"
                className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white"
              >
                Schedule Free Call
              </Button>
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  )
}
