"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Building2, Shield, FileCheck, Sparkles, Lock, ArrowRight, BarChart3, Brain, Leaf } from "lucide-react"

const ENTERPRISE_FEATURES = [
  {
    icon: Shield,
    title: "Verified Builder Identity",
    description: "Blockchain-backed identity seals eliminate fake profiles and credentials",
  },
  {
    icon: FileCheck,
    title: "Smart Collaboration Contracts",
    description: "Automated escrow, milestone payments, and dispute-free delivery",
  },
  {
    icon: Lock,
    title: "Immutable Proof-of-Work",
    description: "Permanent, verifiable credentials for every completed project",
  },
  {
    icon: Brain,
    title: "AI Matching Engine",
    description: "Intelligent skill + reputation matching for optimal builder selection",
  },
  {
    icon: BarChart3,
    title: "Enterprise Dashboard",
    description: "Real-time analytics, risk scoring, and ESG compliance reporting",
  },
  {
    icon: Leaf,
    title: "ESG Compliance",
    description: "Environmental, Social, and Governance scoring for sustainable sourcing",
  },
]

const USE_CASES = [
  {
    title: "Enterprise Campaign Build",
    description: "Assemble verified teams: Designer, Strategist, Writer, AI Specialist — all contract-bound.",
  },
  {
    title: "Rapid Innovation Cell",
    description: "Form agile teams for MVP-building, brand creation, AI workflows, and training programs.",
  },
  {
    title: "Live Expert Sessions",
    description: "Streamlabs-powered live workshops with automated billing and session archival.",
  },
]

const COMPETITIVE_ADVANTAGES = [
  { platform: "Fiverr", weakness: "Commodity labor", cbeStrength: "Verified builders" },
  { platform: "Upwork", weakness: "Mixed quality", cbeStrength: "Credentialed builders" },
  { platform: "LinkedIn", weakness: "Static networking", cbeStrength: "Actionable contracting" },
  { platform: "Indeed", weakness: "Employment only", cbeStrength: "Founders & consultants" },
]

export default function EnterprisePage() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#00F0FF]/5 to-transparent" />
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6 bg-[#00F0FF]/10 text-[#00F0FF] border-[#00F0FF]/30">
              <Building2 className="w-3 h-3 mr-1" />
              Enterprise Solutions
            </Badge>
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              <span className="text-[#00F0FF]">CBE</span> Enterprise
            </h1>
            <p className="text-xl text-gray-400 mb-8 max-w-2xl mx-auto">
              Verified entrepreneurial talent, immutable proof of work, and AI-driven matching supported by secure smart
              contracts.
            </p>
            <div className="flex gap-4 justify-center">
              <Button size="lg" className="bg-[#00F0FF] hover:bg-[#00F0FF]/80 text-black font-semibold">
                Schedule Demo
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-[#00F0FF]/30 text-[#00F0FF] hover:bg-[#00F0FF]/10 bg-transparent"
              >
                Download Pitch Deck
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="container mx-auto px-6 pb-20">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          <TabsList className="grid grid-cols-5 bg-[#1A1D1F] border border-[#00F0FF]/20 p-1">
            <TabsTrigger
              value="overview"
              className="data-[state=active]:bg-[#00F0FF]/20 data-[state=active]:text-[#00F0FF]"
            >
              Overview
            </TabsTrigger>
            <TabsTrigger
              value="features"
              className="data-[state=active]:bg-[#00F0FF]/20 data-[state=active]:text-[#00F0FF]"
            >
              Features
            </TabsTrigger>
            <TabsTrigger
              value="use-cases"
              className="data-[state=active]:bg-[#00F0FF]/20 data-[state=active]:text-[#00F0FF]"
            >
              Use Cases
            </TabsTrigger>
            <TabsTrigger
              value="competitive"
              className="data-[state=active]:bg-[#00F0FF]/20 data-[state=active]:text-[#00F0FF]"
            >
              Competitive
            </TabsTrigger>
            <TabsTrigger
              value="roadmap"
              className="data-[state=active]:bg-[#00F0FF]/20 data-[state=active]:text-[#00F0FF]"
            >
              Roadmap
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-8">
            <Card className="bg-[#1A1D1F] border-[#00F0FF]/20">
              <CardHeader>
                <CardTitle className="text-2xl text-white">The Enterprise Problem</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-400">Enterprises face critical challenges when sourcing external talent:</p>
                <div className="grid md:grid-cols-3 gap-4">
                  {[
                    "Unverified contractors",
                    "Fake portfolios",
                    "Delivery inconsistency",
                    "Legal risk of non-compliant contracting",
                    "Slow procurement cycles",
                    "No transparent record of work delivered",
                  ].map((problem, i) => (
                    <div key={i} className="flex items-center gap-2 text-[#FF003C]">
                      <span className="w-2 h-2 bg-[#FF003C] rounded-full" />
                      {problem}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-[#1A1D1F] border-[#00F0FF]/20">
              <CardHeader>
                <CardTitle className="text-2xl text-white">The CBE Solution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  {[
                    { icon: Shield, text: "Verified Builder Identity Seals (BIS)" },
                    { icon: FileCheck, text: "Smart Collaboration Contracts" },
                    { icon: Lock, text: "Immutable Proof-of-Work Ledger" },
                    { icon: Brain, text: "AI-driven skill + project matching" },
                    { icon: BarChart3, text: "Enterprise dashboards" },
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-[#00F0FF]/10 flex items-center justify-center">
                        <item.icon className="w-5 h-5 text-[#00F0FF]" />
                      </div>
                      <span className="text-gray-300">{item.text}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Market Size */}
            <Card className="bg-[#1A1D1F] border-[#00F0FF]/20">
              <CardHeader>
                <CardTitle className="text-2xl text-white">Market Opportunity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-4 gap-4">
                  {[
                    { label: "Freelance/Consulting", value: "$400B+" },
                    { label: "Creator Economy", value: "$200B+" },
                    { label: "Micro-Agency Sector", value: "$100B+" },
                    { label: "Enterprise Verification", value: "$50B+" },
                  ].map((market, i) => (
                    <div key={i} className="text-center p-4 bg-[#0A0A0A] rounded-lg border border-[#00F0FF]/10">
                      <div className="text-3xl font-bold text-[#00F0FF]">{market.value}</div>
                      <div className="text-sm text-gray-400 mt-1">{market.label}</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Features Tab */}
          <TabsContent value="features" className="space-y-8">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {ENTERPRISE_FEATURES.map((feature, i) => (
                <Card key={i} className="bg-[#1A1D1F] border-[#00F0FF]/20 hover:border-[#00F0FF]/40 transition-colors">
                  <CardHeader>
                    <div className="w-12 h-12 rounded-lg bg-[#00F0FF]/10 flex items-center justify-center mb-4">
                      <feature.icon className="w-6 h-6 text-[#00F0FF]" />
                    </div>
                    <CardTitle className="text-white">{feature.title}</CardTitle>
                    <CardDescription className="text-gray-400">{feature.description}</CardDescription>
                  </CardHeader>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Use Cases Tab */}
          <TabsContent value="use-cases" className="space-y-8">
            <div className="grid md:grid-cols-3 gap-6">
              {USE_CASES.map((useCase, i) => (
                <Card key={i} className="bg-[#1A1D1F] border-[#00F0FF]/20">
                  <CardHeader>
                    <div className="flex items-center gap-2 mb-2">
                      <Sparkles className="w-5 h-5 text-[#FFD16F]" />
                      <span className="text-sm text-[#FFD16F]">Use Case #{i + 1}</span>
                    </div>
                    <CardTitle className="text-white">{useCase.title}</CardTitle>
                    <CardDescription className="text-gray-400">{useCase.description}</CardDescription>
                  </CardHeader>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Competitive Tab */}
          <TabsContent value="competitive" className="space-y-8">
            <Card className="bg-[#1A1D1F] border-[#00F0FF]/20">
              <CardHeader>
                <CardTitle className="text-2xl text-white">Competitive Landscape</CardTitle>
                <CardDescription>CBE stands alone in entrepreneur-grade verification</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-[#00F0FF]/20">
                        <th className="text-left py-3 px-4 text-gray-400">Platform</th>
                        <th className="text-left py-3 px-4 text-[#FF003C]">Weakness</th>
                        <th className="text-left py-3 px-4 text-[#00F0FF]">CBE Strength</th>
                      </tr>
                    </thead>
                    <tbody>
                      {COMPETITIVE_ADVANTAGES.map((row, i) => (
                        <tr key={i} className="border-b border-[#00F0FF]/10">
                          <td className="py-3 px-4 text-white font-medium">{row.platform}</td>
                          <td className="py-3 px-4 text-[#FF003C]">{row.weakness}</td>
                          <td className="py-3 px-4 text-[#00F0FF]">{row.cbeStrength}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Roadmap Tab */}
          <TabsContent value="roadmap" className="space-y-8">
            <Card className="bg-[#1A1D1F] border-[#00F0FF]/20">
              <CardHeader>
                <CardTitle className="text-2xl text-white">Global Expansion Roadmap</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {[
                  {
                    phase: "Phase 1",
                    months: "0-12",
                    title: "Domestic Establishment",
                    markets: "U.S. & Canada",
                    progress: 75,
                  },
                  {
                    phase: "Phase 2",
                    months: "12-24",
                    title: "English-Speaking Expansion",
                    markets: "UK, Australia, Singapore",
                    progress: 25,
                  },
                  {
                    phase: "Phase 3",
                    months: "24-36",
                    title: "Emerging Builder Hotspots",
                    markets: "Nigeria, Brazil, India, Philippines",
                    progress: 0,
                  },
                  {
                    phase: "Phase 4",
                    months: "36-48",
                    title: "Global Enterprise Integration",
                    markets: "White-label & API",
                    progress: 0,
                  },
                ].map((phase, i) => (
                  <div key={i} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Badge className="bg-[#00F0FF]/10 text-[#00F0FF] border-[#00F0FF]/30">{phase.phase}</Badge>
                        <span className="text-white font-medium">{phase.title}</span>
                        <span className="text-gray-500 text-sm">({phase.months} months)</span>
                      </div>
                      <span className="text-[#00F0FF]">{phase.progress}%</span>
                    </div>
                    <Progress value={phase.progress} className="h-2 bg-[#0A0A0A]" />
                    <p className="text-gray-400 text-sm">Markets: {phase.markets}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* CTA Section */}
        <div className="mt-16 text-center">
          <Card className="bg-gradient-to-r from-[#00F0FF]/10 to-[#FF003C]/10 border-[#00F0FF]/30">
            <CardContent className="py-12">
              <h2 className="text-3xl font-bold text-white mb-4">Ready to Transform Enterprise Contracting?</h2>
              <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
                Pilot with CBE to modernize your contractor networks with verified identity, smart contracts, and AI
                matching.
              </p>
              <div className="flex gap-4 justify-center">
                <Button size="lg" className="bg-[#00F0FF] hover:bg-[#00F0FF]/80 text-black font-semibold">
                  Start Enterprise Pilot
                </Button>
                <Link href="/business/chaos-builder-exchange">
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-[#00F0FF]/30 text-[#00F0FF] hover:bg-[#00F0FF]/10 bg-transparent"
                  >
                    Explore Platform
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}
