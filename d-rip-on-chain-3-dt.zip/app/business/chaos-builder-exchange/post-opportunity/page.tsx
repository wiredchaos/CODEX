"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Plus, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { CBE_CONFIG } from "@/config/chaos-builder-exchange"

export default function PostOpportunityPage() {
  const [skills, setSkills] = useState<string[]>([])
  const [newSkill, setNewSkill] = useState("")
  const [isRemote, setIsRemote] = useState(true)

  const addSkill = () => {
    if (newSkill.trim() && !skills.includes(newSkill.trim())) {
      setSkills([...skills, newSkill.trim()])
      setNewSkill("")
    }
  }

  const removeSkill = (skill: string) => {
    setSkills(skills.filter((s) => s !== skill))
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-3xl mx-auto px-4 py-8">
        <Link
          href="/business/chaos-builder-exchange"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-cyan-400 transition-colors mb-8"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Exchange
        </Link>

        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Post an Opportunity</h1>
          <p className="text-muted-foreground">Find the perfect builder for your project, partnership, or gig.</p>
        </div>

        <Card className="border-border/50 bg-card/50">
          <CardHeader>
            <CardTitle>Opportunity Details</CardTitle>
            <CardDescription>Provide details about what you&apos;re looking for.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Title */}
            <div className="space-y-2">
              <Label htmlFor="title">Title *</Label>
              <Input id="title" placeholder="e.g., AI Copilot for Legal Documents" className="bg-background/50" />
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                placeholder="Describe your project, requirements, and what you're looking for..."
                className="bg-background/50 min-h-32"
              />
            </div>

            {/* Type and Category */}
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Opportunity Type *</Label>
                <Select>
                  <SelectTrigger className="bg-background/50">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    {CBE_CONFIG.opportunityTypes.map((type) => (
                      <SelectItem key={type.id} value={type.id}>
                        {type.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Category *</Label>
                <Select>
                  <SelectTrigger className="bg-background/50">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {CBE_CONFIG.categories.map((cat) => (
                      <SelectItem key={cat.id} value={cat.id}>
                        {cat.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Budget and Timeline */}
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="budget">Budget Range</Label>
                <Input id="budget" placeholder="e.g., $5,000 - $10,000" className="bg-background/50" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="timeline">Timeline</Label>
                <Input id="timeline" placeholder="e.g., 3 months" className="bg-background/50" />
              </div>
            </div>

            {/* Skills */}
            <div className="space-y-2">
              <Label>Preferred Skills</Label>
              <div className="flex gap-2">
                <Input
                  placeholder="Add a skill..."
                  value={newSkill}
                  onChange={(e) => setNewSkill(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addSkill())}
                  className="bg-background/50"
                />
                <Button
                  type="button"
                  onClick={addSkill}
                  variant="outline"
                  className="border-cyan-500/30 bg-transparent"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              {skills.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {skills.map((skill) => (
                    <Badge
                      key={skill}
                      variant="secondary"
                      className="bg-cyan-500/10 text-cyan-400 border-cyan-500/20 pr-1"
                    >
                      {skill}
                      <button onClick={() => removeSkill(skill)} className="ml-1 hover:text-white">
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}
            </div>

            {/* Remote toggle */}
            <div className="flex items-center justify-between p-4 rounded-lg border border-border/50 bg-background/50">
              <div>
                <Label htmlFor="remote" className="font-medium">
                  Remote Friendly
                </Label>
                <p className="text-sm text-muted-foreground">Allow builders to work from anywhere</p>
              </div>
              <Switch id="remote" checked={isRemote} onCheckedChange={setIsRemote} />
            </div>

            {/* Location (if not remote) */}
            {!isRemote && (
              <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <Input id="location" placeholder="e.g., San Francisco, CA" className="bg-background/50" />
              </div>
            )}

            {/* Submit */}
            <div className="flex gap-4 pt-4">
              <Button className="flex-1 bg-cyan-500 hover:bg-cyan-600 text-black font-semibold">
                Post Opportunity
              </Button>
              <Button variant="outline" className="border-border/50 bg-transparent">
                Save Draft
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
