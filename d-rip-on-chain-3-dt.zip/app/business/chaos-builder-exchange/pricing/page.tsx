"use client"

import Link from "next/link"
import { ArrowLeft, BadgeCheck, Check, Crown, Sparkles, Star, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CBE_PRICING_TIERS } from "@/config/cbe-brand"

export default function CBEPricingPage() {
  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      {/* Hero */}
      <div className="relative overflow-hidden border-b border-[#00F0FF]/20">
        {/* Background effects */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,240,255,0.1),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_right,rgba(255,0,60,0.05),transparent_50%)]" />

        {/* Circuit pattern */}
        <div className="absolute inset-0 opacity-5">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <defs>
              <pattern id="circuit-pricing" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
                <path d="M 10 0 L 10 10 M 0 10 L 20 10" stroke="#00F0FF" strokeWidth="0.5" fill="none" />
                <circle cx="10" cy="10" r="1" fill="#00F0FF" />
              </pattern>
            </defs>
            <rect width="100" height="100" fill="url(#circuit-pricing)" />
          </svg>
        </div>

        <div className="relative max-w-6xl mx-auto px-4 py-16 text-center">
          <Link
            href="/business/chaos-builder-exchange"
            className="inline-flex items-center gap-2 text-sm text-[#5E6C72] hover:text-[#00F0FF] transition-colors mb-8"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Exchange
          </Link>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-4">
            <span className="bg-gradient-to-r from-[#00F0FF] via-[#0080FF] to-[#00F0FF] bg-clip-text text-transparent">
              Builder Pricing
            </span>
          </h1>
          <p className="text-xl text-[#5E6C72] max-w-2xl mx-auto mb-8">
            Choose the tier that matches your ambition. Scale up anytime.
          </p>

          {/* Trust badges */}
          <div className="flex flex-wrap justify-center gap-6 text-sm text-[#F2F9FB]">
            <div className="flex items-center gap-2">
              <BadgeCheck className="h-5 w-5 text-[#00F0FF]" />
              <span>No contracts</span>
            </div>
            <div className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-[#00F0FF]" />
              <span>Cancel anytime</span>
            </div>
            <div className="flex items-center gap-2">
              <Star className="h-5 w-5 text-[#FFD16F]" />
              <span>14-day free trial on Pro</span>
            </div>
          </div>
        </div>
      </div>

      {/* Pricing Grid */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {CBE_PRICING_TIERS.map((tier) => (
            <Card
              key={tier.id}
              className={`relative overflow-hidden transition-all duration-300 ${
                tier.highlighted
                  ? "border-[#00F0FF] bg-gradient-to-br from-[#00F0FF]/10 to-transparent scale-105 shadow-lg shadow-[#00F0FF]/20"
                  : tier.id === "couture"
                    ? "border-[#FFD16F]/50 bg-gradient-to-br from-[#FFD16F]/5 to-transparent"
                    : "border-[#1A1D1F] bg-[#1A1D1F]/50 hover:border-[#00F0FF]/30"
              }`}
            >
              {tier.highlighted && (
                <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-[#00F0FF] to-[#0080FF] text-[#0A0A0A] text-xs font-bold py-1 text-center">
                  MOST POPULAR
                </div>
              )}

              {tier.badge && (
                <div className="absolute top-4 right-4">
                  <Badge className="bg-gradient-to-r from-[#FFD16F] to-[#FFA500] text-[#0A0A0A] border-0">
                    <Crown className="h-3 w-3 mr-1" />
                    {tier.badge}
                  </Badge>
                </div>
              )}

              <CardHeader className={tier.highlighted ? "pt-10" : ""}>
                <CardTitle className="text-lg text-[#F2F9FB]">{tier.name}</CardTitle>
                <CardDescription className="text-[#5E6C72]">{tier.description}</CardDescription>
              </CardHeader>

              <CardContent className="space-y-6">
                {/* Price */}
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-bold text-[#F2F9FB]">${tier.price}</span>
                  {tier.billingPeriod && <span className="text-[#5E6C72]">/{tier.billingPeriod}</span>}
                </div>

                {/* Features */}
                <ul className="space-y-3">
                  {tier.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-2 text-sm">
                      <Check
                        className={`h-4 w-4 mt-0.5 flex-shrink-0 ${
                          tier.id === "couture" ? "text-[#FFD16F]" : "text-[#00F0FF]"
                        }`}
                      />
                      <span className="text-[#F2F9FB]">{feature}</span>
                    </li>
                  ))}
                </ul>

                {/* Limitations */}
                {tier.limitations.length > 0 && (
                  <ul className="space-y-2 pt-2 border-t border-[#1A1D1F]">
                    {tier.limitations.map((limitation, index) => (
                      <li key={index} className="flex items-start gap-2 text-sm text-[#5E6C72]">
                        <span className="text-[#FF003C]">×</span>
                        <span>{limitation}</span>
                      </li>
                    ))}
                  </ul>
                )}

                {/* CTA */}
                <Button
                  className={`w-full ${
                    tier.highlighted
                      ? "bg-gradient-to-r from-[#00F0FF] to-[#0080FF] text-[#0A0A0A] hover:opacity-90"
                      : tier.id === "couture"
                        ? "bg-gradient-to-r from-[#FFD16F] to-[#FFA500] text-[#0A0A0A] hover:opacity-90"
                        : "bg-[#1A1D1F] border border-[#00F0FF]/30 text-[#00F0FF] hover:bg-[#00F0FF]/10"
                  }`}
                >
                  {tier.id === "couture" && <Sparkles className="mr-2 h-4 w-4" />}
                  {tier.cta}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* FAQ Section */}
        <div className="mt-20 max-w-3xl mx-auto">
          <h2 className="text-2xl font-bold text-center mb-8 text-[#F2F9FB]">Frequently Asked Questions</h2>
          <div className="space-y-4">
            {[
              {
                q: "Can I switch tiers anytime?",
                a: "Yes, upgrade or downgrade at any time. Changes take effect on your next billing cycle.",
              },
              {
                q: "What payment methods do you accept?",
                a: "We accept all major credit cards, PayPal, and select cryptocurrencies.",
              },
              {
                q: "Is there a free trial?",
                a: "Pro Builder tier includes a 14-day free trial. Enterprise and Couture are available by application.",
              },
              {
                q: "What's the platform fee?",
                a: "Free tier: 12%, Pro: 8% (0% for first 3 clients/month), Enterprise: 5%, Couture: 3%.",
              },
            ].map((faq, index) => (
              <Card key={index} className="border-[#1A1D1F] bg-[#1A1D1F]/30">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base text-[#F2F9FB]">{faq.q}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-[#5E6C72]">{faq.a}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
