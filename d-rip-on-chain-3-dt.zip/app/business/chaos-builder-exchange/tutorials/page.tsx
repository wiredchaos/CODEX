"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Play, CheckCircle, Circle, ChevronRight, Video, BookOpen, Zap, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"

const tutorials = [
  {
    id: "create-profile",
    title: "Create Your Builder Profile",
    description: "Build your professional authority profile in under 2 minutes",
    duration: "2 min",
    icon: Users,
    steps: [
      "Click Create Profile",
      "Upload your avatar",
      "Add title & professional summary",
      "Select your skills & industries",
      "Upload portfolio items",
      "Connect Streamlabs (optional)",
      "Save and publish",
    ],
    completed: false,
  },
  {
    id: "post-service",
    title: "Publish a Service Listing",
    description: "Turn your expertise into a discoverable product",
    duration: "90 sec",
    icon: Zap,
    steps: [
      "Open Service Publisher",
      "Choose a category",
      "Set title, description, pricing",
      "Add delivery timelines",
      "Upload visuals & examples",
      "Click Publish Service",
    ],
    completed: false,
  },
  {
    id: "opportunity-grid",
    title: "Explore the Opportunity Grid",
    description: "Find collaborations, partnerships, and project deals",
    duration: "2 min",
    icon: BookOpen,
    steps: [
      "Navigate to Opportunity Grid",
      "Browse collaboration requests",
      "Review budget ranges & requirements",
      "Submit a Proposal",
      "Wait for AI Match recommendations",
    ],
    completed: false,
  },
  {
    id: "go-live",
    title: "Go Live with Streamlabs",
    description: "Start live consulting sessions with real-time monetization",
    duration: "3 min",
    icon: Video,
    steps: [
      "Visit Live Console",
      "Click Connect Streamlabs",
      "Approve OAuth permissions",
      "Press Go Live",
      "Receive alerts & tips in Stream Feed",
      "End session (auto-archived)",
    ],
    completed: false,
  },
]

export default function CBETutorialsPage() {
  const [expandedTutorial, setExpandedTutorial] = useState<string | null>(null)
  const [completedSteps, setCompletedSteps] = useState<Record<string, number[]>>({})

  const toggleStep = (tutorialId: string, stepIndex: number) => {
    setCompletedSteps((prev) => {
      const current = prev[tutorialId] || []
      if (current.includes(stepIndex)) {
        return { ...prev, [tutorialId]: current.filter((i) => i !== stepIndex) }
      }
      return { ...prev, [tutorialId]: [...current, stepIndex] }
    })
  }

  const getProgress = (tutorialId: string, totalSteps: number) => {
    const completed = completedSteps[tutorialId]?.length || 0
    return (completed / totalSteps) * 100
  }

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white">
      {/* Header */}
      <header className="border-b border-[#1A1D1F] bg-[#0A0A0A]/95 backdrop-blur sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/business/chaos-builder-exchange">
              <Button variant="ghost" size="sm" className="text-[#5E6C72] hover:text-white">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to CBE
              </Button>
            </Link>
            <div className="h-6 w-px bg-[#1A1D1F]" />
            <h1 className="text-xl font-bold">
              <span className="text-[#00F0FF]">CBE</span> Tutorials
            </h1>
          </div>
          <Badge className="bg-[#00F0FF]/10 text-[#00F0FF] border-[#00F0FF]/30">
            {tutorials.length} Guides Available
          </Badge>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        {/* Hero */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">
            Master <span className="text-[#00F0FF]">Chaos Builder Exchange</span>
          </h2>
          <p className="text-[#5E6C72] text-lg max-w-2xl mx-auto">
            Step-by-step guides to help you create profiles, publish services, find opportunities, and go live with
            Streamlabs.
          </p>
        </div>

        {/* Tutorial Grid */}
        <div className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto">
          {tutorials.map((tutorial) => {
            const Icon = tutorial.icon
            const isExpanded = expandedTutorial === tutorial.id
            const progress = getProgress(tutorial.id, tutorial.steps.length)
            const isComplete = progress === 100

            return (
              <Card
                key={tutorial.id}
                className={`bg-[#1A1D1F] border-[#2A2D2F] transition-all duration-300 ${
                  isExpanded ? "ring-2 ring-[#00F0FF]" : "hover:border-[#00F0FF]/50"
                } ${isComplete ? "border-green-500/50" : ""}`}
              >
                <CardHeader
                  className="cursor-pointer"
                  onClick={() => setExpandedTutorial(isExpanded ? null : tutorial.id)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${isComplete ? "bg-green-500/20" : "bg-[#00F0FF]/10"}`}>
                        <Icon className={`w-5 h-5 ${isComplete ? "text-green-400" : "text-[#00F0FF]"}`} />
                      </div>
                      <div>
                        <CardTitle className="text-white text-lg">{tutorial.title}</CardTitle>
                        <CardDescription className="text-[#5E6C72]">{tutorial.description}</CardDescription>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-[#5E6C72] border-[#2A2D2F]">
                      {tutorial.duration}
                    </Badge>
                  </div>

                  {/* Progress Bar */}
                  <div className="mt-4">
                    <div className="flex justify-between text-xs text-[#5E6C72] mb-1">
                      <span>Progress</span>
                      <span>{Math.round(progress)}%</span>
                    </div>
                    <Progress value={progress} className="h-1 bg-[#2A2D2F]" />
                  </div>
                </CardHeader>

                {isExpanded && (
                  <CardContent className="pt-0">
                    <div className="border-t border-[#2A2D2F] pt-4">
                      <h4 className="text-sm font-medium text-[#5E6C72] mb-3">Steps</h4>
                      <div className="space-y-2">
                        {tutorial.steps.map((step, index) => {
                          const isStepComplete = completedSteps[tutorial.id]?.includes(index)
                          return (
                            <button
                              key={index}
                              onClick={(e) => {
                                e.stopPropagation()
                                toggleStep(tutorial.id, index)
                              }}
                              className={`w-full flex items-center gap-3 p-2 rounded-lg transition-all ${
                                isStepComplete
                                  ? "bg-green-500/10 text-green-400"
                                  : "bg-[#0A0A0A] text-[#F2F9FB] hover:bg-[#2A2D2F]"
                              }`}
                            >
                              {isStepComplete ? (
                                <CheckCircle className="w-4 h-4 text-green-400 shrink-0" />
                              ) : (
                                <Circle className="w-4 h-4 text-[#5E6C72] shrink-0" />
                              )}
                              <span className="text-sm text-left">{step}</span>
                            </button>
                          )
                        })}
                      </div>

                      {/* Start Tutorial Button */}
                      <Button className="w-full mt-4 bg-[#00F0FF] text-black hover:bg-[#00F0FF]/90">
                        <Play className="w-4 h-4 mr-2" />
                        {isComplete ? "Review Tutorial" : "Start Tutorial"}
                      </Button>
                    </div>
                  </CardContent>
                )}
              </Card>
            )
          })}
        </div>

        {/* Quick Links */}
        <div className="mt-16 text-center">
          <h3 className="text-xl font-bold mb-6">Ready to Build?</h3>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/business/chaos-builder-exchange">
              <Button
                variant="outline"
                className="border-[#00F0FF] text-[#00F0FF] hover:bg-[#00F0FF]/10 bg-transparent"
              >
                <ChevronRight className="w-4 h-4 mr-2" />
                Go to CBE Home
              </Button>
            </Link>
            <Link href="/business/chaos-builder-exchange/find-builders">
              <Button
                variant="outline"
                className="border-[#FF003C] text-[#FF003C] hover:bg-[#FF003C]/10 bg-transparent"
              >
                <Users className="w-4 h-4 mr-2" />
                Find Builders
              </Button>
            </Link>
            <Link href="/business/chaos-builder-exchange/pricing">
              <Button
                variant="outline"
                className="border-[#FFD16F] text-[#FFD16F] hover:bg-[#FFD16F]/10 bg-transparent"
              >
                <Zap className="w-4 h-4 mr-2" />
                View Pricing
              </Button>
            </Link>
          </div>
        </div>
      </main>
    </div>
  )
}
