"use client"

import type React from "react"

import Link from "next/link"
import { useState } from "react"
import {
  ArrowLeft,
  ArrowRight,
  BadgeCheck,
  Brain,
  Briefcase,
  Code,
  Coins,
  Palette,
  Scale,
  Search,
  Star,
  Target,
  TrendingUp,
  Users,
  Video,
  Zap,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  CBE_CONFIG,
  MOCK_BUILDERS,
  MOCK_LISTINGS,
  MOCK_OPPORTUNITIES,
  type BuilderProfile,
  type ServiceListing,
  type Opportunity,
} from "@/config/chaos-builder-exchange"
import { NowLiveBadge } from "@/integrations/streamlabs/components/NowLiveBadge"
import { TipFeed } from "@/integrations/streamlabs/components/TipFeed"

const categoryIcons: Record<string, React.ReactNode> = {
  "ai-automation": <Brain className="h-5 w-5" />,
  "web3-blockchain": <Coins className="h-5 w-5" />,
  "design-creative": <Palette className="h-5 w-5" />,
  development: <Code className="h-5 w-5" />,
  marketing: <TrendingUp className="h-5 w-5" />,
  strategy: <Target className="h-5 w-5" />,
  content: <Video className="h-5 w-5" />,
  finance: <Scale className="h-5 w-5" />,
}

function BuilderCard({ builder }: { builder: BuilderProfile }) {
  return (
    <Link href={`/business/chaos-builder-exchange/profile/${builder.id}`}>
      <Card className="group relative overflow-hidden border-border/50 bg-card/50 backdrop-blur-sm hover:border-cyan-500/50 transition-all duration-300 cursor-pointer">
        {/* Glow effect */}
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

        <CardHeader className="pb-3">
          <div className="flex items-start gap-4">
            <div className="relative">
              <img
                src={builder.avatarUrl || "/placeholder.svg?height=64&width=64&query=avatar"}
                alt={builder.displayName}
                className="w-16 h-16 rounded-full object-cover border-2 border-cyan-500/30"
              />
              {builder.isVerified && (
                <BadgeCheck className="absolute -bottom-1 -right-1 h-5 w-5 text-cyan-400 bg-background rounded-full" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <CardTitle className="text-lg truncate group-hover:text-cyan-400 transition-colors">
                  {builder.displayName}
                </CardTitle>
                <NowLiveBadge patchId="CBE" size="sm" />
              </div>
              <CardDescription className="line-clamp-1">{builder.headline}</CardDescription>
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Stats */}
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-1">
              <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
              <span className="font-medium">{builder.rating}</span>
              <span className="text-muted-foreground">({builder.reviewCount})</span>
            </div>
            <div className="flex items-center gap-1 text-muted-foreground">
              <Briefcase className="h-4 w-4" />
              <span>{builder.completedProjects} projects</span>
            </div>
          </div>

          {/* Skills */}
          <div className="flex flex-wrap gap-1">
            {builder.skills.slice(0, 3).map((skill) => (
              <Badge
                key={skill}
                variant="secondary"
                className="text-xs bg-cyan-500/10 text-cyan-400 border-cyan-500/20"
              >
                {skill}
              </Badge>
            ))}
            {builder.skills.length > 3 && (
              <Badge variant="secondary" className="text-xs">
                +{builder.skills.length - 3}
              </Badge>
            )}
          </div>

          {/* Trust badges */}
          <div className="flex items-center gap-2 pt-2 border-t border-border/50">
            {builder.trustBadges.slice(0, 3).map((badgeId) => {
              const badge = CBE_CONFIG.trustBadges.find((b) => b.id === badgeId)
              if (!badge) return null
              return (
                <div key={badgeId} className="flex items-center gap-1 text-xs text-muted-foreground">
                  {badgeId === "verified" && <BadgeCheck className="h-3 w-3 text-cyan-400" />}
                  {badgeId === "top-rated" && <Star className="h-3 w-3 text-yellow-500" />}
                  {badgeId === "fast-delivery" && <Zap className="h-3 w-3 text-orange-400" />}
                  {badgeId === "repeat-clients" && <Users className="h-3 w-3 text-green-400" />}
                  <span>{badge.name}</span>
                </div>
              )
            })}
          </div>

          {/* Concierge badge */}
          {builder.isConcierge && (
            <div className="absolute top-4 right-4">
              <Badge className="bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0">CONCIERGE</Badge>
            </div>
          )}
        </CardContent>
      </Card>
    </Link>
  )
}

function ListingCard({ listing }: { listing: ServiceListing }) {
  const builder = MOCK_BUILDERS.find((b) => b.id === listing.builderId)

  return (
    <Link href={`/business/chaos-builder-exchange/listing/${listing.id}`}>
      <Card className="group relative overflow-hidden border-border/50 bg-card/50 backdrop-blur-sm hover:border-cyan-500/50 transition-all duration-300 cursor-pointer h-full">
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

        {listing.isFeatured && (
          <div className="absolute top-0 right-0">
            <div className="bg-gradient-to-r from-cyan-500 to-blue-500 text-white text-xs px-3 py-1 rounded-bl-lg font-medium">
              FEATURED
            </div>
          </div>
        )}

        <CardHeader className="pb-3">
          <div className="flex items-center gap-2 mb-2">
            {categoryIcons[listing.category]}
            <Badge variant="outline" className="text-xs">
              {CBE_CONFIG.categories.find((c) => c.id === listing.category)?.name}
            </Badge>
          </div>
          <CardTitle className="text-lg line-clamp-2 group-hover:text-cyan-400 transition-colors">
            {listing.title}
          </CardTitle>
          <CardDescription className="line-clamp-2">{listing.description}</CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Builder info */}
          {builder && (
            <div className="flex items-center gap-2">
              <img
                src={builder.avatarUrl || "/placeholder.svg?height=32&width=32&query=avatar"}
                alt={builder.displayName}
                className="w-8 h-8 rounded-full object-cover"
              />
              <span className="text-sm font-medium">{builder.displayName}</span>
              {builder.isVerified && <BadgeCheck className="h-4 w-4 text-cyan-400" />}
            </div>
          )}

          {/* Stats */}
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-1">
              <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
              <span className="font-medium">{listing.rating}</span>
              <span className="text-muted-foreground">({listing.reviewCount})</span>
            </div>
            <span className="text-muted-foreground">{listing.orderCount} orders</span>
          </div>

          {/* Pricing */}
          <div className="flex items-center justify-between pt-3 border-t border-border/50">
            <span className="text-xs text-muted-foreground uppercase tracking-wide">Starting at</span>
            <span className="text-xl font-bold text-cyan-400">${listing.basePrice.toLocaleString()}</span>
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}

function OpportunityCard({ opportunity }: { opportunity: Opportunity }) {
  return (
    <Card className="group relative overflow-hidden border-border/50 bg-card/50 backdrop-blur-sm hover:border-cyan-500/50 transition-all duration-300 cursor-pointer">
      <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

      <CardHeader className="pb-3">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            {categoryIcons[opportunity.category]}
            <Badge variant="outline" className="text-xs">
              {CBE_CONFIG.opportunityTypes.find((t) => t.id === opportunity.type)?.name}
            </Badge>
          </div>
          <Badge
            className={
              opportunity.status === "open"
                ? "bg-green-500/20 text-green-400 border-green-500/30"
                : "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
            }
          >
            {opportunity.status.toUpperCase()}
          </Badge>
        </div>
        <CardTitle className="text-lg group-hover:text-cyan-400 transition-colors">{opportunity.title}</CardTitle>
        <CardDescription className="line-clamp-2">{opportunity.description}</CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Requirements */}
        <div className="flex flex-wrap gap-1">
          {opportunity.preferredSkills.slice(0, 4).map((skill) => (
            <Badge key={skill} variant="secondary" className="text-xs">
              {skill}
            </Badge>
          ))}
        </div>

        {/* Details */}
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div>
            <span className="text-muted-foreground">Budget:</span>
            <p className="font-medium text-cyan-400">{opportunity.budget || "Open"}</p>
          </div>
          <div>
            <span className="text-muted-foreground">Timeline:</span>
            <p className="font-medium">{opportunity.timeline || "Flexible"}</p>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-3 border-t border-border/50">
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <Users className="h-4 w-4" />
            <span>{opportunity.applicationCount} proposals</span>
          </div>
          <Button size="sm" variant="outline" className="border-cyan-500/30 hover:bg-cyan-500/10 bg-transparent">
            Apply Now
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

export default function ChaosBuilderExchangePage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative overflow-hidden border-b border-border/50">
        {/* Background effects */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,255,255,0.1),transparent_50%)]" />
        <div className="absolute inset-0 bg-[linear-gradient(to_right,transparent,rgba(0,0,0,0.8),transparent)]" />

        {/* Circuit pattern */}
        <div className="absolute inset-0 opacity-10">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <defs>
              <pattern id="circuit-cbe" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
                <path d="M 10 0 L 10 10 M 0 10 L 20 10" stroke="currentColor" strokeWidth="0.5" fill="none" />
                <circle cx="10" cy="10" r="1" fill="currentColor" />
              </pattern>
            </defs>
            <rect width="100" height="100" fill="url(#circuit-cbe)" className="text-cyan-500" />
          </svg>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 py-16 sm:py-24">
          <Link
            href="/business"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-cyan-400 transition-colors mb-8"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Business Suite
          </Link>

          <div className="max-w-3xl">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-4">
              <span className="bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-400 bg-clip-text text-transparent">
                CHAOS BUILDER
              </span>
              <br />
              <span className="text-white">EXCHANGE</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-2">{CBE_CONFIG.tagline}</p>
            <p className="text-muted-foreground mb-8 max-w-2xl">{CBE_CONFIG.description}</p>

            {/* Search bar */}
            <div className="flex gap-2 max-w-xl">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  placeholder="Search builders, services, or opportunities..."
                  className="pl-10 h-12 bg-background/50 border-border/50 focus:border-cyan-500/50"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Button className="h-12 px-6 bg-cyan-500 hover:bg-cyan-600 text-black font-semibold">Search</Button>
            </div>

            {/* Quick actions */}
            <div className="flex flex-wrap gap-3 mt-6">
              <Link href="/business/chaos-builder-exchange/find-builders">
                <Button variant="outline" className="border-cyan-500/30 hover:bg-cyan-500/10 bg-transparent">
                  <Users className="mr-2 h-4 w-4" />
                  Find Builders
                </Button>
              </Link>
              <Link href="/business/chaos-builder-exchange/post-opportunity">
                <Button variant="outline" className="border-cyan-500/30 hover:bg-cyan-500/10 bg-transparent">
                  <Briefcase className="mr-2 h-4 w-4" />
                  Post Opportunity
                </Button>
              </Link>
              <Link href="/business/chaos-builder-exchange/concierge">
                <Button className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white border-0">
                  <Zap className="mr-2 h-4 w-4" />
                  Concierge Services
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="mb-12 p-6 rounded-2xl border border-cyan-500/30 bg-gradient-to-br from-cyan-500/5 to-transparent">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <NowLiveBadge patchId="CBE" size="lg" showChannel />
              <div>
                <h3 className="text-lg font-bold">CBE Live Office Hours</h3>
                <p className="text-sm text-muted-foreground">Watch builders share strategies in real-time</p>
              </div>
            </div>
            <Link href="/business/chaos-builder-exchange/concierge">
              <Button variant="outline" className="border-cyan-500/30 hover:bg-cyan-500/10 bg-transparent">
                <Video className="mr-2 h-4 w-4" />
                Join Stream
              </Button>
            </Link>
          </div>
          <TipFeed patchId="CBE" limit={5} variant="ticker" />
        </div>

        {/* Categories */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Browse by Category</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
            {CBE_CONFIG.categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(selectedCategory === category.id ? null : category.id)}
                className={`p-4 rounded-lg border text-center transition-all ${
                  selectedCategory === category.id
                    ? "border-cyan-500 bg-cyan-500/10 text-cyan-400"
                    : "border-border/50 bg-card/50 hover:border-cyan-500/50 hover:bg-cyan-500/5"
                }`}
              >
                <div className="flex justify-center mb-2">{categoryIcons[category.id]}</div>
                <span className="text-xs font-medium">{category.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Tabs for different views */}
        <Tabs defaultValue="featured" className="space-y-8">
          <TabsList className="bg-card/50 border border-border/50">
            <TabsTrigger value="featured">Featured</TabsTrigger>
            <TabsTrigger value="services">Services</TabsTrigger>
            <TabsTrigger value="opportunities">Opportunities</TabsTrigger>
            <TabsTrigger value="builders">Builders</TabsTrigger>
          </TabsList>

          <TabsContent value="featured" className="space-y-8">
            {/* Featured Builders */}
            <section>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold">Top Builders</h2>
                <Link
                  href="/business/chaos-builder-exchange/find-builders"
                  className="text-sm text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                >
                  View all <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {MOCK_BUILDERS.map((builder) => (
                  <BuilderCard key={builder.id} builder={builder} />
                ))}
              </div>
            </section>

            {/* Featured Listings */}
            <section>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold">Featured Services</h2>
                <Link
                  href="/business/chaos-builder-exchange/find-builders"
                  className="text-sm text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                >
                  View all <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {MOCK_LISTINGS.map((listing) => (
                  <ListingCard key={listing.id} listing={listing} />
                ))}
              </div>
            </section>

            {/* Open Opportunities */}
            <section>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold">Open Opportunities</h2>
                <Link
                  href="/business/chaos-builder-exchange/post-opportunity"
                  className="text-sm text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                >
                  Post opportunity <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {MOCK_OPPORTUNITIES.map((opp) => (
                  <OpportunityCard key={opp.id} opportunity={opp} />
                ))}
              </div>
            </section>
          </TabsContent>

          <TabsContent value="services">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {MOCK_LISTINGS.map((listing) => (
                <ListingCard key={listing.id} listing={listing} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="opportunities">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {MOCK_OPPORTUNITIES.map((opp) => (
                <OpportunityCard key={opp.id} opportunity={opp} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="builders">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {MOCK_BUILDERS.map((builder) => (
                <BuilderCard key={builder.id} builder={builder} />
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Stats Banner */}
        <div className="mt-16 p-8 rounded-2xl border border-cyan-500/30 bg-gradient-to-br from-cyan-500/5 to-transparent">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-cyan-400">500+</div>
              <div className="text-sm text-muted-foreground">Active Builders</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-cyan-400">$2.5M+</div>
              <div className="text-sm text-muted-foreground">Deal Flow</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-cyan-400">1,200+</div>
              <div className="text-sm text-muted-foreground">Projects Completed</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-cyan-400">4.9</div>
              <div className="text-sm text-muted-foreground">Avg. Rating</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
