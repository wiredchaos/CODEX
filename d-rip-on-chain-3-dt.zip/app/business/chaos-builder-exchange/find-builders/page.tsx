"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, BadgeCheck, Briefcase, Filter, Search, Star, Users, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { MOCK_BUILDERS, CBE_CONFIG, type BuilderProfile } from "@/config/chaos-builder-exchange"

function BuilderCard({ builder }: { builder: BuilderProfile }) {
  return (
    <Link href={`/business/chaos-builder-exchange/profile/${builder.id}`}>
      <Card className="group relative overflow-hidden border-border/50 bg-card/50 backdrop-blur-sm hover:border-cyan-500/50 transition-all duration-300 cursor-pointer h-full">
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

        {builder.isConcierge && (
          <div className="absolute top-4 right-4">
            <Badge className="bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0">CONCIERGE</Badge>
          </div>
        )}

        <CardHeader className="pb-3">
          <div className="flex items-start gap-4">
            <div className="relative">
              <img
                src={builder.avatarUrl || "/placeholder.svg?height=64&width=64&query=avatar"}
                alt={builder.displayName}
                className="w-16 h-16 rounded-full object-cover border-2 border-cyan-500/30"
              />
              {builder.isVerified && (
                <BadgeCheck className="absolute -bottom-1 -right-1 h-5 w-5 text-cyan-400 bg-background rounded-full" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <CardTitle className="text-lg truncate group-hover:text-cyan-400 transition-colors">
                {builder.displayName}
              </CardTitle>
              <CardDescription className="line-clamp-2">{builder.headline}</CardDescription>
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-1">
              <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
              <span className="font-medium">{builder.rating}</span>
              <span className="text-muted-foreground">({builder.reviewCount})</span>
            </div>
            <div className="flex items-center gap-1 text-muted-foreground">
              <Briefcase className="h-4 w-4" />
              <span>{builder.completedProjects} projects</span>
            </div>
          </div>

          <div className="flex flex-wrap gap-1">
            {builder.skills.slice(0, 3).map((skill) => (
              <Badge
                key={skill}
                variant="secondary"
                className="text-xs bg-cyan-500/10 text-cyan-400 border-cyan-500/20"
              >
                {skill}
              </Badge>
            ))}
            {builder.skills.length > 3 && (
              <Badge variant="secondary" className="text-xs">
                +{builder.skills.length - 3}
              </Badge>
            )}
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-border/50">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              {builder.trustBadges.includes("verified") && <BadgeCheck className="h-3 w-3 text-cyan-400" />}
              {builder.trustBadges.includes("top-rated") && <Star className="h-3 w-3 text-yellow-500" />}
              {builder.trustBadges.includes("fast-delivery") && <Zap className="h-3 w-3 text-orange-400" />}
            </div>
            {builder.hourlyRate && <span className="font-semibold text-cyan-400">${builder.hourlyRate}/hr</span>}
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}

export default function FindBuildersPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [showFilters, setShowFilters] = useState(false)

  const filteredBuilders = MOCK_BUILDERS.filter((builder) => {
    const matchesSearch =
      searchQuery === "" ||
      builder.displayName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      builder.headline.toLowerCase().includes(searchQuery.toLowerCase()) ||
      builder.skills.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase()))

    const matchesCategory =
      selectedCategories.length === 0 || builder.categories.some((c) => selectedCategories.includes(c))

    return matchesSearch && matchesCategory
  })

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <Link
          href="/business/chaos-builder-exchange"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-cyan-400 transition-colors mb-8"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Exchange
        </Link>

        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Find Builders</h1>
          <p className="text-muted-foreground">
            Discover talented entrepreneurs, consultants, and agencies ready to help you build.
          </p>
        </div>

        {/* Search and filters */}
        <div className="flex gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              placeholder="Search by name, skills, or expertise..."
              className="pl-10 h-12 bg-card/50 border-border/50 focus:border-cyan-500/50"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button
            variant="outline"
            className="h-12 border-border/50 hover:border-cyan-500/50 bg-transparent"
            onClick={() => setShowFilters(!showFilters)}
          >
            <Filter className="mr-2 h-4 w-4" />
            Filters
          </Button>
        </div>

        {/* Filter panel */}
        {showFilters && (
          <Card className="mb-8 border-border/50 bg-card/50">
            <CardHeader>
              <CardTitle className="text-lg">Filter by Category</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {CBE_CONFIG.categories.map((category) => (
                  <div key={category.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={category.id}
                      checked={selectedCategories.includes(category.id)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setSelectedCategories([...selectedCategories, category.id])
                        } else {
                          setSelectedCategories(selectedCategories.filter((c) => c !== category.id))
                        }
                      }}
                    />
                    <Label htmlFor={category.id} className="text-sm cursor-pointer">
                      {category.name}
                    </Label>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Results */}
        <div className="mb-4 text-sm text-muted-foreground">{filteredBuilders.length} builders found</div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredBuilders.map((builder) => (
            <BuilderCard key={builder.id} builder={builder} />
          ))}
        </div>

        {filteredBuilders.length === 0 && (
          <Card className="border-border/50 bg-card/50">
            <CardContent className="py-12 text-center">
              <Users className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No builders found</h3>
              <p className="text-muted-foreground">Try adjusting your search or filters.</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
