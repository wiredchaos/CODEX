"use client"

import Link from "next/link"
import {
  ArrowLeft,
  BadgeCheck,
  Briefcase,
  Clock,
  Github,
  Globe,
  Linkedin,
  MessageSquare,
  Star,
  Twitter,
  Users,
  Zap,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MOCK_BUILDERS, MOCK_LISTINGS, CBE_CONFIG } from "@/config/chaos-builder-exchange"

export default async function BuilderProfilePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const builder = MOCK_BUILDERS.find((b) => b.id === id)
  const listings = MOCK_LISTINGS.filter((l) => l.builderId === id)

  if (!builder) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Builder Not Found</h1>
        <Link href="/business/chaos-builder-exchange">
          <Button>Return to Exchange</Button>
        </Link>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="relative overflow-hidden border-b border-border/50">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,255,255,0.1),transparent_50%)]" />

        <div className="relative max-w-6xl mx-auto px-4 py-8">
          <Link
            href="/business/chaos-builder-exchange"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-cyan-400 transition-colors mb-8"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Exchange
          </Link>

          <div className="flex flex-col md:flex-row gap-8">
            {/* Avatar and basic info */}
            <div className="flex-shrink-0">
              <div className="relative">
                <img
                  src={builder.avatarUrl || "/placeholder.svg?height=200&width=200&query=avatar"}
                  alt={builder.displayName}
                  className="w-32 h-32 md:w-40 md:h-40 rounded-2xl object-cover border-4 border-cyan-500/30"
                />
                {builder.isVerified && (
                  <BadgeCheck className="absolute -bottom-2 -right-2 h-8 w-8 text-cyan-400 bg-background rounded-full p-1" />
                )}
              </div>
            </div>

            {/* Profile info */}
            <div className="flex-1">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h1 className="text-3xl font-bold flex items-center gap-3">
                    {builder.displayName}
                    {builder.isConcierge && (
                      <Badge className="bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0">
                        CONCIERGE
                      </Badge>
                    )}
                  </h1>
                  <p className="text-xl text-muted-foreground mt-1">{builder.headline}</p>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" className="border-cyan-500/30 hover:bg-cyan-500/10 bg-transparent">
                    <MessageSquare className="mr-2 h-4 w-4" />
                    Message
                  </Button>
                  <Button className="bg-cyan-500 hover:bg-cyan-600 text-black">Hire Now</Button>
                </div>
              </div>

              {/* Stats */}
              <div className="flex flex-wrap items-center gap-6 mt-6">
                <div className="flex items-center gap-2">
                  <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                  <span className="text-2xl font-bold">{builder.rating}</span>
                  <span className="text-muted-foreground">({builder.reviewCount} reviews)</span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Briefcase className="h-5 w-5" />
                  <span>{builder.completedProjects} projects</span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Clock className="h-5 w-5" />
                  <span>Responds {builder.responseTime}</span>
                </div>
                {builder.hourlyRate && (
                  <div className="flex items-center gap-2">
                    <span className="text-cyan-400 font-bold">${builder.hourlyRate}/hr</span>
                  </div>
                )}
              </div>

              {/* Trust badges */}
              <div className="flex flex-wrap gap-3 mt-4">
                {builder.trustBadges.map((badgeId) => {
                  const badge = CBE_CONFIG.trustBadges.find((b) => b.id === badgeId)
                  if (!badge) return null
                  return (
                    <div
                      key={badgeId}
                      className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/20"
                    >
                      {badgeId === "verified" && <BadgeCheck className="h-4 w-4 text-cyan-400" />}
                      {badgeId === "top-rated" && <Star className="h-4 w-4 text-yellow-500" />}
                      {badgeId === "fast-delivery" && <Zap className="h-4 w-4 text-orange-400" />}
                      {badgeId === "repeat-clients" && <Users className="h-4 w-4 text-green-400" />}
                      {badgeId === "neuro-certified" && (
                        <span className="h-4 w-4 text-xs font-bold text-red-500">N</span>
                      )}
                      <span className="text-sm font-medium">{badge.name}</span>
                    </div>
                  )
                })}
              </div>

              {/* Social links */}
              <div className="flex gap-3 mt-4">
                {builder.socialLinks.twitter && (
                  <a
                    href={`https://twitter.com/${builder.socialLinks.twitter}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-lg bg-card/50 border border-border/50 hover:border-cyan-500/50 transition-colors"
                  >
                    <Twitter className="h-5 w-5" />
                  </a>
                )}
                {builder.socialLinks.linkedin && (
                  <a
                    href={`https://linkedin.com/in/${builder.socialLinks.linkedin}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-lg bg-card/50 border border-border/50 hover:border-cyan-500/50 transition-colors"
                  >
                    <Linkedin className="h-5 w-5" />
                  </a>
                )}
                {builder.socialLinks.github && (
                  <a
                    href={`https://github.com/${builder.socialLinks.github}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-lg bg-card/50 border border-border/50 hover:border-cyan-500/50 transition-colors"
                  >
                    <Github className="h-5 w-5" />
                  </a>
                )}
                {builder.socialLinks.website && (
                  <a
                    href={`https://${builder.socialLinks.website}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-lg bg-card/50 border border-border/50 hover:border-cyan-500/50 transition-colors"
                  >
                    <Globe className="h-5 w-5" />
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-4 py-8">
        <Tabs defaultValue="about" className="space-y-8">
          <TabsList className="bg-card/50 border border-border/50">
            <TabsTrigger value="about">About</TabsTrigger>
            <TabsTrigger value="services">Services ({listings.length})</TabsTrigger>
            <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
            <TabsTrigger value="reviews">Reviews</TabsTrigger>
          </TabsList>

          <TabsContent value="about" className="space-y-8">
            <Card className="border-border/50 bg-card/50">
              <CardHeader>
                <CardTitle>About</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">{builder.bio}</p>
              </CardContent>
            </Card>

            <div className="grid md:grid-cols-2 gap-6">
              <Card className="border-border/50 bg-card/50">
                <CardHeader>
                  <CardTitle>Skills</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {builder.skills.map((skill) => (
                      <Badge
                        key={skill}
                        variant="secondary"
                        className="bg-cyan-500/10 text-cyan-400 border-cyan-500/20"
                      >
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/50 bg-card/50">
                <CardHeader>
                  <CardTitle>Industries</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {builder.industries.map((industry) => (
                      <Badge key={industry} variant="outline">
                        {industry}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="services">
            {listings.length > 0 ? (
              <div className="grid md:grid-cols-2 gap-6">
                {listings.map((listing) => (
                  <Link key={listing.id} href={`/business/chaos-builder-exchange/listing/${listing.id}`}>
                    <Card className="h-full border-border/50 bg-card/50 hover:border-cyan-500/50 transition-colors cursor-pointer">
                      <CardHeader>
                        <CardTitle className="text-lg">{listing.title}</CardTitle>
                        <CardDescription>{listing.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                            <span>{listing.rating}</span>
                            <span className="text-muted-foreground">({listing.reviewCount})</span>
                          </div>
                          <span className="text-xl font-bold text-cyan-400">${listing.basePrice.toLocaleString()}</span>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            ) : (
              <Card className="border-border/50 bg-card/50">
                <CardContent className="py-12 text-center text-muted-foreground">No services listed yet.</CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="portfolio">
            {builder.portfolioItems.length > 0 ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {builder.portfolioItems.map((item) => (
                  <Card key={item.id} className="border-border/50 bg-card/50">
                    <CardHeader>
                      <CardTitle className="text-lg">{item.title}</CardTitle>
                      <CardDescription>{item.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-1">
                        {item.tags.map((tag) => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="border-border/50 bg-card/50">
                <CardContent className="py-12 text-center text-muted-foreground">Portfolio coming soon.</CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="reviews">
            <Card className="border-border/50 bg-card/50">
              <CardContent className="py-12 text-center text-muted-foreground">
                Reviews will be displayed here once available.
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
