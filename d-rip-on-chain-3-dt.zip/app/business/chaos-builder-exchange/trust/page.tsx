"use client"

import Link from "next/link"
import { useState } from "react"
import {
  ArrowLeft,
  Shield,
  FileCheck,
  Award,
  Coins,
  TrendingUp,
  TrendingDown,
  Minus,
  CheckCircle2,
  Lock,
  Zap,
  BadgeCheck,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Mock data for demonstration
const MOCK_TRUST_SCORE = {
  builderId: "builder_001",
  identityScore: 75,
  contractScore: 82,
  credentialScore: 65,
  communityScore: 58,
  overallScore: 73,
  trustTier: "GOLD" as const,
  trend: "UP" as const,
}

const MOCK_CREDENTIALS = [
  { type: "PROJECT_COMPLETION", title: "AI Strategy Implementation", client: "TechCorp", date: "2024-11" },
  { type: "CLIENT_TESTIMONIAL", title: "Outstanding Consultation", client: "StartupX", date: "2024-10" },
  { type: "SKILL_VERIFICATION", title: "Certified Prompt Engineer", client: "CBE", date: "2024-09" },
]

const MOCK_TOKENS = [
  { type: "ONBOARDING_COMPLETE", amount: 100, date: "2024-08" },
  { type: "FIRST_SERVICE_PUBLISHED", amount: 50, date: "2024-08" },
  { type: "FIRST_PROJECT_COMPLETED", amount: 200, date: "2024-09" },
  { type: "REFERRAL_BONUS", amount: 150, date: "2024-10" },
]

const tierColors = {
  BRONZE: "#CD7F32",
  SILVER: "#C0C0C0",
  GOLD: "#FFD700",
  PLATINUM: "#E5E4E2",
  DIAMOND: "#B9F2FF",
}

const tierDescriptions = {
  BRONZE: "New builder establishing reputation",
  SILVER: "Active builder with growing track record",
  GOLD: "Established builder with proven results",
  PLATINUM: "Elite builder with exceptional reputation",
  DIAMOND: "Top-tier builder with outstanding credentials",
}

export default function TrustPage() {
  const [activeTab, setActiveTab] = useState("overview")
  const tokenBalance = MOCK_TOKENS.reduce((sum, t) => sum + t.amount, 0)

  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      {/* Header */}
      <header className="border-b border-[#1A1D1F] bg-[#0A0A0A]/95 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Link href="/business/chaos-builder-exchange">
              <Button variant="ghost" size="icon" className="text-[#5E6C72] hover:text-[#00F0FF]">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-xl font-bold text-[#F2F9FB]">Trust & Credentials</h1>
              <p className="text-sm text-[#5E6C72]">Blockchain-verified reputation system</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 space-y-8">
        {/* Trust Score Overview */}
        <Card className="border-[#1A1D1F] bg-gradient-to-br from-[#1A1D1F] to-[#0A0A0A]">
          <CardContent className="p-8">
            <div className="flex flex-col lg:flex-row items-center gap-8">
              {/* Score Circle */}
              <div className="relative">
                <div
                  className="w-40 h-40 rounded-full flex items-center justify-center border-4"
                  style={{ borderColor: tierColors[MOCK_TRUST_SCORE.trustTier] }}
                >
                  <div className="text-center">
                    <div className="text-4xl font-bold text-[#F2F9FB]">{MOCK_TRUST_SCORE.overallScore}</div>
                    <div className="text-sm text-[#5E6C72]">Trust Score</div>
                  </div>
                </div>
                <div
                  className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full text-xs font-bold"
                  style={{
                    backgroundColor: tierColors[MOCK_TRUST_SCORE.trustTier],
                    color: MOCK_TRUST_SCORE.trustTier === "DIAMOND" ? "#0A0A0A" : "#0A0A0A",
                  }}
                >
                  {MOCK_TRUST_SCORE.trustTier}
                </div>
              </div>

              {/* Score Breakdown */}
              <div className="flex-1 space-y-4 w-full">
                <div className="flex items-center gap-2 mb-4">
                  {MOCK_TRUST_SCORE.trend === "UP" && <TrendingUp className="h-5 w-5 text-green-500" />}
                  {MOCK_TRUST_SCORE.trend === "DOWN" && <TrendingDown className="h-5 w-5 text-red-500" />}
                  {MOCK_TRUST_SCORE.trend === "STABLE" && <Minus className="h-5 w-5 text-[#5E6C72]" />}
                  <span className="text-[#5E6C72]">{tierDescriptions[MOCK_TRUST_SCORE.trustTier]}</span>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-[#5E6C72] flex items-center gap-2">
                        <Shield className="h-4 w-4" /> Identity
                      </span>
                      <span className="text-sm font-medium text-[#F2F9FB]">{MOCK_TRUST_SCORE.identityScore}</span>
                    </div>
                    <Progress value={MOCK_TRUST_SCORE.identityScore} className="h-2" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-[#5E6C72] flex items-center gap-2">
                        <FileCheck className="h-4 w-4" /> Contracts
                      </span>
                      <span className="text-sm font-medium text-[#F2F9FB]">{MOCK_TRUST_SCORE.contractScore}</span>
                    </div>
                    <Progress value={MOCK_TRUST_SCORE.contractScore} className="h-2" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-[#5E6C72] flex items-center gap-2">
                        <Award className="h-4 w-4" /> Credentials
                      </span>
                      <span className="text-sm font-medium text-[#F2F9FB]">{MOCK_TRUST_SCORE.credentialScore}</span>
                    </div>
                    <Progress value={MOCK_TRUST_SCORE.credentialScore} className="h-2" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-[#5E6C72] flex items-center gap-2">
                        <Coins className="h-4 w-4" /> Community
                      </span>
                      <span className="text-sm font-medium text-[#F2F9FB]">{MOCK_TRUST_SCORE.communityScore}</span>
                    </div>
                    <Progress value={MOCK_TRUST_SCORE.communityScore} className="h-2" />
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-[#1A1D1F] border border-[#1A1D1F]">
            <TabsTrigger
              value="overview"
              className="data-[state=active]:bg-[#00F0FF] data-[state=active]:text-[#0A0A0A]"
            >
              Overview
            </TabsTrigger>
            <TabsTrigger
              value="credentials"
              className="data-[state=active]:bg-[#00F0FF] data-[state=active]:text-[#0A0A0A]"
            >
              Credentials (PoWL)
            </TabsTrigger>
            <TabsTrigger value="tokens" className="data-[state=active]:bg-[#00F0FF] data-[state=active]:text-[#0A0A0A]">
              Tokens (OT)
            </TabsTrigger>
            <TabsTrigger
              value="identity"
              className="data-[state=active]:bg-[#00F0FF] data-[state=active]:text-[#0A0A0A]"
            >
              Identity (BIBS)
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6 mt-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="border-[#1A1D1F] bg-[#1A1D1F]/50">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-[#5E6C72]">Identity Seal</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <BadgeCheck className="h-6 w-6 text-[#00F0FF]" />
                    <span className="text-lg font-bold text-[#F2F9FB]">PREMIUM</span>
                  </div>
                  <p className="text-xs text-[#5E6C72] mt-1">3/4 verifications complete</p>
                </CardContent>
              </Card>

              <Card className="border-[#1A1D1F] bg-[#1A1D1F]/50">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-[#5E6C72]">Smart Contracts</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <FileCheck className="h-6 w-6 text-green-500" />
                    <span className="text-lg font-bold text-[#F2F9FB]">12 / 14</span>
                  </div>
                  <p className="text-xs text-[#5E6C72] mt-1">86% completion rate</p>
                </CardContent>
              </Card>

              <Card className="border-[#1A1D1F] bg-[#1A1D1F]/50">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-[#5E6C72]">Proof of Work</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Award className="h-6 w-6 text-[#FFD16F]" />
                    <span className="text-lg font-bold text-[#F2F9FB]">{MOCK_CREDENTIALS.length}</span>
                  </div>
                  <p className="text-xs text-[#5E6C72] mt-1">Verified credentials</p>
                </CardContent>
              </Card>

              <Card className="border-[#1A1D1F] bg-[#1A1D1F]/50">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm text-[#5E6C72]">Token Balance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Coins className="h-6 w-6 text-[#00F0FF]" />
                    <span className="text-lg font-bold text-[#F2F9FB]">{tokenBalance} OT</span>
                  </div>
                  <p className="text-xs text-[#5E6C72] mt-1">Available to redeem</p>
                </CardContent>
              </Card>
            </div>

            {/* Value Proposition */}
            <Card className="border-[#1A1D1F] bg-[#1A1D1F]/50">
              <CardHeader>
                <CardTitle className="text-[#F2F9FB]">Blockchain-Verified Trust</CardTitle>
                <CardDescription>Why CBE uses blockchain where it matters</CardDescription>
              </CardHeader>
              <CardContent className="grid md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-[#00F0FF]">
                    <Shield className="h-5 w-5" />
                    <span className="font-semibold">Identity Trust</span>
                  </div>
                  <p className="text-sm text-[#5E6C72]">
                    Cryptographic verification eliminates fake profiles. Your BIBS seal proves you are who you claim to
                    be.
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-[#00F0FF]">
                    <Lock className="h-5 w-5" />
                    <span className="font-semibold">Contract Security</span>
                  </div>
                  <p className="text-sm text-[#5E6C72]">
                    Smart contracts with escrow eliminate payment disputes. Funds release automatically on milestone
                    approval.
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-[#00F0FF]">
                    <Award className="h-5 w-5" />
                    <span className="font-semibold">Immutable Proof</span>
                  </div>
                  <p className="text-sm text-[#5E6C72]">
                    Every completed project becomes a permanent, verifiable credential that cannot be forged or
                    fabricated.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Credentials Tab */}
          <TabsContent value="credentials" className="space-y-6 mt-6">
            <Card className="border-[#1A1D1F] bg-[#1A1D1F]/50">
              <CardHeader>
                <CardTitle className="text-[#F2F9FB]">Proof-of-Work Ledger (PoWL)</CardTitle>
                <CardDescription>Non-transferable credentials for verified achievements</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {MOCK_CREDENTIALS.map((cred, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between p-4 rounded-lg border border-[#1A1D1F] bg-[#0A0A0A]"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-full bg-[#1A1D1F] flex items-center justify-center">
                        {cred.type === "PROJECT_COMPLETION" && <CheckCircle2 className="h-6 w-6 text-green-500" />}
                        {cred.type === "CLIENT_TESTIMONIAL" && <Award className="h-6 w-6 text-[#FFD16F]" />}
                        {cred.type === "SKILL_VERIFICATION" && <BadgeCheck className="h-6 w-6 text-[#00F0FF]" />}
                      </div>
                      <div>
                        <div className="font-medium text-[#F2F9FB]">{cred.title}</div>
                        <div className="text-sm text-[#5E6C72]">
                          {cred.client} • {cred.date}
                        </div>
                      </div>
                    </div>
                    <Badge variant="outline" className="border-[#00F0FF] text-[#00F0FF]">
                      Verified
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tokens Tab */}
          <TabsContent value="tokens" className="space-y-6 mt-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="border-[#1A1D1F] bg-[#1A1D1F]/50">
                <CardHeader>
                  <CardTitle className="text-[#F2F9FB]">Token History</CardTitle>
                  <CardDescription>Opportunity Tokens earned</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {MOCK_TOKENS.map((token, i) => (
                    <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-[#0A0A0A]">
                      <div className="flex items-center gap-3">
                        <Zap className="h-5 w-5 text-[#FFD16F]" />
                        <span className="text-sm text-[#F2F9FB]">{token.type.replace(/_/g, " ")}</span>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-[#00F0FF]">+{token.amount} OT</div>
                        <div className="text-xs text-[#5E6C72]">{token.date}</div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card className="border-[#1A1D1F] bg-[#1A1D1F]/50">
                <CardHeader>
                  <CardTitle className="text-[#F2F9FB]">Redeem Tokens</CardTitle>
                  <CardDescription>Balance: {tokenBalance} OT</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { name: "7-Day Profile Boost", cost: 200 },
                    { name: "Featured Placement", cost: 500 },
                    { name: "Concierge Priority", cost: 300 },
                    { name: "Premium Badge (30d)", cost: 400 },
                  ].map((option, i) => (
                    <div key={i} className="flex items-center justify-between p-3 rounded-lg border border-[#1A1D1F]">
                      <span className="text-sm text-[#F2F9FB]">{option.name}</span>
                      <Button
                        size="sm"
                        variant={tokenBalance >= option.cost ? "default" : "outline"}
                        disabled={tokenBalance < option.cost}
                        className={
                          tokenBalance >= option.cost ? "bg-[#00F0FF] text-[#0A0A0A] hover:bg-[#00F0FF]/90" : ""
                        }
                      >
                        {option.cost} OT
                      </Button>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Identity Tab */}
          <TabsContent value="identity" className="space-y-6 mt-6">
            <Card className="border-[#1A1D1F] bg-[#1A1D1F]/50">
              <CardHeader>
                <CardTitle className="text-[#F2F9FB]">Builder Identity Blockchain Seal (BIBS)</CardTitle>
                <CardDescription>Cryptographic verification of your identity</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center gap-4 p-4 rounded-lg bg-gradient-to-r from-[#00F0FF]/10 to-transparent border border-[#00F0FF]/30">
                  <BadgeCheck className="h-12 w-12 text-[#00F0FF]" />
                  <div>
                    <div className="text-lg font-bold text-[#F2F9FB]">PREMIUM Verification Level</div>
                    <div className="text-sm text-[#5E6C72]">3 of 4 verification checks complete</div>
                  </div>
                </div>

                <div className="space-y-3">
                  {[
                    { name: "Identity Proof", desc: "Government ID or equivalent", done: true },
                    { name: "Portfolio Verified", desc: "Work samples authenticated", done: true },
                    { name: "Business Verified", desc: "Business registration confirmed", done: true },
                    { name: "Reference Checked", desc: "3 professional references verified", done: false },
                  ].map((check, i) => (
                    <div key={i} className="flex items-center justify-between p-4 rounded-lg border border-[#1A1D1F]">
                      <div className="flex items-center gap-3">
                        {check.done ? (
                          <CheckCircle2 className="h-5 w-5 text-green-500" />
                        ) : (
                          <div className="h-5 w-5 rounded-full border-2 border-[#5E6C72]" />
                        )}
                        <div>
                          <div className="font-medium text-[#F2F9FB]">{check.name}</div>
                          <div className="text-sm text-[#5E6C72]">{check.desc}</div>
                        </div>
                      </div>
                      {!check.done && (
                        <Button size="sm" variant="outline" className="border-[#00F0FF] text-[#00F0FF] bg-transparent">
                          Verify
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
