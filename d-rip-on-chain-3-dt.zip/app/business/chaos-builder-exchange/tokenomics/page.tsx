"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  Coins,
  Shield,
  Award,
  ArrowRight,
  CheckCircle,
  ChevronDown,
  ChevronUp,
  Lock,
  Zap,
  TrendingUp,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CBE_TOKENOMICS, SCC_FLOW, PWK_FLOW, BIS_FLOW } from "@/lib/blockchain/tokenomics"

// Brand colors
const CHAOS_CYAN = "#00F0FF"
const INFRARED_FLUX = "#FF003C"
const CIRCUIT_GOLD = "#FFD16F"

function TokenCard({
  symbol,
  name,
  description,
  icon: Icon,
  color,
  features,
}: {
  symbol: string
  name: string
  description: string
  icon: React.ElementType
  color: string
  features: string[]
}) {
  const [expanded, setExpanded] = useState(false)

  return (
    <Card
      className="bg-[#0A0A0A] border-[#1A1D1F] hover:border-opacity-80 transition-all"
      style={{ borderColor: color }}
    >
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-lg" style={{ backgroundColor: `${color}20` }}>
              <Icon className="w-6 h-6" style={{ color }} />
            </div>
            <div>
              <CardTitle className="text-white flex items-center gap-2">
                {name}
                <Badge variant="outline" className="text-xs" style={{ borderColor: color, color }}>
                  {symbol}
                </Badge>
              </CardTitle>
              <CardDescription className="text-[#5E6C72]">{description}</CardDescription>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setExpanded(!expanded)} className="text-[#5E6C72]">
            {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </Button>
        </div>
      </CardHeader>
      {expanded && (
        <CardContent className="pt-0">
          <div className="space-y-2">
            {features.map((feature, idx) => (
              <div key={idx} className="flex items-center gap-2 text-sm text-[#F2F9FB]">
                <CheckCircle className="w-4 h-4" style={{ color }} />
                {feature}
              </div>
            ))}
          </div>
          <div className="mt-4 flex gap-2">
            <Badge variant="secondary" className="bg-[#1A1D1F] text-[#5E6C72]">
              <Lock className="w-3 h-3 mr-1" />
              Non-Transferable
            </Badge>
            <Badge variant="secondary" className="bg-[#1A1D1F] text-[#5E6C72]">
              <Shield className="w-3 h-3 mr-1" />
              Non-Tradeable
            </Badge>
          </div>
        </CardContent>
      )}
    </Card>
  )
}

function FlowDiagram({ flow }: { flow: typeof SCC_FLOW }) {
  return (
    <div className="space-y-3">
      {flow.steps.map((step, idx) => (
        <div key={step.step} className="flex items-start gap-3">
          <div className="flex flex-col items-center">
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                step.isDecision ? "bg-[#FFD16F]/20 text-[#FFD16F]" : "bg-[#00F0FF]/20 text-[#00F0FF]"
              }`}
            >
              {idx + 1}
            </div>
            {idx < flow.steps.length - 1 && <div className="w-0.5 h-8 bg-[#1A1D1F] my-1" />}
          </div>
          <div className="flex-1 pb-4">
            <p className="text-white font-medium">{step.description}</p>
            {step.isDecision && step.outcomes && (
              <div className="mt-2 flex gap-2">
                {step.outcomes.map((outcome) => (
                  <Badge
                    key={outcome.condition}
                    variant="outline"
                    className={`text-xs ${
                      outcome.condition === "Approved" || outcome.condition === "Successful"
                        ? "border-green-500 text-green-400"
                        : "border-red-500 text-red-400"
                    }`}
                  >
                    {outcome.condition} → {outcome.next}
                  </Badge>
                ))}
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  )
}

function EarningTable() {
  const earnings = [
    { action: "Complete Onboarding", tokens: 100, frequency: "One-time" },
    { action: "Publish First Service", tokens: 50, frequency: "One-time" },
    { action: "Complete First Project", tokens: 200, frequency: "One-time" },
    { action: "Receive First Review", tokens: 75, frequency: "One-time" },
    { action: "Early Delivery Bonus", tokens: 50, frequency: "Per project" },
    { action: "Referral Bonus", tokens: 150, frequency: "Per referral" },
    { action: "Seasonal Events", tokens: 100, frequency: "Limited time" },
    { action: "Community Contribution", tokens: 25, frequency: "Per contribution" },
  ]

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-[#1A1D1F]">
            <th className="text-left py-3 px-4 text-[#5E6C72] font-medium">Action</th>
            <th className="text-right py-3 px-4 text-[#5E6C72] font-medium">OT Reward</th>
            <th className="text-right py-3 px-4 text-[#5E6C72] font-medium">Frequency</th>
          </tr>
        </thead>
        <tbody>
          {earnings.map((item) => (
            <tr key={item.action} className="border-b border-[#1A1D1F]/50 hover:bg-[#1A1D1F]/30">
              <td className="py-3 px-4 text-white">{item.action}</td>
              <td className="py-3 px-4 text-right">
                <span className="text-[#00F0FF] font-mono">{item.tokens} OT</span>
              </td>
              <td className="py-3 px-4 text-right text-[#5E6C72]">{item.frequency}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function RedemptionTable() {
  const redemptions = [
    { item: "Service Boost (7 days)", cost: 200, category: "BOOST" },
    { item: "Profile Promotion (14 days)", cost: 300, category: "PLACEMENT" },
    { item: "Priority Placement (30 days)", cost: 500, category: "PLACEMENT" },
    { item: "Concierge Priority", cost: 400, category: "CONCIERGE" },
    { item: "Premium Templates", cost: 150, category: "UNLOCK" },
    { item: "10% Service Discount", cost: 100, category: "DISCOUNT" },
  ]

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-[#1A1D1F]">
            <th className="text-left py-3 px-4 text-[#5E6C72] font-medium">Utility</th>
            <th className="text-right py-3 px-4 text-[#5E6C72] font-medium">OT Cost</th>
            <th className="text-right py-3 px-4 text-[#5E6C72] font-medium">Category</th>
          </tr>
        </thead>
        <tbody>
          {redemptions.map((item) => (
            <tr key={item.item} className="border-b border-[#1A1D1F]/50 hover:bg-[#1A1D1F]/30">
              <td className="py-3 px-4 text-white">{item.item}</td>
              <td className="py-3 px-4 text-right">
                <span className="text-[#FFD16F] font-mono">{item.cost} OT</span>
              </td>
              <td className="py-3 px-4 text-right">
                <Badge variant="outline" className="border-[#5E6C72] text-[#5E6C72]">
                  {item.category}
                </Badge>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default function TokenomicsPage() {
  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      {/* Header */}
      <header className="border-b border-[#1A1D1F] bg-[#0A0A0A]/95 backdrop-blur sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/business/chaos-builder-exchange">
                <Button variant="ghost" size="sm" className="text-[#5E6C72] hover:text-white">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to CBE
                </Button>
              </Link>
              <div className="h-6 w-px bg-[#1A1D1F]" />
              <h1 className="text-xl font-bold text-white">Tokenomics</h1>
              <Badge className="bg-green-500/20 text-green-400 border-green-500/50">Regulatory Safe</Badge>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Hero */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">Non-Speculative Token Architecture</h2>
          <p className="text-xl text-[#5E6C72] max-w-2xl mx-auto">
            CBE uses blockchain without creating speculative assets. All tokens are utility-only, non-transferable, and
            designed for platform functionality.
          </p>
        </div>

        {/* Core Principles */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-12">
          {Object.entries(CBE_TOKENOMICS.principles).map(([key, value]) => (
            <Card key={key} className="bg-[#0A0A0A] border-[#1A1D1F]">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  <span className="text-[#5E6C72] text-sm">{key.replace(/_/g, " ")}</span>
                </div>
                <p className="text-white text-sm">{value}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Token Types */}
        <section className="mb-12">
          <h3 className="text-2xl font-bold text-white mb-6">Token Types</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <TokenCard
              symbol="OT"
              name="Opportunity Tokens"
              description="Internal utility credits"
              icon={Coins}
              color={CHAOS_CYAN}
              features={[
                "Earned through platform activity",
                "Used for boosts & promotions",
                "Priority placement access",
                "Template unlocks",
                "NOT sold to public",
                "NOT tradable or transferable",
              ]}
            />
            <TokenCard
              symbol="BIS"
              name="Builder Identity Seal"
              description="Verification token"
              icon={Shield}
              color={INFRARED_FLUX}
              features={[
                "One-time verification stamp",
                "Confirms identity & portfolio",
                "Similar to professional license",
                "Revoked if fraud detected",
                "Non-transferable badge",
                "Enables premium features",
              ]}
            />
            <TokenCard
              symbol="PWK"
              name="Proof-of-Work Key"
              description="Reputation asset"
              icon={Award}
              color={CIRCUIT_GOLD}
              features={[
                "Generated per completed project",
                "Immutable proof of delivery",
                "Increases reputation score",
                "Cannot be transferred",
                "Linked to contract hash",
                "Builds long-term trust",
              ]}
            />
          </div>
        </section>

        <Tabs defaultValue="earning" className="mb-12">
          <TabsList className="bg-[#1A1D1F] border border-[#2A2D2F]">
            <TabsTrigger
              value="earning"
              className="data-[state=active]:bg-[#00F0FF]/20 data-[state=active]:text-[#00F0FF]"
            >
              <Zap className="w-4 h-4 mr-2" />
              Earning OT
            </TabsTrigger>
            <TabsTrigger
              value="redemption"
              className="data-[state=active]:bg-[#FFD16F]/20 data-[state=active]:text-[#FFD16F]"
            >
              <TrendingUp className="w-4 h-4 mr-2" />
              Redeeming OT
            </TabsTrigger>
            <TabsTrigger
              value="flows"
              className="data-[state=active]:bg-[#FF003C]/20 data-[state=active]:text-[#FF003C]"
            >
              <ArrowRight className="w-4 h-4 mr-2" />
              Contract Flows
            </TabsTrigger>
          </TabsList>

          <TabsContent value="earning" className="mt-6">
            <Card className="bg-[#0A0A0A] border-[#1A1D1F]">
              <CardHeader>
                <CardTitle className="text-white">How to Earn Opportunity Tokens</CardTitle>
                <CardDescription className="text-[#5E6C72]">
                  OTs are earned through activity, never purchased
                </CardDescription>
              </CardHeader>
              <CardContent>
                <EarningTable />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="redemption" className="mt-6">
            <Card className="bg-[#0A0A0A] border-[#1A1D1F]">
              <CardHeader>
                <CardTitle className="text-white">Redemption Options</CardTitle>
                <CardDescription className="text-[#5E6C72]">
                  Use your OT for platform features and boosts
                </CardDescription>
              </CardHeader>
              <CardContent>
                <RedemptionTable />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="flows" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="bg-[#0A0A0A] border-[#1A1D1F]">
                <CardHeader>
                  <CardTitle className="text-white text-lg">Service Booking (SCC)</CardTitle>
                  <CardDescription className="text-[#5E6C72]">Smart Collaboration Contract</CardDescription>
                </CardHeader>
                <CardContent>
                  <FlowDiagram flow={SCC_FLOW} />
                </CardContent>
              </Card>

              <Card className="bg-[#0A0A0A] border-[#1A1D1F]">
                <CardHeader>
                  <CardTitle className="text-white text-lg">Proof-of-Work (PWK)</CardTitle>
                  <CardDescription className="text-[#5E6C72]">Credential Generation</CardDescription>
                </CardHeader>
                <CardContent>
                  <FlowDiagram flow={PWK_FLOW} />
                </CardContent>
              </Card>

              <Card className="bg-[#0A0A0A] border-[#1A1D1F]">
                <CardHeader>
                  <CardTitle className="text-white text-lg">Identity Seal (BIS)</CardTitle>
                  <CardDescription className="text-[#5E6C72]">Verification Process</CardDescription>
                </CardHeader>
                <CardContent>
                  <FlowDiagram flow={BIS_FLOW} />
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Compliance Notice */}
        <Card className="bg-[#0A0A0A] border-green-500/30">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-lg bg-green-500/20">
                <Shield className="w-6 h-6 text-green-400" />
              </div>
              <div>
                <h4 className="text-white font-bold mb-2">Regulatory Compliance</h4>
                <p className="text-[#5E6C72] mb-4">
                  CBE tokens are designed to be regulatory-safe under utility token frameworks. There is no expectation
                  of profit, no trading pairs, and no speculative mechanics.
                </p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline" className="border-green-500/50 text-green-400">
                    Not a Security
                  </Badge>
                  <Badge variant="outline" className="border-green-500/50 text-green-400">
                    No Profit Expectation
                  </Badge>
                  <Badge variant="outline" className="border-green-500/50 text-green-400">
                    Platform-Controlled
                  </Badge>
                  <Badge variant="outline" className="border-green-500/50 text-green-400">
                    Utility Only
                  </Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
