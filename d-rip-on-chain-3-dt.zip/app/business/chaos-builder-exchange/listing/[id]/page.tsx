"use client"

import { use } from "react"
import Link from "next/link"
import { ArrowLeft, BadgeCheck, Check, Clock, MessageSquare, RefreshCw, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MOCK_BUILDERS, MOCK_LISTINGS, CBE_CONFIG } from "@/config/chaos-builder-exchange"

export default function ListingPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const listing = MOCK_LISTINGS.find((l) => l.id === id)
  const builder = listing ? MOCK_BUILDERS.find((b) => b.id === listing.builderId) : null

  if (!listing || !builder) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Listing Not Found</h1>
        <Link href="/business/chaos-builder-exchange">
          <Button>Return to Exchange</Button>
        </Link>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <Link
          href="/business/chaos-builder-exchange"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-cyan-400 transition-colors mb-8"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Exchange
        </Link>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main content */}
          <div className="lg:col-span-2 space-y-6">
            <div>
              {listing.isFeatured && (
                <Badge className="mb-4 bg-gradient-to-r from-cyan-500 to-blue-500 text-white border-0">FEATURED</Badge>
              )}
              <h1 className="text-3xl font-bold mb-4">{listing.title}</h1>

              {/* Builder info */}
              <Link
                href={`/business/chaos-builder-exchange/profile/${builder.id}`}
                className="flex items-center gap-3 p-3 rounded-lg bg-card/50 border border-border/50 hover:border-cyan-500/50 transition-colors w-fit"
              >
                <img
                  src={builder.avatarUrl || "/placeholder.svg?height=48&width=48&query=avatar"}
                  alt={builder.displayName}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold">{builder.displayName}</span>
                    {builder.isVerified && <BadgeCheck className="h-4 w-4 text-cyan-400" />}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Star className="h-3 w-3 text-yellow-500 fill-yellow-500" />
                    <span>{builder.rating}</span>
                    <span>({builder.reviewCount} reviews)</span>
                  </div>
                </div>
              </Link>
            </div>

            <Card className="border-border/50 bg-card/50">
              <CardHeader>
                <CardTitle>About This Service</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">{listing.description}</p>
              </CardContent>
            </Card>

            <Card className="border-border/50 bg-card/50">
              <CardHeader>
                <CardTitle>What You Get</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {listing.deliverables.map((item, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <Check className="h-5 w-5 text-cyan-400 mt-0.5 flex-shrink-0" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="border-border/50 bg-card/50">
              <CardHeader>
                <CardTitle>Tags</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {listing.tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="bg-cyan-500/10 text-cyan-400 border-cyan-500/20">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Card className="border-cyan-500/30 bg-card/50 sticky top-24">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <Badge variant="outline">
                    {CBE_CONFIG.pricingTiers.find((t) => t.id === listing.pricingTier)?.name}
                  </Badge>
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                    <span className="font-medium">{listing.rating}</span>
                    <span className="text-muted-foreground text-sm">({listing.reviewCount})</span>
                  </div>
                </div>
                <CardTitle className="text-4xl text-cyan-400">${listing.basePrice.toLocaleString()}</CardTitle>
                <CardDescription>Starting price</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3 text-sm">
                  <div className="flex items-center gap-3">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span>Delivery: {listing.timeline}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <RefreshCw className="h-4 w-4 text-muted-foreground" />
                    <span>{listing.revisions} revisions included</span>
                  </div>
                </div>

                <div className="space-y-2 pt-4">
                  <Button className="w-full bg-cyan-500 hover:bg-cyan-600 text-black font-semibold">
                    Order Now - ${listing.basePrice.toLocaleString()}
                  </Button>
                  <Button variant="outline" className="w-full border-cyan-500/30 hover:bg-cyan-500/10 bg-transparent">
                    <MessageSquare className="mr-2 h-4 w-4" />
                    Contact Builder
                  </Button>
                </div>

                <p className="text-xs text-center text-muted-foreground pt-2">{listing.orderCount} orders completed</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
