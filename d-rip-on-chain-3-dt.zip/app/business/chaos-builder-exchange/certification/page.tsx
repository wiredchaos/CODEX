"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import {
  Award,
  CheckCircle2,
  Clock,
  GraduationCap,
  Shield,
  Star,
  Target,
  Trophy,
  Users,
  Zap,
  BookOpen,
  ArrowRight,
  Lock,
} from "lucide-react"
import {
  CERTIFICATIONS,
  CERTIFICATION_MODULES,
  type CertificationTier,
  type CertificationModule,
} from "@/lib/cbe/certification"

export default function CBECertificationPage() {
  const [selectedTier, setSelectedTier] = useState<CertificationTier>("VBC")
  const [expandedModule, setExpandedModule] = useState<string | null>(null)

  const cert = CERTIFICATIONS[selectedTier]
  const modules = CERTIFICATION_MODULES[selectedTier]

  // Demo builder stats
  const builderStats = {
    bisVerified: true,
    pwkCount: 8,
    reputationScore: 72,
    completedSCCs: 12,
    disputeEscalations: 0,
    governanceViolations: 0,
    currentCertifications: ["VBC"] as CertificationTier[],
  }

  const getTierIcon = (tier: CertificationTier) => {
    switch (tier) {
      case "VBC":
        return <Shield className="h-6 w-6" />
      case "EBC":
        return <Star className="h-6 w-6" />
      case "MBA_CBE":
        return <Trophy className="h-6 w-6" />
    }
  }

  const getAssessmentIcon = (type: CertificationModule["assessmentType"]) => {
    switch (type) {
      case "quiz":
        return <BookOpen className="h-4 w-4" />
      case "practical":
        return <Zap className="h-4 w-4" />
      case "portfolio":
        return <Target className="h-4 w-4" />
      case "case_study":
        return <Users className="h-4 w-4" />
    }
  }

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white">
      {/* Header */}
      <div className="border-b border-[#1A1D1F] bg-gradient-to-r from-[#0A0A0A] via-[#0F1419] to-[#0A0A0A]">
        <div className="container mx-auto px-6 py-12">
          <div className="flex items-center gap-3 mb-4">
            <GraduationCap className="h-10 w-10 text-[#00F0FF]" />
            <h1 className="text-4xl font-bold">CBE Certification Program</h1>
          </div>
          <p className="text-[#5E6C72] text-lg max-w-2xl">
            Blockchain-backed credentialing system for entrepreneurial builders worldwide. Progress from Verified
            Builder to Master Builder Accreditation.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        {/* Certification Tier Selection */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {(Object.keys(CERTIFICATIONS) as CertificationTier[]).map((tier) => {
            const c = CERTIFICATIONS[tier]
            const isSelected = selectedTier === tier
            const isEarned = builderStats.currentCertifications.includes(tier)
            const isLocked =
              (tier === "EBC" && !builderStats.currentCertifications.includes("VBC")) ||
              (tier === "MBA_CBE" && !builderStats.currentCertifications.includes("EBC"))

            return (
              <Card
                key={tier}
                className={`cursor-pointer transition-all duration-300 ${
                  isSelected ? "border-2 bg-[#0F1419]" : "border-[#1A1D1F] bg-[#0A0A0A] hover:border-[#5E6C72]"
                } ${isLocked ? "opacity-60" : ""}`}
                style={{ borderColor: isSelected ? c.badgeColor : undefined }}
                onClick={() => !isLocked && setSelectedTier(tier)}
              >
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div
                      className="p-3 rounded-lg"
                      style={{ backgroundColor: `${c.badgeColor}20`, color: c.badgeColor }}
                    >
                      {getTierIcon(tier)}
                    </div>
                    {isEarned ? (
                      <Badge className="bg-[#4ADE80] text-black">
                        <CheckCircle2 className="h-3 w-3 mr-1" />
                        Earned
                      </Badge>
                    ) : isLocked ? (
                      <Badge variant="outline" className="border-[#5E6C72] text-[#5E6C72]">
                        <Lock className="h-3 w-3 mr-1" />
                        Locked
                      </Badge>
                    ) : (
                      <Badge variant="outline" style={{ borderColor: c.badgeColor, color: c.badgeColor }}>
                        Available
                      </Badge>
                    )}
                  </div>
                  <CardTitle className="text-white mt-4">{c.shortName}</CardTitle>
                  <CardDescription className="text-[#5E6C72]">{c.name}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-[#5E6C72]">Modules</span>
                      <span className="text-white">{c.modules.length}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-[#5E6C72]">Min PWKs</span>
                      <span className="text-white">{c.requirements.minimumPWKs}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-[#5E6C72]">Fee</span>
                      <span className="text-white">${c.fee}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Selected Certification Details */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <Tabs defaultValue="curriculum" className="w-full">
              <TabsList className="bg-[#1A1D1F] border border-[#2A2D2F]">
                <TabsTrigger
                  value="curriculum"
                  className="data-[state=active]:bg-[#00F0FF] data-[state=active]:text-black"
                >
                  Curriculum
                </TabsTrigger>
                <TabsTrigger
                  value="requirements"
                  className="data-[state=active]:bg-[#00F0FF] data-[state=active]:text-black"
                >
                  Requirements
                </TabsTrigger>
                <TabsTrigger
                  value="benefits"
                  className="data-[state=active]:bg-[#00F0FF] data-[state=active]:text-black"
                >
                  Benefits
                </TabsTrigger>
              </TabsList>

              <TabsContent value="curriculum" className="mt-6">
                <Card className="bg-[#0A0A0A] border-[#1A1D1F]">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <BookOpen className="h-5 w-5 text-[#00F0FF]" />
                      {cert.name} Modules
                    </CardTitle>
                    <CardDescription className="text-[#5E6C72]">{cert.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {modules.map((module, index) => (
                      <div
                        key={module.id}
                        className={`border rounded-lg transition-all duration-300 ${
                          expandedModule === module.id
                            ? "border-[#00F0FF] bg-[#0F1419]"
                            : "border-[#1A1D1F] hover:border-[#5E6C72]"
                        }`}
                      >
                        <button
                          className="w-full p-4 text-left"
                          onClick={() => setExpandedModule(expandedModule === module.id ? null : module.id)}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4">
                              <div className="w-8 h-8 rounded-full bg-[#1A1D1F] flex items-center justify-center text-[#00F0FF] font-bold">
                                {index + 1}
                              </div>
                              <div>
                                <h4 className="font-medium text-white">{module.title}</h4>
                                <div className="flex items-center gap-3 text-sm text-[#5E6C72] mt-1">
                                  <span className="flex items-center gap-1">
                                    <Clock className="h-3 w-3" />
                                    {module.duration}
                                  </span>
                                  <span className="flex items-center gap-1">
                                    {getAssessmentIcon(module.assessmentType)}
                                    {module.assessmentType.replace("_", " ")}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <ArrowRight
                              className={`h-5 w-5 text-[#5E6C72] transition-transform ${
                                expandedModule === module.id ? "rotate-90" : ""
                              }`}
                            />
                          </div>
                        </button>

                        {expandedModule === module.id && (
                          <div className="px-4 pb-4 border-t border-[#1A1D1F] pt-4">
                            <p className="text-[#5E6C72] mb-4">{module.description}</p>
                            <h5 className="text-sm font-medium text-white mb-2">Learning Objectives:</h5>
                            <ul className="space-y-2">
                              {module.objectives.map((obj, i) => (
                                <li key={i} className="flex items-center gap-2 text-sm text-[#5E6C72]">
                                  <CheckCircle2 className="h-4 w-4 text-[#4ADE80]" />
                                  {obj}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="requirements" className="mt-6">
                <Card className="bg-[#0A0A0A] border-[#1A1D1F]">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Target className="h-5 w-5 text-[#FF003C]" />
                      Eligibility Requirements
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 bg-[#0F1419] rounded-lg border border-[#1A1D1F]">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[#5E6C72]">BIS Verification</span>
                          {builderStats.bisVerified ? (
                            <CheckCircle2 className="h-5 w-5 text-[#4ADE80]" />
                          ) : (
                            <Lock className="h-5 w-5 text-[#FF003C]" />
                          )}
                        </div>
                        <p className="text-sm text-white">
                          {cert.requirements.bisVerification ? "Required" : "Not Required"}
                        </p>
                      </div>

                      <div className="p-4 bg-[#0F1419] rounded-lg border border-[#1A1D1F]">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[#5E6C72]">Minimum PWKs</span>
                          {builderStats.pwkCount >= cert.requirements.minimumPWKs ? (
                            <CheckCircle2 className="h-5 w-5 text-[#4ADE80]" />
                          ) : (
                            <span className="text-[#FF003C] text-sm">
                              {builderStats.pwkCount}/{cert.requirements.minimumPWKs}
                            </span>
                          )}
                        </div>
                        <Progress
                          value={Math.min(100, (builderStats.pwkCount / cert.requirements.minimumPWKs) * 100)}
                          className="h-2"
                        />
                      </div>

                      <div className="p-4 bg-[#0F1419] rounded-lg border border-[#1A1D1F]">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[#5E6C72]">Reputation Score</span>
                          {builderStats.reputationScore >= cert.requirements.minimumReputationScore ? (
                            <CheckCircle2 className="h-5 w-5 text-[#4ADE80]" />
                          ) : (
                            <span className="text-[#FF003C] text-sm">
                              {builderStats.reputationScore}/{cert.requirements.minimumReputationScore}
                            </span>
                          )}
                        </div>
                        <Progress
                          value={Math.min(
                            100,
                            (builderStats.reputationScore / cert.requirements.minimumReputationScore) * 100,
                          )}
                          className="h-2"
                        />
                      </div>

                      <div className="p-4 bg-[#0F1419] rounded-lg border border-[#1A1D1F]">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[#5E6C72]">Completed SCCs</span>
                          {builderStats.completedSCCs >= cert.requirements.minimumCompletedSCCs ? (
                            <CheckCircle2 className="h-5 w-5 text-[#4ADE80]" />
                          ) : (
                            <span className="text-[#FF003C] text-sm">
                              {builderStats.completedSCCs}/{cert.requirements.minimumCompletedSCCs}
                            </span>
                          )}
                        </div>
                        <Progress
                          value={Math.min(
                            100,
                            (builderStats.completedSCCs / cert.requirements.minimumCompletedSCCs) * 100,
                          )}
                          className="h-2"
                        />
                      </div>
                    </div>

                    {cert.requirements.additionalRequirements && (
                      <div className="border-t border-[#1A1D1F] pt-6">
                        <h4 className="text-white font-medium mb-4">Additional Requirements</h4>
                        <ul className="space-y-2">
                          {cert.requirements.additionalRequirements.map((req, i) => (
                            <li key={i} className="flex items-center gap-2 text-[#5E6C72]">
                              <div className="w-2 h-2 rounded-full bg-[#00F0FF]" />
                              {req}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="benefits" className="mt-6">
                <Card className="bg-[#0A0A0A] border-[#1A1D1F]">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Award className="h-5 w-5 text-[#FFD16F]" />
                      Certification Benefits
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                      <div className="p-4 bg-[#0F1419] rounded-lg border border-[#1A1D1F]">
                        <h4 className="text-[#5E6C72] text-sm mb-2">Placement Level</h4>
                        <p className="text-white font-medium capitalize">{cert.benefits.placement}</p>
                      </div>
                      <div className="p-4 bg-[#0F1419] rounded-lg border border-[#1A1D1F]">
                        <h4 className="text-[#5E6C72] text-sm mb-2">Match Priority</h4>
                        <p className="text-white font-medium">{cert.benefits.matchPriority}x Multiplier</p>
                      </div>
                      <div className="p-4 bg-[#0F1419] rounded-lg border border-[#1A1D1F]">
                        <h4 className="text-[#5E6C72] text-sm mb-2">Base Rate Multiplier</h4>
                        <p className="text-white font-medium">{cert.benefits.baseRateMultiplier}x</p>
                      </div>
                      <div className="p-4 bg-[#0F1419] rounded-lg border border-[#1A1D1F]">
                        <h4 className="text-[#5E6C72] text-sm mb-2">Bid Multiplier</h4>
                        <p className="text-white font-medium">{cert.benefits.bidMultiplier}x</p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <h4 className="text-white font-medium">Additional Benefits</h4>
                      {cert.benefits.additionalBenefits.map((benefit, i) => (
                        <div key={i} className="flex items-center gap-3 text-[#5E6C72]">
                          <CheckCircle2 className="h-4 w-4 text-[#4ADE80]" />
                          {benefit}
                        </div>
                      ))}
                      {cert.benefits.enterpriseEligible && (
                        <div className="flex items-center gap-3 text-[#5E6C72]">
                          <CheckCircle2 className="h-4 w-4 text-[#4ADE80]" />
                          Enterprise contract eligibility
                        </div>
                      )}
                      {cert.benefits.privateMarketplaceAccess && (
                        <div className="flex items-center gap-3 text-[#5E6C72]">
                          <CheckCircle2 className="h-4 w-4 text-[#4ADE80]" />
                          Private marketplace access
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Enrollment Card */}
            <Card className="bg-[#0F1419] border-[#1A1D1F]">
              <CardHeader>
                <CardTitle className="text-white">Enroll Now</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-[#5E6C72]">Program Fee</span>
                  <span className="text-2xl font-bold text-white">${cert.fee}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-[#5E6C72]">Renewal Period</span>
                  <span className="text-white">{cert.renewalPeriod} months</span>
                </div>
                <Button className="w-full" style={{ backgroundColor: cert.badgeColor, color: "#0A0A0A" }}>
                  Begin Certification
                </Button>
                <p className="text-xs text-[#5E6C72] text-center">Blockchain-verified credential upon completion</p>
              </CardContent>
            </Card>

            {/* Your Progress Card */}
            <Card className="bg-[#0A0A0A] border-[#1A1D1F]">
              <CardHeader>
                <CardTitle className="text-white text-lg">Your Progress</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#4ADE80]/20 flex items-center justify-center">
                    <Shield className="h-5 w-5 text-[#4ADE80]" />
                  </div>
                  <div>
                    <p className="text-white font-medium">VBC</p>
                    <p className="text-xs text-[#4ADE80]">Completed</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#00F0FF]/20 flex items-center justify-center">
                    <Star className="h-5 w-5 text-[#00F0FF]" />
                  </div>
                  <div>
                    <p className="text-white font-medium">EBC</p>
                    <p className="text-xs text-[#5E6C72]">2 requirements remaining</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 opacity-50">
                  <div className="w-10 h-10 rounded-full bg-[#FFD700]/20 flex items-center justify-center">
                    <Trophy className="h-5 w-5 text-[#FFD700]" />
                  </div>
                  <div>
                    <p className="text-white font-medium">MBA-CBE</p>
                    <p className="text-xs text-[#5E6C72]">Locked</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card className="bg-[#0A0A0A] border-[#1A1D1F]">
              <CardHeader>
                <CardTitle className="text-white text-lg">Your Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[#5E6C72]">PWKs Earned</span>
                  <span className="text-white font-medium">{builderStats.pwkCount}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#5E6C72]">Reputation</span>
                  <span className="text-white font-medium">{builderStats.reputationScore}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#5E6C72]">Completed SCCs</span>
                  <span className="text-white font-medium">{builderStats.completedSCCs}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#5E6C72]">Disputes</span>
                  <span className="text-[#4ADE80] font-medium">{builderStats.disputeEscalations}</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
