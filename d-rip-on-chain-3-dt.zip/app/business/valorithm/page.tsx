"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  Calculator,
  FileText,
  TrendingUp,
  DollarSign,
  Clock,
  Briefcase,
  Lightbulb,
  Code,
  Palette,
  BarChart3,
  Download,
  Plus,
  ChevronRight,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

type WorkCategory = "creative" | "technical" | "strategic" | "operational" | "production" | "research" | "management"
type ComplexityLevel = "basic" | "intermediate" | "advanced" | "expert" | "enterprise"

const INDUSTRY_RATES: Record<WorkCategory, number> = {
  creative: 85,
  technical: 125,
  strategic: 150,
  operational: 65,
  production: 95,
  research: 110,
  management: 135,
}

const COMPLEXITY_MULTIPLIERS: Record<ComplexityLevel, number> = {
  basic: 1.0,
  intermediate: 1.25,
  advanced: 1.5,
  expert: 2.0,
  enterprise: 2.5,
}

const IP_TIERS = [
  { tier: 1, label: "Basic", value: 300, desc: "Standard templates, basic content" },
  { tier: 2, label: "Custom", value: 1500, desc: "Custom designs, unique content" },
  { tier: 3, label: "Proprietary", value: 6250, desc: "Proprietary systems, branded assets" },
  { tier: 4, label: "Patentable", value: 30000, desc: "Patentable concepts, platform features" },
  { tier: 5, label: "Core IP", value: 150000, desc: "Core IP, foundational technology" },
]

export default function ValorithmPage() {
  const [activeTab, setActiveTab] = useState("calculator")

  // Calculator state
  const [category, setCategory] = useState<WorkCategory>("technical")
  const [complexity, setComplexity] = useState<ComplexityLevel>("intermediate")
  const [hours, setHours] = useState(40)
  const [ipTier, setIpTier] = useState<number | null>(null)
  const [aiCredits, setAiCredits] = useState(1000)

  // Calculate values
  const hourlyRate = INDUSTRY_RATES[category] * COMPLEXITY_MULTIPLIERS[complexity]
  const laborValue = hourlyRate * hours
  const ipValue = ipTier ? IP_TIERS.find((t) => t.tier === ipTier)?.value || 0 : 0
  const aiSavings = aiCredits * 0.15
  const totalValue = laborValue + ipValue + aiSavings
  const equityMin = Math.min((totalValue / 1000) * 0.375, 30)
  const equityMax = Math.min((totalValue / 1000) * 0.625, 30)

  // Demo data for dashboard
  const demoStats = {
    totalValue: 47850,
    hoursLogged: 384,
    aiSavings: 12340,
    ipAssets: 8,
  }

  const recentLogs = [
    { id: 1, category: "technical", hours: 12, value: 3000, date: "2024-12-07" },
    { id: 2, category: "creative", hours: 8, value: 1360, date: "2024-12-06" },
    { id: 3, category: "strategic", hours: 4, value: 900, date: "2024-12-05" },
    { id: 4, category: "production", hours: 6, value: 855, date: "2024-12-04" },
  ]

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <Link
          href="/business"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors mb-8"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Business Patch
        </Link>

        <div className="mb-12">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-4 rounded-xl bg-gradient-to-br from-amber-500/20 to-orange-500/20 border border-amber-500/30">
              <Calculator className="h-8 w-8 text-amber-500" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">VALORITHM</h1>
              <p className="text-muted-foreground">Sweat Equity Valuation Engine</p>
            </div>
          </div>
          <p className="text-sm text-muted-foreground max-w-2xl">
            Quantify the real economic value of your creative, technical, and strategic work. Generate audit-ready
            reports for equity justification, investor presentations, and client billing.
          </p>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          <TabsList className="grid w-full grid-cols-5 max-w-2xl">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="calculator">Calculator</TabsTrigger>
            <TabsTrigger value="log">Activity Log</TabsTrigger>
            <TabsTrigger value="assets">IP Assets</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            {/* KPI Tiles */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 border-amber-500/30">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <DollarSign className="h-5 w-5 text-amber-500" />
                    <Badge variant="outline" className="text-xs">
                      Total
                    </Badge>
                  </div>
                  <p className="text-2xl font-bold">${demoStats.totalValue.toLocaleString()}</p>
                  <p className="text-xs text-muted-foreground">Sweat Equity Value</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <Clock className="h-5 w-5 text-blue-500" />
                    <Badge variant="outline" className="text-xs">
                      Logged
                    </Badge>
                  </div>
                  <p className="text-2xl font-bold">{demoStats.hoursLogged}</p>
                  <p className="text-xs text-muted-foreground">Hours Documented</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <TrendingUp className="h-5 w-5 text-green-500" />
                    <Badge variant="outline" className="text-xs">
                      Saved
                    </Badge>
                  </div>
                  <p className="text-2xl font-bold">${demoStats.aiSavings.toLocaleString()}</p>
                  <p className="text-xs text-muted-foreground">AI Cost Avoided</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <Lightbulb className="h-5 w-5 text-purple-500" />
                    <Badge variant="outline" className="text-xs">
                      Created
                    </Badge>
                  </div>
                  <p className="text-2xl font-bold">{demoStats.ipAssets}</p>
                  <p className="text-xs text-muted-foreground">IP Assets</p>
                </CardContent>
              </Card>
            </div>

            {/* Category Breakdown */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Value by Category</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { cat: "Technical", value: 18500, color: "bg-blue-500", pct: 39 },
                    { cat: "Creative", value: 12400, color: "bg-purple-500", pct: 26 },
                    { cat: "Strategic", value: 9200, color: "bg-amber-500", pct: 19 },
                    { cat: "Production", value: 5100, color: "bg-green-500", pct: 11 },
                    { cat: "Other", value: 2650, color: "bg-zinc-500", pct: 5 },
                  ].map((item) => (
                    <div key={item.cat} className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>{item.cat}</span>
                        <span className="text-muted-foreground">${item.value.toLocaleString()}</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div className={`h-full ${item.color} rounded-full`} style={{ width: `${item.pct}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button
                variant="outline"
                className="h-auto p-4 justify-start bg-transparent"
                onClick={() => setActiveTab("calculator")}
              >
                <Calculator className="h-5 w-5 mr-3" />
                <div className="text-left">
                  <p className="font-medium">New Calculation</p>
                  <p className="text-xs text-muted-foreground">Calculate work value</p>
                </div>
                <ChevronRight className="h-4 w-4 ml-auto" />
              </Button>

              <Button
                variant="outline"
                className="h-auto p-4 justify-start bg-transparent"
                onClick={() => setActiveTab("reports")}
              >
                <FileText className="h-5 w-5 mr-3" />
                <div className="text-left">
                  <p className="font-medium">Generate Report</p>
                  <p className="text-xs text-muted-foreground">Create equity report</p>
                </div>
                <ChevronRight className="h-4 w-4 ml-auto" />
              </Button>

              <Button
                variant="outline"
                className="h-auto p-4 justify-start bg-transparent"
                onClick={() => setActiveTab("log")}
              >
                <Plus className="h-5 w-5 mr-3" />
                <div className="text-left">
                  <p className="font-medium">Log Activity</p>
                  <p className="text-xs text-muted-foreground">Track new work</p>
                </div>
                <ChevronRight className="h-4 w-4 ml-auto" />
              </Button>
            </div>
          </TabsContent>

          {/* Calculator Tab */}
          <TabsContent value="calculator" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Input Panel */}
              <Card>
                <CardHeader>
                  <CardTitle>Valuation Calculator</CardTitle>
                  <CardDescription>Configure your work parameters</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label>Work Category</Label>
                    <Select value={category} onValueChange={(v) => setCategory(v as WorkCategory)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="creative">
                          <div className="flex items-center gap-2">
                            <Palette className="h-4 w-4" /> Creative (${INDUSTRY_RATES.creative}/hr)
                          </div>
                        </SelectItem>
                        <SelectItem value="technical">
                          <div className="flex items-center gap-2">
                            <Code className="h-4 w-4" /> Technical (${INDUSTRY_RATES.technical}/hr)
                          </div>
                        </SelectItem>
                        <SelectItem value="strategic">
                          <div className="flex items-center gap-2">
                            <Briefcase className="h-4 w-4" /> Strategic (${INDUSTRY_RATES.strategic}/hr)
                          </div>
                        </SelectItem>
                        <SelectItem value="operational">
                          <div className="flex items-center gap-2">
                            <BarChart3 className="h-4 w-4" /> Operational (${INDUSTRY_RATES.operational}/hr)
                          </div>
                        </SelectItem>
                        <SelectItem value="production">Production (${INDUSTRY_RATES.production}/hr)</SelectItem>
                        <SelectItem value="research">Research (${INDUSTRY_RATES.research}/hr)</SelectItem>
                        <SelectItem value="management">Management (${INDUSTRY_RATES.management}/hr)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Complexity Level</Label>
                    <Select value={complexity} onValueChange={(v) => setComplexity(v as ComplexityLevel)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="basic">Basic (1.0x)</SelectItem>
                        <SelectItem value="intermediate">Intermediate (1.25x)</SelectItem>
                        <SelectItem value="advanced">Advanced (1.5x)</SelectItem>
                        <SelectItem value="expert">Expert (2.0x)</SelectItem>
                        <SelectItem value="enterprise">Enterprise (2.5x)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <Label>Estimated Hours</Label>
                      <span className="text-sm text-muted-foreground">{hours} hrs</span>
                    </div>
                    <Slider value={[hours]} onValueChange={([v]) => setHours(v)} min={1} max={500} step={1} />
                  </div>

                  <div className="space-y-2">
                    <Label>IP Asset Tier (Optional)</Label>
                    <Select
                      value={ipTier?.toString() || "none"}
                      onValueChange={(v) => setIpTier(v === "none" ? null : Number.parseInt(v))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="No IP Asset" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">No IP Asset</SelectItem>
                        {IP_TIERS.map((tier) => (
                          <SelectItem key={tier.tier} value={tier.tier.toString()}>
                            Tier {tier.tier}: {tier.label} (${tier.value.toLocaleString()})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {ipTier && (
                      <p className="text-xs text-muted-foreground">{IP_TIERS.find((t) => t.tier === ipTier)?.desc}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <Label>AI Credits Used</Label>
                      <span className="text-sm text-muted-foreground">{aiCredits.toLocaleString()}</span>
                    </div>
                    <Slider
                      value={[aiCredits]}
                      onValueChange={([v]) => setAiCredits(v)}
                      min={0}
                      max={50000}
                      step={100}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Results Panel */}
              <Card className="bg-gradient-to-br from-amber-500/5 to-orange-500/5 border-amber-500/20">
                <CardHeader>
                  <CardTitle>Valuation Results</CardTitle>
                  <CardDescription>Based on industry benchmarks</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="p-4 rounded-lg bg-background/50 border">
                    <p className="text-xs text-muted-foreground mb-1">Effective Hourly Rate</p>
                    <p className="text-2xl font-bold">${hourlyRate.toFixed(2)}/hr</p>
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between py-2 border-b">
                      <span className="text-muted-foreground">Labor Value</span>
                      <span className="font-medium">${laborValue.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between py-2 border-b">
                      <span className="text-muted-foreground">IP Asset Value</span>
                      <span className="font-medium">${ipValue.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between py-2 border-b">
                      <span className="text-muted-foreground">AI Cost Savings</span>
                      <span className="font-medium text-green-500">+${aiSavings.toFixed(2)}</span>
                    </div>
                  </div>

                  <div className="p-4 rounded-lg bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-500/30">
                    <p className="text-xs text-muted-foreground mb-1">Total Sweat Equity Value</p>
                    <p className="text-3xl font-bold text-amber-500">${totalValue.toLocaleString()}</p>
                  </div>

                  <div className="p-4 rounded-lg bg-background/50 border">
                    <p className="text-xs text-muted-foreground mb-2">Recommended Equity Range</p>
                    <div className="flex items-center gap-2">
                      <span className="text-xl font-bold">{equityMin.toFixed(2)}%</span>
                      <span className="text-muted-foreground">—</span>
                      <span className="text-xl font-bold">{equityMax.toFixed(2)}%</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">
                      Based on ${totalValue.toLocaleString()} contribution value
                    </p>
                  </div>

                  <Button className="w-full" size="lg">
                    <FileText className="h-4 w-4 mr-2" />
                    Generate Equity Report
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Activity Log Tab */}
          <TabsContent value="log" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-xl font-bold">Activity Log</h2>
                <p className="text-sm text-muted-foreground">Track your documented work</p>
              </div>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Log New Entry
              </Button>
            </div>

            <Card>
              <CardContent className="p-0">
                <div className="divide-y">
                  {recentLogs.map((log) => (
                    <div
                      key={log.id}
                      className="p-4 flex items-center justify-between hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-center gap-4">
                        <div
                          className={`p-2 rounded-lg ${
                            log.category === "technical"
                              ? "bg-blue-500/10 text-blue-500"
                              : log.category === "creative"
                                ? "bg-purple-500/10 text-purple-500"
                                : log.category === "strategic"
                                  ? "bg-amber-500/10 text-amber-500"
                                  : "bg-green-500/10 text-green-500"
                          }`}
                        >
                          {log.category === "technical" ? (
                            <Code className="h-4 w-4" />
                          ) : log.category === "creative" ? (
                            <Palette className="h-4 w-4" />
                          ) : log.category === "strategic" ? (
                            <Briefcase className="h-4 w-4" />
                          ) : (
                            <BarChart3 className="h-4 w-4" />
                          )}
                        </div>
                        <div>
                          <p className="font-medium capitalize">{log.category} Work</p>
                          <p className="text-xs text-muted-foreground">
                            {log.hours} hours • {log.date}
                          </p>
                        </div>
                      </div>
                      <p className="font-bold">${log.value.toLocaleString()}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* IP Assets Tab */}
          <TabsContent value="assets" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-xl font-bold">IP Asset Library</h2>
                <p className="text-sm text-muted-foreground">Manage your intellectual property portfolio</p>
              </div>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Asset
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                { name: "VALORITHM Engine", tier: 4, value: 30000, type: "code" },
                { name: "Brand Identity System", tier: 3, value: 6250, type: "design" },
                { name: "API Architecture", tier: 3, value: 6250, type: "code" },
                { name: "Marketing Templates", tier: 2, value: 1500, type: "design" },
                { name: "Documentation Suite", tier: 2, value: 1500, type: "document" },
                { name: "Training Materials", tier: 1, value: 300, type: "document" },
              ].map((asset, i) => (
                <Card key={i} className="hover:border-primary/50 transition-colors cursor-pointer">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <Badge variant="outline">Tier {asset.tier}</Badge>
                      <span className="text-xs text-muted-foreground">{asset.type}</span>
                    </div>
                    <h3 className="font-medium mb-1">{asset.name}</h3>
                    <p className="text-lg font-bold text-amber-500">${asset.value.toLocaleString()}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Reports Tab */}
          <TabsContent value="reports" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-xl font-bold">Reports Center</h2>
                <p className="text-sm text-muted-foreground">Generate and download valuation reports</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="hover:border-primary/50 transition-colors cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="p-3 rounded-lg bg-amber-500/10">
                      <FileText className="h-6 w-6 text-amber-500" />
                    </div>
                    <div>
                      <h3 className="font-bold">Sweat Equity Report</h3>
                      <p className="text-sm text-muted-foreground">Attorney-grade valuation document</p>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mb-4">
                    Comprehensive report with work evidence, AI audit, labor equivalent, IP valuation, and equity
                    recommendation.
                  </p>
                  <Button className="w-full">
                    <Download className="h-4 w-4 mr-2" />
                    Generate Report
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:border-primary/50 transition-colors cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="p-3 rounded-lg bg-blue-500/10">
                      <BarChart3 className="h-6 w-6 text-blue-500" />
                    </div>
                    <div>
                      <h3 className="font-bold">Investor Deck</h3>
                      <p className="text-sm text-muted-foreground">Gamma-style presentation outline</p>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mb-4">
                    10-slide deck with problem, solution, work volume, AI savings, IP portfolio, and equity
                    justification.
                  </p>
                  <Button variant="outline" className="w-full bg-transparent">
                    <Download className="h-4 w-4 mr-2" />
                    Generate Outline
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:border-primary/50 transition-colors cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="p-3 rounded-lg bg-purple-500/10">
                      <Briefcase className="h-6 w-6 text-purple-500" />
                    </div>
                    <div>
                      <h3 className="font-bold">White Label Report</h3>
                      <p className="text-sm text-muted-foreground">Freelancer productivity report</p>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mb-4">
                    Customizable report for client billing and productivity documentation.
                  </p>
                  <Button variant="outline" className="w-full bg-transparent">
                    <Download className="h-4 w-4 mr-2" />
                    Generate Report
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:border-primary/50 transition-colors cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="p-3 rounded-lg bg-green-500/10">
                      <TrendingUp className="h-6 w-6 text-green-500" />
                    </div>
                    <div>
                      <h3 className="font-bold">Executive Summary</h3>
                      <p className="text-sm text-muted-foreground">One-page valuation snapshot</p>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mb-4">
                    Quick overview with key metrics, highlights, and equity recommendation.
                  </p>
                  <Button variant="outline" className="w-full bg-transparent">
                    <Download className="h-4 w-4 mr-2" />
                    Generate Summary
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Recent Reports */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Recent Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8 text-muted-foreground">
                  <FileText className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p>No reports generated yet</p>
                  <p className="text-sm">Create your first report above</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Footer */}
        <div className="mt-12 p-6 rounded-xl bg-muted/50 border">
          <div className="flex items-center gap-3 mb-3">
            <Badge>VALORITHM</Badge>
            <span className="text-xs text-muted-foreground">Sweat Equity Valuation Engine</span>
          </div>
          <p className="text-xs text-muted-foreground">
            Industry rates sourced from Bureau of Labor Statistics, Glassdoor, and industry reports (2024). All
            valuations are estimates and should be reviewed by qualified professionals for legal or financial decisions.
          </p>
        </div>
      </div>
    </div>
  )
}
