import Link from "next/link"
import { ArrowLeft, LayoutDashboard, TrendingUp, Users, DollarSign, Activity } from "lucide-react"

const metrics = [
  { label: "Revenue MTD", value: "$--,---", change: "+---%", icon: DollarSign },
  { label: "Active Clients", value: "---", change: "+--", icon: Users },
  { label: "Conversion Rate", value: "--.-%", change: "+-.-%", icon: TrendingUp },
  { label: "System Health", value: "---%", change: "Stable", icon: Activity },
]

export default function GlobalDashboardPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <Link
        href="/business"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors mb-8"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Business Patch
      </Link>

      <div className="mb-12">
        <div className="flex items-center gap-4 mb-4">
          <div className="p-4 rounded-xl bg-primary/10">
            <LayoutDashboard className="h-8 w-8 text-primary" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-primary">Global Dashboard</h1>
            <p className="text-muted-foreground">Cross-module analytics and business intelligence</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
        {metrics.map((metric) => (
          <div key={metric.label} className="p-6 rounded-xl border border-border bg-card/50">
            <div className="flex items-center justify-between mb-4">
              <metric.icon className="h-5 w-5 text-primary" />
              <span className="text-xs text-emerald-400">{metric.change}</span>
            </div>
            <div className="text-2xl font-bold mb-1">{metric.value}</div>
            <div className="text-sm text-muted-foreground">{metric.label}</div>
          </div>
        ))}
      </div>

      <div className="p-6 rounded-xl border border-primary/30 bg-primary/5">
        <h2 className="text-lg font-bold mb-2">Coming Soon</h2>
        <p className="text-sm text-muted-foreground">
          Live data integration with real-time analytics across all business modules.
        </p>
      </div>
    </div>
  )
}
