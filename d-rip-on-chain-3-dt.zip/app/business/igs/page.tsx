"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { getAllGenerals, getGeneralsByCategory } from "@/lib/igs/registry"
import type { GeneralId, GeneralMode, IndustryCategory } from "@/lib/igs/types"
import {
  GraduationCap,
  Scale,
  BookOpen,
  Shield,
  Network,
  FileCode,
  Cpu,
  Stethoscope,
  Gavel,
  Building2,
  Palette,
  Factory,
  Zap,
} from "lucide-react"

const CATEGORY_ICONS: Record<IndustryCategory, any> = {
  STEM: GraduationCap,
  MEDICAL: Stethoscope,
  LEGAL: Gavel,
  FINANCE: Building2,
  CREATIVE: Palette,
  INDUSTRIAL: Factory,
  WILDCARD: Zap,
}

const MODE_ICONS: Record<GeneralMode, any> = {
  COURTROOM_TESTIMONY: Scale,
  CREDENTIALING_EXAM: GraduationCap,
  UNIVERSITY_LIBRARY: BookOpen,
  ANTI_MOLOCH: Shield,
  CROSS_INDUSTRY: Network,
  SMART_CONTRACT: FileCode,
  CHAOS_OS_API: Cpu,
}

export default function IGSPage() {
  const [selectedGeneral, setSelectedGeneral] = useState<GeneralId | null>(null)
  const [selectedMode, setSelectedMode] = useState<GeneralMode | null>(null)
  const [query, setQuery] = useState("")
  const [response, setResponse] = useState<any>(null)
  const [loading, setLoading] = useState(false)

  const generals = getAllGenerals()
  const selectedGeneralData = selectedGeneral ? generals.find((g) => g.id === selectedGeneral) : null

  const handleSubmit = async () => {
    if (!selectedGeneral || !selectedMode || !query) return

    setLoading(true)
    try {
      const res = await fetch("/api/igs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          generalId: selectedGeneral,
          mode: selectedMode,
          query,
        }),
      })
      const data = await res.json()
      setResponse(data)
    } catch (error) {
      console.error("IGS Query Error:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-8 space-y-8">
      <div className="space-y-2">
        <h1 className="text-4xl font-bold">Industry General System (IGS)</h1>
        <p className="text-muted-foreground text-lg">
          33 AI-powered industry experts with courtroom-ready testimony, university-grade knowledge, and Web3 smart
          contract integration
        </p>
      </div>

      <Tabs defaultValue="browse" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="browse">Browse Generals</TabsTrigger>
          <TabsTrigger value="query">Query General</TabsTrigger>
          <TabsTrigger value="web3">Web2 → Web3 Bridge</TabsTrigger>
          <TabsTrigger value="cad">Text-to-CAD</TabsTrigger>
        </TabsList>

        <TabsContent value="browse" className="space-y-6">
          {(["STEM", "MEDICAL", "LEGAL", "FINANCE", "CREATIVE", "INDUSTRIAL", "WILDCARD"] as IndustryCategory[]).map(
            (category) => {
              const categoryGenerals = getGeneralsByCategory(category)
              const Icon = CATEGORY_ICONS[category]

              return (
                <div key={category} className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Icon className="h-6 w-6" />
                    <h2 className="text-2xl font-bold">{category}</h2>
                    <Badge variant="secondary">{categoryGenerals.length} Generals</Badge>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {categoryGenerals.map((general) => (
                      <Card key={general.id} className="hover:border-primary transition-colors cursor-pointer">
                        <CardHeader>
                          <CardTitle className="text-lg">{general.name}</CardTitle>
                          <CardDescription className="text-sm">{general.description}</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <div>
                            <div className="text-xs font-medium mb-1">Modes</div>
                            <div className="flex flex-wrap gap-1">
                              {general.modes.slice(0, 3).map((mode) => (
                                <Badge key={mode} variant="outline" className="text-xs">
                                  {mode.replace(/_/g, " ")}
                                </Badge>
                              ))}
                              {general.modes.length > 3 && (
                                <Badge variant="outline" className="text-xs">
                                  +{general.modes.length - 3}
                                </Badge>
                              )}
                            </div>
                          </div>

                          <div>
                            <div className="text-xs font-medium mb-1">Skill Domains</div>
                            <div className="text-xs text-muted-foreground">
                              {general.skillDomains.slice(0, 3).join(", ")}
                              {general.skillDomains.length > 3 && ` +${general.skillDomains.length - 3} more`}
                            </div>
                          </div>

                          {general.smartContractTemplates.length > 0 && (
                            <div>
                              <div className="text-xs font-medium mb-1 flex items-center gap-1">
                                <FileCode className="h-3 w-3" />
                                Smart Contracts
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {general.smartContractTemplates.slice(0, 2).join(", ")}
                              </div>
                            </div>
                          )}

                          <Button
                            variant="outline"
                            size="sm"
                            className="w-full bg-transparent"
                            onClick={() => {
                              setSelectedGeneral(general.id)
                              setSelectedMode(general.modes[0])
                            }}
                          >
                            Consult This General
                          </Button>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )
            },
          )}
        </TabsContent>

        <TabsContent value="query" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Query an Industry General</CardTitle>
              <CardDescription>
                Select a General, choose a mode, and ask your question. Responses are powered by university-grade
                knowledge and Anti-Moloch governance.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Select General</Label>
                <Select value={selectedGeneral || ""} onValueChange={(val) => setSelectedGeneral(val as GeneralId)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a General..." />
                  </SelectTrigger>
                  <SelectContent>
                    {generals.map((g) => (
                      <SelectItem key={g.id} value={g.id}>
                        {g.name} ({g.category})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedGeneralData && (
                <div className="space-y-2">
                  <Label>Select Mode</Label>
                  <Select value={selectedMode || ""} onValueChange={(val) => setSelectedMode(val as GeneralMode)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a mode..." />
                    </SelectTrigger>
                    <SelectContent>
                      {selectedGeneralData.modes.map((mode) => {
                        const Icon = MODE_ICONS[mode]
                        return (
                          <SelectItem key={mode} value={mode}>
                            <div className="flex items-center gap-2">
                              <Icon className="h-4 w-4" />
                              {mode.replace(/_/g, " ")}
                            </div>
                          </SelectItem>
                        )
                      })}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="space-y-2">
                <Label>Your Question</Label>
                <Textarea
                  placeholder="Ask your industry-specific question..."
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  rows={4}
                />
              </div>

              <Button onClick={handleSubmit} disabled={!selectedGeneral || !selectedMode || !query || loading}>
                {loading ? "Consulting General..." : "Submit Query"}
              </Button>
            </CardContent>
          </Card>

          {response && (
            <Card>
              <CardHeader>
                <CardTitle>General Response</CardTitle>
                <div className="flex items-center gap-2">
                  <Badge>Confidence: {(response.confidenceScore * 100).toFixed(0)}%</Badge>
                  {response.governance?.flags && response.governance.flags.length > 0 && (
                    <Badge variant="destructive">{response.governance.flags.length} Governance Flags</Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="font-medium mb-2">Response:</div>
                  <div className="text-sm text-muted-foreground bg-muted p-4 rounded">{response.response}</div>
                </div>

                {response.citations && (
                  <div>
                    <div className="font-medium mb-2">Citations:</div>
                    <ul className="list-disc list-inside text-sm text-muted-foreground">
                      {response.citations.map((citation: string, idx: number) => (
                        <li key={idx}>{citation}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {response.smartContractSuggestions && (
                  <div>
                    <div className="font-medium mb-2 flex items-center gap-2">
                      <FileCode className="h-4 w-4" />
                      Smart Contract Suggestions:
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {response.smartContractSuggestions.map((suggestion: string) => (
                        <Badge key={suggestion} variant="secondary">
                          {suggestion}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {response.antiMolochFlags && (
                  <div>
                    <div className="font-medium mb-2 flex items-center gap-2">
                      <Shield className="h-4 w-4" />
                      Anti-Moloch Governance:
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {response.antiMolochFlags.map((flag: string) => (
                        <Badge key={flag} variant="outline">
                          {flag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {response.governance?.recommendations && (
                  <div>
                    <div className="font-medium mb-2">Recommendations:</div>
                    <ul className="list-disc list-inside text-sm text-muted-foreground">
                      {response.governance.recommendations.map((rec: string, idx: number) => (
                        <li key={idx}>{rec}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="web3" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Web2 → Web3 Transformation Bridge</CardTitle>
              <CardDescription>
                Understand how each industry is being disrupted by smart contracts, NFTs, and Web3 technology
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {generals
                .filter((g) => g.web3Map.examples.length > 0)
                .slice(0, 5)
                .map((general) => (
                  <div key={general.id} className="space-y-3 border-l-2 border-primary pl-4">
                    <h3 className="font-bold">{general.name}</h3>
                    <div className="text-sm space-y-2">
                      <div>
                        <span className="font-medium">Smart Contract Disruption: </span>
                        <span className="text-muted-foreground">{general.web3Map.smartContractDisruption}</span>
                      </div>
                      <div>
                        <span className="font-medium">NFT Use Cases: </span>
                        <span className="text-muted-foreground">{general.web3Map.nftUseCases.join(", ")}</span>
                      </div>
                      <div>
                        <span className="font-medium">Tokenized Jobs: </span>
                        <span className="text-muted-foreground">{general.web3Map.tokenizedJobs.join(", ")}</span>
                      </div>
                    </div>

                    {general.web3Map.examples.map((example, idx) => (
                      <Card key={idx} className="bg-muted/50">
                        <CardHeader>
                          <CardTitle className="text-base">{example.title}</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-2 text-sm">
                          <div>
                            <span className="font-medium">Web2: </span>
                            {example.web2Description}
                          </div>
                          <div>
                            <span className="font-medium">Web3: </span>
                            {example.web3Translation}
                          </div>
                          <div>
                            <span className="font-medium">Smart Contract Use Case: </span>
                            {example.smartContractUseCase}
                          </div>
                          <div>
                            <span className="font-medium">Income Pathway: </span>
                            {example.incomePathway}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="cad" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Text-to-CAD Swarm</CardTitle>
              <CardDescription>
                Convert natural language descriptions into CAD models, blueprints, and 3D printable files
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Describe what you want to create</Label>
                <Textarea
                  placeholder="e.g., 'A 3-story residential building with a modern facade and rooftop terrace'"
                  rows={4}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>CAD Type</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ARCHITECTURAL">Architectural</SelectItem>
                      <SelectItem value="BLUEPRINT">Blueprint</SelectItem>
                      <SelectItem value="3D_PRINTABLE">3D Printable</SelectItem>
                      <SelectItem value="SCHEMATIC">Schematic</SelectItem>
                      <SelectItem value="PROTOTYPE">Prototype</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Industry</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select industry..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="architecture">Architecture</SelectItem>
                      <SelectItem value="engineering">Engineering</SelectItem>
                      <SelectItem value="manufacturing">Manufacturing</SelectItem>
                      <SelectItem value="product-design">Product Design</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <input type="checkbox" id="physics" />
                <Label htmlFor="physics">Enable Physics Validation</Label>
              </div>

              <div className="flex items-center space-x-2">
                <input type="checkbox" id="safety" />
                <Label htmlFor="safety">Enable Safety Validation</Label>
              </div>

              <Button>Generate CAD Model</Button>
            </CardContent>
          </Card>

          <Card className="bg-muted/50">
            <CardHeader>
              <CardTitle className="text-lg">CAD Swarm Pipeline</CardTitle>
            </CardHeader>
            <CardContent>
              <ol className="list-decimal list-inside space-y-2 text-sm">
                <li>Natural language prompt parsing</li>
                <li>Structural logic validation</li>
                <li>Physics simulation (if enabled)</li>
                <li>Safety protocol check (if enabled)</li>
                <li>CAD mesh generation</li>
                <li>3D model export (DWG, STL, OBJ, STEP, SVG)</li>
                <li>Feasibility report & cost estimation</li>
              </ol>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
