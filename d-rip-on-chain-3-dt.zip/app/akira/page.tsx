import Link from "next/link"
import { BookOpen, Sparkles, Map, Scroll, Gamepad2 } from "lucide-react"

export default function AkiraCodexPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="pt-12 pb-16 px-6 text-center border-b border-neutral-800 bg-gradient-to-b from-cyan-950/10 to-black">
        <p className="text-xs font-mono text-cyan-400 tracking-[0.3em] mb-2">WIRED CHAOS META</p>
        <h1 className="text-5xl md:text-6xl font-bold mb-4">AKIRA CODEX</h1>
        <p className="text-neutral-400 max-w-2xl mx-auto mb-8">
          The Narrative Engine for multi-universe transmedia storytelling. Generate, expand, visualize, and publish
          across books, graphic novels, animation, ARG, and world-building.
        </p>

        {/* Featured Universe CTA */}
        <Link
          href="/akira/universes/neteru-apinaya"
          className="inline-flex items-center gap-2 bg-gradient-to-r from-cyan-600 to-amber-600 hover:from-cyan-500 hover:to-amber-500 text-white px-8 py-4 rounded-xl font-semibold transition-all shadow-lg shadow-cyan-500/20"
        >
          <Sparkles className="h-5 w-5" />
          Enter NETERU APINAYA (Featured Universe)
        </Link>
      </header>

      {/* Main Sections */}
      <main className="max-w-5xl mx-auto px-6 py-12">
        <div className="grid gap-6 md:grid-cols-2">
          {/* Universe Selector */}
          <Link
            href="/akira/universes"
            className="group border border-neutral-800 hover:border-cyan-600/50 rounded-xl p-6 transition-all bg-neutral-900/20 hover:bg-cyan-950/20"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="p-3 rounded-lg bg-neutral-800 group-hover:bg-cyan-900/50 transition-colors">
                <Map className="h-6 w-6 text-neutral-400 group-hover:text-cyan-400" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white group-hover:text-cyan-400 transition-colors">
                  Universe Selector
                </h2>
                <p className="text-xs text-neutral-500">Browse all available storyworlds</p>
              </div>
            </div>
            <p className="text-sm text-neutral-400">
              Choose from NETERU APINAYA (featured), VAULT 33 CHRONICLES, and more universes
            </p>
          </Link>

          {/* Story Engine */}
          <Link
            href="/akira/story-engine"
            className="group border border-neutral-800 hover:border-pink-600/50 rounded-xl p-6 transition-all bg-neutral-900/20 hover:bg-pink-950/20"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="p-3 rounded-lg bg-neutral-800 group-hover:bg-pink-900/50 transition-colors">
                <Scroll className="h-6 w-6 text-neutral-400 group-hover:text-pink-400" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white group-hover:text-pink-400 transition-colors">
                  Story Engine
                </h2>
                <p className="text-xs text-neutral-500">Generate → Expand → Publish</p>
              </div>
            </div>
            <p className="text-sm text-neutral-400">
              Create story seeds, expand into novellas, convert to ebooks, and publish to KDP
            </p>
          </Link>

          {/* Books */}
          <Link
            href="/books"
            className="group border border-neutral-800 hover:border-amber-600/50 rounded-xl p-6 transition-all bg-neutral-900/20 hover:bg-amber-950/20"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="p-3 rounded-lg bg-neutral-800 group-hover:bg-amber-900/50 transition-colors">
                <BookOpen className="h-6 w-6 text-neutral-400 group-hover:text-amber-400" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white group-hover:text-amber-400 transition-colors">
                  Published Works
                </h2>
                <p className="text-xs text-neutral-500">Browse the bookstore</p>
              </div>
            </div>
            <p className="text-sm text-neutral-400">Explore completed publications, microsites, and Kindle listings</p>
          </Link>

          {/* ARG */}
          <Link
            href="/arg/neuro"
            className="group border border-neutral-800 hover:border-emerald-600/50 rounded-xl p-6 transition-all bg-neutral-900/20 hover:bg-emerald-950/20"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="p-3 rounded-lg bg-neutral-800 group-hover:bg-emerald-900/50 transition-colors">
                <Gamepad2 className="h-6 w-6 text-neutral-400 group-hover:text-emerald-400" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white group-hover:text-emerald-400 transition-colors">
                  ARG System
                </h2>
                <p className="text-xs text-neutral-500">Interactive missions</p>
              </div>
            </div>
            <p className="text-sm text-neutral-400">
              Play through alternate reality game missions, clue chains, and real-world artifact paths
            </p>
          </Link>
        </div>

        {/* Credit Footer */}
        <footer className="mt-16 pt-8 border-t border-neutral-800 text-center text-xs font-mono text-neutral-600">
          <p>AKIRA CODEX | Built with WIRED CHAOS META</p>
          <p className="mt-1">Featured Universe: NETERU APINAYA by NEURO META X</p>
        </footer>
      </main>
    </div>
  )
}
