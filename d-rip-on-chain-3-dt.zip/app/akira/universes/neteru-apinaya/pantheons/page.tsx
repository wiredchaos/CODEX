"use client"

import Link from "next/link"
import { ArrowLeft, Sun, Moon, MapPin } from "lucide-react"
import { NETERU_PANTHEONS } from "@/config/neteru-universe"

export default function NeteruPantheonsPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Back navigation */}
      <div className="absolute top-4 left-4 z-20">
        <Link
          href="/akira/universes/neteru-apinaya"
          className="inline-flex items-center gap-2 text-sm text-white/50 hover:text-cyan-400 transition-colors font-mono tracking-wider"
        >
          <ArrowLeft className="h-4 w-4" />
          NETERU APINAYA
        </Link>
      </div>

      {/* Header */}
      <header className="pt-20 pb-12 px-6 text-center border-b border-neutral-800">
        <p className="text-xs font-mono text-amber-400 tracking-[0.3em] mb-2">NETERU APINAYA</p>
        <h1 className="text-4xl font-bold mb-4">PANTHEONS</h1>
        <p className="text-neutral-400 max-w-2xl mx-auto">
          Divine entities and their shadow counterparts across the Neteru cosmology
        </p>
      </header>

      {/* Pantheons Grid */}
      <main className="max-w-6xl mx-auto px-6 py-12">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {NETERU_PANTHEONS.map((deity) => (
            <article
              key={deity.id}
              className="border border-neutral-800 rounded-xl p-5 bg-neutral-900/20 hover:border-amber-500/30 transition-colors"
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="p-2 rounded-lg bg-amber-900/30">
                  <Sun className="h-5 w-5 text-amber-400" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-white">{deity.name}</h2>
                  <p className="text-xs text-amber-400">{deity.domain}</p>
                </div>
              </div>

              {deity.shadowCounterpart && (
                <div className="flex items-center gap-2 mb-3 text-xs">
                  <Moon className="h-3 w-3 text-purple-400" />
                  <span className="text-neutral-500">Shadow:</span>
                  <span className="text-purple-400">{deity.shadowCounterpart}</span>
                </div>
              )}

              {deity.geopoliticalNode && (
                <div className="flex items-center gap-2 mb-3 text-xs">
                  <MapPin className="h-3 w-3 text-emerald-400" />
                  <span className="text-neutral-500">Node:</span>
                  <span className="text-emerald-400">{deity.geopoliticalNode}</span>
                </div>
              )}

              <div className="space-y-2 text-xs">
                <div>
                  <span className="text-neutral-500">Artifacts:</span>{" "}
                  <span className="text-cyan-400">{deity.artifacts.join(", ")}</span>
                </div>
                <div>
                  <span className="text-neutral-500">Powers:</span>{" "}
                  <span className="text-pink-400">{deity.powers.join(", ")}</span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </main>
    </div>
  )
}
