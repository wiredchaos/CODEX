"use client"

import Link from "next/link"
import { ArrowLeft, Dna, Shield, Zap } from "lucide-react"
import { NETERU_BLOODLINES } from "@/config/neteru-universe"

export default function NeteruBloodlinesPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Back navigation */}
      <div className="absolute top-4 left-4 z-20">
        <Link
          href="/akira/universes/neteru-apinaya"
          className="inline-flex items-center gap-2 text-sm text-white/50 hover:text-cyan-400 transition-colors font-mono tracking-wider"
        >
          <ArrowLeft className="h-4 w-4" />
          NETERU APINAYA
        </Link>
      </div>

      {/* Header */}
      <header className="pt-20 pb-12 px-6 text-center border-b border-neutral-800">
        <p className="text-xs font-mono text-pink-400 tracking-[0.3em] mb-2">NETERU APINAYA</p>
        <h1 className="text-4xl font-bold mb-4">BLOODLINES</h1>
        <p className="text-neutral-400 max-w-2xl mx-auto">
          Genetic lineages carrying ancient powers and awakened abilities
        </p>
      </header>

      {/* Bloodlines Grid */}
      <main className="max-w-5xl mx-auto px-6 py-12">
        <div className="grid gap-6 md:grid-cols-2">
          {NETERU_BLOODLINES.map((bloodline) => (
            <article
              key={bloodline.id}
              className="border border-neutral-800 rounded-xl p-6 bg-neutral-900/20 hover:border-pink-500/30 transition-colors"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 rounded-lg bg-pink-900/30">
                  <Dna className="h-5 w-5 text-pink-400" />
                </div>
                <h2 className="text-xl font-bold text-white">{bloodline.name}</h2>
              </div>

              <p className="text-xs text-neutral-500 mb-4">{bloodline.origin}</p>

              <div className="space-y-3 text-sm">
                <div>
                  <div className="flex items-center gap-1 text-neutral-400 mb-1">
                    <Shield className="h-3 w-3" />
                    <span className="text-xs font-mono">TRAITS</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {bloodline.traits.map((trait, i) => (
                      <span key={i} className="px-2 py-0.5 bg-neutral-800 rounded text-xs text-neutral-300">
                        {trait}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="flex items-center gap-1 text-neutral-400 mb-1">
                    <Zap className="h-3 w-3" />
                    <span className="text-xs font-mono">ABILITIES</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {bloodline.abilities.map((ability, i) => (
                      <span key={i} className="px-2 py-0.5 bg-cyan-900/30 rounded text-xs text-cyan-400">
                        {ability}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="text-xs font-mono text-neutral-500 mb-1">ANTAGONISTS</div>
                  <p className="text-xs text-red-400">{bloodline.antagonists.join(", ")}</p>
                </div>

                {bloodline.modernDescendants && (
                  <div>
                    <div className="text-xs font-mono text-neutral-500 mb-1">MODERN DESCENDANTS</div>
                    <p className="text-xs text-amber-400">{bloodline.modernDescendants.join(", ")}</p>
                  </div>
                )}
              </div>
            </article>
          ))}
        </div>
      </main>
    </div>
  )
}
