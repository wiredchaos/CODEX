"use client"

import Link from "next/link"
import {
  ArrowLeft,
  BookOpen,
  Users,
  Sparkles,
  Clock,
  Map,
  Scroll,
  Gamepad2,
  Eye,
  Box,
  Hexagon,
  Zap,
} from "lucide-react"
import {
  NETERU_UNIVERSE,
  NETERU_ARCS,
  NETERU_CHARACTERS,
  NETERU_BLOODLINES,
  NETERU_PANTHEONS,
} from "@/config/neteru-universe"

const CONTENT_INDEX = {
  manuscripts: 5,
  story_arcs: 4,
  pantheon_mythology: 2,
  mini_episodes: 2,
  visual_geometry: 2,
  strategy_distribution: 3,
  lib_system_guides: 3,
  character_development: 1,
  assets: 1,
}

const SECTIONS = [
  {
    id: "codex",
    name: "Codex",
    icon: Scroll,
    description: "Complete Neteru lore encyclopedia",
    href: "/akira/universes/neteru-apinaya/codex",
    status: "active",
  },
  {
    id: "books",
    name: "Books",
    icon: BookOpen,
    description: "5 manuscripts ingested",
    href: "/akira/universes/neteru-apinaya/books",
    status: "active",
  },
  {
    id: "arcs",
    name: "Story Arcs",
    icon: Sparkles,
    description: "4 major narrative threads",
    href: "/akira/universes/neteru-apinaya/arcs",
    status: "active",
  },
  {
    id: "pantheons",
    name: "Pantheons",
    icon: Eye,
    description: "Deities and shadow counterparts",
    href: "/akira/universes/neteru-apinaya/pantheons",
    status: "active",
  },
  {
    id: "bloodlines",
    name: "Bloodlines",
    icon: Users,
    description: "Genetic lineages and abilities",
    href: "/akira/universes/neteru-apinaya/bloodlines",
    status: "active",
  },
  {
    id: "characters",
    name: "Characters",
    icon: Users,
    description: "Key figures in the universe",
    href: "/akira/universes/neteru-apinaya/characters",
    status: "building",
  },
  {
    id: "timelines",
    name: "Timelines",
    icon: Clock,
    description: "BC/AD manipulation & fabrication",
    href: "/akira/universes/neteru-apinaya/timelines",
    status: "active",
  },
  {
    id: "geometry",
    name: "Sacred Geometry",
    icon: Hexagon,
    description: "589 grid, sigils, and diagrams",
    href: "/akira/universes/neteru-apinaya/geometry",
    status: "building",
  },
  {
    id: "episodes",
    name: "Episodes",
    icon: Gamepad2,
    description: "2 mini-episodes ready for OTT",
    href: "/akira/universes/neteru-apinaya/episodes",
    status: "building",
  },
  {
    id: "frames",
    name: "Storyboard Frames",
    icon: Box,
    description: "Frame-based visual narrative",
    href: "/akira/universes/neteru-apinaya/frames",
    status: "building",
  },
  {
    id: "game",
    name: "ARG Missions",
    icon: Zap,
    description: "Interactive game content",
    href: "/akira/universes/neteru-apinaya/game",
    status: "building",
  },
  {
    id: "akashic",
    name: "Akashic Mechanics",
    icon: Eye,
    description: "Eternal Sight, Veil of Time",
    href: "/akira/universes/neteru-apinaya/akashic",
    status: "building",
  },
  {
    id: "artifacts",
    name: "Artifacts",
    icon: Box,
    description: "Relics and ether tech",
    href: "/akira/universes/neteru-apinaya/artifacts",
    status: "building",
  },
  {
    id: "world-map",
    name: "World Map",
    icon: Map,
    description: "Global seer sisterhood overlay",
    href: "/akira/universes/neteru-apinaya/world-map",
    status: "building",
  },
]

export default function NeteruApinayaHubPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      <div className="fixed inset-0 pointer-events-none opacity-5">
        <div className="absolute inset-0 bg-[repeating-linear-gradient(0deg,rgba(0,255,255,0.03)_0px,transparent_1px,transparent_2px,rgba(0,255,255,0.03)_3px)]" />
      </div>

      {/* Back navigation */}
      <div className="absolute top-4 left-4 z-20">
        <Link
          href="/akira/universes"
          className="inline-flex items-center gap-2 text-sm text-white/50 hover:text-cyan-400 transition-colors font-mono tracking-wider"
        >
          <ArrowLeft className="h-4 w-4" />
          UNIVERSE SELECTOR
        </Link>
      </div>

      <header className="relative pt-20 pb-20 px-6 text-center border-b border-cyan-800/30 overflow-hidden">
        {/* Background layers */}
        <div className="absolute inset-0 bg-gradient-to-b from-cyan-950/30 via-black to-black" />
        <div className="absolute inset-0 bg-[url('/ancient-egyptian-hieroglyphics-cosmic-background.jpg')] opacity-[0.07] bg-cover bg-center mix-blend-screen" />

        {/* Glowing geometric overlay */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl animate-pulse" />
          <div
            className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-red-500/10 rounded-full blur-3xl animate-pulse"
            style={{ animationDelay: "1s" }}
          />
        </div>

        <div className="relative z-10">
          {/* Status indicator */}
          <div className="inline-flex items-center gap-2 bg-cyan-950/50 border border-cyan-500/30 rounded-full px-4 py-1.5 mb-4">
            <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" />
            <span className="text-xs font-mono text-cyan-400 tracking-[0.2em]">PRIMARY UNIVERSE ONLINE</span>
          </div>

          {/* Title with glitch effect */}
          <h1 className="text-6xl md:text-7xl lg:text-8xl font-bold mb-4 relative">
            <span className="absolute inset-0 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-red-500 blur-sm opacity-50">
              NETERU APINAYA
            </span>
            <span className="relative text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-amber-400 to-red-400">
              NETERU APINAYA
            </span>
          </h1>

          <p className="text-sm font-mono text-cyan-400/70 tracking-[0.3em] mb-3">THE CODEX OF THE ETERNAL SIGHT</p>

          <p className="text-neutral-300 max-w-3xl mx-auto mb-8 text-lg leading-relaxed">
            {NETERU_UNIVERSE.description}
          </p>

          {/* Credit badges */}
          <div className="flex flex-wrap justify-center gap-3 mb-8">
            <div className="bg-black/70 border border-cyan-500/30 rounded-lg px-4 py-2 backdrop-blur-sm">
              <p className="text-xs font-mono text-neutral-500">CREATED BY</p>
              <p className="text-sm font-bold text-cyan-400">{NETERU_UNIVERSE.author.name}</p>
            </div>
            <div className="bg-black/70 border border-pink-500/30 rounded-lg px-4 py-2 backdrop-blur-sm">
              <p className="text-xs font-mono text-neutral-500">PUBLISHED BY</p>
              <p className="text-sm font-bold text-pink-400">{NETERU_UNIVERSE.publisher.name}</p>
            </div>
            <div className="bg-black/70 border border-amber-500/30 rounded-lg px-4 py-2 backdrop-blur-sm">
              <p className="text-xs font-mono text-neutral-500">PRODUCED BY</p>
              <p className="text-sm font-bold text-amber-400">{NETERU_UNIVERSE.studio.name}</p>
            </div>
          </div>

          {/* CTA */}
          <Link
            href="/akira/story-engine"
            className="inline-flex items-center gap-2 bg-gradient-to-r from-cyan-600 to-pink-600 hover:from-cyan-500 hover:to-pink-500 text-white px-8 py-4 rounded-lg font-bold tracking-wide transition-all shadow-lg shadow-cyan-500/20"
          >
            <Zap className="h-5 w-5" />
            ACTIVATE STORY ENGINE
          </Link>
        </div>
      </header>

      <section className="border-b border-neutral-800/50 bg-neutral-950/30 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-sm font-mono text-cyan-400 tracking-[0.2em]">CONTENT INGESTION STATUS</h2>
            <div className="text-xs font-mono text-emerald-400">23 ITEMS INDEXED</div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-4 gap-3">
            <div className="bg-black/50 border border-cyan-800/30 rounded-lg p-3">
              <div className="text-2xl font-bold text-cyan-400">{CONTENT_INDEX.manuscripts}</div>
              <div className="text-xs font-mono text-neutral-500">MANUSCRIPTS</div>
            </div>
            <div className="bg-black/50 border border-pink-800/30 rounded-lg p-3">
              <div className="text-2xl font-bold text-pink-400">{CONTENT_INDEX.story_arcs}</div>
              <div className="text-xs font-mono text-neutral-500">STORY ARCS</div>
            </div>
            <div className="bg-black/50 border border-amber-800/30 rounded-lg p-3">
              <div className="text-2xl font-bold text-amber-400">{CONTENT_INDEX.pantheon_mythology}</div>
              <div className="text-xs font-mono text-neutral-500">PANTHEON DOCS</div>
            </div>
            <div className="bg-black/50 border border-emerald-800/30 rounded-lg p-3">
              <div className="text-2xl font-bold text-emerald-400">{CONTENT_INDEX.mini_episodes}</div>
              <div className="text-xs font-mono text-neutral-500">MINI EPISODES</div>
            </div>
          </div>
        </div>
      </section>

      {/* Universe stats */}
      <section className="border-b border-neutral-800/50 bg-gradient-to-b from-neutral-950/50 to-black">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-4xl font-bold text-cyan-400 mb-1">{NETERU_ARCS.length}</div>
              <div className="text-xs font-mono text-neutral-500 tracking-wider">STORY ARCS</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-pink-400 mb-1">{NETERU_CHARACTERS.length}</div>
              <div className="text-xs font-mono text-neutral-500 tracking-wider">CHARACTERS</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-amber-400 mb-1">{NETERU_BLOODLINES.length}</div>
              <div className="text-xs font-mono text-neutral-500 tracking-wider">BLOODLINES</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-emerald-400 mb-1">{NETERU_PANTHEONS.length}</div>
              <div className="text-xs font-mono text-neutral-500 tracking-wider">PANTHEONS</div>
            </div>
          </div>
        </div>
      </section>

      <main className="max-w-7xl mx-auto px-6 py-16">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold text-neutral-200">UNIVERSE NAVIGATION</h2>
          <div className="flex items-center gap-4 text-xs font-mono">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-emerald-400 rounded-full" />
              <span className="text-neutral-500">ACTIVE</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-amber-400 rounded-full" />
              <span className="text-neutral-500">BUILDING</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {SECTIONS.map((section) => {
            const Icon = section.icon
            const isActive = section.status === "active"

            return (
              <Link
                key={section.id}
                href={section.href}
                className={`group relative border rounded-xl p-5 transition-all overflow-hidden ${
                  isActive
                    ? "border-cyan-800/50 hover:border-cyan-600/80 bg-gradient-to-br from-cyan-950/10 to-black hover:from-cyan-950/20"
                    : "border-neutral-800/50 hover:border-amber-600/50 bg-gradient-to-br from-neutral-950/20 to-black"
                }`}
              >
                {/* Status indicator */}
                <div className="absolute top-3 right-3">
                  <div className={`w-2 h-2 rounded-full ${isActive ? "bg-emerald-400" : "bg-amber-400"}`} />
                </div>

                <div className="flex items-start gap-4">
                  <div
                    className={`p-3 rounded-lg transition-colors ${
                      isActive
                        ? "bg-cyan-900/30 group-hover:bg-cyan-900/50"
                        : "bg-neutral-800/50 group-hover:bg-amber-900/30"
                    }`}
                  >
                    <Icon
                      className={`h-6 w-6 ${
                        isActive ? "text-cyan-400" : "text-neutral-500 group-hover:text-amber-400"
                      }`}
                    />
                  </div>
                  <div className="flex-1">
                    <h3
                      className={`font-bold mb-1 transition-colors ${
                        isActive
                          ? "text-white group-hover:text-cyan-400"
                          : "text-neutral-400 group-hover:text-amber-400"
                      }`}
                    >
                      {section.name}
                    </h3>
                    <p className="text-xs text-neutral-500 leading-relaxed">{section.description}</p>
                  </div>
                </div>
              </Link>
            )
          })}
        </div>

        {/* Engine integrations */}
        <div className="mt-16 grid md:grid-cols-2 gap-6">
          {/* Story Engine */}
          <div className="border border-cyan-800/50 rounded-xl p-6 bg-gradient-to-br from-cyan-950/20 via-black to-black">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 rounded-lg bg-cyan-900/30">
                <Zap className="h-5 w-5 text-cyan-400" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-cyan-400">NETERU STORY ENGINE</h3>
                <p className="text-xs font-mono text-cyan-400/50">GENERATE → EXPAND → PUBLISH</p>
              </div>
            </div>
            <p className="text-sm text-neutral-400 mb-4">
              Create new Neteru chapters, scenes, storyboards, and OTT episodes using the integrated story engine.
            </p>
            <Link
              href="/akira/story-engine"
              className="inline-block bg-cyan-600 hover:bg-cyan-700 text-white px-6 py-2.5 rounded-lg font-medium transition-colors text-sm"
            >
              Open Story Engine
            </Link>
          </div>

          {/* WIRED CHAOS Outputs */}
          <div className="border border-pink-800/50 rounded-xl p-6 bg-gradient-to-br from-pink-950/20 via-black to-black">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 rounded-lg bg-pink-900/30">
                <Box className="h-5 w-5 text-pink-400" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-pink-400">WIRED CHAOS OUTPUTS</h3>
                <p className="text-xs font-mono text-pink-400/50">TRANSMEDIA DISTRIBUTION</p>
              </div>
            </div>
            <p className="text-sm text-neutral-400 mb-3">
              Content flows to Creator Codex, NPC, 789 Studios, and FEN/589 Magazine.
            </p>
            <div className="flex flex-wrap gap-2">
              <span className="text-xs font-mono px-2 py-1 bg-neutral-800/50 border border-neutral-700 rounded text-neutral-400">
                Creator Codex
              </span>
              <span className="text-xs font-mono px-2 py-1 bg-neutral-800/50 border border-neutral-700 rounded text-neutral-400">
                NPC Games
              </span>
              <span className="text-xs font-mono px-2 py-1 bg-neutral-800/50 border border-neutral-700 rounded text-neutral-400">
                789 Studios
              </span>
              <span className="text-xs font-mono px-2 py-1 bg-neutral-800/50 border border-neutral-700 rounded text-neutral-400">
                589 Magazine
              </span>
            </div>
          </div>
        </div>

        {/* Imprint Footer */}
        <footer className="mt-16 pt-8 border-t border-neutral-800/50 text-center">
          <p className="text-xs font-mono text-neutral-500 tracking-wider mb-2">{NETERU_UNIVERSE.creditLine}</p>
          <p className="text-xs text-neutral-600">Powered by AKIRA CODEX | Built with WIRED CHAOS META</p>
        </footer>
      </main>
    </div>
  )
}
