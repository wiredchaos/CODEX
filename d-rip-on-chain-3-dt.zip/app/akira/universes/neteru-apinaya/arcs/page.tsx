"use client"

import Link from "next/link"
import { ArrowLeft, Clock } from "lucide-react"
import { NETERU_ARCS } from "@/config/neteru-universe"

export default function NeteruArcsPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Back navigation */}
      <div className="absolute top-4 left-4 z-20">
        <Link
          href="/akira/universes/neteru-apinaya"
          className="inline-flex items-center gap-2 text-sm text-white/50 hover:text-cyan-400 transition-colors font-mono tracking-wider"
        >
          <ArrowLeft className="h-4 w-4" />
          NETERU APINAYA
        </Link>
      </div>

      {/* Header */}
      <header className="pt-20 pb-12 px-6 text-center border-b border-neutral-800">
        <p className="text-xs font-mono text-cyan-400 tracking-[0.3em] mb-2">NETERU APINAYA</p>
        <h1 className="text-4xl font-bold mb-4">STORY ARCS</h1>
        <p className="text-neutral-400 max-w-2xl mx-auto">
          Major narrative threads weaving through the Neteru Apinaya universe
        </p>
      </header>

      {/* Arcs Grid */}
      <main className="max-w-4xl mx-auto px-6 py-12">
        <div className="space-y-6">
          {NETERU_ARCS.map((arc) => (
            <article
              key={arc.id}
              className={`border rounded-xl p-6 ${
                arc.status === "in-progress"
                  ? "border-cyan-500/50 bg-cyan-950/10"
                  : arc.status === "complete"
                    ? "border-emerald-500/50 bg-emerald-950/10"
                    : "border-neutral-700 bg-neutral-900/20"
              }`}
            >
              <div className="flex items-start justify-between gap-4 mb-4">
                <div>
                  <h2 className="text-xl font-bold text-white">{arc.title}</h2>
                  <div className="flex items-center gap-3 mt-1 text-xs font-mono">
                    <span
                      className={`px-2 py-0.5 rounded ${
                        arc.status === "in-progress"
                          ? "bg-cyan-600 text-white"
                          : arc.status === "complete"
                            ? "bg-emerald-600 text-white"
                            : "bg-neutral-700 text-neutral-300"
                      }`}
                    >
                      {arc.status.toUpperCase()}
                    </span>
                    <span className="text-neutral-500">{arc.chapters} chapters</span>
                  </div>
                </div>
                <div className="text-right text-xs text-neutral-500">
                  <Clock className="h-4 w-4 inline mr-1" />
                  {arc.timelineEra}
                </div>
              </div>

              <p className="text-neutral-300 text-sm mb-4">{arc.synopsis}</p>

              <div className="flex flex-wrap gap-4 text-xs">
                <div>
                  <span className="text-neutral-500">Characters:</span>{" "}
                  <span className="text-cyan-400">{arc.primaryCharacters.join(", ")}</span>
                </div>
                <div>
                  <span className="text-neutral-500">Themes:</span>{" "}
                  <span className="text-pink-400">{arc.themes.join(", ")}</span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </main>
    </div>
  )
}
