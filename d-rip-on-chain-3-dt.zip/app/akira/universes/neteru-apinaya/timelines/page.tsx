"use client"

import Link from "next/link"
import { ArrowLeft, Clock, AlertTriangle, CheckCircle } from "lucide-react"
import { NETERU_TIMELINE } from "@/config/neteru-universe"

export default function NeteruTimelinesPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Back navigation */}
      <div className="absolute top-4 left-4 z-20">
        <Link
          href="/akira/universes/neteru-apinaya"
          className="inline-flex items-center gap-2 text-sm text-white/50 hover:text-cyan-400 transition-colors font-mono tracking-wider"
        >
          <ArrowLeft className="h-4 w-4" />
          NETERU APINAYA
        </Link>
      </div>

      {/* Header */}
      <header className="pt-20 pb-12 px-6 text-center border-b border-neutral-800">
        <p className="text-xs font-mono text-emerald-400 tracking-[0.3em] mb-2">NETERU APINAYA</p>
        <h1 className="text-4xl font-bold mb-4">TIMELINES</h1>
        <p className="text-neutral-400 max-w-2xl mx-auto">
          Historical events across eras, including manipulated history and true revelations
        </p>
      </header>

      {/* Timeline */}
      <main className="max-w-3xl mx-auto px-6 py-12">
        <div className="relative border-l-2 border-neutral-700 pl-8 space-y-8">
          {NETERU_TIMELINE.map((event, index) => (
            <article key={event.id} className="relative">
              {/* Timeline dot */}
              <div
                className={`absolute -left-[41px] w-4 h-4 rounded-full border-2 ${
                  event.manipulated ? "border-red-500 bg-red-900" : "border-emerald-500 bg-emerald-900"
                }`}
              />

              {/* Event card */}
              <div
                className={`border rounded-xl p-5 ${
                  event.manipulated ? "border-red-500/30 bg-red-950/10" : "border-neutral-800 bg-neutral-900/20"
                }`}
              >
                <div className="flex items-start justify-between gap-4 mb-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Clock className="h-4 w-4 text-neutral-500" />
                      <span className="text-sm font-mono text-neutral-400">{event.date}</span>
                      <span className="text-xs px-2 py-0.5 bg-neutral-800 rounded text-neutral-500">
                        {event.era.toUpperCase()}
                      </span>
                    </div>
                    <h2 className="text-lg font-bold text-white">{event.title}</h2>
                  </div>
                  {event.manipulated ? (
                    <div className="flex items-center gap-1 text-red-400 text-xs">
                      <AlertTriangle className="h-3 w-3" />
                      MANIPULATED
                    </div>
                  ) : (
                    <div className="flex items-center gap-1 text-emerald-400 text-xs">
                      <CheckCircle className="h-3 w-3" />
                      VERIFIED
                    </div>
                  )}
                </div>

                <div className="space-y-3 text-sm">
                  <div>
                    <span className="text-neutral-500">Official:</span>{" "}
                    <span className="text-neutral-300">{event.description}</span>
                  </div>
                  {event.trueHistory && (
                    <div className="p-3 bg-black/50 rounded-lg border border-cyan-800/30">
                      <span className="text-cyan-400 text-xs font-mono">TRUE HISTORY:</span>
                      <p className="text-cyan-300 mt-1">{event.trueHistory}</p>
                    </div>
                  )}
                  <div className="text-xs">
                    <span className="text-neutral-500">Connected Arcs:</span>{" "}
                    <span className="text-amber-400">{event.connectedArcs.join(", ")}</span>
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </main>
    </div>
  )
}
