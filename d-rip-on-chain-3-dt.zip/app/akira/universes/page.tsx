"use client"

import Link from "next/link"
import { ArrowLeft, Star, BookOpen, Users, Clock, Map, Sparkles } from "lucide-react"
import { NETERU_UNIVERSE } from "@/config/neteru-universe"

// Universe options (Neteru is featured/default, others are placeholders)
const UNIVERSES = [
  {
    id: "neteru-apinaya",
    name: "NETERU APINAYA",
    featured: true,
    default: true,
    status: "active",
    description: NETERU_UNIVERSE.description,
    author: "NEURO META X",
    publisher: "CHAOS PUBLICATIONS",
    studio: "NETERU STUDIOS",
    stats: {
      arcs: 5,
      characters: 12,
      bloodlines: 5,
      pantheons: 8,
    },
  },
  {
    id: "vault-33-chronicles",
    name: "VAULT 33 CHRONICLES",
    featured: false,
    default: false,
    status: "coming-soon",
    description: "The forbidden archives beneath reality. A universe of secrets, tarot, and hidden knowledge.",
    author: "COLLECTIVE",
    publisher: "CHAOS PUBLICATIONS",
    studio: "VAULT STUDIOS",
    stats: {
      arcs: 0,
      characters: 0,
      bloodlines: 0,
      pantheons: 0,
    },
  },
  {
    id: "frequency-wars",
    name: "FREQUENCY WARS",
    featured: false,
    default: false,
    status: "planned",
    description:
      "The battle for signal supremacy. A cyberpunk universe of hackers, frequencies, and digital rebellion.",
    author: "TBD",
    publisher: "CHAOS PUBLICATIONS",
    studio: "789 STUDIOS",
    stats: {
      arcs: 0,
      characters: 0,
      bloodlines: 0,
      pantheons: 0,
    },
  },
]

export default function UniverseSelectorPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Back navigation */}
      <div className="absolute top-4 left-4 z-20">
        <Link
          href="/akira"
          className="inline-flex items-center gap-2 text-sm text-white/50 hover:text-cyan-400 transition-colors font-mono tracking-wider"
        >
          <ArrowLeft className="h-4 w-4" />
          BACK TO AKIRA CODEX
        </Link>
      </div>

      {/* Header */}
      <header className="pt-20 pb-12 px-6 text-center border-b border-neutral-800">
        <p className="text-xs font-mono text-cyan-400 tracking-[0.3em] mb-2">AKIRA CODEX</p>
        <h1 className="text-4xl md:text-5xl font-bold mb-4">UNIVERSE SELECTOR</h1>
        <p className="text-neutral-400 max-w-2xl mx-auto">
          Choose your storyworld. Each universe is a complete transmedia ecosystem with its own lore, characters, and
          narrative engines.
        </p>
      </header>

      {/* Universe Grid */}
      <main className="max-w-6xl mx-auto px-6 py-12">
        <div className="grid gap-6">
          {UNIVERSES.map((universe) => (
            <article
              key={universe.id}
              className={`relative border rounded-xl p-6 transition-all ${
                universe.featured
                  ? "border-cyan-500/50 bg-gradient-to-br from-cyan-950/20 to-black"
                  : universe.status === "coming-soon"
                    ? "border-amber-500/30 bg-amber-950/10"
                    : "border-neutral-800 bg-neutral-900/20 opacity-60"
              }`}
            >
              {/* Featured Badge */}
              {universe.featured && (
                <div className="absolute -top-3 left-6 bg-cyan-600 text-white text-xs font-mono px-3 py-1 rounded-full flex items-center gap-1">
                  <Star className="h-3 w-3" />
                  FEATURED UNIVERSE
                </div>
              )}

              {/* Status Badge */}
              {universe.status === "coming-soon" && (
                <div className="absolute -top-3 left-6 bg-amber-600 text-white text-xs font-mono px-3 py-1 rounded-full">
                  COMING SOON
                </div>
              )}

              <div className="flex flex-col lg:flex-row gap-6">
                {/* Universe Info */}
                <div className="flex-1">
                  <h2 className="text-2xl font-bold mb-2">{universe.name}</h2>
                  <p className="text-neutral-400 text-sm mb-4">{universe.description}</p>

                  {/* Credits */}
                  <div className="flex flex-wrap gap-4 text-xs font-mono text-neutral-500 mb-4">
                    <span>
                      Author: <span className="text-cyan-400">{universe.author}</span>
                    </span>
                    <span>
                      Publisher: <span className="text-pink-400">{universe.publisher}</span>
                    </span>
                    <span>
                      Studio: <span className="text-amber-400">{universe.studio}</span>
                    </span>
                  </div>

                  {/* Stats */}
                  {universe.status === "active" && (
                    <div className="flex flex-wrap gap-4 text-sm">
                      <div className="flex items-center gap-1 text-neutral-400">
                        <BookOpen className="h-4 w-4" />
                        <span>{universe.stats.arcs} Arcs</span>
                      </div>
                      <div className="flex items-center gap-1 text-neutral-400">
                        <Users className="h-4 w-4" />
                        <span>{universe.stats.characters} Characters</span>
                      </div>
                      <div className="flex items-center gap-1 text-neutral-400">
                        <Sparkles className="h-4 w-4" />
                        <span>{universe.stats.bloodlines} Bloodlines</span>
                      </div>
                      <div className="flex items-center gap-1 text-neutral-400">
                        <Clock className="h-4 w-4" />
                        <span>{universe.stats.pantheons} Pantheons</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Action */}
                <div className="flex items-center">
                  {universe.status === "active" ? (
                    <Link
                      href={`/akira/universes/${universe.id}`}
                      className="bg-cyan-600 hover:bg-cyan-700 text-white px-6 py-3 rounded-lg font-medium transition-colors flex items-center gap-2"
                    >
                      <Map className="h-4 w-4" />
                      Enter Universe
                    </Link>
                  ) : (
                    <button
                      disabled
                      className="bg-neutral-700 text-neutral-400 px-6 py-3 rounded-lg font-medium cursor-not-allowed"
                    >
                      {universe.status === "coming-soon" ? "Coming Soon" : "Planned"}
                    </button>
                  )}
                </div>
              </div>

              {/* Credit Line for Featured */}
              {universe.featured && (
                <div className="mt-4 pt-4 border-t border-cyan-800/30 text-xs font-mono text-cyan-400/70">
                  {NETERU_UNIVERSE.creditLine}
                </div>
              )}
            </article>
          ))}
        </div>
      </main>
    </div>
  )
}
