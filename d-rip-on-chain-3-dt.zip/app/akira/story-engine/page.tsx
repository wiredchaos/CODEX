"use client"

import { useState } from "react"
import type { StorySeed, Novella, Publication } from "@/types"

type Stage = "seed" | "expand" | "publish"

export default function AkiraStoryEnginePage() {
  const [currentStage, setCurrentStage] = useState<Stage>("seed")
  const [prompt, setPrompt] = useState("")
  const [loading, setLoading] = useState(false)
  const [seed, setSeed] = useState<StorySeed | null>(null)
  const [novella, setNovella] = useState<Novella | null>(null)
  const [publication, setPublication] = useState<Publication | null>(null)

  const generateSeed = async () => {
    if (!prompt.trim() || loading) return
    setLoading(true)
    try {
      const res = await fetch("/api/akira/seed", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, genre: "cyberpunk", tone: "dark" }),
      })
      const data = await res.json()
      setSeed(data.seed)
      setCurrentStage("expand")
    } catch (error) {
      console.error("[v0] Seed generation error:", error)
    } finally {
      setLoading(false)
    }
  }

  const expandNovella = async () => {
    if (!seed || loading) return
    setLoading(true)
    try {
      const res = await fetch("/api/akira/expand", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ storySeedId: seed.id }),
      })
      const data = await res.json()
      setNovella(data.novella)
      setCurrentStage("publish")
    } catch (error) {
      console.error("[v0] Novella expansion error:", error)
    } finally {
      setLoading(false)
    }
  }

  const convertToEbook = async () => {
    if (!novella || loading) return
    setLoading(true)
    try {
      const res = await fetch("/api/creator/convert", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ novellaId: novella.id }),
      })
      const data = await res.json()
      setPublication(data.publication)
    } catch (error) {
      console.error("[v0] Ebook conversion error:", error)
    } finally {
      setLoading(false)
    }
  }

  const publishToKDP = async () => {
    if (!publication || loading) return
    setLoading(true)
    try {
      const res = await fetch("/api/creator/publish", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ storyId: publication.storyId }),
      })
      const data = await res.json()
      setPublication(data.publication)
    } catch (error) {
      console.error("[v0] KDP publish error:", error)
    } finally {
      setLoading(false)
    }
  }

  const createMicrosite = async () => {
    if (!publication || loading) return
    setLoading(true)
    try {
      const res = await fetch("/api/creator/microsite", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ storyId: publication.storyId }),
      })
      const data = await res.json()
      setPublication(data.publication)
    } catch (error) {
      console.error("[v0] Microsite creation error:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background text-foreground p-6">
      <div className="max-w-6xl mx-auto">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-cyan-400 mb-2">AKIRA Story Engine</h1>
          <p className="text-sm text-neutral-400">3-Stage Pipeline: Generate → Expand → Publish</p>
        </header>

        {/* Stage Indicator */}
        <div className="flex items-center justify-center gap-4 mb-12">
          {["seed", "expand", "publish"].map((stage, idx) => (
            <div key={stage} className="flex items-center">
              <div
                className={`px-4 py-2 rounded-lg font-mono text-sm ${
                  currentStage === stage
                    ? "bg-cyan-600 text-white"
                    : seed || idx === 0
                      ? "bg-neutral-800 text-neutral-400"
                      : "bg-neutral-900 text-neutral-600"
                }`}
              >
                {stage.toUpperCase()}
              </div>
              {idx < 2 && <div className="w-8 h-0.5 bg-neutral-700 mx-2" />}
            </div>
          ))}
        </div>

        {/* Stage 1: Story Seed Generator */}
        {currentStage === "seed" && (
          <div className="border border-neutral-800 rounded-xl p-6 bg-black/40">
            <h2 className="text-xl font-semibold text-cyan-400 mb-4">Story Seed Generator</h2>
            <p className="text-sm text-neutral-400 mb-6">
              Enter your story idea and AKIRA-SEED will generate a structured narrative foundation
            </p>
            <div className="space-y-4">
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Enter your story concept... (e.g., 'A hacker discovers a frequency that shouldn't exist')"
                className="w-full h-32 bg-neutral-900 border border-neutral-700 rounded-lg p-4 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 resize-none"
                disabled={loading}
              />
              <button
                onClick={generateSeed}
                disabled={loading || !prompt.trim()}
                className="w-full bg-cyan-600 hover:bg-cyan-700 disabled:bg-neutral-700 px-6 py-3 rounded-lg font-medium transition-colors"
              >
                {loading ? "Generating Seed..." : "Generate Story Seed"}
              </button>
            </div>

            {seed && (
              <div className="mt-6 p-4 bg-cyan-950/20 border border-cyan-800/50 rounded-lg">
                <h3 className="font-semibold text-cyan-400 mb-2">{seed.title}</h3>
                <div className="text-sm text-neutral-300 space-y-2">
                  <p>
                    <strong>Genre:</strong> {seed.genre}
                  </p>
                  <p>
                    <strong>Tone:</strong> {seed.tone}
                  </p>
                  <p>
                    <strong>Beats:</strong> {seed.beats.length} story beats generated
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Stage 2: Novella Expansion */}
        {currentStage === "expand" && (
          <div className="border border-neutral-800 rounded-xl p-6 bg-black/40">
            <h2 className="text-xl font-semibold text-pink-400 mb-4">Novella Expansion</h2>
            <p className="text-sm text-neutral-400 mb-6">
              AKIRA-SWARM will expand your seed into a 3-5 chapter novella
            </p>

            {seed && (
              <div className="mb-6 p-4 bg-neutral-900 border border-neutral-800 rounded-lg">
                <h3 className="font-semibold text-neutral-200 mb-2">Current Seed: {seed.title}</h3>
                <p className="text-xs text-neutral-500">ID: {seed.id}</p>
              </div>
            )}

            <button
              onClick={expandNovella}
              disabled={loading || !seed}
              className="w-full bg-pink-600 hover:bg-pink-700 disabled:bg-neutral-700 px-6 py-3 rounded-lg font-medium transition-colors"
            >
              {loading ? "Expanding Novella..." : "Expand into Novella"}
            </button>

            {novella && (
              <div className="mt-6 p-4 bg-pink-950/20 border border-pink-800/50 rounded-lg">
                <h3 className="font-semibold text-pink-400 mb-3">Novella Complete</h3>
                <div className="text-sm text-neutral-300 space-y-2">
                  <p>
                    <strong>Title:</strong> {novella.title}
                  </p>
                  <p>
                    <strong>Chapters:</strong> {novella.chapters.length}
                  </p>
                  <p>
                    <strong>Word Count:</strong> {novella.wordCount?.toLocaleString() || "TBD"}
                  </p>
                  <p>
                    <strong>Continuity Score:</strong> {novella.continuityScore}
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Stage 3: Publishing */}
        {currentStage === "publish" && (
          <div className="border border-neutral-800 rounded-xl p-6 bg-black/40 space-y-6">
            <div>
              <h2 className="text-xl font-semibold text-purple-400 mb-4">Publishing & Distribution</h2>
              <p className="text-sm text-neutral-400 mb-6">
                Convert to ebook formats, publish to Kindle, and create a microsite
              </p>
            </div>

            {novella && (
              <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-lg">
                <h3 className="font-semibold text-neutral-200 mb-2">Novella: {novella.title}</h3>
                <p className="text-xs text-neutral-500">Ready for publishing</p>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <button
                onClick={convertToEbook}
                disabled={loading}
                className="bg-purple-600 hover:bg-purple-700 disabled:bg-neutral-700 px-6 py-3 rounded-lg font-medium transition-colors"
              >
                Convert to Ebook
              </button>
              <button
                onClick={publishToKDP}
                disabled={loading || !publication}
                className="bg-amber-600 hover:bg-amber-700 disabled:bg-neutral-700 px-6 py-3 rounded-lg font-medium transition-colors"
              >
                Publish to KDP
              </button>
              <button
                onClick={createMicrosite}
                disabled={loading || !publication}
                className="bg-emerald-600 hover:bg-emerald-700 disabled:bg-neutral-700 px-6 py-3 rounded-lg font-medium transition-colors"
              >
                Create Microsite
              </button>
            </div>

            {publication && (
              <div className="p-4 bg-emerald-950/20 border border-emerald-800/50 rounded-lg">
                <h3 className="font-semibold text-emerald-400 mb-3">Publication Status</h3>
                <div className="text-sm text-neutral-300 space-y-2">
                  <p>
                    <strong>EPUB:</strong> {publication.epubUrl || "Pending"}
                  </p>
                  <p>
                    <strong>PDF:</strong> {publication.pdfUrl || "Pending"}
                  </p>
                  <p>
                    <strong>KDP Status:</strong>{" "}
                    <span
                      className={`uppercase ${
                        publication.kdpStatus === "published" ? "text-green-400" : "text-amber-400"
                      }`}
                    >
                      {publication.kdpStatus}
                    </span>
                  </p>
                  {publication.micrositeUrl && (
                    <p>
                      <strong>Microsite:</strong>{" "}
                      <a href={publication.micrositeUrl} className="text-cyan-400 hover:underline">
                        {publication.micrositeUrl}
                      </a>
                    </p>
                  )}
                  {publication.asin && (
                    <p>
                      <strong>ASIN:</strong> {publication.asin}
                    </p>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
