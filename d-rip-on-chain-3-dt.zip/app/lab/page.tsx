import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { FlaskConical, Tv2, Radio, Film, Beaker } from "lucide-react"

export default function LabHomePage() {
  return (
    <div className="container mx-auto px-4 py-12 max-w-5xl">
      <div className="mb-12 text-center">
        <div className="flex items-center justify-center gap-3 mb-4">
          <FlaskConical className="h-10 w-10 text-cyan-400" />
          <h1 className="text-5xl font-bold">WIRED CHAOS META LAB</h1>
        </div>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          A safe environment to explore, test, and understand all WIRED CHAOS META components without affecting
          production systems.
        </p>
      </div>

      <Card className="p-8 mb-8 border-cyan-500/30 bg-cyan-500/5">
        <h2 className="text-2xl font-semibold mb-4 flex items-center gap-2">
          <Beaker className="h-6 w-6 text-cyan-400" />
          What is the Lab?
        </h2>
        <p className="text-muted-foreground mb-4">
          The WIRED CHAOS META LAB is a testing ground where you can experiment with all features, components, and
          workflows in a controlled environment. Everything here is isolated from the main production system, so you can
          click around, explore, and learn without any risk.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
          <div className="p-4 border border-neutral-800 rounded-lg">
            <h3 className="font-semibold mb-2 text-emerald-400">Safe to Explore</h3>
            <p className="text-sm text-muted-foreground">Nothing you do here affects production</p>
          </div>
          <div className="p-4 border border-neutral-800 rounded-lg">
            <h3 className="font-semibold mb-2 text-cyan-400">Learn by Doing</h3>
            <p className="text-sm text-muted-foreground">See how components work in real-time</p>
          </div>
          <div className="p-4 border border-neutral-800 rounded-lg">
            <h3 className="font-semibold mb-2 text-pink-400">No Technical Skills Needed</h3>
            <p className="text-sm text-muted-foreground">Everything is explained in plain language</p>
          </div>
        </div>
      </Card>

      <div className="space-y-6">
        <h2 className="text-2xl font-semibold">Available Labs</h2>

        <Link href="/lab/789">
          <Card className="p-6 hover:border-fuchsia-500/50 transition-all cursor-pointer group">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-fuchsia-500/10 flex items-center justify-center flex-shrink-0 group-hover:bg-fuchsia-500/20 transition-colors">
                <Tv2 className="h-6 w-6 text-fuchsia-400" />
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-semibold mb-2 flex items-center gap-2">
                  789 Studios Lab
                  <span className="text-xs px-2 py-0.5 rounded bg-fuchsia-500/20 text-fuchsia-400">Active</span>
                </h3>
                <p className="text-muted-foreground mb-3">
                  Explore the complete 789 Studios OTT platform, including the Netflix-style interface, Crypto Spaces
                  Network scheduling, Film3 documentary integration, and creator profiles. Test all features in a safe
                  environment.
                </p>
                <div className="flex flex-wrap gap-2">
                  <span className="text-xs px-2 py-1 rounded bg-neutral-800 text-neutral-400">OTT Platform</span>
                  <span className="text-xs px-2 py-1 rounded bg-neutral-800 text-neutral-400">CSN Schedule</span>
                  <span className="text-xs px-2 py-1 rounded bg-neutral-800 text-neutral-400">Film3</span>
                  <span className="text-xs px-2 py-1 rounded bg-neutral-800 text-neutral-400">Analytics</span>
                </div>
              </div>
              <Button variant="outline" className="ml-auto bg-transparent">
                Open Lab
              </Button>
            </div>
          </Card>
        </Link>

        <Card className="p-6 border-neutral-800 bg-neutral-900/30 opacity-60">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-lg bg-neutral-800 flex items-center justify-center flex-shrink-0">
              <Radio className="h-6 w-6 text-neutral-500" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-semibold mb-2 flex items-center gap-2">
                33.3FM Lab
                <span className="text-xs px-2 py-0.5 rounded bg-neutral-800 text-neutral-500">Coming Soon</span>
              </h3>
              <p className="text-muted-foreground">
                Test the DOGECHAIN radio system, audiobooks, podcasts, and creator studio features.
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-6 border-neutral-800 bg-neutral-900/30 opacity-60">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-lg bg-neutral-800 flex items-center justify-center flex-shrink-0">
              <Film className="h-6 w-6 text-neutral-500" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-semibold mb-2 flex items-center gap-2">
                NEURO Swarm Lab
                <span className="text-xs px-2 py-0.5 rounded bg-neutral-800 text-neutral-500">Coming Soon</span>
              </h3>
              <p className="text-muted-foreground">
                Experiment with the NEURO Lore Swarm Engine, TV show generation, and DJ Red Fang content production.
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
