import { Card } from "@/components/ui/card"
import Link from "next/link"
import { Tv2, Radio, Film, Users, ArrowRight, Calendar, TrendingUp } from "lucide-react"

export default function Lab789Page() {
  return (
    <div className="container mx-auto px-4 py-12 max-w-6xl">
      <div className="mb-8">
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
          <Link href="/lab" className="hover:text-foreground">
            Lab
          </Link>
          <span>/</span>
          <span>789 Studios</span>
        </div>
        <h1 className="text-4xl font-bold mb-3">789 Studios Lab</h1>
        <p className="text-lg text-muted-foreground max-w-3xl">
          A complete testing environment for the 789 Studios OTT platform. Explore all features safely without affecting
          production.
        </p>
      </div>

      <Card className="p-6 mb-8 border-fuchsia-500/30 bg-fuchsia-500/5">
        <h2 className="text-xl font-semibold mb-3">What is 789 Studios?</h2>
        <p className="text-muted-foreground mb-4">
          789 Studios is the entertainment production and distribution platform for WIRED CHAOS META. Think of it as a
          Netflix-style service built specifically for crypto-native content creators, featuring:
        </p>
        <ul className="space-y-2 text-muted-foreground">
          <li className="flex items-start gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-fuchsia-400 mt-2 flex-shrink-0" />
            <span>
              <strong>OTT Platform:</strong> A video streaming interface for shows, documentaries, and original content
            </span>
          </li>
          <li className="flex items-start gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-fuchsia-400 mt-2 flex-shrink-0" />
            <span>
              <strong>CSN (Crypto Spaces Network):</strong> Live X Spaces scheduling and analytics powered by Lurky
            </span>
          </li>
          <li className="flex items-start gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-fuchsia-400 mt-2 flex-shrink-0" />
            <span>
              <strong>Film3:</strong> Documentary production tools and distribution for web3 filmmakers
            </span>
          </li>
          <li className="flex items-start gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-fuchsia-400 mt-2 flex-shrink-0" />
            <span>
              <strong>Creator Profiles:</strong> Public profiles for crew members and content creators
            </span>
          </li>
        </ul>
      </Card>

      <div className="mb-8">
        <h2 className="text-2xl font-semibold mb-4">How It Works (Simple Workflow)</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-4 text-center">
            <div className="w-12 h-12 rounded-full bg-cyan-500/10 flex items-center justify-center mx-auto mb-3">
              <Users className="h-6 w-6 text-cyan-400" />
            </div>
            <h3 className="font-semibold mb-2">1. Connect</h3>
            <p className="text-sm text-muted-foreground">Link X (Twitter) accounts to pull in Spaces data</p>
          </Card>

          <Card className="p-4 text-center">
            <div className="w-12 h-12 rounded-full bg-pink-500/10 flex items-center justify-center mx-auto mb-3">
              <Radio className="h-6 w-6 text-pink-400" />
            </div>
            <h3 className="font-semibold mb-2">2. Schedule</h3>
            <p className="text-sm text-muted-foreground">CSN analyzes Spaces and creates content schedules</p>
          </Card>

          <Card className="p-4 text-center">
            <div className="w-12 h-12 rounded-full bg-fuchsia-500/10 flex items-center justify-center mx-auto mb-3">
              <Film className="h-6 w-6 text-fuchsia-400" />
            </div>
            <h3 className="font-semibold mb-2">3. Create</h3>
            <p className="text-sm text-muted-foreground">Film3 tools help produce documentaries and shows</p>
          </Card>

          <Card className="p-4 text-center">
            <div className="w-12 h-12 rounded-full bg-emerald-500/10 flex items-center justify-center mx-auto mb-3">
              <Tv2 className="h-6 w-6 text-emerald-400" />
            </div>
            <h3 className="font-semibold mb-2">4. Stream</h3>
            <p className="text-sm text-muted-foreground">Content appears on the OTT platform for viewers</p>
          </Card>
        </div>
      </div>

      <div className="space-y-4">
        <h2 className="text-2xl font-semibold">Explore the Lab Modules</h2>

        <Link href="/lab/789/dashboard">
          <Card className="p-5 hover:border-fuchsia-500/50 transition-all cursor-pointer group">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-lg bg-fuchsia-500/10 flex items-center justify-center group-hover:bg-fuchsia-500/20 transition-colors">
                  <TrendingUp className="h-5 w-5 text-fuchsia-400" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">789 Dashboard</h3>
                  <p className="text-sm text-muted-foreground">
                    View analytics, connected accounts, and recent Spaces activity
                  </p>
                </div>
              </div>
              <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-fuchsia-400 transition-colors" />
            </div>
          </Card>
        </Link>

        <Card className="p-5 opacity-60 border-neutral-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-lg bg-neutral-800 flex items-center justify-center">
                <Tv2 className="h-5 w-5 text-neutral-500" />
              </div>
              <div>
                <h3 className="font-semibold text-lg flex items-center gap-2">
                  OTT Interface
                  <span className="text-xs px-2 py-0.5 rounded bg-neutral-800 text-neutral-500">Coming Soon</span>
                </h3>
                <p className="text-sm text-muted-foreground">
                  Test the Netflix-style streaming interface with show rails and players
                </p>
              </div>
            </div>
          </div>
        </Card>

        <Card className="p-5 opacity-60 border-neutral-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-lg bg-neutral-800 flex items-center justify-center">
                <Calendar className="h-5 w-5 text-neutral-500" />
              </div>
              <div>
                <h3 className="font-semibold text-lg flex items-center gap-2">
                  CSN Schedule
                  <span className="text-xs px-2 py-0.5 rounded bg-neutral-800 text-neutral-500">Coming Soon</span>
                </h3>
                <p className="text-sm text-muted-foreground">
                  View and manage Crypto Spaces Network programming schedules
                </p>
              </div>
            </div>
          </div>
        </Card>

        <Card className="p-5 opacity-60 border-neutral-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-lg bg-neutral-800 flex items-center justify-center">
                <Film className="h-5 w-5 text-neutral-500" />
              </div>
              <div>
                <h3 className="font-semibold text-lg flex items-center gap-2">
                  Film3 Tools
                  <span className="text-xs px-2 py-0.5 rounded bg-neutral-800 text-neutral-500">Coming Soon</span>
                </h3>
                <p className="text-sm text-muted-foreground">
                  Test documentary production and Film3DAO integration features
                </p>
              </div>
            </div>
          </div>
        </Card>

        <Card className="p-5 opacity-60 border-neutral-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-lg bg-neutral-800 flex items-center justify-center">
                <Users className="h-5 w-5 text-neutral-500" />
              </div>
              <div>
                <h3 className="font-semibold text-lg flex items-center gap-2">
                  Creator Profiles
                  <span className="text-xs px-2 py-0.5 rounded bg-neutral-800 text-neutral-500">Coming Soon</span>
                </h3>
                <p className="text-sm text-muted-foreground">
                  Explore public crew member profiles and creator showcases
                </p>
              </div>
            </div>
          </div>
        </Card>
      </div>

      <Card className="p-6 mt-8 border-cyan-500/30 bg-cyan-500/5">
        <h3 className="font-semibold mb-2 text-cyan-400">Lab Safety Notice</h3>
        <p className="text-sm text-muted-foreground">
          This is a lab environment. Everything here is isolated from production systems. Feel free to click around,
          test features, and experiment—nothing you do here will affect the live 789 Studios platform or any connected
          accounts.
        </p>
      </Card>
    </div>
  )
}
