"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Twitter, TrendingUp, Users, Radio, ArrowLeft } from "lucide-react"
import Link from "next/link"

interface XProfile {
  id: string
  twitterId: string
  handle: string
  name: string
  avatarUrl?: string
  createdAt: string
}

interface LurkySpace {
  id: string
  title: string
  state: string
  started_at?: string
  creator_username?: string
  participant_count?: number
}

export default function Lab789DashboardPage() {
  const [profiles, setProfiles] = useState<XProfile[]>([])
  const [spaces, setSpaces] = useState<LurkySpace[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      const [profilesRes, spacesRes] = await Promise.all([fetch("/api/x/profiles"), fetch("/api/lurky/spaces?limit=5")])

      const profilesData = await profilesRes.json()
      const spacesData = await spacesRes.json()

      setProfiles(profilesData.profiles || [])
      setSpaces(spacesData.spaces || [])
    } catch (err) {
      console.error("[v0] Failed to load dashboard data:", err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-12 max-w-6xl">
      <div className="mb-8">
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
          <Link href="/lab" className="hover:text-foreground">
            Lab
          </Link>
          <span>/</span>
          <Link href="/lab/789" className="hover:text-foreground">
            789 Studios
          </Link>
          <span>/</span>
          <span>Dashboard</span>
        </div>
        <div className="flex items-center gap-3 mb-3">
          <Link href="/lab/789">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Lab
            </Button>
          </Link>
        </div>
        <h1 className="text-4xl font-bold mb-2">789 Studios Dashboard (Lab Copy)</h1>
        <p className="text-muted-foreground">Content analytics and X account management - Safe testing environment</p>
      </div>
      {/* </CHANGE> */}

      <Card className="p-4 mb-6 border-cyan-500/30 bg-cyan-500/5">
        <p className="text-sm text-cyan-400">
          <strong>Lab Mode:</strong> This is a non-production copy. Changes here won't affect the live 789 Studios
          system.
        </p>
      </Card>
      {/* </CHANGE> */}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="p-6 border-cyan-500/30 bg-cyan-500/5">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-muted-foreground">Connected Accounts</h3>
            <Twitter className="h-4 w-4 text-cyan-400" />
          </div>
          <div className="text-3xl font-bold text-cyan-400">{profiles.length}</div>
          <p className="text-xs text-muted-foreground mt-1">X profiles linked</p>
        </Card>

        <Card className="p-6 border-pink-500/30 bg-pink-500/5">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-muted-foreground">Total Spaces</h3>
            <Radio className="h-4 w-4 text-pink-400" />
          </div>
          <div className="text-3xl font-bold text-pink-400">{spaces.length}</div>
          <p className="text-xs text-muted-foreground mt-1">Analyzed broadcasts</p>
        </Card>

        <Card className="p-6 border-emerald-500/30 bg-emerald-500/5">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-muted-foreground">Engagement</h3>
            <TrendingUp className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="text-3xl font-bold text-emerald-400">
            {spaces.reduce((acc, s) => acc + (s.participant_count || 0), 0)}
          </div>
          <p className="text-xs text-muted-foreground mt-1">Total participants</p>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">Connected X Accounts</h2>
            <Link href="/x-connect">
              <Button variant="outline" size="sm">
                Manage
              </Button>
            </Link>
          </div>

          {loading ? (
            <Card className="p-6">
              <p className="text-muted-foreground">Loading accounts...</p>
            </Card>
          ) : profiles.length === 0 ? (
            <Card className="p-6">
              <p className="text-muted-foreground mb-4">No X accounts connected yet.</p>
              <Link href="/x-connect">
                <Button className="gap-2">
                  <Twitter className="h-4 w-4" />
                  Connect First Account
                </Button>
              </Link>
            </Card>
          ) : (
            <div className="space-y-3">
              {profiles.map((profile) => (
                <Card key={profile.id} className="p-4 flex items-center gap-4">
                  {profile.avatarUrl ? (
                    <img
                      src={profile.avatarUrl || "/placeholder.svg"}
                      alt={profile.name}
                      className="w-10 h-10 rounded-full"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                      <Twitter className="h-5 w-5" />
                    </div>
                  )}
                  <div className="flex-1">
                    <h3 className="font-medium">{profile.name}</h3>
                    <p className="text-sm text-muted-foreground">@{profile.handle}</p>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-cyan-400">
                    <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                    Active
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>

        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">Recent Spaces</h2>
            <Link href="/lurky-analytics">
              <Button variant="outline" size="sm">
                View All
              </Button>
            </Link>
          </div>

          {loading ? (
            <Card className="p-6">
              <p className="text-muted-foreground">Loading spaces...</p>
            </Card>
          ) : spaces.length === 0 ? (
            <Card className="p-6">
              <p className="text-muted-foreground">No spaces found. Connect X accounts to see analytics.</p>
            </Card>
          ) : (
            <div className="space-y-3">
              {spaces.slice(0, 5).map((space) => (
                <Card key={space.id} className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-pink-500/10 flex items-center justify-center flex-shrink-0">
                      <Radio className="h-5 w-5 text-pink-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-sm mb-1 line-clamp-2">{space.title}</h3>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        {space.creator_username && <span>@{space.creator_username}</span>}
                        {space.participant_count && (
                          <>
                            <span>•</span>
                            <span className="flex items-center gap-1">
                              <Users className="h-3 w-3" />
                              {space.participant_count}
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="mt-8">
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Link href="/x-connect">
              <Button variant="outline" className="w-full justify-start gap-2 bg-transparent">
                <Twitter className="h-4 w-4" />
                Connect X Account
              </Button>
            </Link>
            <Link href="/lurky-analytics">
              <Button variant="outline" className="w-full justify-start gap-2 bg-transparent">
                <TrendingUp className="h-4 w-4" />
                View Analytics
              </Button>
            </Link>
            <Link href="/story-engine">
              <Button variant="outline" className="w-full justify-start gap-2 bg-transparent">
                <Radio className="h-4 w-4" />
                Create Content
              </Button>
            </Link>
          </div>
        </Card>
      </div>
    </div>
  )
}
