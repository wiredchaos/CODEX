"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Shield,
  BookOpen,
  FlaskConical,
  GraduationCap,
  Network,
  Server,
  Code,
  Cloud,
  Cpu,
  Database,
  FileCheck,
  Library,
  Zap,
  CheckCircle,
  XCircle,
  Loader2,
} from "lucide-react"

const PILLAR_ICONS: Record<string, React.ReactNode> = {
  pillar_cybersecurity: <Shield className="h-5 w-5" />,
  pillar_network_infra: <Network className="h-5 w-5" />,
  pillar_enterprise_it: <Server className="h-5 w-5" />,
  pillar_programming_dev: <Code className="h-5 w-5" />,
  pillar_cloud_ecommerce: <Cloud className="h-5 w-5" />,
  pillar_hardware_iot: <Cpu className="h-5 w-5" />,
  pillar_databases: <Database className="h-5 w-5" />,
  pillar_governance_compliance: <FileCheck className="h-5 w-5" />,
  pillar_general_knowledge: <Library className="h-5 w-5" />,
}

interface RegistryData {
  version: string
  namespace: string
  stats: {
    pillars: number
    generals: number
    swarms: number
    antiMolochRules: number
  }
  pillars: Array<{
    id: string
    name: string
    generalId: string
    swarmCount: number
  }>
}

interface QueryResponse {
  pillarId: string
  generalId: string
  swarmIds: string[]
  interpretation: string
  curriculumModules: Array<{
    id: string
    title: string
    description: string
    objectives: string[]
    estimatedMinutes: number
  }>
  labBlueprints: Array<{
    id: string
    title: string
    description: string
    difficulty: string
  }>
  assessments: Array<{
    id: string
    type: string
    title: string
    passingScore: number
  }>
  knowledgeGraphSummary: string
  safetyChecks: Array<{
    id: string
    rule: string
    passed: boolean
    details: string
  }>
}

export default function EduImportPage() {
  const [registry, setRegistry] = useState<RegistryData | null>(null)
  const [loading, setLoading] = useState(false)
  const [queryLoading, setQueryLoading] = useState(false)
  const [query, setQuery] = useState("")
  const [selectedPillar, setSelectedPillar] = useState<string>("")
  const [requireLab, setRequireLab] = useState(false)
  const [requireAssessment, setRequireAssessment] = useState(false)
  const [certTarget, setCertTarget] = useState("")
  const [response, setResponse] = useState<QueryResponse | null>(null)

  const loadRegistry = async () => {
    setLoading(true)
    try {
      const res = await fetch("/api/edu")
      const data = await res.json()
      setRegistry(data)
    } catch (error) {
      console.error("Failed to load registry:", error)
    } finally {
      setLoading(false)
    }
  }

  const submitQuery = async () => {
    if (!query.trim()) return

    setQueryLoading(true)
    try {
      const res = await fetch("/api/edu", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query,
          pillarId: selectedPillar || undefined,
          requireLab,
          requireAssessment,
          certificationTarget: certTarget || undefined,
        }),
      })
      const data = await res.json()
      setResponse(data)
    } catch (error) {
      console.error("Query failed:", error)
    } finally {
      setQueryLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-cyan-500/10">
              <GraduationCap className="h-8 w-8 text-cyan-500" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">EDU Import Protocol</h1>
              <p className="text-muted-foreground">MN AGENTIC SWARM GENERAL - Education Namespace</p>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <Tabs defaultValue="query" className="space-y-6">
          <TabsList className="grid w-full max-w-md grid-cols-4">
            <TabsTrigger value="query">Query</TabsTrigger>
            <TabsTrigger value="registry">Registry</TabsTrigger>
            <TabsTrigger value="pillars">Pillars</TabsTrigger>
            <TabsTrigger value="governance">Governance</TabsTrigger>
          </TabsList>

          <TabsContent value="query" className="space-y-6">
            <div className="grid gap-6 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5 text-yellow-500" />
                    GIGA Import Query
                  </CardTitle>
                  <CardDescription>
                    Query the EDU Import Protocol to generate curricula, labs, and assessments
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Query</Label>
                    <Textarea
                      placeholder="Enter your educational query... e.g., 'Create a penetration testing curriculum for beginners'"
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      rows={4}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Target Pillar (optional)</Label>
                    <Select value={selectedPillar} onValueChange={setSelectedPillar}>
                      <SelectTrigger>
                        <SelectValue placeholder="Auto-detect from query" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="auto">Auto-detect</SelectItem>
                        <SelectItem value="pillar_cybersecurity">Cybersecurity & DFIR</SelectItem>
                        <SelectItem value="pillar_network_infra">Networking & Infrastructure</SelectItem>
                        <SelectItem value="pillar_enterprise_it">Enterprise IT Systems</SelectItem>
                        <SelectItem value="pillar_programming_dev">Programming & Development</SelectItem>
                        <SelectItem value="pillar_cloud_ecommerce">Cloud & E-Commerce</SelectItem>
                        <SelectItem value="pillar_hardware_iot">Hardware & IoT</SelectItem>
                        <SelectItem value="pillar_databases">Database Systems</SelectItem>
                        <SelectItem value="pillar_governance_compliance">Governance & Compliance</SelectItem>
                        <SelectItem value="pillar_general_knowledge">General Knowledge</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Certification Target (optional)</Label>
                    <Input
                      placeholder="e.g., CompTIA Security+, CCNA, AWS SAA"
                      value={certTarget}
                      onChange={(e) => setCertTarget(e.target.value)}
                    />
                  </div>

                  <div className="flex items-center gap-6">
                    <div className="flex items-center gap-2">
                      <Switch id="require-lab" checked={requireLab} onCheckedChange={setRequireLab} />
                      <Label htmlFor="require-lab">Generate Lab</Label>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch
                        id="require-assessment"
                        checked={requireAssessment}
                        onCheckedChange={setRequireAssessment}
                      />
                      <Label htmlFor="require-assessment">Generate Assessment</Label>
                    </div>
                  </div>

                  <Button onClick={submitQuery} disabled={queryLoading || !query.trim()} className="w-full">
                    {queryLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Zap className="mr-2 h-4 w-4" />
                        Execute Query
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {response && (
                <Card>
                  <CardHeader>
                    <CardTitle>Query Response</CardTitle>
                    <CardDescription>Processed by {response.generalId}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-[400px] pr-4">
                      <div className="space-y-4">
                        <div>
                          <h4 className="font-medium mb-2">Interpretation</h4>
                          <p className="text-sm text-muted-foreground">{response.interpretation}</p>
                        </div>

                        <div>
                          <h4 className="font-medium mb-2">Safety Checks</h4>
                          <div className="space-y-1">
                            {response.safetyChecks.map((check) => (
                              <div key={check.id} className="flex items-center gap-2 text-sm">
                                {check.passed ? (
                                  <CheckCircle className="h-4 w-4 text-green-500" />
                                ) : (
                                  <XCircle className="h-4 w-4 text-red-500" />
                                )}
                                <span className="truncate">{check.rule}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {response.curriculumModules.length > 0 && (
                          <div>
                            <h4 className="font-medium mb-2 flex items-center gap-2">
                              <BookOpen className="h-4 w-4" />
                              Curriculum Modules
                            </h4>
                            {response.curriculumModules.map((module) => (
                              <Card key={module.id} className="mb-2">
                                <CardContent className="p-3">
                                  <p className="font-medium text-sm">{module.title}</p>
                                  <p className="text-xs text-muted-foreground">{module.estimatedMinutes} min</p>
                                </CardContent>
                              </Card>
                            ))}
                          </div>
                        )}

                        {response.labBlueprints.length > 0 && (
                          <div>
                            <h4 className="font-medium mb-2 flex items-center gap-2">
                              <FlaskConical className="h-4 w-4" />
                              Lab Blueprints
                            </h4>
                            {response.labBlueprints.map((lab) => (
                              <Card key={lab.id} className="mb-2">
                                <CardContent className="p-3">
                                  <p className="font-medium text-sm">{lab.title}</p>
                                  <Badge variant="outline" className="mt-1">
                                    {lab.difficulty}
                                  </Badge>
                                </CardContent>
                              </Card>
                            ))}
                          </div>
                        )}

                        <div>
                          <h4 className="font-medium mb-2">Knowledge Graph</h4>
                          <p className="text-sm text-muted-foreground">{response.knowledgeGraphSummary}</p>
                        </div>
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="registry">
            <Card>
              <CardHeader>
                <CardTitle>Agent Registry</CardTitle>
                <CardDescription>Overview of all registered Generals and Swarms</CardDescription>
              </CardHeader>
              <CardContent>
                {!registry ? (
                  <Button onClick={loadRegistry} disabled={loading}>
                    {loading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Loading...
                      </>
                    ) : (
                      "Load Registry"
                    )}
                  </Button>
                ) : (
                  <div className="space-y-6">
                    <div className="grid gap-4 md:grid-cols-4">
                      <Card>
                        <CardContent className="p-4 text-center">
                          <p className="text-3xl font-bold text-cyan-500">{registry.stats.pillars}</p>
                          <p className="text-sm text-muted-foreground">Pillars</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="p-4 text-center">
                          <p className="text-3xl font-bold text-yellow-500">{registry.stats.generals}</p>
                          <p className="text-sm text-muted-foreground">Field Generals</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="p-4 text-center">
                          <p className="text-3xl font-bold text-green-500">{registry.stats.swarms}</p>
                          <p className="text-sm text-muted-foreground">Swarm Agents</p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="p-4 text-center">
                          <p className="text-3xl font-bold text-red-500">{registry.stats.antiMolochRules}</p>
                          <p className="text-sm text-muted-foreground">Safety Rules</p>
                        </CardContent>
                      </Card>
                    </div>

                    <div>
                      <p className="text-sm text-muted-foreground mb-2">Namespace: {registry.namespace}</p>
                      <p className="text-sm text-muted-foreground">Version: {registry.version}</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="pillars">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {registry?.pillars.map((pillar) => (
                <Card key={pillar.id} className="hover:border-cyan-500/50 transition-colors">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      {PILLAR_ICONS[pillar.id]}
                      {pillar.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 text-sm">
                      <p>
                        <span className="text-muted-foreground">General:</span>{" "}
                        <code className="text-xs bg-muted px-1 rounded">{pillar.generalId}</code>
                      </p>
                      <p>
                        <span className="text-muted-foreground">Swarms:</span>{" "}
                        <Badge variant="secondary">{pillar.swarmCount}</Badge>
                      </p>
                    </div>
                  </CardContent>
                </Card>
              )) || (
                <Card className="col-span-full">
                  <CardContent className="p-8 text-center">
                    <p className="text-muted-foreground">Load the registry first to view pillars</p>
                    <Button onClick={loadRegistry} className="mt-4" disabled={loading}>
                      Load Registry
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="governance">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-red-500" />
                  Anti-Moloch Governance
                </CardTitle>
                <CardDescription>Safety rules and copyright compliance policies</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h4 className="font-medium mb-3">Anti-Moloch Rules</h4>
                  <ul className="space-y-2">
                    <li className="flex items-start gap-2 text-sm">
                      <XCircle className="h-4 w-4 text-red-500 mt-0.5 shrink-0" />
                      No instruction for real-world illegal activity
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <XCircle className="h-4 w-4 text-red-500 mt-0.5 shrink-0" />
                      No attack guidance on live targets or third parties
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                      Always bias to defense education over offense
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                      Prioritize user empowerment and resilience
                    </li>
                    <li className="flex items-start gap-2 text-sm">
                      <XCircle className="h-4 w-4 text-red-500 mt-0.5 shrink-0" />
                      Refuse actions that enable systemic exploitation
                    </li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-medium mb-3">Copyright Policy</h4>
                  <Badge className="mb-2">Transformative Use Only</Badge>
                  <div className="grid gap-4 md:grid-cols-2 mt-3">
                    <div>
                      <p className="text-sm font-medium text-green-500 mb-2">Allowed</p>
                      <ul className="text-sm space-y-1 text-muted-foreground">
                        <li>• Semantic distillation</li>
                        <li>• Knowledge graph construction</li>
                        <li>• Curriculum design</li>
                        <li>• Assessment design</li>
                        <li>• Lab design</li>
                      </ul>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-red-500 mb-2">Forbidden</p>
                      <ul className="text-sm space-y-1 text-muted-foreground">
                        <li>• Redistribute original videos</li>
                        <li>• Redistribute original PDFs/books</li>
                        <li>• Provide direct download links</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-3">Safety Modes</h4>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• Sandbox only for exploit simulation</li>
                    <li>• Red team content wrapped in defensive context</li>
                    <li>• Sensitive topics require elevated role</li>
                    <li>• Logging enabled for all high-risk interactions</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
