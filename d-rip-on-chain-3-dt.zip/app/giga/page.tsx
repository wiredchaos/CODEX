import type React from "react"
/**
 * WIRED CHAOS META — GIGA SYSTEM DASHBOARD
 * Central control panel for all patches and subsystems
 */

import { initializeGigaSystem, GIGA_PATCHES, SPLINE_ENVIRONMENTS, NEURO_AVATARS, AKASHIC_LAYERS } from "@/lib/giga"
import { Shield, Cpu, Box, Users, Layers, Radio, Zap } from "lucide-react"

export default function GigaDashboardPage() {
  const status = initializeGigaSystem()

  const activePatches = GIGA_PATCHES.filter((p) => p.status === "ACTIVE")
  const prototypePatches = GIGA_PATCHES.filter((p) => p.status === "PROTOTYPE")
  const publicAvatars = NEURO_AVATARS.filter((a) => a.classification === "PUBLIC")

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white">
      {/* Header */}
      <header className="border-b border-cyan-500/20 p-6">
        <div className="flex items-center gap-3">
          <Cpu className="w-8 h-8 text-cyan-400" />
          <div>
            <h1 className="text-2xl font-bold text-cyan-400">WIRED CHAOS META — GIGA SYSTEM</h1>
            <p className="text-sm text-gray-400">VERSION: {status.version} | AUTHORITY: ROOT</p>
          </div>
        </div>
      </header>

      <main className="p-6 space-y-8">
        {/* System Status */}
        <section className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatusCard
            icon={<Shield className="w-5 h-5" />}
            label="Firewalls"
            value={status.firewallsIntact ? "INTACT" : "COMPROMISED"}
            status={status.firewallsIntact ? "success" : "error"}
          />
          <StatusCard
            icon={<Cpu className="w-5 h-5" />}
            label="Hub Status"
            value={status.hubOperational ? "OPERATIONAL" : "OFFLINE"}
            status={status.hubOperational ? "success" : "error"}
          />
          <StatusCard
            icon={<Layers className="w-5 h-5" />}
            label="Active Patches"
            value={`${status.patchesActive} / ${GIGA_PATCHES.length}`}
            status="info"
          />
          <StatusCard
            icon={<Box className="w-5 h-5" />}
            label="3D Environments"
            value={`${status.threeDEnvironmentsReady} Ready`}
            status="info"
          />
        </section>

        {/* Patch Registry */}
        <section>
          <h2 className="text-xl font-bold text-cyan-400 mb-4 flex items-center gap-2">
            <Radio className="w-5 h-5" />
            PATCH REGISTRY
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {activePatches.map((patch) => (
              <PatchCard key={patch.id} patch={patch} />
            ))}
          </div>

          {prototypePatches.length > 0 && (
            <>
              <h3 className="text-lg font-semibold text-yellow-400 mt-6 mb-3">PROTOTYPE PATCHES</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {prototypePatches.map((patch) => (
                  <PatchCard key={patch.id} patch={patch} />
                ))}
              </div>
            </>
          )}
        </section>

        {/* NEURO Avatars */}
        <section>
          <h2 className="text-xl font-bold text-cyan-400 mb-4 flex items-center gap-2">
            <Users className="w-5 h-5" />
            NEURO AVATAR MATRIX
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {publicAvatars.map((avatar) => (
              <AvatarCard key={avatar.id} avatar={avatar} />
            ))}
            {/* Classified Slots */}
            <div className="bg-red-950/20 border border-red-500/30 rounded-lg p-4 flex items-center justify-center">
              <span className="text-red-400 text-sm font-mono">[CLASSIFIED]</span>
            </div>
            <div className="bg-red-950/20 border border-red-500/30 rounded-lg p-4 flex items-center justify-center">
              <span className="text-red-400 text-sm font-mono">[CLASSIFIED]</span>
            </div>
          </div>
        </section>

        {/* 3D Environments */}
        <section>
          <h2 className="text-xl font-bold text-cyan-400 mb-4 flex items-center gap-2">
            <Box className="w-5 h-5" />
            3D SPLINE ENVIRONMENTS
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {SPLINE_ENVIRONMENTS.slice(0, 6).map((env) => (
              <EnvironmentCard key={env.id} environment={env} />
            ))}
          </div>
        </section>

        {/* Akashic Layers */}
        <section>
          <h2 className="text-xl font-bold text-cyan-400 mb-4 flex items-center gap-2">
            <Zap className="w-5 h-5" />
            AKASHIC NFT LAYERS
          </h2>
          <div className="grid grid-cols-3 md:grid-cols-9 gap-2">
            {AKASHIC_LAYERS.map((layer) => (
              <div
                key={layer.layer}
                className={`p-3 rounded-lg border text-center ${
                  layer.burnRequired
                    ? "bg-red-950/20 border-red-500/30"
                    : layer.stargateSync
                      ? "bg-purple-950/20 border-purple-500/30"
                      : "bg-cyan-950/20 border-cyan-500/30"
                }`}
              >
                <div className="text-2xl font-bold">{layer.layer}</div>
                <div className="text-xs text-gray-400 truncate">{layer.name.split(" ")[0]}</div>
              </div>
            ))}
          </div>
        </section>

        {/* System Output */}
        <section className="bg-black/50 border border-green-500/30 rounded-lg p-4 font-mono text-sm">
          <div className="text-green-400 mb-2">[GIGA] System Output:</div>
          <div className="text-green-300">PATCH SEARCH COMPLETE. INDEX READY.</div>
          <div className="text-green-300">Patches indexed: {GIGA_PATCHES.length}</div>
          <div className="text-green-300">Firewall integrity: {status.firewallsIntact ? "INTACT" : "COMPROMISED"}</div>
          <div className="text-green-300">NEURO avatars loaded: {status.neuroAvatarsLoaded}</div>
          <div className="text-green-300">3D environments ready: {status.threeDEnvironmentsReady}</div>
          <div className="text-green-400 mt-2">WIRED CHAOS META GIGA BUILD COMPLETE</div>
        </section>
      </main>
    </div>
  )
}

// ============================================
// COMPONENTS
// ============================================

function StatusCard({
  icon,
  label,
  value,
  status,
}: {
  icon: React.ReactNode
  label: string
  value: string
  status: "success" | "error" | "info"
}) {
  const colors = {
    success: "text-green-400 border-green-500/30 bg-green-950/20",
    error: "text-red-400 border-red-500/30 bg-red-950/20",
    info: "text-cyan-400 border-cyan-500/30 bg-cyan-950/20",
  }

  return (
    <div className={`rounded-lg border p-4 ${colors[status]}`}>
      <div className="flex items-center gap-2 mb-2">
        {icon}
        <span className="text-sm text-gray-400">{label}</span>
      </div>
      <div className="text-lg font-bold">{value}</div>
    </div>
  )
}

function PatchCard({ patch }: { patch: any }) {
  const statusColors = {
    ACTIVE: "border-green-500/30 bg-green-950/10",
    PROTOTYPE: "border-yellow-500/30 bg-yellow-950/10",
    DORMANT: "border-gray-500/30 bg-gray-950/10",
  }

  const firewallColors = {
    HARD: "text-red-400",
    SOFT: "text-yellow-400",
    PERMEABLE: "text-blue-400",
    NONE: "text-gray-400",
  }

  return (
    <div className={`rounded-lg border p-4 ${statusColors[patch.status as keyof typeof statusColors]}`}>
      <div className="flex items-center justify-between mb-2">
        <h3 className="font-bold text-white">{patch.name}</h3>
        <span className={`text-xs ${firewallColors[patch.firewall as keyof typeof firewallColors]}`}>
          {patch.firewall}
        </span>
      </div>
      <p className="text-xs text-gray-400 mb-2 line-clamp-2">{patch.role}</p>
      <div className="flex flex-wrap gap-1">
        {patch.neuroIntegration && (
          <span className="text-xs px-2 py-0.5 bg-cyan-500/20 text-cyan-400 rounded">NEURO</span>
        )}
        {patch.threeDEnabled && (
          <span className="text-xs px-2 py-0.5 bg-purple-500/20 text-purple-400 rounded">3D</span>
        )}
        {patch.blockchainEnabled && (
          <span className="text-xs px-2 py-0.5 bg-green-500/20 text-green-400 rounded">{patch.primaryChain}</span>
        )}
      </div>
    </div>
  )
}

function AvatarCard({ avatar }: { avatar: any }) {
  return (
    <div className="bg-cyan-950/20 border border-cyan-500/30 rounded-lg p-4">
      <div className="w-12 h-12 bg-cyan-500/20 rounded-full mb-2 flex items-center justify-center">
        <Users className="w-6 h-6 text-cyan-400" />
      </div>
      <h3 className="font-bold text-white text-sm">{avatar.displayName}</h3>
      <p className="text-xs text-gray-400">{avatar.motionPreset}</p>
      <div className="flex gap-1 mt-2">
        {avatar.multiverse.slice(0, 2).map((m: string) => (
          <span key={m} className="text-xs px-1.5 py-0.5 bg-cyan-500/10 text-cyan-400 rounded">
            {m}
          </span>
        ))}
      </div>
    </div>
  )
}

function EnvironmentCard({ environment }: { environment: any }) {
  const lightingColors = {
    neon: "border-cyan-500/30",
    ethereal: "border-purple-500/30",
    dark: "border-gray-500/30",
    cinematic: "border-yellow-500/30",
  }

  return (
    <div
      className={`rounded-lg border p-4 bg-black/30 ${lightingColors[environment.lighting as keyof typeof lightingColors]}`}
    >
      <h3 className="font-bold text-white mb-1">{environment.name}</h3>
      <p className="text-xs text-gray-400 mb-2">{environment.type}</p>
      <div className="flex flex-wrap gap-1">
        <span className="text-xs px-2 py-0.5 bg-white/10 text-gray-300 rounded">{environment.lighting}</span>
        <span className="text-xs px-2 py-0.5 bg-white/10 text-gray-300 rounded">
          {environment.interactiveElements.length} elements
        </span>
      </div>
    </div>
  )
}
