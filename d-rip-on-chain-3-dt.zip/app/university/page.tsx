"use client"

import { useState } from "react"
import { HOUSES } from "@/config/university"
import { SAMPLE_ARTIFACTS } from "@/config/artifacts"
import { HouseCard } from "@/components/university/house-card"
import { RankProgression } from "@/components/university/rank-progression"
import { ArtifactCard } from "@/components/artifact/artifact-card"
import { CinematicHeader } from "@/components/akashic/cinematic-header"
import { DossierSection } from "@/components/akashic/dossier-section"
import { FilmCard } from "@/components/akashic/film-card"
import { Shield, Briefcase, Trophy, Users } from "lucide-react"

export default function UniversityPage() {
  const [selectedHouse, setSelectedHouse] = useState<string>("WCU")

  // Mock user data
  const userData = {
    rank: "Initiate" as const,
    house: "WCU",
    artifacts: [SAMPLE_ARTIFACTS[0], SAMPLE_ARTIFACTS[2]],
    loopProgress: 12,
  }

  return (
    <div className="min-h-screen bg-black -mx-4 sm:-mx-6 lg:-mx-8 -my-8 px-4 sm:px-6 lg:px-8 scanlines film-grain circuit-bg">
      {/* Cinematic Hero */}
      <CinematicHeader
        title="WIRED CHAOS UNIVERSITY"
        subtitle="THE AKASHIC ARCHIVES"
        chapter="EDUCATIONAL DIVISION"
        tagline="Progress through ranks, join houses, unlock the deepest secrets of the Akashic archives"
      />

      <div className="max-w-6xl mx-auto pb-16">
        {/* User Dashboard - Cinematic Style */}
        <DossierSection title="OPERATIVE STATUS" classification="CLEARANCE FILE">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { icon: Shield, label: "RANK", value: userData.rank, color: "#00FFFF" },
              { icon: Users, label: "HOUSE", value: userData.house, color: "#FF3131" },
              { icon: Trophy, label: "ARTIFACTS", value: userData.artifacts.length, color: "#FFE066" },
              { icon: Briefcase, label: "LOOP", value: `${userData.loopProgress}%`, color: "#A35FFF" },
            ].map((stat) => (
              <div
                key={stat.label}
                className="p-4 rounded-lg border bg-black/50 text-center"
                style={{ borderColor: `${stat.color}30` }}
              >
                <stat.icon className="h-5 w-5 mx-auto mb-2" style={{ color: stat.color }} />
                <p className="text-xs font-mono text-white/40 tracking-wider">{stat.label}</p>
                <p className="text-xl font-bold mt-1" style={{ color: stat.color }}>
                  {stat.value}
                </p>
              </div>
            ))}
          </div>
        </DossierSection>

        {/* Houses - Film Card Style */}
        <DossierSection title="UNIVERSITY HOUSES" classification="FACTION INTEL">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {HOUSES.map((house) => (
              <HouseCard
                key={house.id}
                house={house}
                isSelected={selectedHouse === house.id}
                onSelect={() => setSelectedHouse(house.id)}
              />
            ))}
          </div>
        </DossierSection>

        {/* Two Column: Rank + Artifacts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 my-12">
          <FilmCard title="RANK PROGRESSION" chapter="ASCENSION PATH" accentColor="cyan">
            <RankProgression currentRank={userData.rank} />
          </FilmCard>

          <FilmCard title="ARTIFACT INVENTORY" chapter="COLLECTED ITEMS" accentColor="red">
            <div className="space-y-3">
              {userData.artifacts.length > 0 ? (
                userData.artifacts.map((artifact) => <ArtifactCard key={artifact.id} artifact={artifact} owned />)
              ) : (
                <div className="p-6 border border-dashed border-white/20 rounded text-center">
                  <p className="text-white/40 font-mono text-sm">NO ARTIFACTS COLLECTED</p>
                  <p className="text-white/20 text-xs mt-1">Complete quests to earn artifacts</p>
                </div>
              )}
            </div>
          </FilmCard>
        </div>

        {/* Akashic Courses */}
        <DossierSection title="AKASHIC COURSES" classification="CURRICULUM">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { name: "589 Numerology", status: "UNLOCKED", realm: "VRG33589", color: "#00FFFF" },
              { name: "82675 Loop Theory", status: "LOCKED", realm: "Neteru", color: "#FF3131" },
              { name: "Apinaya Time Structure", status: "LOCKED", realm: "Neteru", color: "#A35FFF" },
              { name: "Vault33 Lore Literacy", status: "LOCKED", realm: "Vault33", color: "#FFE066" },
            ].map((course) => (
              <div
                key={course.name}
                className="p-4 rounded-lg border bg-black/50"
                style={{
                  borderColor: course.status === "UNLOCKED" ? `${course.color}50` : "rgba(255,255,255,0.1)",
                  opacity: course.status === "LOCKED" ? 0.5 : 1,
                }}
              >
                <h3 className="font-mono text-sm text-white tracking-wider mb-1">{course.name}</h3>
                <p className="text-xs text-white/30 mb-2">{course.realm}</p>
                <span
                  className="text-xs font-mono px-2 py-0.5 rounded"
                  style={{
                    color: course.status === "UNLOCKED" ? course.color : "rgba(255,255,255,0.3)",
                    background: course.status === "UNLOCKED" ? `${course.color}20` : "rgba(255,255,255,0.05)",
                  }}
                >
                  {course.status}
                </span>
              </div>
            ))}
          </div>
        </DossierSection>
      </div>
    </div>
  )
}
