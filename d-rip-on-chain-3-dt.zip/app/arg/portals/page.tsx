"use client"
import { PORTAL_ORIGIN_EVENT } from "@/types/clockfall"

const PORTALS = [
  {
    id: "gate-33-3",
    name: "Gate 33.3",
    status: "dormant",
    location: "Primary broadcast nexus",
    coordinates: "33.3°N, 118.5°W",
    activationCondition: "Requires 589 signature + frequency lock",
  },
  {
    id: "vault-33-main",
    name: "Vault 33 Main Portal",
    status: "dormant",
    location: "Deep archive chamber",
    coordinates: "Classified",
    activationCondition: "82675 checksum required",
  },
  {
    id: "vrg33589-rift",
    name: "VRG33589 Dimensional Rift",
    status: "primed",
    location: "Astral boundary layer",
    coordinates: "Non-Euclidean",
    activationCondition: "Triad activation pending",
  },
  {
    id: "akira-rupture",
    name: "Akira Codex Rupture Point",
    status: "dormant",
    location: "Story engine terminus",
    coordinates: "Variable",
    activationCondition: "Narrative coherence threshold",
  },
  {
    id: "xrpl-astral",
    name: "XRPL Astral Gateway",
    status: "dormant",
    location: "Ledger frequency node",
    coordinates: "589.82675",
    activationCondition: "ISO 20022 alignment",
  },
  {
    id: "neuro-signal",
    name: "NEURO Signal Beacon",
    status: "active",
    location: "Red Fang transmission point",
    coordinates: "Omnipresent",
    activationCondition: "Always broadcasting",
  },
]

export default function PortalsPage() {
  const activeCount = PORTALS.filter((p) => p.status === "active").length
  const primedCount = PORTALS.filter((p) => p.status === "primed").length
  const dormantCount = PORTALS.filter((p) => p.status === "dormant").length

  return (
    <main className="min-h-screen bg-black text-white">
      {/* Hero */}
      <section className="relative py-20 px-6 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-cyan-950/20 via-black to-black" />

        <div className="relative z-10 max-w-4xl mx-auto text-center">
          <div className="text-cyan-400 font-mono text-sm tracking-[0.3em] mb-4">589 PORTAL NETWORK</div>
          <h1 className="text-5xl md:text-6xl font-bold text-cyan-300 mb-4">PORTAL MAP</h1>
          <p className="text-cyan-400/60 max-w-2xl mx-auto">
            Every Gate, Vault, Rift, and Chamber in WIRED CHAOS traces back to January 19, 2038
          </p>

          {/* Status indicators */}
          <div className="flex justify-center gap-8 mt-8">
            <div className="text-center">
              <div className="text-3xl font-bold text-emerald-400">{activeCount}</div>
              <div className="text-xs text-emerald-400/60">ACTIVE</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-amber-400">{primedCount}</div>
              <div className="text-xs text-amber-400/60">PRIMED</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-neutral-400">{dormantCount}</div>
              <div className="text-xs text-neutral-400/60">DORMANT</div>
            </div>
          </div>
        </div>
      </section>

      {/* Portal Grid */}
      <section className="py-16 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="grid md:grid-cols-2 gap-6">
            {PORTALS.map((portal) => (
              <div
                key={portal.id}
                className={`border rounded-xl p-6 transition-all ${
                  portal.status === "active"
                    ? "border-emerald-500/50 bg-emerald-950/20"
                    : portal.status === "primed"
                      ? "border-amber-500/50 bg-amber-950/20"
                      : "border-neutral-700/50 bg-neutral-900/20"
                }`}
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-white">{portal.name}</h3>
                    <p className="text-sm text-neutral-400">{portal.location}</p>
                  </div>
                  <div
                    className={`px-2 py-1 rounded text-xs uppercase font-mono ${
                      portal.status === "active"
                        ? "bg-emerald-500/20 text-emerald-400"
                        : portal.status === "primed"
                          ? "bg-amber-500/20 text-amber-400"
                          : "bg-neutral-500/20 text-neutral-400"
                    }`}
                  >
                    {portal.status}
                  </div>
                </div>

                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-neutral-500">Coordinates:</span>
                    <span className="text-cyan-400 font-mono">{portal.coordinates}</span>
                  </div>
                  <div>
                    <span className="text-neutral-500">Activation:</span>
                    <p className="text-neutral-300 mt-1">{portal.activationCondition}</p>
                  </div>
                </div>

                {portal.status === "active" && (
                  <div className="mt-4 pt-4 border-t border-emerald-500/20">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
                      <span className="text-xs text-emerald-400">SIGNAL BROADCASTING</span>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Origin Event */}
      <section className="py-16 px-6 bg-gradient-to-b from-black to-amber-950/10">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-2xl font-bold text-amber-300 mb-4">PORTAL ORIGIN EVENT</h2>
          <div className="border border-amber-500/30 rounded-xl p-6 bg-amber-950/20">
            <div className="font-mono text-amber-400 text-lg mb-2">
              {PORTAL_ORIGIN_EVENT.date} @ {PORTAL_ORIGIN_EVENT.time} {PORTAL_ORIGIN_EVENT.timezone}
            </div>
            <p className="text-amber-300/80">{PORTAL_ORIGIN_EVENT.description}</p>
            <div className="mt-4 text-xs text-amber-400/60 uppercase">{PORTAL_ORIGIN_EVENT.significance}</div>
          </div>
        </div>
      </section>
    </main>
  )
}
