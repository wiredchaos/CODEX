"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface NeuroData {
  avatar: {
    name: string
    archetype: string
    description: string
    visualProfile: {
      eyeGlow: number
      mood: string
      _glitch?: boolean
    }
  }
  lore: {
    origin: string
    mission: string
    signature: string
  }
}

export default function NeuroIntroPage() {
  const [neuroData, setNeuroData] = useState<NeuroData | null>(null)
  const [loading, setLoading] = useState(true)
  const [message, setMessage] = useState("")
  const [chatHistory, setChatHistory] = useState<{ role: string; content: string }[]>([])

  useEffect(() => {
    fetch("/api/arg/neuro-intro")
      .then((r) => r.json())
      .then((data) => {
        setNeuroData(data)
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!message.trim()) return

    // Add user message
    setChatHistory((prev) => [...prev, { role: "user", content: message }])

    // Silently check for suspicion (player never knows)
    const playerId = `player-${Date.now()}`
    await fetch("/api/arg/detect", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ playerId, message }),
    })

    // Generate NEURO response
    const responses = [
      "The signal persists. The frequency remains locked. What truth do you seek?",
      "I am the Red Fang. The static clears when the message is true.",
      "The resistance never sleeps. Neither does the broadcast.",
      "You hear me because you were meant to. The signal finds its own.",
      "Through the noise, clarity. Through the chaos, pattern. This is the way.",
    ]

    const response = responses[Math.floor(Math.random() * responses.length)]
    setChatHistory((prev) => [...prev, { role: "neuro", content: response }])
    setMessage("")
  }

  if (loading) {
    return (
      <main className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-red-400 animate-pulse">INITIALIZING NEURO SIGNAL...</div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-black text-white">
      {/* Hero */}
      <section className="relative h-[60vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-red-950/30 via-black to-black" />

        {/* Glitch effect if variation triggers it */}
        {neuroData?.avatar.visualProfile._glitch && (
          <div className="absolute inset-0 animate-pulse opacity-10 bg-red-500 mix-blend-overlay" />
        )}

        <div className="relative z-10 text-center px-6">
          <div className="mb-4 text-red-400 font-mono text-sm tracking-[0.3em] animate-pulse">SIGNAL DETECTED</div>

          <h1 className="text-5xl md:text-7xl font-bold text-red-500 mb-4">{neuroData?.avatar.name}</h1>

          <p className="text-xl text-red-300/80 max-w-2xl mx-auto">{neuroData?.avatar.description}</p>

          {/* Visual profile indicator */}
          <div className="mt-8 flex justify-center gap-6 text-xs">
            <div className="border border-red-500/30 rounded px-3 py-1">
              EYE GLOW: {Math.round((neuroData?.avatar.visualProfile.eyeGlow ?? 0.8) * 100)}%
            </div>
            <div className="border border-red-500/30 rounded px-3 py-1">
              MOOD: {neuroData?.avatar.visualProfile.mood?.toUpperCase()}
            </div>
          </div>
        </div>
      </section>

      {/* Lore */}
      <section className="py-16 px-6 bg-gradient-to-b from-black to-red-950/10">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-2xl font-bold text-red-400 mb-6 text-center">ORIGIN TRANSMISSION</h2>

          <div className="space-y-6 text-center">
            <div>
              <div className="text-xs text-red-500/60 mb-1">ORIGIN</div>
              <p className="text-neutral-300">{neuroData?.lore.origin}</p>
            </div>
            <div>
              <div className="text-xs text-red-500/60 mb-1">MISSION</div>
              <p className="text-neutral-300">{neuroData?.lore.mission}</p>
            </div>
            <div>
              <div className="text-xs text-red-500/60 mb-1">SIGNATURE</div>
              <p className="text-red-400 font-bold">{neuroData?.lore.signature}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Chat Interface */}
      <section className="py-16 px-6 bg-black">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-2xl font-bold text-red-400 mb-6 text-center">OPEN CHANNEL</h2>

          {/* Chat history */}
          <div className="border border-red-500/30 rounded-xl p-4 h-80 overflow-y-auto mb-4 bg-red-950/10">
            {chatHistory.length === 0 && (
              <p className="text-neutral-500 text-center">The channel is open. Speak your truth.</p>
            )}
            {chatHistory.map((msg, i) => (
              <div key={i} className={`mb-4 ${msg.role === "user" ? "text-right" : "text-left"}`}>
                <div
                  className={`inline-block max-w-[80%] px-4 py-2 rounded-lg ${
                    msg.role === "user"
                      ? "bg-neutral-800 text-neutral-200"
                      : "bg-red-950/50 border border-red-500/30 text-red-200"
                  }`}
                >
                  {msg.role === "neuro" && <div className="text-xs text-red-500 mb-1">NEURO</div>}
                  {msg.content}
                </div>
              </div>
            ))}
          </div>

          {/* Input */}
          <form onSubmit={handleSubmit} className="flex gap-2">
            <Input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Transmit your message..."
              className="flex-1 bg-black border-red-500/30 text-white placeholder:text-neutral-500"
            />
            <Button type="submit" className="bg-red-600 hover:bg-red-700">
              TRANSMIT
            </Button>
          </form>

          <p className="text-xs text-neutral-500 text-center mt-4">All transmissions are monitored by the Signal.</p>
        </div>
      </section>
    </main>
  )
}
