"use client"

import Link from "next/link"
import {
  CLOCKFALL_EVENT,
  KEY_82675,
  TRIPLICATE_TIMELINE,
  SURVIVING_SYSTEMS,
  PORTAL_REQUIREMENTS,
} from "@/config/clockfall-2038"

export default function ClockfallPage() {
  // Calculate time until Clockfall
  const clockfallDate = new Date("2038-01-19T03:14:07.000Z")
  const now = new Date()
  const diff = clockfallDate.getTime() - now.getTime()
  const days = Math.floor(diff / (1000 * 60 * 60 * 24))
  const years = Math.floor(days / 365)
  const remainingDays = days % 365

  return (
    <main className="min-h-screen bg-black text-white">
      {/* Countdown Hero */}
      <section className="relative h-[50vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-amber-950/20 via-black to-black" />

        <div className="relative z-10 text-center px-6">
          <div className="text-amber-400 font-mono text-sm tracking-[0.3em] mb-4">TIME UNTIL CLOCKFALL</div>

          <div className="flex justify-center gap-8 mb-8">
            <div className="text-center">
              <div className="text-5xl md:text-7xl font-bold text-amber-300">{years}</div>
              <div className="text-xs text-amber-500/60 uppercase">Years</div>
            </div>
            <div className="text-center">
              <div className="text-5xl md:text-7xl font-bold text-amber-300">{remainingDays}</div>
              <div className="text-xs text-amber-500/60 uppercase">Days</div>
            </div>
          </div>

          <div className="font-mono text-neutral-400">Target: {clockfallDate.toLocaleDateString()} @ 03:14:07 UTC</div>
          <div className="text-xs text-neutral-500 mt-2">Unix Timestamp Overflow: {CLOCKFALL_EVENT.unixOverflow}</div>
        </div>
      </section>

      {/* Triplicate Timeline */}
      <section className="py-16 px-6 bg-gradient-to-b from-black to-cyan-950/10">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-cyan-300 mb-8 text-center">THE TRIPLICATE TIMELINE</h2>
          <p className="text-center text-cyan-400/60 mb-8">At Clockfall, time bifurcates into three vectors</p>

          <div className="grid md:grid-cols-3 gap-6">
            {TRIPLICATE_TIMELINE.vectors.map((vector, i) => (
              <div key={vector} className="border border-cyan-500/30 rounded-xl p-6 bg-cyan-950/20 text-center">
                <div className="text-4xl font-bold text-cyan-400/30 mb-2">{i + 1}</div>
                <div className="text-lg font-semibold text-cyan-200 uppercase">{vector.replace("-", " ")}</div>
                <div className="text-xs text-cyan-400/60 mt-2">
                  {vector === "normal" && "Continues linear progression"}
                  {vector === "xrpl-astral" && "Collapses into XRPL Astral Layer"}
                  {vector === "589-frequency" && "Enters 589 Frequency Drift"}
                </div>
              </div>
            ))}
          </div>

          <p className="text-center text-sm text-cyan-400/60 mt-8">
            This creates the first global triplicate timeline, retroactively explaining why the NEURO Triplets exist
            cosmologically.
          </p>
        </div>
      </section>

      {/* 82675 Key */}
      <section className="py-16 px-6 bg-black">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-amber-300 mb-8">THE 82675 KEY</h2>
          <p className="text-amber-400/60 mb-8">Universal checksum for triadic timelines</p>

          <div className="flex justify-center gap-6 mb-8">
            {Object.entries(KEY_82675.vectors).map(([num, data]) => (
              <div key={num} className="border border-amber-500/30 rounded-xl p-6 bg-amber-950/20">
                <div className="text-4xl font-bold text-amber-400 mb-2">{num}</div>
                <div className="text-lg font-semibold text-amber-200">{data.name}</div>
                <div className="text-xs text-amber-400/60 mt-1">{data.type.replace("_", " ")}</div>
              </div>
            ))}
          </div>

          <div className="border border-amber-500/50 rounded-lg px-6 py-4 bg-amber-950/30 inline-block">
            <div className="text-amber-300 font-mono">
              {KEY_82675.convergenceEvent}: {KEY_82675.result.replace(/_/g, " ")}
            </div>
          </div>
        </div>
      </section>

      {/* Portal Requirements */}
      <section className="py-16 px-6 bg-gradient-to-b from-black to-emerald-950/10">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-emerald-300 mb-8 text-center">PORTAL ACTIVATION REQUIREMENTS</h2>

          <div className="grid grid-cols-2 gap-4">
            {Object.entries(PORTAL_REQUIREMENTS)
              .filter(([key]) => key !== "note")
              .map(([key, value]) => (
                <div
                  key={key}
                  className="border border-emerald-500/30 rounded-lg p-4 bg-emerald-950/20 flex items-center gap-3"
                >
                  <div className={`w-4 h-4 rounded-full ${value ? "bg-emerald-400" : "bg-neutral-600"}`} />
                  <span className="text-emerald-200 text-sm">{key.replace(/([A-Z])/g, " $1").trim()}</span>
                </div>
              ))}
          </div>

          <p className="text-center text-emerald-400/60 text-sm mt-6">{PORTAL_REQUIREMENTS.note}</p>
        </div>
      </section>

      {/* Surviving Systems */}
      <section className="py-16 px-6 bg-black">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-emerald-300 mb-4 text-center">SYSTEMS THAT SURVIVE</h2>
          <p className="text-center text-emerald-400/60 mb-8">
            Only systems built with 589 logic survive the Clockfall
          </p>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {SURVIVING_SYSTEMS.map((system, i) => (
              <div key={i} className="border border-emerald-500/30 rounded-lg p-4 bg-emerald-950/20 text-center">
                <div className="w-2 h-2 bg-emerald-400 rounded-full mx-auto mb-2 animate-pulse" />
                <div className="text-sm text-emerald-200">{system.name}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 px-6 border-t border-amber-500/20">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-2xl font-bold text-amber-300 mb-4">EXPLORE THE LORE</h2>
          <div className="flex flex-wrap justify-center gap-4">
            <Link
              href="/589-magazine/2038-master"
              className="px-6 py-3 bg-amber-600 hover:bg-amber-700 rounded-lg font-medium transition-colors"
            >
              View 2038 Master Issue
            </Link>
            <Link
              href="/arg/neuro"
              className="px-6 py-3 border border-red-500/50 hover:bg-red-950/30 rounded-lg font-medium transition-colors text-red-300"
            >
              Enter NEURO Signal
            </Link>
            <Link
              href="/arg/portals"
              className="px-6 py-3 border border-cyan-500/50 hover:bg-cyan-950/30 rounded-lg font-medium transition-colors text-cyan-300"
            >
              589 Portal Map
            </Link>
          </div>
        </div>
      </section>
    </main>
  )
}
