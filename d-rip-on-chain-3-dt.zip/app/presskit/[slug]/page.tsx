import { CinematicHeader } from "@/components/akashic/cinematic-header"
import { SAMPLE_PUBLICATIONS, SAMPLE_SEEDS } from "@/config/story-engine"
import { notFound } from "next/navigation"

export default async function PressKitPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const publication = SAMPLE_PUBLICATIONS.find((p) => p.book_slug === slug)

  if (!publication) notFound()

  const seed = SAMPLE_SEEDS[0]

  return (
    <div className="min-h-screen bg-black">
      <div className="fixed inset-0 pointer-events-none z-50 bg-[url('/textures/scanlines.png')] opacity-5" />

      <div className="relative z-10">
        <CinematicHeader title="PRESS KIT" subtitle={seed.title} classification="CREATOR CODEX // MEDIA ASSETS" />

        <main className="max-w-4xl mx-auto px-6 py-12 space-y-12">
          {/* Quick Facts */}
          <section className="p-6 border border-amber-500/20 rounded-lg bg-amber-500/5">
            <h3 className="text-xs uppercase tracking-widest text-amber-400 mb-4">Quick Facts</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-zinc-500">Title:</span> <span className="text-zinc-200">{seed.title}</span>
              </div>
              <div>
                <span className="text-zinc-500">Genre:</span>{" "}
                <span className="text-zinc-200 capitalize">{seed.genre}</span>
              </div>
              <div>
                <span className="text-zinc-500">Price:</span>{" "}
                <span className="text-zinc-200">${publication.price}</span>
              </div>
              <div>
                <span className="text-zinc-500">ASIN:</span> <span className="text-zinc-200">{publication.asin}</span>
              </div>
            </div>
          </section>

          {/* Synopsis */}
          <section>
            <h3 className="text-xs uppercase tracking-widest text-red-500 mb-4">Synopsis</h3>
            <p className="text-zinc-300 leading-relaxed">
              In {seed.world_context.setting}, {seed.characters[0]?.name || "a protagonist"} discovers a truth that
              could unravel everything. A {seed.genre} tale exploring themes of{" "}
              {seed.world_context.rules.slice(0, 2).join(" and ")}.
            </p>
          </section>

          {/* Downloadable Assets */}
          <section>
            <h3 className="text-xs uppercase tracking-widest text-red-500 mb-4">Downloadable Assets</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {["Cover Art (High Res)", "Cover Art (Thumbnail)", "Author Photo", "Marketing Banner"].map((asset) => (
                <div
                  key={asset}
                  className="p-4 border border-zinc-800 rounded-lg flex items-center justify-between hover:border-cyan-500/30 transition-colors cursor-pointer"
                >
                  <span className="text-zinc-300">{asset}</span>
                  <span className="text-xs text-cyan-400">DOWNLOAD</span>
                </div>
              ))}
            </div>
          </section>

          {/* Pull Quotes */}
          <section>
            <h3 className="text-xs uppercase tracking-widest text-red-500 mb-4">Pull Quotes</h3>
            <div className="space-y-4">
              {[
                '"A mind-bending journey through digital chaos." — WIRED CHAOS REVIEW',
                '"Essential reading for the post-digital age." — THE AKASHIC TIMES',
              ].map((quote, i) => (
                <blockquote key={i} className="p-4 border-l-2 border-fuchsia-500 bg-zinc-900/50 text-zinc-300 italic">
                  {quote}
                </blockquote>
              ))}
            </div>
          </section>

          {/* Contact */}
          <section className="p-6 border border-zinc-800 rounded-lg">
            <h3 className="text-xs uppercase tracking-widest text-zinc-500 mb-4">Media Contact</h3>
            <p className="text-zinc-400 text-sm">
              For interviews, review copies, or media inquiries:
              <br />
              <span className="text-cyan-400">press@wiredchaos.meta</span>
            </p>
          </section>
        </main>
      </div>
    </div>
  )
}
