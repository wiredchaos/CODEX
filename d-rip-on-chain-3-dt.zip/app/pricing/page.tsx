"use client"

import { useState } from "react"
import Link from "next/link"
import { Check, Zap, Crown, Sparkles, Building2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { SEAT_TIERS, FOUNDER_TIERS, type SeatTier } from "@/lib/pricing/seat-pricing-engine"

export default function PricingPage() {
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly" | "lifetime">("monthly")
  const [hasNFT, setHasNFT] = useState(false)

  const getPrice = (tier: SeatTier) => {
    let price =
      billingCycle === "monthly" ? tier.monthlyPrice : billingCycle === "yearly" ? tier.yearlyPrice : tier.lifetimePrice

    if (hasNFT) {
      price = Math.round(price * (1 - tier.nftDiscount / 100))
    }

    return price
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Zap className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="font-bold text-lg">WIRED CHAOS</h1>
              <p className="text-xs text-muted-foreground">PRICING</p>
            </div>
          </Link>
          <div className="flex items-center gap-4">
            <Button variant="outline" size="sm" asChild>
              <Link href="/lite">Lite Version</Link>
            </Button>
            <Button size="sm" asChild>
              <Link href="/register">Get Started</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="py-16 px-4 text-center">
        <Badge variant="outline" className="mb-4">
          <Sparkles className="w-3 h-3 mr-1" />
          Sacred Number Pricing
        </Badge>
        <h1 className="text-4xl font-bold mb-4">
          Choose Your <span className="text-primary">Access Level</span>
        </h1>
        <p className="text-muted-foreground max-w-2xl mx-auto mb-8">
          Pricing aligned to 589 and 333 sacred increments. NFT holders receive automatic discounts across all tiers.
        </p>

        {/* NFT Discount Toggle */}
        <div className="flex items-center justify-center gap-3 mb-8">
          <span className={`text-sm ${!hasNFT ? "text-foreground" : "text-muted-foreground"}`}>Standard Pricing</span>
          <button
            onClick={() => setHasNFT(!hasNFT)}
            className={`relative w-12 h-6 rounded-full transition-colors ${hasNFT ? "bg-primary" : "bg-muted"}`}
          >
            <span
              className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform ${
                hasNFT ? "left-7" : "left-1"
              }`}
            />
          </button>
          <span className={`text-sm ${hasNFT ? "text-foreground" : "text-muted-foreground"}`}>NFT Holder Pricing</span>
        </div>

        {/* Billing Cycle Tabs */}
        <Tabs value={billingCycle} onValueChange={(v) => setBillingCycle(v as any)} className="mb-12">
          <TabsList className="mx-auto">
            <TabsTrigger value="monthly">Monthly</TabsTrigger>
            <TabsTrigger value="yearly">
              Yearly{" "}
              <Badge variant="secondary" className="ml-2 text-xs">
                Save 20%
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="lifetime">Lifetime</TabsTrigger>
          </TabsList>
        </Tabs>
      </section>

      {/* Seat Tiers */}
      <section className="px-4 pb-16">
        <div className="container mx-auto max-w-7xl">
          <div className="grid md:grid-cols-3 lg:grid-cols-6 gap-4">
            {SEAT_TIERS.map((tier, index) => {
              const isPopular = tier.id === "pro-33"
              const price = getPrice(tier)

              return (
                <Card
                  key={tier.id}
                  className={`relative ${isPopular ? "border-primary shadow-lg ring-2 ring-primary/20" : ""}`}
                >
                  {isPopular && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                      <Badge className="bg-primary">Most Popular</Badge>
                    </div>
                  )}
                  <CardHeader className="text-center pb-2">
                    <div className="text-xs text-muted-foreground mb-1">{tier.sacredNumber} ALIGNMENT</div>
                    <CardTitle className="text-lg">{tier.name}</CardTitle>
                    <CardDescription>{tier.seats} seats</CardDescription>
                  </CardHeader>
                  <CardContent className="text-center">
                    <div className="mb-4">
                      <span className="text-3xl font-bold">${price}</span>
                      {billingCycle !== "lifetime" && (
                        <span className="text-muted-foreground">/{billingCycle === "monthly" ? "mo" : "yr"}</span>
                      )}
                      {hasNFT && tier.nftDiscount > 0 && (
                        <div className="text-xs text-green-500 mt-1">-{tier.nftDiscount}% NFT discount</div>
                      )}
                    </div>
                    <ul className="text-xs text-left space-y-2 mb-4">
                      {tier.features.slice(0, 3).map((feature, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <Check className="w-3 h-3 text-primary mt-0.5 shrink-0" />
                          <span className="text-muted-foreground">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Button className="w-full" size="sm" variant={isPopular ? "default" : "outline"}>
                      Select
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Founder Tiers */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="container mx-auto max-w-5xl">
          <div className="text-center mb-12">
            <Badge variant="outline" className="mb-4">
              <Crown className="w-3 h-3 mr-1" />
              Limited Availability
            </Badge>
            <h2 className="text-3xl font-bold mb-4">Founder Tiers</h2>
            <p className="text-muted-foreground">
              One-time purchase for lifetime access, governance rights, and exclusive benefits
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {FOUNDER_TIERS.map((tier) => (
              <Card key={tier.id} className="relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full -translate-y-1/2 translate-x-1/2" />
                <CardHeader>
                  <div className="flex items-center justify-between mb-2">
                    <Crown className="w-8 h-8 text-primary" />
                    <Badge variant="secondary">{tier.maxSupply} spots</Badge>
                  </div>
                  <CardTitle>{tier.name}</CardTitle>
                  <CardDescription>{tier.seats} seats included</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-6">
                    <span className="text-4xl font-bold">${tier.price.toLocaleString()}</span>
                    <span className="text-muted-foreground"> one-time</span>
                  </div>
                  <ul className="space-y-2 mb-6">
                    {tier.benefits.map((benefit, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm">
                        <Check className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                        <span>{benefit}</span>
                      </li>
                    ))}
                  </ul>
                  <Button className="w-full">Claim Founder Spot</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* White Label CTA */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-3xl">
          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="p-8 text-center">
              <Building2 className="w-12 h-12 text-primary mx-auto mb-4" />
              <h3 className="text-2xl font-bold mb-2">White-Label Solutions</h3>
              <p className="text-muted-foreground mb-6">
                Deploy your own branded version of WIRED CHAOS for your organization. Custom domains, branding, and
                dedicated support included.
              </p>
              <Button size="lg" asChild>
                <Link href="/business/chaos-builder-exchange/concierge">Contact Sales</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 py-8 px-4">
        <div className="container mx-auto text-center text-sm text-muted-foreground">
          <p>© 2025 WIRED CHAOS META. Sacred Number Pricing System.</p>
          <p className="mt-1">589 + 333 aligned for optimal value exchange.</p>
        </div>
      </footer>
    </div>
  )
}
