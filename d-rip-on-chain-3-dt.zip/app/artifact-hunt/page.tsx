import { SAMPLE_ARTIFACTS } from "@/config/artifacts"
import { ArtifactCard } from "@/components/artifact/artifact-card"
import { CinematicHeader } from "@/components/akashic/cinematic-header"
import { FilmCard } from "@/components/akashic/film-card"
import { EnterChaosCTA } from "@/components/akashic/enter-chaos-cta"
import { DossierSection } from "@/components/akashic/dossier-section"

export default function ArtifactHuntPage() {
  return (
    <div className="min-h-screen bg-black -mx-4 sm:-mx-6 lg:-mx-8 -my-8 px-4 sm:px-6 lg:px-8">
      {/* Cinematic Hero */}
      <CinematicHeader
        title="ARTIFACT HUNT"
        subtitle="DISCOVER. DECODE. ASCEND."
        chapter="FIELD OPERATIONS"
        tagline="Hidden across broadcasts, buried in ciphers, waiting for those who dare to seek"
      />

      <div className="max-w-5xl mx-auto pb-16">
        {/* How It Works - Dossier Style */}
        <DossierSection title="CLUE CLASSIFICATION" classification="INTEL BRIEF">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <FilmCard title="VISIBLE" chapter="CLASS-A" accentColor="cyan">
              <p className="text-sm text-white/60">
                Text on screen, explicit riddles, obvious symbols placed in broadcasts for all operatives.
              </p>
            </FilmCard>
            <FilmCard title="SEMI-HIDDEN" chapter="CLASS-B" accentColor="red">
              <p className="text-sm text-white/60">
                589 patterns, cropped frames, symbols in backgrounds requiring heightened awareness.
              </p>
            </FilmCard>
            <FilmCard title="DEEP" chapter="CLASS-C" accentColor="cyan">
              <p className="text-sm text-white/60">
                Audio spectrograms, frame counts, encoded messages for dedicated field agents.
              </p>
            </FilmCard>
          </div>
        </DossierSection>

        {/* Artifact Classes */}
        <DossierSection title="ARTIFACT CLASSIFICATION" classification="MANIFEST">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { name: "NEURAL KEYS", color: "#00FFFF", desc: "Unlock hidden content" },
              { name: "QUANTUM RELICS", color: "#FF3131", desc: "Rare storyline pieces" },
              { name: "CHAOS CHIPS", color: "#A35FFF", desc: "Game power-ups" },
              { name: "ANCESTRAL SCROLLS", color: "#FFE066", desc: "Lore expansion items" },
            ].map((item) => (
              <div
                key={item.name}
                className="p-4 rounded-lg border border-white/10 bg-black/50 text-center"
                style={{ borderColor: `${item.color}30` }}
              >
                <div className="w-12 h-12 mx-auto mb-3 rounded-full" style={{ background: `${item.color}20` }}>
                  <div
                    className="w-full h-full rounded-full flex items-center justify-center text-lg font-bold"
                    style={{ color: item.color }}
                  >
                    {item.name.charAt(0)}
                  </div>
                </div>
                <h4 className="text-xs font-mono tracking-wider mb-1" style={{ color: item.color }}>
                  {item.name}
                </h4>
                <p className="text-xs text-white/40">{item.desc}</p>
              </div>
            ))}
          </div>
        </DossierSection>

        {/* Available Artifacts */}
        <DossierSection title="ACTIVE ARTIFACTS" classification="FIELD TARGETS">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {SAMPLE_ARTIFACTS.map((artifact) => (
              <ArtifactCard key={artifact.id} artifact={artifact} />
            ))}
          </div>
        </DossierSection>

        {/* CTA */}
        <EnterChaosCTA href="/university" label="ENTER THE UNIVERSITY" />
      </div>
    </div>
  )
}
