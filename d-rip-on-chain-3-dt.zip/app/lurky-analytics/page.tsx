"use client"

import { useState, useEffect, useMemo } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Radio, Users, Search, Filter, Coins, TrendingUp, TrendingDown } from "lucide-react"

interface LurkySpace {
  id: string
  title: string
  state: string
  started_at?: string
  creator_username?: string
  creator_handle?: string
  participant_count?: number
  categories?: string[]
}

interface LurkyCoin {
  id: string
  name: string
  symbol: string
  image?: string
  priceUsd?: number
  price?: number
  priceChange24h?: number
  marketCapRank?: number
  mentions?: {
    total: number
    bullish: number
    neutral: number
    bearish: number
  }
  mentionStats?: {
    total: number
    bullish: number
    neutral: number
    bearish: number
  }
}

interface LurkySpeaker {
  id: string
  twitterId?: string
  handle: string
  name?: string
  image?: string
  followersCount?: number
  verified?: boolean
  verifiedType?: string
}

export default function LurkyAnalyticsPage() {
  // Spaces state
  const [spaces, setSpaces] = useState<LurkySpace[]>([])
  const [spacesLoading, setSpacesLoading] = useState(true)
  const [spacesPage, setSpacesPage] = useState(0)
  const [spacesState, setSpacesState] = useState("analyzed")
  const [spacesQuery, setSpacesQuery] = useState("")

  const [coins, setCoins] = useState<LurkyCoin[]>([])
  const [coinsLoading, setCoinsLoading] = useState(true)
  const [coinsPage, setCoinsPage] = useState(0)
  const [coinsSortBy, setCoinsSortBy] = useState<"mentions" | "market_cap">("mentions")

  const [speakers, setSpeakers] = useState<LurkySpeaker[]>([])
  const [speakersLoading, setSpeakersLoading] = useState(true)
  const [speakersPage, setSpeakersPage] = useState(0)
  const [minFollowers, setMinFollowers] = useState<string>("5000")

  const limit = 20

  // Load Spaces
  useEffect(() => {
    const loadSpaces = async () => {
      setSpacesLoading(true)
      try {
        const res = await fetch(`/api/lurky/spaces?page=${spacesPage}&limit=${limit}&state=${spacesState}`)
        const data = await res.json()
        setSpaces(data.spaces || [])
      } catch (err) {
        console.error("Failed to load spaces:", err)
      } finally {
        setSpacesLoading(false)
      }
    }
    loadSpaces()
  }, [spacesPage, spacesState])

  useEffect(() => {
    const loadCoins = async () => {
      setCoinsLoading(true)
      try {
        const res = await fetch(
          `/api/lurky/coins-with-mentions?page=${coinsPage}&limit=${limit}&sort_by=${coinsSortBy}&sort_dir=desc`,
        )
        const data = await res.json()
        setCoins(data.coins || [])
      } catch (err) {
        console.error("Failed to load coins:", err)
      } finally {
        setCoinsLoading(false)
      }
    }
    loadCoins()
  }, [coinsPage, coinsSortBy])

  useEffect(() => {
    const loadSpeakers = async () => {
      setSpeakersLoading(true)
      try {
        const params = new URLSearchParams()
        params.set("page", String(speakersPage))
        params.set("limit", String(limit))
        if (minFollowers) {
          params.set("min_followers", minFollowers)
        }
        const res = await fetch(`/api/lurky/speakers?${params.toString()}`)
        const data = await res.json()
        setSpeakers(data.speakers || [])
      } catch (err) {
        console.error("Failed to load speakers:", err)
      } finally {
        setSpeakersLoading(false)
      }
    }
    loadSpeakers()
  }, [speakersPage, minFollowers])

  // Filter spaces by search query
  const filteredSpaces = useMemo(() => {
    if (!spacesQuery.trim()) return spaces
    const q = spacesQuery.toLowerCase()
    return spaces.filter(
      (s) =>
        s.title?.toLowerCase().includes(q) ||
        s.creator_username?.toLowerCase().includes(q) ||
        s.creator_handle?.toLowerCase().includes(q),
    )
  }, [spaces, spacesQuery])

  return (
    <div className="container mx-auto px-4 py-12 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Lurky Analytics</h1>
        <p className="text-muted-foreground">
          Multi-panel intelligence view for 789Studios: Spaces, coin sentiment, and speakers
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Panel 1: Spaces */}
        <Card className="p-4 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Radio className="h-5 w-5 text-pink-400" />
                Spaces
              </h2>
              <p className="text-xs text-muted-foreground">Filter by state and search</p>
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <Select
              value={spacesState}
              onValueChange={(v) => {
                setSpacesPage(0)
                setSpacesState(v)
              }}
            >
              <SelectTrigger className="h-8 text-xs">
                <Filter className="h-3 w-3 mr-1" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="analyzed">Analyzed</SelectItem>
                <SelectItem value="live">Live</SelectItem>
                <SelectItem value="scheduled">Scheduled</SelectItem>
                <SelectItem value="ended">Ended</SelectItem>
              </SelectContent>
            </Select>

            <div className="relative">
              <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground" />
              <Input
                placeholder="Search spaces..."
                value={spacesQuery}
                onChange={(e) => setSpacesQuery(e.target.value)}
                className="pl-7 h-8 text-xs"
              />
            </div>
          </div>

          {spacesLoading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
            </div>
          ) : (
            <>
              <div className="space-y-2 max-h-80 overflow-y-auto">
                {filteredSpaces.map((space) => (
                  <div
                    key={space.id}
                    className="border border-border rounded-lg p-3 text-xs hover:border-primary/50 transition-colors"
                  >
                    <div className="flex justify-between items-start gap-2 mb-1">
                      <h3 className="font-medium line-clamp-2">{space.title || "(no title)"}</h3>
                      <span
                        className={`shrink-0 px-1.5 py-0.5 rounded text-[10px] ${
                          space.state === "live"
                            ? "bg-green-500/10 text-green-400"
                            : space.state === "scheduled"
                              ? "bg-blue-500/10 text-blue-400"
                              : "bg-pink-500/10 text-pink-400"
                        }`}
                      >
                        {space.state}
                      </span>
                    </div>
                    <div className="flex justify-between text-muted-foreground">
                      <span>@{space.creator_username || space.creator_handle || "unknown"}</span>
                      {space.started_at && <span>{new Date(space.started_at).toLocaleDateString()}</span>}
                    </div>
                  </div>
                ))}
                {!filteredSpaces.length && (
                  <p className="text-xs text-muted-foreground text-center py-4">No spaces found</p>
                )}
              </div>

              <div className="flex justify-between items-center pt-2 border-t">
                <Button
                  variant="outline"
                  size="sm"
                  className="h-7 text-xs bg-transparent"
                  disabled={spacesPage === 0}
                  onClick={() => setSpacesPage((p) => Math.max(0, p - 1))}
                >
                  Prev
                </Button>
                <span className="text-xs text-muted-foreground">Page {spacesPage + 1}</span>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-7 text-xs bg-transparent"
                  onClick={() => setSpacesPage((p) => p + 1)}
                >
                  Next
                </Button>
              </div>
            </>
          )}
        </Card>

        <Card className="p-4 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Coins className="h-5 w-5 text-amber-400" />
                Coin Sentiment Radar
              </h2>
              <p className="text-xs text-muted-foreground">Coins mentioned in Spaces</p>
            </div>
            <Select
              value={coinsSortBy}
              onValueChange={(v) => {
                setCoinsPage(0)
                setCoinsSortBy(v as "mentions" | "market_cap")
              }}
            >
              <SelectTrigger className="h-7 w-28 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="mentions">Mentions</SelectItem>
                <SelectItem value="market_cap">Market Cap</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {coinsLoading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-amber-400" />
            </div>
          ) : (
            <>
              <div className="space-y-2 max-h-80 overflow-y-auto">
                {coins.map((coin) => {
                  const mentions = coin.mentions ??
                    coin.mentionStats ?? { total: 0, bullish: 0, neutral: 0, bearish: 0 }
                  const total = mentions.total || mentions.bullish + mentions.neutral + mentions.bearish || 0
                  const { bullish = 0, neutral = 0, bearish = 0 } = mentions

                  return (
                    <div
                      key={coin.id ?? coin.symbol}
                      className="border border-border rounded-lg p-3 text-xs hover:border-amber-400/50 transition-colors"
                    >
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2">
                          {coin.image && (
                            <img
                              src={coin.image || "/placeholder.svg"}
                              alt={coin.symbol}
                              className="w-6 h-6 rounded-full"
                            />
                          )}
                          <div>
                            <div className="font-medium">{coin.name}</div>
                            <div className="text-[10px] text-muted-foreground">
                              {coin.symbol} · Rank {coin.marketCapRank ?? "–"}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-medium">${Number(coin.priceUsd ?? coin.price ?? 0).toFixed(4)}</div>
                          {coin.priceChange24h != null && (
                            <div
                              className={`text-[10px] flex items-center justify-end gap-0.5 ${
                                coin.priceChange24h >= 0 ? "text-emerald-400" : "text-red-400"
                              }`}
                            >
                              {coin.priceChange24h >= 0 ? (
                                <TrendingUp className="h-3 w-3" />
                              ) : (
                                <TrendingDown className="h-3 w-3" />
                              )}
                              {coin.priceChange24h.toFixed(2)}%
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Sentiment bar */}
                      <div>
                        <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
                          <span>Sentiment</span>
                          <span>{total} mentions</span>
                        </div>
                        <div className="h-2 w-full bg-muted rounded-full overflow-hidden flex">
                          <div
                            style={{ width: total > 0 ? `${(bullish / total) * 100}%` : "0%" }}
                            className="h-full bg-emerald-500"
                          />
                          <div
                            style={{ width: total > 0 ? `${(neutral / total) * 100}%` : "0%" }}
                            className="h-full bg-neutral-500"
                          />
                          <div
                            style={{ width: total > 0 ? `${(bearish / total) * 100}%` : "0%" }}
                            className="h-full bg-red-500"
                          />
                        </div>
                        <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                          <span className="text-emerald-400">Bull {bullish}</span>
                          <span>Neu {neutral}</span>
                          <span className="text-red-400">Bear {bearish}</span>
                        </div>
                      </div>
                    </div>
                  )
                })}
                {!coins.length && (
                  <p className="text-xs text-muted-foreground text-center py-4">No coins with mentions</p>
                )}
              </div>

              <div className="flex justify-between items-center pt-2 border-t">
                <Button
                  variant="outline"
                  size="sm"
                  className="h-7 text-xs bg-transparent"
                  disabled={coinsPage === 0}
                  onClick={() => setCoinsPage((p) => Math.max(0, p - 1))}
                >
                  Prev
                </Button>
                <span className="text-xs text-muted-foreground">Page {coinsPage + 1}</span>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-7 text-xs bg-transparent"
                  onClick={() => setCoinsPage((p) => p + 1)}
                >
                  Next
                </Button>
              </div>
            </>
          )}
        </Card>

        <Card className="p-4 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Users className="h-5 w-5 text-sky-400" />
                Speakers
              </h2>
              <p className="text-xs text-muted-foreground">Top X accounts in Spaces</p>
            </div>
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <span>Min</span>
              <Input
                type="number"
                className="w-20 h-7 text-xs"
                value={minFollowers}
                onChange={(e) => {
                  setSpeakersPage(0)
                  setMinFollowers(e.target.value)
                }}
                placeholder="5000"
              />
            </div>
          </div>

          {speakersLoading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sky-400" />
            </div>
          ) : (
            <>
              <div className="space-y-2 max-h-80 overflow-y-auto">
                {speakers.map((speaker) => (
                  <div
                    key={speaker.twitterId ?? speaker.id}
                    className="border border-border rounded-lg p-3 text-xs flex items-center gap-3 hover:border-sky-400/50 transition-colors"
                  >
                    {speaker.image ? (
                      <img
                        src={speaker.image || "/placeholder.svg"}
                        alt={speaker.handle}
                        className="w-10 h-10 rounded-full"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                        <Users className="h-5 w-5 text-muted-foreground" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1">
                        <span className="font-medium truncate">{speaker.name ?? speaker.handle}</span>
                        {speaker.verified && (
                          <span className="text-sky-400 text-[10px]">
                            {speaker.verifiedType === "business" ? "✓ Biz" : "✓"}
                          </span>
                        )}
                      </div>
                      <div className="text-muted-foreground">@{speaker.handle}</div>
                    </div>
                    <div className="text-right text-muted-foreground">
                      {speaker.followersCount != null && <div>{speaker.followersCount.toLocaleString()}</div>}
                      <div className="text-[10px]">followers</div>
                    </div>
                  </div>
                ))}
                {!speakers.length && (
                  <p className="text-xs text-muted-foreground text-center py-4">No speakers found</p>
                )}
              </div>

              <div className="flex justify-between items-center pt-2 border-t">
                <Button
                  variant="outline"
                  size="sm"
                  className="h-7 text-xs bg-transparent"
                  disabled={speakersPage === 0}
                  onClick={() => setSpeakersPage((p) => Math.max(0, p - 1))}
                >
                  Prev
                </Button>
                <span className="text-xs text-muted-foreground">Page {speakersPage + 1}</span>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-7 text-xs bg-transparent"
                  onClick={() => setSpeakersPage((p) => p + 1)}
                >
                  Next
                </Button>
              </div>
            </>
          )}
        </Card>
      </div>
    </div>
  )
}
