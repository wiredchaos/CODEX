import { CinematicHeader } from "@/components/akashic/cinematic-header"
import { SAMPLE_PUBLICATIONS, SAMPLE_SEEDS } from "@/config/story-engine"
import { notFound } from "next/navigation"
import Link from "next/link"

export default async function BookPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const publication = SAMPLE_PUBLICATIONS.find((p) => p.book_slug === slug)

  if (!publication) {
    notFound()
  }

  const seed = SAMPLE_SEEDS[0] // In real app, fetch by novella_id

  return (
    <div className="min-h-screen bg-black">
      {/* Film overlays */}
      <div className="fixed inset-0 pointer-events-none z-50 bg-[url('/textures/scanlines.png')] opacity-5" />

      <div className="relative z-10">
        <CinematicHeader
          title={seed.title.toUpperCase()}
          subtitle="A WIRED CHAOS META Publication"
          classification="CREATOR CODEX // PUBLISHED"
        />

        <main className="max-w-4xl mx-auto px-6 py-12">
          {/* Book Cover Placeholder */}
          <div className="aspect-[2/3] max-w-sm mx-auto mb-12 border border-cyan-500/30 rounded-lg bg-gradient-to-b from-cyan-500/10 to-fuchsia-500/10 flex items-center justify-center">
            <div className="text-center p-8">
              <div className="text-6xl font-bold text-cyan-400 mb-4 glitch" data-text={seed.title[0]}>
                {seed.title[0]}
              </div>
              <h3 className="text-xl font-mono text-zinc-200">{seed.title}</h3>
              <p className="text-sm text-zinc-500 mt-2">{seed.genre}</p>
            </div>
          </div>

          {/* Book Details */}
          <div className="space-y-8">
            <div className="text-center">
              <p className="text-zinc-400 max-w-2xl mx-auto">{seed.longDescription || seed.world_context.setting}</p>
            </div>

            {/* Metadata */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div className="p-4 border border-zinc-800 rounded-lg text-center">
                <div className="text-zinc-500 mb-1">Genre</div>
                <div className="text-cyan-400 capitalize">{seed.genre}</div>
              </div>
              <div className="p-4 border border-zinc-800 rounded-lg text-center">
                <div className="text-zinc-500 mb-1">Tone</div>
                <div className="text-amber-400 capitalize">{seed.tone}</div>
              </div>
              <div className="p-4 border border-zinc-800 rounded-lg text-center">
                <div className="text-zinc-500 mb-1">Price</div>
                <div className="text-emerald-400">${publication.price}</div>
              </div>
              <div className="p-4 border border-zinc-800 rounded-lg text-center">
                <div className="text-zinc-500 mb-1">Status</div>
                <div className="text-green-400 uppercase">{publication.kdp_status}</div>
              </div>
            </div>

            {/* Characters */}
            <div>
              <h3 className="text-xs uppercase tracking-widest text-red-500 mb-4">Characters</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {seed.characters.map((char, i) => (
                  <div key={i} className="p-4 border border-zinc-800 rounded-lg bg-zinc-900/50">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-cyan-400 font-mono">{char.name}</span>
                      <span className="text-xs text-zinc-600">—</span>
                      <span className="text-xs text-zinc-500">{char.archetype}</span>
                    </div>
                    <div className="flex flex-wrap gap-1 mb-2">
                      {char.traits.map((trait) => (
                        <span key={trait} className="px-2 py-0.5 text-xs bg-zinc-800 text-zinc-400 rounded">
                          {trait}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* CTA */}
            <div className="flex justify-center gap-4">
              <Link
                href={`https://amazon.com/dp/${publication.asin}`}
                target="_blank"
                className="px-6 py-3 bg-cyan-500 text-black font-mono text-sm hover:bg-cyan-400 transition-colors rounded"
              >
                BUY ON KINDLE
              </Link>
              <Link
                href={`/presskit/${slug}`}
                className="px-6 py-3 border border-cyan-500/50 text-cyan-400 font-mono text-sm hover:bg-cyan-500/10 transition-colors rounded"
              >
                PRESS KIT
              </Link>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
