import Link from "next/link"
import { Card } from "@/components/ui/card"

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-12">
      {/* Header */}
      <div className="text-center mb-12">
        <h1 className="text-5xl sm:text-6xl font-bold tracking-tight mb-3">
          <span className="neon-text-cyan">WIRED CHAOS OS</span>
        </h1>
        <p className="text-lg text-muted-foreground">Multi-Agent Intelligence System</p>
        <p className="text-sm text-muted-foreground/70 mt-2">Answer + 3D Video + Avatar System</p>
      </div>

      <div className="w-full max-w-5xl mb-8">
        <Link href="/pos" className="group block">
          <div className="relative overflow-hidden rounded-xl border border-red-500/40 hover:border-red-500/70 bg-gradient-to-r from-red-950/30 via-black to-red-950/30 p-6 transition-all duration-300 hover:shadow-[0_0_40px_rgba(255,0,0,0.15)]">
            <div className="absolute top-2 right-2 px-2 py-0.5 bg-red-500/20 rounded text-xs text-red-400 font-mono">
              LIVE
            </div>
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold text-red-400 mb-1">POS // PROOF OF STREAM</h3>
                <p className="text-sm text-muted-foreground">BWB News Network • 33.3FM Radio • Signal Chain Audio</p>
              </div>
              <div className="w-12 h-12 rounded-full bg-red-500/20 flex items-center justify-center group-hover:bg-red-500/30 transition-colors">
                <svg className="w-6 h-6 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={1.5}
                    d="M5.636 18.364a9 9 0 010-12.728m12.728 0a9 9 0 010 12.728m-9.9-2.829a5 5 0 010-7.07m7.072 0a5 5 0 010 7.07M13 12a1 1 0 11-2 0 1 1 0 012 0z"
                  />
                </svg>
              </div>
            </div>
          </div>
        </Link>
      </div>

      {/* Patch Selector */}
      <div className="w-full max-w-5xl mb-12">
        <div className="text-center mb-8">
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-2">SELECT YOUR PATCH</h2>
          <p className="text-muted-foreground">Choose your operational mode</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Business Patch */}
          <Link
            href="/business"
            className="group relative p-8 rounded-xl border border-primary/30 bg-card/50 hover:border-primary/60 hover:bg-primary/5 transition-all duration-300"
          >
            {/* Glowing Orb */}
            <div className="flex justify-center mb-6">
              <div className="relative">
                <div className="w-24 h-24 rounded-full bg-primary/80 group-hover:bg-primary transition-colors duration-300" />
                <div className="absolute inset-0 w-24 h-24 rounded-full bg-primary/40 blur-xl group-hover:bg-primary/60 transition-all duration-300" />
              </div>
            </div>

            <h3 className="text-xl sm:text-2xl font-bold text-primary text-center mb-4">BUSINESS PATCH</h3>

            <p className="text-center text-muted-foreground mb-6">
              Strategic operations. Professional workflows. Business intelligence systems.
            </p>

            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-center gap-2">
                <span className="text-muted-foreground">•</span>
                <span>Universal Funnel Engine</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-muted-foreground">•</span>
                <span>Tax Suite Intelligence</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-muted-foreground">•</span>
                <span>Marketing Swarm</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-muted-foreground">•</span>
                <span>Creator Codex</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-muted-foreground">•</span>
                <span>Business Ascent School</span>
              </li>
            </ul>
          </Link>

          {/* Rogue Frequency Patch */}
          <Link
            href="/rogue-frequency"
            className="group relative p-8 rounded-xl border border-accent/30 bg-card/50 hover:border-accent/60 hover:bg-accent/5 transition-all duration-300"
          >
            {/* Glowing Orb */}
            <div className="flex justify-center mb-6">
              <div className="relative">
                <div className="w-24 h-24 rounded-full bg-accent/80 group-hover:bg-accent transition-colors duration-300" />
                <div className="absolute inset-0 w-24 h-24 rounded-full bg-accent/40 blur-xl group-hover:bg-accent/60 transition-all duration-300" />
              </div>
            </div>

            <h3 className="text-xl sm:text-2xl font-bold text-accent text-center mb-4">ROGUE FREQUENCY PATCH</h3>

            <p className="text-center text-muted-foreground mb-6">
              Shadow operations. Signal intelligence. Frequency warfare training.
            </p>

            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2">
                <span className="text-accent">•</span>
                <span className="text-accent">10 Signal Levels</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-accent">•</span>
                <span className="text-accent">Cryptic Intelligence Drops</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-accent">•</span>
                <span className="text-accent">Spectral Clearance</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-accent">•</span>
                <span className="text-accent">Shadow Current Training</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-accent">•</span>
                <span className="text-accent">Sovereign Protocol</span>
              </li>
            </ul>
          </Link>
        </div>
      </div>

      <div className="w-full max-w-5xl mb-12">
        <div className="text-center mb-6">
          <h2 className="text-xl font-bold tracking-tight mb-2">ENTERPRISE SYSTEMS</h2>
          <p className="text-sm text-muted-foreground">Advanced business intelligence and swarm agents</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Link href="/credit-repair">
            <Card className="p-4 border-emerald-500/30 hover:border-emerald-500/60 bg-emerald-500/5 hover:bg-emerald-500/10 transition-all cursor-pointer group h-full">
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto mb-3 group-hover:bg-emerald-500/30 transition-colors">
                  <svg className="w-6 h-6 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                    />
                  </svg>
                </div>
                <h3 className="font-bold text-sm mb-1 text-emerald-400">Credit Repair Swarm</h3>
                <p className="text-xs text-muted-foreground">DIY + DFY + Bootcamp</p>
              </div>
            </Card>
          </Link>

          <Link href="/business/igs">
            <Card className="p-4 border-blue-500/30 hover:border-blue-500/60 bg-blue-500/5 hover:bg-blue-500/10 transition-all cursor-pointer group h-full">
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-blue-500/20 flex items-center justify-center mx-auto mb-3 group-hover:bg-blue-500/30 transition-colors">
                  <svg className="w-6 h-6 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"
                    />
                  </svg>
                </div>
                <h3 className="font-bold text-sm mb-1 text-blue-400">Industry Generals</h3>
                <p className="text-xs text-muted-foreground">33 SME Agents</p>
              </div>
            </Card>
          </Link>

          <Link href="/agentic">
            <Card className="p-4 border-purple-500/30 hover:border-purple-500/60 bg-purple-500/5 hover:bg-purple-500/10 transition-all cursor-pointer group h-full">
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-purple-500/20 flex items-center justify-center mx-auto mb-3 group-hover:bg-purple-500/30 transition-colors">
                  <svg className="w-6 h-6 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                    />
                  </svg>
                </div>
                <h3 className="font-bold text-sm mb-1 text-purple-400">Agentic Command</h3>
                <p className="text-xs text-muted-foreground">Constitutional AI</p>
              </div>
            </Card>
          </Link>

          <Link href="/edu">
            <Card className="p-4 border-amber-500/30 hover:border-amber-500/60 bg-amber-500/5 hover:bg-amber-500/10 transition-all cursor-pointer group h-full">
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-amber-500/20 flex items-center justify-center mx-auto mb-3 group-hover:bg-amber-500/30 transition-colors">
                  <svg className="w-6 h-6 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
                    />
                  </svg>
                </div>
                <h3 className="font-bold text-sm mb-1 text-amber-400">EDU Import Protocol</h3>
                <p className="text-xs text-muted-foreground">9 Pillars + 22 Swarms</p>
              </div>
            </Card>
          </Link>
        </div>
      </div>

      <div className="w-full max-w-5xl mb-12">
        <div className="text-center mb-6">
          <h2 className="text-xl font-bold tracking-tight mb-2">BROADCAST & MEDIA</h2>
          <p className="text-sm text-muted-foreground">POS Network • BWB News • 33.3FM Radio</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Link href="/pos/bwb">
            <Card className="p-4 border-red-500/30 hover:border-red-500/60 bg-red-500/5 hover:bg-red-500/10 transition-all cursor-pointer group h-full">
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-red-500/20 flex items-center justify-center mx-auto mb-3 group-hover:bg-red-500/30 transition-colors">
                  <svg className="w-6 h-6 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"
                    />
                  </svg>
                </div>
                <h3 className="font-bold text-sm mb-1 text-red-400">BWB News</h3>
                <p className="text-xs text-muted-foreground">Barbed Wire Broadcast</p>
              </div>
            </Card>
          </Link>

          <Link href="/33fm">
            <Card className="p-4 border-pink-500/30 hover:border-pink-500/60 bg-pink-500/5 hover:bg-pink-500/10 transition-all cursor-pointer group h-full">
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-pink-500/20 flex items-center justify-center mx-auto mb-3 group-hover:bg-pink-500/30 transition-colors">
                  <svg className="w-6 h-6 text-pink-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3"
                    />
                  </svg>
                </div>
                <h3 className="font-bold text-sm mb-1 text-pink-400">33.3FM Radio</h3>
                <p className="text-xs text-muted-foreground">DJ Red Fang + Chrome Fang</p>
              </div>
            </Card>
          </Link>

          <Link href="/broadcast/live">
            <Card className="p-4 border-cyan-500/30 hover:border-cyan-500/60 bg-cyan-500/5 hover:bg-cyan-500/10 transition-all cursor-pointer group h-full">
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-cyan-500/20 flex items-center justify-center mx-auto mb-3 group-hover:bg-cyan-500/30 transition-colors">
                  <svg className="w-6 h-6 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"
                    />
                  </svg>
                </div>
                <h3 className="font-bold text-sm mb-1 text-cyan-400">Avatar Live v33</h3>
                <p className="text-xs text-muted-foreground">Broadcast Control</p>
              </div>
            </Card>
          </Link>

          <Link href="/video">
            <Card className="p-4 border-orange-500/30 hover:border-orange-500/60 bg-orange-500/5 hover:bg-orange-500/10 transition-all cursor-pointer group h-full">
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-orange-500/20 flex items-center justify-center mx-auto mb-3 group-hover:bg-orange-500/30 transition-colors">
                  <svg className="w-6 h-6 text-orange-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4M4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z"
                    />
                  </svg>
                </div>
                <h3 className="font-bold text-sm mb-1 text-orange-400">Video Prompts</h3>
                <p className="text-xs text-muted-foreground">Generator Library</p>
              </div>
            </Card>
          </Link>
        </div>
      </div>

      {/* Gallery CTA */}
      <div className="w-full max-w-5xl mb-12">
        <Link href="/gallery" className="group block">
          <div className="relative overflow-hidden rounded-xl border border-cyan-500/30 hover:border-cyan-500/60 bg-gradient-to-r from-cyan-500/5 via-transparent to-red-500/5 p-6 transition-all duration-300 hover:shadow-[0_0_40px_rgba(0,255,255,0.1)]">
            {/* Scanline effect */}
            <div className="absolute inset-0 pointer-events-none bg-[repeating-linear-gradient(0deg,transparent,transparent_2px,rgba(0,255,255,0.02)_2px,rgba(0,255,255,0.02)_4px)] opacity-0 group-hover:opacity-100 transition-opacity" />

            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold text-cyan-400 mb-1">NEURO PHOTO GALLERY</h3>
                <p className="text-sm text-muted-foreground">
                  Explore avatar portraits and character visuals across AKASHIC and CORPORATE modes
                </p>
              </div>
              <div className="w-12 h-12 rounded-full bg-cyan-500/20 flex items-center justify-center group-hover:bg-cyan-500/30 transition-colors">
                <svg className="w-6 h-6 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={1.5}
                    d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                  />
                </svg>
              </div>
            </div>
          </div>
        </Link>
      </div>

      {/* Core Systems */}
      <div className="w-full max-w-4xl mb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Link href="/npc/console">
            <Card className="p-6 border-cyan-500/30 hover:border-cyan-500/60 bg-cyan-500/5 hover:bg-cyan-500/10 transition-all cursor-pointer group h-full">
              <div className="text-center">
                <div className="text-4xl mb-3">💬</div>
                <h3 className="font-bold text-lg mb-2 text-cyan-400">NPC Console</h3>
                <p className="text-xs text-muted-foreground">Interactive Answer + Video</p>
              </div>
            </Card>
          </Link>

          <Link href="/akira/story-engine">
            <Card className="p-6 border-pink-500/30 hover:border-pink-500/60 bg-pink-500/5 hover:bg-pink-500/10 transition-all cursor-pointer group h-full">
              <div className="text-center">
                <div className="text-4xl mb-3">📖</div>
                <h3 className="font-bold text-lg mb-2 text-pink-400">Akira Story Engine</h3>
                <p className="text-xs text-muted-foreground">Seed → Expand → Publish</p>
              </div>
            </Card>
          </Link>

          <Link href="/bookstore">
            <Card className="p-6 border-purple-500/30 hover:border-purple-500/60 bg-purple-500/5 hover:bg-purple-500/10 transition-all cursor-pointer group h-full">
              <div className="text-center">
                <div className="text-4xl mb-3">📚</div>
                <h3 className="font-bold text-lg mb-2 text-purple-400">Creator Codex Bookstore</h3>
                <p className="text-xs text-muted-foreground">Published works</p>
              </div>
            </Card>
          </Link>

          <Link href="/business/meetings">
            <Card className="p-6 border-amber-500/30 hover:border-amber-500/60 bg-amber-500/5 hover:bg-amber-500/10 transition-all cursor-pointer group h-full">
              <div className="text-center">
                <div className="text-4xl mb-3">🏢</div>
                <h3 className="font-bold text-lg mb-2 text-amber-400">Business 3D Meetings</h3>
                <p className="text-xs text-muted-foreground">Environment dashboard</p>
              </div>
            </Card>
          </Link>
        </div>
      </div>

      {/* Core Systems */}
      <div className="w-full max-w-5xl mb-12">
        <div className="text-center mb-6">
          <h2 className="text-xl font-bold tracking-tight mb-2">CORE SYSTEMS</h2>
          <p className="text-sm text-muted-foreground">Multi-agent intelligence infrastructure</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Link href="/video-engine">
            <Card className="p-4 border-cyan-500/30 hover:border-cyan-500/60 bg-cyan-500/5 hover:bg-cyan-500/10 transition-all cursor-pointer group h-full">
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-cyan-500/20 flex items-center justify-center mx-auto mb-3 group-hover:bg-cyan-500/30 transition-colors">
                  <svg className="w-6 h-6 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"
                    />
                  </svg>
                </div>
                <h3 className="font-bold text-sm mb-1 text-cyan-400">Answer + Video Engine</h3>
                <p className="text-xs text-muted-foreground">Text + 3D cinematic output</p>
              </div>
            </Card>
          </Link>

          <Link href="/story-engine">
            <Card className="p-4 border-pink-500/30 hover:border-pink-500/60 bg-pink-500/5 hover:bg-pink-500/10 transition-all cursor-pointer group h-full">
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-pink-500/20 flex items-center justify-center mx-auto mb-3 group-hover:bg-pink-500/30 transition-colors">
                  <svg className="w-6 h-6 text-pink-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
                    />
                  </svg>
                </div>
                <h3 className="font-bold text-sm mb-1 text-pink-400">Story Engine</h3>
                <p className="text-xs text-muted-foreground">AKIRA-CREATOR pipeline</p>
              </div>
            </Card>
          </Link>

          <Link href="/npc">
            <Card className="p-4 border-emerald-500/30 hover:border-emerald-500/60 bg-emerald-500/5 hover:bg-emerald-500/10 transition-all cursor-pointer group h-full">
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto mb-3 group-hover:bg-emerald-500/30 transition-colors">
                  <svg className="w-6 h-6 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                    />
                  </svg>
                </div>
                <h3 className="font-bold text-sm mb-1 text-emerald-400">NPC Interface</h3>
                <p className="text-xs text-muted-foreground">Interactive agent layer</p>
              </div>
            </Card>
          </Link>

          <Link href="/avatar-advancement">
            <Card className="p-4 border-amber-500/30 hover:border-amber-500/60 bg-amber-500/5 hover:bg-amber-500/10 transition-all cursor-pointer group h-full">
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-amber-500/20 flex items-center justify-center mx-auto mb-3 group-hover:bg-amber-500/30 transition-colors">
                  <svg className="w-6 h-6 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M13 10V3L4 14h7v7l9-11h-7z"
                    />
                  </svg>
                </div>
                <h3 className="font-bold text-sm mb-1 text-amber-400">Avatar Advancement</h3>
                <p className="text-xs text-muted-foreground">Tier progression system</p>
              </div>
            </Card>
          </Link>
        </div>
      </div>

      {/* System Archives */}
      <div className="w-full max-w-5xl">
        <div className="text-center mb-6">
          <h2 className="text-xl font-bold tracking-tight mb-2">SYSTEM ARCHIVES</h2>
          <p className="text-sm text-muted-foreground">Access canonical lore and operational history</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Link href="/lore-dictionary">
            <Card className="p-4 border-cyan-500/20 hover:border-cyan-500/40 transition-all cursor-pointer group">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-cyan-500/10 flex items-center justify-center group-hover:bg-cyan-500/20 transition-colors">
                  <span className="text-cyan-400 text-lg">📖</span>
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-sm mb-0.5 text-cyan-400">Lore Dictionary</h3>
                  <p className="text-xs text-muted-foreground">ARG-safe mappings</p>
                </div>
              </div>
            </Card>
          </Link>

          <Link href="/black-ledger">
            <Card className="p-4 border-red-500/20 hover:border-red-500/40 transition-all cursor-pointer group">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center group-hover:bg-red-500/20 transition-colors">
                  <span className="text-red-400 text-lg">📅</span>
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-sm mb-0.5 text-red-400">Black Ledger Year</h3>
                  <p className="text-xs text-muted-foreground">Cycle 2025.X timeline</p>
                </div>
              </div>
            </Card>
          </Link>

          <Link href="/motherboard">
            <Card className="p-4 border-purple-500/20 hover:border-purple-500/40 transition-all cursor-pointer group">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center group-hover:bg-purple-500/20 transition-colors">
                  <span className="text-purple-400 text-lg">🔮</span>
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-sm mb-0.5 text-purple-400">Akashic Motherboard</h3>
                  <p className="text-xs text-muted-foreground">University network</p>
                </div>
              </div>
            </Card>
          </Link>
        </div>
      </div>
    </div>
  )
}
