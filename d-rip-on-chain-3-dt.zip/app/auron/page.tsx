"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AuronTag, AuronBadge, AuronSeq, AuronFactionCard, AuronLedgerButtons } from "@/components/auron"
import { CORE_FACTIONS, LORE_DICTIONARY } from "@/config/lore-canon"
import { getEventsByFaction } from "@/config/black-ledger-year"

export default function AuronPactPage() {
  const [activeFaction, setActiveFaction] = useState<string>("auron_pact")

  const auronPact = CORE_FACTIONS.find((f) => f.id === "auron_pact")
  const auronLore = LORE_DICTIONARY.find((e) => e.id === "auron_pact")
  const auronEvents = getEventsByFaction("auron_pact")

  return (
    <div className="min-h-screen bg-black">
      {/* Hero */}
      <div className="relative border-b border-cyan-500/20">
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 via-transparent to-red-500/5" />
        <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-10" />

        <div className="container mx-auto px-4 py-20 relative">
          <div className="max-w-3xl">
            <AuronSeq classification="AURON" className="mb-4">
              Event File: AUR-33
            </AuronSeq>

            <h1 className="text-5xl md:text-6xl font-bold text-white mb-4 tracking-tight">
              THE <span className="text-[#00FFFF]">AURON</span> PACT
            </h1>

            <p className="text-xl text-zinc-400 mb-6">
              A covert alliance formed to stabilize Layer-1 consensus after the Oracle Wars. Instead of stabilizing the
              chain, the Pact fractured internally.
            </p>

            <div className="flex flex-wrap gap-2 mb-8">
              <AuronBadge color="cyan">Data Clarity</AuronBadge>
              <AuronBadge color="red">System Breach</AuronBadge>
              <AuronBadge color="green">Signal Chain Active</AuronBadge>
            </div>

            <p className="text-sm text-zinc-500 font-mono">"News That Cuts Through the Noise." — AURON DIRECTIVE</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <Tabs defaultValue="overview" className="space-y-8">
          <TabsList className="bg-black/60 border border-cyan-500/20">
            <TabsTrigger
              value="overview"
              className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
            >
              Overview
            </TabsTrigger>
            <TabsTrigger
              value="factions"
              className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
            >
              Factions
            </TabsTrigger>
            <TabsTrigger
              value="timeline"
              className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
            >
              Timeline
            </TabsTrigger>
            <TabsTrigger
              value="components"
              className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
            >
              UI Components
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-8">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-black/60 border-cyan-500/20 p-6">
                <h3 className="text-lg font-bold text-cyan-400 mb-4">AURON PACT LORE</h3>
                {auronLore && (
                  <div className="space-y-4">
                    <p className="text-zinc-300">{auronLore.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {auronLore.aliases?.map((alias) => (
                        <AuronTag key={alias}>{alias}</AuronTag>
                      ))}
                    </div>
                  </div>
                )}
              </Card>

              <Card className="bg-black/60 border-red-500/20 p-6">
                <h3 className="text-lg font-bold text-red-400 mb-4">INVESTIGATION VECTORS</h3>
                <ul className="space-y-3">
                  <li className="flex items-start gap-2 text-zinc-400 text-sm">
                    <span className="text-red-500">?</span>
                    What ignited the Oracle Wars?
                  </li>
                  <li className="flex items-start gap-2 text-zinc-400 text-sm">
                    <span className="text-red-500">?</span>
                    Why did the Auron Pact destabilize immediately?
                  </li>
                  <li className="flex items-start gap-2 text-zinc-400 text-sm">
                    <span className="text-red-500">?</span>
                    Who regulates the GMX Protocol breach vector?
                  </li>
                </ul>
              </Card>
            </div>

            {/* Faction Selector */}
            <div>
              <h3 className="text-lg font-bold text-white mb-4">LEDGER FACTIONS</h3>
              <AuronLedgerButtons
                buttons={[
                  { id: "auron_pact", label: "Auron Directive" },
                  { id: "etherion_assembly", label: "The Etherion Assembly" },
                  { id: "undernet_syndicates", label: "The Undernet Syndicates" },
                ]}
                activeId={activeFaction}
                onSelect={setActiveFaction}
              />
            </div>
          </TabsContent>

          {/* Factions Tab */}
          <TabsContent value="factions" className="space-y-6">
            <h3 className="text-lg font-bold text-white">CORE FACTIONS</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {CORE_FACTIONS.map((faction) => (
                <AuronFactionCard
                  key={faction.id}
                  name={faction.name}
                  description={faction.description}
                  role={faction.role}
                  color={faction.color}
                  connectedPatches={faction.connectedPatches}
                  isActive={faction.id === "auron_pact"}
                />
              ))}
            </div>
          </TabsContent>

          {/* Timeline Tab */}
          <TabsContent value="timeline" className="space-y-6">
            <h3 className="text-lg font-bold text-white">AURON PACT EVENTS</h3>
            <div className="space-y-4">
              {auronEvents.map((event) => (
                <Card key={event.month} className="bg-black/60 border-cyan-500/20 p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <AuronTag variant="event">{event.month}</AuronTag>
                      <h4 className="text-white font-bold mt-2">{event.title}</h4>
                    </div>
                    {event.losses && (
                      <Badge variant="outline" className="border-red-500/30 text-red-400">
                        {event.losses}
                      </Badge>
                    )}
                  </div>
                  <p className="text-zinc-400 text-sm">{event.description}</p>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Components Tab */}
          <TabsContent value="components" className="space-y-8">
            <h3 className="text-lg font-bold text-white">UI COMPONENT LIBRARY</h3>

            {/* Tags */}
            <Card className="bg-black/60 border-zinc-800 p-6">
              <h4 className="text-white font-mono text-sm mb-4">{"<AuronTag />"}</h4>
              <div className="flex flex-wrap gap-2">
                <AuronTag>Pact</AuronTag>
                <AuronTag variant="directive">Auron Directive</AuronTag>
                <AuronTag variant="signal">Signal Chain</AuronTag>
                <AuronTag variant="event">Event File</AuronTag>
              </div>
            </Card>

            {/* Badges */}
            <Card className="bg-black/60 border-zinc-800 p-6">
              <h4 className="text-white font-mono text-sm mb-4">{"<AuronBadge />"}</h4>
              <div className="flex flex-wrap gap-2">
                <AuronBadge color="cyan">Data Clarity</AuronBadge>
                <AuronBadge color="red">System Breach</AuronBadge>
                <AuronBadge color="green">Signal Active</AuronBadge>
                <AuronBadge color="black">Shadow Mode</AuronBadge>
                <AuronBadge color="cyan" pulse>
                  LIVE
                </AuronBadge>
              </div>
            </Card>

            {/* Sequences */}
            <Card className="bg-black/60 border-zinc-800 p-6">
              <h4 className="text-white font-mono text-sm mb-4">{"<AuronSeq />"}</h4>
              <div className="space-y-2">
                <AuronSeq classification="AURON">Event File: AUR-33</AuronSeq>
                <AuronSeq classification="VERIFIED">Transmission Confirmed</AuronSeq>
                <AuronSeq classification="CLASSIFIED">Level V Access Required</AuronSeq>
                <AuronSeq classification="REDACTED">Data Purged</AuronSeq>
              </div>
            </Card>

            {/* Color Palette */}
            <Card className="bg-black/60 border-zinc-800 p-6">
              <h4 className="text-white font-mono text-sm mb-4">AURON PALETTE</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="w-full h-16 rounded bg-[#00FFFF] mb-2" />
                  <p className="text-xs text-zinc-400 font-mono">#00FFFF</p>
                  <p className="text-xs text-zinc-500">Data Clarity</p>
                </div>
                <div className="text-center">
                  <div className="w-full h-16 rounded bg-[#FF3131] mb-2" />
                  <p className="text-xs text-zinc-400 font-mono">#FF3131</p>
                  <p className="text-xs text-zinc-500">System Breach</p>
                </div>
                <div className="text-center">
                  <div className="w-full h-16 rounded bg-[#39FF14] mb-2" />
                  <p className="text-xs text-zinc-400 font-mono">#39FF14</p>
                  <p className="text-xs text-zinc-500">Signal Chain</p>
                </div>
                <div className="text-center">
                  <div className="w-full h-16 rounded bg-[#0C0C0C] border border-zinc-700 mb-2" />
                  <p className="text-xs text-zinc-400 font-mono">#0C0C0C</p>
                  <p className="text-xs text-zinc-500">Auron Secrecy</p>
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Footer */}
      <div className="border-t border-cyan-500/20 py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-zinc-600 text-xs font-mono">
            AURON PACT v1.0 — WIRED CHAOS META LABS — ALL SYSTEMS NOMINAL
          </p>
        </div>
      </div>
    </div>
  )
}
