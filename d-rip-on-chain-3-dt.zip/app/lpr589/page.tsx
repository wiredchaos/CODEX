import { PATCHES } from "@/config/patches"
import { AkashicPageTemplate } from "@/components/patch/akashic-page-template"
import { notFound } from "next/navigation"

export default function LPR589Page() {
  const patch = PATCHES.find((p) => p.slug === "lpr589")
  if (!patch) notFound()
  return <AkashicPageTemplate patch={patch} />
}
