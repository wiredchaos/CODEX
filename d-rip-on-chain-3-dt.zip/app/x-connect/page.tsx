// app/x-connect/page.tsx
"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { CheckCircle2, XCircle, Twitter } from "lucide-react"

interface XProfile {
  id: string
  twitterId: string
  handle: string
  name: string
  avatarUrl?: string
  createdAt: string
}

export default function XConnectPage() {
  const searchParams = useSearchParams()
  const [profiles, setProfiles] = useState<XProfile[]>([])
  const [loading, setLoading] = useState(true)
  const success = searchParams.get("success")
  const error = searchParams.get("error")

  useEffect(() => {
    loadProfiles()
  }, [])

  const loadProfiles = async () => {
    try {
      const res = await fetch("/api/x/profiles")
      const data = await res.json()
      setProfiles(data.profiles || [])
    } catch (err) {
      console.error("Failed to load profiles:", err)
    } finally {
      setLoading(false)
    }
  }

  const handleConnect = () => {
    const clientId = process.env.NEXT_PUBLIC_X_CLIENT_ID
    const redirectUri = `${window.location.origin}/api/x/connect/callback`
    const scope = "tweet.read users.read offline.access"

    const authUrl = `https://twitter.com/i/oauth2/authorize?response_type=code&client_id=${clientId}&redirect_uri=${encodeURIComponent(redirectUri)}&scope=${encodeURIComponent(scope)}&state=789studios&code_challenge=challenge&code_challenge_method=plain`

    window.location.href = authUrl
  }

  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Connect X Account</h1>
        <p className="text-muted-foreground">
          Link your X (Twitter) accounts to enable Lurky analytics for 789 Studios
        </p>
      </div>

      {success && (
        <div className="mb-6 p-4 bg-green-500/10 border border-green-500/20 rounded-lg flex items-center gap-3">
          <CheckCircle2 className="h-5 w-5 text-green-500" />
          <p className="text-green-500">X account connected successfully!</p>
        </div>
      )}

      {error && (
        <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-lg flex items-center gap-3">
          <XCircle className="h-5 w-5 text-red-500" />
          <p className="text-red-500">Failed to connect X account. Please try again.</p>
        </div>
      )}

      <Card className="p-6 mb-8">
        <h2 className="text-xl font-semibold mb-4">Add New Account</h2>
        <Button onClick={handleConnect} className="gap-2">
          <Twitter className="h-4 w-4" />
          Connect X Account
        </Button>
      </Card>

      <div>
        <h2 className="text-xl font-semibold mb-4">Connected Accounts</h2>
        {loading ? (
          <p className="text-muted-foreground">Loading accounts...</p>
        ) : profiles.length === 0 ? (
          <p className="text-muted-foreground">No accounts connected yet.</p>
        ) : (
          <div className="grid gap-4">
            {profiles.map((profile) => (
              <Card key={profile.id} className="p-4 flex items-center gap-4">
                {profile.avatarUrl ? (
                  <img
                    src={profile.avatarUrl || "/placeholder.svg"}
                    alt={profile.name}
                    className="w-12 h-12 rounded-full"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center">
                    <Twitter className="h-6 w-6" />
                  </div>
                )}
                <div className="flex-1">
                  <h3 className="font-semibold">{profile.name}</h3>
                  <p className="text-sm text-muted-foreground">@{profile.handle}</p>
                </div>
                <div className="flex items-center gap-2 text-sm text-green-500">
                  <CheckCircle2 className="h-4 w-4" />
                  Connected
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
