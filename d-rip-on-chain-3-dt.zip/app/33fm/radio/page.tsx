"use client"

import { useEffect, useState } from "react"
import { Play, Pause, SkipForward, Volume2, RadioIcon, Users } from "lucide-react"

interface NowPlaying {
  track: {
    id: string
    title: string
    creatorHandle: string
    creatorName: string
    coverArtUrl: string
    duration: number
    currentTime: number
    genre: string
  }
  nextUp: Array<{
    id: string
    title: string
    creatorHandle: string
    duration: number
  }>
  listeners: number
  show: {
    title: string
    host: string
  }
}

export default function FM33RadioPage() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [nowPlaying, setNowPlaying] = useState<NowPlaying | null>(null)
  const [volume, setVolume] = useState(80)

  useEffect(() => {
    fetch("/api/33fm/now-playing")
      .then((r) => r.json())
      .then((data) => setNowPlaying(data))
      .catch(console.error)

    const interval = setInterval(() => {
      fetch("/api/33fm/now-playing")
        .then((r) => r.json())
        .then((data) => setNowPlaying(data))
        .catch(console.error)
    }, 30000)

    return () => clearInterval(interval)
  }, [])

  if (!nowPlaying) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center space-y-4">
          <RadioIcon className="w-16 h-16 mx-auto text-cyan-400 animate-pulse" />
          <p className="text-zinc-400">Loading 33.3FM...</p>
        </div>
      </div>
    )
  }

  const progress = (nowPlaying.track.currentTime / nowPlaying.track.duration) * 100

  return (
    <main className="min-h-screen bg-black text-white">
      <div className="max-w-5xl mx-auto px-6 py-12 space-y-8">
        {/* Header */}
        <header className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold neon-text-cyan">33.3FM LIVE</h1>
            <p className="text-sm text-zinc-400 mt-1">{nowPlaying.show.title}</p>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-zinc-900 border border-zinc-800 rounded-full">
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
            <Users className="w-4 h-4 text-zinc-400" />
            <span className="text-sm text-zinc-300">{nowPlaying.listeners} listening</span>
          </div>
        </header>

        {/* Now Playing Card */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-8 space-y-6">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Album Art */}
            <div className="relative w-full md:w-80 aspect-square rounded-xl overflow-hidden shadow-2xl">
              <img
                src={nowPlaying.track.coverArtUrl || "/placeholder.svg"}
                alt={nowPlaying.track.title}
                className="w-full h-full object-cover"
              />
              {isPlaying && (
                <div className="absolute inset-0 bg-gradient-to-t from-cyan-500/20 via-transparent to-transparent animate-pulse" />
              )}
            </div>

            {/* Track Info */}
            <div className="flex-1 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="inline-block px-3 py-1 bg-cyan-500/20 border border-cyan-500/30 rounded-full text-xs text-cyan-400">
                  {nowPlaying.track.genre}
                </div>
                <h2 className="text-3xl font-bold">{nowPlaying.track.title}</h2>
                <p className="text-lg text-zinc-400">
                  by <span className="text-cyan-400">@{nowPlaying.track.creatorHandle}</span>
                </p>
              </div>

              {/* Progress Bar */}
              <div className="space-y-2">
                <div className="w-full bg-zinc-800 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-500 to-fuchsia-500 transition-all duration-500"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <div className="flex justify-between text-xs text-zinc-500">
                  <span>{formatTime(nowPlaying.track.currentTime)}</span>
                  <span>{formatTime(nowPlaying.track.duration)}</span>
                </div>
              </div>

              {/* Controls */}
              <div className="flex items-center justify-center gap-6">
                <button className="p-3 hover:bg-zinc-800 rounded-full transition-colors">
                  <Volume2 className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="p-4 bg-gradient-to-br from-cyan-500 to-fuchsia-500 hover:from-cyan-600 hover:to-fuchsia-600 rounded-full transition-all shadow-lg"
                >
                  {isPlaying ? <Pause className="w-6 h-6 text-black" /> : <Play className="w-6 h-6 text-black" />}
                </button>
                <button className="p-3 hover:bg-zinc-800 rounded-full transition-colors">
                  <SkipForward className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Next Up */}
        <div className="space-y-4">
          <h3 className="text-xl font-semibold">Coming Up Next</h3>
          <div className="space-y-2">
            {nowPlaying.nextUp.map((track, i) => (
              <div
                key={track.id}
                className="flex items-center gap-4 p-4 bg-zinc-900/50 border border-zinc-800 rounded-lg hover:border-zinc-700 transition-colors"
              >
                <div className="w-8 h-8 flex items-center justify-center bg-zinc-800 rounded text-sm text-zinc-400">
                  {i + 1}
                </div>
                <div className="flex-1">
                  <p className="font-medium">{track.title}</p>
                  <p className="text-sm text-zinc-400">@{track.creatorHandle}</p>
                </div>
                <span className="text-sm text-zinc-500">{formatTime(track.duration)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </main>
  )
}

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60)
  const secs = seconds % 60
  return `${mins}:${secs.toString().padStart(2, "0")}`
}
