import type React from "react"
import Link from "next/link"
import { Radio, Video, Mic, BookAudio, Sparkles, Waves } from "lucide-react"

export default function FM33HomePage() {
  return (
    <main className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <section className="relative py-20 px-6 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-cyan-500/10 via-fuchsia-500/10 to-black" />
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-20 left-10 w-64 h-64 bg-cyan-500 rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-fuchsia-500 rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-6xl mx-auto text-center space-y-6">
          <div className="inline-block px-4 py-1.5 bg-cyan-500/20 border border-cyan-500/30 rounded-full text-sm text-cyan-400 mb-4">
            Powered by Dogechain
          </div>
          <h1 className="text-6xl md:text-8xl font-bold tracking-tight">
            <span className="neon-text-cyan">33.3FM</span>
            <br />
            <span className="text-fuchsia-400">DOGECHAIN</span>
          </h1>
          <p className="text-xl text-zinc-300 max-w-2xl mx-auto">
            The future of music, video, podcasts, and audiobooks. Mint, broadcast, and monetize on the decentralized
            web.
          </p>

          <p className="text-sm text-zinc-500">
            Signal Chain curated by <span className="text-cyan-400">DJ Chrome Fang</span>
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
            <Link
              href="/33fm/radio"
              className="px-6 py-3 bg-cyan-500 hover:bg-cyan-600 text-black font-semibold rounded-lg transition-all"
            >
              Listen Live
            </Link>
            <Link
              href="/33fm/jukebox"
              className="px-6 py-3 bg-fuchsia-500 hover:bg-fuchsia-600 text-white font-semibold rounded-lg transition-all"
            >
              Video Jukebox
            </Link>
            <Link
              href="/33fm/studio"
              className="px-6 py-3 border border-zinc-700 hover:border-cyan-500 text-white font-semibold rounded-lg transition-all"
            >
              Enter Studio
            </Link>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <h2 className="text-4xl font-bold text-center mb-12">
          <span className="neon-text-cyan">Everything You Need</span>
        </h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <FeatureCard
            icon={<Radio className="w-8 h-8 text-cyan-400" />}
            title="24/7 Radio"
            description="Continuous broadcast with AI-curated rotation and live DJ shows"
            href="/33fm/radio"
          />
          <FeatureCard
            icon={<Video className="w-8 h-8 text-fuchsia-400" />}
            title="Video Jukebox"
            description="MTV-style video channel with swipeable playlists and creator premieres"
            href="/33fm/jukebox"
          />
          <FeatureCard
            icon={<Sparkles className="w-8 h-8 text-yellow-400" />}
            title="Music Minter"
            description="Upload, master, and mint your tracks on Dogechain with AI tools"
            href="/33fm/studio/mint"
          />
          <FeatureCard
            icon={<Mic className="w-8 h-8 text-emerald-400" />}
            title="Podcasts"
            description="Record in 3D production studios and publish to 33.3FM"
            href="/33fm/podcasts"
          />
          <FeatureCard
            icon={<BookAudio className="w-8 h-8 text-purple-400" />}
            title="Audiobooks"
            description="Narrate in the audiobook studio and mint as NFTs"
            href="/33fm/audiobooks"
          />
          <FeatureCard
            icon={<Waves className="w-8 h-8 text-orange-400" />}
            title="Signal Chain"
            description="Background audio layer curated by DJ Chrome Fang across the network"
            href="/33fm/studio/signal-booth"
          />
        </div>
      </section>

      {/* Creator Section */}
      <section className="bg-zinc-900/50 py-20 px-6">
        <div className="max-w-5xl mx-auto text-center space-y-6">
          <h2 className="text-4xl font-bold">
            <span className="neon-text-fuchsia">For Creators</span>
          </h2>
          <p className="text-lg text-zinc-400 max-w-2xl mx-auto">
            Get your own 3D venue, production studios, and creator profile. Mint unlimited content with pro tier access.
          </p>
          <div className="flex flex-wrap justify-center gap-4 pt-4">
            <Link
              href="/33fm/creator/signup"
              className="px-6 py-3 bg-fuchsia-500 hover:bg-fuchsia-600 text-white font-semibold rounded-lg transition-all"
            >
              Become a Creator
            </Link>
            <Link
              href="/33fm/creators"
              className="px-6 py-3 border border-zinc-700 hover:border-fuchsia-500 text-white font-semibold rounded-lg transition-all"
            >
              Browse Creators
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <div className="grid md:grid-cols-4 gap-8 text-center">
          <StatCard value="10K+" label="Tracks Minted" />
          <StatCard value="342" label="Live Listeners" />
          <StatCard value="1.2K" label="Creators" />
          <StatCard value="500+" label="Videos" />
        </div>
      </section>

      {/* DJ Duo Section */}
      <section className="max-w-5xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-2 gap-6">
          <div className="p-6 bg-gradient-to-br from-red-950/30 to-zinc-900 rounded-2xl border border-red-500/20">
            <h3 className="text-xl font-bold text-red-400 mb-2">DJ Red Fang</h3>
            <p className="text-sm text-zinc-400 mb-3">Primary Host</p>
            <p className="text-zinc-500 text-sm">
              Sultry, commanding, smooth transitions. The foreground voice and narrative anchor of 33.3FM.
            </p>
          </div>
          <div className="p-6 bg-gradient-to-br from-zinc-800/30 to-zinc-900 rounded-2xl border border-zinc-700/50">
            <h3 className="text-xl font-bold text-zinc-300 mb-2">DJ Chrome Fang</h3>
            <p className="text-sm text-zinc-400 mb-3">Signal Chain Curator</p>
            <p className="text-zinc-500 text-sm">
              Low baritone, vinyl scholar, analog priest. The background engineer and keeper of the Signal Chain.
            </p>
          </div>
        </div>
      </section>
    </main>
  )
}

function FeatureCard({
  icon,
  title,
  description,
  href,
}: { icon: React.ReactNode; title: string; description: string; href: string }) {
  return (
    <Link
      href={href}
      className="group p-6 border border-zinc-800 hover:border-cyan-500/50 rounded-xl bg-zinc-900/50 hover:bg-zinc-900 transition-all"
    >
      <div className="mb-4">{icon}</div>
      <h3 className="text-xl font-semibold mb-2 group-hover:text-cyan-400 transition-colors">{title}</h3>
      <p className="text-sm text-zinc-400">{description}</p>
    </Link>
  )
}

function StatCard({ value, label }: { value: string; label: string }) {
  return (
    <div className="space-y-2">
      <div className="text-4xl font-bold neon-text-cyan">{value}</div>
      <div className="text-sm text-zinc-400">{label}</div>
    </div>
  )
}
