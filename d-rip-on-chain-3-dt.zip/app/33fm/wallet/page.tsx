"use client"

export default function WalletPage() {
  return (
    <main className="min-h-screen bg-black text-white p-6">
      <div className="max-w-4xl mx-auto">
        <header className="mb-8">
          <h1 className="text-4xl font-bold text-cyan-400 mb-2">CONNECT WALLET</h1>
          <p className="text-neutral-400">Link your crypto wallet to boost tracks, mint content, and earn</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            { name: "MetaMask", chain: "ETH", icon: "🦊" },
            { name: "Phantom", chain: "SOL", icon: "👻" },
            { name: "Dogechain", chain: "DOGE", icon: "🐕" },
            { name: "Xaman", chain: "XRP", icon: "💎" },
            { name: "HashPack", chain: "HBAR", icon: "⚡" },
            { name: "Bitcoin", chain: "BTC", icon: "₿" },
          ].map((wallet) => (
            <button
              key={wallet.chain}
              className="border border-neutral-800 rounded-xl p-6 hover:border-cyan-500 transition-colors text-left"
            >
              <div className="text-4xl mb-3">{wallet.icon}</div>
              <h3 className="text-lg font-semibold">{wallet.name}</h3>
              <p className="text-sm text-neutral-400 mt-1">{wallet.chain}</p>
            </button>
          ))}
        </div>

        <div className="mt-12 border border-neutral-800 rounded-xl p-6">
          <h2 className="text-xl font-semibold mb-4">Email Login</h2>
          <p className="text-sm text-neutral-400 mb-4">Don't have a wallet? Start with email and upgrade later</p>
          <input
            type="email"
            placeholder="your@email.com"
            className="w-full bg-neutral-900 border border-neutral-800 rounded px-4 py-3 text-white mb-3"
          />
          <button className="w-full px-6 py-3 bg-cyan-500 rounded text-black font-medium hover:bg-cyan-400 transition-colors">
            Send Magic Link
          </button>
        </div>

        <div className="mt-8 border border-neutral-800 rounded-xl p-6">
          <h2 className="text-xl font-semibold mb-4">Social Login</h2>
          <div className="grid grid-cols-2 gap-3">
            {["Google", "Apple", "X/Twitter", "Discord"].map((provider) => (
              <button
                key={provider}
                className="px-4 py-3 border border-neutral-800 rounded hover:border-cyan-500 transition-colors"
              >
                Connect with {provider}
              </button>
            ))}
          </div>
        </div>
      </div>
    </main>
  )
}
