import { notFound } from "next/navigation"
import { fetchLurkyProfileByHandle } from "@/lib/lurky/profiles"
import { getMockTracks, getMockPodcasts, getMockAudiobooks } from "@/lib/33fm-mock-data"

export default async function CreatorProfilePage({ params }: { params: { handle: string } }) {
  const { handle } = params

  const lurkyProfile = await fetchLurkyProfileByHandle(handle).catch(() => null)

  const mockTracks = getMockTracks()
    .filter((t) => t.creator.toLowerCase().includes(handle.toLowerCase()))
    .slice(0, 10)
  const mockPodcasts = getMockPodcasts()
    .filter((p) => p.host.toLowerCase().includes(handle.toLowerCase()))
    .slice(0, 5)
  const mockAudiobooks = getMockAudiobooks()
    .filter((a) => a.narrator.toLowerCase().includes(handle.toLowerCase()))
    .slice(0, 5)

  // If no content and no Lurky profile, show not found
  if (!lurkyProfile && mockTracks.length === 0 && mockPodcasts.length === 0 && mockAudiobooks.length === 0) {
    notFound()
  }

  const displayName = lurkyProfile?.displayName || handle
  const avatarUrl = lurkyProfile?.avatarUrl
  const bio = lurkyProfile?.description || "33.3FM Creator"
  const followers = lurkyProfile?.followers
  const verified = lurkyProfile?.verified

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8 flex gap-6">
          <div className="w-32 h-32 bg-neutral-900 rounded-xl flex items-center justify-center text-4xl flex-shrink-0">
            {avatarUrl ? (
              <img
                src={avatarUrl || "/placeholder.svg"}
                alt={displayName}
                className="w-full h-full object-cover rounded-xl"
              />
            ) : (
              "🎵"
            )}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h1 className="text-4xl font-bold text-cyan-400 mb-2">@{handle}</h1>
              {verified && <span className="text-xl">✓</span>}
            </div>
            <p className="text-xl text-neutral-300 mb-2">{displayName}</p>
            {bio && <p className="text-neutral-400 mb-4">{bio}</p>}
            <div className="flex gap-3 flex-wrap">
              <span className="px-3 py-1 bg-neutral-900 rounded text-sm">33.3FM CREATOR</span>
              {followers && (
                <span className="px-3 py-1 bg-neutral-900 rounded text-sm">{followers.toLocaleString()} followers</span>
              )}
              {lurkyProfile && (
                <span className="px-3 py-1 bg-cyan-500/20 text-cyan-400 rounded text-sm border border-cyan-500/30">
                  Verified via Lurky
                </span>
              )}
            </div>
          </div>
        </header>

        <div className="space-y-8">
          {mockTracks.length > 0 && (
            <section>
              <h2 className="text-2xl font-semibold mb-4">Recent Tracks</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {mockTracks.map((track) => (
                  <div
                    key={track.id}
                    className="border border-neutral-800 rounded-xl p-4 hover:border-cyan-500 transition-colors"
                  >
                    <h3 className="font-semibold truncate">{track.title}</h3>
                    <p className="text-sm text-neutral-400 mt-1">by {track.artist}</p>
                    <p className="text-xs text-neutral-500 mt-2">{track.genre}</p>
                  </div>
                ))}
              </div>
            </section>
          )}

          {mockAudiobooks.length > 0 && (
            <section>
              <h2 className="text-2xl font-semibold mb-4">Audiobooks</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {mockAudiobooks.map((book) => (
                  <div
                    key={book.id}
                    className="border border-neutral-800 rounded-xl p-4 hover:border-cyan-500 transition-colors"
                  >
                    <h3 className="font-semibold">{book.title}</h3>
                    <p className="text-xs text-neutral-400 mt-1">by {book.author}</p>
                  </div>
                ))}
              </div>
            </section>
          )}

          {mockPodcasts.length > 0 && (
            <section>
              <h2 className="text-2xl font-semibold mb-4">Podcasts</h2>
              <div className="space-y-3">
                {mockPodcasts.map((podcast) => (
                  <div
                    key={podcast.id}
                    className="border border-neutral-800 rounded-xl p-4 hover:border-cyan-500 transition-colors"
                  >
                    <h3 className="font-semibold">{podcast.title}</h3>
                    <p className="text-xs text-neutral-400 mt-1">{podcast.description}</p>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>
      </div>
    </main>
  )
}
