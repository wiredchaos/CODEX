"use client"

import { StudioHeader } from "@/components/vss/studio-header"
import { StudioSidebar } from "@/components/vss/studio-sidebar"
import { Sliders, Volume2, Waves } from "lucide-react"

export default function MixRoomPage() {
  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <StudioHeader currentRoom="mix-room" />
      <div className="flex flex-1">
        <StudioSidebar />
        <main className="flex-1 p-8">
          <div className="max-w-4xl mx-auto space-y-6">
            <header className="space-y-2">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-lg bg-cyan-500/20 border border-cyan-500/30">
                  <Sliders className="w-6 h-6 text-cyan-400" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold">Mix Room</h1>
                  <p className="text-sm text-neutral-400">Professional mixing console</p>
                </div>
              </div>
            </header>

            {/* Mixer Channels */}
            <div className="grid grid-cols-4 gap-4">
              {["Vocals", "Drums", "Bass", "Synth"].map((channel, i) => (
                <div key={channel} className="p-4 rounded-lg bg-neutral-900/50 border border-neutral-800 space-y-4">
                  <p className="text-sm font-medium text-center">{channel}</p>
                  <div className="h-32 bg-neutral-800 rounded relative">
                    <div
                      className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-cyan-500 to-cyan-500/50 rounded-b"
                      style={{ height: `${60 + i * 10}%` }}
                    />
                  </div>
                  <div className="flex justify-center gap-2">
                    <button className="p-2 rounded bg-neutral-800 hover:bg-neutral-700">
                      <Volume2 className="w-4 h-4" />
                    </button>
                    <button className="p-2 rounded bg-neutral-800 hover:bg-neutral-700">
                      <Waves className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <p className="text-xs text-neutral-500 text-center">
              Full mixing controls available. Drag faders to adjust levels.
            </p>
          </div>
        </main>
      </div>
    </div>
  )
}
