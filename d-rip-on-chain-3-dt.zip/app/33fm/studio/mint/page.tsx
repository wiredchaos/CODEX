"use client"

import { StudioHeader } from "@/components/vss/studio-header"
import { StudioSidebar } from "@/components/vss/studio-sidebar"
import { Sparkles, Upload, ImageIcon, Music } from "lucide-react"

export default function MintPage() {
  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <StudioHeader currentRoom="mint" />
      <div className="flex flex-1">
        <StudioSidebar />
        <main className="flex-1 p-8">
          <div className="max-w-2xl mx-auto space-y-6">
            <header className="space-y-2">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-lg bg-pink-500/20 border border-pink-500/30">
                  <Sparkles className="w-6 h-6 text-pink-400" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold">NFT Mint</h1>
                  <p className="text-sm text-neutral-400">Mint your tracks as NFTs on Dogechain</p>
                </div>
              </div>
            </header>

            <div className="p-6 rounded-lg bg-neutral-900/50 border border-neutral-800 border-dashed">
              <div className="text-center space-y-4">
                <div className="inline-flex p-4 rounded-full bg-neutral-800">
                  <Upload className="w-8 h-8 text-neutral-400" />
                </div>
                <div>
                  <p className="font-medium">Drop your track to mint</p>
                  <p className="text-sm text-neutral-500">WAV, MP3, or FLAC up to 50MB</p>
                </div>
                <button className="px-6 py-2 rounded-lg bg-pink-500 hover:bg-pink-400 text-black font-semibold transition-colors">
                  Select File
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 rounded-lg bg-neutral-900/50 border border-neutral-800">
                <ImageIcon className="w-5 h-5 text-cyan-400 mb-2" />
                <p className="text-sm font-medium">Cover Art</p>
                <p className="text-xs text-neutral-500">Auto-generated or upload</p>
              </div>
              <div className="p-4 rounded-lg bg-neutral-900/50 border border-neutral-800">
                <Music className="w-5 h-5 text-cyan-400 mb-2" />
                <p className="text-sm font-medium">Royalties</p>
                <p className="text-xs text-neutral-500">Set your split %</p>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
