import Link from "next/link"
import { Shield, Radio, Sliders, Cpu, Settings2, Coins, ListMusic, Zap } from "lucide-react"
import { RoomCard } from "@/components/vss/room-card"
import { StudioHeader } from "@/components/vss/studio-header"

const rooms = [
  {
    id: "gate",
    name: "Gate",
    description: "Verify your identity and unlock studio access",
    href: "/33fm/studio/gate",
    icon: Shield,
    color: "text-yellow-400",
    status: "active" as const,
  },
  {
    id: "signal-booth",
    name: "Signal Booth",
    description: "Record vocals, podcasts, and voice-overs",
    href: "/33fm/studio/signal-booth",
    icon: Radio,
    color: "text-cyan-400",
    status: "active" as const,
  },
  {
    id: "producer-room",
    name: "Producer Room",
    description: "Create beats with drum pads and AI assistance",
    href: "/33fm/studio/producer-room",
    icon: Cpu,
    color: "text-fuchsia-400",
    status: "active" as const,
  },
  {
    id: "mix-room",
    name: "Mix Room",
    description: "Mix and master your tracks with pro tools",
    href: "/33fm/studio/mix-room",
    icon: Sliders,
    color: "text-emerald-400",
    status: "active" as const,
  },
  {
    id: "control-room",
    name: "Control Room",
    description: "Manage projects, settings, and exports",
    href: "/33fm/studio/control-room",
    icon: Settings2,
    color: "text-orange-400",
    status: "active" as const,
  },
  {
    id: "mint",
    name: "Mint",
    description: "Mint your audio as NFTs on Dogechain",
    href: "/33fm/studio/mint",
    icon: Coins,
    color: "text-purple-400",
    status: "active" as const,
  },
  {
    id: "playlists",
    name: "Playlists",
    description: "Organize and share your curated collections",
    href: "/33fm/studio/playlists",
    icon: ListMusic,
    color: "text-blue-400",
    status: "active" as const,
  },
]

export default function VSSStudioPage() {
  return (
    <main className="min-h-screen bg-black text-white">
      <StudioHeader showBack={false} />

      {/* Hero Section */}
      <section className="relative py-16 px-6 overflow-hidden">
        {/* Neon Motherboard Background */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-b from-red-950/20 via-black to-black" />
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl" />
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-red-500/10 rounded-full blur-3xl" />

          {/* Circuit Traces */}
          <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 1000 500">
            <path
              d="M0 250 L200 250 L250 200 L400 200 L450 250 L600 250"
              stroke="currentColor"
              fill="none"
              strokeWidth="1"
              className="text-cyan-500"
            />
            <path
              d="M600 250 L700 250 L750 300 L900 300 L950 250 L1000 250"
              stroke="currentColor"
              fill="none"
              strokeWidth="1"
              className="text-red-500"
            />
            <circle cx="200" cy="250" r="4" fill="currentColor" className="text-cyan-400" />
            <circle cx="450" cy="250" r="4" fill="currentColor" className="text-cyan-400" />
            <circle cx="750" cy="300" r="4" fill="currentColor" className="text-red-400" />
          </svg>
        </div>

        <div className="relative max-w-6xl mx-auto text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-red-900/30 border border-red-500/30 rounded-full text-sm">
            <Zap className="w-4 h-4 text-cyan-400" />
            <span className="text-cyan-400">Virtual Signal Studio</span>
          </div>

          <h1 className="text-5xl md:text-7xl font-bold tracking-tight">
            <span className="text-cyan-400">VSS</span>
            <span className="text-red-500">-33.3</span>
          </h1>

          <p className="text-lg text-neutral-400 max-w-2xl mx-auto">
            Professional audio production suite. Record, produce, mix, and mint your music directly to the blockchain.
          </p>

          <div className="flex items-center justify-center gap-4 pt-4">
            <Link
              href="/33fm/studio/signal-booth"
              className="px-6 py-3 bg-cyan-500 hover:bg-cyan-400 text-black font-semibold rounded-lg transition-colors"
            >
              Start Recording
            </Link>
            <Link
              href="/33fm/studio/producer-room"
              className="px-6 py-3 border border-red-500/50 hover:border-red-400 text-red-400 font-semibold rounded-lg transition-colors"
            >
              Make Beats
            </Link>
          </div>
        </div>
      </section>

      {/* Studio Rooms Grid */}
      <section className="max-w-6xl mx-auto px-6 pb-20">
        <h2 className="text-2xl font-bold mb-8 text-center">
          <span className="text-neutral-400">Enter a</span> <span className="text-cyan-400">Room</span>
        </h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {rooms.map((room) => (
            <RoomCard key={room.id} {...room} />
          ))}
        </div>
      </section>

      {/* Status Bar */}
      <div className="fixed bottom-0 left-0 right-0 h-10 bg-black/90 border-t border-red-900/30 flex items-center justify-between px-4 text-xs">
        <div className="flex items-center gap-4">
          <span className="text-neutral-500">VSS-33.3 v1.0.0</span>
          <span className="text-cyan-400">● ONLINE</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-neutral-500">Latency: 12ms</span>
          <span className="text-neutral-500">Sample Rate: 48kHz</span>
        </div>
      </div>
    </main>
  )
}
