"use client"

import { useState } from "react"
import { Play, Pause, Square, Plus, Sparkles } from "lucide-react"
import { StudioHeader } from "@/components/vss/studio-header"
import { StudioSidebar } from "@/components/vss/studio-sidebar"
import { DrumPad } from "@/components/vss/drum-pad"
import { TrackLane } from "@/components/vss/track-lane"

const drumPads = [
  { id: "1", label: "Kick", color: "red", keyBinding: "Q" },
  { id: "2", label: "Snare", color: "cyan", keyBinding: "W" },
  { id: "3", label: "Hi-Hat", color: "yellow", keyBinding: "E" },
  { id: "4", label: "Clap", color: "fuchsia", keyBinding: "R" },
  { id: "5", label: "Tom", color: "orange", keyBinding: "A" },
  { id: "6", label: "Rim", color: "green", keyBinding: "S" },
  { id: "7", label: "Crash", color: "blue", keyBinding: "D" },
  { id: "8", label: "Perc", color: "purple", keyBinding: "F" },
]

const initialTracks = [
  { id: "1", name: "Drums", type: "drums" as const, volume: 80, muted: false, solo: false, color: "#ef4444" },
  { id: "2", name: "Bass", type: "midi" as const, volume: 75, muted: false, solo: false, color: "#22d3ee" },
  { id: "3", name: "Synth", type: "midi" as const, volume: 70, muted: false, solo: false, color: "#d946ef" },
  { id: "4", name: "Vocals", type: "audio" as const, volume: 85, muted: true, solo: false, color: "#22c55e" },
]

export default function ProducerRoomPage() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [bpm, setBpm] = useState(120)
  const [tracks, setTracks] = useState(initialTracks)

  const toggleTrackMute = (id: string) => {
    setTracks(tracks.map((t) => (t.id === id ? { ...t, muted: !t.muted } : t)))
  }

  const toggleTrackSolo = (id: string) => {
    setTracks(tracks.map((t) => (t.id === id ? { ...t, solo: !t.solo } : t)))
  }

  const updateTrackVolume = (id: string, volume: number) => {
    setTracks(tracks.map((t) => (t.id === id ? { ...t, volume } : t)))
  }

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <StudioHeader currentRoom="producer-room" />

      <div className="flex flex-1">
        <StudioSidebar />

        <main className="flex-1 p-6 overflow-auto">
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h1 className="text-3xl font-bold">Producer Room</h1>
                <p className="text-neutral-400">Create beats and produce tracks</p>
              </div>
              <button className="flex items-center gap-2 px-4 py-2 bg-fuchsia-500/20 border border-fuchsia-500/50 rounded-lg text-fuchsia-400 hover:bg-fuchsia-500/30 transition-colors">
                <Sparkles className="w-4 h-4" />
                AI Assist
              </button>
            </div>

            {/* Transport Bar */}
            <div className="flex items-center gap-4 p-4 bg-red-950/20 border border-red-900/50 rounded-xl mb-6">
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="w-12 h-12 rounded-full bg-cyan-500 hover:bg-cyan-400 flex items-center justify-center transition-colors"
              >
                {isPlaying ? <Pause className="w-6 h-6 text-black" /> : <Play className="w-6 h-6 text-black ml-1" />}
              </button>
              <button className="w-10 h-10 rounded-full bg-red-500/20 hover:bg-red-500/30 flex items-center justify-center transition-colors">
                <Square className="w-4 h-4 text-red-400" />
              </button>

              <div className="flex items-center gap-2 ml-4">
                <span className="text-sm text-neutral-400">BPM</span>
                <input
                  type="number"
                  value={bpm}
                  onChange={(e) => setBpm(Number(e.target.value))}
                  className="w-16 px-2 py-1 bg-black border border-neutral-700 rounded text-center text-cyan-400 font-mono"
                />
              </div>

              <div className="ml-auto font-mono text-2xl text-cyan-400">00:00:00</div>
            </div>

            {/* Main Content Grid */}
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Drum Pads */}
              <div className="lg:col-span-1">
                <h2 className="text-lg font-semibold mb-4 text-cyan-400">Drum Pads</h2>
                <div className="grid grid-cols-4 gap-2 p-4 bg-neutral-900/50 border border-neutral-800 rounded-xl">
                  {drumPads.map((pad) => (
                    <DrumPad key={pad.id} label={pad.label} color={pad.color} keyBinding={pad.keyBinding} />
                  ))}
                </div>
              </div>

              {/* Track Lanes */}
              <div className="lg:col-span-2">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold text-cyan-400">Tracks</h2>
                  <button className="flex items-center gap-1 px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 rounded text-sm transition-colors">
                    <Plus className="w-4 h-4" />
                    Add Track
                  </button>
                </div>
                <div className="space-y-2">
                  {tracks.map((track) => (
                    <TrackLane
                      key={track.id}
                      name={track.name}
                      type={track.type}
                      volume={track.volume}
                      isMuted={track.muted}
                      isSolo={track.solo}
                      color={track.color}
                      onMuteToggle={() => toggleTrackMute(track.id)}
                      onSoloToggle={() => toggleTrackSolo(track.id)}
                      onVolumeChange={(v) => updateTrackVolume(track.id, v)}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
