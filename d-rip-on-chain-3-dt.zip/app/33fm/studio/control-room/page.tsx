"use client"

import type React from "react"

import { StudioHeader } from "@/components/vss/studio-header"
import { StudioSidebar } from "@/components/vss/studio-sidebar"
import { Settings, Cpu, Database, Shield } from "lucide-react"

export default function ControlRoomPage() {
  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <StudioHeader currentRoom="control-room" />
      <div className="flex flex-1">
        <StudioSidebar />
        <main className="flex-1 p-8">
          <div className="max-w-4xl mx-auto space-y-6">
            <header className="space-y-2">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-lg bg-pink-500/20 border border-pink-500/30">
                  <Settings className="w-6 h-6 text-pink-400" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold">Control Room</h1>
                  <p className="text-sm text-neutral-400">Master controls for Producer tier</p>
                </div>
              </div>
            </header>

            <div className="grid grid-cols-3 gap-4">
              <ControlPanel icon={Cpu} title="Processing" value="Active" status="online" />
              <ControlPanel icon={Database} title="Storage" value="2.4 TB" status="online" />
              <ControlPanel icon={Shield} title="Security" value="Encrypted" status="online" />
            </div>

            <div className="p-6 rounded-lg bg-neutral-900/50 border border-neutral-800">
              <h2 className="font-semibold mb-4">Master Output</h2>
              <div className="h-24 bg-neutral-800 rounded-lg flex items-center justify-center">
                <div className="flex gap-1">
                  {Array.from({ length: 32 }).map((_, i) => (
                    <div
                      key={i}
                      className="w-2 bg-gradient-to-t from-pink-500 to-cyan-500 rounded-full"
                      style={{ height: `${Math.random() * 60 + 20}px` }}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}

function ControlPanel({
  icon: Icon,
  title,
  value,
  status,
}: {
  icon: React.ElementType
  title: string
  value: string
  status: "online" | "offline"
}) {
  return (
    <div className="p-4 rounded-lg bg-neutral-900/50 border border-neutral-800">
      <div className="flex items-center justify-between mb-2">
        <Icon className="w-5 h-5 text-pink-400" />
        <span
          className={`text-[10px] px-2 py-0.5 rounded-full ${
            status === "online" ? "bg-emerald-500/20 text-emerald-400" : "bg-red-500/20 text-red-400"
          }`}
        >
          {status.toUpperCase()}
        </span>
      </div>
      <p className="text-xs text-neutral-500">{title}</p>
      <p className="text-lg font-semibold">{value}</p>
    </div>
  )
}
