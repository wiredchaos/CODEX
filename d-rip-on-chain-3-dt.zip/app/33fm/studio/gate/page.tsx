"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Shield, Wallet, Check, Lock, Zap, Sparkles, Key } from "lucide-react"
import { StudioHeader } from "@/components/vss/studio-header"
import { StudioSidebar } from "@/components/vss/studio-sidebar"
import { STUDIO_TIERS, type StudioTierId } from "@/lib/studio/tiers"
import { useStudioAccess } from "@/lib/studio/use-studio-access"

export default function GatePage() {
  const { activeTier, loading, refetch } = useStudioAccess()
  const [isVerifying, setIsVerifying] = useState(false)

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <StudioHeader currentRoom="gate" />

      <div className="flex flex-1">
        <StudioSidebar />

        <main className="flex-1 p-6 overflow-y-auto">
          <div className="max-w-6xl mx-auto">
            {/* Gate Status */}
            <header className="text-center mb-12">
              <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-yellow-900/20 border-2 border-yellow-500/50 mb-6">
                <Shield className="w-12 h-12 text-yellow-400" />
              </div>
              <h1 className="text-3xl font-bold mb-2">Studio Gate</h1>
              <p className="text-neutral-400">Validate your access or upgrade your tier to unlock studio features.</p>
              {!loading && (
                <p className="text-xs text-cyan-300 mt-2">
                  Current tier: <span className="font-semibold">{activeTier ?? "None (Free)"}</span>
                </p>
              )}
            </header>

            {/* Tier Cards Grid */}
            <div className="grid gap-6 md:grid-cols-3 mb-12">
              {STUDIO_TIERS.map((tier) => (
                <TierCard
                  key={tier.id}
                  tier={tier}
                  activeTier={activeTier}
                  isVerifying={isVerifying}
                  setIsVerifying={setIsVerifying}
                  onVerified={refetch}
                />
              ))}
            </div>

            {/* Verification Steps */}
            <div className="max-w-2xl mx-auto space-y-4">
              <h2 className="text-lg font-semibold text-center mb-4">Verification Process</h2>
              <VerificationStep
                number={1}
                title="Connect Wallet"
                description="Link your Dogechain, XRPL, or ETH wallet"
                status={activeTier ? "complete" : "pending"}
                icon={Wallet}
              />
              <VerificationStep
                number={2}
                title="Verify Ownership"
                description="Confirm NFT, Key, or subscription status"
                status={activeTier ? "complete" : "locked"}
                icon={Check}
              />
              <VerificationStep
                number={3}
                title="Unlock Access"
                description="Gain full studio permissions for your tier"
                status={activeTier ? "complete" : "locked"}
                icon={Zap}
              />
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}

function TierCard({
  tier,
  activeTier,
  isVerifying,
  setIsVerifying,
  onVerified,
}: {
  tier: (typeof STUDIO_TIERS)[number]
  activeTier: StudioTierId | null
  isVerifying: boolean
  setIsVerifying: (v: boolean) => void
  onVerified: () => void
}) {
  const isActive =
    activeTier === tier.id ||
    (activeTier === "syndicate" && tier.id !== "syndicate") ||
    (activeTier === "producer" && tier.id === "creator")

  const handleAction = async () => {
    setIsVerifying(true)
    // Simulate verification
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsVerifying(false)
    onVerified()
  }

  return (
    <div
      className={`relative rounded-xl border p-6 shadow-lg transition-all ${
        tier.highlight
          ? "bg-gradient-to-br from-pink-950/40 to-slate-900/60 border-pink-500 shadow-pink-500/30"
          : isActive
            ? "bg-gradient-to-br from-cyan-950/40 to-slate-900/60 border-cyan-500/50"
            : "bg-gradient-to-br from-slate-950/80 to-slate-900/40 border-slate-700"
      }`}
    >
      {tier.highlight && (
        <div className="absolute -top-3 right-4 rounded-full bg-pink-500 px-3 py-1 text-xs font-semibold text-black flex items-center gap-1">
          <Sparkles className="w-3 h-3" />
          Featured
        </div>
      )}

      <div className="space-y-1">
        <h2 className="text-xl font-semibold">{tier.name}</h2>
        <p className={`text-sm ${tier.highlight ? "text-pink-300" : "text-cyan-300"}`}>{tier.priceLabel}</p>
        {tier.badge && (
          <p className="text-[11px] uppercase tracking-wide text-pink-300 flex items-center gap-1">
            {tier.badge === "Key Required" ? <Key className="w-3 h-3" /> : <Sparkles className="w-3 h-3" />}
            {tier.badge}
          </p>
        )}
        <p className="mt-2 text-xs text-neutral-400">{tier.description}</p>
      </div>

      <ul className="mt-4 space-y-1.5 text-xs text-neutral-300">
        {tier.features.map((f) => (
          <li key={f} className="flex items-center gap-2">
            <span
              className={`inline-block h-1.5 w-1.5 rounded-full ${tier.highlight ? "bg-pink-400" : "bg-cyan-400"}`}
            />
            {f}
          </li>
        ))}
      </ul>

      <TierButton tier={tier} isActive={isActive} isVerifying={isVerifying} onAction={handleAction} />
    </div>
  )
}

function TierButton({
  tier,
  isActive,
  isVerifying,
  onAction,
}: {
  tier: (typeof STUDIO_TIERS)[number]
  isActive: boolean
  isVerifying: boolean
  onAction: () => void
}) {
  if (isActive) {
    return (
      <Link
        href="/33fm/studio"
        className="w-full mt-4 inline-flex items-center justify-center rounded-md bg-cyan-500 px-4 py-2.5 text-sm font-semibold text-black hover:bg-cyan-400 transition-colors"
      >
        <Check className="w-4 h-4 mr-2" />
        Enter Studio
      </Link>
    )
  }

  switch (tier.id) {
    case "creator":
      return (
        <button
          disabled={isVerifying}
          onClick={onAction}
          className="w-full mt-4 inline-flex items-center justify-center rounded-md border border-cyan-400 px-4 py-2.5 text-sm font-semibold text-cyan-300 hover:bg-cyan-900/40 disabled:opacity-50 transition-colors"
        >
          {isVerifying ? "Processing..." : "Start Creator Plan"}
        </button>
      )
    case "producer":
      return (
        <button
          disabled={isVerifying}
          onClick={onAction}
          className="w-full mt-4 inline-flex items-center justify-center rounded-md border border-pink-500 px-4 py-2.5 text-sm font-semibold text-pink-300 hover:bg-pink-900/40 disabled:opacity-50 transition-colors"
        >
          {isVerifying ? "Verifying..." : "Verify 2090 NFT"}
        </button>
      )
    case "syndicate":
      return (
        <button
          disabled={isVerifying}
          onClick={onAction}
          className="w-full mt-4 inline-flex items-center justify-center rounded-md border border-emerald-500 px-4 py-2.5 text-sm font-semibold text-emerald-300 hover:bg-emerald-900/40 disabled:opacity-50 transition-colors"
        >
          {isVerifying ? "Checking..." : "Verify Vault33 Key"}
        </button>
      )
  }
}

function VerificationStep({
  number,
  title,
  description,
  status,
  icon: Icon,
}: {
  number: number
  title: string
  description: string
  status: "complete" | "pending" | "locked"
  icon: React.ElementType
}) {
  return (
    <div
      className={`flex items-center gap-4 p-4 rounded-lg border ${
        status === "complete"
          ? "bg-emerald-900/20 border-emerald-500/50"
          : status === "pending"
            ? "bg-yellow-900/20 border-yellow-500/50"
            : "bg-neutral-900/50 border-neutral-800"
      }`}
    >
      <div
        className={`w-10 h-10 rounded-full flex items-center justify-center ${
          status === "complete"
            ? "bg-emerald-500/20 text-emerald-400"
            : status === "pending"
              ? "bg-yellow-500/20 text-yellow-400"
              : "bg-neutral-800 text-neutral-500"
        }`}
      >
        {status === "complete" ? (
          <Check className="w-5 h-5" />
        ) : status === "locked" ? (
          <Lock className="w-4 h-4" />
        ) : (
          <Icon className="w-5 h-5" />
        )}
      </div>
      <div className="flex-1">
        <h3 className="font-semibold text-white">{title}</h3>
        <p className="text-sm text-neutral-400">{description}</p>
      </div>
      <span className="text-sm text-neutral-500">Step {number}</span>
    </div>
  )
}
