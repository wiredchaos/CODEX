"use client"
import { Mic, Square, Play, Pause, Download, Trash2 } from "lucide-react"
import { StudioHeader } from "@/components/vss/studio-header"
import { StudioSidebar } from "@/components/vss/studio-sidebar"
import { WaveformVisualizer } from "@/components/vss/waveform-visualizer"
import { useAudioRecorder } from "@/hooks/use-audio-recorder"

export default function SignalBoothPage() {
  const {
    isRecording,
    isPaused,
    duration,
    audioUrl,
    error,
    startRecording,
    stopRecording,
    pauseRecording,
    resumeRecording,
    clearRecording,
  } = useAudioRecorder()

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <StudioHeader currentRoom="signal-booth" />

      <div className="flex flex-1">
        <StudioSidebar />

        <main className="flex-1 p-6">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-3xl font-bold mb-2">Signal Booth</h1>
            <p className="text-neutral-400 mb-8">Professional recording environment for vocals and spoken word</p>

            {/* Recording Interface */}
            <div className="bg-red-950/20 border border-red-900/50 rounded-xl p-8">
              {/* Waveform Display */}
              <div className="mb-8">
                <WaveformVisualizer isPlaying={isRecording && !isPaused} barCount={96} />
              </div>

              {/* Timer */}
              <div className="text-center mb-8">
                <span className="text-6xl font-mono text-cyan-400">{formatTime(duration)}</span>
                {isRecording && (
                  <div className="mt-2 flex items-center justify-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-red-500 animate-pulse" />
                    <span className="text-red-400 text-sm">Recording</span>
                  </div>
                )}
              </div>

              {/* Controls */}
              <div className="flex items-center justify-center gap-4">
                {!isRecording && !audioUrl && (
                  <button
                    onClick={startRecording}
                    className="w-20 h-20 rounded-full bg-red-500 hover:bg-red-400 flex items-center justify-center transition-colors"
                  >
                    <Mic className="w-8 h-8 text-white" />
                  </button>
                )}

                {isRecording && (
                  <>
                    <button
                      onClick={isPaused ? resumeRecording : pauseRecording}
                      className="w-14 h-14 rounded-full bg-yellow-500 hover:bg-yellow-400 flex items-center justify-center transition-colors"
                    >
                      {isPaused ? <Play className="w-6 h-6 text-black" /> : <Pause className="w-6 h-6 text-black" />}
                    </button>
                    <button
                      onClick={stopRecording}
                      className="w-20 h-20 rounded-full bg-red-500 hover:bg-red-400 flex items-center justify-center transition-colors"
                    >
                      <Square className="w-8 h-8 text-white" />
                    </button>
                  </>
                )}

                {audioUrl && (
                  <div className="flex items-center gap-4">
                    <audio src={audioUrl} controls className="h-12" />
                    <a
                      href={audioUrl}
                      download="recording.webm"
                      className="p-3 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black transition-colors"
                    >
                      <Download className="w-5 h-5" />
                    </a>
                    <button
                      onClick={clearRecording}
                      className="p-3 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-400 transition-colors"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                )}
              </div>

              {error && <p className="text-center text-red-400 mt-4">{error}</p>}
            </div>

            {/* Tips */}
            <div className="mt-8 grid md:grid-cols-3 gap-4">
              <div className="p-4 bg-neutral-900/50 border border-neutral-800 rounded-lg">
                <h3 className="font-semibold text-cyan-400 mb-2">Tip 1</h3>
                <p className="text-sm text-neutral-400">Use headphones to prevent audio feedback during recording</p>
              </div>
              <div className="p-4 bg-neutral-900/50 border border-neutral-800 rounded-lg">
                <h3 className="font-semibold text-cyan-400 mb-2">Tip 2</h3>
                <p className="text-sm text-neutral-400">Record in a quiet environment for best results</p>
              </div>
              <div className="p-4 bg-neutral-900/50 border border-neutral-800 rounded-lg">
                <h3 className="font-semibold text-cyan-400 mb-2">Tip 3</h3>
                <p className="text-sm text-neutral-400">Position mic 6-12 inches from your mouth</p>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
