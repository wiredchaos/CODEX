"use client"

import { StudioHeader } from "@/components/vss/studio-header"
import { StudioSidebar } from "@/components/vss/studio-sidebar"
import { ListMusic, Plus, Play, MoreHorizontal } from "lucide-react"

export default function PlaylistsPage() {
  const playlists = [
    { name: "Studio Sessions", tracks: 12, duration: "48 min" },
    { name: "Beat Drops", tracks: 8, duration: "32 min" },
    { name: "Ambient Mixes", tracks: 15, duration: "1h 12 min" },
  ]

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <StudioHeader currentRoom="playlists" />
      <div className="flex flex-1">
        <StudioSidebar />
        <main className="flex-1 p-8">
          <div className="max-w-4xl mx-auto space-y-6">
            <header className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-lg bg-cyan-500/20 border border-cyan-500/30">
                  <ListMusic className="w-6 h-6 text-cyan-400" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold">Playlists</h1>
                  <p className="text-sm text-neutral-400">Manage your studio playlists</p>
                </div>
              </div>
              <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-semibold transition-colors">
                <Plus className="w-4 h-4" />
                New Playlist
              </button>
            </header>

            <div className="space-y-3">
              {playlists.map((playlist) => (
                <div
                  key={playlist.name}
                  className="flex items-center justify-between p-4 rounded-lg bg-neutral-900/50 border border-neutral-800 hover:border-neutral-700 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <button className="p-3 rounded-full bg-cyan-500 hover:bg-cyan-400 text-black transition-colors">
                      <Play className="w-4 h-4" />
                    </button>
                    <div>
                      <p className="font-medium">{playlist.name}</p>
                      <p className="text-sm text-neutral-500">
                        {playlist.tracks} tracks • {playlist.duration}
                      </p>
                    </div>
                  </div>
                  <button className="p-2 rounded-lg hover:bg-neutral-800 transition-colors">
                    <MoreHorizontal className="w-5 h-5 text-neutral-400" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
