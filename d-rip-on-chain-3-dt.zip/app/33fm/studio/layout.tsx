import type React from "react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "VSS-33.3 | Virtual Signal Studio",
  description: "Professional audio production suite for 33.3FM Dogechain",
}

export default function StudioLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
