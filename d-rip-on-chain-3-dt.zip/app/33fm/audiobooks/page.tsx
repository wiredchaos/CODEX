"use client"

import { useState, useEffect } from "react"

export default function AudiobooksPage() {
  const [audiobooks, setAudiobooks] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch("/api/33fm/audiobooks")
      .then((r) => r.json())
      .then((data) => setAudiobooks(data.audiobooks || []))
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [])

  if (loading) {
    return (
      <main className="min-h-screen flex items-center justify-center">
        <div className="text-cyan-400">Loading Audiobooks...</div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8">
          <h1 className="text-4xl font-bold text-cyan-400 mb-2">33.3FM AUDIOBOOK LIBRARY</h1>
          <p className="text-neutral-400">Creator-narrated audiobooks minted on Dogechain</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {audiobooks.map((book) => (
            <div
              key={book.id}
              className="border border-neutral-800 rounded-xl overflow-hidden hover:border-cyan-500 transition-colors"
            >
              <div className="aspect-[3/4] bg-neutral-900 flex items-center justify-center">
                {book.coverArtUrl ? (
                  <img
                    src={book.coverArtUrl || "/placeholder.svg"}
                    alt={book.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="text-6xl">📚</div>
                )}
              </div>
              <div className="p-4">
                <h3 className="font-semibold truncate">{book.title}</h3>
                <p className="text-sm text-neutral-400 mt-1">by {book.author}</p>
                <p className="text-xs text-neutral-500 mt-1">Narrated by {book.narrator}</p>
                <div className="mt-3 flex items-center justify-between">
                  <span className="text-xs text-neutral-400">
                    {Math.floor(book.totalDuration / 3600)}h {Math.floor((book.totalDuration % 3600) / 60)}m
                  </span>
                  <button className="text-xs px-3 py-1 bg-cyan-500 rounded text-black font-medium hover:bg-cyan-400 transition-colors">
                    Listen
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {audiobooks.length === 0 && (
          <div className="text-center py-12">
            <p className="text-neutral-400">No audiobooks available yet</p>
          </div>
        )}
      </div>
    </main>
  )
}
