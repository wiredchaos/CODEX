"use client"

import { useState, useEffect } from "react"

export default function PodcastsPage() {
  const [podcasts, setPodcasts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch("/api/33fm/podcasts")
      .then((r) => r.json())
      .then((data) => setPodcasts(data.podcasts || []))
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [])

  if (loading) {
    return (
      <main className="min-h-screen flex items-center justify-center">
        <div className="text-cyan-400">Loading Podcasts...</div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8">
          <h1 className="text-4xl font-bold text-cyan-400 mb-2">33.3FM PODCASTS</h1>
          <p className="text-neutral-400">Creator shows, interviews, and audio series</p>
        </header>

        <div className="space-y-4">
          {podcasts.map((podcast) => (
            <div
              key={podcast.id}
              className="border border-neutral-800 rounded-xl p-6 hover:border-cyan-500 transition-colors"
            >
              <div className="flex gap-4">
                <div className="w-24 h-24 bg-neutral-900 rounded-lg flex items-center justify-center flex-shrink-0">
                  {podcast.coverArtUrl ? (
                    <img
                      src={podcast.coverArtUrl || "/placeholder.svg"}
                      alt={podcast.title}
                      className="w-full h-full object-cover rounded-lg"
                    />
                  ) : (
                    <div className="text-4xl">🎙️</div>
                  )}
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold">{podcast.title}</h3>
                  <p className="text-sm text-neutral-400 mt-1">by @{podcast.creator?.handle || "unknown"}</p>
                  {podcast.description && <p className="text-sm text-neutral-300 mt-2">{podcast.description}</p>}
                  <div className="flex items-center gap-4 mt-3">
                    {podcast.seasonNum && podcast.episodeNum && (
                      <span className="text-xs text-neutral-500">
                        S{podcast.seasonNum} E{podcast.episodeNum}
                      </span>
                    )}
                    <span className="text-xs text-neutral-500">{Math.floor(podcast.duration / 60)} min</span>
                    <span className="text-xs text-neutral-500">{podcast.playCount || 0} plays</span>
                  </div>
                </div>
                <button className="px-4 py-2 bg-cyan-500 rounded text-black font-medium hover:bg-cyan-400 transition-colors self-start">
                  Play
                </button>
              </div>
            </div>
          ))}
        </div>

        {podcasts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-neutral-400">No podcasts available yet</p>
          </div>
        )}
      </div>
    </main>
  )
}
