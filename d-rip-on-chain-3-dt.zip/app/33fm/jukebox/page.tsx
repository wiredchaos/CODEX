"use client"

import { useState, useEffect } from "react"
import Link from "next/link"

export default function JukeboxPage() {
  const [videos, setVideos] = useState<any[]>([])
  const [currentVideo, setCurrentVideo] = useState<any | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch("/api/33fm/videos")
      .then((r) => r.json())
      .then((data) => {
        setVideos(data.videos || [])
        if (data.videos?.length > 0) {
          setCurrentVideo(data.videos[0])
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [])

  if (loading) {
    return (
      <main className="min-h-screen flex items-center justify-center">
        <div className="text-cyan-400">Loading Jukebox...</div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <header className="max-w-7xl mx-auto mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-cyan-400 mb-2">33.3FM JUKEBOX</h1>
            <p className="text-neutral-400">24/7 Music Video Stream</p>
          </div>
          <Link
            href="/33fm/radio"
            className="px-4 py-2 border border-cyan-400 rounded text-cyan-400 hover:bg-cyan-400 hover:text-black transition-colors"
          >
            Switch to Radio
          </Link>
        </div>
      </header>

      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          {currentVideo ? (
            <div className="border border-neutral-800 rounded-xl overflow-hidden">
              <div className="aspect-video bg-neutral-900 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-6xl mb-4">📺</div>
                  <p className="text-xl font-medium">{currentVideo.title}</p>
                  <p className="text-sm text-neutral-400 mt-2">by @{currentVideo.creator?.handle || "unknown"}</p>
                </div>
              </div>
              <div className="p-4 border-t border-neutral-800">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-neutral-400">
                      {currentVideo.viewCount || 0} views • {currentVideo.boostCount || 0} boosts
                    </p>
                  </div>
                  <button className="px-4 py-2 bg-cyan-500 rounded text-black font-medium hover:bg-cyan-400 transition-colors">
                    Boost This Video
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="border border-neutral-800 rounded-xl p-12 text-center">
              <p className="text-neutral-400">No videos in queue</p>
            </div>
          )}
        </div>

        <div className="border border-neutral-800 rounded-xl p-4">
          <h2 className="text-xl font-semibold mb-4">Coming Up</h2>
          <div className="space-y-3 max-h-[600px] overflow-y-auto">
            {videos.slice(1, 11).map((video) => (
              <div
                key={video.id}
                className="border border-neutral-800 rounded-lg p-3 cursor-pointer hover:border-cyan-500 transition-colors"
                onClick={() => setCurrentVideo(video)}
              >
                <p className="font-medium truncate">{video.title}</p>
                <p className="text-xs text-neutral-400 mt-1">@{video.creator?.handle || "unknown"}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </main>
  )
}
