import Link from "next/link"
import { ArrowLeft, Layers } from "lucide-react"

const layerTypes = [
  { name: "Surface Layer", visibility: "Public", description: "Visible to all operatives" },
  { name: "Shadow Layer", visibility: "Hidden", description: "Requires spectral clearance" },
  { name: "Deep Layer", visibility: "Encrypted", description: "Cipher-gated access only" },
  { name: "Void Layer", visibility: "Unknown", description: "Existence unconfirmed" },
]

export default function LayerSelectionPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <Link
        href="/rogue-frequency"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-accent transition-colors mb-8"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Rogue Frequency
      </Link>

      <div className="mb-12">
        <div className="flex items-center gap-4 mb-4">
          <div className="p-4 rounded-xl bg-accent/10">
            <Layers className="h-8 w-8 text-accent" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-accent">Layer Selection</h1>
            <p className="text-muted-foreground">Navigate between reality layers</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
        {layerTypes.map((layer) => (
          <div key={layer.name} className="p-6 rounded-xl border border-border bg-card/50">
            <div className="flex items-center gap-3 mb-4">
              <span
                className={`text-xs px-2 py-1 rounded ${
                  layer.visibility === "Public"
                    ? "bg-accent/20 text-accent"
                    : layer.visibility === "Hidden"
                      ? "bg-amber-500/20 text-amber-400"
                      : layer.visibility === "Encrypted"
                        ? "bg-fuchsia-500/20 text-fuchsia-400"
                        : "bg-muted text-muted-foreground"
                }`}
              >
                {layer.visibility}
              </span>
            </div>
            <h3 className="text-lg font-semibold mb-2">{layer.name}</h3>
            <p className="text-sm text-muted-foreground">{layer.description}</p>
          </div>
        ))}
      </div>

      <div className="p-6 rounded-xl border border-accent/30 bg-accent/5">
        <h2 className="text-lg font-bold mb-2">Active</h2>
        <p className="text-sm text-muted-foreground">
          Layer navigation system online. Additional layers unlock with clearance progression.
        </p>
      </div>
    </div>
  )
}
