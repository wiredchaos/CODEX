import Link from "next/link"
import { ArrowLeft, Lock } from "lucide-react"
import { CinematicHeader } from "@/components/akashic/cinematic-header"
import { DossierSection } from "@/components/akashic/dossier-section"
import { EnterChaosCTA } from "@/components/akashic/enter-chaos-cta"

const layers = [
  { level: 1, name: "Entry Chamber", status: "UNLOCKED", cipher: "Basic", desc: "Initiation protocols" },
  { level: 2, name: "Archives Alpha", status: "UNLOCKED", cipher: "Standard", desc: "Historical records" },
  { level: 3, name: "Deep Storage", status: "ENCRYPTED", cipher: "Advanced", desc: "Classified data" },
  { level: 4, name: "Core Vault", status: "ENCRYPTED", cipher: "Complex", desc: "Origin fragments" },
  { level: 5, name: "Omega Chamber", status: "SEALED", cipher: "Master", desc: "The final truth" },
]

export default function Vault33Page() {
  return (
    <div className="min-h-screen bg-black -mx-4 sm:-mx-6 lg:-mx-8 -my-8 px-4 sm:px-6 lg:px-8 scanlines film-grain circuit-bg">
      {/* Back nav */}
      <div className="absolute top-4 left-4 z-20">
        <Link
          href="/rogue-frequency"
          className="inline-flex items-center gap-2 text-sm text-white/50 hover:text-[#FF3131] transition-colors font-mono tracking-wider"
        >
          <ArrowLeft className="h-4 w-4" />
          EXIT VAULT
        </Link>
      </div>

      {/* Cinematic Header */}
      <CinematicHeader
        title="VAULT 33"
        subtitle="CIPHER-GATED ARCHIVES"
        chapter="SECURE FACILITY"
        tagline="Only those who solve the cipher shall pass through the gates"
      />

      <div className="max-w-4xl mx-auto pb-16">
        <DossierSection title="SECURITY LAYERS" classification="ACCESS MATRIX">
          <div className="space-y-4">
            {layers.map((layer) => {
              const isUnlocked = layer.status === "UNLOCKED"
              const isSealed = layer.status === "SEALED"
              const accentColor = isUnlocked ? "#00FFFF" : isSealed ? "#FF3131" : "#A35FFF"

              return (
                <div
                  key={layer.level}
                  className="relative p-6 rounded-lg border bg-black/50"
                  style={{
                    borderColor: `${accentColor}30`,
                    opacity: isSealed ? 0.5 : 1,
                  }}
                >
                  {/* Accent bar */}
                  <div
                    className="absolute left-0 top-0 bottom-0 w-1 rounded-l-lg"
                    style={{ background: accentColor, boxShadow: `0 0 10px ${accentColor}` }}
                  />

                  <div className="flex items-center justify-between pl-4">
                    <div className="flex items-center gap-6">
                      <div className="text-3xl font-bold font-mono" style={{ color: accentColor }}>
                        {String(layer.level).padStart(2, "0")}
                      </div>
                      <div>
                        <h3 className="font-bold text-white tracking-wider">{layer.name}</h3>
                        <p className="text-xs text-white/40 font-mono">{layer.desc}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <span className="text-xs font-mono text-white/40">CIPHER: {layer.cipher}</span>
                      <span
                        className="text-xs font-mono px-3 py-1 rounded border"
                        style={{
                          color: accentColor,
                          borderColor: accentColor,
                          background: `${accentColor}10`,
                        }}
                      >
                        {layer.status}
                      </span>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </DossierSection>

        <div className="my-12 p-6 rounded-lg border border-[#FF3131]/30 bg-[#FF3131]/5">
          <div className="flex items-center gap-3 mb-2">
            <Lock className="h-5 w-5 text-[#FF3131]" />
            <span className="film-label">PROTOTYPE STATUS</span>
          </div>
          <p className="text-white/60 text-sm font-mono">
            Full cipher system with puzzle mechanics and reward tracking currently in development phase.
          </p>
        </div>

        <EnterChaosCTA href="/rogue-frequency" label="RETURN TO ROGUE FREQUENCY" />
      </div>
    </div>
  )
}
