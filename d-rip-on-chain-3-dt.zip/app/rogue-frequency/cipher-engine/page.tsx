import Link from "next/link"
import { ArrowLeft, Key, Binary, Hash, Fingerprint } from "lucide-react"
import { CinematicHeader } from "@/components/akashic/cinematic-header"
import { DossierSection } from "@/components/akashic/dossier-section"
import { FilmCard } from "@/components/akashic/film-card"
import { EnterChaosCTA } from "@/components/akashic/enter-chaos-cta"

const cipherTypes = [
  { name: "Substitution", icon: Hash, level: "Basic", color: "#00FFFF", desc: "Letter replacement patterns" },
  { name: "Binary", icon: Binary, level: "Standard", color: "#00FFFF", desc: "Digital encoding systems" },
  { name: "Spectral", icon: Fingerprint, level: "Advanced", color: "#A35FFF", desc: "Frequency-based encryption" },
  { name: "Quantum", icon: Key, level: "Master", color: "#FF3131", desc: "Multi-dimensional keys" },
]

export default function CipherEnginePage() {
  return (
    <div className="min-h-screen bg-black -mx-4 sm:-mx-6 lg:-mx-8 -my-8 px-4 sm:px-6 lg:px-8 scanlines film-grain circuit-bg">
      {/* Back nav */}
      <div className="absolute top-4 left-4 z-20">
        <Link
          href="/rogue-frequency"
          className="inline-flex items-center gap-2 text-sm text-white/50 hover:text-[#FF3131] transition-colors font-mono tracking-wider"
        >
          <ArrowLeft className="h-4 w-4" />
          EXIT ENGINE
        </Link>
      </div>

      {/* Cinematic Header */}
      <CinematicHeader
        title="CIPHER ENGINE"
        subtitle="ENCRYPTION TOOLKIT"
        chapter="CRYPTOGRAPHY LAB"
        tagline="Master the art of encoding and decoding hidden transmissions"
      />

      <div className="max-w-5xl mx-auto pb-16">
        <DossierSection title="CIPHER PROTOCOLS" classification="ENCRYPTION MATRIX">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {cipherTypes.map((cipher) => (
              <FilmCard
                key={cipher.name}
                title={`${cipher.name.toUpperCase()} CIPHER`}
                chapter={cipher.level.toUpperCase()}
                accentColor={cipher.color === "#FF3131" ? "red" : "cyan"}
              >
                <div className="flex items-center gap-4">
                  <div
                    className="p-3 rounded-lg"
                    style={{ background: `${cipher.color}15`, border: `1px solid ${cipher.color}30` }}
                  >
                    <cipher.icon className="h-6 w-6" style={{ color: cipher.color }} />
                  </div>
                  <p className="text-sm text-white/60">{cipher.desc}</p>
                </div>
              </FilmCard>
            ))}
          </div>
        </DossierSection>

        {/* Interactive Demo Area */}
        <DossierSection title="CIPHER INTERFACE" classification="PROTOTYPE">
          <div className="p-8 rounded-lg border border-[#00FFFF]/20 bg-black/50 text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-[#00FFFF]/10 flex items-center justify-center">
              <Key className="h-8 w-8 text-[#00FFFF]" />
            </div>
            <h3 className="text-lg font-mono text-[#00FFFF] tracking-wider mb-2">ENCODE / DECODE</h3>
            <p className="text-white/40 text-sm font-mono max-w-md mx-auto">
              Full cipher toolkit with interactive encode/decode interface and training modules coming in next cycle.
            </p>
          </div>
        </DossierSection>

        <EnterChaosCTA href="/rogue-frequency" label="RETURN TO ROGUE FREQUENCY" />
      </div>
    </div>
  )
}
