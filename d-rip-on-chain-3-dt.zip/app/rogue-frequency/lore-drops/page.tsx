import Link from "next/link"
import { ArrowLeft, Eye, EyeOff, Sparkles } from "lucide-react"
import { CinematicHeader } from "@/components/akashic/cinematic-header"
import { DossierSection } from "@/components/akashic/dossier-section"
import { EnterChaosCTA } from "@/components/akashic/enter-chaos-cta"

const loreDrops = [
  { id: 1, title: "Origin Signal", type: "Visible", date: "Cycle 1", read: true },
  { id: 2, title: "The First Frequency", type: "Visible", date: "Cycle 1", read: true },
  { id: 3, title: "Shadow Protocol", type: "Semi-Hidden", date: "Cycle 2", read: false },
  { id: 4, title: "Cipher of the Ancients", type: "Deep", date: "Cycle 3", read: false },
  { id: 5, title: "[REDACTED]", type: "Classified", date: "Unknown", read: false },
]

const typeConfig = {
  Visible: { color: "#00FFFF", icon: Eye },
  "Semi-Hidden": { color: "#FFE066", icon: Sparkles },
  Deep: { color: "#A35FFF", icon: EyeOff },
  Classified: { color: "#FF3131", icon: EyeOff },
}

export default function LoreDropsPage() {
  return (
    <div className="min-h-screen bg-black -mx-4 sm:-mx-6 lg:-mx-8 -my-8 px-4 sm:px-6 lg:px-8 scanlines film-grain circuit-bg">
      {/* Back nav */}
      <div className="absolute top-4 left-4 z-20">
        <Link
          href="/rogue-frequency"
          className="inline-flex items-center gap-2 text-sm text-white/50 hover:text-[#FF3131] transition-colors font-mono tracking-wider"
        >
          <ArrowLeft className="h-4 w-4" />
          EXIT ARCHIVE
        </Link>
      </div>

      {/* Cinematic Header */}
      <CinematicHeader
        title="LORE DROPS"
        subtitle="NARRATIVE FRAGMENTS"
        chapter="INTEL ARCHIVE"
        tagline="Each fragment reveals a piece of the greater truth"
      />

      <div className="max-w-4xl mx-auto pb-16">
        <DossierSection title="ARCHIVED TRANSMISSIONS" classification="LORE MANIFEST">
          <div className="space-y-4">
            {loreDrops.map((drop) => {
              const config = typeConfig[drop.type as keyof typeof typeConfig]
              const IconComponent = config.icon

              return (
                <div
                  key={drop.id}
                  className="relative p-5 rounded-lg border bg-black/50"
                  style={{
                    borderColor: drop.type === "Classified" ? "rgba(255,255,255,0.1)" : `${config.color}30`,
                    opacity: drop.type === "Classified" ? 0.4 : 1,
                  }}
                >
                  {/* Accent bar */}
                  <div
                    className="absolute left-0 top-0 bottom-0 w-1 rounded-l-lg"
                    style={{ background: config.color, boxShadow: `0 0 10px ${config.color}` }}
                  />

                  <div className="flex items-center justify-between pl-4">
                    <div className="flex items-center gap-4">
                      <IconComponent className="h-5 w-5" style={{ color: config.color }} />
                      <div>
                        <h3 className="font-bold text-white tracking-wider">{drop.title}</h3>
                        <p className="text-xs text-white/30 font-mono">{drop.date}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      {drop.read && (
                        <span className="text-xs font-mono text-[#00FFFF]/60 px-2 py-0.5 rounded bg-[#00FFFF]/10">
                          READ
                        </span>
                      )}
                      <span
                        className="text-xs font-mono px-3 py-1 rounded border"
                        style={{
                          color: config.color,
                          borderColor: config.color,
                          background: `${config.color}10`,
                        }}
                      >
                        {drop.type.toUpperCase()}
                      </span>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </DossierSection>

        <div className="my-12 p-6 rounded-lg border border-[#00FFFF]/30 bg-[#00FFFF]/5">
          <span className="film-label mb-3 block w-fit">SYSTEM STATUS</span>
          <p className="text-white/60 text-sm font-mono">
            New lore drops released with each broadcast cycle. Hidden drops require cipher completion to access.
          </p>
        </div>

        <EnterChaosCTA href="/rogue-frequency" label="RETURN TO ROGUE FREQUENCY" />
      </div>
    </div>
  )
}
