import Link from "next/link"
import { ArrowLeft, Radio, Eye, Shield, Zap, Crown, Lock, Layers, Target, Skull, BookOpen } from "lucide-react"

const signalLevels = [
  { level: 1, name: "Static Initiate", clearance: "Entry", unlocked: true },
  { level: 2, name: "Frequency Scout", clearance: "Basic", unlocked: true },
  { level: 3, name: "Signal Adept", clearance: "Standard", unlocked: true },
  { level: 4, name: "Wave Rider", clearance: "Elevated", unlocked: false },
  { level: 5, name: "Spectral Operative", clearance: "High", unlocked: false },
  { level: 6, name: "Shadow Caster", clearance: "Secret", unlocked: false },
  { level: 7, name: "Cipher Lord", clearance: "Top Secret", unlocked: false },
  { level: 8, name: "Void Walker", clearance: "Black", unlocked: false },
  { level: 9, name: "Chaos Architect", clearance: "Omega", unlocked: false },
  { level: 10, name: "Sovereign", clearance: "Absolute", unlocked: false },
]

const features = [
  {
    name: "Cryptic Intelligence Drops",
    description: "Encrypted data packages containing hidden intel, cipher challenges, and lore fragments.",
    icon: Eye,
  },
  {
    name: "Spectral Clearance System",
    description: "Progress through 10 security tiers, each unlocking deeper access to shadow operations.",
    icon: Shield,
  },
  {
    name: "Shadow Current Training",
    description: "Master frequency manipulation, signal interception, and spectral navigation techniques.",
    icon: Zap,
  },
  {
    name: "Sovereign Protocol",
    description: "The ultimate directive—complete autonomy for those who reach Level 10 clearance.",
    icon: Crown,
  },
]

const argModules = [
  { name: "Vault 33 Portal", icon: Lock, status: "Active" },
  { name: "Layer Selection", icon: Layers, status: "Active" },
  { name: "Puzzle Chamber", icon: Target, status: "Prototype" },
  { name: "Cipher Engine", icon: Skull, status: "Prototype" },
  { name: "Lore Drop Page", icon: BookOpen, status: "Active" },
]

export default function RogueFrequencyPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <Link
        href="/"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-accent transition-colors mb-8"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Patch Selection
      </Link>

      <div className="mb-12">
        <div className="flex items-center gap-4 mb-4">
          <div className="relative">
            <div className="w-16 h-16 rounded-full bg-accent/80" />
            <div className="absolute inset-0 w-16 h-16 rounded-full bg-accent/40 blur-lg" />
          </div>
          <div>
            <h1 className="text-3xl sm:text-4xl font-bold text-accent">ROGUE FREQUENCY PATCH</h1>
            <p className="text-muted-foreground">Shadow operations. Signal intelligence.</p>
          </div>
        </div>
      </div>

      {/* Signal Levels */}
      <section className="mb-12">
        <div className="flex items-center gap-2 mb-6">
          <Radio className="h-5 w-5 text-accent" />
          <h2 className="text-xl font-bold">10 Signal Levels</h2>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          {signalLevels.map((level) => (
            <div
              key={level.level}
              className={`p-4 rounded-lg border text-center transition-all ${
                level.unlocked ? "border-accent/50 bg-accent/10" : "border-border bg-card/30 opacity-60"
              }`}
            >
              <div className={`text-2xl font-bold mb-1 ${level.unlocked ? "text-accent" : "text-muted-foreground"}`}>
                {level.level}
              </div>
              <div className="text-xs font-medium truncate">{level.name}</div>
              <div className={`text-xs mt-1 ${level.unlocked ? "text-accent/70" : "text-muted-foreground/50"}`}>
                {level.clearance}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Core Features */}
      <section className="mb-12">
        <h2 className="text-xl font-bold mb-6">Core Systems</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {features.map((feature) => (
            <div
              key={feature.name}
              className="p-6 rounded-xl border border-border bg-card/50 hover:border-accent/30 transition-all"
            >
              <div className="p-3 rounded-lg bg-accent/10 w-fit mb-4">
                <feature.icon className="h-6 w-6 text-accent" />
              </div>
              <h3 className="text-lg font-semibold mb-2">{feature.name}</h3>
              <p className="text-sm text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ARG Modules */}
      <section className="mb-12">
        <h2 className="text-xl font-bold mb-6">ARG Module Screens</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {argModules.map((module) => (
            <div
              key={module.name}
              className="p-4 rounded-lg border border-border bg-card/50 hover:border-accent/30 transition-all"
            >
              <div className="flex items-center gap-3 mb-2">
                <module.icon className="h-5 w-5 text-accent" />
                <span
                  className={`text-xs px-2 py-0.5 rounded ${
                    module.status === "Active" ? "bg-accent/20 text-accent" : "bg-muted text-muted-foreground"
                  }`}
                >
                  {module.status}
                </span>
              </div>
              <h3 className="text-sm font-medium">{module.name}</h3>
            </div>
          ))}
        </div>
      </section>

      {/* Roadmap */}
      <section className="p-6 rounded-xl border border-border bg-card/30">
        <h2 className="text-xl font-bold mb-4">Shadow Operations Roadmap</h2>
        <ul className="space-y-2 text-sm text-muted-foreground">
          <li className="flex items-start gap-2">
            <span className="text-accent mt-1">→</span>
            <span>Real-time signal interception training modules</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-accent mt-1">→</span>
            <span>Cipher engine with progressive difficulty layers</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-accent mt-1">→</span>
            <span>Spectral clearance verification system</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-accent mt-1">→</span>
            <span>Shadow current field exercises</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-accent mt-1">→</span>
            <span>Sovereign Protocol activation pathway</span>
          </li>
        </ul>
      </section>
    </div>
  )
}
