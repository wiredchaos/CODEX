import Link from "next/link"
import { ArrowLeft, Puzzle } from "lucide-react"

const puzzles = [
  { name: "Entry Cipher", difficulty: "Basic", status: "Available", reward: "Archive Access" },
  { name: "Signal Decode", difficulty: "Standard", status: "Available", reward: "Intel Fragment" },
  { name: "Matrix Break", difficulty: "Advanced", status: "Locked", reward: "Spectral Key" },
  { name: "Void Sequence", difficulty: "Master", status: "Locked", reward: "Classified" },
]

export default function PuzzleChamberPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <Link
        href="/rogue-frequency"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-accent transition-colors mb-8"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Rogue Frequency
      </Link>

      <div className="mb-12">
        <div className="flex items-center gap-4 mb-4">
          <div className="p-4 rounded-xl bg-accent/10">
            <Puzzle className="h-8 w-8 text-accent" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-accent">Puzzle Chamber</h1>
            <p className="text-muted-foreground">Challenge archive and reward system</p>
          </div>
        </div>
      </div>

      <div className="space-y-4 mb-12">
        {puzzles.map((puzzle) => (
          <div
            key={puzzle.name}
            className={`p-6 rounded-xl border ${
              puzzle.status === "Available" ? "border-accent/30 bg-card/50" : "border-border bg-card/20 opacity-60"
            }`}
          >
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold mb-1">{puzzle.name}</h3>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <span>Difficulty: {puzzle.difficulty}</span>
                  <span>Reward: {puzzle.reward}</span>
                </div>
              </div>
              <span
                className={`text-xs px-3 py-1 rounded-full ${
                  puzzle.status === "Available" ? "bg-accent/20 text-accent" : "bg-muted text-muted-foreground"
                }`}
              >
                {puzzle.status}
              </span>
            </div>
          </div>
        ))}
      </div>

      <div className="p-6 rounded-xl border border-accent/30 bg-accent/5">
        <h2 className="text-lg font-bold mb-2">Prototype</h2>
        <p className="text-sm text-muted-foreground">
          Interactive puzzle engine with hint system and leaderboards in development.
        </p>
      </div>
    </div>
  )
}
