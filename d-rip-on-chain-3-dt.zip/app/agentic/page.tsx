"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AlertCircle, Brain, Scale, Shield, TrendingUp, Zap } from "lucide-react"
import type { AgenticResponse } from "@/lib/agentic"

const GENERALS = [
  { id: "MATHEMATICS", name: "Mathematics" },
  { id: "ENGINEERING", name: "Engineering" },
  { id: "ARCHITECTURE_CAD", name: "Architecture + CAD" },
  { id: "INSURANCE", name: "Insurance" },
  { id: "TAXATION", name: "Taxation" },
]

const BRAIN_LAYERS = [
  { id: "ANALYTICAL", name: "Analytical Brain", icon: Scale, color: "text-blue-500" },
  { id: "ENGINEERING", name: "Engineering Brain", icon: Zap, color: "text-yellow-500" },
  { id: "ENTERPRISE_AI", name: "Enterprise AI Brain", icon: Shield, color: "text-green-500" },
  { id: "ECONOMIC", name: "Economic Brain", icon: TrendingUp, color: "text-purple-500" },
  { id: "INTERPRETATION", name: "Interpretation Brain", icon: Brain, color: "text-cyan-500" },
]

export default function AgenticCommandPage() {
  const [selectedGeneral, setSelectedGeneral] = useState<string>("")
  const [query, setQuery] = useState<string>("")
  const [loading, setLoading] = useState(false)
  const [response, setResponse] = useState<AgenticResponse | null>(null)

  const handleSubmit = async () => {
    if (!selectedGeneral || !query) return

    setLoading(true)
    try {
      const res = await fetch("/api/agentic", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          generalId: selectedGeneral,
          query,
          requireDebate: true,
          requireWeb3Translation: true,
        }),
      })

      const data = await res.json()
      setResponse(data)
    } catch (error) {
      console.error("Error:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Agentic Command Specification</h1>
        <p className="text-muted-foreground">
          Constitutional framework governing all WIRED CHAOS Generals with 5-stack brain, adversarial debate, and
          Anti-Moloch governance
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-3 mb-8">
        {BRAIN_LAYERS.map((layer) => {
          const Icon = layer.icon
          return (
            <Card key={layer.id}>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Icon className={`h-5 w-5 ${layer.color}`} />
                  <CardTitle className="text-sm">{layer.name}</CardTitle>
                </div>
              </CardHeader>
            </Card>
          )
        })}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Query a General</CardTitle>
            <CardDescription>Select a general and submit your query for full agentic processing</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Select General</label>
              <Select value={selectedGeneral} onValueChange={setSelectedGeneral}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a general..." />
                </SelectTrigger>
                <SelectContent>
                  {GENERALS.map((general) => (
                    <SelectItem key={general.id} value={general.id}>
                      {general.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Your Query</label>
              <Textarea
                placeholder="Enter your question or problem statement..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                rows={6}
              />
            </div>

            <Button onClick={handleSubmit} disabled={!selectedGeneral || !query || loading} className="w-full">
              {loading ? "Processing through 5-stack brain..." : "Submit Query"}
            </Button>
          </CardContent>
        </Card>

        {response && (
          <Card>
            <CardHeader>
              <CardTitle>Agentic Response</CardTitle>
              <CardDescription>
                Confidence: {(response.confidenceScore * 100).toFixed(0)}% | Deployment Ready:{" "}
                {response.deploymentReady ? "✅" : "❌"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="conclusion">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="conclusion">Conclusion</TabsTrigger>
                  <TabsTrigger value="debate">Debate</TabsTrigger>
                  <TabsTrigger value="web3">Web3</TabsTrigger>
                  <TabsTrigger value="safety">Safety</TabsTrigger>
                </TabsList>

                <TabsContent value="conclusion" className="space-y-4">
                  <div>
                    <h3 className="font-semibold mb-2">Interpretation</h3>
                    <p className="text-sm text-muted-foreground">{response.interpretation}</p>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Triangulated Conclusion</h3>
                    <p className="text-sm">{response.triangulatedConclusion}</p>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Industry Reasoning</h3>
                    <p className="text-sm text-muted-foreground">{response.industryReasoning}</p>
                  </div>
                </TabsContent>

                <TabsContent value="debate" className="space-y-4">
                  <div>
                    <Badge variant="outline" className="mb-2">
                      ADVOCATE
                    </Badge>
                    <p className="text-sm">{response.debateSummary.advocatePosition}</p>
                  </div>
                  <div>
                    <Badge variant="outline" className="mb-2">
                      SKEPTIC
                    </Badge>
                    <ul className="text-sm space-y-1">
                      {response.debateSummary.skepticChallenges.map((challenge, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <AlertCircle className="h-4 w-4 mt-0.5 text-yellow-500 flex-shrink-0" />
                          <span>{challenge}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <Badge variant="outline" className="mb-2">
                      REGULATOR
                    </Badge>
                    <ul className="text-sm space-y-1">
                      {response.debateSummary.regulatorFindings.map((finding, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <Shield className="h-4 w-4 mt-0.5 text-green-500 flex-shrink-0" />
                          <span>{finding}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </TabsContent>

                <TabsContent value="web3" className="space-y-4">
                  <div>
                    <h3 className="font-semibold mb-2">Web2 Context</h3>
                    <p className="text-sm text-muted-foreground">{response.web2Description}</p>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Web3 Translation</h3>
                    <p className="text-sm">{response.web3Translation}</p>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Smart Contract Applications</h3>
                    <ul className="text-sm space-y-1">
                      {response.smartContractApplications.map((app, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <Zap className="h-4 w-4 mt-0.5 text-purple-500 flex-shrink-0" />
                          <span>{app}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </TabsContent>

                <TabsContent value="safety" className="space-y-4">
                  <div>
                    <h3 className="font-semibold mb-2">Anti-Moloch Checks</h3>
                    <div className="space-y-2">
                      {response.complianceSafetyChecks.map((check) => (
                        <div key={check.id} className="flex items-start gap-2 text-sm">
                          {check.passed ? (
                            <Shield className="h-4 w-4 mt-0.5 text-green-500 flex-shrink-0" />
                          ) : (
                            <AlertCircle className="h-4 w-4 mt-0.5 text-red-500 flex-shrink-0" />
                          )}
                          <div>
                            <p className="font-medium">{check.rule}</p>
                            <p className="text-muted-foreground text-xs">{check.details}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Next Steps</h3>
                    <ul className="text-sm space-y-1">
                      {response.nextSteps.map((step, i) => (
                        <li key={i}>
                          {i + 1}. {step}
                        </li>
                      ))}
                    </ul>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
