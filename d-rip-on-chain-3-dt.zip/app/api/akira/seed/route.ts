import { type NextRequest, NextResponse } from "next/server"
import type { StorySeed, StoryGenre, StoryTone } from "@/config/story-engine"

// POST /api/akira/seed - Generate story seed JSON
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { prompt, genre, tone } = body as {
      prompt: string
      genre?: StoryGenre
      tone?: StoryTone
    }

    if (!prompt) {
      return NextResponse.json({ error: "Prompt is required" }, { status: 400 })
    }

    // Simulated AKIRA-SEED agent response
    const seed: StorySeed = {
      id: `seed-${Date.now()}`,
      title: extractTitle(prompt),
      genre: genre || "cyberpunk",
      tone: tone || "dark",
      characters: generateCharacters(prompt),
      beats: generateBeats(prompt),
      world_context: generateWorldContext(prompt),
      created_at: new Date().toISOString(),
      status: "draft",
    }

    return NextResponse.json({
      success: true,
      agent: "AKIRA-SEED",
      seed,
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to generate seed" }, { status: 500 })
  }
}

function extractTitle(prompt: string): string {
  const words = prompt.split(" ").slice(0, 4)
  return `The ${words[0] || "Unknown"} ${words[1] || "Chronicle"}`
}

function generateCharacters(prompt: string) {
  return [
    {
      name: "Protagonist",
      archetype: "The Seeker",
      role: "protagonist" as const,
      traits: ["determined", "curious", "haunted"],
      secret: "Carries a fragment of the original code",
    },
  ]
}

function generateBeats(prompt: string) {
  return [
    { act: 1, title: "Inciting Incident", description: "The world shifts", tension_level: 2 as const },
    { act: 2, title: "Rising Action", description: "Forces converge", tension_level: 3 as const },
    { act: 3, title: "Climax", description: "Truth revealed", tension_level: 5 as const },
  ]
}

function generateWorldContext(prompt: string) {
  return {
    setting: "The Wired Chaos Network",
    era: "Post-Digital",
    rules: ["Reality is mutable", "Data has weight", "Memory persists"],
    factions: ["The Collective", "Rogue Frequencies", "The Archive"],
    lore_connections: ["Akira Codex", "Vault 33"],
  }
}
