import { type NextRequest, NextResponse } from "next/server"
import { generateVideoPrompt } from "@/lib/video/generator"
import type { VideoGenerationRequest } from "@/lib/video/types"

export async function POST(request: NextRequest) {
  try {
    const body: VideoGenerationRequest = await request.json()

    // Validate required fields
    if (!body.category || !body.avatarId || !body.environmentId || !body.provider) {
      return NextResponse.json(
        { error: "Missing required fields: category, avatarId, environmentId, provider" },
        { status: 400 },
      )
    }

    // Generate the video prompt using the library
    const result = generateVideoPrompt(body)

    return NextResponse.json(result)
  } catch (error) {
    console.error("Video prompt generation error:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to generate video prompt" },
      { status: 500 },
    )
  }
}
