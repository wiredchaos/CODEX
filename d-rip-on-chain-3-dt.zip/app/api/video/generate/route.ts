import { type NextRequest, NextResponse } from "next/server"
import { ENVIRONMENTS, SCENE_RULES, type VideoGenerateRequest } from "@/config/video-engine"

export async function POST(request: NextRequest) {
  try {
    const body: VideoGenerateRequest = await request.json()
    const { seed_json, avatar_style, motion_type, duration, environment } = body

    // Validate duration
    const durationNum = Number.parseInt(duration)
    if (durationNum < SCENE_RULES.min_video_duration || durationNum > SCENE_RULES.max_video_duration) {
      return NextResponse.json(
        {
          error: `Duration must be between ${SCENE_RULES.min_video_duration}-${SCENE_RULES.max_video_duration} seconds`,
        },
        { status: 400 },
      )
    }

    // Find environment config
    const envConfig = ENVIRONMENTS.find((e) => e.id === environment)
    if (!envConfig) {
      return NextResponse.json({ error: "Invalid environment ID" }, { status: 400 })
    }

    // Generate video config (placeholder - would connect to Runway/Pika/Spline)
    const videoConfig = {
      id: `vid_${Date.now()}`,
      seed: seed_json,
      avatar_style,
      motion_type,
      duration_seconds: durationNum,
      environment: {
        id: envConfig.id,
        lighting: envConfig.lighting,
        elements: envConfig.elements.slice(0, SCENE_RULES.max_objects), // Enforce scene density
      },
      render_settings: {
        resolution: "1080p",
        fps: 30,
        codec: "h264",
      },
      status: "queued",
      estimated_completion: new Date(Date.now() + 60000).toISOString(),
    }

    return NextResponse.json({
      success: true,
      video_config: videoConfig,
      message: "Video generation queued",
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to queue video generation" }, { status: 500 })
  }
}
