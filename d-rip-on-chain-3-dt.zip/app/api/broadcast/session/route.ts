/**
 * AVATAR LIVE MODE v33 — SESSION API
 * Manages broadcast session lifecycle
 */

import { type NextRequest, NextResponse } from "next/server"
import { createBroadcastSession, type BroadcastSessionManager } from "@/lib/broadcast"

// In-memory session store (would use Redis/DB in production)
const activeSessions = new Map<string, BroadcastSessionManager>()

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { action, userId, avatarId, config, sessionId, viewerId, triggerAction, isSubscriber, viewerCount } = body

    switch (action) {
      case "create": {
        if (!userId || !avatarId) {
          return NextResponse.json({ error: "userId and avatarId required" }, { status: 400 })
        }

        const session = createBroadcastSession(userId, avatarId, config)
        const sessionData = session.getSession()
        activeSessions.set(sessionData.id, session)

        return NextResponse.json({
          success: true,
          session: sessionData,
        })
      }

      case "start": {
        const session = activeSessions.get(sessionId)
        if (!session) {
          return NextResponse.json({ error: "Session not found" }, { status: 404 })
        }

        await session.start()
        return NextResponse.json({
          success: true,
          session: session.getSession(),
        })
      }

      case "pause": {
        const session = activeSessions.get(sessionId)
        if (!session) {
          return NextResponse.json({ error: "Session not found" }, { status: 404 })
        }

        await session.pause()
        return NextResponse.json({
          success: true,
          session: session.getSession(),
        })
      }

      case "resume": {
        const session = activeSessions.get(sessionId)
        if (!session) {
          return NextResponse.json({ error: "Session not found" }, { status: 404 })
        }

        await session.resume()
        return NextResponse.json({
          success: true,
          session: session.getSession(),
        })
      }

      case "end": {
        const session = activeSessions.get(sessionId)
        if (!session) {
          return NextResponse.json({ error: "Session not found" }, { status: 404 })
        }

        await session.end()
        const finalSession = session.getSession()
        activeSessions.delete(sessionId)

        return NextResponse.json({
          success: true,
          session: finalSession,
          eventLog: session.getEventLog(),
        })
      }

      case "trigger_fx": {
        const session = activeSessions.get(sessionId)
        if (!session) {
          return NextResponse.json({ error: "Session not found" }, { status: 404 })
        }

        const { event } = body
        session.triggerTimelineFx(event)

        return NextResponse.json({
          success: true,
          session: session.getSession(),
        })
      }

      case "viewer_trigger": {
        const session = activeSessions.get(sessionId)
        if (!session) {
          return NextResponse.json({ error: "Session not found" }, { status: 404 })
        }

        session.processViewerTrigger(viewerId, triggerAction, isSubscriber)

        return NextResponse.json({
          success: true,
          session: session.getSession(),
        })
      }

      case "update_viewers": {
        const session = activeSessions.get(sessionId)
        if (!session) {
          return NextResponse.json({ error: "Session not found" }, { status: 404 })
        }

        session.updateViewerCount(viewerCount)

        return NextResponse.json({
          success: true,
          session: session.getSession(),
        })
      }

      case "health": {
        const session = activeSessions.get(sessionId)
        if (!session) {
          return NextResponse.json({ error: "Session not found" }, { status: 404 })
        }

        return NextResponse.json({
          success: true,
          health: session.getStreamHealth(),
          session: session.getSession(),
        })
      }

      default:
        return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }
  } catch (error) {
    console.error("[Broadcast API] Error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const sessionId = searchParams.get("sessionId")

  if (sessionId) {
    const session = activeSessions.get(sessionId)
    if (!session) {
      return NextResponse.json({ error: "Session not found" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      session: session.getSession(),
      health: session.getStreamHealth(),
      eventLog: session.getEventLog().slice(-50),
    })
  }

  // List all active sessions
  const sessions = Array.from(activeSessions.entries()).map(([id, session]) => ({
    id,
    ...session.getSession(),
  }))

  return NextResponse.json({
    success: true,
    activeSessions: sessions.length,
    sessions,
  })
}
