import { type NextRequest, NextResponse } from "next/server"
import { createGeneral } from "@/lib/agentic"
import type { AgenticRequest } from "@/lib/agentic"

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as AgenticRequest

    // Validate request
    if (!body.generalId || !body.query) {
      return NextResponse.json({ error: "Missing required fields: generalId, query" }, { status: 400 })
    }

    // Create general instance
    const general = createGeneral(body.generalId)

    // Process request through full agentic pipeline
    const response = await general.processRequest(body)

    return NextResponse.json(response)
  } catch (error) {
    console.error("[v0] Agentic API error:", error)
    return NextResponse.json({ error: "Internal server error processing agentic request" }, { status: 500 })
  }
}
