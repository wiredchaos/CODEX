import { type NextRequest, NextResponse } from "next/server"
import { type AvatarAssessment, type AvatarTier, TIER_THRESHOLDS } from "@/config/story-engine"

// POST /api/chaos/assess - Evaluate avatar creative credit
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { avatar_id, novella_id, publication_id } = body

    if (!avatar_id) {
      return NextResponse.json({ error: "Avatar ID is required" }, { status: 400 })
    }

    // Simulated CHAOS-GATE assessment
    const story_integrity = 70 + Math.floor(Math.random() * 30)
    const creative_ethic = 60 + Math.floor(Math.random() * 40)
    const lore_alignment = 50 + Math.floor(Math.random() * 50)
    const submission_frequency = Math.floor(Math.random() * 100)

    const total_score = Math.floor((story_integrity + creative_ethic + lore_alignment + submission_frequency) / 4)

    const tier = calculateTier(total_score * 100)
    const unlocks = getUnlocks(tier)

    const assessment: AvatarAssessment = {
      avatar_id,
      story_integrity,
      creative_ethic,
      lore_alignment,
      submission_frequency,
      total_score,
      tier,
      unlocks,
    }

    return NextResponse.json({
      success: true,
      agent: "CHAOS-GATE",
      assessment,
      xp_earned: total_score * 10,
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to assess avatar" }, { status: 500 })
  }
}

function calculateTier(score: number): AvatarTier {
  if (score >= TIER_THRESHOLDS.merovingian) return "merovingian"
  if (score >= TIER_THRESHOLDS.lorekeeper) return "lorekeeper"
  if (score >= TIER_THRESHOLDS.chronicler) return "chronicler"
  if (score >= TIER_THRESHOLDS.scribe) return "scribe"
  return "initiate"
}

function getUnlocks(tier: AvatarTier): string[] {
  const unlocks: Record<AvatarTier, string[]> = {
    initiate: ["Basic Story Templates"],
    scribe: ["Advanced Characters", "Custom Worlds"],
    chronicler: ["Multi-Chapter Expansion", "Cover Generation"],
    lorekeeper: ["KDP Direct Publish", "Microsite Access"],
    merovingian: ["Unlimited Stories", "Revenue Share", "Lore Canon Access"],
  }
  return unlocks[tier]
}
