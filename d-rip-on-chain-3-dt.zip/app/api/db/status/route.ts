/**
 * WIRED CHAOS META - Database Status Endpoint
 * Returns connection status for all patches
 */

import { NextResponse } from "next/server"
import { getConnectionStatus, getRecentAudits } from "@/lib/db"
import { PATCH_LABELS, PATCH_SCHEMAS } from "@/lib/types/patch"
import type { PatchId } from "@/lib/types/patch"

export async function GET() {
  const connectionStatus = getConnectionStatus()
  const recentAudits = getRecentAudits(10)

  const patches = Object.entries(PATCH_SCHEMAS).map(([id, schema]) => ({
    id,
    label: PATCH_LABELS[id as PatchId],
    schema,
    connected: connectionStatus[id as PatchId] ?? false,
  }))

  return NextResponse.json({
    status: "operational",
    timestamp: new Date().toISOString(),
    database: {
      provider: "neon",
      pooling: true,
      ssl: true,
    },
    patches,
    recentAudits: recentAudits.map((a) => ({
      patchId: a.patchId,
      duration: `${a.duration}ms`,
      success: a.success,
      timestamp: a.timestamp.toISOString(),
    })),
    firewall: {
      layer1: "API Validation",
      layer2: "Schema Isolation",
      status: "active",
    },
  })
}
