// ============================================
// 589 MAGAZINE - Available Themes API
// GET /api/magazine/themes
// ============================================

import { NextResponse } from "next/server"
import { MAGAZINE_THEMES } from "@/config/589-magazine"

export async function GET() {
  const themes = Object.entries(MAGAZINE_THEMES).map(([id, config]) => ({
    id,
    label: config.label,
    signalTriggers: config.signalTriggers,
    loreKeywords: config.loreKeywords,
    colorAccent: config.colorAccent,
  }))

  return NextResponse.json({ themes })
}
