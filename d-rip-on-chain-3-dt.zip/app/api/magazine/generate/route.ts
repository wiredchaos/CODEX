// ============================================
// 589 MAGAZINE - Issue Generation API
// POST /api/magazine/generate
// ============================================

import { type NextRequest, NextResponse } from "next/server"
import type { MagazineTheme } from "@/types/magazine"
import { MAGAZINE_THEMES } from "@/config/589-magazine"
import { runSwarmSession, formatIssueTerminalOutput } from "@/lib/magazine/swarm-engine"

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { theme } = body as { theme?: MagazineTheme }

    // Validate theme or pick random
    let selectedTheme: MagazineTheme
    if (theme && theme in MAGAZINE_THEMES) {
      selectedTheme = theme
    } else {
      const themes = Object.keys(MAGAZINE_THEMES) as MagazineTheme[]
      selectedTheme = themes[Math.floor(Math.random() * themes.length)]
    }

    // Run the swarm session
    const session = await runSwarmSession(selectedTheme)

    if (!session.coverOutput) {
      return NextResponse.json({ error: "Failed to generate magazine cover" }, { status: 500 })
    }

    // Format for Issue Terminal
    const terminalOutput = formatIssueTerminalOutput(session.coverOutput)

    return NextResponse.json({
      success: true,
      session: {
        id: session.id,
        theme: session.theme,
        agentCount: session.agents.length,
        loreBotStatus: session.loreBot.status,
        newsBotStatus: session.newsBot.status,
      },
      cover: session.coverOutput,
      terminalOutput,
    })
  } catch (error) {
    console.error("Magazine generation error:", error)
    return NextResponse.json({ error: "Failed to generate magazine issue" }, { status: 500 })
  }
}
