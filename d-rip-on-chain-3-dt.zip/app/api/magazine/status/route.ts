// ============================================
// 589 MAGAZINE - System Status API
// GET /api/magazine/status
// ============================================

import { NextResponse } from "next/server"
import { getSwarmEngineStatus } from "@/lib/magazine/swarm-engine"
import { getLoreBotStatus } from "@/lib/magazine/neuro-lore-bot"
import { getNewsBotStatus } from "@/lib/magazine/neuro-news-bot"

export async function GET() {
  return NextResponse.json({
    swarmEngine: getSwarmEngineStatus(),
    loreBot: getLoreBotStatus(),
    newsBot: getNewsBotStatus(),
    systemTime: new Date().toISOString(),
    patchFirewall: {
      status: "ACTIVE",
      isolatedFrom: ["CHAOS OS Core", "FEN Main", "External Systems"],
      allowedConnections: ["Vault33 Archives", "VRG33589", "Gate 33.3"],
    },
  })
}
