import { type NextRequest, NextResponse } from "next/server"
import { IGS } from "@/lib/igs"
import type { GeneralRequest } from "@/lib/igs/types"

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as GeneralRequest

    // Validate request
    if (!body.generalId || !body.mode || !body.query) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Route to appropriate General
    const response = await IGS.router.routeRequest(body)

    // Anti-Moloch governance check
    const governance = IGS.antiMoloch.evaluateDecision(body.generalId, response.response, {
      multipleGeneralsConsulted: false,
    })

    return NextResponse.json({
      ...response,
      governance,
    })
  } catch (error) {
    console.error("[IGS API Error]", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
