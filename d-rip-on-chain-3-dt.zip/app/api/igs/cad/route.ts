import { type NextRequest, NextResponse } from "next/server"
import { IGS } from "@/lib/igs"
import type { TextToCADRequest } from "@/lib/igs/types"

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as TextToCADRequest

    // Validate request
    if (!body.prompt || !body.type || !body.industry) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Generate CAD
    const response = await IGS.cadSwarm.generateCAD(body)

    return NextResponse.json(response)
  } catch (error) {
    console.error("[CAD API Error]", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
