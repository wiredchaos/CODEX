// ============================================
// SWARM CONTENT GENERATION API
// Generates continuous lore content
// ============================================

import { type NextRequest, NextResponse } from "next/server"
import {
  generateLoreContent,
  generateTVEpisode,
  generateRadioBroadcast,
  generateARGMission,
  generatePortalEvent,
  generateTimeLoop,
  routeContent,
  type SwarmNodeType,
} from "@/lib/swarm/lore-swarm-engine"

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { nodeType, params } = body as {
      nodeType: SwarmNodeType
      params?: Record<string, any>
    }

    let content

    switch (nodeType) {
      case "LORE":
        content = generateLoreContent(params?.theme || "The Akashic Prophecy")
        break
      case "SCREENWRITER":
        content = generateTVEpisode(params?.showIndex || 0, params?.season || 1, params?.episode || 1)
        break
      case "AUDIO":
        content = generateRadioBroadcast(params?.universe || "33.3FM")
        break
      case "GAME":
        content = generateARGMission(params?.patch || "VAULT_33")
        break
      case "PORTAL":
        content = generatePortalEvent()
        break
      case "TIME_LOOP":
        content = generateTimeLoop()
        break
      default:
        return NextResponse.json({ error: `Unknown node type: ${nodeType}` }, { status: 400 })
    }

    // Route content to correct patch
    const routing = routeContent(content)

    return NextResponse.json({
      success: true,
      content,
      routing,
      constant: "DJ_RED_FANG",
      timeAnchors: content.timeAnchors,
    })
  } catch (error) {
    console.error("Swarm generation error:", error)
    return NextResponse.json({ error: "Failed to generate swarm content" }, { status: 500 })
  }
}

export async function GET() {
  // Return swarm status and available node types
  return NextResponse.json({
    status: "ACTIVE",
    constant: "DJ_RED_FANG",
    nodeTypes: ["LORE", "SCREENWRITER", "GAME", "AUDIO", "MAGAZINE", "TIME_LOOP", "PORTAL", "ROUTER"],
    patches: ["33_3FM", "789_OTT", "VRG33589", "CREATOR_CODEX", "AKIRA_CODEX", "FEN", "VAULT_33", "BUSINESS_PATCH"],
    entities: {
      constant: "DJ_RED_FANG",
      triplets: ["NEURO_RED_FANG", "ZERO_LUX", "KYROS_33"],
    },
    timeAnchors: {
      frequency589: true,
      stamp82675: true,
      clockfall2038: "2038-01-19T03:14:07.000Z",
    },
  })
}
