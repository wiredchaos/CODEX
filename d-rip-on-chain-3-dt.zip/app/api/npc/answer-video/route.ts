import { type NextRequest, NextResponse } from "next/server"
import {
  AVATARS,
  ENVIRONMENTS,
  type AnswerVideoRequest,
  type AnswerVideoResponse,
  type AvatarEmotion,
  type HookType,
} from "@/config/video-engine"

export async function POST(request: NextRequest) {
  try {
    const body: AnswerVideoRequest = await request.json()
    const { prompt, avatar, emotion = "neutral", environment } = body

    // Find avatar config
    const avatarConfig = AVATARS.find((a) => a.id === avatar) || AVATARS[0]

    // Determine environment (use avatar default if not specified)
    const envId = environment || avatarConfig.default_environment
    const envConfig = ENVIRONMENTS.find((e) => e.id === envId) || ENVIRONMENTS[0]

    // Generate text answer (placeholder - would connect to AI)
    const textAnswer = generateTextResponse(prompt, avatarConfig.name, emotion)

    // Select attention hook based on emotion
    const hookType = selectHookType(emotion)

    // Generate video URL (placeholder - would connect to video generation service)
    const videoUrl = `/api/video/placeholder?avatar=${avatar}&env=${envId}&hook=${hookType}`
    const thumbnailUrl = `/api/thumbnail/placeholder?avatar=${avatar}&env=${envId}`

    const response: AnswerVideoResponse = {
      text_answer: textAnswer,
      video_url: videoUrl,
      thumbnail: thumbnailUrl,
      avatar_pose: avatarConfig.signature_pose,
      environment: envId,
      duration_seconds: calculateDuration(textAnswer),
    }

    return NextResponse.json(response)
  } catch (error) {
    return NextResponse.json({ error: "Failed to generate answer video" }, { status: 500 })
  }
}

function generateTextResponse(prompt: string, avatarName: string, emotion: AvatarEmotion): string {
  // Placeholder response generation - would connect to AI service
  const responses: Record<AvatarEmotion, string> = {
    neutral: `[${avatarName}] Processing your query: "${prompt.slice(0, 50)}..." The system has analyzed your request and prepared a response.`,
    intensity: `[${avatarName}] CRITICAL ALERT: Your query triggers high-priority protocols. "${prompt.slice(0, 30)}..." requires immediate attention.`,
    wisdom: `[${avatarName}] The ancient frequencies speak to your question: "${prompt.slice(0, 40)}..." Let the wisdom flow through the channels.`,
    warning: `[${avatarName}] CAUTION ADVISED: "${prompt.slice(0, 35)}..." has triggered security protocols. Proceed with awareness.`,
    excitement: `[${avatarName}] SIGNAL LOCKED! "${prompt.slice(0, 40)}..." This is exactly what the chaos ordered!`,
    mystery: `[${avatarName}] The shadows whisper of "${prompt.slice(0, 35)}..." Some answers reveal themselves only to those who seek.`,
    authority: `[${avatarName}] DIRECTIVE RECEIVED: "${prompt.slice(0, 40)}..." The protocol has been established.`,
  }
  return responses[emotion]
}

function selectHookType(emotion: AvatarEmotion): HookType {
  const hookMap: Record<AvatarEmotion, HookType> = {
    neutral: "lens_flare",
    intensity: "red_pulse",
    wisdom: "bright_spark",
    warning: "red_pulse",
    excitement: "glitch_burst",
    mystery: "silhouette_cut",
    authority: "sudden_motion",
  }
  return hookMap[emotion]
}

function calculateDuration(text: string): number {
  // Roughly 3 seconds per 50 characters, clamped between 3-12 seconds
  const baseDuration = Math.ceil(text.length / 50) * 3
  return Math.max(3, Math.min(12, baseDuration))
}
