import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { generateNodeId } from "@/lib/hrm/service"

export async function GET(request: Request) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { data: profile, error } = await supabase
      .from("neuro_node_profiles")
      .select("*")
      .eq("user_id", user.id)
      .single()

    if (error && error.code !== "PGRST116") {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ profile: profile || null })
  } catch (error) {
    console.error("[v0] Profile fetch error:", error)
    return NextResponse.json({ error: "Failed to fetch profile" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const nodeId = await generateNodeId()

    const { data: profile, error } = await supabase
      .from("neuro_node_profiles")
      .insert({
        user_id: user.id,
        node_id: nodeId,
        display_name: body.displayName,
        headline: body.headline,
        bio: body.bio,
        industry: body.industry,
        current_role: body.currentRole,
        years_experience: body.yearsExperience || 0,
      })
      .select()
      .single()

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ profile })
  } catch (error) {
    console.error("[v0] Profile creation error:", error)
    return NextResponse.json({ error: "Failed to create profile" }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()

    const { data: profile, error } = await supabase
      .from("neuro_node_profiles")
      .update({
        display_name: body.displayName,
        headline: body.headline,
        bio: body.bio,
        location: body.location,
        industry: body.industry,
        current_role: body.currentRole,
        years_experience: body.yearsExperience,
        seeking_opportunities: body.seekingOpportunities,
        available_for_consulting: body.availableForConsulting,
        profile_visibility: body.profileVisibility,
        updated_at: new Date().toISOString(),
      })
      .eq("user_id", user.id)
      .select()
      .single()

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ profile })
  } catch (error) {
    console.error("[v0] Profile update error:", error)
    return NextResponse.json({ error: "Failed to update profile" }, { status: 500 })
  }
}
