import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { getUserSkills, getUserGameProgress, getUserCredentials, calculateSkillScores } from "@/lib/hrm/service"

export async function GET(request: Request) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Fetch all dashboard data in parallel
    const [profile, skills, gameProgress, credentials, skillScores] = await Promise.all([
      supabase.from("neuro_node_profiles").select("*").eq("user_id", user.id).single(),
      getUserSkills(user.id),
      getUserGameProgress(user.id),
      getUserCredentials(user.id),
      calculateSkillScores(user.id),
    ])

    // Calculate stats
    const totalGamesCompleted = gameProgress.filter((p) => p.status === "completed").length
    const totalSkillsEarned = skills.length
    const totalCredentials = credentials.length
    const totalXp = profile.data?.total_xp || 0
    const level = profile.data?.level || 1

    // Recent activity
    const recentActivity = gameProgress
      .filter((p) => p.lastPlayed)
      .sort((a, b) => new Date(b.lastPlayed!).getTime() - new Date(a.lastPlayed!).getTime())
      .slice(0, 10)

    return NextResponse.json({
      profile: profile.data,
      stats: {
        totalXp,
        level,
        totalGamesCompleted,
        totalSkillsEarned,
        totalCredentials,
      },
      skillScores,
      recentActivity,
      skills,
      credentials,
    })
  } catch (error) {
    console.error("[v0] Dashboard error:", error)
    return NextResponse.json({ error: "Failed to fetch dashboard data" }, { status: 500 })
  }
}
