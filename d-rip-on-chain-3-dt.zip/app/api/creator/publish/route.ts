import { type NextRequest, NextResponse } from "next/server"
import type { PublicationMetadata } from "@/config/story-engine"

// POST /api/creator/publish - Push to Kindle queue + registry
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { novella_id, book_slug, cover_prompt, author_avatar_id, price } = body

    if (!novella_id || !book_slug) {
      return NextResponse.json({ error: "Novella ID and book slug are required" }, { status: 400 })
    }

    // Simulated CC-PUBLISH agent response
    const publication: PublicationMetadata = {
      id: `pub-${Date.now()}`,
      novella_id,
      book_slug,
      cover_prompt: cover_prompt || "Default cyberpunk cover",
      kdp_status: "pending",
      price: price || 4.99,
      royalty_split: 70,
      author_avatar_id: author_avatar_id || "anonymous",
    }

    return NextResponse.json({
      success: true,
      agent: "CC-PUBLISH",
      publication,
      message: "Publication queued for KDP submission",
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to queue publication" }, { status: 500 })
  }
}
