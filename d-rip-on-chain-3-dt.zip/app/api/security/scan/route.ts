// ============================================================
// WIRED CHAOS META - Security Scan API Endpoint
// GET /api/security/scan - Returns current security status
// ============================================================

import { NextResponse } from "next/server"
import { generateSecurityReport, AFFECTED_PATCHES } from "@/lib/security/vulnerability-scanner"

// Get package versions from package.json at build time
// In production, these would be injected via build process
const PACKAGE_VERSIONS = {
  next: process.env.NEXT_VERSION || "16.0.7", // Default to patched version
  react: process.env.REACT_VERSION || "19.0.1",
  "react-dom": process.env.REACT_DOM_VERSION || "19.0.1",
}

export async function GET() {
  try {
    const report = generateSecurityReport(PACKAGE_VERSIONS)

    return NextResponse.json({
      success: true,
      report,
      affectedPatches: AFFECTED_PATCHES,
      scanTimestamp: new Date().toISOString(),
      nextActions:
        report.overallStatus === "VULNERABLE"
          ? [
              "Run: npm install next@latest react@latest react-dom@latest",
              "Clear cache: rm -rf .next node_modules/.cache",
              "Rebuild: npm run build",
              "Redeploy to Vercel",
              "Rotate environment secrets",
            ]
          : ["System is secure. Continue monitoring."],
    })
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: "Security scan failed",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
