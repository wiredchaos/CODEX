/**
 * NSQ GUARD - Status API
 * Returns current security system status
 */

import { NextResponse } from "next/server"
import { CryptoGateway } from "@/lib/crypto-gateway"
import { getAuditStats } from "@/lib/nsa-security-swarm"

export async function GET() {
  const cryptoStatus = CryptoGateway.getStatus()
  const auditStats = getAuditStats()

  return NextResponse.json({
    cryptoProfile: cryptoStatus.profile,
    pqcReady: cryptoStatus.pqcReady,
    algorithms: cryptoStatus.algorithms,
    auditStats: {
      totalRequests: auditStats.totalRequests,
      allowedRequests: auditStats.allowedRequests,
      deniedRequests: auditStats.deniedRequests,
      avgExecutionTimeMs: auditStats.avgExecutionTimeMs,
    },
    middleware: {
      edgeProtection: true,
      rateLimiting: true,
      securityHeaders: true,
    },
    timestamp: Date.now(),
  })
}
