/**
 * NSQ GUARD - Audit Log API
 * Returns recent security audit entries
 */

import { type NextRequest, NextResponse } from "next/server"
import { getRecentAuditEntries } from "@/lib/nsa-security-swarm"

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const limit = Number.parseInt(searchParams.get("limit") ?? "50")
  const resource = searchParams.get("resource") ?? undefined
  const allowed = searchParams.get("allowed")

  const entries = getRecentAuditEntries(limit, {
    resource,
    allowed: allowed !== null ? allowed === "true" : undefined,
  })

  return NextResponse.json({
    entries,
    count: entries.length,
    timestamp: Date.now(),
  })
}
