// WIRED CHAOS META - Security Incidents API
import { NextResponse } from "next/server"
import { getAllIncidents, getOpenIncidents } from "@/lib/security/incident-logger"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const filter = searchParams.get("filter")

  const incidents = filter === "open" ? getOpenIncidents() : getAllIncidents()

  return NextResponse.json({
    system: "WIRED CHAOS META",
    total: incidents.length,
    open: getOpenIncidents().length,
    incidents,
    timestamp: new Date().toISOString(),
  })
}
