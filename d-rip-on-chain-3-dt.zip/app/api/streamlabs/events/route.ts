import { NextResponse } from "next/server"
import { getEventsForPatch, getEventStats, type StreamEventType } from "@/integrations/streamlabs/events-bus"
import { getPatchStreamProfile } from "@/integrations/streamlabs/patch-registry"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const patchId = searchParams.get("patchId")
    const typesParam = searchParams.get("types")
    const limitParam = searchParams.get("limit")
    const sinceParam = searchParams.get("since")
    const includeStats = searchParams.get("stats") === "true"

    if (!patchId) {
      return NextResponse.json({ error: "patchId is required" }, { status: 400 })
    }

    // Check if patch is registered/known
    const profile = getPatchStreamProfile(patchId)
    if (!profile) {
      return NextResponse.json({ error: "Unknown patch ID" }, { status: 404 })
    }

    // Parse filters
    const types = typesParam?.split(",").filter(Boolean) as StreamEventType[] | undefined
    const limit = limitParam ? Number.parseInt(limitParam, 10) : 25
    const since = sinceParam ? Number.parseInt(sinceParam, 10) : undefined

    // Get events
    const events = getEventsForPatch(patchId, {
      types,
      limit: Math.min(limit, 100), // Cap at 100
      since,
    })

    // Optionally include stats
    const stats = includeStats ? getEventStats(patchId) : undefined

    return NextResponse.json({
      patchId,
      profile: {
        displayName: profile.displayName,
        theme: profile.theme,
      },
      events,
      stats,
      count: events.length,
    })
  } catch (error) {
    console.error("Events fetch error:", error)
    return NextResponse.json({ error: "Failed to fetch events" }, { status: 500 })
  }
}
