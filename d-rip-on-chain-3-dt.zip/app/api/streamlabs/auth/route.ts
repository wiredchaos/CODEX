import { NextResponse } from "next/server"
import { streamlabsClient } from "@/integrations/streamlabs/client"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const code = searchParams.get("code")
    const error = searchParams.get("error")
    const state = searchParams.get("state")

    if (error) {
      console.error("Streamlabs OAuth error:", error)
      return NextResponse.redirect(new URL("/settings?streamlabs=error", request.url))
    }

    if (!code) {
      return NextResponse.json({ error: "No authorization code provided" }, { status: 400 })
    }

    // Exchange code for tokens
    await streamlabsClient.exchangeCode(code)

    // Get user info to verify connection
    const user = await streamlabsClient.getUser()

    console.log("Streamlabs connected for user:", user.username)

    // Redirect to success page
    const redirectUrl = state || "/settings?streamlabs=connected"
    return NextResponse.redirect(new URL(redirectUrl, request.url))
  } catch (error) {
    console.error("Streamlabs auth error:", error)
    return NextResponse.redirect(new URL("/settings?streamlabs=error", request.url))
  }
}
