import { NextResponse } from "next/server"
import { publishEvent, type StreamEventType } from "@/integrations/streamlabs/events-bus"
import crypto from "crypto"

const WEBHOOK_SECRET = process.env.STREAMLABS_WEBHOOK_SECRET || ""

function verifySignature(payload: string, signature: string): boolean {
  if (!WEBHOOK_SECRET) return true // Skip verification if no secret configured

  const expectedSignature = crypto.createHmac("sha256", WEBHOOK_SECRET).update(payload).digest("hex")

  return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSignature))
}

export async function POST(request: Request) {
  try {
    const payload = await request.text()
    const signature = request.headers.get("x-streamlabs-signature") || ""

    // Verify webhook signature
    if (WEBHOOK_SECRET && !verifySignature(payload, signature)) {
      console.error("Invalid webhook signature")
      return NextResponse.json({ error: "Invalid signature" }, { status: 401 })
    }

    const data = JSON.parse(payload)

    // Map Streamlabs event types to our types
    const typeMap: Record<string, StreamEventType> = {
      donation: "donation",
      follow: "follow",
      subscription: "subscription",
      host: "host",
      raid: "raid",
      bits: "bits",
      superchat: "superchat",
    }

    const eventType = typeMap[data.type] || "custom"

    // Normalize the event payload
    const event = publishEvent(
      {
        type: eventType,
        payload: {
          username: data.from || data.name,
          displayName: data.display_name || data.from || data.name,
          message: data.message,
          amount: Number.parseFloat(data.amount) || 0,
          currency: data.currency || "USD",
          tier: data.tier,
          viewers: data.viewers,
          months: data.months,
          ...data,
        },
      },
      data.patchId, // Optional patch targeting from webhook payload
    )

    return NextResponse.json({
      success: true,
      eventId: event.id,
      type: eventType,
    })
  } catch (error) {
    console.error("Webhook processing error:", error)
    return NextResponse.json({ error: "Failed to process webhook" }, { status: 500 })
  }
}
