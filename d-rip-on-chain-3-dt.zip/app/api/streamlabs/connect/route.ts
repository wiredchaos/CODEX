import { NextResponse } from "next/server"
import { streamlabsClient } from "@/integrations/streamlabs/client"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const state = searchParams.get("state") || undefined

    const authUrl = streamlabsClient.getAuthUrl(state)

    return NextResponse.redirect(authUrl)
  } catch (error) {
    console.error("Streamlabs connect error:", error)
    return NextResponse.json({ error: "Failed to initiate Streamlabs connection" }, { status: 500 })
  }
}
