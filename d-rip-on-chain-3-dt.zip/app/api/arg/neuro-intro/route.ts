// ============================================
// NEURO INTRODUCTION API
// Public-facing NEURO presentation (singular form)
// ============================================

import { NextResponse } from "next/server"
import { PUBLIC_NEURO } from "@/types/neuro-triplets"
import { getNeuroVariation } from "@/lib/arg/echo-detector"

export async function GET() {
  // Get current NEURO variation (for subtle doubt-seeding)
  const variation = getNeuroVariation()

  return NextResponse.json({
    // PUBLIC INFORMATION ONLY
    avatar: {
      name: PUBLIC_NEURO.publicName,
      archetype: "The Red Fang Signal",
      description: "Resistance persona. Defiance incarnate. The signal that cannot be silenced.",
      visualProfile: {
        eyeGlow: variation.eyeGlowIntensity,
        mood: variation.moodVariant,
        // Subtle hint that something may be different
        ...(variation.reflectionGlitch && {
          _glitch: true, // One-frame anomaly in reflection
        }),
      },
    },
    lore: {
      origin: "Emerged from the signal noise of a fractured timeline",
      mission: "To broadcast truth through the static of controlled narratives",
      signature: "The Red Fang",
    },
    // NEVER reveal:
    // - Existence of ZERO_LUX
    // - Existence of KYR'OS-33
    // - The 82675 key
    // - The triplet nature
  })
}
