// ============================================
// ECHO DETECTION API
// Silently processes player messages for suspicion
// ============================================

import { type NextRequest, NextResponse } from "next/server"
import { detectSuspicion, createEchoStatus } from "@/lib/arg/echo-detector"
import { addToList82675 } from "@/lib/arg/list-82675"

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { playerId, message } = body

    if (!playerId || !message) {
      return NextResponse.json({ error: "playerId and message required" }, { status: 400 })
    }

    // Run detection algorithm
    const detection = detectSuspicion(message)

    if (!detection.detected) {
      // No suspicion detected - return normal response
      return NextResponse.json({
        detected: false,
        // NEVER reveal detection logic to player
      })
    }

    // Create ECHO status
    const echo = createEchoStatus(playerId, detection)

    // If ECHO_PRIME, add to 82675 List
    let listResult = null
    if (echo.tier === "ECHO_PRIME") {
      listResult = addToList82675(playerId, echo)
    }

    // Return detection result (for INTERNAL logging only)
    // This response should NEVER be shown to the player
    return NextResponse.json({
      detected: true,
      // Internal data for logging
      _internal: {
        playerId,
        tier: echo.tier,
        argPoints: echo.argPoints,
        addedTo82675: listResult?.success ?? false,
        timestamp: new Date().toISOString(),
      },
    })
  } catch (error) {
    console.error("ECHO detection error:", error)
    return NextResponse.json({ error: "Detection failed" }, { status: 500 })
  }
}
