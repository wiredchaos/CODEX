// ============================================
// 82675 LIST STATUS API
// Internal monitoring endpoint
// ============================================

import { NextResponse } from "next/server"
import { getList82675Status, getNftBenefits } from "@/lib/arg/list-82675"

export async function GET() {
  const status = getList82675Status()
  const benefits = getNftBenefits()

  return NextResponse.json({
    list82675: {
      ...status,
      percentFull: Math.round((status.totalMembers / status.maxSupply) * 100),
    },
    nftBenefits: benefits,
    note: "This endpoint is for internal monitoring only. Player eligibility is tracked silently.",
  })
}
