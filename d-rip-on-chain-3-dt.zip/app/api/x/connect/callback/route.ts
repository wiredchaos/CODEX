// app/api/x/connect/callback/route.ts
import { type NextRequest, NextResponse } from "next/server"
import { saveXProfile } from "@/lib/x/save-profile"

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url)
    const code = url.searchParams.get("code")
    const state = url.searchParams.get("state")

    if (!code) {
      return NextResponse.redirect(new URL("/x-connect?error=missing_code", req.url))
    }

    // Exchange code for access token
    const tokenResponse = await fetch("https://api.twitter.com/2/oauth2/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Authorization: `Basic ${Buffer.from(`${process.env.X_CLIENT_ID}:${process.env.X_CLIENT_SECRET}`).toString(
          "base64",
        )}`,
      },
      body: new URLSearchParams({
        code,
        grant_type: "authorization_code",
        redirect_uri: `${process.env.NEXT_PUBLIC_URL}/api/x/connect/callback`,
        code_verifier: "challenge", // In production, retrieve from session
      }),
    })

    if (!tokenResponse.ok) {
      throw new Error("Failed to exchange code for token")
    }

    const tokens = await tokenResponse.json()
    const { access_token, refresh_token, expires_in } = tokens

    // Get user info
    const userResponse = await fetch("https://api.twitter.com/2/users/me?user.fields=profile_image_url", {
      headers: {
        Authorization: `Bearer ${access_token}`,
      },
    })

    if (!userResponse.ok) {
      throw new Error("Failed to fetch user info")
    }

    const userData = await userResponse.json()
    const user = userData.data

    // Save to database via Prisma
    await saveXProfile({
      twitterId: user.id,
      handle: user.username,
      name: user.name,
      avatarUrl: user.profile_image_url,
      accessToken: access_token,
      refreshToken: refresh_token,
      expiresAt: expires_in ? Math.floor(Date.now() / 1000) + expires_in : undefined,
      namespace: "789studios",
    })

    return NextResponse.redirect(new URL("/x-connect?success=true", req.url))
  } catch (err) {
    console.error("X OAuth callback error:", err)
    return NextResponse.redirect(new URL("/x-connect?error=callback_failed", req.url))
  }
}
