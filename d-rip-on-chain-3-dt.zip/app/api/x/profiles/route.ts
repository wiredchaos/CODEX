import { type NextRequest, NextResponse } from "next/server"

// Mock X profiles for 789 Studios
const MOCK_PROFILES = [
  {
    id: "xprof_vibes_001",
    twitterId: "1234567890",
    handle: "VIBES",
    name: "VIBES • 789 Studios",
    avatarUrl: "/vibes-profile-picture.jpg",
    namespace: "789studios",
    createdAt: new Date("2024-01-15").toISOString(),
  },
  {
    id: "xprof_neuro_001",
    twitterId: "1234567891",
    handle: "neurometax",
    name: "NEURO • 789 Studios",
    avatarUrl: "/neuro-profile-picture-red-theme.jpg",
    namespace: "789studios",
    createdAt: new Date("2024-01-16").toISOString(),
  },
  {
    id: "xprof_gator_001",
    twitterId: "1234567892",
    handle: "GATOR_789",
    name: "GATOR • 789 Studios",
    avatarUrl: "/gator-profile-picture.jpg",
    namespace: "789studios",
    createdAt: new Date("2024-01-17").toISOString(),
  },
]

export async function GET() {
  try {
    // Return mock profiles instead of querying Prisma
    return NextResponse.json({ profiles: MOCK_PROFILES }, { status: 200 })
  } catch (err) {
    console.error("X profiles fetch error:", err)
    return NextResponse.json({ error: "Failed to fetch profiles" }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const body = await req.json()
    const id = body?.id as string | undefined

    if (!id) {
      return NextResponse.json({ error: "Missing profile id" }, { status: 400 })
    }

    // Mock deletion - just return success
    console.log("[v0] Mock delete profile:", id)
    return NextResponse.json({ ok: true }, { status: 200 })
  } catch (error) {
    console.error("Delete X profile error:", error)
    return NextResponse.json({ error: "Failed to delete profile" }, { status: 500 })
  }
}
