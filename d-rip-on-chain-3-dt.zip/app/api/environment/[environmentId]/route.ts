import { type NextRequest, NextResponse } from "next/server"
import { ENVIRONMENTS } from "@/config/video-engine"

export async function GET(request: NextRequest, { params }: { params: { environmentId: string } }) {
  try {
    const environmentId = params.environmentId

    // Find environment config
    const envConfig = ENVIRONMENTS.find((e) => e.id === environmentId)
    if (!envConfig) {
      return NextResponse.json({ error: "Environment not found" }, { status: 404 })
    }

    // Return environment config matching EnvironmentConfig interface
    const environmentConfig = {
      id: envConfig.id,
      label: envConfig.name,
      patch: envConfig.category,
      defaultAvatarIds: getDefaultAvatarsForEnvironment(envConfig.id),
      description: envConfig.description,
      lighting: envConfig.lighting,
      elements: envConfig.elements,
      interactionModes: envConfig.interaction_modes,
    }

    return NextResponse.json(environmentConfig)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch environment" }, { status: 500 })
  }
}

function getDefaultAvatarsForEnvironment(envId: string): string[] {
  // Map environments to their default avatars
  const envAvatarMap: Record<string, string[]> = {
    neon_boardroom: ["neuro-meta", "dog-1787", "neurolux-drae"],
    glass_atrium: ["neuro-meta", "shadowlux"],
    creator_studio: ["neurolux-drae", "neuro-meta"],
    financial_observatory: ["shadowlux", "degen-sith"],
    rupture_library: ["neuro-meta", "kiba-neuro"],
    vault_33_chamber: ["kiba-neuro", "oyalan-shako"],
    neon_tunnel: ["neuro-meta", "uplink"],
    core_memory_node: ["uplink", "neuro-meta"],
    broadcast_studio: ["fm-persona-33"],
  }
  return envAvatarMap[envId] || ["neuro-meta"]
}
