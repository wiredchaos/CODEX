import { type NextRequest, NextResponse } from "next/server"
import { ENVIRONMENTS, type EnvironmentLoadRequest } from "@/config/video-engine"

export async function POST(request: NextRequest) {
  try {
    const body: EnvironmentLoadRequest = await request.json()
    const { environment_id, detail_level, interaction_mode } = body

    // Find environment config
    const envConfig = ENVIRONMENTS.find((e) => e.id === environment_id)
    if (!envConfig) {
      return NextResponse.json({ error: "Invalid environment ID" }, { status: 400 })
    }

    // Check if interaction mode is supported
    if (!envConfig.interaction_modes.includes(interaction_mode)) {
      return NextResponse.json({ error: `Environment does not support ${interaction_mode} mode` }, { status: 400 })
    }

    // Generate environment load config
    const loadConfig = {
      id: `env_${Date.now()}`,
      environment: {
        ...envConfig,
        detail_level,
        active_interaction_mode: interaction_mode,
      },
      assets: {
        skybox: `/assets/environments/${environment_id}/skybox_${detail_level}.hdr`,
        floor: `/assets/environments/${environment_id}/floor.glb`,
        elements: envConfig.elements.map((el) => ({
          name: el,
          model: `/assets/environments/${environment_id}/${el}.glb`,
          position: [0, 0, 0],
        })),
      },
      audio: envConfig.ambient_sound
        ? {
            source: `/assets/audio/${envConfig.ambient_sound}.mp3`,
            loop: true,
            volume: 0.3,
          }
        : null,
      status: "loaded",
    }

    return NextResponse.json({
      success: true,
      load_config: loadConfig,
      message: "Environment loaded",
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to load environment" }, { status: 500 })
  }
}
