// X (Twitter) OAuth Login Route
// NOTE: This is a scaffold. Full implementation requires X Developer Portal credentials
// and compliance with X Platform Terms of Service.

import { NextResponse } from "next/server"

// Environment variables required:
// X_OAUTH_CLIENT_ID
// X_OAUTH_CLIENT_SECRET
// NEXT_PUBLIC_APP_URL

export async function GET() {
  const clientId = process.env.X_OAUTH_CLIENT_ID

  if (!clientId) {
    return NextResponse.json(
      { error: "X OAuth not configured. Set X_OAUTH_CLIENT_ID in environment." },
      { status: 501 },
    )
  }

  // X OAuth 2.0 Authorization URL
  // See: https://developer.x.com/en/docs/authentication/oauth-2-0/authorization-code
  const authUrl = new URL("https://twitter.com/i/oauth2/authorize")

  authUrl.searchParams.set("response_type", "code")
  authUrl.searchParams.set("client_id", clientId)
  authUrl.searchParams.set("redirect_uri", `${process.env.NEXT_PUBLIC_APP_URL}/api/auth/x/callback`)
  authUrl.searchParams.set("scope", "tweet.read users.read offline.access")
  authUrl.searchParams.set("state", crypto.randomUUID())
  authUrl.searchParams.set("code_challenge", "challenge") // Implement PKCE in production
  authUrl.searchParams.set("code_challenge_method", "plain")

  return NextResponse.redirect(authUrl.toString())
}
