import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function POST(req: NextRequest) {
  try {
    const { address, chain, signature, message } = await req.json()

    if (!address || !chain || !signature || !message) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // TODO: Verify signature against message
    // For now, we'll trust the client (implement proper verification)

    // Find or create user with this wallet
    let wallet = await prisma.fMWallet.findUnique({
      where: {
        chain_address: {
          chain,
          address,
        },
      },
      include: { user: true },
    })

    if (!wallet) {
      // Create new user and wallet
      const user = await prisma.fMUser.create({
        data: {
          displayName: `${chain}-${address.slice(0, 6)}`,
          walletAddress: address,
          tierLevel: "free",
        },
      })

      wallet = await prisma.fMWallet.create({
        data: {
          userId: user.id,
          chain,
          address,
          isPrimary: true,
        },
        include: { user: true },
      })
    }

    return NextResponse.json({
      success: true,
      user: wallet.user,
      token: "TODO_GENERATE_JWT", // TODO: Implement JWT generation
    })
  } catch (error) {
    console.error("Wallet login error:", error)
    return NextResponse.json({ error: "Wallet login failed" }, { status: 500 })
  }
}
