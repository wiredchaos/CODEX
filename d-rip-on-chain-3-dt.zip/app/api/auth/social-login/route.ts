import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function POST(req: NextRequest) {
  try {
    const { provider, providerId, email, name, avatar } = await req.json()

    if (!provider || !providerId) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Find existing auth
    let auth = await prisma.fMUserAuth.findUnique({
      where: {
        provider_providerId: {
          provider,
          providerId,
        },
      },
      include: { user: true },
    })

    if (!auth) {
      // Create new user and auth
      const user = await prisma.fMUser.create({
        data: {
          email: email || undefined,
          displayName: name || `User${Date.now()}`,
          avatarUrl: avatar,
          tierLevel: "free",
        },
      })

      auth = await prisma.fMUserAuth.create({
        data: {
          userId: user.id,
          provider,
          providerId,
          metadata: { email, name, avatar },
        },
        include: { user: true },
      })
    }

    return NextResponse.json({
      success: true,
      user: auth.user,
      token: "TODO_GENERATE_JWT",
    })
  } catch (error) {
    console.error("Social login error:", error)
    return NextResponse.json({ error: "Social login failed" }, { status: 500 })
  }
}
