import NextAuth from "next-auth"
import TwitterProvider from "next-auth/providers/twitter"
import type { NextAuthOptions } from "next-auth"

export const authOptions: NextAuthOptions = {
  providers: [
    TwitterProvider({
      clientId: process.env.X_CLIENT_ID!,
      clientSecret: process.env.X_CLIENT_SECRET!,
      version: "2.0",
    }),
  ],
  callbacks: {
    async jwt({ token, account, profile }) {
      if (account?.provider === "twitter" && profile) {
        token.xHandle = (profile as any).data?.username || (profile as any).username
        token.xId = (profile as any).data?.id || (profile as any).id
        token.xName = (profile as any).data?.name || (profile as any).name
        token.xAvatar = (profile as any).data?.profile_image_url || (profile as any).profile_image_url
      }
      return token
    },
    async session({ session, token }) {
      if (token.xHandle) {
        ;(session as any).xHandle =
          token.xHandle(session as any).xId =
          token.xId(session as any).xName =
          token.xName(session as any).xAvatar =
            token.xAvatar
      }
      return session
    },
  },
  pages: {
    signIn: "/auth/signin",
    error: "/auth/error",
  },
}

const handler = NextAuth(authOptions)

export { handler as GET, handler as POST }
