import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { calculateValuation } from "@/lib/valorithm/calculator"
import type { ValuationCalculatorInput } from "@/lib/valorithm/types"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const {
      workCategory,
      complexityLevel,
      estimatedHours,
      aiCreditsUsed = 0,
      outputTypes = [],
      ipTier,
      projectName,
    } = body

    const input: ValuationCalculatorInput = {
      workCategory,
      complexityLevel,
      estimatedHours,
      aiCreditsUsed,
      outputTypes,
      ipTier,
    }

    const valuation = calculateValuation(input)

    // Log the sweat equity entry
    const { data: log, error } = await supabase
      .from("valorithm_sweat_equity_logs")
      .insert({
        user_id: user.id,
        labor_category: workCategory,
        estimated_hours: estimatedHours,
        estimated_cost: valuation.breakdown.laborValue,
        ip_bonus: valuation.ipBonusValue,
        total_value: valuation.totalValue,
        project_name: projectName,
      })
      .select()
      .single()

    if (error) throw error

    return NextResponse.json({
      success: true,
      data: {
        log,
        valuation,
      },
    })
  } catch (error) {
    console.error("Log entry error:", error)
    return NextResponse.json({ success: false, error: "Failed to log entry" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    const { data: logs } = await supabase
      .from("valorithm_sweat_equity_logs")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })

    // Calculate aggregates
    const totals = (logs || []).reduce(
      (acc, log) => ({
        totalHours: acc.totalHours + (log.estimated_hours || 0),
        totalCost: acc.totalCost + (log.estimated_cost || 0),
        totalIPBonus: acc.totalIPBonus + (log.ip_bonus || 0),
        totalValue: acc.totalValue + (log.total_value || 0),
      }),
      { totalHours: 0, totalCost: 0, totalIPBonus: 0, totalValue: 0 },
    )

    return NextResponse.json({
      success: true,
      data: {
        logs,
        totals,
      },
    })
  } catch (error) {
    console.error("Log fetch error:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch logs" }, { status: 500 })
  }
}
