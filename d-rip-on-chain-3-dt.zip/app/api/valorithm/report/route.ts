import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { generateSweatEquityReport, generateInvestorDeckOutline } from "@/lib/valorithm/report-generator"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { projectName, type = "sweat_equity" } = body

    // Fetch user's sweat equity logs
    const { data: logs } = await supabase
      .from("valorithm_sweat_equity_logs")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: true })

    // Fetch user's IP assets
    const { data: ipAssets } = await supabase.from("valorithm_ip_assets").select("*").eq("user_id", user.id)

    const report = generateSweatEquityReport(user.id, logs || [], ipAssets || [], projectName || "Untitled Project")

    // Save report to database
    const { data: savedReport, error } = await supabase
      .from("valorithm_reports")
      .insert({
        user_id: user.id,
        type: report.type,
        title: report.title,
        content_json: report.contentJson,
      })
      .select()
      .single()

    if (error) throw error

    // Generate investor deck outline if requested
    let deckOutline = null
    if (type === "investor_deck") {
      deckOutline = generateInvestorDeckOutline(report)
    }

    return NextResponse.json({
      success: true,
      data: {
        report: savedReport,
        deckOutline,
      },
    })
  } catch (error) {
    console.error("Report generation error:", error)
    return NextResponse.json({ success: false, error: "Report generation failed" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    const { data: reports } = await supabase
      .from("valorithm_reports")
      .select("*")
      .eq("user_id", user.id)
      .order("generated_at", { ascending: false })

    return NextResponse.json({ success: true, data: reports })
  } catch (error) {
    console.error("Report fetch error:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch reports" }, { status: 500 })
  }
}
