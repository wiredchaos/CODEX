import { type NextRequest, NextResponse } from "next/server"
import { calculateValuation, calculateBatchValuation } from "@/lib/valorithm/calculator"
import type { ValuationCalculatorInput } from "@/lib/valorithm/types"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { inputs, batch = false } = body

    if (batch && Array.isArray(inputs)) {
      const result = calculateBatchValuation(inputs as ValuationCalculatorInput[])
      return NextResponse.json({ success: true, data: result })
    }

    if (!inputs || typeof inputs !== "object") {
      return NextResponse.json({ success: false, error: "Invalid input" }, { status: 400 })
    }

    const result = calculateValuation(inputs as ValuationCalculatorInput)
    return NextResponse.json({ success: true, data: result })
  } catch (error) {
    console.error("Valuation calculation error:", error)
    return NextResponse.json({ success: false, error: "Calculation failed" }, { status: 500 })
  }
}
