// VALORITHM™ Dashboard API

import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function GET(req: NextRequest) {
  try {
    console.log("[v0] VALORITHM dashboard: Starting request")

    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    console.log("[v0] VALORITHM dashboard: User check", { hasUser: !!user })

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get all prompts with error handling
    const { data: prompts, error: promptsError } = await supabase
      .from("valorithm_prompts")
      .select("*")
      .eq("user_id", user.id)
      .order("timestamp", { ascending: false })

    if (promptsError) {
      console.log("[v0] VALORITHM dashboard: Prompts query error", promptsError)
      // Return empty data if table doesn't exist yet
      if (promptsError.code === "42P01" || promptsError.message.includes("does not exist")) {
        return NextResponse.json({
          kpis: {
            totalValue: 0,
            costAvoided: 0,
            hoursSaved: 0,
            ipAssets: 0,
          },
          prompts: [],
          outputs: [],
          ipAssets: [],
          analytics: {
            byCategory: {},
            timeline: [],
          },
          needsSetup: true,
        })
      }
      throw promptsError
    }

    // Get all outputs with error handling
    const { data: outputs, error: outputsError } = await supabase
      .from("valorithm_outputs")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })

    if (outputsError) {
      console.log("[v0] VALORITHM dashboard: Outputs query error", outputsError)
    }

    // Get all IP assets with error handling
    const { data: ipAssets, error: ipError } = await supabase
      .from("valorithm_ip_assets")
      .select("*")
      .eq("user_id", user.id)

    if (ipError) {
      console.log("[v0] VALORITHM dashboard: IP assets query error", ipError)
    }

    // Calculate KPIs
    const totalValue = prompts?.reduce((sum, p) => sum + Number(p.estimated_cost), 0) || 0
    const totalHours = prompts?.reduce((sum, p) => sum + Number(p.estimated_hours), 0) || 0
    const totalAICost = prompts?.reduce((sum, p) => sum + (Number(p.tokens_used) / 1000) * 0.002, 0) || 0
    const costAvoided = totalValue - totalAICost
    const ipCount = ipAssets?.length || 0

    // Category breakdown
    const byCategory =
      prompts?.reduce(
        (acc, p) => {
          acc[p.category] = (acc[p.category] || 0) + Number(p.estimated_cost)
          return acc
        },
        {} as Record<string, number>,
      ) || {}

    // Timeline data (last 30 days)
    const thirtyDaysAgo = new Date()
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)

    const timelineData =
      prompts
        ?.filter((p) => new Date(p.timestamp) >= thirtyDaysAgo)
        .reduce(
          (acc, p) => {
            const date = new Date(p.timestamp).toISOString().split("T")[0]
            acc[date] = (acc[date] || 0) + Number(p.estimated_cost)
            return acc
          },
          {} as Record<string, number>,
        ) || {}

    const timeline = Object.entries(timelineData).map(([date, value]) => ({ date, value }))

    return NextResponse.json({
      kpis: {
        totalValue: Math.round(totalValue),
        costAvoided: Math.round(costAvoided),
        hoursSaved: Math.round(totalHours * 10) / 10,
        ipAssets: ipCount,
      },
      prompts: prompts || [],
      outputs: outputs || [],
      ipAssets: ipAssets || [],
      analytics: {
        byCategory,
        timeline,
      },
    })
  } catch (error: any) {
    console.error("[VALORITHM] Dashboard error:", error)
    return NextResponse.json(
      {
        error: error.message,
        needsSetup: error.code === "42P01" || error.message?.includes("does not exist"),
        kpis: {
          totalValue: 0,
          costAvoided: 0,
          hoursSaved: 0,
          ipAssets: 0,
        },
        prompts: [],
        outputs: [],
        ipAssets: [],
        analytics: {
          byCategory: {},
          timeline: [],
        },
      },
      { status: error.code === "42P01" ? 200 : 500 },
    )
  }
}
