// VALORITHM™ Prompt Capture API

import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { ValoEngine } from "@/lib/valorithm/engine"

export async function POST(req: NextRequest) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { content, tokens_used = 0 } = await req.json()

    if (!content) {
      return NextResponse.json({ error: "Content required" }, { status: 400 })
    }

    // Classify and analyze
    const category = ValoEngine.classifyWork(content)
    const complexityTier = ValoEngine.assessComplexity(content)
    const laborCategory = ValoEngine.mapToLaborCategory(category, content)
    const estimatedHours = ValoEngine.estimateHours(complexityTier)
    const laborRate = 100 // Default mid-level rate
    const estimatedCost = ValoEngine.calculateLaborCost(laborCategory, estimatedHours)

    // Store prompt
    const { data: prompt, error } = await supabase
      .from("valorithm_prompts")
      .insert({
        user_id: user.id,
        content,
        category,
        complexity_tier: complexityTier,
        tokens_used,
        estimated_hours: estimatedHours,
        labor_rate: laborRate,
        estimated_cost: estimatedCost,
      })
      .select()
      .single()

    if (error) throw error

    // Create sweat equity log
    await supabase.from("valorithm_sweat_equity_logs").insert({
      user_id: user.id,
      prompt_id: prompt.id,
      labor_category: laborCategory,
      estimated_hours: estimatedHours,
      hourly_rate: laborRate,
      estimated_cost: estimatedCost,
    })

    return NextResponse.json({
      success: true,
      prompt,
      analysis: {
        category,
        complexity_tier: complexityTier,
        labor_category: laborCategory,
        estimated_hours: estimatedHours,
        estimated_cost: estimatedCost,
      },
    })
  } catch (error: any) {
    console.error("[VALORITHM] Capture error:", error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
