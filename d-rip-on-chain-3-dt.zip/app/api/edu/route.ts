import { NextResponse } from "next/server"
import { gigaImportEngine } from "@/lib/edu/giga-import"
import type { EduImportRequest } from "@/lib/edu/types"

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as EduImportRequest

    if (!body.query) {
      return NextResponse.json({ error: "Query is required" }, { status: 400 })
    }

    const response = await gigaImportEngine.processRequest(body)

    return NextResponse.json(response)
  } catch (error) {
    console.error("EDU Import API error:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Internal server error" },
      { status: 500 },
    )
  }
}

export async function GET() {
  // Return registry overview
  const { GENERALS, SWARMS, PILLARS, GOVERNANCE } = await import("@/lib/edu/registry")

  return NextResponse.json({
    version: "1.0.0",
    namespace: "wired_chaos_meta.education",
    stats: {
      pillars: PILLARS.length,
      generals: GENERALS.length,
      swarms: SWARMS.length,
      antiMolochRules: GOVERNANCE.antiMolochRules.length,
    },
    pillars: PILLARS.map((p) => ({
      id: p.id,
      name: p.name,
      generalId: p.generalId,
      swarmCount: p.swarmAgentIds.length,
    })),
  })
}
