import { type NextRequest, NextResponse } from "next/server"
import { fetchLurkyProfileByHandle } from "@/lib/lurky/profiles"

export async function GET(req: NextRequest, { params }: { params: { handle: string } }) {
  try {
    const { handle } = params

    if (!handle) {
      return NextResponse.json({ error: "Handle is required" }, { status: 400 })
    }

    const profile = await fetchLurkyProfileByHandle(handle)

    if (!profile) {
      return NextResponse.json({ error: "Profile not found or Lurky API unavailable", handle }, { status: 404 })
    }

    return NextResponse.json(profile, { status: 200 })
  } catch (error) {
    console.error("[v0] Lurky profile API error:", error)
    return NextResponse.json({ error: "Failed to fetch Lurky profile" }, { status: 500 })
  }
}
