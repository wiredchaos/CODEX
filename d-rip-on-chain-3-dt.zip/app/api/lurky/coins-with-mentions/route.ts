import { type NextRequest, NextResponse } from "next/server"
import { getLurkyClient } from "@/lib/lurky/client"

export async function GET(req: NextRequest) {
  try {
    const client = getLurkyClient()
    const url = new URL(req.url)

    const page = Number(url.searchParams.get("page") ?? "0")
    const limit = Number(url.searchParams.get("limit") ?? "20")
    const sort_by = (url.searchParams.get("sort_by") ?? "mentions") as "market_cap" | "name" | "price" | "mentions"
    const sort_dir = (url.searchParams.get("sort_dir") ?? "desc") as "asc" | "desc"

    const chainsParam = url.searchParams.get("chains")
    const chains = chainsParam ? chainsParam.split(",").map((c) => c.trim()) : undefined

    const min_rank = url.searchParams.get("min_rank")
    const max_rank = url.searchParams.get("max_rank")

    const lurkyRes = await client.listCoinsWithMentions({
      page,
      limit,
      sort_by,
      sort_dir,
      chains,
      min_rank: min_rank ? Number(min_rank) : undefined,
      max_rank: max_rank ? Number(max_rank) : undefined,
      mentioned: true,
    })

    return NextResponse.json(
      {
        coins: lurkyRes.data ?? lurkyRes.coins ?? lurkyRes,
        page,
        limit,
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("Lurky coins-with-mentions error:", error)
    return NextResponse.json({ error: "Failed to fetch coin mentions" }, { status: 500 })
  }
}
