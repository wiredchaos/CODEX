import { NextResponse } from "next/server"
import { syncNeuroProfileToDatabase } from "@/lib/lurky/neuro-profile"

export async function POST() {
  try {
    const profile = await syncNeuroProfileToDatabase()

    if (!profile) {
      return NextResponse.json({ error: "Failed to sync NEURO profile from Lurky" }, { status: 500 })
    }

    return NextResponse.json({
      message: "NEURO profile synced successfully",
      profile,
    })
  } catch (error) {
    console.error("[NEURO_SYNC_API] Error:", error)
    return NextResponse.json({ error: "Profile sync failed" }, { status: 500 })
  }
}
