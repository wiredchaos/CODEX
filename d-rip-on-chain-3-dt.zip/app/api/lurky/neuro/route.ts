import { NextResponse } from "next/server"
import { getNeuroProfileCached } from "@/lib/lurky/neuro-profile"

export async function GET() {
  try {
    const profile = await getNeuroProfileCached()

    if (!profile) {
      return NextResponse.json({ error: "NEURO profile not found on Lurky.app" }, { status: 404 })
    }

    return NextResponse.json(profile)
  } catch (error) {
    console.error("[NEURO_PROFILE_API] Error:", error)
    return NextResponse.json({ error: "Failed to fetch NEURO profile" }, { status: 500 })
  }
}
