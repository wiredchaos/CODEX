// app/api/lurky/discussions/route.ts
import { type NextRequest, NextResponse } from "next/server"
import { getLurkyClient } from "@/lib/lurky/client"

export async function GET(req: NextRequest) {
  try {
    const client = getLurkyClient()
    const url = new URL(req.url)

    const page = Number(url.searchParams.get("page") ?? "0")
    const limit = Number(url.searchParams.get("limit") ?? "50")
    const speaker_id = url.searchParams.get("speaker_id") ?? undefined
    const coin_symbol = url.searchParams.get("coin_symbol") ?? undefined
    const sentiment = url.searchParams.get("sentiment") as "bullish" | "neutral" | "bearish" | undefined
    const from_date = url.searchParams.get("from_date") ?? undefined
    const to_date = url.searchParams.get("to_date") ?? undefined

    const lurkyRes = await client.listDiscussions({
      page,
      limit,
      speaker_id,
      coin_symbol,
      sentiment,
      from_date,
      to_date,
    })

    return NextResponse.json(
      {
        discussions: lurkyRes.discussions ?? [],
        page,
        limit,
        total: lurkyRes.total,
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("Lurky discussions error:", error)
    return NextResponse.json({ error: "Failed to fetch discussions" }, { status: 500 })
  }
}
