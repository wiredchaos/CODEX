// app/api/lurky/spaces/[spaceId]/route.ts
import { type NextRequest, NextResponse } from "next/server"
import { getLurkyClient } from "@/lib/lurky/client"

export async function GET(req: NextRequest, { params }: { params: Promise<{ spaceId: string }> }) {
  try {
    const { spaceId } = await params
    const url = new URL(req.url)

    const includeSpeakers = url.searchParams.get("include_speakers") === "true"
    const includeCoins = url.searchParams.get("include_coins") === "true"
    const includeDiscussions = url.searchParams.get("include_discussions") === "true"
    const includeMindMap = url.searchParams.get("include_mind_map") === "true"

    const client = getLurkyClient()
    const spaceDetails = await client.getSpaceDetails({
      space_id: spaceId,
      include_speakers: includeSpeakers,
      include_coins: includeCoins,
      include_discussions: includeDiscussions,
      include_mind_map: includeMindMap,
    })

    return NextResponse.json(spaceDetails, { status: 200 })
  } catch (error) {
    console.error("[v0] Lurky space details error:", error)
    return NextResponse.json({ error: "Failed to fetch space details" }, { status: 500 })
  }
}
