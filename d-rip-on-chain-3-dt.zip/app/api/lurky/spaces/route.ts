import { type NextRequest, NextResponse } from "next/server"
import { getLurkyClient } from "@/lib/lurky/client"

// Mock X profiles for creator IDs
const MOCK_PROFILES = [
  { twitterId: "1234567890", handle: "VIBES" },
  { twitterId: "1234567891", handle: "neurometax" },
  { twitterId: "1234567892", handle: "GATOR_789" },
]

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url)
    const page = Number(url.searchParams.get("page") ?? "0")
    const limit = Number(url.searchParams.get("limit") ?? "10")
    const state = url.searchParams.get("state") ?? "analyzed"

    // Use mock profiles instead of Prisma
    const profiles = MOCK_PROFILES

    if (!profiles.length) {
      return NextResponse.json({ spaces: [], page, limit, note: "No connected X profiles" }, { status: 200 })
    }

    const creatorIds = profiles.map((p) => p.twitterId)

    // Call Lurky client with mock creator IDs
    const client = getLurkyClient()
    const lurkyRes = await client.listSpaces({
      creator_ids: creatorIds,
      state,
      page,
      limit,
    })

    return NextResponse.json({ ...lurkyRes, profileCount: profiles.length }, { status: 200 })
  } catch (err) {
    console.error("[v0] Lurky spaces error:", err)
    return NextResponse.json({ error: "Failed to fetch spaces" }, { status: 500 })
  }
}
