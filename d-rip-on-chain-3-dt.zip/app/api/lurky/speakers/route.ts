import { type NextRequest, NextResponse } from "next/server"
import { getLurkyClient } from "@/lib/lurky/client"

export async function GET(req: NextRequest) {
  try {
    const client = getLurkyClient()
    const url = new URL(req.url)

    const page = Number(url.searchParams.get("page") ?? "0")
    const limit = Number(url.searchParams.get("limit") ?? "20")
    const min_followers = url.searchParams.get("min_followers")
    const max_followers = url.searchParams.get("max_followers")

    const lurkyRes = await client.listSpeakers({
      page,
      limit,
      min_followers: min_followers ? Number(min_followers) : undefined,
      max_followers: max_followers ? Number(max_followers) : undefined,
    })

    return NextResponse.json(
      {
        speakers: lurkyRes.data ?? lurkyRes.speakers ?? lurkyRes,
        page,
        limit,
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("Lurky speakers error:", error)
    return NextResponse.json({ error: "Failed to fetch speakers" }, { status: 500 })
  }
}
