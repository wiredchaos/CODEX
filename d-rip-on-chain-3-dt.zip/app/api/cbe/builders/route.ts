import { type NextRequest, NextResponse } from "next/server"
import { MOCK_BUILDERS } from "@/config/chaos-builder-exchange"

// GET /api/cbe/builders - List all builder profiles
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get("category")
    const skill = searchParams.get("skill")
    const verified = searchParams.get("verified")
    const concierge = searchParams.get("concierge")
    const limit = Number.parseInt(searchParams.get("limit") || "20")
    const offset = Number.parseInt(searchParams.get("offset") || "0")

    // Filter mock data (replace with Prisma queries when DB is ready)
    let builders = [...MOCK_BUILDERS]

    if (category) {
      builders = builders.filter((b) => b.industries.includes(category))
    }
    if (skill) {
      builders = builders.filter((b) => b.skills.some((s) => s.toLowerCase().includes(skill.toLowerCase())))
    }
    if (verified === "true") {
      builders = builders.filter((b) => b.isVerified)
    }
    if (concierge === "true") {
      builders = builders.filter((b) => b.isConcierge)
    }

    const total = builders.length
    builders = builders.slice(offset, offset + limit)

    return NextResponse.json({
      success: true,
      data: builders,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total,
      },
    })
  } catch (error) {
    console.error("Error fetching builders:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch builders" }, { status: 500 })
  }
}

// POST /api/cbe/builders - Create a new builder profile
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Validate required fields
    const required = ["displayName", "handle", "skills"]
    for (const field of required) {
      if (!body[field]) {
        return NextResponse.json({ success: false, error: `Missing required field: ${field}` }, { status: 400 })
      }
    }

    // In production, this would create a Prisma record
    const newBuilder = {
      id: `builder-${Date.now()}`,
      userId: body.userId || "user-temp",
      displayName: body.displayName,
      handle: body.handle,
      headline: body.headline || "",
      bio: body.bio || "",
      avatarUrl: body.avatarUrl || null,
      location: body.location || null,
      websiteUrl: body.websiteUrl || null,
      skills: body.skills || [],
      industries: body.industries || [],
      rateType: body.rateType || "project",
      hourlyRate: body.hourlyRate || null,
      isVerified: false,
      isConcierge: false,
      rating: 0,
      reviewCount: 0,
      completedProjects: 0,
      trustBadges: [],
      socialLinks: body.socialLinks || {},
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    return NextResponse.json({
      success: true,
      data: newBuilder,
      message: "Builder profile created successfully",
    })
  } catch (error) {
    console.error("Error creating builder:", error)
    return NextResponse.json({ success: false, error: "Failed to create builder profile" }, { status: 500 })
  }
}
