import { type NextRequest, NextResponse } from "next/server"

// GET /api/cbe/bookings - List bookings
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const builderId = searchParams.get("builderId")
    const clientId = searchParams.get("clientId")
    const status = searchParams.get("status")

    // Mock bookings data
    const bookings = [
      {
        id: "booking-1",
        builderId: "neuro-meta-x",
        clientId: "client-123",
        listingId: "listing-1",
        status: "active",
        agreedPrice: 5000,
        currency: "USD",
        notes: "AI strategy consultation package",
        deliveryDate: "2024-02-15T00:00:00Z",
        createdAt: "2024-01-10T09:00:00Z",
        updatedAt: "2024-01-10T09:00:00Z",
      },
    ]

    let filtered = [...bookings]
    if (builderId) filtered = filtered.filter((b) => b.builderId === builderId)
    if (clientId) filtered = filtered.filter((b) => b.clientId === clientId)
    if (status) filtered = filtered.filter((b) => b.status === status)

    return NextResponse.json({
      success: true,
      data: filtered,
    })
  } catch (error) {
    console.error("Error fetching bookings:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch bookings" }, { status: 500 })
  }
}

// POST /api/cbe/bookings - Create a new booking
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const required = ["builderId", "clientId"]
    for (const field of required) {
      if (!body[field]) {
        return NextResponse.json({ success: false, error: `Missing required field: ${field}` }, { status: 400 })
      }
    }

    const newBooking = {
      id: `booking-${Date.now()}`,
      builderId: body.builderId,
      clientId: body.clientId,
      listingId: body.listingId || null,
      status: "pending",
      agreedPrice: body.agreedPrice || null,
      currency: body.currency || "USD",
      notes: body.notes || null,
      deliveryDate: body.deliveryDate || null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    return NextResponse.json({
      success: true,
      data: newBooking,
      message: "Booking created successfully",
    })
  } catch (error) {
    console.error("Error creating booking:", error)
    return NextResponse.json({ success: false, error: "Failed to create booking" }, { status: 500 })
  }
}
