import { type NextRequest, NextResponse } from "next/server"

// Mock reviews data
const MOCK_REVIEWS = [
  {
    id: "review-1",
    builderId: "neuro-meta-x",
    reviewerId: "client-1",
    listingId: "listing-1",
    rating: 5,
    title: "Exceptional AI Strategy",
    comment: "NEURO META X delivered beyond expectations. The couture prompting transformed our entire workflow.",
    isVerified: true,
    createdAt: "2024-01-15T10:00:00Z",
    reviewer: { displayName: "Tech Founder", avatarUrl: null },
  },
  {
    id: "review-2",
    builderId: "neuro-meta-x",
    reviewerId: "client-2",
    listingId: "listing-1",
    rating: 5,
    title: "Game Changer",
    comment: "The strategic depth and creative output were unmatched. Highly recommend for serious builders.",
    isVerified: true,
    createdAt: "2024-01-20T14:30:00Z",
    reviewer: { displayName: "Agency Owner", avatarUrl: null },
  },
]

// GET /api/cbe/reviews - List reviews
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const builderId = searchParams.get("builderId")
    const listingId = searchParams.get("listingId")
    const limit = Number.parseInt(searchParams.get("limit") || "20")
    const offset = Number.parseInt(searchParams.get("offset") || "0")

    let reviews = [...MOCK_REVIEWS]

    if (builderId) {
      reviews = reviews.filter((r) => r.builderId === builderId)
    }
    if (listingId) {
      reviews = reviews.filter((r) => r.listingId === listingId)
    }

    const total = reviews.length
    reviews = reviews.slice(offset, offset + limit)

    return NextResponse.json({
      success: true,
      data: reviews,
      pagination: { total, limit, offset, hasMore: offset + limit < total },
    })
  } catch (error) {
    console.error("Error fetching reviews:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch reviews" }, { status: 500 })
  }
}

// POST /api/cbe/reviews - Create a new review
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const required = ["builderId", "rating"]
    for (const field of required) {
      if (!body[field]) {
        return NextResponse.json({ success: false, error: `Missing required field: ${field}` }, { status: 400 })
      }
    }

    if (body.rating < 1 || body.rating > 5) {
      return NextResponse.json({ success: false, error: "Rating must be between 1 and 5" }, { status: 400 })
    }

    const newReview = {
      id: `review-${Date.now()}`,
      builderId: body.builderId,
      reviewerId: body.reviewerId || null,
      listingId: body.listingId || null,
      rating: body.rating,
      title: body.title || null,
      comment: body.comment || null,
      isVerified: false,
      createdAt: new Date().toISOString(),
    }

    return NextResponse.json({
      success: true,
      data: newReview,
      message: "Review submitted successfully",
    })
  } catch (error) {
    console.error("Error creating review:", error)
    return NextResponse.json({ success: false, error: "Failed to submit review" }, { status: 500 })
  }
}
