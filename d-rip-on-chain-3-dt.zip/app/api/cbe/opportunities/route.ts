import { type NextRequest, NextResponse } from "next/server"
import { MOCK_OPPORTUNITIES } from "@/config/chaos-builder-exchange"

// GET /api/cbe/opportunities - List all opportunities
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const type = searchParams.get("type")
    const category = searchParams.get("category")
    const status = searchParams.get("status")
    const limit = Number.parseInt(searchParams.get("limit") || "20")
    const offset = Number.parseInt(searchParams.get("offset") || "0")

    let opportunities = [...MOCK_OPPORTUNITIES]

    if (type) {
      opportunities = opportunities.filter((o) => o.type === type)
    }
    if (category) {
      opportunities = opportunities.filter((o) => o.category === category)
    }
    if (status) {
      opportunities = opportunities.filter((o) => o.status === status)
    }

    const total = opportunities.length
    opportunities = opportunities.slice(offset, offset + limit)

    return NextResponse.json({
      success: true,
      data: opportunities,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total,
      },
    })
  } catch (error) {
    console.error("Error fetching opportunities:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch opportunities" }, { status: 500 })
  }
}

// POST /api/cbe/opportunities - Create a new opportunity
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const required = ["creatorId", "title", "description", "type", "category"]
    for (const field of required) {
      if (!body[field]) {
        return NextResponse.json({ success: false, error: `Missing required field: ${field}` }, { status: 400 })
      }
    }

    const newOpportunity = {
      id: `opp-${Date.now()}`,
      creatorId: body.creatorId,
      title: body.title,
      description: body.description,
      type: body.type,
      category: body.category,
      budget: body.budget || null,
      budgetMin: body.budgetMin || null,
      budgetMax: body.budgetMax || null,
      currency: body.currency || "USD",
      timeline: body.timeline || null,
      preferredSkills: body.preferredSkills || [],
      requirements: body.requirements || null,
      status: "open",
      applicationCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    return NextResponse.json({
      success: true,
      data: newOpportunity,
      message: "Opportunity posted successfully",
    })
  } catch (error) {
    console.error("Error creating opportunity:", error)
    return NextResponse.json({ success: false, error: "Failed to post opportunity" }, { status: 500 })
  }
}
