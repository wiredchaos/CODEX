import { type NextRequest, NextResponse } from "next/server"
import { MOCK_LISTINGS } from "@/config/chaos-builder-exchange"

// GET /api/cbe/listings - List all service listings
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get("category")
    const builderId = searchParams.get("builderId")
    const featured = searchParams.get("featured")
    const minPrice = searchParams.get("minPrice")
    const maxPrice = searchParams.get("maxPrice")
    const limit = Number.parseInt(searchParams.get("limit") || "20")
    const offset = Number.parseInt(searchParams.get("offset") || "0")

    let listings = [...MOCK_LISTINGS]

    if (category) {
      listings = listings.filter((l) => l.category === category)
    }
    if (builderId) {
      listings = listings.filter((l) => l.builderId === builderId)
    }
    if (featured === "true") {
      listings = listings.filter((l) => l.isFeatured)
    }
    if (minPrice) {
      listings = listings.filter((l) => l.basePrice >= Number.parseInt(minPrice))
    }
    if (maxPrice) {
      listings = listings.filter((l) => l.basePrice <= Number.parseInt(maxPrice))
    }

    const total = listings.length
    listings = listings.slice(offset, offset + limit)

    return NextResponse.json({
      success: true,
      data: listings,
      pagination: {
        total,
        limit,
        offset,
        hasMore: offset + limit < total,
      },
    })
  } catch (error) {
    console.error("Error fetching listings:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch listings" }, { status: 500 })
  }
}

// POST /api/cbe/listings - Create a new service listing
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const required = ["builderId", "title", "description", "category", "basePrice"]
    for (const field of required) {
      if (!body[field]) {
        return NextResponse.json({ success: false, error: `Missing required field: ${field}` }, { status: 400 })
      }
    }

    const newListing = {
      id: `listing-${Date.now()}`,
      builderId: body.builderId,
      title: body.title,
      description: body.description,
      category: body.category,
      subcategory: body.subcategory || null,
      basePrice: body.basePrice,
      currency: body.currency || "USD",
      deliveryTime: body.deliveryTime || "7 days",
      revisions: body.revisions || 2,
      features: body.features || [],
      requirements: body.requirements || null,
      isFeatured: false,
      isActive: true,
      rating: 0,
      reviewCount: 0,
      orderCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    return NextResponse.json({
      success: true,
      data: newListing,
      message: "Service listing created successfully",
    })
  } catch (error) {
    console.error("Error creating listing:", error)
    return NextResponse.json({ success: false, error: "Failed to create listing" }, { status: 500 })
  }
}
