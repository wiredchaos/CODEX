import { type NextRequest, NextResponse } from "next/server"

export async function POST(req: NextRequest) {
  try {
    const { userId, boostType, targetId, targetType, amount, currency, txHash } = await req.json()

    if (!userId || !boostType || !targetId || !amount || !currency) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    return NextResponse.json(
      {
        message: "Database not initialized - boost feature disabled",
        info: "Run scripts/001_create_33fm_tables.sql to enable AUX boost engine",
        mockBoost: {
          id: `boost_mock_${Date.now()}`,
          userId,
          boostType,
          targetId,
          targetType,
          amount,
          currency,
          txHash: txHash || `0x${Math.random().toString(16).substring(2, 66)}`,
          status: "mock_only",
          createdAt: new Date().toISOString(),
        },
      },
      { status: 503 },
    )
  } catch (error) {
    console.error("[v0] Boost error:", error)
    return NextResponse.json({ error: "Boost failed" }, { status: 500 })
  }
}

export async function GET(req: NextRequest) {
  try {
    return NextResponse.json({
      boosts: [],
      dbStatus: "mock_data",
      message: "No boosts available. Database not initialized.",
    })
  } catch (error) {
    console.error("[v0] Fetch boosts error:", error)
    return NextResponse.json({ error: "Failed to fetch boosts" }, { status: 500 })
  }
}
