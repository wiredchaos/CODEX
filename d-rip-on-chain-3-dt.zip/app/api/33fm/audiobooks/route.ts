import { type NextRequest, NextResponse } from "next/server"
import { mockAudiobooks } from "@/lib/33fm-mock-data"

const MOCK_AUDIOBOOKS = [
  {
    id: "ab_1",
    title: "The Neon Chronicles",
    author: "J.R. Cyberpunk",
    narrator: "Nova Voice",
    coverArtUrl: "/neon-album-art.jpg",
    chapters: 12,
    totalDuration: 7200,
    creator: {
      handle: "novastudios",
      user: { displayName: "Nova Studios" },
    },
    createdAt: new Date().toISOString(),
  },
]

export async function POST(req: NextRequest) {
  try {
    const { creatorId, title, author, narrator, coverArtUrl, chapters, totalDuration } = await req.json()

    if (!creatorId || !title || !chapters || !totalDuration) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    return NextResponse.json(
      {
        message: "Database not initialized - audiobook upload disabled",
        info: "Run scripts/001_create_33fm_tables.sql to enable audiobook uploads",
        mockAudiobook: {
          id: `ab_mock_${Date.now()}`,
          creatorId,
          title,
          author,
          narrator,
          coverArtUrl,
          chapters,
          totalDuration,
          createdAt: new Date().toISOString(),
          status: "mock_only",
        },
      },
      { status: 503 },
    )

    // try {
    //   const { prisma } = await import("@/lib/prisma")

    //   const audiobook = await prisma.fMAudiobook.create({
    //     data: {
    //       creatorId,
    //       title,
    //       author: author || "Unknown",
    //       narrator: narrator || "Unknown",
    //       coverArtUrl,
    //       chapters,
    //       totalDuration,
    //     },
    //   })

    //   return NextResponse.json({ success: true, audiobook })
    // } catch (dbError) {
    //   return NextResponse.json(
    //     {
    //       error: "Database not initialized",
    //       message: "Please run the 33FM migration script",
    //       mockResponse: {
    //         id: `ab_mock_${Date.now()}`,
    //         creatorId,
    //         title,
    //         author,
    //         narrator,
    //         coverArtUrl,
    //         chapters,
    //         totalDuration,
    //         createdAt: new Date().toISOString(),
    //       },
    //     },
    //     { status: 503 },
    //   )
    // }
  } catch (error) {
    console.error("[v0] Create audiobook error:", error)
    return NextResponse.json({ error: "Failed to create audiobook" }, { status: 500 })
  }
}

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url)
    const creatorId = url.searchParams.get("creatorId")

    let audiobooks = mockAudiobooks

    // Filter by creator if requested
    if (creatorId) {
      audiobooks = mockAudiobooks.filter((ab) => ab.creator.handle === creatorId)
    }

    return NextResponse.json({
      audiobooks,
      dbStatus: "mock_data",
      message: "Using mock data. Run scripts/001_create_33fm_tables.sql to enable database storage.",
    })
  } catch (error) {
    console.error("[v0] Fetch audiobooks error:", error)
    return NextResponse.json({ error: "Failed to fetch audiobooks" }, { status: 500 })
  }
}
