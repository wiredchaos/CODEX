import { type NextRequest, NextResponse } from "next/server"
import { mockPodcasts } from "@/lib/33fm-mock-data"

const MOCK_PODCASTS = [
  {
    id: "pod_1",
    title: "Wired Chaos Chronicles Ep 1",
    description: "The origin story of the chaos network",
    audioUrl: "/audio/wcc-ep1.mp3",
    coverArtUrl: "/neon-album-art.jpg",
    duration: 3600,
    episodeNum: 1,
    seasonNum: 1,
    creator: {
      handle: "wcpodcast",
      user: { displayName: "Wired Chaos Podcast" },
    },
    createdAt: new Date().toISOString(),
  },
]

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()

    return NextResponse.json(
      {
        message: "Database not initialized - podcast upload disabled",
        info: "Run scripts/001_create_33fm_tables.sql to enable podcast uploads",
        mockPodcast: {
          id: `pod_mock_${Date.now()}`,
          ...body,
          createdAt: new Date().toISOString(),
          status: "mock_only",
        },
      },
      { status: 503 },
    )
  } catch (error) {
    console.error("[v0] Create podcast error:", error)
    return NextResponse.json({ error: "Failed to create podcast" }, { status: 500 })
  }
}

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url)
    const creatorId = url.searchParams.get("creatorId")

    let podcasts = mockPodcasts

    // Filter by creator if requested
    if (creatorId) {
      podcasts = mockPodcasts.filter((p) => p.creator.handle === creatorId)
    }

    return NextResponse.json({
      podcasts,
      dbStatus: "mock_data",
      message: "Using mock data. Run scripts/001_create_33fm_tables.sql to enable database storage.",
    })
  } catch (error) {
    console.error("[v0] Fetch podcasts error:", error)
    return NextResponse.json({ error: "Failed to fetch podcasts" }, { status: 500 })
  }
}
