import { type NextRequest, NextResponse } from "next/server"
import { mockTracks } from "@/lib/33fm-mock-data"

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url)
    const page = Number(url.searchParams.get("page") ?? "0")
    const limit = Number(url.searchParams.get("limit") ?? "20")
    const genre = url.searchParams.get("genre")

    let tracks = mockTracks
    let total = mockTracks.length

    // Filter by genre if requested
    if (genre) {
      tracks = tracks.filter((t) => t.genre === genre)
      total = tracks.length
    }

    // Apply pagination
    const paginatedTracks = tracks.slice(page * limit, (page + 1) * limit)

    return NextResponse.json({
      tracks: paginatedTracks,
      page,
      limit,
      total,
      dbStatus: "mock_data",
      message: "Using mock data. Run scripts/001_create_33fm_tables.sql to enable database storage.",
    })
  } catch (error) {
    console.error("[v0] 33FM tracks error:", error)
    return NextResponse.json(
      {
        error: "Failed to fetch tracks",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { title, audioUrl, coverArtUrl, duration, genre, mintChain } = body

    return NextResponse.json(
      {
        message: "Database not initialized - track upload disabled",
        info: "Run scripts/001_create_33fm_tables.sql to enable track uploads",
        mockTrack: {
          id: `mock_${Date.now()}`,
          title,
          audioUrl,
          coverArtUrl,
          duration,
          genre,
          mintChain: mintChain || "DOGE",
          createdAt: new Date().toISOString(),
          status: "mock_only",
        },
      },
      { status: 503 },
    )
  } catch (error) {
    console.error("[v0] 33FM track upload error:", error)
    return NextResponse.json(
      {
        error: "Failed to upload track",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
