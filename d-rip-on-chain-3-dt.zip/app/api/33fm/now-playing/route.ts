import { type NextRequest, NextResponse } from "next/server"

export const runtime = "edge"

// This would connect to KV for real-time data
export async function GET(req: NextRequest) {
  // TODO: Connect to Vercel KV for real-time now_playing data
  const mockNowPlaying = {
    track: {
      id: "track_001",
      title: "Neon Frequencies",
      creatorHandle: "djredfang",
      creatorName: "DJ Red Fang",
      coverArtUrl: "/neon-album-art.jpg",
      duration: 245,
      currentTime: 67,
      genre: "Electronic",
    },
    nextUp: [
      {
        id: "track_002",
        title: "Chaos Protocol",
        creatorHandle: "neurometax",
        duration: 198,
      },
      {
        id: "track_003",
        title: "Digital Uprising",
        creatorHandle: "shadowlux",
        duration: 223,
      },
    ],
    listeners: 342,
    show: {
      title: "DJ Red Fang Morning Mix",
      host: "DJ Red Fang",
    },
  }

  return NextResponse.json(mockNowPlaying, {
    headers: {
      "Cache-Control": "no-cache, no-store, must-revalidate",
    },
  })
}
