import { type NextRequest, NextResponse } from "next/server"

const MINT_FEES = {
  nftHolder: 0.03,
  nonHolder: 0.05,
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { userId, trackId, hasNFT } = body

    if (!userId || !trackId) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const mintFee = hasNFT ? MINT_FEES.nftHolder : MINT_FEES.nonHolder

    const mockMintResponse = {
      message: "Database not initialized - minting feature disabled",
      info: "Run scripts/001_create_33fm_tables.sql to enable track minting",
      mockMint: {
        trackId,
        mintFeePercent: mintFee * 100,
        txHash: "0x" + Math.random().toString(16).substring(2, 66),
        chain: "DOGE",
        status: "mock_only",
        createdAt: new Date().toISOString(),
      },
    }

    return NextResponse.json(mockMintResponse, { status: 503 })
  } catch (error) {
    console.error("[v0] 33FM mint error:", error)
    return NextResponse.json({ error: "Minting failed" }, { status: 500 })
  }
}
