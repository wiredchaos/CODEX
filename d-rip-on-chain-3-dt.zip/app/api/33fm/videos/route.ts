import { NextResponse } from "next/server"
import { getMockVideos } from "@/lib/33fm-mock-data"

export async function GET() {
  try {
    const videos = getMockVideos()

    return NextResponse.json(
      {
        videos,
        dbStatus: "mock_data",
        note: "Using mock video data. Run migration to enable real database.",
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("33FM videos API error:", error)
    return NextResponse.json({ error: "Failed to fetch videos", videos: [] }, { status: 500 })
  }
}
