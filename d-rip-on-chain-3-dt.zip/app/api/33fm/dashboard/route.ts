import { type NextRequest, NextResponse } from "next/server"
import { mockStats, mockTracks, mockNowPlaying } from "@/lib/33fm-mock-data"

export async function GET(req: NextRequest) {
  try {
    // Return mock data - to enable real database, run scripts/001_create_33fm_tables.sql
    return NextResponse.json({
      stats: mockStats,
      recentTracks: mockTracks,
      nowPlaying: mockNowPlaying,
      dbStatus: "mock_data",
      message:
        "Using mock data. To enable real data storage, run the SQL migration in scripts/001_create_33fm_tables.sql",
    })
  } catch (error) {
    console.error("[v0] 33FM dashboard error:", error)
    return NextResponse.json(
      {
        error: "Failed to load dashboard data",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
