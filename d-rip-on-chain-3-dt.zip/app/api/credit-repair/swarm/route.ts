import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { routeAgent } from "@/lib/credit-repair/swarm/router"
import type { AgentId } from "@/lib/credit-repair/types"

export async function POST(request: Request) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { agentId, payload } = body as { agentId: AgentId; payload: unknown }

    if (!agentId || !payload) {
      return NextResponse.json({ error: "agentId and payload are required" }, { status: 400 })
    }

    const response = await routeAgent({
      agentId,
      userId: user.id,
      payload,
    })

    return NextResponse.json(response)
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Unknown error" }, { status: 500 })
  }
}
