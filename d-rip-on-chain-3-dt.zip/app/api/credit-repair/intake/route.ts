import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { validateIntakeForm } from "@/lib/credit-repair/validators/intake"
import { analyzeCreditProfile } from "@/lib/credit-repair/services/credit-analysis-service"
import type { CreditProfile } from "@/lib/credit-repair/types"

export async function POST(request: Request) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const validation = validateIntakeForm(body)

    if (!validation.success) {
      return NextResponse.json({ error: "Validation failed", details: validation.errors }, { status: 400 })
    }

    const formData = validation.data!

    // Upsert user record
    await supabase.from("cr_users").upsert({
      id: user.id,
      email: formData.email,
      name: formData.name,
      phone: formData.phone,
      onboarding_completed: true,
      updated_at: new Date().toISOString(),
    })

    // Create credit profile
    const hasCollections = formData.collectionsCount > 0
    const derogatoryCount = Math.floor((formData.collectionsCount + formData.latePaymentsCount) * 0.3)

    const profileData: Partial<CreditProfile> = {
      userId: user.id,
      scoreRange: formData.scoreRange,
      hasCollections,
      collectionsCount: formData.collectionsCount,
      latePaymentsCount: formData.latePaymentsCount,
      derogatoryItemsCount: derogatoryCount,
      utilizationPercent: formData.utilizationPercent,
      inquiriesCount: formData.inquiriesCount,
      goals: formData.goals,
      timelinePreference: formData.timelinePreference,
    }

    // Analyze to determine tier
    const analysis = analyzeCreditProfile(profileData as CreditProfile)

    const { data: profile, error: profileError } = await supabase
      .from("cr_credit_profiles")
      .insert({
        user_id: user.id,
        score_range: profileData.scoreRange,
        has_collections: profileData.hasCollections,
        collections_count: profileData.collectionsCount,
        late_payments_count: profileData.latePaymentsCount,
        derogatory_items_count: profileData.derogatoryItemsCount,
        utilization_percent: profileData.utilizationPercent,
        inquiries_count: profileData.inquiriesCount,
        goals: profileData.goals,
        timeline_preference: profileData.timelinePreference,
        profile_tier: analysis.profileTier,
      })
      .select()
      .single()

    if (profileError) {
      return NextResponse.json({ error: profileError.message }, { status: 500 })
    }

    // Log funnel event
    await supabase.from("cr_funnel_events").insert({
      user_id: user.id,
      type: "COMPLETE_INTAKE",
      payload: { profileTier: analysis.profileTier },
    })

    return NextResponse.json({
      success: true,
      profile,
      analysis,
    })
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Unknown error" }, { status: 500 })
  }
}
