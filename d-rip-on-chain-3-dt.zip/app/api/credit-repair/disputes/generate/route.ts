import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { routeAgent } from "@/lib/credit-repair/swarm/router"
import type { DisputeEnginePayload } from "@/lib/credit-repair/types"

export async function POST(request: Request) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { creditProfileId, disputeItemIds, templateIds } = body

    // Fetch dispute items
    const { data: disputeItems, error: itemsError } = await supabase
      .from("cr_dispute_items")
      .select("*")
      .in("id", disputeItemIds)

    if (itemsError || !disputeItems) {
      return NextResponse.json({ error: "Failed to fetch dispute items" }, { status: 400 })
    }

    // Transform to expected format
    const transformedItems = disputeItems.map((item) => ({
      id: item.id,
      creditProfileId: item.credit_profile_id,
      type: item.type,
      creditorName: item.creditor_name,
      accountNumberMasked: item.account_number_masked,
      reportedDate: item.reported_date ? new Date(item.reported_date) : new Date(),
      amount: item.amount,
      notes: item.notes,
      status: item.status,
    }))

    const payload: DisputeEnginePayload = {
      userId: user.id,
      creditProfileId,
      disputeItems: transformedItems,
      strategies: templateIds,
    }

    const response = await routeAgent({
      agentId: "DISPUTE_ENGINE",
      userId: user.id,
      payload,
    })

    if (!response.success) {
      return NextResponse.json({ error: response.errors?.join(", ") }, { status: 500 })
    }

    // Save generated letters to database
    const letters = (response.data as { letters: Array<Record<string, unknown>> }).letters
    for (const letter of letters) {
      await supabase.from("cr_dispute_letters").insert({
        user_id: user.id,
        credit_profile_id: creditProfileId,
        letter_type: letter.letterType,
        target: letter.target,
        bureau: letter.bureau,
        title: letter.title,
        body: letter.body,
        status: "DRAFT",
      })
    }

    return NextResponse.json({
      success: true,
      data: response.data,
    })
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Unknown error" }, { status: 500 })
  }
}
