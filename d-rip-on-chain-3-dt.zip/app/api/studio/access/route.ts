import { NextResponse } from "next/server"

// Temporary access endpoint - replace with real NFT/wallet/Stripe logic
export async function GET() {
  // For testing, change this value:
  // "creator" - basic rooms only
  // "producer" - all Producer-gated rooms
  // "syndicate" - all rooms + future extras
  // null - no access (free tier)

  return NextResponse.json({
    tier: "producer" as const,
  })
}
