import { type NextRequest, NextResponse } from "next/server"
import { AVATARS, ENVIRONMENTS, type AvatarRenderRequest } from "@/config/video-engine"

export async function POST(request: NextRequest) {
  try {
    const body: AvatarRenderRequest = await request.json()
    const { avatar, expression, pose, lighting, environment } = body

    // Find avatar config
    const avatarConfig = AVATARS.find((a) => a.id === avatar)
    if (!avatarConfig) {
      return NextResponse.json({ error: "Invalid avatar ID" }, { status: 400 })
    }

    // Find environment config
    const envConfig = ENVIRONMENTS.find((e) => e.id === environment)
    if (!envConfig) {
      return NextResponse.json({ error: "Invalid environment ID" }, { status: 400 })
    }

    // Generate render config
    const renderConfig = {
      id: `render_${Date.now()}`,
      avatar: {
        id: avatarConfig.id,
        name: avatarConfig.name,
        codename: avatarConfig.codename,
        pose: pose || avatarConfig.signature_pose,
        lighting_profile: avatarConfig.lighting_profile,
        motion_seed: avatarConfig.motion_seed,
      },
      expression: {
        name: expression,
        config: avatarConfig.expressions.find((e) => e.name === expression) || avatarConfig.expressions[0],
      },
      environment: {
        id: envConfig.id,
        lighting: envConfig.lighting,
      },
      intro_animation: avatarConfig.intro_animation,
      status: "rendering",
      output_format: "webm",
    }

    return NextResponse.json({
      success: true,
      render_config: renderConfig,
      message: "Avatar render initiated",
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to initiate avatar render" }, { status: 500 })
  }
}
