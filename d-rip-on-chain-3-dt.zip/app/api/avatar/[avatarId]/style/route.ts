import { type NextRequest, NextResponse } from "next/server"
import { AVATARS } from "@/config/video-engine"

export async function GET(request: NextRequest, { params }: { params: { avatarId: string } }) {
  try {
    const avatarId = params.avatarId

    // Find avatar config
    const avatarConfig = AVATARS.find((a) => a.id === avatarId)
    if (!avatarConfig) {
      return NextResponse.json({ error: "Avatar not found" }, { status: 404 })
    }

    // Return avatar style object matching AvatarStyle interface
    const avatarStyle = {
      id: avatarConfig.id,
      displayName: avatarConfig.name,
      colors: {
        primary: avatarConfig.lighting_profile.primary_color,
        secondary: avatarConfig.lighting_profile.secondary_color,
        accent: avatarConfig.lighting_profile.rim_light,
        shadow: "#000000",
      },
      lightingProfile: mapLightingProfile(avatarConfig.lighting_profile),
      motionProfile: mapMotionProfile(avatarConfig.motion_seed),
    }

    return NextResponse.json(avatarStyle)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch avatar style" }, { status: 500 })
  }
}

function mapLightingProfile(profile: any): string {
  // Map lighting profile colors to predefined profiles
  const primary = profile.primary_color.toLowerCase()
  if (primary.includes("ff3")) return "red-fang"
  if (primary.includes("00ff")) return "frequency-lux"
  if (primary.includes("a855")) return "cosmic-veil"
  if (primary.includes("8b5c")) return "shadowlux-dimmer"
  return "glass-luminance"
}

function mapMotionProfile(motion: any): string {
  const idle = motion.idle_loop.toLowerCase()
  if (idle.includes("confident") || idle.includes("authority")) return "precise"
  if (idle.includes("alert") || idle.includes("combat")) return "blade-quiet"
  if (idle.includes("guard")) return "guardian"
  if (idle.includes("data") || idle.includes("flow")) return "signal"
  if (idle.includes("lurking")) return "sovereign"
  if (idle.includes("ancestral")) return "flow"
  return "discipline"
}
