import Link from "next/link"
import { ArrowLeft, Target, Brain, Eye, Zap, Heart } from "lucide-react"

const assessmentAreas = [
  {
    name: "Cognitive Processing",
    icon: Brain,
    description: "Analyze your thinking patterns and problem-solving style",
  },
  { name: "Pattern Recognition", icon: Eye, description: "Measure your ability to identify trends and connections" },
  { name: "Technical Aptitude", icon: Zap, description: "Evaluate your natural inclination toward technical skills" },
  { name: "Creative Capacity", icon: Heart, description: "Assess your creative thinking and innovation potential" },
]

export default function StrengthAssessmentPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <Link
        href="/education"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-emerald-400 transition-colors mb-8"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Education
      </Link>

      <div className="mb-12">
        <div className="flex items-center gap-4 mb-4">
          <div className="p-4 rounded-xl bg-emerald-500/10">
            <Target className="h-8 w-8 text-emerald-400" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-emerald-400">Strength Assessment</h1>
            <p className="text-muted-foreground">Discover your unique capabilities</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
        {assessmentAreas.map((area) => (
          <div
            key={area.name}
            className="p-6 rounded-xl border border-border bg-card/50 hover:border-emerald-500/30 transition-all"
          >
            <div className="p-2 rounded-lg bg-emerald-500/10 w-fit mb-4">
              <area.icon className="h-5 w-5 text-emerald-400" />
            </div>
            <h3 className="text-lg font-semibold mb-2">{area.name}</h3>
            <p className="text-sm text-muted-foreground">{area.description}</p>
          </div>
        ))}
      </div>

      <div className="p-6 rounded-xl border border-emerald-500/30 bg-emerald-500/5">
        <h2 className="text-lg font-bold mb-2">Prototype</h2>
        <p className="text-sm text-muted-foreground">
          Assessment engine in development. Will generate personalized learning paths.
        </p>
      </div>
    </div>
  )
}
