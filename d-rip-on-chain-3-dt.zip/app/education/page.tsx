import Link from "next/link"
import { ArrowLeft, Brain, Code, Target, TrendingUp } from "lucide-react"

const educationModules = [
  {
    slug: "ai-academy",
    name: "AI Academy",
    description: "Master artificial intelligence fundamentals, prompt engineering, and multi-agent systems.",
    icon: Brain,
    status: "Active",
  },
  {
    slug: "coding-bootcamp",
    name: "Coding+ Bootcamp",
    description: "Intensive programming curriculum from fundamentals to advanced full-stack development.",
    icon: Code,
    status: "Active",
  },
  {
    slug: "strength-assessment",
    name: "Strength Assessment",
    description: "Identify your cognitive and skill strengths to optimize your learning path.",
    icon: Target,
    status: "Prototype",
  },
  {
    slug: "trading-simulator",
    name: "Trading Simulator",
    description: "Practice market analysis and trading strategies in a risk-free environment.",
    icon: TrendingUp,
    status: "Prototype",
  },
]

export default function EducationPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <Link
        href="/"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors mb-8"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Hub
      </Link>

      <div className="mb-12">
        <div className="flex items-center gap-4 mb-4">
          <div className="relative">
            <div className="w-16 h-16 rounded-full bg-emerald-500/80" />
            <div className="absolute inset-0 w-16 h-16 rounded-full bg-emerald-500/40 blur-lg" />
          </div>
          <div>
            <h1 className="text-3xl sm:text-4xl font-bold text-emerald-400">EDUCATION MODULES</h1>
            <p className="text-muted-foreground">Skill development. Knowledge acceleration.</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {educationModules.map((module) => (
          <Link
            key={module.slug}
            href={`/education/${module.slug}`}
            className="group p-6 rounded-xl border border-border bg-card/50 hover:border-emerald-500/50 hover:bg-emerald-500/5 transition-all duration-300"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 rounded-lg bg-emerald-500/10 group-hover:bg-emerald-500/20 transition-colors">
                <module.icon className="h-6 w-6 text-emerald-400" />
              </div>
              <span
                className={`text-xs px-2 py-1 rounded ${
                  module.status === "Active" ? "bg-emerald-500/20 text-emerald-400" : "bg-muted text-muted-foreground"
                }`}
              >
                {module.status}
              </span>
            </div>
            <h3 className="text-lg font-semibold mb-2 group-hover:text-emerald-400 transition-colors">{module.name}</h3>
            <p className="text-sm text-muted-foreground">{module.description}</p>
          </Link>
        ))}
      </div>

      <div className="mt-12 p-6 rounded-xl border border-border bg-card/30">
        <h2 className="text-xl font-bold mb-4">Education Roadmap</h2>
        <ul className="space-y-2 text-sm text-muted-foreground">
          <li className="flex items-start gap-2">
            <span className="text-emerald-400 mt-1">→</span>
            <span>Adaptive learning paths based on strength assessment</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-emerald-400 mt-1">→</span>
            <span>Certification integration with WCU ranks</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-emerald-400 mt-1">→</span>
            <span>Live mentorship and cohort-based learning</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-emerald-400 mt-1">→</span>
            <span>Project-based capstone challenges</span>
          </li>
        </ul>
      </div>
    </div>
  )
}
