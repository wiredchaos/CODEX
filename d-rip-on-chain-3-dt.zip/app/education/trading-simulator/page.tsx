import Link from "next/link"
import { ArrowLeft, TrendingUp, BarChart3, CandlestickChart, Wallet } from "lucide-react"

const features = [
  { name: "Paper Trading", icon: Wallet, description: "Practice with virtual funds in real market conditions" },
  { name: "Technical Analysis", icon: CandlestickChart, description: "Learn chart patterns and indicators" },
  { name: "Portfolio Tracking", icon: BarChart3, description: "Monitor performance and optimize allocations" },
]

export default function TradingSimulatorPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <Link
        href="/education"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-emerald-400 transition-colors mb-8"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Education
      </Link>

      <div className="mb-12">
        <div className="flex items-center gap-4 mb-4">
          <div className="p-4 rounded-xl bg-emerald-500/10">
            <TrendingUp className="h-8 w-8 text-emerald-400" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-emerald-400">Trading Simulator</h1>
            <p className="text-muted-foreground">Risk-free market training</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        {features.map((feature) => (
          <div
            key={feature.name}
            className="p-6 rounded-xl border border-border bg-card/50 hover:border-emerald-500/30 transition-all"
          >
            <div className="p-2 rounded-lg bg-emerald-500/10 w-fit mb-4">
              <feature.icon className="h-5 w-5 text-emerald-400" />
            </div>
            <h3 className="text-lg font-semibold mb-2">{feature.name}</h3>
            <p className="text-sm text-muted-foreground">{feature.description}</p>
          </div>
        ))}
      </div>

      <div className="p-6 rounded-xl border border-emerald-500/30 bg-emerald-500/5">
        <h2 className="text-lg font-bold mb-2">Prototype</h2>
        <p className="text-sm text-muted-foreground">
          Full simulator with live data feeds and strategy backtesting coming soon.
        </p>
      </div>
    </div>
  )
}
