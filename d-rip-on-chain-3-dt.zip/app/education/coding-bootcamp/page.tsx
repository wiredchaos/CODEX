import Link from "next/link"
import { ArrowLeft, Code, FileCode, Database, Globe, Terminal } from "lucide-react"

const tracks = [
  { name: "Frontend Mastery", modules: 12, icon: Globe },
  { name: "Backend Engineering", modules: 14, icon: Database },
  { name: "Full-Stack Development", modules: 20, icon: FileCode },
  { name: "DevOps & Deployment", modules: 8, icon: Terminal },
]

export default function CodingBootcampPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <Link
        href="/education"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-emerald-400 transition-colors mb-8"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Education
      </Link>

      <div className="mb-12">
        <div className="flex items-center gap-4 mb-4">
          <div className="p-4 rounded-xl bg-emerald-500/10">
            <Code className="h-8 w-8 text-emerald-400" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-emerald-400">Coding+ Bootcamp</h1>
            <p className="text-muted-foreground">From zero to full-stack developer</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
        {tracks.map((track) => (
          <div
            key={track.name}
            className="p-6 rounded-xl border border-border bg-card/50 hover:border-emerald-500/30 transition-all"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 rounded-lg bg-emerald-500/10">
                <track.icon className="h-5 w-5 text-emerald-400" />
              </div>
              <span className="text-xs px-2 py-1 rounded bg-muted text-muted-foreground">{track.modules} modules</span>
            </div>
            <h3 className="text-lg font-semibold">{track.name}</h3>
          </div>
        ))}
      </div>

      <div className="p-6 rounded-xl border border-emerald-500/30 bg-emerald-500/5">
        <h2 className="text-lg font-bold mb-2">Coming Soon</h2>
        <p className="text-sm text-muted-foreground">
          Interactive coding environment with live projects and peer collaboration.
        </p>
      </div>
    </div>
  )
}
