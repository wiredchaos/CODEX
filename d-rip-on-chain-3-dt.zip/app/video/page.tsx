"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Copy, Play, Sparkles, Video, Palette, MapPin } from "lucide-react"
import {
  getCategoryOptions,
  getAvatarOptions,
  getEnvironmentOptions,
  AVATAR_OVERLAYS,
  ENVIRONMENT_OVERLAYS,
  PROVIDER_SUFFIXES,
} from "@/lib/video"
import type { VideoPromptCategory, VideoProvider, EmotionType, VideoGenerationResponse } from "@/lib/video/types"

const EMOTION_OPTIONS: { value: EmotionType; label: string }[] = [
  { value: "focused_authority", label: "Focused Authority" },
  { value: "curious_discovery", label: "Curious Discovery" },
  { value: "intense_urgency", label: "Intense Urgency" },
  { value: "calm_confidence", label: "Calm Confidence" },
  { value: "mysterious_intrigue", label: "Mysterious Intrigue" },
  { value: "playful_energy", label: "Playful Energy" },
  { value: "solemn_gravity", label: "Solemn Gravity" },
  { value: "triumphant_reveal", label: "Triumphant Reveal" },
]

const DURATION_OPTIONS = [3, 5, 8, 10, 12]

export default function VideoGeneratorPage() {
  const [category, setCategory] = useState<VideoPromptCategory>("npc.answer")
  const [avatarId, setAvatarId] = useState("neuro-meta")
  const [environmentId, setEnvironmentId] = useState("npc-neon-tunnel")
  const [duration, setDuration] = useState(3)
  const [emotion, setEmotion] = useState<EmotionType>("focused_authority")
  const [provider, setProvider] = useState<VideoProvider>("runway")
  const [contextInput, setContextInput] = useState("")
  const [result, setResult] = useState<VideoGenerationResponse | null>(null)
  const [loading, setLoading] = useState(false)

  const categoryOptions = getCategoryOptions()
  const avatarOptions = getAvatarOptions()
  const environmentOptions = getEnvironmentOptions()

  const selectedAvatar = AVATAR_OVERLAYS.find((a) => a.id === avatarId)
  const selectedEnv = ENVIRONMENT_OVERLAYS.find((e) => e.id === environmentId)

  async function handleGenerate() {
    setLoading(true)
    try {
      const requestBody: Record<string, unknown> = {
        category,
        avatarId,
        environmentId,
        duration,
        emotion,
        provider,
      }

      // Add context based on category
      if (category === "npc.answer") requestBody.messageSummary = contextInput
      if (category === "akira.seed_hook") requestBody.seedSummary = contextInput
      if (category === "akira.chapter_hook") requestBody.chapterSummary = contextInput
      if (category === "creator.trailer") requestBody.bookTone = contextInput
      if (category === "creator.chapter_spark") requestBody.chapterTheme = contextInput
      if (category === "business.training_snippet") requestBody.trainingTopic = contextInput
      if (category === "fen.vault_artifact") requestBody.artifactBrief = contextInput

      const response = await fetch("/api/video/generate-prompt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(requestBody),
      })

      const data = await response.json()
      if (response.ok) {
        setResult(data)
      } else {
        console.error("Generation failed:", data.error)
      }
    } catch (error) {
      console.error("Generation error:", error)
    } finally {
      setLoading(false)
    }
  }

  function copyToClipboard() {
    if (result?.videoPrompt) {
      navigator.clipboard.writeText(result.videoPrompt)
    }
  }

  function getContextLabel(): string {
    switch (category) {
      case "npc.answer":
        return "Message Summary"
      case "akira.seed_hook":
        return "Story Seed Summary"
      case "akira.chapter_hook":
        return "Chapter Summary"
      case "creator.trailer":
        return "Book Tone"
      case "creator.chapter_spark":
        return "Chapter Theme"
      case "business.training_snippet":
        return "Training Topic"
      case "fen.vault_artifact":
        return "Artifact Brief"
      default:
        return "Context"
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-[#00F0FF]/20 bg-[#0A0A0A]">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-[#00F0FF] to-[#FF003C] flex items-center justify-center">
              <Video className="h-5 w-5 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">WC META LABS</h1>
              <p className="text-sm text-[#00F0FF]">Video Generator Prompt Library v1.0</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <Tabs defaultValue="generator" className="space-y-6">
          <TabsList className="bg-[#1A1D1F] border border-[#00F0FF]/20">
            <TabsTrigger value="generator">Prompt Generator</TabsTrigger>
            <TabsTrigger value="avatars">Avatar Library</TabsTrigger>
            <TabsTrigger value="environments">Environments</TabsTrigger>
            <TabsTrigger value="providers">Providers</TabsTrigger>
          </TabsList>

          {/* Generator Tab */}
          <TabsContent value="generator">
            <div className="grid gap-6 lg:grid-cols-2">
              {/* Configuration Panel */}
              <Card className="border-[#00F0FF]/20 bg-[#0A0A0A]">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-[#00F0FF]" />
                    Prompt Configuration
                  </CardTitle>
                  <CardDescription>Configure your video generation parameters</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Category */}
                  <div className="space-y-2">
                    <Label className="text-[#00F0FF]">Category</Label>
                    <Select value={category} onValueChange={(v) => setCategory(v as VideoPromptCategory)}>
                      <SelectTrigger className="bg-[#1A1D1F] border-[#00F0FF]/30">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {categoryOptions.map((opt) => (
                          <SelectItem key={opt.value} value={opt.value}>
                            {opt.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Avatar */}
                  <div className="space-y-2">
                    <Label className="text-[#00F0FF]">Avatar</Label>
                    <Select value={avatarId} onValueChange={setAvatarId}>
                      <SelectTrigger className="bg-[#1A1D1F] border-[#00F0FF]/30">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {avatarOptions.map((opt) => (
                          <SelectItem key={opt.value} value={opt.value}>
                            {opt.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Environment */}
                  <div className="space-y-2">
                    <Label className="text-[#00F0FF]">Environment</Label>
                    <Select value={environmentId} onValueChange={setEnvironmentId}>
                      <SelectTrigger className="bg-[#1A1D1F] border-[#00F0FF]/30">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {environmentOptions.map((opt) => (
                          <SelectItem key={opt.value} value={opt.value}>
                            {opt.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Duration + Emotion Row */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-[#00F0FF]">Duration (sec)</Label>
                      <Select value={duration.toString()} onValueChange={(v) => setDuration(Number.parseInt(v))}>
                        <SelectTrigger className="bg-[#1A1D1F] border-[#00F0FF]/30">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {DURATION_OPTIONS.map((d) => (
                            <SelectItem key={d} value={d.toString()}>
                              {d}s
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-[#00F0FF]">Emotion</Label>
                      <Select value={emotion} onValueChange={(v) => setEmotion(v as EmotionType)}>
                        <SelectTrigger className="bg-[#1A1D1F] border-[#00F0FF]/30">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {EMOTION_OPTIONS.map((opt) => (
                            <SelectItem key={opt.value} value={opt.value}>
                              {opt.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Provider */}
                  <div className="space-y-2">
                    <Label className="text-[#00F0FF]">Video Provider</Label>
                    <Select value={provider} onValueChange={(v) => setProvider(v as VideoProvider)}>
                      <SelectTrigger className="bg-[#1A1D1F] border-[#00F0FF]/30">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="runway">Runway</SelectItem>
                        <SelectItem value="pika">Pika</SelectItem>
                        <SelectItem value="kaiber">Kaiber</SelectItem>
                        <SelectItem value="grok-video">Grok Video</SelectItem>
                        <SelectItem value="spline">Spline</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Context Input */}
                  <div className="space-y-2">
                    <Label className="text-[#00F0FF]">{getContextLabel()}</Label>
                    <Textarea
                      placeholder={`Enter ${getContextLabel().toLowerCase()}...`}
                      value={contextInput}
                      onChange={(e) => setContextInput(e.target.value)}
                      className="bg-[#1A1D1F] border-[#00F0FF]/30 min-h-[100px]"
                    />
                  </div>

                  {/* Generate Button */}
                  <Button
                    onClick={handleGenerate}
                    disabled={loading}
                    className="w-full bg-gradient-to-r from-[#00F0FF] to-[#FF003C] text-white hover:opacity-90"
                  >
                    {loading ? (
                      "Generating..."
                    ) : (
                      <>
                        <Play className="h-4 w-4 mr-2" />
                        Generate Video Prompt
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {/* Output Panel */}
              <Card className="border-[#FF003C]/20 bg-[#0A0A0A]">
                <CardHeader>
                  <CardTitle className="text-white flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <Video className="h-5 w-5 text-[#FF003C]" />
                      Generated Prompt
                    </span>
                    {result && (
                      <Button variant="outline" size="sm" onClick={copyToClipboard}>
                        <Copy className="h-4 w-4 mr-1" />
                        Copy
                      </Button>
                    )}
                  </CardTitle>
                  {result && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      <Badge variant="outline" className="border-[#00F0FF] text-[#00F0FF]">
                        {result.provider}
                      </Badge>
                      <Badge variant="outline" className="border-[#FF003C] text-[#FF003C]">
                        {result.durationSeconds}s
                      </Badge>
                      <Badge variant="outline">{result.metadata.emotion.replace("_", " ")}</Badge>
                    </div>
                  )}
                </CardHeader>
                <CardContent>
                  {result ? (
                    <div className="space-y-4">
                      <pre className="bg-[#1A1D1F] p-4 rounded-lg text-sm text-gray-300 whitespace-pre-wrap overflow-auto max-h-[500px] border border-[#00F0FF]/10">
                        {result.videoPrompt}
                      </pre>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-[#00F0FF]">Avatar</p>
                          <p className="text-gray-400">{result.avatarUsed}</p>
                        </div>
                        <div>
                          <p className="text-[#00F0FF]">Environment</p>
                          <p className="text-gray-400">{result.environmentUsed}</p>
                        </div>
                        <div>
                          <p className="text-[#00F0FF]">Hook Strategy</p>
                          <p className="text-gray-400">{result.metadata.hookStrategy}</p>
                        </div>
                        <div>
                          <p className="text-[#00F0FF]">Camera Motion</p>
                          <p className="text-gray-400">{result.metadata.cameraMotion.replace("_", " ")}</p>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="h-[300px] flex items-center justify-center text-gray-500 border border-dashed border-[#00F0FF]/20 rounded-lg">
                      Configure parameters and click Generate
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Preview Cards */}
            {selectedAvatar && selectedEnv && (
              <div className="grid md:grid-cols-2 gap-4 mt-6">
                <Card className="border-[#00F0FF]/20 bg-[#0A0A0A]">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Palette className="h-4 w-4 text-[#00F0FF]" />
                      Selected Avatar
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="font-medium text-white">{selectedAvatar.name}</p>
                    <p className="text-sm text-gray-400 mt-1">{selectedAvatar.brief}</p>
                    <div className="flex gap-2 mt-3">
                      {selectedAvatar.palette.map((color, i) => (
                        <div
                          key={i}
                          className="h-6 w-6 rounded-full border border-white/20"
                          style={{ backgroundColor: color }}
                          title={color}
                        />
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-[#FF003C]/20 bg-[#0A0A0A]">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-[#FF003C]" />
                      Selected Environment
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="font-medium text-white">{selectedEnv.name}</p>
                    <p className="text-sm text-gray-400 mt-1">{selectedEnv.brief}</p>
                    <div className="flex flex-wrap gap-1 mt-3">
                      {selectedEnv.ambientElements.map((el, i) => (
                        <Badge key={i} variant="outline" className="text-xs">
                          {el}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          {/* Avatars Tab */}
          <TabsContent value="avatars">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {AVATAR_OVERLAYS.map((avatar) => (
                <Card key={avatar.id} className="border-[#00F0FF]/20 bg-[#0A0A0A]">
                  <CardHeader>
                    <CardTitle className="text-white text-base">{avatar.name}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-sm text-gray-400">{avatar.brief}</p>
                    <div>
                      <p className="text-xs text-[#00F0FF] mb-1">Color Palette</p>
                      <div className="flex gap-2">
                        {avatar.palette.map((color, i) => (
                          <div
                            key={i}
                            className="h-6 w-6 rounded-full border border-white/20"
                            style={{ backgroundColor: color }}
                            title={color}
                          />
                        ))}
                      </div>
                      <p className="text-xs text-gray-500 mt-1">{avatar.paletteDescription}</p>
                    </div>
                    <div className="flex gap-2">
                      <Badge variant="outline" className="text-xs">
                        {avatar.defaultEmotion.replace("_", " ")}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {avatar.defaultCameraMotion.replace("_", " ")}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Environments Tab */}
          <TabsContent value="environments">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {ENVIRONMENT_OVERLAYS.map((env) => (
                <Card key={env.id} className="border-[#FF003C]/20 bg-[#0A0A0A]">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-white text-base">{env.name}</CardTitle>
                      <Badge className="bg-[#1A1D1F] text-[#00F0FF]">{env.category}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-sm text-gray-400">{env.brief}</p>
                    <div>
                      <p className="text-xs text-[#FF003C] mb-1">Ambient Elements</p>
                      <div className="flex flex-wrap gap-1">
                        {env.ambientElements.map((el, i) => (
                          <Badge key={i} variant="outline" className="text-xs">
                            {el}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="flex gap-2 text-xs">
                      <span className="text-gray-500">Patch:</span>
                      <span className="text-gray-400">{env.patch}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Providers Tab */}
          <TabsContent value="providers">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {PROVIDER_SUFFIXES.map((prov) => (
                <Card key={prov.provider} className="border-[#00F0FF]/20 bg-[#0A0A0A]">
                  <CardHeader>
                    <CardTitle className="text-white capitalize">{prov.provider}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <p className="text-xs text-[#00F0FF] mb-2">Optimizations</p>
                      <div className="flex flex-wrap gap-1">
                        {prov.optimizations.map((opt, i) => (
                          <Badge key={i} variant="outline" className="text-xs">
                            {opt}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="bg-[#1A1D1F] p-3 rounded-lg">
                      <p className="text-xs text-gray-400 whitespace-pre-wrap">{prov.suffix.trim()}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
