"use client"

import { useState } from "react"
import { CinematicHeader } from "@/components/akashic/cinematic-header"
import { LORE_DICTIONARY, CORE_FACTIONS, type LoreEntity, type CoreFaction } from "@/config/lore-canon"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function LoreDictionaryPage() {
  const [search, setSearch] = useState("")

  const filteredEntities = LORE_DICTIONARY.filter(
    (entity) =>
      entity.fictional.toLowerCase().includes(search.toLowerCase()) ||
      entity.realWorld.toLowerCase().includes(search.toLowerCase()) ||
      entity.description.toLowerCase().includes(search.toLowerCase()),
  )

  const characters = filteredEntities.filter((e) => e.type === "Character")
  const institutions = filteredEntities.filter((e) => e.type === "Institution")
  const technologies = filteredEntities.filter((e) => e.type === "Technology")
  const locations = filteredEntities.filter((e) => e.type === "Location")
  const events = filteredEntities.filter((e) => e.type === "Event")

  return (
    <div className="min-h-screen bg-black">
      <CinematicHeader
        title="LORE DICTIONARY"
        subtitle="ARG-Safe Canon Reference"
        tagline="Real World → Fictional Mappings"
        classification="MASTER ARCHIVE"
      />

      <div className="container mx-auto px-4 py-12 max-w-6xl">
        {/* Search */}
        <div className="mb-8">
          <Input
            type="text"
            placeholder="Search entities..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="bg-black/60 border-cyan-500/30 text-white placeholder:text-zinc-600 font-mono"
          />
        </div>

        <Tabs defaultValue="all" className="w-full">
          <TabsList className="bg-black/60 border border-cyan-500/20 mb-8">
            <TabsTrigger value="all">All ({filteredEntities.length})</TabsTrigger>
            <TabsTrigger value="factions">Core Factions ({CORE_FACTIONS.length})</TabsTrigger>
            <TabsTrigger value="characters">Characters ({characters.length})</TabsTrigger>
            <TabsTrigger value="institutions">Institutions ({institutions.length})</TabsTrigger>
            <TabsTrigger value="technologies">Technologies ({technologies.length})</TabsTrigger>
            <TabsTrigger value="locations">Locations ({locations.length})</TabsTrigger>
            <TabsTrigger value="events">Events ({events.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="all">
            <EntityGrid entities={filteredEntities} />
          </TabsContent>

          <TabsContent value="factions">
            <FactionGrid factions={CORE_FACTIONS} />
          </TabsContent>

          <TabsContent value="characters">
            <EntityGrid entities={characters} />
          </TabsContent>

          <TabsContent value="institutions">
            <EntityGrid entities={institutions} />
          </TabsContent>

          <TabsContent value="technologies">
            <EntityGrid entities={technologies} />
          </TabsContent>

          <TabsContent value="locations">
            <EntityGrid entities={locations} />
          </TabsContent>

          <TabsContent value="events">
            <EntityGrid entities={events} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

function EntityGrid({ entities }: { entities: LoreEntity[] }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {entities.map((entity) => (
        <Card
          key={entity.id}
          className="bg-black/60 border-cyan-500/20 backdrop-blur-sm hover:border-cyan-500/40 transition-all p-6"
        >
          <div className="flex items-start justify-between mb-3">
            <Badge variant="outline" className="border-cyan-500/30 text-cyan-400 text-xs">
              {entity.type}
            </Badge>
            <Badge variant="outline" className="border-zinc-700 text-zinc-500 text-xs">
              {entity.category}
            </Badge>
          </div>

          <h3 className="text-xl font-bold text-cyan-400 mb-2 font-mono tracking-wide">{entity.fictional}</h3>

          <p className="text-zinc-500 text-sm mb-3 line-through">{entity.realWorld}</p>

          <p className="text-zinc-300 text-sm leading-relaxed mb-4">{entity.description}</p>

          {entity.aliases && entity.aliases.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {entity.aliases.map((alias) => (
                <Badge key={alias} variant="outline" className="border-zinc-700 text-zinc-500 text-xs">
                  {alias}
                </Badge>
              ))}
            </div>
          )}
        </Card>
      ))}
    </div>
  )
}

function FactionGrid({ factions }: { factions: CoreFaction[] }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {factions.map((faction) => (
        <Card
          key={faction.id}
          className="bg-black/60 border-2 backdrop-blur-sm hover:shadow-lg transition-all p-6"
          style={{ borderColor: faction.color + "40" }}
        >
          <div className="mb-4">
            <h3 className="text-2xl font-bold mb-2 font-mono tracking-wide" style={{ color: faction.color }}>
              {faction.name}
            </h3>
            <Badge variant="outline" className="text-xs" style={{ borderColor: faction.color, color: faction.color }}>
              {faction.role}
            </Badge>
          </div>

          <p className="text-zinc-300 text-sm leading-relaxed mb-4">{faction.description}</p>

          <div className="space-y-2">
            <p className="text-zinc-500 text-xs font-mono tracking-wider">CONNECTED PATCHES:</p>
            <div className="flex flex-wrap gap-2">
              {faction.connectedPatches.map((patch) => (
                <Badge key={patch} variant="outline" className="border-zinc-700 text-zinc-400 text-xs">
                  {patch}
                </Badge>
              ))}
            </div>
          </div>
        </Card>
      ))}
    </div>
  )
}
