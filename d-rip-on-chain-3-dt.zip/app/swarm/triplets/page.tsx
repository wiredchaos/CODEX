"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { NEURO_ENTITIES, NEURO_TRIAD } from "@/config/neuro-entities"

export default function NeuroTripletsPage() {
  return (
    <main className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="border-b border-neutral-800 bg-gradient-to-r from-red-950/20 via-purple-950/20 to-yellow-950/20">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <Badge className="bg-neutral-800 mb-4">THREE SEPARATE ENTITIES</Badge>
          <h1 className="text-4xl font-black">THE NEURO TRIPLETS</h1>
          <p className="text-neutral-400 mt-2 max-w-2xl">
            Not variants. Not reflections. Not alternate forms. Three separate individuals with distinct origins,
            timelines, abilities, and story arcs — unified by the Neteru Apinaya cosmology.
          </p>

          {/* Convergence Info */}
          <div className="flex gap-4 mt-6">
            <Badge variant="outline" className="border-yellow-500 text-yellow-400">
              Convergence Key: {NEURO_TRIAD.convergenceKey}
            </Badge>
            <Badge variant="outline" className="border-cyan-500 text-cyan-400">
              Portal Frequency: {NEURO_TRIAD.portalFrequency}
            </Badge>
            <Badge variant="outline" className="border-red-500 text-red-400">
              Activation: 2038 Clockfall
            </Badge>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
        {/* Entity Cards */}
        {Object.values(NEURO_ENTITIES).map((entity) => (
          <Card
            key={entity.id}
            className="bg-neutral-950 border-neutral-800 overflow-hidden"
            style={{
              borderLeftWidth: "4px",
              borderLeftColor: entity.colorPalette.primary,
            }}
          >
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <Badge className="mb-2" style={{ backgroundColor: entity.colorPalette.primary }}>
                    {entity.apinayaAspect.replace(/_/g, " ")}
                  </Badge>
                  <CardTitle style={{ color: entity.colorPalette.primary }}>{entity.name}</CardTitle>
                  <CardDescription>{entity.title}</CardDescription>
                </div>
                <div
                  className="w-16 h-16 rounded-full"
                  style={{
                    background: `linear-gradient(135deg, ${entity.colorPalette.primary}, ${entity.colorPalette.secondary})`,
                    boxShadow: `0 0 30px ${entity.colorPalette.aura}`,
                  }}
                />
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Origin */}
              <div>
                <h4 className="text-sm font-semibold text-neutral-400 mb-2">ORIGIN</h4>
                <p className="text-neutral-300">{entity.origin}</p>
              </div>

              {/* Timeline */}
              <div>
                <h4 className="text-sm font-semibold text-neutral-400 mb-2">TIMELINE</h4>
                <p className="text-neutral-300">{entity.timeline}</p>
              </div>

              {/* Story Arc */}
              <div>
                <h4 className="text-sm font-semibold text-neutral-400 mb-2">STORY ARC</h4>
                <p className="text-neutral-300">{entity.storyArc}</p>
              </div>

              {/* Apinaya Domains */}
              <div>
                <h4 className="text-sm font-semibold text-neutral-400 mb-2">APINAYA DOMAINS</h4>
                <div className="flex flex-wrap gap-2">
                  {entity.apinayaDomains.map((domain) => (
                    <Badge
                      key={domain}
                      variant="outline"
                      style={{ borderColor: entity.colorPalette.accent, color: entity.colorPalette.accent }}
                    >
                      {domain}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Abilities */}
              <div>
                <h4 className="text-sm font-semibold text-neutral-400 mb-2">ABILITIES</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {entity.abilities.map((ability) => (
                    <div
                      key={ability}
                      className="bg-black rounded px-3 py-2 text-sm text-neutral-300 border border-neutral-800"
                    >
                      {ability}
                    </div>
                  ))}
                </div>
              </div>

              {/* Content Patches */}
              <div>
                <h4 className="text-sm font-semibold text-neutral-400 mb-2">CONTENT PATCHES</h4>
                <div className="flex flex-wrap gap-2">
                  {entity.contentPatches.map((patch) => (
                    <Badge key={patch} className="bg-neutral-800">
                      {patch.replace(/_/g, " ")}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Show Info */}
              {entity.showTitle && (
                <div className="bg-black rounded-lg p-4 border border-neutral-800">
                  <h4 className="text-sm font-semibold text-neutral-400 mb-2">TV SERIES</h4>
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-semibold" style={{ color: entity.colorPalette.primary }}>
                      {entity.showTitle}
                    </span>
                    <Badge
                      variant="outline"
                      className={
                        entity.showTier === "PUBLIC"
                          ? "border-green-500 text-green-400"
                          : entity.showTier === "SECRET"
                            ? "border-purple-500 text-purple-400"
                            : "border-yellow-500 text-yellow-400"
                      }
                    >
                      {entity.showTier}
                    </Badge>
                  </div>
                </div>
              )}

              {/* Hood Urban PhD (NEURO only) */}
              {entity.hoodUrbanPhD && (
                <div className="bg-gradient-to-r from-orange-950/30 to-black rounded-lg p-4 border border-orange-800/50">
                  <h4 className="text-sm font-semibold text-orange-400 mb-2">HOOD URBAN PhD</h4>
                  <p className="text-neutral-300 text-sm mb-3">{entity.hoodUrbanPhD.description}</p>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <h5 className="text-xs font-semibold text-neutral-500 mb-1">DISCIPLINES</h5>
                      <div className="flex flex-wrap gap-1">
                        {entity.hoodUrbanPhD.disciplines.slice(0, 4).map((d) => (
                          <Badge key={d} variant="outline" className="text-xs border-orange-500/50 text-orange-300">
                            {d}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h5 className="text-xs font-semibold text-neutral-500 mb-1">MANIFESTATIONS</h5>
                      <div className="flex flex-wrap gap-1">
                        {entity.hoodUrbanPhD.manifestations.slice(0, 4).map((m) => (
                          <Badge key={m} variant="outline" className="text-xs border-orange-500/50 text-orange-300">
                            {m}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Color Palette */}
              <div>
                <h4 className="text-sm font-semibold text-neutral-400 mb-2">COLOR PALETTE</h4>
                <div className="flex gap-2">
                  {Object.entries(entity.colorPalette).map(([name, color]) => (
                    <div key={name} className="flex flex-col items-center">
                      <div
                        className="w-8 h-8 rounded-full border border-neutral-700"
                        style={{ backgroundColor: color }}
                      />
                      <span className="text-[10px] text-neutral-500 mt-1">{name}</span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {/* Triad Convergence */}
        <Card className="bg-gradient-to-br from-neutral-950 via-black to-neutral-950 border-yellow-500/30">
          <CardHeader>
            <Badge className="w-fit bg-yellow-600">COMBINED POWER</Badge>
            <CardTitle className="text-yellow-400">{NEURO_TRIAD.combined.name}</CardTitle>
            <CardDescription>When all three awaken together</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-4 text-center">
              <div className="bg-black rounded-lg p-4 border border-yellow-500/20">
                <div className="text-2xl font-bold text-yellow-400">{NEURO_TRIAD.convergenceKey}</div>
                <div className="text-sm text-neutral-500">Convergence Key</div>
              </div>
              <div className="bg-black rounded-lg p-4 border border-yellow-500/20">
                <div className="text-lg font-bold text-yellow-400">{NEURO_TRIAD.combined.power.replace(/_/g, " ")}</div>
                <div className="text-sm text-neutral-500">Combined Power</div>
              </div>
              <div className="bg-black rounded-lg p-4 border border-yellow-500/20">
                <div className="text-lg font-bold text-yellow-400">
                  {NEURO_TRIAD.combined.triggerCondition.replace(/_/g, " ")}
                </div>
                <div className="text-sm text-neutral-500">Trigger Condition</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  )
}
