"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { TV_SHOWS } from "@/lib/swarm/lore-swarm-engine"
import { NEURO_ENTITIES } from "@/config/neuro-entities"

export default function TVShowsPage() {
  const [generatedEpisodes, setGeneratedEpisodes] = useState<Record<string, string>>({})
  const [loading, setLoading] = useState<string | null>(null)

  const generateEpisode = async (showIndex: number, season: number, episode: number) => {
    const show = TV_SHOWS[showIndex]
    const key = `${show.entity}_S${season}E${episode}`
    setLoading(key)

    try {
      const res = await fetch("/api/swarm/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nodeType: "SCREENWRITER",
          params: { showIndex, season, episode },
        }),
      })

      const data = await res.json()
      if (data.success) {
        setGeneratedEpisodes((prev) => ({
          ...prev,
          [key]: data.content.content,
        }))
      }
    } catch (error) {
      console.error("Failed to generate episode:", error)
    } finally {
      setLoading(null)
    }
  }

  return (
    <main className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="border-b border-neutral-800 bg-gradient-to-r from-red-950/20 via-purple-950/20 to-yellow-950/20">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <Badge className="bg-neutral-800 mb-4">NEURO LORE SWARM</Badge>
          <h1 className="text-4xl font-black">TV SHOW PRODUCTION</h1>
          <p className="text-neutral-400 mt-2">
            Three shows across three platforms — each NEURO entity has their own series with distinct tone and tier.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
        {TV_SHOWS.map((show, index) => {
          const entity = Object.values(NEURO_ENTITIES).find(
            (e) => e.id === show.entity || e.name.includes(show.entity.replace("_", " ")),
          )
          const entityColor = entity?.colorPalette.primary || "#ffffff"

          return (
            <Card
              key={show.showTitle}
              className="bg-neutral-950 border-neutral-800 overflow-hidden"
              style={{ borderLeftWidth: "4px", borderLeftColor: entityColor }}
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Badge
                        className={
                          show.tier === "PUBLIC"
                            ? "bg-green-600"
                            : show.tier === "SECRET"
                              ? "bg-purple-600"
                              : "bg-yellow-600"
                        }
                      >
                        {show.tier}
                      </Badge>
                      <Badge variant="outline" className="border-neutral-600">
                        {show.platform.replace(/_/g, " ")}
                      </Badge>
                    </div>
                    <CardTitle style={{ color: entityColor }}>{show.showTitle}</CardTitle>
                    <CardDescription>{show.episodeFormat}</CardDescription>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold text-neutral-400">{show.seasonCount}</div>
                    <div className="text-xs text-neutral-500">SEASONS</div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {/* Season Episodes */}
                  {Array.from({ length: show.seasonCount }, (_, seasonIndex) => (
                    <div key={seasonIndex} className="bg-black rounded-lg p-4 border border-neutral-800">
                      <h4 className="font-semibold mb-3">Season {seasonIndex + 1}</h4>
                      <div className="space-y-2">
                        {Array.from({ length: 3 }, (_, epIndex) => {
                          const key = `${show.entity}_S${seasonIndex + 1}E${epIndex + 1}`
                          const isLoading = loading === key
                          const hasContent = generatedEpisodes[key]

                          return (
                            <div key={epIndex} className="flex items-center justify-between">
                              <span className="text-sm text-neutral-400">Episode {epIndex + 1}</span>
                              <Button
                                size="sm"
                                variant="outline"
                                className="h-7 text-xs bg-transparent"
                                disabled={isLoading}
                                onClick={() => generateEpisode(index, seasonIndex + 1, epIndex + 1)}
                              >
                                {isLoading ? "Generating..." : hasContent ? "Regenerate" : "Generate"}
                              </Button>
                            </div>
                          )
                        })}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Generated Content Display */}
                {Object.entries(generatedEpisodes)
                  .filter(([key]) => key.startsWith(show.entity))
                  .map(([key, content]) => (
                    <div key={key} className="mt-4 bg-black rounded-lg p-4 border border-neutral-800">
                      <Badge className="mb-2" style={{ backgroundColor: entityColor }}>
                        {key.replace(/_/g, " ")}
                      </Badge>
                      <pre className="text-sm text-neutral-300 whitespace-pre-wrap font-mono">{content}</pre>
                    </div>
                  ))}
              </CardContent>
            </Card>
          )
        })}
      </div>
    </main>
  )
}
