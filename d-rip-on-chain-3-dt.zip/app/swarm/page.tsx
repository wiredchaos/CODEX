"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"

type NodeType = "LORE" | "SCREENWRITER" | "GAME" | "AUDIO" | "PORTAL" | "TIME_LOOP"

interface GeneratedContent {
  id: string
  nodeType: string
  targetPatch: string
  entity: string
  title: string
  content: string
  metadata: Record<string, any>
  createdAt: string
  timeAnchors: {
    frequency589: boolean
    stamp82675: boolean
    clockfall2038: boolean
  }
}

export default function SwarmControlPage() {
  const [selectedNode, setSelectedNode] = useState<NodeType>("LORE")
  const [theme, setTheme] = useState("The Akashic Prophecy")
  const [universe, setUniverse] = useState("33.3FM")
  const [loading, setLoading] = useState(false)
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent | null>(null)
  const [history, setHistory] = useState<GeneratedContent[]>([])

  const generateContent = async () => {
    setLoading(true)
    try {
      const params: Record<string, any> = {}

      if (selectedNode === "LORE") params.theme = theme
      if (selectedNode === "AUDIO") params.universe = universe
      if (selectedNode === "SCREENWRITER") {
        params.showIndex = 0
        params.season = 1
        params.episode = history.filter((h) => h.nodeType === "SCREENWRITER").length + 1
      }
      if (selectedNode === "GAME") params.patch = "VAULT_33"

      const res = await fetch("/api/swarm/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nodeType: selectedNode, params }),
      })

      const data = await res.json()
      if (data.success) {
        setGeneratedContent(data.content)
        setHistory((prev) => [data.content, ...prev].slice(0, 10))
      }
    } catch (error) {
      console.error("Generation failed:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="border-b border-red-900/50 bg-gradient-to-r from-black via-red-950/20 to-black">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-red-600 to-red-900 flex items-center justify-center">
              <span className="text-2xl font-bold">S</span>
            </div>
            <div>
              <h1 className="text-3xl font-bold text-red-500">NEURO LORE SWARM</h1>
              <p className="text-neutral-400">Master Content Engine — DJ Red Fang Constant Active</p>
            </div>
          </div>

          {/* Time Anchors */}
          <div className="flex gap-4 mt-4">
            <Badge variant="outline" className="border-cyan-500 text-cyan-400">
              589 Frequency: LOCKED
            </Badge>
            <Badge variant="outline" className="border-yellow-500 text-yellow-400">
              82675 Stamp: ACTIVE
            </Badge>
            <Badge variant="outline" className="border-red-500 text-red-400">
              2038 Anchor: STABLE
            </Badge>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Control Panel */}
          <Card className="bg-neutral-950 border-neutral-800">
            <CardHeader>
              <CardTitle className="text-red-400">Swarm Control</CardTitle>
              <CardDescription>Select content node and parameters</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm text-neutral-400 mb-2 block">Content Node</label>
                <Select value={selectedNode} onValueChange={(v) => setSelectedNode(v as NodeType)}>
                  <SelectTrigger className="bg-black border-neutral-700">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="LORE">LORE — Akira Codex</SelectItem>
                    <SelectItem value="SCREENWRITER">SCREENWRITER — TV Episodes</SelectItem>
                    <SelectItem value="AUDIO">AUDIO — 33.3FM Broadcast</SelectItem>
                    <SelectItem value="GAME">GAME — ARG Missions</SelectItem>
                    <SelectItem value="PORTAL">PORTAL — Portal Events</SelectItem>
                    <SelectItem value="TIME_LOOP">TIME_LOOP — Paradox Cycles</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {selectedNode === "LORE" && (
                <div>
                  <label className="text-sm text-neutral-400 mb-2 block">Theme</label>
                  <Input
                    value={theme}
                    onChange={(e) => setTheme(e.target.value)}
                    className="bg-black border-neutral-700"
                    placeholder="Enter lore theme..."
                  />
                </div>
              )}

              {selectedNode === "AUDIO" && (
                <div>
                  <label className="text-sm text-neutral-400 mb-2 block">Universe</label>
                  <Select value={universe} onValueChange={setUniverse}>
                    <SelectTrigger className="bg-black border-neutral-700">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="33.3FM">33.3FM</SelectItem>
                      <SelectItem value="789OTT">789 OTT</SelectItem>
                      <SelectItem value="VRG33589">VRG33589</SelectItem>
                      <SelectItem value="Vault33">Vault 33</SelectItem>
                      <SelectItem value="FEN">FEN</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}

              <Button onClick={generateContent} disabled={loading} className="w-full bg-red-600 hover:bg-red-700">
                {loading ? "Generating..." : "Generate Content"}
              </Button>
            </CardContent>
          </Card>

          {/* Generated Content Display */}
          <Card className="lg:col-span-2 bg-neutral-950 border-neutral-800">
            <CardHeader>
              <CardTitle className="text-cyan-400">Generated Content</CardTitle>
              <CardDescription>Latest swarm output</CardDescription>
            </CardHeader>
            <CardContent>
              {generatedContent ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold">{generatedContent.title}</h3>
                    <Badge variant="outline" className="border-red-500 text-red-400">
                      {generatedContent.nodeType}
                    </Badge>
                  </div>

                  <div className="flex gap-2">
                    <Badge className="bg-neutral-800">{generatedContent.targetPatch}</Badge>
                    <Badge className="bg-neutral-800">{generatedContent.entity}</Badge>
                  </div>

                  <div className="bg-black border border-neutral-800 rounded-lg p-4">
                    <pre className="text-sm text-neutral-300 whitespace-pre-wrap font-mono">
                      {generatedContent.content}
                    </pre>
                  </div>

                  <div className="flex gap-2 text-xs">
                    {generatedContent.timeAnchors.frequency589 && <span className="text-cyan-400">589: ACTIVE</span>}
                    {generatedContent.timeAnchors.stamp82675 && <span className="text-yellow-400">82675: ACTIVE</span>}
                    {generatedContent.timeAnchors.clockfall2038 && <span className="text-red-400">2038: ANCHORED</span>}
                  </div>
                </div>
              ) : (
                <div className="text-center py-12 text-neutral-500">
                  Select a node type and generate content to see results
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Entity Cards */}
        <div className="grid md:grid-cols-4 gap-4 mt-8">
          {/* DJ Red Fang - Constant */}
          <Card className="bg-gradient-to-br from-red-950/50 to-black border-red-800">
            <CardHeader className="pb-2">
              <Badge className="w-fit bg-red-600">UNIVERSAL CONSTANT</Badge>
              <CardTitle className="text-red-400">DJ RED FANG</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-neutral-400">
              <p>Immutable across all timelines, multiverses, and Apinaya layers.</p>
              <p className="mt-2 text-red-300">Frequency: 33.3FM</p>
            </CardContent>
          </Card>

          {/* NEURO of the Red Fang */}
          <Card className="bg-gradient-to-br from-orange-950/30 to-black border-orange-800/50">
            <CardHeader className="pb-2">
              <Badge className="w-fit bg-orange-600">SEKHEMET-APINAYA</Badge>
              <CardTitle className="text-orange-400">NEURO</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-neutral-400">
              <p>The Living Vector. Hood Urban PhD.</p>
              <p className="mt-2 text-orange-300">Patch: 789 OTT</p>
            </CardContent>
          </Card>

          {/* ZERO-LUX */}
          <Card className="bg-gradient-to-br from-purple-950/30 to-black border-purple-800/50">
            <CardHeader className="pb-2">
              <Badge className="w-fit bg-purple-600">NEBWET-APINAYA</Badge>
              <CardTitle className="text-purple-400">ZERO-LUX</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-neutral-400">
              <p>The Negative Vector. Silent Function.</p>
              <p className="mt-2 text-purple-300">Patch: VRG33589</p>
            </CardContent>
          </Card>

          {/* KYR'OS-33 */}
          <Card className="bg-gradient-to-br from-yellow-950/30 to-black border-yellow-800/50">
            <CardHeader className="pb-2">
              <Badge className="w-fit bg-yellow-600">MAAT-APINAYA</Badge>
              <CardTitle className="text-yellow-400">KYR'OS-33</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-neutral-400">
              <p>The Balancing Vector. Golden Echo.</p>
              <p className="mt-2 text-yellow-300">Patch: Creator Codex</p>
            </CardContent>
          </Card>
        </div>

        {/* Generation History */}
        {history.length > 0 && (
          <Card className="mt-8 bg-neutral-950 border-neutral-800">
            <CardHeader>
              <CardTitle className="text-neutral-400">Generation History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {history.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-3 bg-black rounded-lg border border-neutral-800"
                  >
                    <div className="flex items-center gap-3">
                      <Badge variant="outline" className="text-xs">
                        {item.nodeType}
                      </Badge>
                      <span className="text-sm">{item.title}</span>
                    </div>
                    <span className="text-xs text-neutral-500">{new Date(item.createdAt).toLocaleTimeString()}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </main>
  )
}
