"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { DJ_RED_FANG, BROADCAST_INTROS, PORTAL_OPENING_CONDITIONS } from "@/config/dj-red-fang"

export default function RedFangConstantPage() {
  return (
    <main className="min-h-screen bg-black text-white">
      {/* Hero */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-red-900/30 via-black to-black" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(255,0,0,0.1)_0%,_transparent_70%)]" />

        <div className="relative max-w-7xl mx-auto px-6 py-16">
          <div className="flex items-center gap-6">
            <div className="w-32 h-32 rounded-full bg-gradient-to-br from-red-500 via-red-600 to-red-900 flex items-center justify-center shadow-[0_0_60px_rgba(255,0,0,0.5)]">
              <span className="text-5xl font-black">RF</span>
            </div>
            <div>
              <Badge className="bg-red-600 mb-2">UNIVERSAL CONSTANT</Badge>
              <h1 className="text-5xl font-black text-red-500">DJ RED FANG</h1>
              <p className="text-xl text-neutral-400 mt-2">The Only Entity Unchanged Across All Reality</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
        {/* Core Description */}
        <Card className="bg-neutral-950 border-red-900/50">
          <CardHeader>
            <CardTitle className="text-red-400">The Constant</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-lg text-neutral-300 leading-relaxed">{DJ_RED_FANG.description}</p>

            <div className="mt-6 grid grid-cols-3 gap-4 text-center">
              <div className="bg-black rounded-lg p-4 border border-red-900/30">
                <div className="text-3xl font-bold text-red-500">{DJ_RED_FANG.timelinePresence}</div>
                <div className="text-sm text-neutral-500">Timeline Presence</div>
              </div>
              <div className="bg-black rounded-lg p-4 border border-red-900/30">
                <div className="text-3xl font-bold text-red-500">{DJ_RED_FANG.multiversePresence}</div>
                <div className="text-sm text-neutral-500">Multiverse Presence</div>
              </div>
              <div className="bg-black rounded-lg p-4 border border-red-900/30">
                <div className="text-3xl font-bold text-red-500">{DJ_RED_FANG.apinayaPresence}</div>
                <div className="text-sm text-neutral-500">Apinaya Presence</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Essence */}
        <Card className="bg-neutral-950 border-neutral-800">
          <CardHeader>
            <CardTitle className="text-cyan-400">Essence Attributes</CardTitle>
            <CardDescription>Core powers and roles across the multiverse</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {DJ_RED_FANG.essence.map((attr) => (
                <Badge key={attr} variant="outline" className="border-cyan-500 text-cyan-400 px-3 py-1">
                  {attr}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Adaptive Properties */}
        <Card className="bg-neutral-950 border-neutral-800">
          <CardHeader>
            <CardTitle className="text-yellow-400">Adaptive Properties</CardTitle>
            <CardDescription>How Red Fang adapts to each universe while remaining immutable</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {DJ_RED_FANG.adaptiveProperties.map((prop) => (
                <div key={prop.universe} className="bg-black rounded-lg p-4 border border-neutral-800">
                  <h4 className="font-bold text-yellow-400 mb-3">{prop.universe}</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-neutral-500">Tone:</span>
                      <span className="text-neutral-300">{prop.tone}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-500">Dialect:</span>
                      <span className="text-neutral-300">{prop.dialect}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-500">Cadence:</span>
                      <span className="text-neutral-300">{prop.cadence}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-500">Energy:</span>
                      <span className="text-neutral-300">{prop.energy}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Broadcast Intros */}
        <Card className="bg-neutral-950 border-neutral-800">
          <CardHeader>
            <CardTitle className="text-red-400">Broadcast Intros</CardTitle>
            <CardDescription>Opening transmissions for each universe</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(BROADCAST_INTROS).map(([universe, intro]) => (
                <div key={universe} className="bg-black rounded-lg p-4 border border-neutral-800">
                  <Badge className="mb-2 bg-red-900">{universe}</Badge>
                  <p className="text-neutral-300 italic font-mono text-sm">"{intro}"</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Portal Conditions */}
        <Card className="bg-neutral-950 border-neutral-800">
          <CardHeader>
            <CardTitle className="text-purple-400">Portal Opening Conditions</CardTitle>
            <CardDescription>Requirements for portal activation (Red Fang required)</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {Object.entries(PORTAL_OPENING_CONDITIONS).map(([condition, required]) => (
                <div
                  key={condition}
                  className={`p-3 rounded-lg text-center ${required ? "bg-green-900/20 border border-green-500/30" : "bg-neutral-900"}`}
                >
                  <div className={`text-2xl mb-1 ${required ? "text-green-400" : "text-neutral-600"}`}>
                    {required ? "✓" : "✗"}
                  </div>
                  <div className="text-xs text-neutral-400">{condition.replace(/([A-Z])/g, " $1").trim()}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Frequencies */}
        <Card className="bg-neutral-950 border-neutral-800">
          <CardHeader>
            <CardTitle className="text-cyan-400">Broadcast Frequencies</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4">
              {DJ_RED_FANG.broadcastFrequencies.map((freq) => (
                <div
                  key={freq}
                  className="bg-gradient-to-br from-cyan-900/30 to-black border border-cyan-500/30 rounded-lg px-6 py-4 text-center"
                >
                  <div className="text-2xl font-mono font-bold text-cyan-400">{freq}</div>
                  <div className="text-xs text-neutral-500 mt-1">ACTIVE</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  )
}
