import { ShowCard } from "@/components/media/show-card"
import { HeroPreview } from "@/components/media/hero-preview"
import { PatchPreview } from "@/components/media/patch-preview"
import { Badge } from "@/components/ui/badge"
import { Radio, Tv, Film, Sparkles } from "lucide-react"

// Show data with Ken Burns motion-still previews
const FEATURED_SHOWS = [
  {
    id: "neuro-trials",
    title: "NEURO TRIALS",
    logline: "Analog rebels hijack the stream and test black-box AI models in underground competitions.",
    mediaSrc: "/cyberpunk-neon-ai-neural-network-dark.jpg",
    status: "live" as const,
    tags: ["AI", "Competition", "Underground"],
    episodeCount: 12,
    motionDirection: "zoom-in" as const,
  },
  {
    id: "vault33-chronicles",
    title: "VAULT33 CHRONICLES",
    logline: "Deep dives into the forbidden archives. What was hidden will be revealed.",
    mediaSrc: "/dark-vault-archive-mysterious-red-glow.jpg",
    status: "upcoming" as const,
    tags: ["Lore", "Mystery", "Archives"],
    episodeCount: 8,
    motionDirection: "pan-left" as const,
  },
  {
    id: "signal-chain",
    title: "THE SIGNAL CHAIN",
    logline: "DJ Chrome Fang guides you through the frequencies. Music, culture, and the spaces between.",
    mediaSrc: "/radio-station-dj-turntables-neon-cyan.jpg",
    status: "live" as const,
    tags: ["Music", "Culture", "Radio"],
    episodeCount: 52,
    motionDirection: "pan-right" as const,
  },
  {
    id: "rupture-sessions",
    title: "RUPTURE SESSIONS",
    logline: "Live coding, live breaking, live creating. Watch the chaos unfold in real-time.",
    mediaSrc: "/live-coding-session-dark-screen-code.jpg",
    status: "in-production" as const,
    tags: ["Live", "Coding", "Creative"],
    episodeCount: 0,
    motionDirection: "zoom-out" as const,
  },
  {
    id: "two-chains",
    title: "THE TWO CHAINS",
    logline: "Red Chain vs Blue Chain. Political theater for the decentralized age.",
    mediaSrc: "/political-debate-red-blue-neon-stage.jpg",
    status: "upcoming" as const,
    tags: ["Politics", "Debate", "Web3"],
    episodeCount: 0,
    motionDirection: "pan-up" as const,
  },
  {
    id: "akira-codex",
    title: "AKIRA CODEX",
    logline: "Stories that write themselves. AI-assisted narrative experiments from the edge.",
    mediaSrc: "/book-pages-floating-magic-dark-purple.jpg",
    status: "active" as const,
    tags: ["Story", "AI", "Experimental"],
    episodeCount: 24,
    motionDirection: "pan-down" as const,
  },
]

const PATCHES = [
  {
    id: "akira-codex",
    name: "AKIRA CODEX",
    description: "AI-powered story engine and narrative experiments",
    mediaSrc: "/mystical-book-glowing-purple-magic.jpg",
    patchType: "lore" as const,
    status: "active" as const,
    accentColor: "magenta" as const,
  },
  {
    id: "vault33",
    name: "VAULT33",
    description: "The forbidden archives and hidden knowledge",
    mediaSrc: "/vault-door-red-glow-mysterious.jpg",
    patchType: "lore" as const,
    status: "active" as const,
    accentColor: "red" as const,
  },
  {
    id: "business-patch",
    name: "BUSINESS PATCH",
    description: "Enterprise tools and professional services",
    mediaSrc: "/corporate-office-futuristic-cyan.jpg",
    patchType: "business" as const,
    status: "active" as const,
    accentColor: "cyan" as const,
  },
  {
    id: "edu-import",
    name: "EDU IMPORT",
    description: "Technical education and curriculum systems",
    mediaSrc: "/university-library-futuristic-hologram.jpg",
    patchType: "system" as const,
    status: "beta" as const,
    accentColor: "amber" as const,
  },
]

export default function OTTPage() {
  return (
    <div className="min-h-screen bg-[#05060A]">
      {/* Hero Section */}
      <section className="relative">
        <HeroPreview
          title="NEURO TRIALS"
          subtitle="789 STUDIOS PRESENTS"
          description="Analog rebels hijack the stream and test black-box AI models in underground competitions. Season 2 premieres this week."
          mediaSrc="/cyberpunk-arena-ai-competition-neon.jpg"
          mediaMode="motion-still"
          motionDirection="zoom-in"
          status="live"
          primaryAction={{ label: "Watch Now", href: "/789-studios/watch/neuro-trials" }}
          secondaryAction={{ label: "More Info", href: "/789-studios/shows/neuro-trials" }}
          showRadioAttribution
        />
      </section>

      {/* Navigation Bar */}
      <nav className="sticky top-0 z-50 bg-[#05060A]/90 backdrop-blur-md border-b border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <Tv className="w-5 h-5 text-[#00FFFF]" />
              <span className="font-bold text-white">789 STUDIOS</span>
            </div>
            <div className="hidden md:flex items-center gap-4 text-sm">
              <a href="#shows" className="text-[#00FFFF]">
                Shows
              </a>
              <a href="#patches" className="text-zinc-400 hover:text-white">
                Patches
              </a>
              <a href="/pos" className="text-zinc-400 hover:text-white">
                POS Network
              </a>
              <a href="/33fm" className="text-zinc-400 hover:text-white">
                33.3FM
              </a>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="outline" className="border-[#FF3131]/50 text-[#FF3131] text-[10px] font-mono">
              <Radio className="w-3 h-3 mr-1 animate-pulse" />
              LIVE
            </Badge>
          </div>
        </div>
      </nav>

      {/* Shows Section */}
      <section id="shows" className="max-w-7xl mx-auto px-4 py-12">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <Film className="w-5 h-5 text-[#00FFFF]" />
            <h2 className="text-2xl font-bold text-white">All Shows</h2>
          </div>
          <div className="flex items-center gap-2 text-xs text-zinc-500">
            <Sparkles className="w-3 h-3" />
            <span className="font-mono">MOTION-STILL PREVIEWS • NO API COST</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {FEATURED_SHOWS.map((show) => (
            <ShowCard
              key={show.id}
              id={show.id}
              title={show.title}
              logline={show.logline}
              mediaSrc={show.mediaSrc}
              mediaMode="motion-still"
              motionDirection={show.motionDirection}
              status={show.status}
              tags={show.tags}
              episodeCount={show.episodeCount}
              href={`/789-studios/shows/${show.id}`}
              accentColor="cyan"
              showLoading={false}
            />
          ))}
        </div>
      </section>

      {/* Patches Section */}
      <section id="patches" className="max-w-7xl mx-auto px-4 py-12 border-t border-zinc-800">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-5 h-5 rounded bg-gradient-to-br from-[#00FFFF] to-[#FF3131]" />
          <h2 className="text-2xl font-bold text-white">Patches</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {PATCHES.map((patch) => (
            <PatchPreview
              key={patch.id}
              id={patch.id}
              name={patch.name}
              description={patch.description}
              mediaSrc={patch.mediaSrc}
              mediaMode="motion-still"
              motionDirection="pan-right"
              patchType={patch.patchType}
              status={patch.status}
              href={`/patch/${patch.id}`}
              accentColor={patch.accentColor}
            />
          ))}
        </div>
      </section>

      {/* Footer Attribution */}
      <footer className="max-w-7xl mx-auto px-4 py-8 border-t border-zinc-800">
        <div className="flex items-center justify-between text-xs font-mono text-zinc-600">
          <div>789 STUDIOS • WIRED CHAOS META LABS</div>
          <div className="flex items-center gap-2">
            <Radio className="w-3 h-3" />
            <span>SIGNAL CHAIN BY DJ CHROME FANG</span>
          </div>
        </div>
      </footer>
    </div>
  )
}
