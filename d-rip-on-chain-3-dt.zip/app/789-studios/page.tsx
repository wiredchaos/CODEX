import type { Metadata } from "next"
import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { SocialPanel } from "@/components/789-studios/social-panel"
import { Tv, Users, Radio, Film, Mic, Zap, ArrowRight, Play, BookOpen, Calendar } from "lucide-react"

export const metadata: Metadata = {
  title: "789 Studios | WIRED CHAOS META",
  description: "Official 789 Studios production hub - Creator ecosystem, OTT platform, and multimedia production",
}

const STUDIO_FEATURES = [
  {
    icon: Film,
    title: "OTT Platform",
    description: "Stream original content, audiobooks, and live events",
    href: "/789-studios/ott",
    status: "active",
  },
  {
    icon: Users,
    title: "Crew",
    description: "Meet the 789 Studios team and collaborators",
    href: "/789-studios/crew",
    status: "active",
  },
  {
    icon: Mic,
    title: "Creator Hub",
    description: "Tools and resources for content creators",
    href: "/789-studios/creators",
    status: "coming-soon",
  },
  {
    icon: Radio,
    title: "33.3FM Integration",
    description: "Connected to the DOGECHAIN frequency",
    href: "/33fm",
    status: "active",
  },
  {
    icon: BookOpen,
    title: "Audiobook Studio",
    description: "Professional audiobook production and hosting",
    href: "/789-studios/audiobooks",
    status: "coming-soon",
  },
  {
    icon: Calendar,
    title: "Live Events",
    description: "Virtual venues and live streaming",
    href: "/789-studios/events",
    status: "coming-soon",
  },
]

export default function Studios789Page() {
  return (
    <div className="min-h-screen bg-black">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-b from-cyan-500/10 via-transparent to-transparent" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-cyan-500/20 blur-[120px] rounded-full" />

        <div className="relative container mx-auto px-4">
          <div className="text-center max-w-4xl mx-auto">
            <Badge className="mb-6 bg-cyan-500/20 text-cyan-400 border-cyan-500/50">WIRED CHAOS META STUDIOS</Badge>

            <h1 className="text-5xl md:text-7xl font-black mb-6">
              <span className="text-white">789</span>
              <span className="text-cyan-400"> STUDIOS</span>
            </h1>

            <p className="text-xl text-gray-400 mb-8 max-w-2xl mx-auto">
              The creative production hub of the WIRED CHAOS META ecosystem. Building the future of decentralized
              entertainment.
            </p>

            <div className="flex flex-wrap justify-center gap-4">
              <Button size="lg" className="bg-cyan-500 text-black hover:bg-cyan-400 font-bold">
                <Play className="w-5 h-5 mr-2" />
                Explore Content
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10 bg-transparent"
              >
                <Link href="/789-studios/crew">
                  <Users className="w-5 h-5 mr-2" />
                  Meet the Crew
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-16 container mx-auto px-4">
        <h2 className="text-2xl font-bold text-white mb-8 flex items-center gap-2">
          <Zap className="w-6 h-6 text-cyan-400" />
          Studio Features
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {STUDIO_FEATURES.map((feature) => (
            <Link key={feature.title} href={feature.href}>
              <Card className="h-full border-cyan-500/30 bg-black/60 backdrop-blur-sm hover:border-cyan-400/60 hover:shadow-lg hover:shadow-cyan-500/20 transition-all group">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="w-12 h-12 rounded-lg bg-cyan-500/20 flex items-center justify-center mb-4 group-hover:bg-cyan-500/30 transition-colors">
                      <feature.icon className="w-6 h-6 text-cyan-400" />
                    </div>
                    {feature.status === "coming-soon" && (
                      <Badge variant="outline" className="text-xs border-yellow-500/50 text-yellow-500">
                        Coming Soon
                      </Badge>
                    )}
                  </div>
                  <CardTitle className="text-white group-hover:text-cyan-400 transition-colors flex items-center gap-2">
                    {feature.title}
                    <ArrowRight className="w-4 h-4 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-400">{feature.description}</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {/* Social Panel Section */}
      <section className="py-16 container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* About */}
          <Card className="border-cyan-500/30 bg-black/60 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-cyan-400 flex items-center gap-2">
                <Tv className="w-5 h-5" />
                About 789 Studios
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-gray-400">
              <p>
                789 Studios is the multimedia production arm of WIRED CHAOS META, dedicated to creating groundbreaking
                content across streaming, audio, and interactive experiences.
              </p>
              <p>
                Our mission is to empower creators with decentralized tools and platforms that put ownership and
                creative control back in the hands of artists.
              </p>
              <div className="pt-4 border-t border-cyan-500/20">
                <h4 className="text-white font-semibold mb-2">Core Pillars:</h4>
                <ul className="space-y-1">
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                    Creator-First Economics
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                    Decentralized Distribution
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                    Community Governance
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                    Cross-Platform Integration
                  </li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Social Panel */}
          <SocialPanel />
        </div>
      </section>
    </div>
  )
}
