import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CrewCard } from "@/components/789-studios/crew-card"
import { SocialPanel } from "@/components/789-studios/social-panel"
import { CREW_REGISTRY, getFeaturedCrew } from "@/lib/789-studios/crew-registry"
import { Users, ArrowLeft, Sparkles } from "lucide-react"

export const metadata: Metadata = {
  title: "Crew | 789 Studios",
  description: "Meet the 789 Studios crew - The builders behind WIRED CHAOS META",
}

export default function CrewPage() {
  const featuredCrew = getFeaturedCrew()
  const allCrew = CREW_REGISTRY

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <section className="relative py-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-cyan-500/10 via-transparent to-transparent" />
        <div className="absolute top-0 left-1/4 w-[600px] h-[300px] bg-purple-500/10 blur-[100px] rounded-full" />
        <div className="absolute top-0 right-1/4 w-[600px] h-[300px] bg-cyan-500/10 blur-[100px] rounded-full" />

        <div className="relative container mx-auto px-4">
          <Link href="/789-studios">
            <Button variant="ghost" className="mb-6 text-gray-400 hover:text-cyan-400">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to 789 Studios
            </Button>
          </Link>

          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-lg bg-cyan-500/20 flex items-center justify-center">
              <Users className="w-6 h-6 text-cyan-400" />
            </div>
            <div>
              <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/50">789 STUDIOS</Badge>
            </div>
          </div>

          <h1 className="text-4xl md:text-5xl font-black text-white mb-4">THE CREW</h1>

          <p className="text-xl text-gray-400 max-w-2xl">
            Meet the builders, creators, and visionaries behind 789 Studios and the WIRED CHAOS META ecosystem.
          </p>
        </div>
      </section>

      {/* Featured Crew */}
      <section className="py-12 container mx-auto px-4">
        <div className="flex items-center gap-2 mb-8">
          <Sparkles className="w-5 h-5 text-cyan-400" />
          <h2 className="text-xl font-bold text-white">Featured Crew</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          {featuredCrew.map((member) => (
            <CrewCard key={member.id} member={member} variant="featured" />
          ))}
        </div>
      </section>

      {/* All Crew */}
      <section className="py-12 container mx-auto px-4">
        <h2 className="text-xl font-bold text-white mb-8">All Crew Members</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {allCrew.map((member) => (
            <CrewCard key={member.id} member={member} />
          ))}
        </div>
      </section>

      {/* Social Connect */}
      <section className="py-12 container mx-auto px-4">
        <div className="max-w-xl mx-auto">
          <SocialPanel />
        </div>
      </section>
    </div>
  )
}
