import { NeuroProfileCard } from "@/components/neuro/neuro-profile-card"
import { getNeuroProfileCached } from "@/lib/lurky/neuro-profile"

export default async function NeuroProfilePage() {
  const profile = await getNeuroProfileCached()

  return (
    <div className="container mx-auto py-8 space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold">NEURO META X Profile</h1>
        <p className="text-muted-foreground">Live profile data synced from Lurky.app</p>
      </div>

      <NeuroProfileCard />

      {profile && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 border rounded-lg">
            <div className="text-2xl font-bold text-cyan-400">{profile.spacesHosted || 0}</div>
            <div className="text-sm text-muted-foreground">Spaces Hosted</div>
          </div>

          <div className="p-4 border rounded-lg">
            <div className="text-2xl font-bold text-cyan-400">
              {profile.followers ? (profile.followers / 1000).toFixed(1) + "K" : "—"}
            </div>
            <div className="text-sm text-muted-foreground">Followers</div>
          </div>

          <div className="p-4 border rounded-lg">
            <div className="text-2xl font-bold text-cyan-400">{profile.verified ? "✓" : "—"}</div>
            <div className="text-sm text-muted-foreground">Verified Status</div>
          </div>
        </div>
      )}

      <div className="text-xs text-muted-foreground">
        Last synced: {profile?.lastSyncedAt ? new Date(profile.lastSyncedAt).toLocaleString() : "Never"}
      </div>
    </div>
  )
}
