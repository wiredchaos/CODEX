"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import type { AvatarId, EnvironmentId, NpcMessage } from "@/types"

export default function NpcConsolePage() {
  const [messages, setMessages] = useState<NpcMessage[]>([])
  const [prompt, setPrompt] = useState("")
  const [loading, setLoading] = useState(false)
  const [selectedAvatar, setSelectedAvatar] = useState<AvatarId>("neuro-meta")
  const [selectedEnvironment, setSelectedEnvironment] = useState<EnvironmentId>("npc-neon-tunnel")
  const videoPreviewRef = useRef<HTMLDivElement>(null)
  const chatEndRef = useRef<HTMLDivElement>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!prompt.trim() || loading) return

    const userMessage: NpcMessage = {
      id: Date.now().toString(),
      sessionId: "session-1",
      role: "user",
      prompt: prompt.trim(),
      createdAt: new Date().toISOString(),
    }

    setMessages((prev) => [...prev, userMessage])
    setPrompt("")
    setLoading(true)

    try {
      const res = await fetch("/api/npc/answer-video", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: userMessage.prompt,
          avatar: selectedAvatar,
          environment: selectedEnvironment,
        }),
      })

      const data = await res.json()

      const agentMessage: NpcMessage = {
        id: (Date.now() + 1).toString(),
        sessionId: "session-1",
        role: "agent",
        avatarId: selectedAvatar,
        environmentId: selectedEnvironment,
        textAnswer: data.textAnswer,
        videoUrl: data.video?.url,
        thumbnailUrl: data.video?.thumbnailUrl,
        createdAt: new Date().toISOString(),
      }

      setMessages((prev) => [...prev, agentMessage])

      if (videoPreviewRef.current) {
        videoPreviewRef.current.classList.add("animate-pulse-glow")
        setTimeout(() => {
          videoPreviewRef.current?.classList.remove("animate-pulse-glow")
        }, 1500)
      }
    } catch (error) {
      console.error("[v0] NPC answer-video error:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const latestAgentMessage = messages.filter((m) => m.role === "agent").pop()

  return (
    <div className="min-h-screen bg-background text-foreground p-6">
      <div className="max-w-7xl mx-auto">
        <header className="mb-6">
          <h1 className="text-3xl font-bold text-cyan-400">NPC Console</h1>
          <p className="text-sm text-neutral-400 mt-1">Answer + Video Interface for WIRED CHAOS META Agents</p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left: Chat History */}
          <div className="lg:col-span-2 border border-neutral-800 rounded-xl p-4 bg-black/40">
            <div className="h-[60vh] overflow-y-auto space-y-4 mb-4">
              {messages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[80%] rounded-lg p-3 ${
                      msg.role === "user"
                        ? "bg-cyan-900/30 border border-cyan-700/50"
                        : "bg-neutral-900 border border-neutral-700"
                    }`}
                  >
                    {msg.role === "agent" && (
                      <div className="text-xs text-cyan-400 mb-1 font-mono">{msg.avatarId?.toUpperCase()}</div>
                    )}
                    <p className="text-sm">{msg.prompt || msg.textAnswer}</p>
                    {msg.videoUrl && <div className="mt-2 text-xs text-neutral-500">📹 Video: {msg.videoUrl}</div>}
                  </div>
                </div>
              ))}
              <div ref={chatEndRef} />
            </div>

            <form onSubmit={handleSubmit} className="flex gap-2">
              <input
                type="text"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Enter your prompt..."
                className="flex-1 bg-neutral-900 border border-neutral-700 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500"
                disabled={loading}
              />
              <button
                type="submit"
                disabled={loading}
                className="bg-cyan-600 hover:bg-cyan-700 disabled:bg-neutral-700 px-6 py-2 rounded-lg text-sm font-medium transition-colors"
              >
                {loading ? "Processing..." : "Send"}
              </button>
            </form>
          </div>

          {/* Right: Avatar & Video Preview */}
          <div className="space-y-4">
            {/* Current Avatar & Environment */}
            <div className="border border-neutral-800 rounded-xl p-4 bg-black/40">
              <h3 className="text-sm font-semibold text-cyan-400 mb-3">Current Configuration</h3>
              <div className="space-y-3">
                <div>
                  <label className="text-xs text-neutral-400 block mb-1">Avatar</label>
                  <select
                    value={selectedAvatar}
                    onChange={(e) => setSelectedAvatar(e.target.value as AvatarId)}
                    className="w-full bg-neutral-900 border border-neutral-700 rounded px-3 py-2 text-sm"
                  >
                    <option value="neuro-meta">NEURO META</option>
                    <option value="neuro-kiba">NEURO KIBA</option>
                    <option value="kiba-neuro">KIBA NEURO</option>
                    <option value="uplink">UPLINK</option>
                    <option value="oyalan-shako">Oyalán Shàkó</option>
                    <option value="shadowlux">SHADOWLUX</option>
                    <option value="grymm">GRYMM</option>
                    <option value="degen-sith">DeGenSith</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs text-neutral-400 block mb-1">Environment</label>
                  <select
                    value={selectedEnvironment}
                    onChange={(e) => setSelectedEnvironment(e.target.value as EnvironmentId)}
                    className="w-full bg-neutral-900 border border-neutral-700 rounded px-3 py-2 text-sm"
                  >
                    <option value="npc-neon-tunnel">Neon Tunnel</option>
                    <option value="npc-core-node">Core Memory Node</option>
                    <option value="business-neon-boardroom">Neon Boardroom</option>
                    <option value="akira-rupture-library">Rupture Library</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Video Preview */}
            <div ref={videoPreviewRef} className="border border-neutral-800 rounded-xl p-4 bg-black/40 transition-all">
              <h3 className="text-sm font-semibold text-cyan-400 mb-3">Video Preview</h3>
              <div className="aspect-video bg-neutral-900 rounded-lg flex items-center justify-center border border-neutral-700">
                {latestAgentMessage?.videoUrl ? (
                  <div className="text-center space-y-2">
                    <div className="text-4xl">🎬</div>
                    <div className="text-xs text-cyan-400 font-mono">{latestAgentMessage.videoUrl}</div>
                    <div className="text-xs text-neutral-500">Duration: 3-12s | Provider: Placeholder</div>
                  </div>
                ) : (
                  <div className="text-neutral-600 text-sm">Video preview will appear here</div>
                )}
              </div>
              {latestAgentMessage?.videoUrl && (
                <div className="mt-3 p-2 bg-cyan-950/30 border border-cyan-800/50 rounded text-xs text-cyan-300">
                  <strong>HOOK SUMMARY:</strong> Close-up neon shot + avatar entrance
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes pulse-glow {
          0%, 100% { box-shadow: 0 0 10px rgba(0, 255, 255, 0.3); }
          50% { box-shadow: 0 0 30px rgba(0, 255, 255, 0.8); }
        }
        .animate-pulse-glow {
          animation: pulse-glow 1.5s ease-in-out;
        }
      `}</style>
    </div>
  )
}
