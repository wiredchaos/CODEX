import { PATCHES } from "@/config/patches"
import { PatchPageTemplate } from "@/components/patch/patch-page-template"
import { notFound } from "next/navigation"

export default function NPCPage() {
  const patch = PATCHES.find((p) => p.slug === "npc")
  if (!patch) notFound()
  return <PatchPageTemplate patch={patch} />
}
