import { CinematicHeader } from "@/components/akashic/cinematic-header"
import { PipelineDashboard } from "@/components/story-engine/pipeline-dashboard"
import { StoryCreator } from "@/components/story-engine/story-creator"
import { NPCStorysmith } from "@/components/story-engine/npc-storysmith"

export const metadata = {
  title: "Story Engine | WIRED CHAOS META",
  description: "AKIRA-CREATOR Publication Pipeline",
}

export default function StoryEnginePage() {
  return (
    <div className="min-h-screen bg-black">
      {/* Scanline overlay */}
      <div className="fixed inset-0 pointer-events-none z-50 bg-[url('/textures/scanlines.png')] opacity-5" />

      {/* Film grain */}
      <div className="fixed inset-0 pointer-events-none z-40 opacity-[0.03] bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMDAiIGhlaWdodD0iMzAwIj48ZmlsdGVyIGlkPSJhIiB4PSIwIiB5PSIwIj48ZmVUdXJidWxlbmNlIGJhc2VGcmVxdWVuY3k9Ii43NSIgc3RpdGNoVGlsZXM9InN0aXRjaCIgdHlwZT0iZnJhY3RhbE5vaXNlIi8+PC9maWx0ZXI+PHJlY3Qgd2lkdGg9IjMwMCIgaGVpZ2h0PSIzMDAiIGZpbHRlcj0idXJsKCNhKSIgb3BhY2l0eT0iMC4xNSIvPjwvc3ZnPg==')]" />

      <div className="relative z-10">
        <CinematicHeader
          title="STORY ENGINE"
          subtitle="AKIRA-CREATOR Publication Pipeline"
          classification="WC META LABS // BLUE SEAL"
        />

        <main className="max-w-7xl mx-auto px-6 py-12 space-y-16">
          {/* Module ID Banner */}
          <div className="border border-cyan-500/20 rounded-lg p-4 bg-cyan-500/5">
            <div className="flex flex-wrap items-center gap-6 text-xs font-mono">
              <div>
                <span className="text-zinc-500">MODULE:</span>{" "}
                <span className="text-cyan-400">AKIRA-CREATOR STORY ENGINE</span>
              </div>
              <div>
                <span className="text-zinc-500">NAMESPACE:</span>{" "}
                <span className="text-zinc-300">WC META LABS / CREATION SYSTEMS</span>
              </div>
              <div>
                <span className="text-zinc-500">VERSION:</span> <span className="text-zinc-300">1.0</span>
              </div>
              <div>
                <span className="text-zinc-500">SECURITY:</span> <span className="text-blue-400">BLUE SEAL</span>
              </div>
            </div>
          </div>

          {/* NPC-StorySmith Terminal - Added NPC dialogue interface */}
          <section>
            <h2 className="text-xs uppercase tracking-[0.3em] text-red-500 mb-6">NPC-StorySmith Interface</h2>
            <NPCStorysmith />
          </section>

          {/* Pipeline Dashboard */}
          <section>
            <h2 className="text-xs uppercase tracking-[0.3em] text-red-500 mb-6">System Overview</h2>
            <PipelineDashboard />
          </section>

          {/* Story Creator */}
          <section>
            <h2 className="text-xs uppercase tracking-[0.3em] text-red-500 mb-6">Create Story</h2>
            <StoryCreator />
          </section>

          {/* API Routes */}
          <section>
            <h2 className="text-xs uppercase tracking-[0.3em] text-red-500 mb-6">API Route Map</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { route: "/api/akira/seed", method: "POST", desc: "Generate story seed JSON" },
                { route: "/api/akira/expand", method: "POST", desc: "Swarm expansion to novella" },
                { route: "/api/creator/convert", method: "POST", desc: "Convert novella to ebook formats" },
                { route: "/api/creator/publish", method: "POST", desc: "Push to Kindle queue + registry" },
                { route: "/api/creator/microsite", method: "POST", desc: "Spin up dedicated book page" },
                { route: "/api/chaos/assess", method: "POST", desc: "Evaluate avatar creative credit" },
              ].map((api) => (
                <div
                  key={api.route}
                  className="p-4 border border-zinc-800 rounded-lg bg-zinc-900/50 hover:border-cyan-500/30 transition-colors"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-2 py-0.5 text-xs bg-emerald-500/20 text-emerald-400 rounded font-mono">
                      {api.method}
                    </span>
                    <span className="text-sm font-mono text-cyan-400">{api.route}</span>
                  </div>
                  <p className="text-xs text-zinc-500">{api.desc}</p>
                </div>
              ))}
            </div>
          </section>
        </main>
      </div>
    </div>
  )
}
