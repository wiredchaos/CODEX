import type { Metadata } from "next"
import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { SocialPanel } from "@/components/789-studios/social-panel"
import { Zap, Tv, Radio, Shield, BookOpen, Gamepad2, ArrowRight, Globe, Database } from "lucide-react"

export const metadata: Metadata = {
  title: "WIRED CHAOS META | Hub",
  description: "The central hub of the WIRED CHAOS META ecosystem - Where all systems converge",
}

const ECOSYSTEM_PATCHES = [
  {
    id: "789-studios",
    name: "789 Studios",
    description: "Multimedia production and OTT platform",
    icon: Tv,
    href: "/789-studios",
    status: "active",
    color: "cyan",
  },
  {
    id: "33fm",
    name: "33.3FM DOGECHAIN",
    description: "Decentralized radio and creator platform",
    icon: Radio,
    href: "/33fm",
    status: "active",
    color: "pink",
  },
  {
    id: "vault33",
    name: "VAULT 33",
    description: "9-layer Akashic NFT system on XRPL",
    icon: Database,
    href: "/vault33",
    status: "active",
    color: "gold",
  },
  {
    id: "akira-codex",
    name: "AKIRA CODEX",
    description: "Story engine and narrative system",
    icon: BookOpen,
    href: "/akira-codex",
    status: "active",
    color: "red",
  },
  {
    id: "npc",
    name: "NPC Training Lab",
    description: "AI prompt training and gamification",
    icon: Gamepad2,
    href: "/npc",
    status: "active",
    color: "green",
  },
  {
    id: "nsq-guard",
    name: "NSQ GUARD",
    description: "Security and compliance infrastructure",
    icon: Shield,
    href: "/nsq-guard",
    status: "active",
    color: "purple",
  },
]

export default function WiredChaosPage() {
  return (
    <div className="min-h-screen bg-black">
      {/* Hero */}
      <section className="relative py-24 overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-cyan-500/20 blur-[150px] rounded-full" />
          <div className="absolute bottom-0 left-1/4 w-[600px] h-[300px] bg-purple-500/10 blur-[100px] rounded-full" />
          <div className="absolute bottom-0 right-1/4 w-[600px] h-[300px] bg-red-500/10 blur-[100px] rounded-full" />
        </div>

        {/* Grid overlay */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(0,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,255,0.03)_1px,transparent_1px)] bg-[size:50px_50px]" />

        <div className="relative container mx-auto px-4 text-center">
          <Badge className="mb-6 bg-cyan-500/20 text-cyan-400 border-cyan-500/50 text-sm px-4 py-1">
            MULTIVERSE HUB
          </Badge>

          <h1 className="text-6xl md:text-8xl font-black mb-6">
            <span className="text-white">WIRED</span>
            <span className="text-cyan-400"> CHAOS</span>
            <span className="block text-purple-400">META</span>
          </h1>

          <p className="text-xl text-gray-400 max-w-2xl mx-auto mb-10">
            The convergence point of all systems. Where creators build, stories unfold, and the future takes shape.
          </p>

          <div className="flex flex-wrap justify-center gap-4">
            <Button size="lg" className="bg-cyan-500 text-black hover:bg-cyan-400 font-bold">
              <Globe className="w-5 h-5 mr-2" />
              Enter Ecosystem
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10 bg-transparent"
            >
              <Link href="/patches">
                <Zap className="w-5 h-5 mr-2" />
                View All Patches
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Ecosystem Grid */}
      <section className="py-16 container mx-auto px-4">
        <h2 className="text-2xl font-bold text-white mb-8 flex items-center gap-2">
          <Zap className="w-6 h-6 text-cyan-400" />
          Ecosystem Patches
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {ECOSYSTEM_PATCHES.map((patch) => (
            <Link key={patch.id} href={patch.href}>
              <Card className="h-full border-cyan-500/30 bg-black/60 backdrop-blur-sm hover:border-cyan-400/60 hover:shadow-lg hover:shadow-cyan-500/20 transition-all group">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div
                      className={`w-12 h-12 rounded-lg bg-${patch.color}-500/20 flex items-center justify-center mb-4 group-hover:bg-${patch.color}-500/30 transition-colors`}
                    >
                      <patch.icon className={`w-6 h-6 text-${patch.color}-400`} />
                    </div>
                    <Badge
                      variant="outline"
                      className={`text-xs ${patch.status === "active" ? "border-green-500/50 text-green-400" : "border-yellow-500/50 text-yellow-500"}`}
                    >
                      {patch.status === "active" ? "ONLINE" : "BUILDING"}
                    </Badge>
                  </div>
                  <CardTitle className="text-white group-hover:text-cyan-400 transition-colors flex items-center gap-2">
                    {patch.name}
                    <ArrowRight className="w-4 h-4 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-400">{patch.description}</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {/* Social Section */}
      <section className="py-16 container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Mission */}
          <Card className="border-cyan-500/30 bg-black/60 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-cyan-400 flex items-center gap-2">
                <Zap className="w-5 h-5" />
                The Mission
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-gray-400">
              <p>
                WIRED CHAOS META is more than a platform—it's a movement. We're building the infrastructure for the next
                generation of creators, entrepreneurs, and digital pioneers.
              </p>
              <p>
                Through interconnected patches—789 Studios, 33.3FM, VAULT 33, and more—we create ecosystems where
                creativity meets technology, and ownership returns to the creator.
              </p>
              <div className="pt-4 border-t border-cyan-500/20">
                <h4 className="text-white font-semibold mb-2">Core Values:</h4>
                <ul className="grid grid-cols-2 gap-2">
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                    Decentralization
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                    Creator Ownership
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-pink-400" />
                    Community First
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-green-400" />
                    Open Innovation
                  </li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Social Panel */}
          <SocialPanel />
        </div>
      </section>
    </div>
  )
}
