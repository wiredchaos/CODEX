import type React from "react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Credit Repair Swarm Bot - AI-Powered Credit Repair",
  description:
    "AI-powered credit repair platform with DIY and Done-For-You options. Generate dispute letters, track progress, and build business credit.",
}

export default function CreditRepairLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
