"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Shield,
  FileText,
  TrendingUp,
  BookOpen,
  FolderOpen,
  Settings,
  Zap,
  AlertCircle,
  CheckCircle2,
  Clock,
  ArrowRight,
} from "lucide-react"
import Link from "next/link"
import { UPGRADE_CTAS } from "@/data/funnel-copy"

interface DashboardClientProps {
  user: {
    id: string
    name: string | null
    email: string
    plan: string
  } | null
  creditProfile: {
    id: string
    score_range: string
    profile_tier: string
    collections_count: number
    late_payments_count: number
    utilization_percent: number
    goals: string
  } | null
  letters: Array<{
    id: string
    title: string
    status: string
    letter_type: string
    created_at: string
  }>
  bootcampProgress: Array<{
    module_id: string
    status: string
  }>
}

export function DashboardClient({ user, creditProfile, letters, bootcampProgress }: DashboardClientProps) {
  const totalNegatives = creditProfile ? creditProfile.collections_count + creditProfile.late_payments_count : 0

  const completedModules = bootcampProgress.filter((p) => p.status === "COMPLETED").length
  const totalModules = 10
  const bootcampProgressPercent = (completedModules / totalModules) * 100

  const lettersSent = letters.filter((l) => l.status === "SENT").length
  const lettersResolved = letters.filter((l) => l.status === "RESPONSE_RECEIVED").length

  const showUpgradeBanner = user?.plan === "FREE" || user?.plan === "DIY"

  return (
    <div className="min-h-screen bg-muted/30">
      {/* Header */}
      <header className="border-b bg-background">
        <div className="container mx-auto flex items-center justify-between px-4 py-4">
          <div className="flex items-center gap-2">
            <Shield className="h-6 w-6" />
            <span className="font-semibold">Credit Repair Dashboard</span>
          </div>
          <nav className="flex items-center gap-4">
            <Link href="/credit-repair/documents">
              <Button variant="ghost" size="sm">
                <FolderOpen className="mr-2 h-4 w-4" />
                Documents
              </Button>
            </Link>
            <Link href="/credit-repair/settings">
              <Button variant="ghost" size="sm">
                <Settings className="mr-2 h-4 w-4" />
                Settings
              </Button>
            </Link>
          </nav>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Welcome back, {user?.name || "there"}!</h1>
          <p className="text-muted-foreground">Here&apos;s your credit repair progress at a glance</p>
        </div>

        {/* Upgrade Banner */}
        {showUpgradeBanner && (
          <Card className="mb-8 border-primary bg-primary/5">
            <CardContent className="flex items-center justify-between p-6">
              <div className="flex items-center gap-4">
                <Zap className="h-8 w-8 text-primary" />
                <div>
                  <h3 className="font-semibold">{UPGRADE_CTAS.dashboardBanner.headline}</h3>
                  <p className="text-sm text-muted-foreground">{UPGRADE_CTAS.dashboardBanner.body}</p>
                </div>
              </div>
              <Link href="/credit-repair/dfy">
                <Button>{UPGRADE_CTAS.dashboardBanner.cta}</Button>
              </Link>
            </CardContent>
          </Card>
        )}

        {/* Stats Grid */}
        <div className="mb-8 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Link href="/credit-repair/diy">
            <Card className="cursor-pointer transition-all hover:border-primary/50 hover:shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Credit Score Range</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{creditProfile?.score_range || "Not assessed"}</div>
                <p className="text-xs text-muted-foreground">Tier: {creditProfile?.profile_tier || "Unknown"}</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/credit-repair/diy">
            <Card className="cursor-pointer transition-all hover:border-primary/50 hover:shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Negative Items</CardTitle>
                <AlertCircle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalNegatives}</div>
                <p className="text-xs text-muted-foreground">
                  {creditProfile?.collections_count} collections, {creditProfile?.late_payments_count} late payments
                </p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/credit-repair/documents">
            <Card className="cursor-pointer transition-all hover:border-primary/50 hover:shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Letters Sent</CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{lettersSent}</div>
                <p className="text-xs text-muted-foreground">{lettersResolved} responses received</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/credit-repair/business-bootcamp">
            <Card className="cursor-pointer transition-all hover:border-primary/50 hover:shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Bootcamp Progress</CardTitle>
                <BookOpen className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {completedModules}/{totalModules}
                </div>
                <Progress value={bootcampProgressPercent} className="mt-2" />
              </CardContent>
            </Card>
          </Link>
        </div>

        {/* Action Cards */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {/* DIY Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Dispute Center
              </CardTitle>
              <CardDescription>Generate and manage dispute letters</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                {letters.slice(0, 3).map((letter) => (
                  <Link key={letter.id} href="/credit-repair/documents">
                    <div className="flex items-center justify-between text-sm cursor-pointer hover:bg-muted/50 -mx-2 px-2 py-1 rounded transition-colors">
                      <span className="truncate">{letter.title}</span>
                      <Badge variant={letter.status === "SENT" ? "default" : "secondary"}>{letter.status}</Badge>
                    </div>
                  </Link>
                ))}
              </div>
              <Link href="/credit-repair/diy">
                <Button className="w-full">
                  Generate New Letters
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Bootcamp */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Business Bootcamp
              </CardTitle>
              <CardDescription>Build fundable business credit</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Link href="/credit-repair/business-bootcamp">
                  <div className="flex justify-between text-sm cursor-pointer hover:bg-muted/50 -mx-2 px-2 py-1 rounded transition-colors">
                    <span>Entity Formation</span>
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                  </div>
                </Link>
                <Link href="/credit-repair/business-bootcamp">
                  <div className="flex justify-between text-sm cursor-pointer hover:bg-muted/50 -mx-2 px-2 py-1 rounded transition-colors">
                    <span>Banking Setup</span>
                    <Clock className="h-4 w-4 text-yellow-500" />
                  </div>
                </Link>
                <Link href="/credit-repair/business-bootcamp">
                  <div className="flex justify-between text-sm cursor-pointer hover:bg-muted/50 -mx-2 px-2 py-1 rounded transition-colors">
                    <span>Vendor Accounts</span>
                    <Clock className="h-4 w-4 text-muted-foreground" />
                  </div>
                </Link>
              </div>
              <Link href="/credit-repair/business-bootcamp">
                <Button variant="outline" className="w-full bg-transparent">
                  Continue Learning
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Next Best Action */}
          <Card className="border-primary">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-primary" />
                Next Best Action
              </CardTitle>
              <CardDescription>AI-recommended next step</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4 rounded-lg bg-primary/10 p-4">
                <p className="font-medium">
                  {creditProfile?.utilization_percent && creditProfile.utilization_percent > 30
                    ? "Reduce your credit utilization below 30%"
                    : creditProfile?.collections_count && creditProfile.collections_count > 0
                      ? "Send debt validation letters to collections"
                      : "Pull your latest credit reports"}
                </p>
                <p className="mt-1 text-sm text-muted-foreground">This could improve your score by 20-40 points</p>
              </div>
              <Link
                href={
                  creditProfile?.collections_count && creditProfile.collections_count > 0
                    ? "/credit-repair/diy"
                    : "/credit-repair/business-bootcamp"
                }
              >
                <Button className="w-full">Take Action Now</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
