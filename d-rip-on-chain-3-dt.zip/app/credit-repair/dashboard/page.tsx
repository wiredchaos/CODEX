import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { DashboardClient } from "./dashboard-client"

export default async function CreditRepairDashboard() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/credit-repair/auth/login")
  }

  // Fetch user data
  const { data: crUser } = await supabase.from("cr_users").select("*").eq("id", user.id).single()

  // Fetch credit profile
  const { data: creditProfile } = await supabase
    .from("cr_credit_profiles")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })
    .limit(1)
    .single()

  // Fetch dispute letters
  const { data: letters } = await supabase
    .from("cr_dispute_letters")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })

  // Fetch bootcamp progress
  const { data: bootcampProgress } = await supabase.from("cr_bootcamp_progress").select("*").eq("user_id", user.id)

  return (
    <DashboardClient
      user={crUser}
      creditProfile={creditProfile}
      letters={letters || []}
      bootcampProgress={bootcampProgress || []}
    />
  )
}
