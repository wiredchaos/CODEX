import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2, Users, Calendar, MessageSquare, ArrowLeft, Phone } from "lucide-react"
import Link from "next/link"
import { FUNNEL_COPY } from "@/data/funnel-copy"

export default async function DFYPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/credit-repair/auth/login")
  }

  // Check user plan
  const { data: crUser } = await supabase.from("cr_users").select("plan").eq("id", user.id).single()

  const isDFY = crUser?.plan === "DFY"

  return (
    <div className="min-h-screen bg-muted/30">
      <header className="border-b bg-background">
        <div className="container mx-auto flex items-center gap-4 px-4 py-4">
          <Link href="/credit-repair/dashboard">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Dashboard
            </Button>
          </Link>
          <div className="flex items-center gap-2">
            <Users className="h-6 w-6" />
            <span className="font-semibold">Done-For-You Service</span>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {isDFY ? (
          // DFY Client View
          <div className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>Your DFY Status</CardTitle>
                <CardDescription>Our team is actively working on your credit repair</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between rounded-lg border p-4">
                    <div className="flex items-center gap-3">
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                      <span>Initial Credit Analysis</span>
                    </div>
                    <Badge>Completed</Badge>
                  </div>
                  <div className="flex items-center justify-between rounded-lg border p-4">
                    <div className="flex items-center gap-3">
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                      <span>Round 1 Letters Sent</span>
                    </div>
                    <Badge>Completed</Badge>
                  </div>
                  <div className="flex items-center justify-between rounded-lg border p-4">
                    <div className="flex items-center gap-3">
                      <Calendar className="h-5 w-5 text-yellow-500" />
                      <span>Waiting for Bureau Responses</span>
                    </div>
                    <Badge variant="secondary">In Progress</Badge>
                  </div>
                  <div className="flex items-center justify-between rounded-lg border p-4">
                    <div className="flex items-center gap-3">
                      <Calendar className="h-5 w-5 text-muted-foreground" />
                      <span>Round 2 Follow-up</span>
                    </div>
                    <Badge variant="outline">Scheduled</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Contact Your Team</CardTitle>
                <CardDescription>Get in touch with your dedicated credit specialist</CardDescription>
              </CardHeader>
              <CardContent className="flex gap-4">
                <Button className="flex-1">
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Send Message
                </Button>
                <Button variant="outline" className="flex-1 bg-transparent">
                  <Phone className="mr-2 h-4 w-4" />
                  Schedule Call
                </Button>
              </CardContent>
            </Card>
          </div>
        ) : (
          // Upgrade View
          <div className="mx-auto max-w-2xl">
            <Card className="border-primary">
              <CardHeader className="text-center">
                <Badge className="mx-auto mb-4 w-fit">Premium Service</Badge>
                <CardTitle className="text-3xl">{FUNNEL_COPY.dfy.title}</CardTitle>
                <CardDescription className="text-lg">{FUNNEL_COPY.dfy.tagline}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="mb-8 space-y-4">
                  {FUNNEL_COPY.dfy.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-green-500" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                <div className="mb-6 text-center">
                  <span className="text-4xl font-bold">{FUNNEL_COPY.dfy.price}</span>
                </div>

                <Button size="lg" className="w-full">
                  {FUNNEL_COPY.dfy.cta}
                </Button>

                <p className="mt-4 text-center text-sm text-muted-foreground">
                  30-day money-back guarantee if you don't see results
                </p>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  )
}
