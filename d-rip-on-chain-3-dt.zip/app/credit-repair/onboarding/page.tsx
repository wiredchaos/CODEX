"use client"

import { useState, Suspense } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import { Shield, ArrowRight, ArrowLeft } from "lucide-react"

function OnboardingContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const initialEmail = searchParams.get("email") || ""

  const [step, setStep] = useState(1)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [formData, setFormData] = useState({
    name: "",
    email: initialEmail,
    phone: "",
    password: "",
    scoreRange: "550-620" as const,
    collectionsCount: 0,
    latePaymentsCount: 0,
    utilizationPercent: 30,
    inquiriesCount: 0,
    goals: "",
    timelinePreference: "BALANCED" as const,
  })

  const totalSteps = 4
  const progress = (step / totalSteps) * 100

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(step + 1)
    }
  }

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1)
    }
  }

  const handleSubmit = async () => {
    setIsLoading(true)
    setError(null)

    try {
      const supabase = createClient()

      // Sign up user
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          emailRedirectTo:
            process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || `${window.location.origin}/credit-repair/dashboard`,
          data: {
            name: formData.name,
          },
        },
      })

      if (authError) throw authError

      // If user is confirmed (no email verification required in dev)
      if (authData.user && authData.session) {
        // Submit intake data
        const response = await fetch("/api/credit-repair/intake", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(formData),
        })

        if (!response.ok) {
          const data = await response.json()
          throw new Error(data.error || "Failed to save profile")
        }

        router.push("/credit-repair/dashboard")
      } else {
        // Email verification required
        router.push("/credit-repair/auth/verify")
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-muted/30 py-12">
      <div className="container mx-auto max-w-2xl px-4">
        <div className="mb-8 text-center">
          <Shield className="mx-auto mb-4 h-12 w-12" />
          <h1 className="text-2xl font-bold">Credit Assessment</h1>
          <p className="text-muted-foreground">
            Step {step} of {totalSteps}
          </p>
        </div>

        <Progress value={progress} className="mb-8" />

        <Card>
          <CardHeader>
            <CardTitle>
              {step === 1 && "Personal Information"}
              {step === 2 && "Credit Situation"}
              {step === 3 && "Your Goals"}
              {step === 4 && "Create Your Account"}
            </CardTitle>
            <CardDescription>
              {step === 1 && "Tell us about yourself"}
              {step === 2 && "Help us understand your credit profile"}
              {step === 3 && "What do you want to achieve?"}
              {step === 4 && "Secure your account"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {step === 1 && (
              <div className="space-y-4">
                <div className="grid gap-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="John Doe"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="you@example.com"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="phone">Phone (optional)</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="(555) 123-4567"
                  />
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6">
                <div className="grid gap-2">
                  <Label>Current Credit Score Range</Label>
                  <RadioGroup
                    value={formData.scoreRange}
                    onValueChange={(value) =>
                      setFormData({ ...formData, scoreRange: value as typeof formData.scoreRange })
                    }
                  >
                    {["<550", "550-620", "620-680", "680-740", "740+"].map((range) => (
                      <div key={range} className="flex items-center space-x-2">
                        <RadioGroupItem value={range} id={range} />
                        <Label htmlFor={range}>{range}</Label>
                      </div>
                    ))}
                  </RadioGroup>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="collections">Collections</Label>
                    <Input
                      id="collections"
                      type="number"
                      min="0"
                      value={formData.collectionsCount}
                      onChange={(e) =>
                        setFormData({ ...formData, collectionsCount: Number.parseInt(e.target.value) || 0 })
                      }
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="latePayments">Late Payments</Label>
                    <Input
                      id="latePayments"
                      type="number"
                      min="0"
                      value={formData.latePaymentsCount}
                      onChange={(e) =>
                        setFormData({ ...formData, latePaymentsCount: Number.parseInt(e.target.value) || 0 })
                      }
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="utilization">Utilization %</Label>
                    <Input
                      id="utilization"
                      type="number"
                      min="0"
                      max="100"
                      value={formData.utilizationPercent}
                      onChange={(e) =>
                        setFormData({ ...formData, utilizationPercent: Number.parseInt(e.target.value) || 0 })
                      }
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="inquiries">Hard Inquiries</Label>
                    <Input
                      id="inquiries"
                      type="number"
                      min="0"
                      value={formData.inquiriesCount}
                      onChange={(e) =>
                        setFormData({ ...formData, inquiriesCount: Number.parseInt(e.target.value) || 0 })
                      }
                    />
                  </div>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6">
                <div className="grid gap-2">
                  <Label htmlFor="goals">What are your credit goals?</Label>
                  <Textarea
                    id="goals"
                    value={formData.goals}
                    onChange={(e) => setFormData({ ...formData, goals: e.target.value })}
                    placeholder="e.g., Buy a home, get approved for a car loan, qualify for better credit cards..."
                    rows={4}
                  />
                </div>
                <div className="grid gap-2">
                  <Label>Timeline Preference</Label>
                  <RadioGroup
                    value={formData.timelinePreference}
                    onValueChange={(value) =>
                      setFormData({
                        ...formData,
                        timelinePreference: value as typeof formData.timelinePreference,
                      })
                    }
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="FAST" id="fast" />
                      <Label htmlFor="fast">Fast (2-3 months) - I need results quickly</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="BALANCED" id="balanced" />
                      <Label htmlFor="balanced">Balanced (4-6 months) - Steady progress</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="LONG_TERM" id="longterm" />
                      <Label htmlFor="longterm">Long-term (6+ months) - Thorough approach</Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>
            )}

            {step === 4 && (
              <div className="space-y-4">
                <div className="grid gap-2">
                  <Label htmlFor="password">Create Password</Label>
                  <Input
                    id="password"
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    placeholder="Min 8 characters"
                  />
                </div>
                <p className="text-sm text-muted-foreground">
                  By creating an account, you agree to our Terms of Service and Privacy Policy.
                </p>
              </div>
            )}

            {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

            <div className="mt-6 flex justify-between">
              <Button variant="outline" onClick={handleBack} disabled={step === 1}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back
              </Button>
              {step < totalSteps ? (
                <Button onClick={handleNext}>
                  Next
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              ) : (
                <Button onClick={handleSubmit} disabled={isLoading}>
                  {isLoading ? "Creating Account..." : "Complete Setup"}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default function OnboardingPage() {
  return (
    <Suspense fallback={<div className="flex min-h-screen items-center justify-center">Loading...</div>}>
      <OnboardingContent />
    </Suspense>
  )
}
