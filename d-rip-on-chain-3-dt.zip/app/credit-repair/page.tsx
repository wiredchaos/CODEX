"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Shield, Zap, Users, FileText, CheckCircle2, ArrowRight, Lock, Clock, TrendingUp } from "lucide-react"
import Link from "next/link"
import { FUNNEL_COPY } from "@/data/funnel-copy"

export default function CreditRepairLandingPage() {
  const [email, setEmail] = useState("")

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-background to-muted/30 py-20 lg:py-32">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-4xl text-center">
            <Badge variant="secondary" className="mb-4">
              AI-Powered Credit Repair
            </Badge>
            <h1 className="mb-6 text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl">
              {FUNNEL_COPY.hero.headline}
            </h1>
            <p className="mb-4 text-xl text-muted-foreground">{FUNNEL_COPY.hero.subheadline}</p>
            <p className="mb-8 text-lg text-muted-foreground">{FUNNEL_COPY.hero.description}</p>
            <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
              <Link href="/credit-repair/onboarding">
                <Button size="lg" className="gap-2">
                  {FUNNEL_COPY.hero.ctaPrimary}
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
              <Link href="/credit-repair/auth/login">
                <Button variant="outline" size="lg">
                  {FUNNEL_COPY.hero.ctaSecondary}
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Signals */}
      <section className="border-y bg-muted/30 py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap items-center justify-center gap-8">
            {FUNNEL_COPY.trustSignals.map((signal, i) => (
              <div key={i} className="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                <span>{signal}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* DIY vs DFY Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="mb-12 text-center">
            <h2 className="mb-4 text-3xl font-bold">Choose Your Path</h2>
            <p className="text-muted-foreground">
              Whether you want hands-on control or expert handling, we have you covered.
            </p>
          </div>
          <div className="mx-auto grid max-w-5xl gap-8 md:grid-cols-2">
            {/* DIY Card */}
            <Link href="/credit-repair/onboarding?plan=diy" className="block">
              <Card className="relative overflow-hidden border-2 transition-all hover:border-primary/50 hover:shadow-xl cursor-pointer h-full">
                <CardHeader>
                  <div className="mb-2 flex items-center gap-2">
                    <Zap className="h-5 w-5 text-yellow-500" />
                    <Badge variant="outline">Popular</Badge>
                  </div>
                  <CardTitle className="text-2xl">{FUNNEL_COPY.diy.title}</CardTitle>
                  <CardDescription>{FUNNEL_COPY.diy.tagline}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="mb-6 space-y-3">
                    {FUNNEL_COPY.diy.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-green-500" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="mb-4">
                    <span className="text-3xl font-bold">{FUNNEL_COPY.diy.price}</span>
                  </div>
                  <Button className="w-full">{FUNNEL_COPY.diy.cta}</Button>
                </CardContent>
              </Card>
            </Link>

            {/* DFY Card */}
            <Link href="/credit-repair/onboarding?plan=dfy" className="block">
              <Card className="relative overflow-hidden border-2 border-primary transition-all hover:border-primary/80 hover:shadow-xl cursor-pointer h-full">
                <div className="absolute right-0 top-0 bg-primary px-3 py-1 text-xs font-medium text-primary-foreground">
                  Best Value
                </div>
                <CardHeader>
                  <div className="mb-2 flex items-center gap-2">
                    <Users className="h-5 w-5 text-blue-500" />
                    <Badge>Premium</Badge>
                  </div>
                  <CardTitle className="text-2xl">{FUNNEL_COPY.dfy.title}</CardTitle>
                  <CardDescription>{FUNNEL_COPY.dfy.tagline}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="mb-6 space-y-3">
                    {FUNNEL_COPY.dfy.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-green-500" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="mb-4">
                    <span className="text-3xl font-bold">{FUNNEL_COPY.dfy.price}</span>
                  </div>
                  <Button className="w-full" variant="default">
                    {FUNNEL_COPY.dfy.cta}
                  </Button>
                </CardContent>
              </Card>
            </Link>
          </div>
        </div>
      </section>

      {/* Business Bootcamp Section */}
      <section className="bg-muted/30 py-20">
        <div className="container mx-auto px-4">
          <div className="mx-auto max-w-3xl text-center">
            <TrendingUp className="mx-auto mb-4 h-12 w-12 text-primary" />
            <h2 className="mb-4 text-3xl font-bold">{FUNNEL_COPY.bootcamp.title}</h2>
            <p className="mb-4 text-xl text-muted-foreground">{FUNNEL_COPY.bootcamp.tagline}</p>
            <p className="mb-8 text-muted-foreground">{FUNNEL_COPY.bootcamp.description}</p>
            <Link href="/credit-repair/business-bootcamp">
              <Button variant="outline" size="lg" className="gap-2 bg-transparent">
                {FUNNEL_COPY.bootcamp.cta}
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="mb-12 text-center">
            <h2 className="mb-4 text-3xl font-bold">How It Works</h2>
            <p className="text-muted-foreground">Our AI-powered swarm agents work together to repair your credit</p>
          </div>
          <div className="mx-auto grid max-w-5xl gap-8 md:grid-cols-3">
            <Link href="/credit-repair/onboarding" className="block">
              <div className="text-center cursor-pointer transition-transform hover:scale-105">
                <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <FileText className="h-6 w-6 text-primary" />
                </div>
                <h3 className="mb-2 font-semibold">1. Complete Assessment</h3>
                <p className="text-sm text-muted-foreground">Tell us about your credit situation and goals</p>
              </div>
            </Link>
            <Link href="/credit-repair/dashboard" className="block">
              <div className="text-center cursor-pointer transition-transform hover:scale-105">
                <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <Zap className="h-6 w-6 text-primary" />
                </div>
                <h3 className="mb-2 font-semibold">2. AI Analysis</h3>
                <p className="text-sm text-muted-foreground">
                  Our swarm agents analyze and create your dispute strategy
                </p>
              </div>
            </Link>
            <Link href="/credit-repair/diy" className="block">
              <div className="text-center cursor-pointer transition-transform hover:scale-105">
                <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <TrendingUp className="h-6 w-6 text-primary" />
                </div>
                <h3 className="mb-2 font-semibold">3. Watch Scores Rise</h3>
                <p className="text-sm text-muted-foreground">Track deletions and watch your credit improve</p>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* Urgency Section */}
      <section className="border-y bg-destructive/5 py-12">
        <div className="container mx-auto px-4 text-center">
          <Clock className="mx-auto mb-4 h-8 w-8 text-destructive" />
          <h2 className="mb-2 text-2xl font-bold">{FUNNEL_COPY.urgency.headline}</h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">{FUNNEL_COPY.urgency.body}</p>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="mb-12 text-center">
            <h2 className="mb-4 text-3xl font-bold">Frequently Asked Questions</h2>
          </div>
          <div className="mx-auto max-w-3xl space-y-6">
            {FUNNEL_COPY.faq.map((item, i) => (
              <Card key={i}>
                <CardHeader>
                  <CardTitle className="text-lg">{item.question}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{item.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Lead Capture */}
      <section className="bg-primary py-20 text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="mb-4 text-3xl font-bold">Ready to Fix Your Credit?</h2>
          <p className="mb-8 text-primary-foreground/80">
            Join thousands who have already improved their credit scores
          </p>
          <div className="mx-auto flex max-w-md flex-col gap-4 sm:flex-row">
            <Input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-primary-foreground text-foreground"
            />
            <Link href={`/credit-repair/onboarding?email=${encodeURIComponent(email)}`}>
              <Button variant="secondary" className="w-full sm:w-auto">
                Get Started Free
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
            <div className="flex items-center gap-2">
              <Shield className="h-6 w-6" />
              <span className="font-semibold">Credit Repair Swarm Bot</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Lock className="h-4 w-4" />
              <span>Bank-Level Security</span>
              <span className="mx-2">|</span>
              <span>FCRA Compliant</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
