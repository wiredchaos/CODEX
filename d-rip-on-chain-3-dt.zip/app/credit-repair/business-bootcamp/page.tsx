import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { BootcampClient } from "./bootcamp-client"

export default async function BusinessBootcampPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/credit-repair/auth/login")
  }

  // Fetch bootcamp progress
  const { data: progress } = await supabase.from("cr_bootcamp_progress").select("*").eq("user_id", user.id)

  return <BootcampClient progress={progress || []} />
}
