"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, CheckCircle2, Clock, Lock, ArrowLeft, Play } from "lucide-react"
import Link from "next/link"
import { BOOTCAMP_MODULES, getModulesByCategory } from "@/data/bootcamp-modules"
import type { BootcampCategory } from "@/lib/credit-repair/types"

interface BootcampClientProps {
  progress: Array<{
    module_id: string
    status: string
    score: number | null
  }>
}

const categories: { id: BootcampCategory; label: string; icon: string }[] = [
  { id: "ENTITY", label: "Entity", icon: "building" },
  { id: "BANKING", label: "Banking", icon: "bank" },
  { id: "VENDORS", label: "Vendors", icon: "store" },
  { id: "BUSINESS_CREDIT", label: "Business Credit", icon: "credit-card" },
  { id: "FUNDING", label: "Funding", icon: "dollar" },
]

export function BootcampClient({ progress }: BootcampClientProps) {
  const [selectedCategory, setSelectedCategory] = useState<BootcampCategory>("ENTITY")

  const progressMap = new Map(progress.map((p) => [p.module_id, p]))
  const completedCount = progress.filter((p) => p.status === "COMPLETED").length
  const totalModules = BOOTCAMP_MODULES.length
  const overallProgress = (completedCount / totalModules) * 100

  const getModuleStatus = (moduleId: string) => {
    return progressMap.get(moduleId)?.status || "NOT_STARTED"
  }

  const categoryModules = getModulesByCategory(selectedCategory)

  return (
    <div className="min-h-screen bg-muted/30">
      <header className="border-b bg-background">
        <div className="container mx-auto flex items-center gap-4 px-4 py-4">
          <Link href="/credit-repair/dashboard">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Dashboard
            </Button>
          </Link>
          <div className="flex items-center gap-2">
            <BookOpen className="h-6 w-6" />
            <span className="font-semibold">Business Credit Bootcamp</span>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Progress Overview */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Your Progress</CardTitle>
            <CardDescription>
              {completedCount} of {totalModules} modules completed
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Progress value={overallProgress} className="mb-4" />
            <div className="flex flex-wrap gap-2">
              {categories.map((cat) => {
                const catModules = getModulesByCategory(cat.id)
                const catCompleted = catModules.filter((m) => getModuleStatus(m.id) === "COMPLETED").length
                return (
                  <Badge key={cat.id} variant={catCompleted === catModules.length ? "default" : "outline"}>
                    {cat.label}: {catCompleted}/{catModules.length}
                  </Badge>
                )
              })}
            </div>
          </CardContent>
        </Card>

        {/* Category Tabs */}
        <Tabs value={selectedCategory} onValueChange={(v) => setSelectedCategory(v as BootcampCategory)}>
          <TabsList className="mb-8 flex-wrap">
            {categories.map((cat) => (
              <TabsTrigger key={cat.id} value={cat.id}>
                {cat.label}
              </TabsTrigger>
            ))}
          </TabsList>

          {categories.map((cat) => (
            <TabsContent key={cat.id} value={cat.id}>
              <div className="grid gap-4 md:grid-cols-2">
                {getModulesByCategory(cat.id).map((module, index) => {
                  const status = getModuleStatus(module.id)
                  const isLocked =
                    index > 0 && getModuleStatus(getModulesByCategory(cat.id)[index - 1].id) !== "COMPLETED"

                  return (
                    <Card key={module.id} className={isLocked ? "opacity-60" : ""}>
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div>
                            <CardTitle className="text-lg">{module.title}</CardTitle>
                            <CardDescription>{module.description}</CardDescription>
                          </div>
                          {status === "COMPLETED" ? (
                            <CheckCircle2 className="h-5 w-5 text-green-500" />
                          ) : status === "IN_PROGRESS" ? (
                            <Clock className="h-5 w-5 text-yellow-500" />
                          ) : isLocked ? (
                            <Lock className="h-5 w-5 text-muted-foreground" />
                          ) : null}
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="mb-4 flex items-center gap-4 text-sm text-muted-foreground">
                          <span>{module.estimatedMinutes} min</span>
                          <span>{module.sections.length} sections</span>
                        </div>
                        <div className="mb-4">
                          <p className="text-sm font-medium">Learning Objectives:</p>
                          <ul className="mt-1 list-inside list-disc text-sm text-muted-foreground">
                            {module.learningObjectives.slice(0, 2).map((obj, i) => (
                              <li key={i}>{obj}</li>
                            ))}
                          </ul>
                        </div>
                        <Link href={`/credit-repair/business-bootcamp/${module.slug}`}>
                          <Button
                            className="w-full"
                            variant={status === "COMPLETED" ? "outline" : "default"}
                            disabled={isLocked}
                          >
                            {isLocked ? (
                              <>
                                <Lock className="mr-2 h-4 w-4" />
                                Complete Previous First
                              </>
                            ) : status === "COMPLETED" ? (
                              <>
                                <CheckCircle2 className="mr-2 h-4 w-4" />
                                Review Module
                              </>
                            ) : status === "IN_PROGRESS" ? (
                              <>
                                <Play className="mr-2 h-4 w-4" />
                                Continue Learning
                              </>
                            ) : (
                              <>
                                <Play className="mr-2 h-4 w-4" />
                                Start Module
                              </>
                            )}
                          </Button>
                        </Link>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </main>
    </div>
  )
}
