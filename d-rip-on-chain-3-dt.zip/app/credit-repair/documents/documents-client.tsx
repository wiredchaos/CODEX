"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FolderOpen, FileText, Download, Upload, ArrowLeft, Eye } from "lucide-react"
import Link from "next/link"

interface DocumentsClientProps {
  documents: Array<{
    id: string
    type: string
    title: string
    description: string | null
    file_url: string
    created_at: string
  }>
  letters: Array<{
    id: string
    title: string
    letter_type: string
    status: string
    created_at: string
  }>
}

export function DocumentsClient({ documents, letters }: DocumentsClientProps) {
  const disputeLetters = letters
  const responseDocuments = documents.filter((d) => d.type === "RESPONSE")
  const idDocuments = documents.filter((d) => d.type === "ID_PROOF" || d.type === "UTILITY_BILL")
  const businessDocuments = documents.filter((d) => d.type === "BUSINESS_DOC")
  const otherDocuments = documents.filter((d) => d.type === "OTHER")

  return (
    <div className="min-h-screen bg-muted/30">
      <header className="border-b bg-background">
        <div className="container mx-auto flex items-center justify-between px-4 py-4">
          <div className="flex items-center gap-4">
            <Link href="/credit-repair/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Dashboard
              </Button>
            </Link>
            <div className="flex items-center gap-2">
              <FolderOpen className="h-6 w-6" />
              <span className="font-semibold">Document Vault</span>
            </div>
          </div>
          <Button>
            <Upload className="mr-2 h-4 w-4" />
            Upload Document
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <Tabs defaultValue="letters">
          <TabsList className="mb-8">
            <TabsTrigger value="letters">Dispute Letters ({disputeLetters.length})</TabsTrigger>
            <TabsTrigger value="responses">Bureau Responses ({responseDocuments.length})</TabsTrigger>
            <TabsTrigger value="identity">ID Documents ({idDocuments.length})</TabsTrigger>
            <TabsTrigger value="business">Business Docs ({businessDocuments.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="letters">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {disputeLetters.length === 0 ? (
                <Card className="col-span-full">
                  <CardContent className="py-12 text-center">
                    <FileText className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
                    <p className="text-muted-foreground">No dispute letters yet</p>
                    <Link href="/credit-repair/diy">
                      <Button variant="outline" className="mt-4 bg-transparent">
                        Generate Letters
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ) : (
                disputeLetters.map((letter) => (
                  <Card key={letter.id}>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <FileText className="h-8 w-8 text-primary" />
                        <Badge variant="outline">{letter.status}</Badge>
                      </div>
                      <CardTitle className="text-base">{letter.title}</CardTitle>
                      <CardDescription>
                        {letter.letter_type} - {new Date(letter.created_at).toLocaleDateString()}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                          <Eye className="mr-2 h-4 w-4" />
                          View
                        </Button>
                        <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                          <Download className="mr-2 h-4 w-4" />
                          Download
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="responses">
            <Card>
              <CardContent className="py-12 text-center">
                <FileText className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
                <p className="text-muted-foreground">No bureau responses uploaded yet</p>
                <Button variant="outline" className="mt-4 bg-transparent">
                  <Upload className="mr-2 h-4 w-4" />
                  Upload Response
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="identity">
            <Card>
              <CardContent className="py-12 text-center">
                <FileText className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
                <p className="text-muted-foreground">Upload ID documents for dispute verification</p>
                <Button variant="outline" className="mt-4 bg-transparent">
                  <Upload className="mr-2 h-4 w-4" />
                  Upload ID Document
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="business">
            <Card>
              <CardContent className="py-12 text-center">
                <FileText className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
                <p className="text-muted-foreground">Store your business formation documents here</p>
                <Button variant="outline" className="mt-4 bg-transparent">
                  <Upload className="mr-2 h-4 w-4" />
                  Upload Business Document
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
