import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { DocumentsClient } from "./documents-client"

export default async function DocumentsPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/credit-repair/auth/login")
  }

  // Fetch all documents
  const { data: documents } = await supabase
    .from("cr_documents")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })

  // Fetch dispute letters as documents too
  const { data: letters } = await supabase
    .from("cr_dispute_letters")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })

  return <DocumentsClient documents={documents || []} letters={letters || []} />
}
