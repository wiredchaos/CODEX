"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Shield, FileText, Download, Plus, CheckCircle2, Clock, Send, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { DISPUTE_LETTER_TEMPLATES } from "@/data/dispute-letter-templates"
import type { LetterType } from "@/lib/credit-repair/types"

interface DIYClientProps {
  creditProfile: {
    id: string
    score_range: string
    profile_tier: string
  } | null
  disputeItems: Array<{
    id: string
    type: string
    creditor_name: string
    amount: number
    status: string
  }>
  letters: Array<{
    id: string
    title: string
    letter_type: string
    status: string
    body: string
    created_at: string
  }>
}

export function DIYClient({ creditProfile, disputeItems, letters }: DIYClientProps) {
  const [selectedItems, setSelectedItems] = useState<string[]>([])
  const [selectedTemplates, setSelectedTemplates] = useState<LetterType[]>([])
  const [isGenerating, setIsGenerating] = useState(false)
  const [activeTab, setActiveTab] = useState("generate")

  const templates = Object.values(DISPUTE_LETTER_TEMPLATES)

  const handleGenerate = async () => {
    if (!creditProfile || selectedItems.length === 0 || selectedTemplates.length === 0) {
      return
    }

    setIsGenerating(true)
    try {
      const response = await fetch("/api/credit-repair/disputes/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          creditProfileId: creditProfile.id,
          disputeItemIds: selectedItems,
          templateIds: selectedTemplates,
        }),
      })

      if (response.ok) {
        setActiveTab("letters")
        setSelectedItems([])
        setSelectedTemplates([])
      }
    } catch (error) {
      console.error("Failed to generate letters:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <div className="min-h-screen bg-muted/30">
      <header className="border-b bg-background">
        <div className="container mx-auto flex items-center gap-4 px-4 py-4">
          <Link href="/credit-repair/dashboard">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Dashboard
            </Button>
          </Link>
          <div className="flex items-center gap-2">
            <Shield className="h-6 w-6" />
            <span className="font-semibold">DIY Dispute Center</span>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-8">
            <TabsTrigger value="generate">Generate Letters</TabsTrigger>
            <TabsTrigger value="letters">My Letters ({letters.length})</TabsTrigger>
            <TabsTrigger value="checklist">Checklist</TabsTrigger>
          </TabsList>

          <TabsContent value="generate">
            <div className="grid gap-6 lg:grid-cols-2">
              {/* Dispute Items */}
              <Card>
                <CardHeader>
                  <CardTitle>Select Items to Dispute</CardTitle>
                  <CardDescription>Choose the negative items you want to dispute</CardDescription>
                </CardHeader>
                <CardContent>
                  {disputeItems.length === 0 ? (
                    <div className="py-8 text-center">
                      <FileText className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
                      <p className="text-muted-foreground">No dispute items added yet</p>
                      <Button variant="outline" className="mt-4 bg-transparent">
                        <Plus className="mr-2 h-4 w-4" />
                        Add Dispute Item
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {disputeItems.map((item) => (
                        <div key={item.id} className="flex items-start gap-3 rounded-lg border p-4">
                          <Checkbox
                            checked={selectedItems.includes(item.id)}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                setSelectedItems([...selectedItems, item.id])
                              } else {
                                setSelectedItems(selectedItems.filter((id) => id !== item.id))
                              }
                            }}
                          />
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <span className="font-medium">{item.creditor_name}</span>
                              <Badge variant="outline">{item.type}</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              Amount: ${item.amount?.toLocaleString() || "Unknown"}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Letter Templates */}
              <Card>
                <CardHeader>
                  <CardTitle>Select Letter Types</CardTitle>
                  <CardDescription>Choose which dispute letters to generate</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {templates.slice(0, 6).map((template) => (
                      <div key={template.id} className="flex items-start gap-3 rounded-lg border p-4">
                        <Checkbox
                          checked={selectedTemplates.includes(template.id)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedTemplates([...selectedTemplates, template.id])
                            } else {
                              setSelectedTemplates(selectedTemplates.filter((id) => id !== template.id))
                            }
                          }}
                        />
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <span className="font-medium">{template.label}</span>
                            <Badge variant="secondary">{template.target}</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">{template.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="mt-6 flex justify-end">
              <Button
                size="lg"
                onClick={handleGenerate}
                disabled={isGenerating || selectedItems.length === 0 || selectedTemplates.length === 0}
              >
                {isGenerating ? "Generating..." : "Generate Dispute Letters"}
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="letters">
            <div className="space-y-4">
              {letters.length === 0 ? (
                <Card>
                  <CardContent className="py-12 text-center">
                    <FileText className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
                    <p className="text-muted-foreground">
                      No letters generated yet. Start by selecting items to dispute.
                    </p>
                  </CardContent>
                </Card>
              ) : (
                letters.map((letter) => (
                  <Card key={letter.id}>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-lg">{letter.title}</CardTitle>
                          <CardDescription>
                            {letter.letter_type} - Created {new Date(letter.created_at).toLocaleDateString()}
                          </CardDescription>
                        </div>
                        <Badge
                          variant={
                            letter.status === "SENT"
                              ? "default"
                              : letter.status === "RESPONSE_RECEIVED"
                                ? "outline"
                                : "secondary"
                          }
                        >
                          {letter.status === "DRAFT" && <Clock className="mr-1 h-3 w-3" />}
                          {letter.status === "SENT" && <Send className="mr-1 h-3 w-3" />}
                          {letter.status === "RESPONSE_RECEIVED" && <CheckCircle2 className="mr-1 h-3 w-3" />}
                          {letter.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <Download className="mr-2 h-4 w-4" />
                          Download PDF
                        </Button>
                        {letter.status === "DRAFT" && (
                          <Button size="sm">
                            <Send className="mr-2 h-4 w-4" />
                            Mark as Sent
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="checklist">
            <Card>
              <CardHeader>
                <CardTitle>DIY Dispute Checklist</CardTitle>
                <CardDescription>Follow these steps for effective credit repair</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    "Pull credit reports from all 3 bureaus",
                    "Identify and document all negative items",
                    "Generate initial dispute letters (609)",
                    "Send letters via certified mail",
                    "Wait 30 days for bureau response",
                    "Review responses and escalate if needed",
                    "Send follow-up letters (611, 623)",
                    "Track deletions and score changes",
                  ].map((step, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/10 text-sm font-medium">
                        {i + 1}
                      </div>
                      <span>{step}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
