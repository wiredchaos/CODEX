import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { DIYClient } from "./diy-client"

export default async function DIYPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/credit-repair/auth/login")
  }

  // Fetch credit profile
  const { data: creditProfile } = await supabase
    .from("cr_credit_profiles")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })
    .limit(1)
    .single()

  // Fetch dispute items
  const { data: disputeItems } = await supabase
    .from("cr_dispute_items")
    .select("*")
    .eq("credit_profile_id", creditProfile?.id)

  // Fetch existing letters
  const { data: letters } = await supabase
    .from("cr_dispute_letters")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })

  return <DIYClient creditProfile={creditProfile} disputeItems={disputeItems || []} letters={letters || []} />
}
