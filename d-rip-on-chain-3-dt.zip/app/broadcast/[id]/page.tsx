import { notFound } from "next/navigation"
import Link from "next/link"
import { SAMPLE_EPISODES, getCategoryColor, getStatusColor, BROADCAST_AVATARS } from "@/config/broadcast"
import { cn } from "@/lib/utils"
import { ArrowLeft, Radio, Clock, Eye, EyeOff, Sparkles, AlertTriangle } from "lucide-react"

export function generateStaticParams() {
  return SAMPLE_EPISODES.map((episode) => ({ id: episode.id }))
}

export default async function BroadcastEpisodePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const episode = SAMPLE_EPISODES.find((e) => e.id === id)

  if (!episode) notFound()

  const avatarInfo = BROADCAST_AVATARS[episode.primaryAvatar]

  return (
    <div className="space-y-8">
      <Link
        href="/broadcast"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Broadcasts
      </Link>

      {/* Header */}
      <header className="relative p-6 rounded-xl border border-border bg-card/50">
        <div className="absolute inset-0 bg-gradient-to-br from-red-500/5 via-transparent to-primary/5 rounded-xl" />
        <div className="relative">
          <div className="flex flex-wrap items-center gap-3 mb-4">
            <Radio
              className={cn("h-5 w-5", episode.status === "Live" ? "text-red-400 animate-pulse" : "text-primary")}
            />
            <span className={cn("px-2 py-1 text-xs font-bold rounded", getStatusColor(episode.status))}>
              {episode.status}
            </span>
            <span className={cn("px-2 py-1 text-xs font-medium rounded border", getCategoryColor(episode.category))}>
              {episode.category}
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">{episode.title}</h1>

          <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              <span>{new Date(episode.datetime).toLocaleString()}</span>
            </div>
            <div className="flex items-center gap-1">
              <Sparkles className="h-4 w-4 text-amber-400" />
              <span>{avatarInfo.name}</span>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 mt-4">
            {episode.realms.map((realm) => (
              <span
                key={realm}
                className="px-3 py-1 text-xs font-medium rounded bg-secondary text-secondary-foreground"
              >
                {realm}
              </span>
            ))}
          </div>
        </div>
      </header>

      {/* Script */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h2 className="text-lg font-bold text-foreground">Broadcast Script</h2>

          <div className="p-4 rounded-lg border border-border bg-card/30">
            <h3 className="text-sm font-semibold text-primary mb-2">OPEN</h3>
            <p className="text-muted-foreground">{episode.script.open}</p>
          </div>

          <div className="p-4 rounded-lg border border-border bg-card/30">
            <h3 className="text-sm font-semibold text-amber-400 mb-2">LORE FRAME</h3>
            <p className="text-muted-foreground">{episode.script.loreFrame}</p>
          </div>

          <div className="p-4 rounded-lg border border-border bg-card/30">
            <h3 className="text-sm font-semibold text-fuchsia-400 mb-2">QUEST HOOK</h3>
            <p className="text-muted-foreground">{episode.script.questHook}</p>
          </div>

          <div className="p-4 rounded-lg border border-border bg-card/30">
            <h3 className="text-sm font-semibold text-emerald-400 mb-2">CALL TO ACTION</h3>
            <p className="text-muted-foreground">{episode.script.cta}</p>
          </div>
        </div>

        {/* Clues */}
        <div className="space-y-4">
          <h2 className="text-lg font-bold text-foreground flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-400" />
            Hidden Clues
          </h2>

          {episode.clues.map((clue, index) => (
            <div
              key={index}
              className={cn(
                "p-4 rounded-lg border",
                clue.type === "visible"
                  ? "border-cyan-500/30 bg-cyan-500/5"
                  : clue.type === "semi-hidden"
                    ? "border-fuchsia-500/30 bg-fuchsia-500/5"
                    : "border-amber-500/30 bg-amber-500/5",
              )}
            >
              <div className="flex items-center gap-2 mb-2">
                {clue.type === "visible" ? (
                  <Eye className="h-4 w-4 text-cyan-400" />
                ) : (
                  <EyeOff className="h-4 w-4 text-fuchsia-400" />
                )}
                <span
                  className={cn(
                    "text-xs font-bold uppercase",
                    clue.type === "visible"
                      ? "text-cyan-400"
                      : clue.type === "semi-hidden"
                        ? "text-fuchsia-400"
                        : "text-amber-400",
                  )}
                >
                  {clue.type.replace("-", " ")} clue
                </span>
                {clue.artifactType && (
                  <span className="ml-auto text-xs text-muted-foreground">Artifact: {clue.artifactType}</span>
                )}
              </div>
              <p className="text-sm text-foreground mb-2">{clue.description}</p>
              <p className="text-xs text-muted-foreground italic">Hint: "{clue.hint}"</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}
