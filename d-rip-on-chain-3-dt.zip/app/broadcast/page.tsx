import { SAMPLE_EPISODES, BROADCAST_AVATARS } from "@/config/broadcast"
import { EpisodeCard } from "@/components/broadcast/episode-card"
import { CinematicHeader } from "@/components/akashic/cinematic-header"
import { DossierSection } from "@/components/akashic/dossier-section"
import { FilmCard } from "@/components/akashic/film-card"
import { Brain, Sparkles } from "lucide-react"

export default function BroadcastPage() {
  const liveEpisodes = SAMPLE_EPISODES.filter((e) => e.status === "Live")
  const upcomingEpisodes = SAMPLE_EPISODES.filter((e) => e.status === "Upcoming")
  const archivedEpisodes = SAMPLE_EPISODES.filter((e) => e.status === "Archived")

  return (
    <div className="min-h-screen bg-black -mx-4 sm:-mx-6 lg:-mx-8 -my-8 px-4 sm:px-6 lg:px-8 scanlines film-grain circuit-bg">
      {/* Cinematic Hero */}
      <CinematicHeader
        title="BARBED WIRED BROADCAST"
        subtitle="SIGNAL FEED ACTIVE"
        chapter="TRANSMISSION HUB"
        tagline="Automated by the SWARM Lore Bot. Every broadcast contains clues, artifacts, and quest hooks."
      />

      <div className="max-w-6xl mx-auto pb-16">
        {/* Live Ticker */}
        <div className="mb-12 p-4 rounded-lg border border-[#FF3131]/30 bg-[#FF3131]/5">
          <div className="flex items-center gap-3">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#FF3131] opacity-75" />
              <span className="relative inline-flex rounded-full h-3 w-3 bg-[#FF3131]" />
            </span>
            <span className="text-xs font-mono text-[#FF3131] tracking-widest">
              SIGNAL ACTIVE • MONITORING FREQUENCY 589.33 MHz
            </span>
          </div>
        </div>

        {/* Broadcast Avatars */}
        <DossierSection title="BROADCAST AVATARS" classification="NEURO VOICES">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {Object.entries(BROADCAST_AVATARS).map(([key, avatar]) => (
              <FilmCard
                key={key}
                title={avatar.name}
                chapter={key === "BrainDesk" ? "PRIMARY HOST" : "CHAOS ANALYST"}
                accentColor={key === "BrainDesk" ? "cyan" : "red"}
              >
                <div className="flex items-center gap-3">
                  {key === "BrainDesk" ? (
                    <Brain className="h-8 w-8 text-[#00FFFF]" />
                  ) : (
                    <Sparkles className="h-8 w-8 text-[#FF3131]" />
                  )}
                  <p className="text-sm text-white/60">{avatar.description}</p>
                </div>
              </FilmCard>
            ))}
          </div>
        </DossierSection>

        {/* Live Episodes */}
        {liveEpisodes.length > 0 && (
          <DossierSection title="LIVE TRANSMISSION" classification="NOW BROADCASTING">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {liveEpisodes.map((episode) => (
                <EpisodeCard key={episode.id} episode={episode} />
              ))}
            </div>
          </DossierSection>
        )}

        {/* Upcoming */}
        {upcomingEpisodes.length > 0 && (
          <DossierSection title="UPCOMING SIGNALS" classification="SCHEDULED">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {upcomingEpisodes.map((episode) => (
                <EpisodeCard key={episode.id} episode={episode} />
              ))}
            </div>
          </DossierSection>
        )}

        {/* Archive */}
        <DossierSection title="SIGNAL ARCHIVE" classification="HISTORICAL">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {archivedEpisodes.map((episode) => (
              <EpisodeCard key={episode.id} episode={episode} />
            ))}
          </div>
        </DossierSection>
      </div>
    </div>
  )
}
