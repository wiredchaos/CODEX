"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Play,
  Pause,
  Square,
  Radio,
  Mic,
  Zap,
  Users,
  Activity,
  Settings,
  Sparkles,
  Shield,
  Monitor,
  Signal,
} from "lucide-react"
import { CinematicHeader } from "@/components/akashic/cinematic-header"
import {
  type BroadcastSession,
  type VoiceProfileId,
  type TimelineFxEvent,
  type Resolution,
  type LatencyTier,
  getAllVoiceProfiles,
  getAllTimelineFx,
  getAllViewerTriggers,
  RESOLUTION_PRESETS,
  LATENCY_CONFIGS,
} from "@/lib/broadcast"

// Avatar options
const AVATARS = [
  { id: "neuro-meta", name: "NEURO META", description: "Red Fang Precision" },
  { id: "neuro-kiba", name: "NEURO KIBA", description: "Blade-Quiet Power" },
  { id: "dj-red-fang", name: "DJ RED FANG", description: "Timeline Constant" },
  { id: "shadowlux", name: "SHADOWLUX", description: "Soft Encryption" },
  { id: "grymm", name: "GRYMM", description: "Hardline Discipline" },
]

export default function LiveBroadcastPage() {
  const [session, setSession] = useState<BroadcastSession | null>(null)
  const [selectedAvatar, setSelectedAvatar] = useState("neuro-meta")
  const [isLoading, setIsLoading] = useState(false)
  const [activeTab, setActiveTab] = useState("animator")

  // Voice settings
  const [voiceProfile, setVoiceProfile] = useState<VoiceProfileId>("neutral-broadcast")
  const [noiseSuppression, setNoiseSuppression] = useState(true)
  const [clarityCompression, setClarityCompression] = useState(true)

  // Quality settings
  const [resolution, setResolution] = useState<Resolution>("1080p60")
  const [latencyTier, setLatencyTier] = useState<LatencyTier>("standard")
  const [adaptiveBitrate, setAdaptiveBitrate] = useState(true)

  // Auto-animator settings
  const [microGestures, setMicroGestures] = useState(true)
  const [breathSimulation, setBreathSimulation] = useState(true)
  const [eyeTracking, setEyeTracking] = useState(true)
  const [personaTicks, setPersonaTicks] = useState(true)

  // Timeline FX
  const [timelineFxEnabled, setTimelineFxEnabled] = useState(true)
  const [fxIntensity, setFxIntensity] = useState([1.0])

  // Viewer control
  const [viewerControlEnabled, setViewerControlEnabled] = useState(true)
  const [rateLimitPerMinute, setRateLimitPerMinute] = useState([30])

  const voiceProfiles = getAllVoiceProfiles()
  const timelineFxList = getAllTimelineFx()
  const viewerTriggers = getAllViewerTriggers()

  const createSession = async () => {
    setIsLoading(true)
    try {
      const res = await fetch("/api/broadcast/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "create",
          userId: "demo-user",
          avatarId: selectedAvatar,
          config: {
            autoAnimator: {
              microGestures,
              breathSimulation,
              eyeTracking,
              autonomousPersonaTicks: personaTicks,
            },
            voiceMask: {
              profileId: voiceProfile,
              noiseSuppression,
              clarityCompression,
            },
            timelineFx: {
              enabled: timelineFxEnabled,
              intensityMultiplier: fxIntensity[0],
            },
            viewerControl: {
              enabled: viewerControlEnabled,
              rateLimit: rateLimitPerMinute[0],
            },
            quality: {
              resolution,
              latencyTier,
              adaptiveBitrate,
            },
          },
        }),
      })
      const data = await res.json()
      if (data.success) {
        setSession(data.session)
      }
    } catch (error) {
      console.error("Failed to create session:", error)
    }
    setIsLoading(false)
  }

  const controlSession = async (action: string, payload?: Record<string, unknown>) => {
    if (!session) return
    setIsLoading(true)
    try {
      const res = await fetch("/api/broadcast/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action,
          sessionId: session.id,
          ...payload,
        }),
      })
      const data = await res.json()
      if (data.success) {
        setSession(data.session)
      }
    } catch (error) {
      console.error(`Failed to ${action} session:`, error)
    }
    setIsLoading(false)
  }

  const triggerFx = (event: TimelineFxEvent) => {
    controlSession("trigger_fx", { event })
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "live":
        return "bg-red-500"
      case "paused":
        return "bg-yellow-500"
      case "preparing":
        return "bg-blue-500"
      default:
        return "bg-zinc-500"
    }
  }

  return (
    <div className="min-h-screen bg-black -mx-4 sm:-mx-6 lg:-mx-8 -my-8 px-4 sm:px-6 lg:px-8 scanlines">
      <CinematicHeader
        title="AVATAR LIVE MODE"
        subtitle="v33 BROADCAST CONTROL"
        chapter="WIRED CHAOS META"
        tagline="Neural Auto-Animator • Voiceprint Masquerade • Timeline-Synced FX"
      />

      <div className="max-w-7xl mx-auto pb-16">
        {/* Status Bar */}
        <div className="mb-8 p-4 rounded-lg border border-white/10 bg-black/50 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span
                className={`h-3 w-3 rounded-full ${session?.status === "live" ? "animate-pulse" : ""} ${getStatusColor(session?.status || "idle")}`}
              />
              <span className="text-sm font-mono text-white/70 uppercase">{session?.status || "No Session"}</span>
            </div>
            {session && (
              <>
                <Badge variant="outline" className="border-cyan-500/50 text-cyan-400">
                  <Users className="h-3 w-3 mr-1" />
                  {session.viewerCount} viewers
                </Badge>
                <Badge variant="outline" className="border-purple-500/50 text-purple-400">
                  <Zap className="h-3 w-3 mr-1" />
                  {session.totalInteractions} interactions
                </Badge>
              </>
            )}
          </div>

          {/* Session Controls */}
          <div className="flex items-center gap-2">
            {!session ? (
              <Button onClick={createSession} disabled={isLoading} className="bg-cyan-600 hover:bg-cyan-700">
                <Radio className="h-4 w-4 mr-2" />
                Create Session
              </Button>
            ) : session.status === "idle" || session.status === "preparing" ? (
              <Button
                onClick={() => controlSession("start")}
                disabled={isLoading}
                className="bg-green-600 hover:bg-green-700"
              >
                <Play className="h-4 w-4 mr-2" />
                Go Live
              </Button>
            ) : session.status === "live" ? (
              <>
                <Button
                  onClick={() => controlSession("pause")}
                  disabled={isLoading}
                  variant="outline"
                  className="border-yellow-500/50 text-yellow-400"
                >
                  <Pause className="h-4 w-4 mr-2" />
                  Pause
                </Button>
                <Button
                  onClick={() => controlSession("end")}
                  disabled={isLoading}
                  variant="outline"
                  className="border-red-500/50 text-red-400"
                >
                  <Square className="h-4 w-4 mr-2" />
                  End
                </Button>
              </>
            ) : session.status === "paused" ? (
              <>
                <Button
                  onClick={() => controlSession("resume")}
                  disabled={isLoading}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <Play className="h-4 w-4 mr-2" />
                  Resume
                </Button>
                <Button
                  onClick={() => controlSession("end")}
                  disabled={isLoading}
                  variant="outline"
                  className="border-red-500/50 text-red-400"
                >
                  <Square className="h-4 w-4 mr-2" />
                  End
                </Button>
              </>
            ) : null}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Preview Area */}
          <div className="lg:col-span-2 space-y-6">
            {/* Avatar Preview */}
            <Card className="bg-black/50 border-white/10">
              <CardHeader className="border-b border-white/10">
                <CardTitle className="text-white flex items-center gap-2">
                  <Monitor className="h-5 w-5 text-cyan-400" />
                  Avatar Preview
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="aspect-video bg-gradient-to-br from-zinc-900 to-black flex items-center justify-center relative overflow-hidden">
                  {/* Simulated avatar preview */}
                  <div className="absolute inset-0 bg-[url('/cyber-avatar-studio.jpg')] bg-cover bg-center opacity-30" />
                  <div className="relative z-10 text-center">
                    <div className="w-32 h-32 rounded-full bg-gradient-to-br from-cyan-500/20 to-red-500/20 border-2 border-cyan-500/50 mx-auto mb-4 flex items-center justify-center">
                      <Signal className="h-12 w-12 text-cyan-400" />
                    </div>
                    <p className="text-lg font-mono text-white">
                      {AVATARS.find((a) => a.id === selectedAvatar)?.name || "Select Avatar"}
                    </p>
                    <p className="text-sm text-white/50">{AVATARS.find((a) => a.id === selectedAvatar)?.description}</p>
                  </div>

                  {/* Live indicator */}
                  {session?.status === "live" && (
                    <div className="absolute top-4 left-4 flex items-center gap-2 bg-red-600 px-3 py-1 rounded">
                      <span className="h-2 w-2 rounded-full bg-white animate-pulse" />
                      <span className="text-xs font-bold text-white">LIVE</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Timeline FX Triggers */}
            <Card className="bg-black/50 border-white/10">
              <CardHeader className="border-b border-white/10">
                <CardTitle className="text-white flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-purple-400" />
                  Timeline FX Triggers
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {timelineFxList.map((fx) => (
                    <Button
                      key={fx.id}
                      variant="outline"
                      size="sm"
                      onClick={() => triggerFx(fx.event)}
                      disabled={!session || session.status !== "live"}
                      className="border-white/20 hover:border-purple-500/50 hover:bg-purple-500/10 text-white/70 hover:text-purple-300 text-xs h-auto py-2"
                    >
                      <Zap className="h-3 w-3 mr-1" />
                      {fx.event.replace(/_/g, " ")}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Control Panel */}
          <div className="space-y-6">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid grid-cols-4 bg-black/50 border border-white/10">
                <TabsTrigger value="animator" className="text-xs data-[state=active]:bg-cyan-600">
                  <Activity className="h-3 w-3" />
                </TabsTrigger>
                <TabsTrigger value="voice" className="text-xs data-[state=active]:bg-cyan-600">
                  <Mic className="h-3 w-3" />
                </TabsTrigger>
                <TabsTrigger value="viewers" className="text-xs data-[state=active]:bg-cyan-600">
                  <Users className="h-3 w-3" />
                </TabsTrigger>
                <TabsTrigger value="quality" className="text-xs data-[state=active]:bg-cyan-600">
                  <Settings className="h-3 w-3" />
                </TabsTrigger>
              </TabsList>

              {/* Phase 1: Auto-Animator */}
              <TabsContent value="animator">
                <Card className="bg-black/50 border-white/10">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-white text-sm">Neural Auto-Animator</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label className="text-white/70 text-xs">Avatar</Label>
                      <Select value={selectedAvatar} onValueChange={setSelectedAvatar} disabled={!!session}>
                        <SelectTrigger className="bg-black/50 border-white/20 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {AVATARS.map((avatar) => (
                            <SelectItem key={avatar.id} value={avatar.id}>
                              {avatar.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <Label className="text-white/70 text-xs">Micro Gestures</Label>
                        <Switch checked={microGestures} onCheckedChange={setMicroGestures} />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label className="text-white/70 text-xs">Breath Simulation</Label>
                        <Switch checked={breathSimulation} onCheckedChange={setBreathSimulation} />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label className="text-white/70 text-xs">Eye Tracking</Label>
                        <Switch checked={eyeTracking} onCheckedChange={setEyeTracking} />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label className="text-white/70 text-xs">Persona Ticks</Label>
                        <Switch checked={personaTicks} onCheckedChange={setPersonaTicks} />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Phase 2: Voice Mask */}
              <TabsContent value="voice">
                <Card className="bg-black/50 border-white/10">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-white text-sm">Voiceprint Masquerade</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label className="text-white/70 text-xs">Voice Profile</Label>
                      <Select value={voiceProfile} onValueChange={(v) => setVoiceProfile(v as VoiceProfileId)}>
                        <SelectTrigger className="bg-black/50 border-white/20 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {voiceProfiles.map((profile) => (
                            <SelectItem key={profile.id} value={profile.id}>
                              {profile.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <Label className="text-white/70 text-xs">Noise Suppression</Label>
                        <Switch checked={noiseSuppression} onCheckedChange={setNoiseSuppression} />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label className="text-white/70 text-xs">Clarity Compression</Label>
                        <Switch checked={clarityCompression} onCheckedChange={setClarityCompression} />
                      </div>
                    </div>

                    <div className="p-3 rounded bg-white/5 border border-white/10">
                      <p className="text-xs text-white/50 mb-2">Profile Characteristics:</p>
                      <div className="flex flex-wrap gap-1">
                        {voiceProfiles
                          .find((p) => p.id === voiceProfile)
                          ?.characteristics.map((c) => (
                            <Badge key={c} variant="outline" className="text-xs border-cyan-500/30 text-cyan-400">
                              {c}
                            </Badge>
                          ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Phase 4: Viewer Control */}
              <TabsContent value="viewers">
                <Card className="bg-black/50 border-white/10">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-white text-sm">Viewer Interaction</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label className="text-white/70 text-xs">Enable Viewer Triggers</Label>
                      <Switch checked={viewerControlEnabled} onCheckedChange={setViewerControlEnabled} />
                    </div>

                    <div className="space-y-2">
                      <Label className="text-white/70 text-xs">Rate Limit: {rateLimitPerMinute[0]}/min</Label>
                      <Slider
                        value={rateLimitPerMinute}
                        onValueChange={setRateLimitPerMinute}
                        min={5}
                        max={60}
                        step={5}
                        className="py-2"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label className="text-white/70 text-xs">Available Triggers</Label>
                      <div className="grid grid-cols-2 gap-2">
                        {viewerTriggers.slice(0, 6).map((trigger) => (
                          <div
                            key={trigger.action}
                            className="p-2 rounded bg-white/5 border border-white/10 text-center"
                          >
                            <p className="text-xs text-white/70">{trigger.action.replace(/_/g, " ")}</p>
                            {trigger.subscriberOnly && (
                              <Badge className="text-[10px] bg-purple-500/20 text-purple-400 mt-1">Sub Only</Badge>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Phase 6: Quality */}
              <TabsContent value="quality">
                <Card className="bg-black/50 border-white/10">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-white text-sm">Broadcast Quality</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label className="text-white/70 text-xs">Resolution</Label>
                      <Select
                        value={resolution}
                        onValueChange={(v) => setResolution(v as Resolution)}
                        disabled={!!session}
                      >
                        <SelectTrigger className="bg-black/50 border-white/20 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {RESOLUTION_PRESETS.map((preset) => (
                            <SelectItem key={preset.id} value={preset.id}>
                              {preset.id} ({preset.width}x{preset.height})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-white/70 text-xs">Latency Mode</Label>
                      <Select
                        value={latencyTier}
                        onValueChange={(v) => setLatencyTier(v as LatencyTier)}
                        disabled={!!session}
                      >
                        <SelectTrigger className="bg-black/50 border-white/20 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {LATENCY_CONFIGS.map((config) => (
                            <SelectItem key={config.tier} value={config.tier}>
                              {config.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="flex items-center justify-between">
                      <Label className="text-white/70 text-xs">Adaptive Bitrate</Label>
                      <Switch checked={adaptiveBitrate} onCheckedChange={setAdaptiveBitrate} />
                    </div>

                    <div className="space-y-2">
                      <Label className="text-white/70 text-xs">FX Intensity: {fxIntensity[0].toFixed(1)}x</Label>
                      <Slider
                        value={fxIntensity}
                        onValueChange={setFxIntensity}
                        min={0.5}
                        max={2.0}
                        step={0.1}
                        className="py-2"
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            {/* Cross-System Status */}
            <Card className="bg-black/50 border-white/10">
              <CardHeader className="pb-3">
                <CardTitle className="text-white text-sm flex items-center gap-2">
                  <Shield className="h-4 w-4 text-green-400" />
                  Cross-System Links
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {[
                    { name: "Creator Codex", status: "active" },
                    { name: "Akira Codex", status: "active" },
                    { name: "NPC Training", status: "active" },
                    { name: "OTT 789", status: "active" },
                    { name: "33.3FM", status: "active" },
                    { name: "FEN Vault", status: "active" },
                  ].map((system) => (
                    <div key={system.name} className="flex items-center justify-between">
                      <span className="text-xs text-white/70">{system.name}</span>
                      <span className="h-2 w-2 rounded-full bg-green-500" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
