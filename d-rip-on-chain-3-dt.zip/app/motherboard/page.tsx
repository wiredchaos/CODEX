"use client"

import { useState } from "react"
import { UNIVERSITY_NODES, MOTHERBOARD_SUBSYSTEMS } from "@/config/university"
import { CollegeCrest } from "@/components/university/college-crest"
import { MotherboardNode } from "@/components/university/motherboard-node"
import { CinematicHeader } from "@/components/akashic/cinematic-header"
import { DossierSection } from "@/components/akashic/dossier-section"
import Link from "next/link"
import { ArrowRight, Cpu, Database, Radio, Zap } from "lucide-react"

export default function MotherboardPage() {
  const [selectedNode, setSelectedNode] = useState<string | null>(null)
  const activeNode = UNIVERSITY_NODES.find((n) => n.nodeId === selectedNode)

  return (
    <div className="min-h-screen bg-black -mx-4 sm:-mx-6 lg:-mx-8 -my-8 px-4 sm:px-6 lg:px-8 scanlines film-grain circuit-bg">
      <CinematicHeader
        title="AKASHIC MOTHERBOARD"
        subtitle="SYSTEM ARCHITECTURE"
        chapter="CENTRAL COMMAND"
        tagline="The living data circuit. Every college is a node. Every node is a gateway."
      />

      <div className="max-w-7xl mx-auto pb-16">
        {/* Network Status Bar */}
        <div className="flex items-center justify-center gap-8 mb-12 py-4 border-y border-[#FF3131]/20">
          <div className="flex items-center gap-2 text-[#00FFFF]">
            <Cpu className="w-4 h-4" />
            <span className="font-mono text-xs tracking-wider">CORES: 5 ACTIVE</span>
          </div>
          <div className="flex items-center gap-2 text-[#00FFC8]">
            <Database className="w-4 h-4" />
            <span className="font-mono text-xs tracking-wider">STORAGE: AKASHIC</span>
          </div>
          <div className="flex items-center gap-2 text-[#FFE066]">
            <Radio className="w-4 h-4" />
            <span className="font-mono text-xs tracking-wider">SIGNAL: 33.3 FM</span>
          </div>
          <div className="flex items-center gap-2 text-[#FF3131]">
            <Zap className="w-4 h-4" />
            <span className="font-mono text-xs tracking-wider">POWER: INFINITE</span>
          </div>
        </div>

        {/* University College Network */}
        <DossierSection title="COLLEGE NETWORK" classification="NODE MATRIX">
          <div className="flex flex-wrap items-center justify-center gap-8 py-8">
            {UNIVERSITY_NODES.map((node) => (
              <div key={node.nodeId} className="flex flex-col items-center gap-3">
                <CollegeCrest
                  node={node}
                  size="md"
                  isActive={selectedNode === node.nodeId}
                  onClick={() => setSelectedNode(selectedNode === node.nodeId ? null : node.nodeId)}
                />
                <span className="font-mono text-xs tracking-widest" style={{ color: node.color }}>
                  {node.name}
                </span>
              </div>
            ))}
          </div>

          {/* Connection Lines Visualization */}
          <div className="relative h-2 my-6">
            <div className="absolute inset-x-0 top-1/2 h-px bg-gradient-to-r from-transparent via-[#00FFFF]/30 to-transparent" />
            <div className="absolute left-1/4 top-0 w-px h-full bg-[#00FFFF]/20" />
            <div className="absolute left-1/2 top-0 w-px h-full bg-[#FF3131]/20" />
            <div className="absolute left-3/4 top-0 w-px h-full bg-[#A35FFF]/20" />
          </div>
        </DossierSection>

        {/* Selected Node Details */}
        {activeNode && (
          <div
            className="my-8 p-6 rounded-lg border bg-black/70 backdrop-blur animate-in fade-in slide-in-from-bottom-4 duration-300"
            style={{ borderColor: `${activeNode.color}50` }}
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <span className="film-label" style={{ borderColor: activeNode.color, color: activeNode.color }}>
                    {activeNode.nodeId}
                  </span>
                  <h3 className="font-mono text-xl tracking-wider" style={{ color: activeNode.color }}>
                    {activeNode.fullName}
                  </h3>
                </div>
                <p className="text-white/60 italic">"{activeNode.loreTagline}"</p>
              </div>
              <Link
                href={`/university/${activeNode.name.toLowerCase()}`}
                className="rupture-cta text-xs flex items-center gap-2"
                style={{ borderColor: activeNode.color, color: activeNode.color }}
              >
                ENTER NODE <ArrowRight className="w-3 h-3" />
              </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div>
                <p className="font-mono text-white/30 text-xs tracking-wider mb-1">DISCIPLINE</p>
                <p className="text-white/80">{activeNode.discipline}</p>
              </div>
              <div>
                <p className="font-mono text-white/30 text-xs tracking-wider mb-1">MEDIA TYPES</p>
                <div className="flex flex-wrap gap-1">
                  {activeNode.mediaTypes.map((type) => (
                    <span
                      key={type}
                      className="px-2 py-0.5 rounded text-xs font-mono"
                      style={{ backgroundColor: `${activeNode.color}20`, color: activeNode.color }}
                    >
                      {type}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <p className="font-mono text-white/30 text-xs tracking-wider mb-1">CONNECTED NODES</p>
                <p className="text-white/60 font-mono text-xs">{activeNode.connectedNodes.join(" → ")}</p>
              </div>
            </div>
          </div>
        )}

        {/* Motherboard Subsystems */}
        <DossierSection title="SUBSYSTEM ARRAY" classification="INFRASTRUCTURE">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {MOTHERBOARD_SUBSYSTEMS.map((subsystem) => (
              <MotherboardNode key={subsystem.id} subsystem={subsystem} />
            ))}
          </div>
        </DossierSection>

        {/* Network Tagline */}
        <div className="mt-16 text-center">
          <p className="film-quote text-lg">"Wired Chaos University System — Validate Knowledge. Broadcast Lore."</p>
          <div className="mt-6 flex justify-center gap-4">
            <Link href="/university" className="rupture-cta">
              ENTER UNIVERSITY
            </Link>
            <Link href="/broadcast" className="rupture-cta" style={{ borderColor: "#FF3131", color: "#FF3131" }}>
              TUNE IN 33.3 FM
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
