import { CinematicHeader } from "@/components/akashic/cinematic-header"
import { SAMPLE_PUBLICATIONS, SAMPLE_SEEDS } from "@/config/story-engine"
import Link from "next/link"

export const metadata = {
  title: "Bookstore | WIRED CHAOS META",
  description: "CREATOR CODEX Publications",
}

const COLLECTIONS = [
  { slug: "cyberpunk", name: "Cyberpunk", count: 12 },
  { slug: "occult-noir", name: "Occult Noir", count: 8 },
  { slug: "cosmic-horror", name: "Cosmic Horror", count: 5 },
  { slug: "dystopian", name: "Dystopian", count: 15 },
]

export default function BookstorePage() {
  return (
    <div className="min-h-screen bg-black">
      <div className="fixed inset-0 pointer-events-none z-50 bg-[url('/textures/scanlines.png')] opacity-5" />

      <div className="relative z-10">
        <CinematicHeader
          title="BOOKSTORE"
          subtitle="CREATOR CODEX Publications"
          classification="WC META LABS // PUBLIC ACCESS"
        />

        <main className="max-w-7xl mx-auto px-6 py-12 space-y-16">
          {/* Featured Books */}
          <section>
            <h2 className="text-xs uppercase tracking-[0.3em] text-red-500 mb-6">Featured Publications</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {SAMPLE_PUBLICATIONS.map((pub) => {
                const seed = SAMPLE_SEEDS.find((s) => s.id === "seed-001")
                return (
                  <Link
                    key={pub.id}
                    href={`/books/${pub.book_slug}`}
                    className="group border border-zinc-800 rounded-lg overflow-hidden bg-zinc-900/50 hover:border-cyan-500/50 transition-all"
                  >
                    {/* Cover Placeholder */}
                    <div className="aspect-[3/4] bg-gradient-to-b from-cyan-500/10 to-fuchsia-500/10 flex items-center justify-center">
                      <div className="text-center p-6">
                        <div
                          className="text-5xl font-bold text-cyan-400 mb-3 group-hover:scale-110 transition-transform"
                          style={{ textShadow: "0 0 30px rgba(0,255,255,0.5)" }}
                        >
                          {seed?.title[0]}
                        </div>
                        <h3 className="text-lg font-mono text-zinc-200">{seed?.title}</h3>
                      </div>
                    </div>
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-cyan-400 capitalize">{seed?.genre}</span>
                        <span className="text-xs text-emerald-400">${pub.price}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span
                          className={`px-2 py-0.5 text-xs rounded ${
                            pub.kdp_status === "live"
                              ? "bg-green-500/20 text-green-400"
                              : "bg-amber-500/20 text-amber-400"
                          }`}
                        >
                          {pub.kdp_status.toUpperCase()}
                        </span>
                      </div>
                    </div>
                  </Link>
                )
              })}

              {/* Coming Soon placeholders */}
              {[1, 2].map((i) => (
                <div key={i} className="border border-zinc-800/50 rounded-lg overflow-hidden bg-zinc-900/30 opacity-50">
                  <div className="aspect-[3/4] bg-zinc-900 flex items-center justify-center">
                    <span className="text-zinc-600 font-mono text-sm">COMING SOON</span>
                  </div>
                  <div className="p-4">
                    <div className="h-4 bg-zinc-800 rounded w-2/3 mb-2" />
                    <div className="h-3 bg-zinc-800 rounded w-1/3" />
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Collections */}
          <section>
            <h2 className="text-xs uppercase tracking-[0.3em] text-red-500 mb-6">Collections</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {COLLECTIONS.map((col) => (
                <Link
                  key={col.slug}
                  href={`/collections/${col.slug}`}
                  className="p-6 border border-zinc-800 rounded-lg bg-zinc-900/50 hover:border-fuchsia-500/50 transition-all text-center"
                >
                  <h3 className="text-lg font-mono text-fuchsia-400 mb-1">{col.name}</h3>
                  <span className="text-xs text-zinc-500">{col.count} titles</span>
                </Link>
              ))}
            </div>
          </section>

          {/* Author Spotlight */}
          <section>
            <h2 className="text-xs uppercase tracking-[0.3em] text-red-500 mb-6">Author Spotlight</h2>
            <div className="p-6 border border-amber-500/20 rounded-lg bg-amber-500/5">
              <div className="flex items-center gap-6">
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-cyan-500 to-fuchsia-500 flex items-center justify-center">
                  <span className="text-2xl font-bold text-black">C</span>
                </div>
                <div>
                  <h3 className="text-xl font-mono text-amber-400">CIPHER</h3>
                  <p className="text-sm text-zinc-400">Rank: CHRONICLER | 3 Publications</p>
                  <Link href="/authors/cipher" className="text-xs text-cyan-400 hover:underline">
                    View Profile →
                  </Link>
                </div>
              </div>
            </div>
          </section>

          {/* CTA */}
          <section className="text-center py-12 border border-cyan-500/20 rounded-lg bg-gradient-to-b from-cyan-500/5 to-transparent">
            <h3 className="text-2xl font-mono text-cyan-400 mb-4">BECOME A CREATOR</h3>
            <p className="text-zinc-400 mb-6 max-w-xl mx-auto">
              Use the Story Engine to transform your ideas into published works. Earn XP, advance your avatar rank, and
              share in the royalties.
            </p>
            <Link
              href="/story-engine"
              className="inline-block px-8 py-3 bg-cyan-500 text-black font-mono hover:bg-cyan-400 transition-colors rounded"
            >
              ENTER STORY ENGINE
            </Link>
          </section>
        </main>
      </div>
    </div>
  )
}
