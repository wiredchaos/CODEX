import { CinematicHeader } from "@/components/akashic/cinematic-header"
import { MASTER_TIMELINE, GAS_ORACLE, TIMELINE_SUMMARY } from "@/config/master-timeline"
import { Zap } from "lucide-react"

export const metadata = {
  title: "Master Timeline | WIRED CHAOS META",
  description: "The Complete Grand Ledger of Ages",
}

export default function MasterTimelinePage() {
  return (
    <div className="min-h-screen bg-black">
      <div className="fixed inset-0 pointer-events-none z-50 bg-[url('/textures/scanlines.png')] opacity-5" />
      <div className="fixed inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-cyan-500/5 via-transparent to-transparent" />

      <div className="relative z-10">
        <CinematicHeader
          title="MASTER TIMELINE"
          subtitle="The Grand Ledger of Ages"
          classification="VAULT 33 ARCHIVES // HIGHEST CLEARANCE"
        />

        <main className="max-w-7xl mx-auto px-6 py-12 space-y-16">
          {/* Summary */}
          <section className="p-8 border border-cyan-500/30 rounded-lg bg-cyan-500/5">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h2 className="text-xl font-mono text-cyan-400 mb-4 tracking-wider">TIMELINE SUMMARY</h2>
                <div className="space-y-3 text-sm text-zinc-300">
                  <p>
                    <span className="text-cyan-400">Total Ages:</span> {TIMELINE_SUMMARY.totalAges}
                  </p>
                  <p>
                    <span className="text-cyan-400">Temporal Span:</span> {TIMELINE_SUMMARY.span}
                  </p>
                  <p className="leading-relaxed">
                    <span className="text-cyan-400">Key Theme:</span> {TIMELINE_SUMMARY.keyTheme}
                  </p>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-mono text-red-500 mb-3 tracking-wider">CRITICAL MOMENTS</h3>
                <div className="space-y-2 text-sm text-zinc-300">
                  <p>
                    <span className="text-red-400">Climax:</span> {TIMELINE_SUMMARY.climax}
                  </p>
                  <p>
                    <span className="text-emerald-400">Resolution:</span> {TIMELINE_SUMMARY.resolution}
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* Timeline Ages */}
          <section>
            <h2 className="text-xs uppercase tracking-[0.3em] text-red-500 mb-8">THE TWELVE AGES</h2>
            <div className="space-y-8">
              {MASTER_TIMELINE.map((age, idx) => (
                <div
                  key={age.id}
                  className="p-6 border rounded-lg transition-all hover:border-opacity-100"
                  style={{
                    borderColor: `${age.color}50`,
                    backgroundColor: `${age.color}05`,
                  }}
                >
                  <div className="flex items-start gap-6">
                    {/* Age Number */}
                    <div
                      className="flex-shrink-0 w-16 h-16 rounded-full flex items-center justify-center text-2xl font-bold"
                      style={{
                        backgroundColor: `${age.color}20`,
                        color: age.color,
                        boxShadow: `0 0 20px ${age.color}40`,
                      }}
                    >
                      {age.ageNumber}
                    </div>

                    {/* Content */}
                    <div className="flex-1 space-y-4">
                      <div>
                        <h3 className="text-2xl font-mono mb-1" style={{ color: age.color }}>
                          {age.name}
                        </h3>
                        <p className="text-sm text-zinc-400 font-mono">{age.era}</p>
                        <p className="text-xs text-zinc-500 mt-1">{age.yearsBefore}</p>
                      </div>

                      <p className="text-zinc-300 leading-relaxed">{age.description}</p>

                      {/* Key Events */}
                      <div>
                        <h4 className="text-xs uppercase tracking-wider text-zinc-500 mb-2">Key Events</h4>
                        <ul className="space-y-1">
                          {age.keyEvents.map((event, i) => (
                            <li key={i} className="text-sm text-zinc-400 flex items-start gap-2">
                              <span className="text-cyan-400 mt-1">→</span>
                              <span>{event}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Artifacts */}
                      <div className="flex flex-wrap gap-3">
                        {age.artifacts.map((artifact, i) => (
                          <div
                            key={i}
                            className="px-3 py-2 rounded border text-xs"
                            style={{
                              borderColor: `${age.color}40`,
                              backgroundColor: `${age.color}10`,
                            }}
                          >
                            <div className="font-mono" style={{ color: age.color }}>
                              {artifact.name}
                            </div>
                            <div className="text-zinc-500 text-[10px] mt-0.5">{artifact.type}</div>
                          </div>
                        ))}
                      </div>

                      {/* Significance */}
                      <div className="pt-3 border-t border-zinc-800">
                        <p className="text-xs text-zinc-500 italic">{age.significance}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Gas Oracle Integration */}
          <section className="p-8 border border-amber-500/30 rounded-lg bg-amber-500/5">
            <div className="flex items-center gap-3 mb-6">
              <Zap className="w-6 h-6 text-amber-400" />
              <h2 className="text-2xl font-mono text-amber-400 tracking-wider">THE ARCHITECT OF GAS</h2>
            </div>

            <div className="space-y-6">
              <div>
                <h3 className="text-sm text-zinc-400 mb-2">ROLE</h3>
                <p className="text-zinc-200">{GAS_ORACLE.role}</p>
              </div>

              <div>
                <h3 className="text-sm text-zinc-400 mb-2">CAPABILITIES</h3>
                <div className="grid md:grid-cols-2 gap-2">
                  {GAS_ORACLE.capabilities.map((cap, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm text-zinc-300">
                      <span className="text-amber-400">●</span>
                      {cap}
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-sm text-zinc-400 mb-3">RELATIONSHIPS</h3>
                <div className="space-y-2 text-sm">
                  <p className="text-red-400">Neteru: {GAS_ORACLE.relationship.neteru}</p>
                  <p className="text-cyan-400">Akira Codex: {GAS_ORACLE.relationship.akira}</p>
                  <p className="text-emerald-400">NEURO: {GAS_ORACLE.relationship.neuro}</p>
                </div>
              </div>

              <div className="pt-4 border-t border-amber-500/20">
                <p className="text-amber-300 text-lg font-mono">{GAS_ORACLE.significance}</p>
              </div>
            </div>
          </section>
        </main>
      </div>
    </div>
  )
}
