"use client"

import { CinematicHeader } from "@/components/akashic/cinematic-header"
import { DossierSection } from "@/components/akashic/dossier-section"
import { BLACK_LEDGER_TIMELINE, CYCLE_SUMMARY } from "@/config/black-ledger-year"
import { CORE_FACTIONS } from "@/config/lore-canon"
import { Badge } from "@/components/ui/badge"
import { Card } from "@/components/ui/card"

export default function BlackLedgerPage() {
  return (
    <div className="min-h-screen bg-black">
      <CinematicHeader
        title="THE BLACK LEDGER YEAR"
        subtitle="CYCLE 2025.X"
        tagline={CYCLE_SUMMARY.tagline}
        classification="LEVEL V CLEARANCE"
      />

      <div className="container mx-auto px-4 py-12 max-w-5xl">
        {/* Opening Transmission */}
        <div className="mb-16 text-center border-y border-cyan-500/30 py-8">
          <p className="text-cyan-400 text-lg font-mono mb-4">{CYCLE_SUMMARY.tagline}</p>
          <p className="text-zinc-500 text-sm tracking-widest">{CYCLE_SUMMARY.attribution}</p>
          <div className="mt-6 flex flex-wrap justify-center gap-2">
            {CYCLE_SUMMARY.keyThemes.map((theme) => (
              <Badge key={theme} variant="outline" className="border-red-500/30 text-red-400">
                {theme}
              </Badge>
            ))}
          </div>
        </div>

        {/* Timeline */}
        <div className="space-y-8">
          {BLACK_LEDGER_TIMELINE.map((event, index) => (
            <Card
              key={event.month}
              className="bg-black/60 border-cyan-500/20 backdrop-blur-sm hover:border-cyan-500/40 transition-all overflow-hidden"
            >
              <div className="p-6">
                {/* Month & Category */}
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <p className="text-cyan-400 text-sm font-mono tracking-wider mb-1">
                      {String(index + 1).padStart(2, "0")} / {event.month.toUpperCase()}
                    </p>
                    <h3 className="text-2xl font-bold text-white tracking-wide mb-2">{event.title}</h3>
                    <Badge variant="outline" className={`${getCategoryColor(event.category)} text-xs`}>
                      {event.category}
                    </Badge>
                  </div>
                  {event.losses && (
                    <div className="text-right">
                      <p className="text-red-400 text-2xl font-bold font-mono">{event.losses}</p>
                      <p className="text-zinc-500 text-xs">LOST</p>
                    </div>
                  )}
                </div>

                {/* Description */}
                <p className="text-zinc-300 mb-6 leading-relaxed">{event.description}</p>

                {/* Key Events */}
                <DossierSection title="KEY EVENTS" classification="VERIFIED">
                  <ul className="space-y-2">
                    {event.keyEvents.map((ke, i) => (
                      <li key={i} className="text-zinc-400 text-sm flex items-start gap-2">
                        <span className="text-cyan-400 mt-1">▸</span>
                        <span>{ke}</span>
                      </li>
                    ))}
                  </ul>
                </DossierSection>

                {/* Story Hooks */}
                {event.storyHooks && (
                  <DossierSection title="INVESTIGATION VECTORS" classification="CLASSIFIED" className="mt-4">
                    <ul className="space-y-2">
                      {event.storyHooks.map((hook, i) => (
                        <li key={i} className="text-red-400 text-sm flex items-start gap-2">
                          <span className="text-red-500 mt-1">?</span>
                          <span>{hook}</span>
                        </li>
                      ))}
                    </ul>
                  </DossierSection>
                )}

                {/* Factions Involved */}
                <div className="mt-4 flex flex-wrap gap-2">
                  {event.factions.map((fId) => {
                    const faction = CORE_FACTIONS.find((f) => f.id === fId)
                    return faction ? (
                      <Badge
                        key={fId}
                        variant="outline"
                        className="border-zinc-700 text-zinc-400 text-xs"
                        style={{ borderColor: faction.color + "40", color: faction.color }}
                      >
                        {faction.name}
                      </Badge>
                    ) : null
                  })}
                </div>
              </div>

              {/* Anomaly Special Marker */}
              {event.category === "Anomaly" && (
                <div className="bg-red-500/10 border-t border-red-500/30 p-3 text-center">
                  <p className="text-red-400 text-xs font-mono tracking-wider animate-pulse">
                    ⚠ CRITICAL VAULT 33 EVENT ⚠
                  </p>
                </div>
              )}
            </Card>
          ))}
        </div>

        {/* Aftermath */}
        <div className="mt-16 border-t border-cyan-500/30 pt-12">
          <h3 className="text-3xl font-bold text-white tracking-wide mb-6 text-center">THE AFTERMATH</h3>
          <div className="space-y-4 max-w-2xl mx-auto">
            {CYCLE_SUMMARY.aftermath.map((line, i) => (
              <p key={i} className="text-cyan-400 text-center text-lg font-mono leading-relaxed">
                {line}
              </p>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

function getCategoryColor(category: string): string {
  switch (category) {
    case "Collapse":
      return "border-orange-500/30 text-orange-400"
    case "Breach":
      return "border-red-500/30 text-red-400"
    case "Manipulation":
      return "border-purple-500/30 text-purple-400"
    case "War":
      return "border-cyan-500/30 text-cyan-400"
    case "Anomaly":
      return "border-red-500/50 text-red-400 animate-pulse"
    default:
      return "border-zinc-500/30 text-zinc-400"
  }
}
