import Link from "next/link"
import { POS_CHANNELS } from "@/lib/pos/config"
import { RadioTower, Tv, Building2, Radio } from "lucide-react"

export default function POSHomePage() {
  const mainlineChannel = POS_CHANNELS.find((c) => c.id === "BWB_MAINLINE")!

  return (
    <div className="py-8 space-y-12">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-2xl border border-zinc-800">
        <div className="absolute inset-0 bg-gradient-to-br from-red-950/50 via-black to-black" />
        <div className="relative p-8 md:p-12">
          <div className="flex items-center gap-2 text-zinc-500 text-sm mb-4">
            <Building2 className="w-4 h-4" />
            <span>POS TOWER</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
            PROOF OF <span className="text-red-500">STREAM</span>
          </h1>
          <p className="text-xl text-zinc-400 max-w-2xl mb-6">
            The decentralized broadcast network. News, culture, markets, and music — all on-chain.
          </p>
          <div className="flex flex-wrap gap-3">
            <Link
              href="/pos/bwb"
              className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-lg transition-colors"
            >
              Watch BWB Live
            </Link>
            <Link
              href="/world"
              className="px-5 py-2.5 border border-zinc-700 hover:border-zinc-500 text-white font-semibold rounded-lg transition-colors"
            >
              Enter POS Tower
            </Link>
          </div>
        </div>
      </section>

      {/* BWB Network intro */}
      <section>
        <div className="flex items-center gap-3 mb-6">
          <RadioTower className="w-6 h-6 text-red-500" />
          <h2 className="text-2xl font-bold text-white">BWB: Barbed Wire Broadcast</h2>
        </div>
        <p className="text-zinc-400 mb-6 max-w-3xl">
          News that cuts through the noise. BWB is the news division of POS, delivering breaking coverage, market
          analysis, political debate, and cultural commentary across six dedicated channels.
        </p>

        {/* Channel grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {POS_CHANNELS.map((channel) => (
            <Link
              key={channel.id}
              href={`/pos/${channel.slug}`}
              className="group p-5 bg-zinc-900/50 hover:bg-zinc-900 border border-zinc-800 hover:border-zinc-700 rounded-xl transition-all"
            >
              <div className="flex items-start gap-3">
                <div
                  className="w-10 h-10 rounded-lg flex items-center justify-center"
                  style={{ backgroundColor: `${channel.color}20` }}
                >
                  <Tv className="w-5 h-5" style={{ color: channel.color }} />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-white group-hover:text-cyan-400 transition-colors">
                    {channel.name}
                  </h3>
                  <p className="text-sm text-zinc-500">{channel.tagline}</p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* 33.3FM promo */}
      <section className="p-6 bg-gradient-to-r from-cyan-950/30 to-fuchsia-950/30 border border-cyan-500/20 rounded-2xl">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-cyan-500/20 rounded-xl flex items-center justify-center">
            <Radio className="w-8 h-8 text-cyan-400" />
          </div>
          <div className="flex-1">
            <h3 className="text-xl font-bold text-white">33.3FM DOGECHAIN</h3>
            <p className="text-zinc-400">Always-on radio. Music, podcasts, and live DJ sets curated by Chrome Fang.</p>
          </div>
          <Link
            href="/33fm"
            className="px-5 py-2.5 bg-cyan-500 hover:bg-cyan-600 text-black font-semibold rounded-lg transition-colors"
          >
            Tune In
          </Link>
        </div>
      </section>
    </div>
  )
}
