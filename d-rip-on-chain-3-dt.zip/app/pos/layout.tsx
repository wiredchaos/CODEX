import type { ReactNode } from "react"
import Link from "next/link"
import { POS_CHANNELS } from "@/lib/pos/config"
import { HeadlineTicker } from "@/components/broadcast/headline-ticker"
import { SignalChainPlayer } from "@/components/broadcast/signal-chain-player"

export default function POSLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-black text-white pb-16">
      {/* POS Header */}
      <header className="border-b border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link href="/pos" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-red-600 to-red-800 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xs">POS</span>
            </div>
            <span className="font-bold text-lg">Proof of Stream</span>
          </Link>

          {/* Channel nav */}
          <nav className="hidden md:flex items-center gap-1">
            {POS_CHANNELS.slice(0, 4).map((channel) => (
              <Link
                key={channel.id}
                href={`/pos/${channel.slug}`}
                className="px-3 py-1.5 text-sm text-zinc-400 hover:text-white hover:bg-zinc-900 rounded-md transition-colors"
              >
                {channel.name.replace("BWB: ", "")}
              </Link>
            ))}
            <Link href="/pos/channels" className="px-3 py-1.5 text-sm text-zinc-500 hover:text-white transition-colors">
              More
            </Link>
          </nav>

          <div className="flex items-center gap-3">
            <Link
              href="/33fm"
              className="px-3 py-1.5 text-sm bg-cyan-500/20 text-cyan-400 rounded-md hover:bg-cyan-500/30 transition-colors"
            >
              33.3FM
            </Link>
          </div>
        </div>

        {/* Headline ticker */}
        <HeadlineTicker />
      </header>

      {/* Main content */}
      <main className="max-w-7xl mx-auto px-4">{children}</main>

      {/* Global Signal Chain player */}
      <SignalChainPlayer />
    </div>
  )
}
