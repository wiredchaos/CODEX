import { POS_CHANNELS } from "@/lib/pos/config"
import { ChannelHeader } from "@/components/broadcast/channel-header"
import { SegmentRail } from "@/components/broadcast/segment-rail"
import type { BWBSegment } from "@/lib/pos/types"

const MOCK_SEGMENTS: BWBSegment[] = [
  {
    id: "1",
    channelId: "BWB_MAINLINE",
    title: "BWB Evening News",
    description: "Top stories from across the decentralized world",
    status: "LIVE",
    scheduledAt: new Date(),
    duration: 60,
    hosts: ["Marcus Chain", "Elena Wire"],
  },
  {
    id: "2",
    channelId: "BWB_MAINLINE",
    title: "The Barbed Hour",
    description: "In-depth analysis and investigative reports",
    status: "UPCOMING",
    scheduledAt: new Date(Date.now() + 3600000),
    duration: 60,
    hosts: ["Victor Ledger"],
  },
  {
    id: "3",
    channelId: "BWB_MAINLINE",
    title: "Morning Wire",
    description: "Wake up to the headlines that matter",
    status: "REPLAY",
    scheduledAt: null,
    duration: 45,
    hosts: ["Sara Block"],
  },
]

export default function BWBMainlinePage() {
  const channel = POS_CHANNELS.find((c) => c.id === "BWB_MAINLINE")!

  return (
    <div className="py-6 space-y-8">
      <ChannelHeader channel={channel} status="LIVE" currentShow="BWB Evening News" />

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Main video area */}
        <div className="lg:col-span-2">
          <div className="aspect-video bg-zinc-900 rounded-xl border border-zinc-800 flex items-center justify-center">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-red-600/20 rounded-full flex items-center justify-center">
                <span className="text-2xl font-bold text-red-500">BWB</span>
              </div>
              <p className="text-zinc-400">Live broadcast player</p>
              <p className="text-sm text-zinc-600">Video integration ready</p>
            </div>
          </div>

          {/* Show description */}
          <div className="mt-4 p-4 bg-zinc-900/50 rounded-xl border border-zinc-800">
            <h2 className="text-xl font-bold text-white mb-2">BWB Evening News</h2>
            <p className="text-zinc-400">
              Your nightly roundup of breaking news, market movements, and cultural shifts from across the decentralized
              ecosystem. Anchored by Marcus Chain and Elena Wire.
            </p>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <SegmentRail segments={MOCK_SEGMENTS} title="Today's Schedule" />
        </div>
      </div>
    </div>
  )
}
