import { POS_CHANNELS } from "@/lib/pos/config"
import { ChannelHeader } from "@/components/broadcast/channel-header"
import { TrendingUp, TrendingDown, Minus } from "lucide-react"

const MOCK_TICKERS = [
  { symbol: "DOGE", price: "0.1234", change: "+5.2%", trend: "up" },
  { symbol: "BTC", price: "67,432", change: "+1.8%", trend: "up" },
  { symbol: "ETH", price: "3,456", change: "-0.5%", trend: "down" },
  { symbol: "SOL", price: "145.67", change: "+3.1%", trend: "up" },
  { symbol: "CHAOS", price: "0.0089", change: "0.0%", trend: "flat" },
]

export default function BWBPulse24Page() {
  const channel = POS_CHANNELS.find((c) => c.id === "BWB_PULSE24")!

  return (
    <div className="py-6 space-y-8">
      <ChannelHeader channel={channel} status="LIVE" currentShow="Market Open" />

      {/* Market tickers */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {MOCK_TICKERS.map((ticker) => (
          <div key={ticker.symbol} className="p-4 bg-zinc-900/50 rounded-xl border border-zinc-800">
            <div className="text-sm text-zinc-500 mb-1">{ticker.symbol}</div>
            <div className="text-xl font-bold text-white">${ticker.price}</div>
            <div
              className={`flex items-center gap-1 text-sm ${
                ticker.trend === "up" ? "text-green-400" : ticker.trend === "down" ? "text-red-400" : "text-zinc-400"
              }`}
            >
              {ticker.trend === "up" && <TrendingUp className="w-4 h-4" />}
              {ticker.trend === "down" && <TrendingDown className="w-4 h-4" />}
              {ticker.trend === "flat" && <Minus className="w-4 h-4" />}
              {ticker.change}
            </div>
          </div>
        ))}
      </div>

      {/* Main content */}
      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="aspect-video bg-zinc-900 rounded-xl border border-zinc-800 flex items-center justify-center">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-green-600/20 rounded-full flex items-center justify-center">
                <TrendingUp className="w-8 h-8 text-green-500" />
              </div>
              <p className="text-zinc-400">Pulse24 Live Markets</p>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-white">Breaking Markets</h3>
          <div className="space-y-3">
            {[
              "DOGE rallies on renewed retail interest",
              "DeFi TVL hits new monthly high",
              "Fed signals potential rate adjustment",
              "Memecoin season returns to markets",
            ].map((headline, i) => (
              <div key={i} className="p-3 bg-zinc-900/50 rounded-lg border border-zinc-800">
                <p className="text-sm text-zinc-300">{headline}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
