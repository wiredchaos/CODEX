import { POS_CHANNELS } from "@/lib/pos/config"
import { ChannelHeader } from "@/components/broadcast/channel-header"
import { SegmentRail } from "@/components/broadcast/segment-rail"
import type { BWBSegment } from "@/lib/pos/types"

const DUOPLEX_SEGMENTS: BWBSegment[] = [
  {
    id: "1",
    channelId: "BWB_DUOPLEX",
    title: "The Two Chains",
    description: "Red Chain vs Blue Chain - tonight's debate",
    status: "LIVE",
    scheduledAt: new Date(),
    duration: 90,
    hosts: ["Red Representative", "Blue Representative"],
  },
  {
    id: "2",
    channelId: "BWB_DUOPLEX",
    title: "Chain Reaction",
    description: "Post-debate analysis and viewer reactions",
    status: "UPCOMING",
    scheduledAt: new Date(Date.now() + 5400000),
    duration: 30,
    hosts: ["Panel"],
  },
]

export default function BWBDuoplexPage() {
  const channel = POS_CHANNELS.find((c) => c.id === "BWB_DUOPLEX")!

  return (
    <div className="py-6 space-y-8">
      <ChannelHeader channel={channel} status="LIVE" currentShow="The Two Chains" />

      {/* Split stage visual */}
      <div className="grid md:grid-cols-2 gap-1 rounded-xl overflow-hidden">
        {/* Red Chain side */}
        <div className="aspect-video bg-gradient-to-br from-red-950 to-red-900/50 flex items-center justify-center border-r border-zinc-900">
          <div className="text-center">
            <div className="w-20 h-20 mx-auto mb-4 bg-red-600/30 rounded-full flex items-center justify-center">
              <span className="text-3xl font-bold text-red-500">R</span>
            </div>
            <h3 className="text-xl font-bold text-red-400">RED CHAIN</h3>
            <p className="text-sm text-red-300/60">Conservative • Tradition • Stability</p>
          </div>
        </div>

        {/* Blue Chain side */}
        <div className="aspect-video bg-gradient-to-bl from-blue-950 to-blue-900/50 flex items-center justify-center">
          <div className="text-center">
            <div className="w-20 h-20 mx-auto mb-4 bg-blue-600/30 rounded-full flex items-center justify-center">
              <span className="text-3xl font-bold text-blue-500">B</span>
            </div>
            <h3 className="text-xl font-bold text-blue-400">BLUE CHAIN</h3>
            <p className="text-sm text-blue-300/60">Progressive • Innovation • Change</p>
          </div>
        </div>
      </div>

      {/* Tonight's topic */}
      <div className="p-6 bg-zinc-900/50 rounded-xl border border-zinc-800">
        <div className="flex items-center gap-3 mb-4">
          <span className="px-3 py-1 bg-pink-500/20 text-pink-400 text-sm font-medium rounded-full">
            TONIGHT'S TOPIC
          </span>
        </div>
        <h2 className="text-2xl font-bold text-white mb-2">Decentralized Governance: Who Decides the Future?</h2>
        <p className="text-zinc-400">
          Red Chain argues for established validator networks and conservative protocol changes. Blue Chain pushes for
          rapid iteration and community-first governance models. Who will win tonight's debate?
        </p>
      </div>

      <SegmentRail segments={DUOPLEX_SEGMENTS} title="Duoplex Schedule" />
    </div>
  )
}
