// VALORITHM™ Dashboard - Professional Sweat Equity Valuation

import type { Metadata } from "next"
import { ValorimthDashboard } from "./valorithm-dashboard"

export const metadata: Metadata = {
  title: "VALORITHM™ - Sweat Equity Valuation Engine",
  description: "Quantify, calculate, and substantiate the real economic value of creative and technical work",
}

export default function ValorithmPage() {
  return <ValorimthDashboard />
}
