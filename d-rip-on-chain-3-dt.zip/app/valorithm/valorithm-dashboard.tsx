"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TrendingUp, DollarSign, Clock, Briefcase, FileText, Plus, LineChart, PieChartIcon } from "lucide-react"

interface DashboardData {
  kpis: {
    totalValue: number
    costAvoided: number
    hoursSaved: number
    ipAssets: number
  }
  prompts: any[]
  outputs: any[]
  ipAssets: any[]
  analytics: {
    byCategory: Record<string, number>
    timeline: Array<{ date: string; value: number }>
  }
  needsSetup: boolean
}

export function ValorimthDashboard() {
  const [data, setData] = useState<DashboardData | null>(null)
  const [loading, setLoading] = useState(true)
  const [captureOpen, setCaptureOpen] = useState(false)
  const [needsSetup, setNeedsSetup] = useState(false)

  useEffect(() => {
    fetchDashboard()
  }, [])

  const fetchDashboard = async () => {
    try {
      console.log("[v0] Fetching VALORITHM dashboard")
      const res = await fetch("/api/valorithm/dashboard")
      const json = await res.json()
      console.log("[v0] Dashboard response:", json)

      if (json.needsSetup) {
        setNeedsSetup(true)
      }

      setData(json)
    } catch (error) {
      console.error("[VALORITHM] Fetch error:", error)
    } finally {
      setLoading(false)
    }
  }

  const generateReport = async () => {
    try {
      const res = await fetch("/api/valorithm/report", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ report_type: "valuation" }),
      })
      const json = await res.json()

      if (json.success) {
        alert("Report generated successfully!")
        // Download or display report
      }
    } catch (error) {
      console.error("[VALORITHM] Report error:", error)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-zinc-950 via-zinc-900 to-black flex items-center justify-center">
        <div className="text-[#00FFFF] font-mono animate-pulse">Loading VALORITHM™...</div>
      </div>
    )
  }

  if (needsSetup) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-zinc-950 via-zinc-900 to-black">
        <header className="border-b border-[#00FFFF]/20 bg-black/50 backdrop-blur">
          <div className="container mx-auto px-4 py-4">
            <h1 className="text-2xl font-bold text-white">
              VALORITHM<span className="text-[#00FFFF]">™</span>
            </h1>
            <p className="text-sm text-zinc-400 font-mono">Sweat Equity Valuation Engine</p>
          </div>
        </header>

        <main className="container mx-auto px-4 py-8">
          <Card className="bg-zinc-900/50 border-[#FF3131]/30 p-8">
            <div className="text-center space-y-4">
              <h2 className="text-xl font-bold text-[#FF3131]">Database Setup Required</h2>
              <p className="text-zinc-400">
                The VALORITHM database tables need to be created. Please run the SQL script:
              </p>
              <code className="block bg-black/50 p-4 rounded text-[#00FFFF] text-sm font-mono text-left">
                scripts/valorithm-schema-v1.sql
              </code>
              <p className="text-xs text-zinc-500">
                Navigate to your Supabase SQL Editor and execute the schema script to initialize the tables.
              </p>
              <Button
                onClick={() => window.location.reload()}
                className="bg-[#00FFFF] text-black hover:bg-[#00FFFF]/90"
              >
                Retry Connection
              </Button>
            </div>
          </Card>
        </main>
      </div>
    )
  }

  const kpis = data?.kpis || { totalValue: 0, costAvoided: 0, hoursSaved: 0, ipAssets: 0 }

  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-950 via-zinc-900 to-black">
      {/* Header */}
      <header className="border-b border-[#00FFFF]/20 bg-black/50 backdrop-blur">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-white">
                VALORITHM<span className="text-[#00FFFF]">™</span>
              </h1>
              <p className="text-sm text-zinc-400 font-mono">Sweat Equity Valuation Engine</p>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={generateReport}
                variant="outline"
                className="border-[#00FFFF]/30 text-[#00FFFF] hover:bg-[#00FFFF]/10 bg-transparent"
              >
                <FileText className="w-4 h-4 mr-2" />
                Generate Report
              </Button>
              <Button onClick={() => setCaptureOpen(true)} className="bg-[#00FFFF] text-black hover:bg-[#00FFFF]/90">
                <Plus className="w-4 h-4 mr-2" />
                Capture Work
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="bg-zinc-900/50 border-[#00FFFF]/20 p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-zinc-400">Total Sweat Equity</span>
              <DollarSign className="w-5 h-5 text-[#00FFFF]" />
            </div>
            <div className="text-3xl font-bold text-white">${kpis.totalValue.toLocaleString()}</div>
            <div className="text-xs text-[#39FF14] mt-1">+{Math.round(kpis.totalValue / 1000)}% growth</div>
          </Card>

          <Card className="bg-zinc-900/50 border-[#00FFFF]/20 p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-zinc-400">AI Cost Avoided</span>
              <TrendingUp className="w-5 h-5 text-[#39FF14]" />
            </div>
            <div className="text-3xl font-bold text-white">${kpis.costAvoided.toLocaleString()}</div>
            <div className="text-xs text-zinc-500 mt-1">Efficiency gain</div>
          </Card>

          <Card className="bg-zinc-900/50 border-[#00FFFF]/20 p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-zinc-400">Hours Saved</span>
              <Clock className="w-5 h-5 text-[#FF3131]" />
            </div>
            <div className="text-3xl font-bold text-white">{kpis.hoursSaved}</div>
            <div className="text-xs text-zinc-500 mt-1">{Math.round(kpis.hoursSaved / 8)} work days</div>
          </Card>

          <Card className="bg-zinc-900/50 border-[#00FFFF]/20 p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-zinc-400">IP Assets</span>
              <Briefcase className="w-5 h-5 text-[#00FFFF]" />
            </div>
            <div className="text-3xl font-bold text-white">{kpis.ipAssets}</div>
            <div className="text-xs text-zinc-500 mt-1">Created this period</div>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="activity" className="space-y-6">
          <TabsList className="bg-zinc-900/50 border border-[#00FFFF]/20">
            <TabsTrigger value="activity">Activity Feed</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="assets">IP Assets</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
          </TabsList>

          <TabsContent value="activity" className="space-y-4">
            <Card className="bg-zinc-900/50 border-[#00FFFF]/20">
              <div className="p-6">
                <h2 className="text-xl font-bold text-white mb-4">Recent Work Activity</h2>
                <div className="space-y-3">
                  {data?.prompts.slice(0, 10).map((prompt) => (
                    <div
                      key={prompt.id}
                      className="flex items-start justify-between p-4 rounded-lg bg-black/30 border border-[#00FFFF]/10"
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="px-2 py-0.5 rounded text-xs bg-[#00FFFF]/20 text-[#00FFFF] border border-[#00FFFF]/30">
                            {prompt.category}
                          </span>
                          <span className="text-xs text-zinc-500">Tier {prompt.complexity_tier}</span>
                        </div>
                        <p className="text-sm text-zinc-300 line-clamp-2">{prompt.content}</p>
                        <div className="flex items-center gap-4 mt-2 text-xs text-zinc-500">
                          <span>{prompt.estimated_hours}h</span>
                          <span>${prompt.estimated_cost}</span>
                          <span>{new Date(prompt.timestamp).toLocaleDateString()}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <Card className="bg-zinc-900/50 border-[#00FFFF]/20 p-6">
                <div className="flex items-center gap-2 mb-4">
                  <PieChartIcon className="w-5 h-5 text-[#00FFFF]" />
                  <h3 className="text-lg font-bold text-white">Work Category Breakdown</h3>
                </div>
                <div className="space-y-3">
                  {Object.entries(data?.analytics.byCategory || {}).map(([category, value]) => (
                    <div key={category} className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span className="text-zinc-300 capitalize">{category}</span>
                        <span className="text-[#00FFFF]">${value.toLocaleString()}</span>
                      </div>
                      <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-[#00FFFF] to-[#39FF14]"
                          style={{ width: `${(value / kpis.totalValue) * 100}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              <Card className="bg-zinc-900/50 border-[#00FFFF]/20 p-6">
                <div className="flex items-center gap-2 mb-4">
                  <LineChart className="w-5 h-5 text-[#39FF14]" />
                  <h3 className="text-lg font-bold text-white">Value Creation Timeline</h3>
                </div>
                <div className="space-y-2">
                  {data?.analytics.timeline.slice(-7).map((point) => (
                    <div key={point.date} className="flex items-center justify-between text-sm">
                      <span className="text-zinc-400">
                        {new Date(point.date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                      </span>
                      <span className="text-[#39FF14] font-mono">${point.value.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="assets">
            <Card className="bg-zinc-900/50 border-[#00FFFF]/20 p-6">
              <h2 className="text-xl font-bold text-white mb-4">IP Asset Portfolio</h2>
              <p className="text-zinc-400">IP asset tracking coming soon...</p>
            </Card>
          </TabsContent>

          <TabsContent value="reports">
            <Card className="bg-zinc-900/50 border-[#00FFFF]/20 p-6">
              <h2 className="text-xl font-bold text-white mb-4">Generated Reports</h2>
              <p className="text-zinc-400">Reports history coming soon...</p>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
