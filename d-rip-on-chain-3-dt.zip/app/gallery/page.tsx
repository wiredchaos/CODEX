"use client"

import { GalleryGrid } from "@/components/gallery/gallery-grid"
import { getFeaturedPhotos } from "@/lib/gallery/photos"
import Image from "next/image"
import Link from "next/link"
import { useMemo } from "react"

export default function GalleryPage() {
  const featuredPhotos = useMemo(() => getFeaturedPhotos(), [])
  const heroPhoto = featuredPhotos[0]

  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[50vh] min-h-[400px] flex items-end">
        {/* Background Image */}
        {heroPhoto && (
          <>
            <Image
              src={heroPhoto.src || "/placeholder.svg"}
              alt={heroPhoto.alt}
              fill
              className="object-cover"
              priority
            />
            {/* Scanline overlay */}
            <div className="absolute inset-0 pointer-events-none bg-[repeating-linear-gradient(0deg,transparent,transparent_2px,rgba(0,255,255,0.02)_2px,rgba(0,255,255,0.02)_4px)]" />
          </>
        )}

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />

        {/* Content */}
        <div className="relative z-10 w-full max-w-7xl mx-auto px-6 pb-12">
          <div className="flex items-center gap-2 mb-4">
            <Link href="/" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              WIRED CHAOS
            </Link>
            <span className="text-muted-foreground">/</span>
            <span className="text-sm text-cyan-400">Gallery</span>
          </div>

          <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-3">
            <span className="neon-text-cyan">NEURO PHOTO GALLERY</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl">
            Avatar portraits and character visuals from across the WIRED CHAOS META universe. Toggle between AKASHIC and
            CORPORATE modes.
          </p>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="max-w-7xl mx-auto px-6 py-12">
        <GalleryGrid />
      </section>

      {/* Info Section */}
      <section className="max-w-7xl mx-auto px-6 pb-12">
        <div className="grid md:grid-cols-2 gap-6">
          {/* AKASHIC Info */}
          <div className="p-6 rounded-xl border border-cyan-500/30 bg-cyan-500/5">
            <h3 className="text-lg font-bold text-cyan-400 mb-2">AKASHIC MODE</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              The RUPTURE aesthetic. Cinematic, glitch-touched visuals with cyan and red color signatures. Used for
              lore-heavy content, portal imagery, and frequency-aligned transmissions from VRG33589, Vault 33, and Gate
              33.3.
            </p>
          </div>

          {/* CORPORATE Info */}
          <div className="p-6 rounded-xl border border-primary/30 bg-primary/5">
            <h3 className="text-lg font-bold text-primary mb-2">CORPORATE MODE</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              The WIRED CHAOS META Hub style. Clean, professional layouts with softer glows. Used for 789 Studios crew
              profiles, business patch interfaces, and publicly-facing production content.
            </p>
          </div>
        </div>
      </section>
    </main>
  )
}
