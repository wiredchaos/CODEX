"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Award, Brain, Briefcase, Heart, LinkIcon, Settings, TrendingUp, Users, Zap } from "lucide-react"

interface DashboardData {
  profile: any
  stats: {
    totalXp: number
    level: number
    totalGamesCompleted: number
    totalSkillsEarned: number
    totalCredentials: number
  }
  skillScores: Array<{
    categoryId: string
    categoryName: string
    totalXp: number
    avgLevel: number
    skillCount: number
  }>
  recentActivity: any[]
  skills: any[]
  credentials: any[]
}

const categoryIcons: Record<string, any> = {
  cognitive: Brain,
  emotional: Heart,
  leadership: Users,
  technical: Settings,
  workplace: Briefcase,
  blockchain: LinkIcon,
}

const categoryColors: Record<string, string> = {
  cognitive: "text-cyan-400 bg-cyan-500/10 border-cyan-500/20",
  emotional: "text-red-400 bg-red-500/10 border-red-500/20",
  leadership: "text-green-400 bg-green-500/10 border-green-500/20",
  technical: "text-yellow-400 bg-yellow-500/10 border-yellow-500/20",
  workplace: "text-orange-400 bg-orange-500/10 border-orange-500/20",
  blockchain: "text-purple-400 bg-purple-500/10 border-purple-500/20",
}

export function NeuroNodeDashboard() {
  const [data, setData] = useState<DashboardData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchDashboard()
  }, [])

  async function fetchDashboard() {
    try {
      const res = await fetch("/api/neuro-node/dashboard")
      if (res.ok) {
        const json = await res.json()
        setData(json)
      }
    } catch (error) {
      console.error("[v0] Dashboard fetch failed:", error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-500 mx-auto mb-4" />
          <p className="text-muted-foreground">Loading NEURO NODE ID...</p>
        </div>
      </div>
    )
  }

  if (!data) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Welcome to NEURO NODE</CardTitle>
            <CardDescription>Create your professional skill passport to get started</CardDescription>
          </CardHeader>
          <CardContent>
            <Button className="w-full">Create Profile</Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  const { profile, stats, skillScores, recentActivity, skills, credentials } = data
  const xpToNextLevel = stats.level * 1000
  const xpProgress = (stats.totalXp % 1000) / 10

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border/50 bg-card/30 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center text-2xl font-bold text-white">
                {profile?.display_name?.charAt(0) || "N"}
              </div>
              <div>
                <h1 className="text-2xl font-bold">{profile?.display_name || "Professional"}</h1>
                <p className="text-sm text-muted-foreground">{profile?.headline || "Building skills"}</p>
                <p className="text-xs text-cyan-400 font-mono mt-1">{profile?.node_id}</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <div className="text-sm text-muted-foreground">Level {stats.level}</div>
                <div className="text-2xl font-bold text-cyan-400">{stats.totalXp.toLocaleString()} XP</div>
              </div>
              <Button variant="outline" size="sm">
                <Settings className="h-4 w-4 mr-2" />
                Edit Profile
              </Button>
            </div>
          </div>

          {/* XP Progress */}
          <div className="mt-4">
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-muted-foreground">Progress to Level {stats.level + 1}</span>
              <span className="text-cyan-400">{Math.round(xpProgress)}%</span>
            </div>
            <Progress value={xpProgress} className="h-2" />
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="border-cyan-500/20 bg-gradient-to-br from-cyan-500/5 to-transparent">
            <CardHeader className="pb-3">
              <CardDescription className="flex items-center gap-2">
                <Zap className="h-4 w-4 text-cyan-400" />
                Games Completed
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-cyan-400">{stats.totalGamesCompleted}</div>
            </CardContent>
          </Card>

          <Card className="border-green-500/20 bg-gradient-to-br from-green-500/5 to-transparent">
            <CardHeader className="pb-3">
              <CardDescription className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-green-400" />
                Skills Earned
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-400">{stats.totalSkillsEarned}</div>
            </CardContent>
          </Card>

          <Card className="border-yellow-500/20 bg-gradient-to-br from-yellow-500/5 to-transparent">
            <CardHeader className="pb-3">
              <CardDescription className="flex items-center gap-2">
                <Award className="h-4 w-4 text-yellow-400" />
                Credentials
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-yellow-400">{stats.totalCredentials}</div>
            </CardContent>
          </Card>

          <Card className="border-purple-500/20 bg-gradient-to-br from-purple-500/5 to-transparent">
            <CardHeader className="pb-3">
              <CardDescription className="flex items-center gap-2">
                <Users className="h-4 w-4 text-purple-400" />
                Network
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-400">Coming Soon</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="skills" className="space-y-6">
          <TabsList className="bg-card/50 border border-border/50">
            <TabsTrigger value="skills">Skill Tree</TabsTrigger>
            <TabsTrigger value="games">Game Arcade</TabsTrigger>
            <TabsTrigger value="credentials">Credentials</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
          </TabsList>

          <TabsContent value="skills" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {skillScores.map((category) => {
                const Icon = categoryIcons[category.categoryId] || Brain
                const colorClass = categoryColors[category.categoryId] || categoryColors.cognitive

                return (
                  <Card key={category.categoryId} className={`border ${colorClass.split(" ")[2]}`}>
                    <CardHeader className="pb-3">
                      <div className="flex items-center gap-2 mb-2">
                        <Icon className={`h-5 w-5 ${colorClass.split(" ")[0]}`} />
                        <CardTitle className="text-lg">{category.categoryName}</CardTitle>
                      </div>
                      <CardDescription>{category.skillCount} skills earned</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div>
                        <div className="flex items-center justify-between text-sm mb-1">
                          <span className="text-muted-foreground">Average Level</span>
                          <span className={`font-bold ${colorClass.split(" ")[0]}`}>
                            {category.avgLevel.toFixed(1)}
                          </span>
                        </div>
                        <Progress value={category.avgLevel * 20} className="h-2" />
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Total XP</span>
                        <span className={`font-bold ${colorClass.split(" ")[0]}`}>
                          {category.totalXp.toLocaleString()}
                        </span>
                      </div>
                      <Button variant="outline" size="sm" className="w-full mt-2 bg-transparent">
                        View Skills
                      </Button>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </TabsContent>

          <TabsContent value="games">
            <Card>
              <CardHeader>
                <CardTitle>HRM Game Arcade</CardTitle>
                <CardDescription>12 professional skill-building games available</CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full sm:w-auto">Browse All Games</Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="credentials">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {credentials.map((cred) => (
                <Card key={cred.id} className="border-yellow-500/20">
                  <CardHeader>
                    <div className="flex items-center gap-2 mb-2">
                      <Award className="h-5 w-5 text-yellow-400" />
                      <Badge variant="outline" className="text-xs">
                        {cred.credential_type}
                      </Badge>
                    </div>
                    <CardTitle className="text-lg">{cred.title}</CardTitle>
                    <CardDescription>{cred.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-xs text-muted-foreground">
                      Issued by {cred.issuer} • {new Date(cred.issue_date).toLocaleDateString()}
                    </div>
                  </CardContent>
                </Card>
              ))}
              {credentials.length === 0 && (
                <Card className="col-span-full">
                  <CardContent className="py-12 text-center text-muted-foreground">
                    No credentials earned yet. Complete games to earn your first credential!
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="activity">
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Your skill-building journey</CardDescription>
              </CardHeader>
              <CardContent>
                {recentActivity.length > 0 ? (
                  <div className="space-y-3">
                    {recentActivity.map((activity) => (
                      <div
                        key={activity.id}
                        className="flex items-start gap-3 p-3 rounded-lg border border-border/50 bg-card/30"
                      >
                        <Zap className="h-5 w-5 text-cyan-400 mt-0.5" />
                        <div className="flex-1">
                          <div className="font-medium">{activity.game?.title || "Game Activity"}</div>
                          <div className="text-sm text-muted-foreground">
                            {activity.status === "completed" ? "Completed" : "In Progress"} •{" "}
                            {activity.lastPlayed && new Date(activity.lastPlayed).toLocaleDateString()}
                          </div>
                        </div>
                        <Badge variant="outline">{activity.best_score} pts</Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="py-12 text-center text-muted-foreground">
                    No activity yet. Start playing games to build your skill passport!
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
