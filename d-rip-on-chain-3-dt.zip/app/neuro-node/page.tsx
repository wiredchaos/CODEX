import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { NeuroNodeDashboard } from "./neuro-node-dashboard"

export default async function NeuroNodePage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  return <NeuroNodeDashboard />
}
