"use client"

import { useState } from "react"
import { TOWER_FLOORS } from "@/lib/pos/config"
import { Building2, Lock } from "lucide-react"
import { cn } from "@/lib/utils"

export default function WorldPage() {
  const [selectedFloor, setSelectedFloor] = useState<string | null>(null)

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-zinc-900 rounded-full mb-4">
            <Building2 className="w-5 h-5 text-cyan-400" />
            <span className="text-sm text-zinc-400">3D WORLD</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold mb-4">
            POS <span className="text-red-500">TOWER</span>
          </h1>
          <p className="text-xl text-zinc-400 max-w-2xl mx-auto">
            Explore the headquarters of Proof of Stream. Visit newsrooms, radio lofts, and the executive penthouse.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* 3D Viewport placeholder */}
          <div className="aspect-square bg-zinc-900 rounded-2xl border border-zinc-800 flex items-center justify-center">
            <div className="text-center p-8">
              <div className="w-24 h-24 mx-auto mb-6 bg-gradient-to-b from-zinc-700 to-zinc-900 rounded-lg relative">
                {/* Simple tower representation */}
                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-16 h-20 bg-gradient-to-b from-zinc-600 to-zinc-800 rounded-t-lg" />
                <div className="absolute bottom-20 left-1/2 -translate-x-1/2 w-12 h-16 bg-gradient-to-b from-zinc-500 to-zinc-700 rounded-t-lg" />
                <div className="absolute bottom-36 left-1/2 -translate-x-1/2 w-8 h-8 bg-gradient-to-b from-red-600 to-red-800 rounded-t-lg" />
                <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-1 h-6 bg-red-500" />
              </div>
              <p className="text-zinc-400 mb-2">three.js / WebGL viewport</p>
              <p className="text-sm text-zinc-600">
                Full 3D environment with city skyline,
                <br />
                interactive floors, and AR/VR export
              </p>
            </div>
          </div>

          {/* Floor selector */}
          <div className="space-y-4">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Building2 className="w-5 h-5 text-zinc-400" />
              Tower Floors
            </h2>

            <div className="space-y-2">
              {TOWER_FLOORS.slice()
                .reverse()
                .map((floor) => (
                  <button
                    key={floor.id}
                    onClick={() => setSelectedFloor(floor.id)}
                    disabled={!floor.accessible}
                    className={cn(
                      "w-full p-4 rounded-xl border text-left transition-all",
                      selectedFloor === floor.id
                        ? "bg-cyan-500/10 border-cyan-500/50"
                        : floor.accessible
                          ? "bg-zinc-900/50 border-zinc-800 hover:border-zinc-700"
                          : "bg-zinc-950/50 border-zinc-900 opacity-50 cursor-not-allowed",
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div
                          className={cn(
                            "w-10 h-10 rounded-lg flex items-center justify-center text-sm font-bold",
                            floor.id.includes("BWB")
                              ? "bg-red-500/20 text-red-400"
                              : floor.id.includes("FM33")
                                ? "bg-cyan-500/20 text-cyan-400"
                                : floor.id.includes("PENTHOUSE")
                                  ? "bg-yellow-500/20 text-yellow-400"
                                  : "bg-zinc-800 text-zinc-400",
                          )}
                        >
                          L{floor.level}
                        </div>
                        <div>
                          <h3 className="font-semibold text-white">{floor.name}</h3>
                          <p className="text-sm text-zinc-500">{floor.description}</p>
                        </div>
                      </div>
                      {!floor.accessible && <Lock className="w-4 h-4 text-zinc-600" />}
                    </div>
                  </button>
                ))}
            </div>
          </div>
        </div>

        {/* Selected floor detail */}
        {selectedFloor && (
          <div className="mt-8 p-6 bg-zinc-900/50 rounded-2xl border border-zinc-800">
            <h3 className="text-xl font-bold text-white mb-4">
              {TOWER_FLOORS.find((f) => f.id === selectedFloor)?.name}
            </h3>
            <p className="text-zinc-400 mb-4">{TOWER_FLOORS.find((f) => f.id === selectedFloor)?.description}</p>
            <button className="px-5 py-2.5 bg-cyan-500 hover:bg-cyan-600 text-black font-semibold rounded-lg transition-colors">
              Enter Floor (Coming Soon)
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
