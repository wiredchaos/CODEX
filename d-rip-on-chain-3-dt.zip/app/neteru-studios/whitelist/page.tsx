import { StudioHeader } from "@/components/neteru/studio-header"
import { WLSubmissionForm } from "@/components/neteru/wl-submission-form"
import { ProfileCard } from "@/components/neteru/profile-card"
import { GlitchText } from "@/components/neteru/glitch-text"
import Link from "next/link"

export default function WhitelistPage() {
  return (
    <div className="min-h-screen bg-[#0A0A0A] text-zinc-100">
      <StudioHeader />

      <section className="container mx-auto px-4 py-12 max-w-xl">
        <div className="text-center mb-8">
          <GlitchText text="VRG33589 WHITELIST PORTAL" as="h1" className="text-2xl font-bold text-amber-400" />
          <p className="text-zinc-500 mt-2">Submit your assembled key sequence</p>
        </div>

        <div className="space-y-6">
          <ProfileCard />
          <WLSubmissionForm />
        </div>

        <div className="mt-8 text-center space-y-4">
          <Link
            href="/neteru-studios/clues"
            className="inline-block text-amber-400 hover:text-amber-300 text-sm font-mono"
          >
            ← NEED TO FIND CLUES?
          </Link>
        </div>
      </section>
    </div>
  )
}
