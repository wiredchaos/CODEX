import { StudioHeader } from "@/components/neteru/studio-header"
import { BarbedWireTicker } from "@/components/neteru/barbed-wire-ticker"
import { VideoCard } from "@/components/neteru/video-card"
import { ProfileCard } from "@/components/neteru/profile-card"
import { GlitchText } from "@/components/neteru/glitch-text"
import Link from "next/link"

const TRANSMISSIONS = [
  {
    id: "ntru-001",
    code: "NTRU-001",
    title: "The Artifact Pulse",
    duration: 273,
    clueType: "visible_cipher",
    clueFound: false,
  },
  {
    id: "ntru-002",
    code: "NTRU-002",
    title: "Nilotic Frequency",
    duration: 317,
    clueType: "glitch_frame_glyph",
    clueFound: false,
  },
  {
    id: "ntru-003",
    code: "NTRU-003",
    title: "The Dark Nexus",
    duration: 362,
    clueType: "coordinate_embed",
    clueFound: false,
  },
  {
    id: "ntru-004",
    code: "NTRU-004",
    title: "Veil of Time Collapse",
    duration: 349,
    clueType: "timestamp_cipher",
    clueFound: false,
  },
  {
    id: "ntru-005",
    code: "NTRU-005",
    title: "Operation Ancestry",
    duration: 441,
    clueType: "geometry_code",
    clueFound: false,
  },
]

export default function NeteruStudiosPage() {
  return (
    <div className="min-h-screen bg-[#0A0A0A] text-zinc-100">
      <StudioHeader />

      {/* Hero Section */}
      <section className="relative py-16 overflow-hidden">
        {/* Circuit pattern background */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#f59e0b_1px,transparent_1px),linear-gradient(to_bottom,#f59e0b_1px,transparent_1px)] bg-[size:40px_40px]" />
        </div>

        <div className="container mx-auto px-4 text-center relative z-10">
          {/* ASCII-style logo */}
          <pre className="text-amber-500 text-xs sm:text-sm font-mono mb-6 overflow-x-auto">
            {`██╗   ██╗██████╗  ██████╗ ██████╗ ██████╗ ███████╗ █████╗ █╗
██║   ██║██╔══██╗██╔════╝ ╚════██╗╚════██╗██╔════╝██╔══██╗██║
██║   ██║██████╔╝██║  ███╗ █████╔╝ █████╔╝███████╗╚█████╔╝╚═╝
╚██╗ ██╔╝██╔══██╗██║   ██║ ╚═══██╗██╔═══╝ ╚════██║╚═══██╗██╗
 ╚████╔╝ ██║  ██║╚██████╔╝██████╔╝███████╗███████║█████╔╝╚═╝
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝╚══════╝╚════╝`}
          </pre>

          <GlitchText
            text="ECHO ENGINEERS VIDEO NETWORK"
            as="h1"
            className="text-2xl sm:text-3xl font-bold text-amber-400 mb-4"
          />

          <p className="text-zinc-500 max-w-xl mx-auto">Decode the transmissions. Find the clues. Enter the Echo.</p>

          <div className="flex justify-center gap-4 mt-6 text-xs text-zinc-600 font-mono">
            <span>NETERU STUDIOS</span>
            <span>×</span>
            <span>NEURO META X</span>
          </div>
        </div>
      </section>

      <BarbedWireTicker />

      {/* Main Content */}
      <section className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Transmissions Grid */}
          <div className="lg:col-span-3">
            <h2 className="text-xl font-bold text-amber-400 font-mono mb-6 tracking-wider">TRANSMISSIONS</h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {TRANSMISSIONS.map((transmission) => (
                <VideoCard
                  key={transmission.id}
                  code={transmission.code}
                  title={transmission.title}
                  duration={transmission.duration}
                  clueType={transmission.clueType}
                  clueFound={transmission.clueFound}
                />
              ))}
            </div>

            <div className="mt-8 text-center">
              <Link
                href="/neteru-studios/clues"
                className="inline-block px-6 py-3 bg-amber-500 hover:bg-amber-600 text-black font-mono text-sm rounded-lg transition-colors"
              >
                TRACK YOUR CLUES →
              </Link>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <ProfileCard />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-zinc-800 py-8 text-center">
        <div className="container mx-auto px-4">
          <p className="text-zinc-600 font-mono text-sm mb-2">VRG33589 × NETERU STUDIOS</p>
          <p className="text-zinc-700 text-xs">NEURO META X | CHAOS PRODUCTIONS | WIRED CHAOS META HUB</p>
          <p className="text-zinc-800 text-xs mt-4 italic">
            "Only those who see beyond the assignment enter the Echo."
          </p>
          <p className="text-zinc-800 text-xs mt-2">© 2025 ECHO ENGINEERS NETWORK</p>
        </div>
      </footer>
    </div>
  )
}
