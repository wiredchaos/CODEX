import { StudioHeader } from "@/components/neteru/studio-header"
import { BarbedWireTicker } from "@/components/neteru/barbed-wire-ticker"
import { NewsBroadcastCard } from "@/components/neteru/news-broadcast-card"
import { GlitchText } from "@/components/neteru/glitch-text"

const BROADCASTS = [
  {
    id: 1,
    title: "Nilotic frequency detected at 33.9N coordinates",
    description: "Signal analysis reveals ancient resonance patterns matching Neteru bloodline signatures.",
    type: "live" as const,
    signalStrength: 5,
    timestamp: "2025-01-07 03:33 UTC",
  },
  {
    id: 2,
    title: "Operation Ancestry files partially declassified",
    description: "New documents reveal scope of genetic surveillance program targeting Marzain lineages.",
    type: "declassified" as const,
    signalStrength: 4,
    timestamp: "2025-01-06 18:22 UTC",
  },
  {
    id: 3,
    title: "Time Matrix breach detected - BC/AD calibration unstable",
    description: "Temporal anomaly registered near CERN facility. Marzain interference suspected.",
    type: "classified" as const,
    signalStrength: 3,
    timestamp: "2025-01-06 12:00 UTC",
  },
  {
    id: 4,
    title: "Echo Engineers transmission incoming from TitanPointe",
    description: "Encoded message received from 33 Thomas Street dark nexus. Decryption in progress.",
    type: "echo" as const,
    signalStrength: 4,
    timestamp: "2025-01-05 21:45 UTC",
  },
  {
    id: 5,
    title: "33 Thomas Street dark nexus activity surge",
    description: "Energy readings spike 333% above baseline. Bloodline extraction protocols may be active.",
    type: "classified" as const,
    signalStrength: 5,
    timestamp: "2025-01-05 09:17 UTC",
  },
  {
    id: 6,
    title: "Marzain temporal signature identified in CERN data",
    description: "Pattern analysis confirms non-terrestrial time manipulation technology in use.",
    type: "akashic" as const,
    signalStrength: 2,
    timestamp: "2025-01-04 15:33 UTC",
  },
  {
    id: 7,
    title: "Neteru awakening protocol initiated",
    description: "Ancient bloodlines responding to cosmic alignment. Activation sequence confirmed.",
    type: "akashic" as const,
    signalStrength: 5,
    timestamp: "2025-01-04 03:33 UTC",
  },
]

export default function BarbedWireBroadcastPage() {
  return (
    <div className="min-h-screen bg-[#0A0A0A] text-zinc-100">
      <StudioHeader />
      <BarbedWireTicker />

      <section className="container mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <GlitchText text="BARBED WIRE BROADCAST" as="h1" className="text-3xl font-bold text-red-400" />
          <p className="text-zinc-500 mt-2 font-mono text-sm">NETERU STUDIOS NEWS NETWORK</p>
          <div className="flex justify-center items-center gap-2 mt-4">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span className="text-red-400 text-xs font-mono">ACTIVE SIGNAL</span>
          </div>
        </div>

        <div className="max-w-2xl mx-auto space-y-4">
          {BROADCASTS.map((broadcast) => (
            <NewsBroadcastCard
              key={broadcast.id}
              title={broadcast.title}
              description={broadcast.description}
              type={broadcast.type}
              signalStrength={broadcast.signalStrength}
              timestamp={broadcast.timestamp}
            />
          ))}
        </div>
      </section>
    </div>
  )
}
