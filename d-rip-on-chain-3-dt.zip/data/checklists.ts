// User-facing checklists for DIY workflow

export interface ChecklistItem {
  id: string
  title: string
  description: string
  order: number
  category: "setup" | "round1" | "round2" | "round3" | "ongoing"
}

export const DIY_CHECKLIST: ChecklistItem[] = [
  // SETUP PHASE
  {
    id: "setup-1",
    title: "Complete Credit Profile",
    description: "Fill out your credit assessment with accurate information about your current situation.",
    order: 1,
    category: "setup",
  },
  {
    id: "setup-2",
    title: "Upload ID Documents",
    description: "Upload a copy of your government ID and proof of address for dispute letters.",
    order: 2,
    category: "setup",
  },
  {
    id: "setup-3",
    title: "Review Your Credit Reports",
    description: "Obtain and review your credit reports from all three bureaus.",
    order: 3,
    category: "setup",
  },
  {
    id: "setup-4",
    title: "Identify Negative Items",
    description: "List all collections, late payments, and other negative items to dispute.",
    order: 4,
    category: "setup",
  },

  // ROUND 1
  {
    id: "round1-1",
    title: "Generate First Dispute Letters",
    description: "Use the dispute engine to create your first round of 609/611 letters.",
    order: 5,
    category: "round1",
  },
  {
    id: "round1-2",
    title: "Download & Review Letters",
    description: "Review generated letters for accuracy before sending.",
    order: 6,
    category: "round1",
  },
  {
    id: "round1-3",
    title: "Mail Letters via Certified Mail",
    description: "Send letters to bureaus via certified mail with return receipt.",
    order: 7,
    category: "round1",
  },
  {
    id: "round1-4",
    title: "Log Tracking Numbers",
    description: "Record all tracking numbers and mail dates in your document vault.",
    order: 8,
    category: "round1",
  },
  {
    id: "round1-5",
    title: "Wait for Bureau Response",
    description: "Bureaus have 30-45 days to investigate and respond.",
    order: 9,
    category: "round1",
  },

  // ROUND 2
  {
    id: "round2-1",
    title: "Review Bureau Responses",
    description: "Analyze responses and identify items needing further dispute.",
    order: 10,
    category: "round2",
  },
  {
    id: "round2-2",
    title: "Generate Follow-Up Letters",
    description: "Create second round letters for unresolved items.",
    order: 11,
    category: "round2",
  },
  {
    id: "round2-3",
    title: "Send Direct Creditor Disputes",
    description: "Use 623 letters to dispute directly with furnishers.",
    order: 12,
    category: "round2",
  },

  // ONGOING
  {
    id: "ongoing-1",
    title: "Monitor Credit Reports Monthly",
    description: "Check for changes and new items monthly.",
    order: 13,
    category: "ongoing",
  },
  {
    id: "ongoing-2",
    title: "Document All Communications",
    description: "Keep records of all correspondence in your vault.",
    order: 14,
    category: "ongoing",
  },
]

export function getChecklistByCategory(category: ChecklistItem["category"]): ChecklistItem[] {
  return DIY_CHECKLIST.filter((item) => item.category === category).sort((a, b) => a.order - b.order)
}
