import type { BootcampModule, BootcampCategory } from "@/lib/credit-repair/types"

export const BOOTCAMP_MODULES: BootcampModule[] = [
  // ENTITY CATEGORY
  {
    id: "mod-entity-1",
    slug: "choose-entity-type",
    title: "Choose the Right Entity Type",
    description: "Learn which business structure best protects your assets and optimizes tax strategy",
    order: 1,
    category: "ENTITY",
    enabled: true,
    summary: "Understand the differences between LLCs, S-Corps, C-Corps, and Sole Proprietorships.",
    learningObjectives: [
      "Identify the 4 main business entity types",
      "Understand liability protection differences",
      "Learn tax implications of each structure",
      "Choose the optimal entity for your goals",
    ],
    sections: [
      {
        title: "Overview of Business Entities",
        body: "When building business credit, your entity type matters significantly...",
      },
      {
        title: "LLC Deep Dive",
        body: "Limited Liability Companies (LLCs) offer flexibility and protection...",
      },
    ],
    estimatedMinutes: 45,
  },
  {
    id: "mod-entity-2",
    slug: "ein-operating-agreement",
    title: "EIN & Operating Agreement Basics",
    description: "Establish your business identity with proper documentation",
    order: 2,
    category: "ENTITY",
    enabled: true,
    summary: "Learn how to obtain your EIN and create a compliant operating agreement.",
    learningObjectives: [
      "Apply for an EIN correctly",
      "Draft a professional operating agreement",
      "Understand why these documents matter for credit",
      "Avoid common mistakes",
    ],
    sections: [
      {
        title: "What is an EIN?",
        body: "An Employer Identification Number (EIN) is your business Social Security Number...",
      },
      { title: "Operating Agreement Essentials", body: "Even single-member LLCs need an operating agreement..." },
    ],
    estimatedMinutes: 30,
  },

  // BANKING CATEGORY
  {
    id: "mod-banking-1",
    slug: "business-bank-setup",
    title: "Business Bank Account Setup",
    description: "Open the right accounts to build your financial foundation",
    order: 3,
    category: "BANKING",
    enabled: true,
    summary: "Choose and open business bank accounts that support credit building.",
    learningObjectives: [
      "Compare business banking options",
      "Open checking and savings accounts",
      "Set up proper record-keeping",
      "Understand bank reference requirements",
    ],
    sections: [
      {
        title: "Why Business Banking Matters",
        body: "Separate business banking is non-negotiable for credit building...",
      },
      { title: "Choosing Your Bank", body: "Consider these factors when selecting a bank..." },
    ],
    estimatedMinutes: 35,
  },
  {
    id: "mod-banking-2",
    slug: "bank-compliance",
    title: "Bank Compliance & Red Flags",
    description: "Avoid account closures and maintain good standing",
    order: 4,
    category: "BANKING",
    enabled: true,
    summary: "Understand what triggers bank reviews and how to maintain accounts.",
    learningObjectives: [
      "Identify common compliance triggers",
      "Maintain healthy account activity",
      "Respond to bank requests properly",
      "Protect your banking relationships",
    ],
    sections: [
      { title: "Common Red Flags", body: "Banks monitor for suspicious activity..." },
      { title: "Best Practices", body: "Maintain healthy accounts..." },
    ],
    estimatedMinutes: 25,
  },

  // VENDORS CATEGORY
  {
    id: "mod-vendors-1",
    slug: "tier-1-vendors",
    title: "Tier 1 Net-30 Vendors",
    description: "Establish your first tradelines with starter vendors",
    order: 5,
    category: "VENDORS",
    enabled: true,
    summary: "Apply with vendors that approve new businesses and report to bureaus.",
    learningObjectives: [
      "Identify reporting vendors",
      "Complete applications correctly",
      "Use accounts strategically",
      "Build initial tradelines",
    ],
    sections: [
      { title: "What Are Tier 1 Vendors?", body: "Tier 1 vendors extend Net-30 terms to new businesses..." },
      { title: "Top Starter Vendors", body: "Proven Tier 1 vendors include..." },
    ],
    estimatedMinutes: 40,
  },
  {
    id: "mod-vendors-2",
    slug: "reporting-cycles",
    title: "Reporting Cycles & Paydex",
    description: "Understand how payment behavior affects your scores",
    order: 6,
    category: "VENDORS",
    enabled: true,
    summary: "Learn how vendors report and optimize payment timing.",
    learningObjectives: [
      "Understand Paydex scoring",
      "Time payments strategically",
      "Monitor credit reports",
      "Dispute errors effectively",
    ],
    sections: [
      { title: "The Paydex Score", body: "Dun & Bradstreet Paydex score ranges from 1-100..." },
      { title: "Reporting Timeline", body: "Vendors typically report monthly to D&B..." },
    ],
    estimatedMinutes: 30,
  },

  // BUSINESS CREDIT CATEGORY
  {
    id: "mod-credit-1",
    slug: "fundability-profile",
    title: "Fundability Profile",
    description: "Optimize your business presentation for lenders",
    order: 7,
    category: "BUSINESS_CREDIT",
    enabled: true,
    summary: "Ensure your business meets all fundability factors.",
    learningObjectives: [
      "Complete fundability checklist",
      "Optimize online presence",
      "Align credentials properly",
      "Present professional image",
    ],
    sections: [
      { title: "The Fundability Foundation", body: "Lenders evaluate your complete business profile..." },
      { title: "Alignment Matters", body: "Consistency across all platforms..." },
    ],
    estimatedMinutes: 35,
  },
  {
    id: "mod-credit-2",
    slug: "business-vs-personal",
    title: "Business Credit vs Personal Credit",
    description: "Understand the critical differences and protections",
    order: 8,
    category: "BUSINESS_CREDIT",
    enabled: true,
    summary: "Learn how business credit works differently from personal credit.",
    learningObjectives: [
      "Differentiate scoring systems",
      "Understand liability separation",
      "Leverage business credit advantages",
      "Protect personal credit",
    ],
    sections: [
      { title: "Key Differences", body: "Business Credit uses different scoring models..." },
      { title: "The Separation Goal", body: "Ultimate goal: Business credit without personal guarantee..." },
    ],
    estimatedMinutes: 30,
  },

  // FUNDING CATEGORY
  {
    id: "mod-funding-1",
    slug: "funding-stacking",
    title: "Funding Stacking Basics",
    description: "Learn the strategy for maximizing available capital",
    order: 9,
    category: "FUNDING",
    enabled: true,
    summary: "Understand how to layer multiple funding sources strategically.",
    learningObjectives: [
      "Understand funding stack concept",
      "Identify timing strategies",
      "Avoid over-leverage",
      "Plan funding rounds",
    ],
    sections: [
      { title: "What is Funding Stacking?", body: "Funding stacking involves applying for multiple credit sources..." },
      { title: "The Stack Order", body: "Optimal sequence for applications..." },
    ],
    estimatedMinutes: 40,
  },
  {
    id: "mod-funding-2",
    slug: "lender-preparation",
    title: "Preparing for Lender Applications",
    description: "Documentation and presentation for approval success",
    order: 10,
    category: "FUNDING",
    enabled: true,
    summary: "Assemble the documents needed for successful funding applications.",
    learningObjectives: [
      "Gather required documentation",
      "Prepare financial statements",
      "Create business plan summary",
      "Practice lender presentations",
    ],
    sections: [
      { title: "Documentation Checklist", body: "Have these documents ready..." },
      { title: "Presentation Tips", body: "When speaking with lenders..." },
    ],
    estimatedMinutes: 45,
  },
]

export function getModuleBySlug(slug: string): BootcampModule | undefined {
  return BOOTCAMP_MODULES.find((m) => m.slug === slug)
}

export function getModulesByCategory(category: BootcampCategory): BootcampModule[] {
  return BOOTCAMP_MODULES.filter((m) => m.category === category).sort((a, b) => a.order - b.order)
}

export function getAllModules(): BootcampModule[] {
  return [...BOOTCAMP_MODULES].sort((a, b) => a.order - b.order)
}
