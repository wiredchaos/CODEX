import type { DisputeLetterTemplate, LetterType } from "@/lib/credit-repair/types"

export const DISPUTE_LETTER_TEMPLATES: Record<LetterType, DisputeLetterTemplate> = {
  "609_DISPUTE": {
    id: "609_DISPUTE",
    label: "609 Dispute Letter",
    description: "Request verification of account information under FCRA Section 609",
    target: "BUREAU",
    requiredPlaceholders: [
      "fullName",
      "address",
      "city",
      "state",
      "zip",
      "ssn4",
      "dob",
      "bureauName",
      "bureauAddress",
      "accountName",
      "accountNumber",
    ],
    bodyTemplate: `{{fullName}}
{{address}}
{{city}}, {{state}} {{zip}}

Date: {{currentDate}}

{{bureauName}}
{{bureauAddress}}

Re: Request for Verification Under FCRA Section 609

To Whom It May Concern:

I am writing to request verification of the following account(s) appearing on my credit report pursuant to my rights under the Fair Credit Reporting Act, Section 609.

Account Name: {{accountName}}
Account Number: {{accountNumber}}

Under Section 609 of the FCRA, I have the right to request verification of all information in my credit file. Please provide:

1. The original signed contract or agreement bearing my signature
2. Complete payment history for this account
3. Verification that this account belongs to me
4. Proof that you have the legal authority to report this information

If you cannot provide the above documentation within 30 days, this account must be immediately deleted from my credit report per FCRA requirements.

Please send verification to the address above.

Sincerely,

{{fullName}}
SSN: XXX-XX-{{ssn4}}
DOB: {{dob}}`,
  },

  "611_REINVESTIGATION": {
    id: "611_REINVESTIGATION",
    label: "611 Reinvestigation Request",
    description: "Demand a reinvestigation of disputed items under FCRA Section 611",
    target: "BUREAU",
    requiredPlaceholders: [
      "fullName",
      "address",
      "city",
      "state",
      "zip",
      "ssn4",
      "dob",
      "bureauName",
      "bureauAddress",
      "accountName",
      "accountNumber",
      "disputeReason",
    ],
    bodyTemplate: `{{fullName}}
{{address}}
{{city}}, {{state}} {{zip}}

Date: {{currentDate}}

{{bureauName}}
{{bureauAddress}}

Re: Demand for Reinvestigation Under FCRA Section 611

To Whom It May Concern:

I am disputing the following information in my credit file and demanding a reinvestigation under Section 611 of the Fair Credit Reporting Act.

Account Name: {{accountName}}
Account Number: {{accountNumber}}
Reason for Dispute: {{disputeReason}}

Under Section 611 of the FCRA, you are required to:

1. Conduct a reasonable reinvestigation of the disputed information
2. Forward all relevant information to the furnisher
3. Review and consider all information submitted by the consumer
4. Complete the investigation within 30 days

If you cannot verify this information through your reinvestigation, it must be deleted from my credit report immediately.

I expect written notification of the results of your reinvestigation within the required timeframe.

Sincerely,

{{fullName}}
SSN: XXX-XX-{{ssn4}}
DOB: {{dob}}`,
  },

  "623_DIRECT_DISPUTE": {
    id: "623_DIRECT_DISPUTE",
    label: "623 Direct Dispute to Furnisher",
    description: "Dispute directly with the creditor/furnisher under FCRA Section 623",
    target: "CREDITOR",
    requiredPlaceholders: [
      "fullName",
      "address",
      "city",
      "state",
      "zip",
      "ssn4",
      "creditorName",
      "creditorAddress",
      "accountNumber",
      "disputeReason",
    ],
    bodyTemplate: `{{fullName}}
{{address}}
{{city}}, {{state}} {{zip}}

Date: {{currentDate}}

{{creditorName}}
{{creditorAddress}}

Re: Direct Dispute Under FCRA Section 623

To Whom It May Concern:

I am writing to dispute information your company has furnished to the credit reporting agencies regarding my account.

Account Number: {{accountNumber}}
Reason for Dispute: {{disputeReason}}

Under Section 623 of the Fair Credit Reporting Act, as a furnisher of information, you have a duty to:

1. Investigate disputes forwarded by credit bureaus
2. Report only accurate and complete information
3. Correct or delete inaccurate, incomplete, or unverifiable information

I request that you immediately investigate this matter and correct the information reported to all credit bureaus. If you cannot verify the accuracy of this information, you must delete it.

Please respond within 30 days with the results of your investigation.

Sincerely,

{{fullName}}
SSN: XXX-XX-{{ssn4}}`,
  },

  DEBT_VALIDATION: {
    id: "DEBT_VALIDATION",
    label: "Debt Validation Letter",
    description: "Request debt validation from collection agency under FDCPA",
    target: "COLLECTION_AGENCY",
    requiredPlaceholders: [
      "fullName",
      "address",
      "city",
      "state",
      "zip",
      "collectorName",
      "collectorAddress",
      "accountNumber",
      "amount",
    ],
    bodyTemplate: `{{fullName}}
{{address}}
{{city}}, {{state}} {{zip}}

Date: {{currentDate}}

{{collectorName}}
{{collectorAddress}}

Re: Debt Validation Request - Account {{accountNumber}}

To Whom It May Concern:

I am writing in response to your contact regarding the above-referenced account. This is not a refusal to pay, but a request for validation of this debt pursuant to the Fair Debt Collection Practices Act (FDCPA), 15 USC 1692g.

Amount Claimed: {{amount}}

Please provide the following:

1. Proof that you are licensed to collect debts in my state
2. The name and address of the original creditor
3. A copy of the original signed contract or agreement
4. A complete payment history from the original creditor
5. Verification that this debt has not exceeded the statute of limitations
6. Proof that you own this debt or are authorized to collect on it

Until you provide this validation, you must cease all collection activities and remove any reporting from my credit reports.

I am aware of my rights under the FDCPA and will pursue all legal remedies if you continue collection activities without providing proper validation.

Sincerely,

{{fullName}}`,
  },

  CFPB_COMPLAINT_DRAFT: {
    id: "CFPB_COMPLAINT_DRAFT",
    label: "CFPB Complaint Draft",
    description: "Formal complaint to Consumer Financial Protection Bureau",
    target: "CFPB",
    requiredPlaceholders: [
      "fullName",
      "address",
      "city",
      "state",
      "zip",
      "companyName",
      "accountNumber",
      "issueDescription",
      "desiredResolution",
    ],
    bodyTemplate: `CFPB COMPLAINT SUBMISSION

Consumer Information:
Name: {{fullName}}
Address: {{address}}, {{city}}, {{state}} {{zip}}

Company Being Complained About:
{{companyName}}

Account Number: {{accountNumber}}

Issue Description:
{{issueDescription}}

Desired Resolution:
{{desiredResolution}}

Timeline of Events:
[To be completed by consumer with specific dates and actions taken]

Documents Attached:
[List all supporting documentation]

I certify that the information provided is true and accurate to the best of my knowledge.

Signature: {{fullName}}
Date: {{currentDate}}`,
  },

  CEASE_AND_DESIST: {
    id: "CEASE_AND_DESIST",
    label: "Cease and Desist Letter",
    description: "Demand collector stop all contact under FDCPA",
    target: "COLLECTION_AGENCY",
    requiredPlaceholders: [
      "fullName",
      "address",
      "city",
      "state",
      "zip",
      "collectorName",
      "collectorAddress",
      "accountNumber",
    ],
    bodyTemplate: `{{fullName}}
{{address}}
{{city}}, {{state}} {{zip}}

Date: {{currentDate}}

{{collectorName}}
{{collectorAddress}}

Re: CEASE AND DESIST - Account {{accountNumber}}

To Whom It May Concern:

Pursuant to my rights under the Fair Debt Collection Practices Act (FDCPA), 15 USC 1692c, I hereby demand that you cease all communication with me regarding the above-referenced account.

This letter serves as your legal notification to:

1. STOP all telephone calls to me, my family, and my workplace
2. STOP all written correspondence except as required by law
3. STOP all contact with third parties regarding this debt

Under the FDCPA, you may only contact me to:
- Notify me that collection efforts are being terminated
- Notify me that specific legal action may be taken (if true)

Any further communication beyond these exceptions will be considered harassment and may result in legal action against your company.

I will pursue all available legal remedies for any violation of this cease and desist notice.

Sincerely,

{{fullName}}

SENT VIA CERTIFIED MAIL - RETURN RECEIPT REQUESTED`,
  },

  INQUIRY_REMOVAL: {
    id: "INQUIRY_REMOVAL",
    label: "Inquiry Removal Request",
    description: "Request removal of unauthorized hard inquiries",
    target: "BUREAU",
    requiredPlaceholders: [
      "fullName",
      "address",
      "city",
      "state",
      "zip",
      "ssn4",
      "bureauName",
      "bureauAddress",
      "inquiryCompany",
      "inquiryDate",
    ],
    bodyTemplate: `{{fullName}}
{{address}}
{{city}}, {{state}} {{zip}}

Date: {{currentDate}}

{{bureauName}}
{{bureauAddress}}

Re: Unauthorized Inquiry Removal Request

To Whom It May Concern:

I am writing to dispute an unauthorized inquiry on my credit report. I did not authorize the following company to access my credit:

Company: {{inquiryCompany}}
Inquiry Date: {{inquiryDate}}

Under the Fair Credit Reporting Act, a permissible purpose is required to access consumer credit reports. I did not apply for credit with this company, nor did I authorize them to pull my credit.

Please investigate this inquiry and provide proof of my authorization. If you cannot provide written proof that I authorized this inquiry, please remove it from my credit report immediately.

Please send written confirmation of the deletion to the address above.

Sincerely,

{{fullName}}
SSN: XXX-XX-{{ssn4}}`,
  },

  MEDICAL_DEBT_HIPAA: {
    id: "MEDICAL_DEBT_HIPAA",
    label: "Medical Debt HIPAA Letter",
    description: "Challenge medical debt using HIPAA privacy violations",
    target: "COLLECTION_AGENCY",
    requiredPlaceholders: [
      "fullName",
      "address",
      "city",
      "state",
      "zip",
      "collectorName",
      "collectorAddress",
      "accountNumber",
      "medicalProvider",
    ],
    bodyTemplate: `{{fullName}}
{{address}}
{{city}}, {{state}} {{zip}}

Date: {{currentDate}}

{{collectorName}}
{{collectorAddress}}

Re: HIPAA Privacy Violation - Account {{accountNumber}}

To Whom It May Concern:

I am disputing the medical debt you are attempting to collect and challenging your possession of my protected health information (PHI).

Original Medical Provider: {{medicalProvider}}
Account Number: {{accountNumber}}

Under the Health Insurance Portability and Accountability Act (HIPAA), my medical information is protected. Please provide:

1. Proof of your HIPAA compliance status
2. A valid, signed HIPAA authorization form from me allowing disclosure
3. Your Business Associate Agreement with the original provider
4. Documentation showing proper chain of custody of my PHI

If you cannot provide proof that my health information was obtained in compliance with HIPAA regulations, you must:

1. Cease all collection activities immediately
2. Remove this debt from all credit bureau reporting
3. Destroy all copies of my protected health information

Failure to comply may result in complaints to the HHS Office for Civil Rights and legal action.

Sincerely,

{{fullName}}`,
  },

  REINSERTION_CHALLENGE: {
    id: "REINSERTION_CHALLENGE",
    label: "Reinsertion Challenge Letter",
    description: "Challenge the reinsertion of previously deleted accounts",
    target: "BUREAU",
    requiredPlaceholders: [
      "fullName",
      "address",
      "city",
      "state",
      "zip",
      "ssn4",
      "bureauName",
      "bureauAddress",
      "accountName",
      "accountNumber",
      "deletionDate",
    ],
    bodyTemplate: `{{fullName}}
{{address}}
{{city}}, {{state}} {{zip}}

Date: {{currentDate}}

{{bureauName}}
{{bureauAddress}}

Re: Illegal Reinsertion of Deleted Account

To Whom It May Concern:

I am writing to challenge the illegal reinsertion of an account that was previously deleted from my credit report.

Account Name: {{accountName}}
Account Number: {{accountNumber}}
Original Deletion Date: {{deletionDate}}

Under FCRA Section 611(a)(5)(B), reinserted information requires:

1. Certification that the information is accurate and complete
2. Written notification to the consumer within 5 business days

I did not receive the required notification before this account was reinserted. This is a clear violation of the Fair Credit Reporting Act.

I demand that you:
1. Immediately delete this account again
2. Provide proof of the required certification
3. Explain why proper notification was not provided

If this account is not removed within 15 days, I will file complaints with the CFPB and FTC, and pursue legal action for willful non-compliance.

Sincerely,

{{fullName}}
SSN: XXX-XX-{{ssn4}}`,
  },

  LATE_PAYMENT_GOODWILL: {
    id: "LATE_PAYMENT_GOODWILL",
    label: "Late Payment Goodwill Letter",
    description: "Request goodwill removal of late payment marks",
    target: "CREDITOR",
    requiredPlaceholders: [
      "fullName",
      "address",
      "city",
      "state",
      "zip",
      "creditorName",
      "creditorAddress",
      "accountNumber",
      "latePaymentDate",
      "explanation",
    ],
    bodyTemplate: `{{fullName}}
{{address}}
{{city}}, {{state}} {{zip}}

Date: {{currentDate}}

{{creditorName}}
{{creditorAddress}}

Re: Goodwill Late Payment Removal Request - Account {{accountNumber}}

Dear Customer Service Team:

I am writing to kindly request a goodwill adjustment to remove a late payment mark from my account history.

Account Number: {{accountNumber}}
Late Payment Date: {{latePaymentDate}}

I have been a loyal customer and have otherwise maintained an excellent payment history with your company. Unfortunately, I experienced the following situation that led to this late payment:

{{explanation}}

Since that time, I have taken steps to ensure this will not happen again and have maintained perfect payment history.

I understand that you are not obligated to make this adjustment, but I am hoping you will consider my request as a gesture of goodwill given my overall positive account history.

This late payment mark is significantly impacting my credit score and my ability to [purchase a home/refinance/etc.]. Removing this one mark would make a tremendous difference.

I greatly appreciate your consideration of this request.

Sincerely,

{{fullName}}`,
  },

  PAY_FOR_DELETE_PROPOSAL: {
    id: "PAY_FOR_DELETE_PROPOSAL",
    label: "Pay for Delete Proposal",
    description: "Offer payment in exchange for deletion from credit reports",
    target: "COLLECTION_AGENCY",
    requiredPlaceholders: [
      "fullName",
      "address",
      "city",
      "state",
      "zip",
      "collectorName",
      "collectorAddress",
      "accountNumber",
      "originalAmount",
      "offerAmount",
    ],
    bodyTemplate: `{{fullName}}
{{address}}
{{city}}, {{state}} {{zip}}

Date: {{currentDate}}

{{collectorName}}
{{collectorAddress}}

Re: Settlement and Deletion Proposal - Account {{accountNumber}}

To Whom It May Concern:

I am writing to propose a settlement of the above-referenced account.

Original Balance Claimed: {{originalAmount}}
My Settlement Offer: {{offerAmount}}

This offer is contingent upon the following conditions:

1. Full deletion of this account from all credit bureau reports (Experian, Equifax, TransUnion)
2. Written agreement on company letterhead before payment
3. Deletion to occur within 30 days of payment receipt

This is a settlement offer, not an acknowledgment of debt validity. I am making this offer to resolve this matter efficiently.

If you agree to these terms, please send a signed agreement to the address above. Upon receipt of your agreement, I will provide payment via [certified check/money order].

This offer expires in 15 days from the date of this letter.

Sincerely,

{{fullName}}

Note: Payment will not be made without written agreement to delete.`,
  },

  SETTLEMENT_OFFER: {
    id: "SETTLEMENT_OFFER",
    label: "Settlement Offer Letter",
    description: "Formal debt settlement offer",
    target: "COLLECTION_AGENCY",
    requiredPlaceholders: [
      "fullName",
      "address",
      "city",
      "state",
      "zip",
      "collectorName",
      "collectorAddress",
      "accountNumber",
      "originalAmount",
      "offerAmount",
    ],
    bodyTemplate: `{{fullName}}
{{address}}
{{city}}, {{state}} {{zip}}

Date: {{currentDate}}

{{collectorName}}
{{collectorAddress}}

Re: Settlement Offer - Account {{accountNumber}}

To Whom It May Concern:

I am writing to offer a settlement on the above-referenced account.

Balance Claimed: {{originalAmount}}
Settlement Offer: {{offerAmount}}

Settlement Terms:

1. This payment constitutes full and final satisfaction of this debt
2. You will report this account as "Paid in Full" or "Settled" to all credit bureaus
3. You will not sell or transfer this debt after settlement
4. You will provide written confirmation of settlement

This offer is valid for 30 days from the date of this letter. If accepted, please provide a written settlement agreement on company letterhead specifying the above terms.

Payment will be made via certified funds within 10 business days of receiving your signed agreement.

This offer is made without prejudice and is not an acknowledgment of debt validity.

Sincerely,

{{fullName}}`,
  },
}

export function getTemplate(type: LetterType): DisputeLetterTemplate {
  return DISPUTE_LETTER_TEMPLATES[type]
}

export function getAllTemplates(): DisputeLetterTemplate[] {
  return Object.values(DISPUTE_LETTER_TEMPLATES)
}

export function getTemplatesByTarget(target: DisputeLetterTemplate["target"]): DisputeLetterTemplate[] {
  return getAllTemplates().filter((t) => t.target === target)
}
