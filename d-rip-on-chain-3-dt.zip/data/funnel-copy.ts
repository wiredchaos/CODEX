// Marketing and CTA copy blocks for the DIY/DFY funnel

export const FUNNEL_COPY = {
  hero: {
    headline: "Credit Repair Swarm Bot",
    subheadline: "AI-powered credit repair that works while you sleep",
    description:
      "Generate dispute letters, track bureau responses, and build business credit — all in one intelligent platform.",
    ctaPrimary: "Start Free Assessment",
    ctaSecondary: "Log In",
  },

  diy: {
    title: "DIY Credit Repair",
    tagline: "Take control of your credit journey",
    features: [
      "AI-generated dispute letters (609, 611, 623)",
      "Step-by-step dispute tracking",
      "Bureau response management",
      "Business credit bootcamp access",
      "Document vault storage",
    ],
    price: "$47/month",
    cta: "Start DIY Plan",
  },

  dfy: {
    title: "Done-For-You Service",
    tagline: "Let our experts handle everything",
    features: [
      "Full credit analysis by certified specialists",
      "All disputes handled on your behalf",
      "Bureau correspondence management",
      "Monthly strategy calls",
      "Priority support",
      "Business credit building guidance",
    ],
    price: "$297/month",
    cta: "Get Started with DFY",
  },

  bootcamp: {
    title: "Business Credit Bootcamp",
    tagline: "Build fundable business credit from scratch",
    description: "Learn entity structuring, vendor credit, funding stacking, and more.",
    cta: "Explore Bootcamp",
  },

  trustSignals: [
    "FCRA Compliant Letters",
    "Bank-Level Encryption",
    "Thousands of Items Removed",
    "30-Day Money Back Guarantee",
  ],

  urgency: {
    headline: "Every Day Counts",
    body: "Negative items damage your credit score daily. Start your repair journey now and see improvements in as little as 30 days.",
  },

  faq: [
    {
      question: "How long does credit repair take?",
      answer:
        "Results vary, but most clients see their first deletions within 30-45 days. Complete repair typically takes 3-6 months depending on the complexity of your credit file.",
    },
    {
      question: "Is this legal?",
      answer:
        "Absolutely. Our dispute letters are based on your legal rights under the Fair Credit Reporting Act (FCRA) and Fair Debt Collection Practices Act (FDCPA).",
    },
    {
      question: "What's the difference between DIY and DFY?",
      answer:
        "DIY gives you the tools and guidance to dispute items yourself. DFY means our team handles everything — from analysis to correspondence to follow-up.",
    },
    {
      question: "Do you guarantee results?",
      answer:
        "We cannot guarantee specific results as every credit situation is unique. However, if you don't see any progress in 30 days, you can request a full refund.",
    },
  ],
}

export const UPGRADE_CTAS = {
  dashboardBanner: {
    headline: "Upgrade to Done-For-You",
    body: "Let our experts take over your credit repair. Save time and get results faster.",
    cta: "Learn More",
  },
  diyUpsell: {
    headline: "Feeling Overwhelmed?",
    body: "Our DFY team can handle all the work for you. Focus on your life while we fix your credit.",
    cta: "Switch to DFY",
  },
  bootcampUpsell: {
    headline: "Ready for Business Credit?",
    body: "Once your personal credit improves, business credit opens new opportunities.",
    cta: "Start Bootcamp",
  },
}
