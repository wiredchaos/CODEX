# HRM GAME SUITE + NEURO NODE ID

## Enterprise Professional Skills Network

**BUSINESS PATCH FIREWALL: Tier 1 - Corporate Grade**

This system is completely separated from Akashic lore, narrative worlds, and XRPL mythology. It operates exclusively within the WIRED CHAOS BUSINESS PATCH for enterprise compliance, HR audit compatibility, and legal defensibility.

---

## System Overview

### NEURO NODE ID
Professional skill passport and blockchain-backed credential system. Think LinkedIn meets gamified learning with verifiable on-chain credentials.

### HRM Game Suite
12 professional skill-building games across 6 core competency categories, designed for corporate onboarding, leadership development, and workforce training.

---

## Architecture

### Database Schema
- `neuro_node_profiles` - Professional identities
- `nn_skill_categories` - 6 core categories
- `nn_skills` - Individual skills within categories
- `nn_user_skills` - User progress and levels
- `hrm_games` - 12 game definitions
- `hrm_user_game_progress` - Game completion tracking
- `nn_credentials` - Badges, certificates, micro-credentials
- `hrm_company_configs` - Employer customization
- `nn_connections` - Professional network
- `nn_activity_feed` - Social feed for achievements

### 6 Skill Categories

1. **Cognitive Skills** - Problem solving, critical thinking, operational reasoning
2. **Emotional Intelligence** - Self-awareness, empathy, conflict resolution
3. **Leadership & Management** - Situational leadership, delegation, coaching
4. **Technical & Hard Skills** - Lean Sigma, SOPs, safety protocols, compliance
5. **Workplace Behaviors** - Communication, collaboration, time management
6. **Blockchain Literacy** - Smart contracts, digital credentials, decentralized HR

### 12 Core Games

1. **Emotional Compass Arena** - Navigate emotional scenarios and practice self-regulation
2. **Command Shift Simulator** - Practice situational leadership across team dynamics
3. **Balance Matrix** - Identify and develop hard and soft skills
4. **Sigma Dojo (White Belt)** - Learn Lean Six Sigma fundamentals
5. **Ledger of People** - Understand blockchain applications in HR
6. **Perspective Portal** - Develop empathy and inclusive thinking (DEI)
7. **Signal Synchronicity** - Master communication and active listening
8. **The Resilience Gauntlet** - Build stress management skills
9. **Safety Core** - Learn workplace safety and compliance
10. **Shift Navigator** - Practice change management
11. **Executive Labyrinth** - Develop strategic thinking and decision-making
12. **Virtual Colony** - Master remote work collaboration
13. **Priority Forge** - Optimize time management and prioritization

---

## Three-Tier Funnel

### DIY (Entry Level)
- Individuals play free games
- Earn badges and build NEURO NODE ID
- Companies use basic templates

### GUIDED
- Users get curated career path games
- Companies get custom onboarding arcades
- Leadership training becomes branded

### CONCIERGE
- Full corporate LMS integration
- XR retreat onboarding
- Workforce analytics dashboards
- HR compliance tracking
- Blockchain credential issuance for entire staff

---

## For Employers

### CBE Marketplace Integration
Employers can:
- Create custom onboarding arcades
- Buy additional training modules
- Assign games based on job roles
- Track employee progress
- Verify real-time skill profiles
- Use NEURO NODE IDs as hiring filters

### Employer Questionnaire
Captures:
- Industry & company size
- SOPs & org chart
- Company values
- Compliance needs
- Wellness priorities

### White-Label Capabilities
Every game auto-populates:
- Company name & logo
- Brand colors
- Leadership roles
- Department-specific content

---

## Security & Compliance

### Firewalls
- Business Patch isolation: `/patches/business/hrm_game_engine/`
- No cross-references to lore systems
- Separate NPC agents for business vs narrative
- Corporate branding (no cyberpunk/Akashic overlays)
- Employee data isolated from narrative systems

### Legal Protection
- HR compliance standards
- Anti-discrimination protocols
- Security/privacy guidelines
- Enterprise-grade audit trails
- GDPR/CCPA ready

---

## API Endpoints

- `GET /api/neuro-node/profile` - Fetch user profile
- `POST /api/neuro-node/profile` - Create profile
- `PUT /api/neuro-node/profile` - Update profile
- `GET /api/neuro-node/dashboard` - Dashboard data
- `GET /api/hrm/games` - List all games
- `GET /api/hrm/progress` - User game progress
- `POST /api/hrm/complete-game` - Mark game complete
- `GET /api/hrm/credentials` - User credentials

---

## UI Routes

- `/neuro-node` - Main dashboard (skill tree, games, credentials, activity)
- `/neuro-node/games` - Game arcade browser
- `/neuro-node/games/[id]` - Individual game player
- `/neuro-node/network` - Professional connections
- `/neuro-node/credentials` - Credential vault
- `/business/chaos-builder-exchange` - CBE marketplace integration

---

## Next Phase Components

### A. Employer Questionnaire (Typeform-ready)
### B. HRM Game Template JSON Schemas
### C. White-Label Mini-Game Arcade UI
### D. NPC + Swarm Agent Definitions
### E. Funnel + Pricing + BMC
### F. Blockchain Credential Schema

---

## Integration with Existing Systems

- **CBE (Chaos Builder Exchange)** - Employers buy training modules
- **VALORITHM™** - Skill valuations for sweat equity
- **Industry Generals (IGS)** - Sector-specific training paths
- **Credit Repair Swarm** - Financial literacy games (future)

---

## Status: Phase 1 Complete

Database schema deployed, core types defined, API endpoints created, dashboard UI built. Ready for game implementation and employer onboarding funnel.
