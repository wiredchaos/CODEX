# CHAOS BUILDER EXCHANGE — OFFICIAL BRAND KIT

## Color Palette

### Primary Colors (Neon Motherboard DNA)
| Name | Hex | Usage |
|------|-----|-------|
| Chaos Cyan | `#00F0FF` | Primary accent, CTAs, highlights |
| InfraRed Flux | `#FF003C` | Alerts, urgency, live indicators |
| Deep Void Black | `#0A0A0A` | Primary background |
| Electric Graphite | `#1A1D1F` | Cards, secondary backgrounds |

### Secondary Colors
| Name | Hex | Usage |
|------|-----|-------|
| Signal White | `#F2F9FB` | Primary text |
| Neon Ash Grey | `#5E6C72` | Secondary text, descriptions |
| Circuit Gold | `#FFD16F` | Premium features, Couture tier |

---

## Typography

### Headlines
- **Font:** Neue Machina Bold
- **Fallback:** Inter Bold
- **Weights:** 700, 800

### Body Copy
- **Font:** Inter Medium
- **Weights:** 400, 500, 600

### Accents (Stats, Code)
- **Font:** JetBrains Mono / MonoLisa
- **Weights:** 400, 500

---

## Brand Voice

### Tone
- Modern executive tone
- Builder-forward
- Strategic, crisp, authoritative
- Future-tech, clean language
- **No hype, only capability**

### Avoid
- Buzzwords
- Hyperbole
- Casual slang
- Over-promising

---

## Logo Concept

### Primary Mark
"CBE" letters embedded in a hexagonal grid cell:
- Glowing cyan borders
- Thin red flux lines
- Slight holographic depth

### Symbol
A stylized bridge made from neon circuitry — representing "bridging & building."

### Variants
1. Full logo (symbol + wordmark)
2. Icon only (hexagonal symbol)
3. Wordmark only (text treatment)

---

## UI Components

### Buttons
- **Primary:** Solid cyan (#00F0FF), black text
- **Secondary:** Outlined cyan border, transparent bg
- **Premium:** Gold gradient for Couture tier
- **Destructive:** Red flux (#FF003C)

### Cards
- Background: Electric Graphite (#1A1D1F) at 50% opacity
- Border: Border color at 50% opacity
- Hover: Cyan border glow
- Premium cards: Gold border accent

### Badges
- Verified: Cyan with checkmark
- Live: Red pulsing indicator
- Concierge: Gold gradient
- Featured: Cyan gradient

---

## Gradients

```css
/* Cyan Glow */
background: linear-gradient(135deg, #00F0FF 0%, #0080FF 100%);

/* Red Flux */
background: linear-gradient(135deg, #FF003C 0%, #FF6B6B 100%);

/* Gold Accent */
background: linear-gradient(135deg, #FFD16F 0%, #FFA500 100%);

/* Void Depth */
background: linear-gradient(180deg, #0A0A0A 0%, #1A1D1F 100%);
```

---

## Application Examples

### Hero Section
- Deep void black background
- Radial cyan glow at top
- Circuit pattern overlay at 10% opacity
- Large headline with cyan gradient text

### Profile Cards
- Electric graphite background
- Circular avatar with cyan border
- Verified badge with cyan glow
- Skill tags with cyan accent

### Concierge Section
- Gold accent throughout
- Premium gradient buttons
- Crown iconography
- Elevated card treatment
