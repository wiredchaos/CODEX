# CBE TOKENOMICS MODEL
## Regulatory-Safe, Non-Speculative Token Architecture

---

## 1. OVERVIEW

CBE uses three blockchain-powered units, all non-speculative:

| Token | Type | Purpose | Tradeable |
|-------|------|---------|-----------|
| **OT** | Opportunity Token | Internal utility credits | NO |
| **BIS** | Builder Identity Seal | Verification token | NO |
| **PWK** | Proof-of-Work Key | Reputation asset | NO |

---

## 2. OPPORTUNITY TOKENS (OT)

### Purpose
Used inside the platform only for:
- Service boosts
- Profile promotions
- Priority placement
- Early access to concierge matching
- Unlock templates & premium dashboards

### Key Properties
- **NOT** sold to the public
- **NOT** tradable
- **NOT** transferable
- No expectation of profit
- OTs are **EARNED**, not bought

### Earning Methods
| Action | OT Reward |
|--------|-----------|
| Complete Onboarding | 100 |
| Publish First Service | 50 |
| Complete First Project | 200 |
| Receive First Review | 75 |
| Early Delivery Bonus | 50 |
| Referral Bonus | 150 |
| Seasonal Events | 100 |
| Community Contribution | 25 |

### Redemption Options
| Utility | OT Cost |
|---------|---------|
| Service Boost (7 days) | 200 |
| Profile Promotion (14 days) | 300 |
| Priority Placement (30 days) | 500 |
| Concierge Priority | 400 |
| Premium Templates | 150 |
| 10% Service Discount | 100 |

---

## 3. BUILDER IDENTITY SEAL (BIS)

### Purpose
A one-time, non-transferable stamp on blockchain that confirms:
- Identity
- Portfolio authenticity
- Work completion history
- Contract reliability

### Analogy
Similar to a professional license, not a currency.

### Issuance
- Issued **once** upon verification
- **Revoked** if fraud detected

---

## 4. PROOF-OF-WORK KEYS (PWK)

### Purpose
Each completed project generates a PWK, which:
- Cannot be transferred
- Acts as immutable proof of delivery
- Increases Builder Reputation Score
- Enhances matching and ranking

### PWK Metadata
- Hash of deliverables
- Builder ID
- Client ID
- Timestamp
- Rating & review

---

## 5. TOKEN DISTRIBUTION

| Token | Method | Sources |
|-------|--------|---------|
| OT | EARNED | Activity, Milestones, Referrals, Events |
| BIS | ISSUED | Verification completion |
| PWK | GENERATED | Contract completion |

**No speculative mechanics, no trading pairs.**

---

## 6. REGULATORY COMPLIANCE

| Aspect | Status |
|--------|--------|
| Framework | Utility Token Model |
| Securities | Not a security - no profit expectation |
| Transferability | Non-transferable, non-tradeable |
| Governance | Platform-controlled issuance |

---

## 7. COMPARISON TO EXISTING MODELS

CBE's utility pricing mirrors existing SaaS credit systems:
- LinkedIn premium boosts
- Fiverr promoted listings
- Notion marketplace credits

**This is proven, compliant infrastructure.**
