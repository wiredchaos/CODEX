# WC META LABS — VIDEO GENERATOR PROMPT LIBRARY v1.0

## Overview

The Video Generator Prompt Library provides a standardized set of prompt templates for 3D/cinematic micro-videos that work with multiple providers (Runway, Pika, Kaiber, Grok Video, Spline) while respecting AvatarStyle and EnvironmentConfig.

## Architecture

```
lib/video/
├── types.ts          # Type definitions
├── avatars.ts        # Avatar overlay snippets
├── environments.ts   # Environment overlay definitions
├── templates.ts      # Category-specific templates
├── providers.ts      # Provider-specific suffixes
├── generator.ts      # Main generation engine
└── index.ts          # Exports
```

## Categories

| Category | Use Case | Duration |
|----------|----------|----------|
| `npc.answer` | NPC answer clips | 3s |
| `akira.seed_hook` | Story seed hooks | 5s |
| `akira.chapter_hook` | Chapter visualizations | 5s |
| `creator.trailer` | Book trailers | 8s |
| `creator.chapter_spark` | Chapter sparks | 5s |
| `business.meeting_intro` | Meeting intros | 5s |
| `business.training_snippet` | Training clips | 5s |
| `system.announcement` | System announcements | 5s |
| `fen.vault_artifact` | Artifact reveals | 5s |

## API Usage

### Endpoint

```
POST /api/video/generate
```

### Request Body

```json
{
  "category": "npc.answer",
  "avatarId": "neuro-meta",
  "environmentId": "npc-neon-tunnel",
  "duration": 3,
  "emotion": "focused_authority",
  "messageSummary": "explaining how your tax engine flags crypto liabilities",
  "provider": "runway"
}
```

### Response

```json
{
  "videoPrompt": "...",
  "provider": "runway",
  "durationSeconds": 3,
  "avatarUsed": "NEURO META — Red Fang Precision",
  "environmentUsed": "Neon Tunnel",
  "category": "npc.answer",
  "metadata": {
    "emotion": "focused_authority",
    "cameraMotion": "slow_push_in",
    "hookStrategy": "Quick light flare across avatar eyes..."
  }
}
```

## Avatars

- NEURO META — Red Fang Precision
- NEURO KIBA (Human) — Blade-Quiet Power
- KIBA NEURO (Cane Corso) — Guardian Presence
- NEURO UPLINK — Signal Pulse
- Oyalán Shàkó — Red Veil Sovereign
- SHADOWLUX — Soft Encryption
- GRYMM — Hardline Discipline
- 33.3 FM DJ Persona — Frequency Flow
- Dog #1787 — Motherboard Mascot

## Environments

### Business
- Neon Boardroom
- Glass Atrium
- Creator Studio
- Financial Observatory

### AKIRA/FEN
- Rupture Library
- Vault Chamber

### NPC
- Neon Tunnel
- Core Memory Node

### Creator
- Publishing Desk
- Cover Lab

## Providers

| Provider | Optimization Focus |
|----------|-------------------|
| Runway | Realistic lighting, cinematic motion |
| Pika | Smooth loops, social-optimized |
| Kaiber | Stylized/painterly rendering |
| Grok Video | Narrative consistency |
| Spline | Interactive 3D layouts |

## 3-Second Hook Requirement

All templates enforce a strong visual hook in the first 0.3-0.5 seconds:
- Light flare across avatar eyes
- Camera snap-focus
- Sudden holographic glow
- Symbolic object reveal
- System-wide light flash

---

**Version:** 1.0
**Authority:** WC META LABS
**Status:** OPERATIONAL
