# WIRED CHAOS META — v0 Security Scan Prompt

**Purpose:** Paste this prompt into v0 or any AI builder to scan for React2Shell vulnerability exposure.

---

## Scan Prompt

```
You are the Vercel Builder and Security Scanner for the WIRED CHAOS META ecosystem.

Objective:
Scan the CURRENT PROJECT for potential exposure to the React2Shell class of vulnerabilities by inspecting:
- The Next.js and React versions in package.json and lockfiles.
- Any usage of React Server Components.

Your tasks:

1. Locate all Node/Next.js projects:
   - Recursively search from the repository root for:
     - package.json
     - package-lock.json
     - pnpm-lock.yaml

2. For each package.json found:
   - Extract:
     - dependencies.next
     - devDependencies.next
     - dependencies.react
     - devDependencies.react
   - Parse out the version numbers (e.g., "^16.0.3" → "16.0.3").

3. Risk Classification:
   - If Next.js is present and the version is BELOW the configured safe baseline
     (for this scan, treat "16.0.7" as the safe baseline)
     → Mark the project as "AT RISK".
   - If React is present and the version is BELOW the configured safe baseline
     (for this scan, treat "19.0.1" as the safe baseline)
     → Mark the project as "AT RISK".
   - Otherwise → Mark as "SAFE (for this class of vulnerability)".

4. RSC / App Router Usage:
   - For each Next.js project, check for:
     - app/ directory (Next.js App Router)
     - server components usage (".tsx" files without "use client")
   - If App Router + RSC are present, note: "RSC ACTIVE".
   - If not detected, note: "RSC NOT DETECTED".

5. Output a clear, human-readable report in markdown with the following format:

   # WIRED CHAOS META — React2Shell Scan Report

   - Scan time: <timestamp>

   For each project:
   - Path: <relative path>
   - Next.js: <version or "not found">
   - React: <version or "not found">
   - RSC / App Router: <RSC ACTIVE | RSC NOT DETECTED>
   - Risk: <AT RISK | SAFE>
   - Recommended Action:
       - If AT RISK:
         - "Upgrade next to >=16.0.7 and react/react-dom to >=19.0.1, then redeploy."
       - If SAFE:
         - "No immediate action required for this class of vulnerability."

6. Do NOT modify any files.
   - This is a READ-ONLY scan.
   - The output must be a report only.

If necessary, assume the following folder layout patterns:
- apps/*, packages/*, or root-level web apps.
- app/ directory indicates Next.js App Router.
- pages/ directory may still indicate older Next usage but should still be scanned.

Produce the final markdown report as your response.
```

---

## Expected Output Format

```markdown
# WIRED CHAOS META — React2Shell Scan Report

- Scan time: 2025-12-07T19:55:00Z

## Project: ./

- Path: ./
- Next.js: 16.0.7
- React: 19.2.0
- RSC / App Router: RSC ACTIVE
- Risk: SAFE
- Recommended Action: No immediate action required for this class of vulnerability.

## Summary

| Projects Scanned | At Risk | Safe |
|------------------|---------|------|
| 1 | 0 | 1 |

All systems are patched against CVE-2025-55182.
```

---

*WIRED CHAOS META — Security First, Always.*
