# CBE In-App Tutorials

> Step-By-Step Guides for Chaos Builder Exchange Users

---

## TUTORIAL 1 — How to Create a Builder Profile

| Step | Action |
|------|--------|
| 1 | Click **Create Profile** |
| 2 | Upload avatar |
| 3 | Add title & professional summary |
| 4 | Select your skills & industries |
| 5 | Upload portfolio items |
| 6 | Connect Streamlabs (optional but recommended) |
| 7 | Save |
| 8 | Profile goes live |

**Estimated Time:** 2 minutes

---

## TUTORIAL 2 — Posting an Opportunity

| Step | Action |
|------|--------|
| 1 | Navigate to **Opportunity Grid** |
| 2 | Click **Publish Opportunity** |
| 3 | Set budget range |
| 4 | Add description & requirements |
| 5 | Select category |
| 6 | Click **Post** |
| 7 | AI Match recommends builders instantly |

**Estimated Time:** 90 seconds

---

## TUTORIAL 3 — Going Live with Streamlabs

| Step | Action |
|------|--------|
| 1 | Visit **Live Console** |
| 2 | Click **Connect Streamlabs** |
| 3 | Approve OAuth permissions |
| 4 | Press **Go Live** |
| 5 | Alerts and tips appear automatically in the Stream Feed |
| 6 | Session archived for replay |

**Estimated Time:** 60 seconds (first-time setup: 3 minutes)

---

## Quick Reference Card

```
┌─────────────────────────────────────────────────────────┐
│  CBE QUICK ACTIONS                                      │
├─────────────────────────────────────────────────────────┤
│  Create Profile    →  /chaos-builder-exchange/profile   │
│  Post Service      →  /chaos-builder-exchange/listing   │
│  Find Builders     →  /chaos-builder-exchange/find      │
│  Post Opportunity  →  /chaos-builder-exchange/post      │
│  Go Live           →  /chaos-builder-exchange/live      │
│  Concierge         →  /chaos-builder-exchange/concierge │
└─────────────────────────────────────────────────────────┘
