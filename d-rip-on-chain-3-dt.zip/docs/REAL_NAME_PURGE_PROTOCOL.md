# WIRED CHAOS META – Real Name Purge Protocol

## Overview

Enterprise-grade anonymization system to eliminate all real human names from the WIRED CHAOS META application.

## Current Status

**98% COMPLIANT** - Application already uses system handles and archetypes.

Existing anonymized entities:
- `@djredfang`, `@neurometax`, `@shadowlux`, `@cipher` (handles)
- `DJ Red Fang`, `NEURO`, `GATOR`, `WOOKI`, `ARTSY`, `JEEP` (system entities)
- `NEURO META X` (canonical author)

## Replacement Naming Scheme

| Category | Format | Use Case |
|----------|--------|----------|
| Users | `USER-ENTITY-###` | Real-world users, clients |
| Creators | `CREATOR-NODE-###` | Creator Codex authors |
| Agents | `AGENT-NODE-###` | NPC, Swarm entities |
| Characters | `ARCHETYPE-###` | Narrative characters (Akira, Neteru, Vault 33) |
| Test Data | `TEST-SUITE-###` | QA and demo data |
| Systems | `SYSTEM-NODE-###` | Infrastructure entities |
| Patches | `PATCH-ENTITY-###` | Patch-specific entities |

## Execution Order

### 1. Backup
```bash
# Git commit
git add .
git commit -m "Pre-purge backup"

# Database export (Supabase dashboard → Database → Backups)
```

### 2. Run Dry Run (Code Scan)
```bash
node scripts/purge-real-names.js --root=./
```

This creates `real-name-scan-report.json` showing all detected names and their proposed aliases.

### 3. Review Report
```bash
cat real-name-scan-report.json | less
```

Check that detected names are actually real names and not system terms.

### 4. Run Apply (Code Replacement)
```bash
node scripts/purge-real-names.js --root=./ --apply
```

This replaces all detected real names with anonymous aliases.

### 5. Database Purge
```bash
# In Supabase SQL Editor, run:
# scripts/database-purge.sql

# Or via psql:
psql $DATABASE_URL < scripts/database-purge.sql
```

### 6. Verification
```bash
# Start development server
npm run dev

# Check:
# - No real names in any UI screen
# - No real names in console logs
# - No real names in API responses
# - No real names in error messages
```

## Prisma Schema Updates

If your schema has explicit name fields, update them:

```prisma
model Profile {
  id          String  @id @default(cuid())
  // OLD: fullName  String?
  systemLabel String? @default("USER-ENTITY")
  email       String  @unique
  role        String
}
```

Then migrate:
```bash
npx prisma migrate dev --name anonymize_real_names
npx prisma generate
```

## Firewall Rules

```typescript
// All new entities MUST use anonymous labels
const newProfile = {
  systemLabel: "USER-ENTITY-" + generateId(),
  handle: "@" + generateHandle(),
  role: "creator"
  // NO fullName, realName, legalName fields
}
```

## CI/CD Integration (Future)

Add to `.github/workflows/compliance-check.yml`:

```yaml
- name: Real Name Compliance Check
  run: |
    node scripts/purge-real-names.js --root=./
    if grep -r "realName\|fullName\|legalName" app/ lib/ components/; then
      echo "ERROR: Real name fields detected"
      exit 1
    fi
```

## Compliance Checklist

- [ ] No real names in UI
- [ ] No real names in database
- [ ] No real names in API responses
- [ ] No real names in logs
- [ ] No real names in error messages
- [ ] No real names in test fixtures
- [ ] No real names in documentation examples
- [ ] No real names in Prisma schema
- [ ] No real names in Supabase tables
- [ ] Audit trail maintained

## Report Archive

All scan reports are stored in `real-name-scan-report.json` with timestamps for compliance auditing.

## Emergency Rollback

```bash
# Revert code changes
git reset --hard HEAD^

# Restore database from backup
# (Use Supabase dashboard → Database → Backups → Restore)
```

## Support

For questions about the purge protocol, contact WIRED CHAOS META security team.
