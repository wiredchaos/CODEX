# Streamlabs Integration Layer - Documentation

## Overview

The Streamlabs Integration Layer is a global WIRED CHAOS META integration that provides live streaming events, tips, and alerts to any patch via a unified client, event bus, and reusable UI components.

## Environment Variables

Add these to your Vercel project:

```
STREAMLABS_CLIENT_ID=your_client_id
STREAMLABS_CLIENT_SECRET=your_client_secret
STREAMLABS_REDIRECT_URI=https://yourdomain.com/api/streamlabs/auth
STREAMLABS_WEBHOOK_SECRET=your_webhook_secret
```

## Setup Instructions

### 1. Connect Streamlabs Account

1. Navigate to the hub settings or trigger `/api/streamlabs/connect`
2. Authorize with Streamlabs OAuth
3. Tokens are stored securely in `StreamlabsToken` model

### 2. Register Your Patch

```typescript
import { registerStreamlabsPatch } from "@/integrations/streamlabs/patch-registry"

registerStreamlabsPatch({
  patchId: "YOUR-PATCH-ID",
  displayName: "Your Patch Name",
  defaultChannel: "your_channel",
  alertPreferences: {
    donations: true,
    follows: true,
    subscriptions: true,
  },
})
```

### 3. Use Components

```tsx
import { NowLiveBadge } from "@/integrations/streamlabs/components/NowLiveBadge"
import { TipFeed } from "@/integrations/streamlabs/components/TipFeed"
import { StreamStatusCard } from "@/integrations/streamlabs/components/StreamStatusCard"
import { AlertBanner } from "@/integrations/streamlabs/components/AlertBanner"

// In your component
<NowLiveBadge patchId="YOUR-PATCH-ID" />
<TipFeed patchId="YOUR-PATCH-ID" limit={10} variant="list" />
<StreamStatusCard patchId="YOUR-PATCH-ID" variant="large" />
<AlertBanner patchId="YOUR-PATCH-ID" theme="akashic" />
```

### 4. Use Hooks

```tsx
import { useStreamlabsEvents, useStreamStatus } from "@/integrations/streamlabs/hooks"

function MyComponent() {
  const { events, loading } = useStreamlabsEvents("YOUR-PATCH-ID", "donation")
  const { isLive, lastEvent } = useStreamStatus("YOUR-PATCH-ID")
  
  // ...
}
```

## API Routes

| Route | Method | Purpose |
|-------|--------|---------|
| `/api/streamlabs/connect` | GET | Start OAuth flow |
| `/api/streamlabs/auth` | GET | OAuth callback |
| `/api/streamlabs/webhook` | POST | Receive Streamlabs events |
| `/api/streamlabs/events` | GET | Fetch filtered events |

## Per-Patch Usage

### 789 Studios
- Live show overlays
- Tip alerts during premieres
- Stream dashboard integration

### Akira Codex
- "Lore drop" stream alerts
- Live story reading sessions
- Interactive ARG reveals

### Creator Codex
- Live book launch streams
- Content drop announcements
- Author Q&A sessions

### NPC
- Live prompt clinics
- On-stream interactive challenges
- Training webinars

### Chaos Builder Exchange
- Office hours streaming
- Live consulting sessions
- Tip tracking for premium content

## Security Notes

- Webhook signature validation using `STREAMLABS_WEBHOOK_SECRET`
- Tokens stored encrypted in database
- Per-patch event filtering prevents cross-contamination
- No patch can access another patch's Streamlabs configuration

## Firewall Rules

- This is a SHARED SERVICE at the WIRED CHAOS META level
- Patches CALL the integration but do NOT own or modify core logic
- Each patch must explicitly opt-in with their `patchId`
- No hardcoded patch logic inside the integration layer
