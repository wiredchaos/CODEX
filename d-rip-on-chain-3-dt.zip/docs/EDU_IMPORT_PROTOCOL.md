# EDU Import Protocol

**MN AGENTIC SWARM GENERAL - EDUCATION NAMESPACE**

Version: 1.0.0  
Namespace: wired_chaos_meta.education  
Owner: NEURO_META_X

---

## Overview

The EDU Import Protocol is a comprehensive system for ingesting external technical education libraries and transforming them into WIRED CHAOS META SME Generals, Swarm agents, and curriculum modules.

## Architecture

### 9 Knowledge Pillars

1. **Cybersecurity & Digital Forensics** - Hacking, PenTesting, DFIR
2. **Networking & Infrastructure** - Cisco, Linux, Network Design
3. **Enterprise IT Systems** - Microsoft, SAP, ERP
4. **Programming & Software Development** - All Languages
5. **Cloud & E-Commerce Platforms** - AWS, Azure, GCP
6. **Hardware, Robotics & IoT** - Arduino, Embedded Systems
7. **Database Systems** - SQL, NoSQL, Schema Design
8. **Governance, Compliance & Certification** - CompTIA, NIST, ISO
9. **General Technical Knowledge** - Reference Materials

### Agent Hierarchy

- **Field Generals (9)** - One per pillar, TIER_0_ROOT_SM security
- **Swarm Agents (22)** - Specialized workers under each General

## Pipelines

### 1. Ingest Pipeline
- Register archive
- Hash & store in quarantine
- Strip metadata
- Classify by folder & pillar
- Log chain of custody

### 2. Transform Pipeline
- Extract audio & generate transcripts
- Convert documents to text chunks
- Parse slides into semantic segments
- Build knowledge graph per pillar
- Delete intermediate raw copies

### 3. Train Pipeline
- Create skill & objective maps
- Attach content to Generals & Swarms
- Generate curriculum & lab blueprints
- Run quality & safety review
- Sign-off by NEURO_META_X

### 4. Deploy Pipeline
- Publish agents to Swarm Registry
- Link curricula into Academy & Bootcamps
- Enable role-based access
- Activate telemetry & feedback

## Governance

### Anti-Moloch Rules
- No instruction for real-world illegal activity
- No attack guidance on live targets
- Always bias to defense education
- Prioritize user empowerment
- Refuse systemic exploitation enablers

### Copyright Policy
- Mode: Transformative Use Only
- Allowed: Semantic distillation, curriculum design, lab design
- Forbidden: Redistribution of original materials

## API Usage

### GET /api/edu
Returns registry overview with pillar statistics.

### POST /api/edu
Process an educational query.

```json
{
  "query": "Create a penetration testing curriculum",
  "pillarId": "pillar_cybersecurity",
  "requireLab": true,
  "requireAssessment": true,
  "certificationTarget": "CompTIA PenTest+"
}
```

## Access

- UI Dashboard: `/edu`
- Config: `config/edu-import-protocol.json`
- Library: `lib/edu/*`
