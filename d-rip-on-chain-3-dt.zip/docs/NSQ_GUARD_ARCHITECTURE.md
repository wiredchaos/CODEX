# NSQ GUARD — Neural Security Quantum Guard

## Enterprise-Grade Quantum-Resilient Security for WIRED CHAOS META

### Overview

NSQ GUARD is the unified security layer for WIRED CHAOS META, providing:

1. **Crypto Gateway** — Centralized cryptographic operations with quantum-readiness
2. **Security Swarm Guard** — Zero-trust access control with RBAC
3. **Edge Middleware** — Request filtering and rate limiting at the edge
4. **Audit System** — Comprehensive logging for compliance and forensics

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    EDGE (Vercel CDN)                        │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              middleware.ts                           │   │
│  │  • Security Headers (CSP, X-Frame, etc.)            │   │
│  │  • Edge Rate Limiting                               │   │
│  │  • Auth Token Validation                            │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                 NSA SECURITY SWARM                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │ access-ctrl  │  │    rates     │  │ audit-logger │      │
│  │  (RBAC)      │  │  (limiting)  │  │  (forensics) │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│                              │                              │
│                      guardian.ts                            │
│                  (unified enforcement)                      │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                   CRYPTO GATEWAY                            │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │   CLASSIC    │  │    HYBRID    │  │   PQC_ONLY   │      │
│  │  (ECC/RSA)   │  │ (ECC + PQC)  │  │  (Kyber/ML)  │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│                                                             │
│  Algorithms: AES-256-GCM, SHA-256, HMAC-SHA256             │
│  Future: Kyber768, Dilithium3 (via liboqs)                 │
└─────────────────────────────────────────────────────────────┘
```

---

## Usage

### Protecting an API Route

```typescript
import { guard, createContext } from "@/lib/nsa-security-swarm"
import { CryptoGateway } from "@/lib/crypto-gateway"

export async function POST(req: NextRequest) {
  const ctx = createContext({
    identity: {
      userId: session?.userId,
      ipHash: hashIP(req.ip),
      patchId: "finance-core",
    },
    roles: ["PRODUCER"],
    resource: "finance.transfer",
    method: "WRITE",
  })

  const { result, decision } = await guard(ctx, async () => {
    const body = await req.json()
    
    // Encrypt sensitive data before storage
    const encrypted = await CryptoGateway.encryptLongLived(
      Buffer.from(JSON.stringify(body))
    )
    
    // ... save to database ...
    return { success: true }
  })

  if (!decision.allowed) {
    return NextResponse.json({ error: decision.reason }, { status: 403 })
  }

  return NextResponse.json(result)
}
```

### Crypto Profiles

| Profile | Use Case | Algorithms |
|---------|----------|------------|
| CLASSIC | Legacy compatibility | ECC, RSA, AES-256 |
| HYBRID | Default - dual protection | ECC + PQC KEM |
| PQC_ONLY | Archival, long-lived data | Kyber, Dilithium |

Set via environment variable:
```
CRYPTO_PROFILE=HYBRID
```

---

## Role Hierarchy

```
SYSTEM > ADMIN > SYNDICATE > PRODUCER > CREATOR > VIEWER > ANON
```

Each role inherits permissions from all roles below it.

---

## Security Headers

Applied via middleware.ts:

- `X-Frame-Options: DENY`
- `X-Content-Type-Options: nosniff`
- `X-XSS-Protection: 1; mode=block`
- `Referrer-Policy: strict-origin-when-cross-origin`
- `Content-Security-Policy: [configured]`
- `Permissions-Policy: camera=(), microphone=(self), ...`

---

## Quantum Readiness Roadmap

1. **Phase 1 (Current)**: HYBRID profile with classical crypto + PQC placeholders
2. **Phase 2**: Integrate liboqs for Kyber KEM key wrapping
3. **Phase 3**: Add Dilithium for post-quantum signatures
4. **Phase 4**: Full PQC_ONLY mode for archival systems

---

## Monitoring

- Dashboard: `/security`
- Status API: `/api/security/nsq-status`
- Audit API: `/api/security/audit`

---

*NSQ GUARD v1.0 — WIRED CHAOS META LAB*
