# NEURO Profile Integration with Lurky.app

## Overview

This integration pulls NEURO META X's live profile data from Lurky.app and surfaces it across WIRED CHAOS META patches.

## Architecture

1. **Lurky API Client** (`lib/lurky/client.ts`)
   - Configured with `LURKY_API_KEY` environment variable
   - Rate limits: Free (50/month, 5/min), Developer (25K/month, 200/min)

2. **Profile Sync Layer** (`lib/lurky/neuro-profile.ts`)
   - Fetches NEURO's profile from Lurky
   - Caches in Prisma database
   - Auto-refreshes every 6 hours

3. **API Routes**
   - `GET /api/lurky/neuro` - Returns cached NEURO profile
   - `POST /api/lurky/neuro/sync` - Forces fresh sync from Lurky

4. **UI Components**
   - `NeuroProfileCard` - Reusable profile display
   - Used in: NPC Console, Business Suite, 789 Studios

## Environment Variables

```env
LURKY_API_KEY=your_lurky_api_key_here
LURKY_API_BASE_URL=https://api.lurky.app
```

## Usage

### Server Component

```tsx
import { getNeuroProfileCached } from "@/lib/lurky/neuro-profile"

const profile = await getNeuroProfileCached()
```

### Client Component

```tsx
import { NeuroProfileCard } from "@/components/neuro/neuro-profile-card"

<NeuroProfileCard />
```

## Cron Job (Optional)

Add to `vercel.json`:

```json
{
  "crons": [{
    "path": "/api/lurky/neuro/sync",
    "schedule": "0 */6 * * *"
  }]
}
```

## Firewall

NEURO profile data flows one-way:
```
Lurky.app → WIRED CHAOS → All Patches (read-only)
```

No patch can modify the canonical Lurky data.
