# WIRED CHAOS META - Database Architecture

## Overview

WIRED CHAOS META uses a **double-firewall** architecture with Neon PostgreSQL and Prisma ORM to ensure complete patch isolation while maintaining a unified codebase.

## Architecture Diagram

```
                 ┌─────────────────────────────┐
                 │       SWARM / LLM LAYER     │
                 │  (agents, tools, missions)  │
                 └─────────────┬───────────────┘
                               │
                               │  TOOL CALLS
                               ▼
                 ┌─────────────────────────────┐
                 │     FIREWALL 1 — PATCH API │
                 │  /api/<patch>/tools/*      │
                 │  - validates inputs        │
                 │  - enforces patchId        │
                 └─────────────┬───────────────┘
                               │
                               │  VALIDATED CALLS
                               ▼
                 ┌─────────────────────────────┐
                 │     PATCH SERVICE LAYER     │
                 │  (Next.js routes & actions) │
                 │  - uses getPrismaForPatch   │
                 │  - uses queryForPatch       │
                 └─────────────┬───────────────┘
                               │
                               │  ORM / SQL
                               ▼
                 ┌─────────────────────────────┐
                 │   FIREWALL 2 — DB SCHEMAS  │
                 │   Neon Postgres instance   │
                 │   - schemas per patch:     │
                 │     npc, akira, vault33…   │
                 │   - role-based privileges  │
                 └─────────────┬───────────────┘
                               │
                               ▼
                 ┌─────────────────────────────┐
                 │         DISK / STORAGE      │
                 │      (Neon physical data)   │
                 └─────────────────────────────┘
```

## Schemas

| Patch ID | Schema Name | Purpose |
|----------|-------------|---------|
| wcm | public | WIRED CHAOS META hub |
| chaos-os | chaos_os | CHAOS OS |
| npc | npc | NPC / Prompt Engine |
| akira-codex | akira | Akira Codex / Story Engine |
| studios-789 | studios_789 | 789 Studios OTT |
| vault33 | vault33 | Vault 33 |
| tax-suite | tax_suite | Tax Suite |
| trust-suite | trust_suite | Trust Suite |
| education | education | Education Hub |
| business | business | Business Suite / CBE |
| 33fm | fm | 33.3FM Radio |
| neteru | neteru | Neteru Apinaya Universe |
| creator-codex | creator | Creator Codex |
| lite | lite | Lite OS |

## Usage

### Get Prisma Client for a Patch

```typescript
import { getPrismaForPatch } from '@/lib/db';

const prisma = getPrismaForPatch('npc');
const sessions = await prisma.promptSession.findMany();
```

### Raw SQL with Patch Awareness

```typescript
import { queryForPatch } from '@/lib/db';

const results = await queryForPatch('akira-codex', 
  'SELECT * FROM story_arcs WHERE status = $1',
  ['active']
);
```

### Firewall Validation

```typescript
import { validateApiRequest, logFirewallEvent } from '@/lib/db';

const result = validateApiRequest({
  patchId: 'npc',
  operation: 'write',
  resource: 'prompt_sessions',
  userId: 'user_123',
});

logFirewallEvent(request, result);

if (!result.allowed) {
  throw new Error(result.reason);
}
```

## Security

1. **No direct client-side DB access** - All queries through API routes
2. **Schema isolation** - Each patch has its own PostgreSQL schema
3. **Role-based access** - App role has limited permissions (no ALTER/DROP)
4. **Audit logging** - All queries logged to central audit table
5. **TLS required** - All connections encrypted

## Bootstrap

Run the bootstrap script on a fresh Neon database:

```bash
psql $DATABASE_URL < scripts/neon-bootstrap.sql
```

## Environment Variables

| Variable | Description |
|----------|-------------|
| DATABASE_URL | Neon pooled connection string |
| POSTGRES_URL | Alias for DATABASE_URL |
| POSTGRES_URL_NON_POOLING | Direct URL for migrations |
| APP_ENV | production / preview / development |
| APP_NAME | Current patch identifier |
