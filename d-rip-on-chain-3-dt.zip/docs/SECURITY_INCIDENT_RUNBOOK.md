# WIRED CHAOS META — Security Incident Runbook

**Document ID:** WCM-SEC-RUNBOOK-001  
**Version:** 1.0  
**Last Updated:** December 7, 2025

---

## Purpose

This runbook provides step-by-step procedures for responding to security incidents across all WIRED CHAOS META patches.

---

## Incident Registry

| Incident ID | Date | Severity | CVE | Status |
|-------------|------|----------|-----|--------|
| WCM-SEC-2025-R2S | Dec 7, 2025 | CRITICAL | CVE-2025-55182 | RESOLVED |

---

## Emergency Procedures

### 1. Disable a Patch or Route Quickly

**Via Vercel Dashboard:**
1. Navigate to Project Settings > Domains
2. Remove or redirect the affected route
3. Add a maintenance page redirect

**Via Code (Emergency Block):**
```typescript
// middleware.ts - Add emergency block
export function middleware(request: NextRequest) {
  const blockedPaths = ['/compromised-route']
  if (blockedPaths.some(p => request.nextUrl.pathname.startsWith(p))) {
    return NextResponse.redirect(new URL('/maintenance', request.url))
  }
}
```

### 2. Trigger Global Redeploy

```bash
# Via Vercel CLI
vercel --prod --force

# Via GitHub
git commit --allow-empty -m "security: force redeploy"
git push origin main
```

### 3. Rotate Secrets

**Priority Order:**
1. Database keys (SUPABASE_SERVICE_ROLE_KEY)
2. JWT signing keys (SUPABASE_JWT_SECRET)
3. API keys (LURKY_API_KEY, STREAMLABS_CLIENT_SECRET)
4. Payment keys (STRIPE_SECRET_KEY)
5. Blockchain keys (XRPL, DOGE integrations)

**Rotation Steps:**
1. Generate new key in provider dashboard
2. Update Vercel Environment Variables
3. Redeploy all affected projects
4. Verify functionality
5. Revoke old key in provider dashboard

### 4. Notify Stakeholders

**Internal Notification Template:**
```
WIRED CHAOS META SECURITY ALERT

Incident ID: [ID]
Severity: [CRITICAL/HIGH/MEDIUM/LOW]
Affected Systems: [List patches]
Status: [INVESTIGATING/MITIGATING/RESOLVED]

Summary: [Brief description]

Actions Taken:
- [Action 1]
- [Action 2]

Next Steps:
- [Step 1]
- [Step 2]

Contact: NEURO META X / WIRED CHAOS META LAB
```

---

## Quick Reference Commands

```bash
# Check system status
curl https://your-domain.vercel.app/api/status

# Run security scan
curl https://your-domain.vercel.app/api/security/scan

# Check dependency versions
npx next info

# Run audit
npm audit --audit-level=critical

# Clear all caches
rm -rf .next node_modules/.cache

# Force rebuild
npm run build
```

---

## Escalation Matrix

| Severity | Response Time | Escalation |
|----------|---------------|------------|
| CRITICAL | 15 minutes | Immediate - All hands |
| HIGH | 1 hour | Security Lead + Dev Lead |
| MEDIUM | 4 hours | Security Lead |
| LOW | 24 hours | Standard review |

---

## Post-Incident Checklist

- [ ] Root cause identified
- [ ] Patch applied and verified
- [ ] All affected systems redeployed
- [ ] Secrets rotated (if applicable)
- [ ] Logs reviewed for indicators of compromise
- [ ] Incident documented in registry
- [ ] Lessons learned documented
- [ ] Security bulletin issued (if public disclosure needed)

---

*WIRED CHAOS META — Security First, Always.*
