# Dynamic Preview System - Zero-Cost Video Effects

## Overview

The Dynamic Preview System provides cinematic video-like motion effects without any paid API dependencies. It uses CSS Ken Burns animations on static images to create engaging, "alive" visual experiences across all 789 Studios and WIRED CHAOS patches.

## Components

### 1. DynamicPreview

Core component that renders either local video or Ken Burns animated stills.

```tsx
import { DynamicPreview } from "@/components/media/dynamic-preview"

// Motion-still mode (default) - no video file needed
<DynamicPreview
  mode="motion-still"
  src="/images/show-poster.jpg"
  label="NEURO TRIALS"
  aspect="16:9"
  motionDirection="zoom-in"
  duration={18}
  overlay="bottom"
  glowColor="cyan"
/>

// Local video mode - when you have actual video files
<DynamicPreview
  mode="local"
  src="/videos/show-loop.mp4"
  label="LIVE STREAM"
/>
```

**Props:**
- `mode`: "local" | "motion-still"
- `src`: Image or video source path
- `aspect`: "16:9" | "1:1" | "4:3" | "21:9"
- `motionDirection`: "zoom-in" | "zoom-out" | "pan-left" | "pan-right" | "pan-up" | "pan-down"
- `duration`: Animation duration in seconds (default: 18)
- `overlay`: "none" | "bottom" | "full" | "vignette"
- `glowColor`: "cyan" | "red" | "magenta" | "amber" | "none"
- `showLoading`: Enable dramatic loading animation
- `loadingDuration`: Loading delay in ms

### 2. ShowCard

OTT-style show card with integrated DynamicPreview.

```tsx
import { ShowCard } from "@/components/media/show-card"

<ShowCard
  title="NEURO TRIALS"
  logline="Analog rebels hijack the stream..."
  mediaSrc="/images/shows/neuro-trials.jpg"
  mediaMode="motion-still"
  motionDirection="zoom-in"
  status="live"
  tags={["AI", "Competition"]}
  episodeCount={12}
  href="/shows/neuro-trials"
/>
```

### 3. HeroPreview

Full-width hero banner with Ken Burns background.

```tsx
import { HeroPreview } from "@/components/media/hero-preview"

<HeroPreview
  title="NEURO TRIALS"
  subtitle="789 STUDIOS PRESENTS"
  description="Season 2 premieres this week."
  mediaSrc="/images/hero-bg.jpg"
  status="live"
  primaryAction={{ label: "Watch Now", href: "/watch" }}
  showRadioAttribution
/>
```

### 4. PatchPreview

Patch landing card with motion preview.

```tsx
import { PatchPreview } from "@/components/media/patch-preview"

<PatchPreview
  id="akira-codex"
  name="AKIRA CODEX"
  description="AI-powered story engine"
  mediaSrc="/images/patches/akira.jpg"
  patchType="lore"
  status="active"
  accentColor="magenta"
/>
```

## Ken Burns Animation Variants

| Direction | Effect | Best For |
|-----------|--------|----------|
| `zoom-in` | Slow zoom into center | Hero shots, dramatic reveals |
| `zoom-out` | Slow zoom out | Establishing shots, wide scenes |
| `pan-left` | Drift left | Horizontal scenes, cityscapes |
| `pan-right` | Drift right | Following action, transitions |
| `pan-up` | Drift upward | Tall structures, ascending mood |
| `pan-down` | Drift downward | Descending, mysterious reveals |

## Generating Assets

### Free/Low-Cost Options:

1. **Static Poster Art**
   - Use existing artwork or AI-generated images
   - Place in `/public/images/`
   - Use `mediaMode="motion-still"` for automatic animation

2. **Simple Video Loops**
   - Free trials: CapCut, Canva animations
   - Export 5-10 second loops
   - Save to `/public/videos/`
   - Switch to `mediaMode="local"`

3. **Placeholder System**
   - Use query-based placeholders during development
   - `mediaSrc="/placeholder.svg?height=400&width=711"`

## Integration Points

The DynamicPreview system works across:

- **789 Studios OTT** - `/789-studios/ott`
- **POS Network** - `/pos/*`
- **BWB News** - `/pos/bwb/*`
- **Patch Landing Pages** - `/patch/*`
- **AKIRA CODEX** - `/akira-codex/*`
- **Business Patch** - `/business/*`

## Technical Notes

- **Zero API Cost**: All animations are CSS-only
- **Performance**: GPU-accelerated transforms
- **Mobile-Friendly**: Respects `prefers-reduced-motion`
- **Fallbacks**: Graceful degradation to static images
- **Bundle Size**: No external dependencies

## DJ Persona Integration

The system uses DJ Chrome Fang branding for audio/visual transitions:

- "Signal Chain" replaces "Aux Cord"
- "Curated by DJ Chrome Fang" attribution
- "Broadcast on 33.3FM DOGECHAIN" for radio content

---

*WIRED CHAOS META LABS • 789 STUDIOS*
*Zero-Cost Dynamic Media System v1.0*
