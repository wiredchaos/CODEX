// integrations/lurky/components/SpaceCard.tsx
"use client"

import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Users, Clock, Radio } from "lucide-react"
import type { LurkySpace } from "@/lib/lurky/client"

interface SpaceCardProps {
  space: LurkySpace
  variant?: "default" | "compact" | "featured"
  onClick?: () => void
}

export function SpaceCard({ space, variant = "default", onClick }: SpaceCardProps) {
  const isLive = space.state === "live"
  const isScheduled = space.state === "scheduled"

  const getStateColor = () => {
    switch (space.state) {
      case "live":
        return "bg-red-500/20 text-red-400 border-red-500/50"
      case "scheduled":
        return "bg-amber-500/20 text-amber-400 border-amber-500/50"
      case "ended":
        return "bg-zinc-500/20 text-zinc-400 border-zinc-500/50"
      case "analyzed":
        return "bg-cyan-500/20 text-cyan-400 border-cyan-500/50"
      default:
        return "bg-zinc-500/20 text-zinc-400 border-zinc-500/50"
    }
  }

  if (variant === "compact") {
    return (
      <div
        className="flex items-center gap-3 p-3 rounded-lg bg-zinc-900/50 border border-zinc-800 hover:border-cyan-500/30 transition-colors cursor-pointer"
        onClick={onClick}
      >
        {isLive && <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />}
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-zinc-100 truncate">{space.title}</p>
          <p className="text-xs text-zinc-500">@{space.creator_handle || space.creator_username}</p>
        </div>
        <Badge variant="outline" className={getStateColor()}>
          {space.state}
        </Badge>
      </div>
    )
  }

  return (
    <Card
      className="bg-zinc-900/80 border-zinc-800 hover:border-cyan-500/30 transition-all cursor-pointer group"
      onClick={onClick}
    >
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-zinc-100 group-hover:text-cyan-400 transition-colors line-clamp-2">
              {space.title}
            </h3>
            <p className="text-sm text-zinc-500 mt-1">@{space.creator_handle || space.creator_username}</p>
          </div>
          <Badge variant="outline" className={getStateColor()}>
            {isLive && <Radio className="w-3 h-3 mr-1 animate-pulse" />}
            {space.state}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-4 text-sm text-zinc-400">
          {space.participant_count != null && (
            <div className="flex items-center gap-1">
              <Users className="w-4 h-4" />
              <span>{space.participant_count.toLocaleString()}</span>
            </div>
          )}
          {space.started_at && (
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              <span>{new Date(space.started_at).toLocaleDateString()}</span>
            </div>
          )}
        </div>
        {space.categories && space.categories.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-3">
            {space.categories.slice(0, 3).map((cat) => (
              <Badge key={cat} variant="secondary" className="text-xs bg-zinc-800 text-zinc-400">
                {cat}
              </Badge>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
