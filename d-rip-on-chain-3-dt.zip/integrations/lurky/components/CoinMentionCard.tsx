// integrations/lurky/components/CoinMentionCard.tsx
"use client"

import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { TrendingUp, TrendingDown, Minus } from "lucide-react"
import type { LurkyCoin } from "@/lib/lurky/client"

interface CoinMentionCardProps {
  coin: LurkyCoin
  variant?: "default" | "compact" | "detailed"
  onClick?: () => void
}

export function CoinMentionCard({ coin, variant = "default", onClick }: CoinMentionCardProps) {
  const mentions = coin.mentions || coin.mentionStats
  const totalMentions = mentions?.total ?? 0
  const bullishPercent = mentions ? Math.round((mentions.bullish / totalMentions) * 100) : 0
  const bearishPercent = mentions ? Math.round((mentions.bearish / totalMentions) * 100) : 0

  const getSentimentColor = () => {
    if (bullishPercent > 60) return "text-emerald-400"
    if (bearishPercent > 60) return "text-red-400"
    return "text-zinc-400"
  }

  const getSentimentIcon = () => {
    if (bullishPercent > 60) return <TrendingUp className="w-4 h-4 text-emerald-400" />
    if (bearishPercent > 60) return <TrendingDown className="w-4 h-4 text-red-400" />
    return <Minus className="w-4 h-4 text-zinc-400" />
  }

  const priceChange = coin.priceChange24h ?? 0

  if (variant === "compact") {
    return (
      <div
        className="flex items-center gap-3 p-2 rounded-lg bg-zinc-900/50 border border-zinc-800 hover:border-cyan-500/30 transition-colors cursor-pointer"
        onClick={onClick}
      >
        {coin.image && <img src={coin.image || "/placeholder.svg"} alt={coin.name} className="w-6 h-6 rounded-full" />}
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-zinc-100">{coin.symbol}</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-xs bg-cyan-500/10 text-cyan-400 border-cyan-500/30">
            {totalMentions} mentions
          </Badge>
          {getSentimentIcon()}
        </div>
      </div>
    )
  }

  return (
    <Card
      className="bg-zinc-900/80 border-zinc-800 hover:border-cyan-500/30 transition-all cursor-pointer"
      onClick={onClick}
    >
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          {coin.image && (
            <img src={coin.image || "/placeholder.svg"} alt={coin.name} className="w-10 h-10 rounded-full" />
          )}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h3 className="font-semibold text-zinc-100">{coin.name}</h3>
              <Badge variant="secondary" className="text-xs bg-zinc-800">
                {coin.symbol}
              </Badge>
            </div>

            {coin.chain && <p className="text-xs text-zinc-500 mt-1">{coin.chain}</p>}

            <div className="flex items-center gap-4 mt-3">
              {(coin.price || coin.priceUsd) && (
                <div>
                  <p className="text-xs text-zinc-500">Price</p>
                  <p className="text-sm font-medium text-zinc-100">
                    ${(coin.price || coin.priceUsd)?.toLocaleString(undefined, { maximumFractionDigits: 6 })}
                  </p>
                </div>
              )}

              {priceChange !== 0 && (
                <div>
                  <p className="text-xs text-zinc-500">24h</p>
                  <p className={`text-sm font-medium ${priceChange > 0 ? "text-emerald-400" : "text-red-400"}`}>
                    {priceChange > 0 ? "+" : ""}
                    {priceChange.toFixed(2)}%
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {mentions && (
          <div className="mt-4 pt-3 border-t border-zinc-800">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-zinc-500">Sentiment Analysis</span>
              <span className={`text-sm font-medium ${getSentimentColor()}`}>{totalMentions} mentions</span>
            </div>
            <div className="flex gap-1 h-2 rounded-full overflow-hidden bg-zinc-800">
              <div className="bg-emerald-500 transition-all" style={{ width: `${bullishPercent}%` }} />
              <div
                className="bg-zinc-500 transition-all"
                style={{ width: `${100 - bullishPercent - bearishPercent}%` }}
              />
              <div className="bg-red-500 transition-all" style={{ width: `${bearishPercent}%` }} />
            </div>
            <div className="flex justify-between mt-1 text-xs">
              <span className="text-emerald-400">Bullish {bullishPercent}%</span>
              <span className="text-red-400">Bearish {bearishPercent}%</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
