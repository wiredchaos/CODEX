// integrations/lurky/components/SpeakerCard.tsx
"use client"
import { Card, CardContent } from "@/components/ui/card"
import { Users, Radio, CheckCircle } from "lucide-react"
import type { LurkySpeaker } from "@/lib/lurky/client"

interface SpeakerCardProps {
  speaker: LurkySpeaker
  variant?: "default" | "compact"
  onClick?: () => void
}

export function SpeakerCard({ speaker, variant = "default", onClick }: SpeakerCardProps) {
  if (variant === "compact") {
    return (
      <div
        className="flex items-center gap-3 p-2 rounded-lg bg-zinc-900/50 border border-zinc-800 hover:border-cyan-500/30 transition-colors cursor-pointer"
        onClick={onClick}
      >
        {speaker.image ? (
          <img
            src={speaker.image || "/placeholder.svg"}
            alt={speaker.name || speaker.handle}
            className="w-8 h-8 rounded-full"
          />
        ) : (
          <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center">
            <span className="text-xs text-zinc-400">{speaker.handle[0].toUpperCase()}</span>
          </div>
        )}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1">
            <p className="text-sm font-medium text-zinc-100 truncate">{speaker.name || speaker.handle}</p>
            {speaker.verified && <CheckCircle className="w-3 h-3 text-cyan-400 flex-shrink-0" />}
          </div>
          <p className="text-xs text-zinc-500">@{speaker.handle}</p>
        </div>
      </div>
    )
  }

  return (
    <Card
      className="bg-zinc-900/80 border-zinc-800 hover:border-cyan-500/30 transition-all cursor-pointer"
      onClick={onClick}
    >
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          {speaker.image ? (
            <img
              src={speaker.image || "/placeholder.svg"}
              alt={speaker.name || speaker.handle}
              className="w-12 h-12 rounded-full"
            />
          ) : (
            <div className="w-12 h-12 rounded-full bg-zinc-800 flex items-center justify-center">
              <span className="text-lg text-zinc-400">{speaker.handle[0].toUpperCase()}</span>
            </div>
          )}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h3 className="font-semibold text-zinc-100">{speaker.name || speaker.handle}</h3>
              {speaker.verified && <CheckCircle className="w-4 h-4 text-cyan-400" />}
            </div>
            <p className="text-sm text-zinc-500">@{speaker.handle}</p>

            <div className="flex items-center gap-4 mt-3 text-sm">
              {speaker.followersCount != null && (
                <div className="flex items-center gap-1 text-zinc-400">
                  <Users className="w-4 h-4" />
                  <span>{speaker.followersCount.toLocaleString()}</span>
                </div>
              )}
              {speaker.spacesCount != null && (
                <div className="flex items-center gap-1 text-zinc-400">
                  <Radio className="w-4 h-4" />
                  <span>{speaker.spacesCount} spaces</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {speaker.bio && <p className="text-sm text-zinc-400 mt-3 line-clamp-2">{speaker.bio}</p>}
      </CardContent>
    </Card>
  )
}
