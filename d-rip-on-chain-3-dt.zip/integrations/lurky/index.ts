// integrations/lurky/index.ts
// Global Lurky Integration Layer for WIRED CHAOS META
// Similar architecture to Streamlabs - shared service usable by all patches

export * from "@/lib/lurky/client"

import {
  getLurkyClient,
  type LurkySpace,
  type LurkyCoin,
  type LurkySpeaker,
  type LurkyDiscussion,
  type LurkyMindMap,
  LURKY_RATE_LIMITS,
} from "@/lib/lurky/client"

// Patch registry for Lurky integration
export interface LurkyPatchConfig {
  patchId: string
  displayName: string
  creatorIds?: string[] // Twitter IDs to track
  coinSymbols?: string[] // Coins to monitor
  features: {
    spaces: boolean
    coins: boolean
    speakers: boolean
    discussions: boolean
    mindMaps: boolean
  }
}

const patchRegistry = new Map<string, LurkyPatchConfig>()

export function registerLurkyPatch(config: LurkyPatchConfig) {
  patchRegistry.set(config.patchId, config)
}

export function getLurkyPatchConfig(patchId: string): LurkyPatchConfig | undefined {
  return patchRegistry.get(patchId)
}

export function getAllLurkyPatches(): LurkyPatchConfig[] {
  return Array.from(patchRegistry.values())
}

// Pre-register known patches
registerLurkyPatch({
  patchId: "789-STUDIOS",
  displayName: "789 Studios OTT",
  features: {
    spaces: true,
    coins: true,
    speakers: true,
    discussions: true,
    mindMaps: true,
  },
})

registerLurkyPatch({
  patchId: "CBE",
  displayName: "Chaos Builder Exchange",
  features: {
    spaces: true,
    coins: false,
    speakers: true,
    discussions: false,
    mindMaps: false,
  },
})

registerLurkyPatch({
  patchId: "33FM",
  displayName: "33.3FM Radio",
  features: {
    spaces: true,
    coins: true,
    speakers: true,
    discussions: true,
    mindMaps: false,
  },
})

registerLurkyPatch({
  patchId: "AKIRA-CODEX",
  displayName: "Akira Codex",
  features: {
    spaces: true,
    coins: false,
    speakers: true,
    discussions: true,
    mindMaps: true,
  },
})

// Convenience functions for patches
export async function getSpacesForPatch(patchId: string, params?: { page?: number; limit?: number }) {
  const config = getLurkyPatchConfig(patchId)
  if (!config?.features.spaces) {
    throw new Error(`Patch ${patchId} does not have spaces feature enabled`)
  }

  const client = getLurkyClient()
  return client.listSpaces({
    creator_ids: config.creatorIds,
    page: params?.page ?? 0,
    limit: params?.limit ?? 10,
  })
}

export async function getCoinsForPatch(patchId: string, params?: { page?: number; limit?: number }) {
  const config = getLurkyPatchConfig(patchId)
  if (!config?.features.coins) {
    throw new Error(`Patch ${patchId} does not have coins feature enabled`)
  }

  const client = getLurkyClient()
  return client.listCoinsWithMentions({
    page: params?.page ?? 0,
    limit: params?.limit ?? 20,
  })
}

export async function getSpeakersForPatch(patchId: string, params?: { page?: number; limit?: number }) {
  const config = getLurkyPatchConfig(patchId)
  if (!config?.features.speakers) {
    throw new Error(`Patch ${patchId} does not have speakers feature enabled`)
  }

  const client = getLurkyClient()
  return client.listSpeakers({
    page: params?.page ?? 0,
    limit: params?.limit ?? 20,
  })
}

export { getLurkyClient, LURKY_RATE_LIMITS }
export type { LurkySpace, LurkyCoin, LurkySpeaker, LurkyDiscussion, LurkyMindMap }
