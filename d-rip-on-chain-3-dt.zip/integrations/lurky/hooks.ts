// integrations/lurky/hooks.ts
"use client"

import useSWR from "swr"
import type { LurkySpace, LurkyCoin, LurkySpeaker } from "@/lib/lurky/client"

const fetcher = (url: string) => fetch(url).then((r) => r.json())

export function useLurkySpaces(params?: {
  page?: number
  limit?: number
  state?: string
}) {
  const searchParams = new URLSearchParams()
  if (params?.page) searchParams.set("page", String(params.page))
  if (params?.limit) searchParams.set("limit", String(params.limit))
  if (params?.state) searchParams.set("state", params.state)

  const { data, error, isLoading, mutate } = useSWR<{
    spaces: LurkySpace[]
    page: number
    limit: number
    total?: number
  }>(`/api/lurky/spaces?${searchParams.toString()}`, fetcher, {
    refreshInterval: 30000, // Refresh every 30 seconds
  })

  return {
    spaces: data?.spaces ?? [],
    page: data?.page ?? 0,
    total: data?.total,
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useLurkySpeakers(params?: {
  page?: number
  limit?: number
  minFollowers?: number
  maxFollowers?: number
}) {
  const searchParams = new URLSearchParams()
  if (params?.page) searchParams.set("page", String(params.page))
  if (params?.limit) searchParams.set("limit", String(params.limit))
  if (params?.minFollowers) searchParams.set("min_followers", String(params.minFollowers))
  if (params?.maxFollowers) searchParams.set("max_followers", String(params.maxFollowers))

  const { data, error, isLoading, mutate } = useSWR<{
    speakers: LurkySpeaker[]
    page: number
    limit: number
  }>(`/api/lurky/speakers?${searchParams.toString()}`, fetcher, {
    refreshInterval: 60000,
  })

  return {
    speakers: data?.speakers ?? [],
    page: data?.page ?? 0,
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useLurkyCoins(params?: {
  page?: number
  limit?: number
  sortBy?: "market_cap" | "name" | "price" | "mentions"
  sortDir?: "asc" | "desc"
  chains?: string[]
}) {
  const searchParams = new URLSearchParams()
  if (params?.page) searchParams.set("page", String(params.page))
  if (params?.limit) searchParams.set("limit", String(params.limit))
  if (params?.sortBy) searchParams.set("sort_by", params.sortBy)
  if (params?.sortDir) searchParams.set("sort_dir", params.sortDir)
  if (params?.chains?.length) searchParams.set("chains", params.chains.join(","))

  const { data, error, isLoading, mutate } = useSWR<{
    coins: LurkyCoin[]
    page: number
    limit: number
  }>(`/api/lurky/coins-with-mentions?${searchParams.toString()}`, fetcher, {
    refreshInterval: 60000,
  })

  return {
    coins: data?.coins ?? [],
    page: data?.page ?? 0,
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useLurkySpaceDetails(spaceId: string | null) {
  const { data, error, isLoading, mutate } = useSWR(spaceId ? `/api/lurky/spaces/${spaceId}` : null, fetcher, {
    refreshInterval: 30000,
  })

  return {
    space: data,
    isLoading,
    error,
    refresh: mutate,
  }
}
