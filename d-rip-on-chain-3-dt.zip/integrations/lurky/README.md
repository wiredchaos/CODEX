# Lurky API Integration Layer

Global WIRED CHAOS META integration for X/Twitter Spaces analytics via the Lurky API.

## Overview

The Lurky Integration Layer provides Spaces data, coin mentions, speaker analytics, and discussion tracking to all WIRED CHAOS patches via a shared client, hooks, and UI components.

## API Documentation

Full API docs available at: https://api.lurky.app/docs

### Rate Limits

| Tier | Per Month | Per Minute |
|------|-----------|------------|
| Free | 50 | 5 |
| Developer | 25,000 | 200 |
| Enterprise | 100,000 | 200 |

## Environment Variables

```env
LURKY_API_KEY=your-api-key-here
LURKY_API_BASE_URL=https://api.lurky.app  # Optional, defaults to this
```

## Available Endpoints

### Spaces
- `GET /api/lurky/spaces` - List spaces
- `GET /api/lurky/spaces/[spaceId]` - Space details
- Space mentioned coins
- Space speakers
- Space mind map
- Space discussions

### Coins
- `GET /api/lurky/coins-with-mentions` - Coins with sentiment analysis

### Speakers
- `GET /api/lurky/speakers` - List speakers with follower stats

### Discussions
- `GET /api/lurky/discussions` - Discussion transcripts and analysis

## React Hooks

```tsx
import { useLurkySpaces, useLurkySpeakers, useLurkyCoins } from '@/integrations/lurky/hooks'

// In your component
const { spaces, isLoading, error, refresh } = useLurkySpaces({ limit: 10 })
const { speakers } = useLurkySpeakers({ minFollowers: 10000 })
const { coins } = useLurkyCoins({ sortBy: 'mentions' })
```

## UI Components

```tsx
import { SpaceCard } from '@/integrations/lurky/components/SpaceCard'
import { CoinMentionCard } from '@/integrations/lurky/components/CoinMentionCard'
import { SpeakerCard } from '@/integrations/lurky/components/SpeakerCard'

<SpaceCard space={space} variant="default" onClick={() => {}} />
<CoinMentionCard coin={coin} variant="detailed" />
<SpeakerCard speaker={speaker} variant="compact" />
```

## Patch Registration

Patches can register to enable specific Lurky features:

```ts
import { registerLurkyPatch } from '@/integrations/lurky'

registerLurkyPatch({
  patchId: 'MY-PATCH',
  displayName: 'My Patch Name',
  creatorIds: ['twitter-id-1', 'twitter-id-2'],
  features: {
    spaces: true,
    coins: true,
    speakers: true,
    discussions: false,
    mindMaps: false,
  },
})
```

## Pre-Registered Patches

- **789-STUDIOS** - Full features (spaces, coins, speakers, discussions, mind maps)
- **CBE** - Spaces and speakers only
- **33FM** - Spaces, coins, speakers, discussions
- **AKIRA-CODEX** - Spaces, speakers, discussions, mind maps

## Firewall Rules

- Patches can only access features they have registered for
- No patch can modify another patch's Lurky configuration
- All data flows through the shared integration layer
```
