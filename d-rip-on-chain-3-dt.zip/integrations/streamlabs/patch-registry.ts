/**
 * WIRED CHAOS META - Streamlabs Patch Registry
 * Manages per-patch Streamlabs configurations
 */

export interface StreamPatchConfig {
  patchId: string
  displayName: string
  defaultChannel?: string
  alertPreferences: {
    donations: boolean
    follows: boolean
    subscriptions: boolean
    raids: boolean
    custom: boolean
    minDonationAlert?: number
  }
  webhookEndpoint?: string
  theme?: "akashic" | "corporate" | "custom"
  customColors?: {
    primary: string
    secondary: string
    accent: string
  }
}

// Registry storage (replace with DB in production)
const patchRegistry = new Map<string, StreamPatchConfig>()

// Default configurations for known patches
const DEFAULT_PATCH_CONFIGS: Partial<Record<string, Partial<StreamPatchConfig>>> = {
  "789-STUDIOS": {
    displayName: "789 Studios",
    theme: "akashic",
    alertPreferences: {
      donations: true,
      follows: true,
      subscriptions: true,
      raids: true,
      custom: true,
    },
  },
  "AKIRA-CODEX": {
    displayName: "Akira Codex",
    theme: "akashic",
    alertPreferences: {
      donations: true,
      follows: false,
      subscriptions: false,
      raids: false,
      custom: true,
    },
  },
  "CREATOR-CODEX": {
    displayName: "Creator Codex",
    theme: "corporate",
    alertPreferences: {
      donations: true,
      follows: true,
      subscriptions: true,
      raids: false,
      custom: true,
    },
  },
  NPC: {
    displayName: "NPC Interface",
    theme: "akashic",
    alertPreferences: {
      donations: true,
      follows: true,
      subscriptions: false,
      raids: false,
      custom: true,
    },
  },
  CBE: {
    displayName: "Chaos Builder Exchange",
    theme: "corporate",
    alertPreferences: {
      donations: true,
      follows: false,
      subscriptions: false,
      raids: false,
      custom: true,
      minDonationAlert: 5,
    },
  },
  "33FM": {
    displayName: "33.3 FM Radio",
    theme: "akashic",
    alertPreferences: {
      donations: true,
      follows: true,
      subscriptions: true,
      raids: true,
      custom: true,
    },
  },
}

/**
 * Register a patch for Streamlabs integration
 */
export function registerStreamlabsPatch(config: StreamPatchConfig): void {
  const defaults = DEFAULT_PATCH_CONFIGS[config.patchId] || {}
  const fullConfig: StreamPatchConfig = {
    ...defaults,
    ...config,
    alertPreferences: {
      donations: true,
      follows: true,
      subscriptions: true,
      raids: true,
      custom: true,
      ...defaults.alertPreferences,
      ...config.alertPreferences,
    },
  }
  patchRegistry.set(config.patchId, fullConfig)
}

/**
 * Get a patch's Streamlabs configuration
 */
export function getPatchStreamProfile(patchId: string): StreamPatchConfig | null {
  // Return registered config or create default from known patches
  if (patchRegistry.has(patchId)) {
    return patchRegistry.get(patchId)!
  }

  const defaults = DEFAULT_PATCH_CONFIGS[patchId]
  if (defaults) {
    const config: StreamPatchConfig = {
      patchId,
      displayName: defaults.displayName || patchId,
      theme: defaults.theme || "corporate",
      alertPreferences: {
        donations: true,
        follows: true,
        subscriptions: true,
        raids: true,
        custom: true,
        ...defaults.alertPreferences,
      },
    }
    return config
  }

  return null
}

/**
 * Update a patch's configuration
 */
export function updatePatchStreamProfile(
  patchId: string,
  updates: Partial<StreamPatchConfig>,
): StreamPatchConfig | null {
  const existing = patchRegistry.get(patchId)
  if (!existing) return null

  const updated: StreamPatchConfig = {
    ...existing,
    ...updates,
    alertPreferences: {
      ...existing.alertPreferences,
      ...updates.alertPreferences,
    },
  }

  patchRegistry.set(patchId, updated)
  return updated
}

/**
 * Remove a patch from the registry
 */
export function unregisterPatch(patchId: string): boolean {
  return patchRegistry.delete(patchId)
}

/**
 * Get all registered patches
 */
export function getAllRegisteredPatches(): StreamPatchConfig[] {
  return Array.from(patchRegistry.values())
}

/**
 * Check if a patch is registered
 */
export function isPatchRegistered(patchId: string): boolean {
  return patchRegistry.has(patchId) || patchId in DEFAULT_PATCH_CONFIGS
}

/**
 * Get list of known patch IDs
 */
export function getKnownPatchIds(): string[] {
  const registered = Array.from(patchRegistry.keys())
  const defaults = Object.keys(DEFAULT_PATCH_CONFIGS)
  return [...new Set([...registered, ...defaults])]
}
