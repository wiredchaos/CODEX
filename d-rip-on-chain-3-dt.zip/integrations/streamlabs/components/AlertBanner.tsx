"use client"

import { useState, useEffect } from "react"
import { useStreamlabsEvents } from "../hooks"
import { cn } from "@/lib/utils"
import { X, Sparkles, DollarSign, UserPlus, Star, Radio } from "lucide-react"
import type { StreamEventType } from "../events-bus"

interface AlertBannerProps {
  patchId: string
  className?: string
  autoHide?: boolean
  hideDelay?: number
  position?: "top" | "bottom"
  theme?: "akashic" | "corporate"
}

const EVENT_ICONS: Record<StreamEventType, typeof Sparkles> = {
  donation: DollarSign,
  follow: UserPlus,
  subscription: Star,
  host: Radio,
  raid: Sparkles,
  bits: Sparkles,
  superchat: DollarSign,
  custom: Sparkles,
}

const EVENT_COLORS: Record<StreamEventType, string> = {
  donation: "from-green-500/20 to-green-500/5 border-green-500/30",
  follow: "from-blue-500/20 to-blue-500/5 border-blue-500/30",
  subscription: "from-purple-500/20 to-purple-500/5 border-purple-500/30",
  host: "from-orange-500/20 to-orange-500/5 border-orange-500/30",
  raid: "from-red-500/20 to-red-500/5 border-red-500/30",
  bits: "from-cyan-500/20 to-cyan-500/5 border-cyan-500/30",
  superchat: "from-yellow-500/20 to-yellow-500/5 border-yellow-500/30",
  custom: "from-pink-500/20 to-pink-500/5 border-pink-500/30",
}

export function AlertBanner({
  patchId,
  className,
  autoHide = true,
  hideDelay = 8000,
  position = "top",
  theme = "corporate",
}: AlertBannerProps) {
  const { latestEvent } = useStreamlabsEvents(patchId, { limit: 1 })
  const [visible, setVisible] = useState(false)
  const [currentEvent, setCurrentEvent] = useState(latestEvent)

  useEffect(() => {
    if (latestEvent && latestEvent.id !== currentEvent?.id) {
      setCurrentEvent(latestEvent)
      setVisible(true)

      if (autoHide) {
        const timer = setTimeout(() => setVisible(false), hideDelay)
        return () => clearTimeout(timer)
      }
    }
  }, [latestEvent, currentEvent, autoHide, hideDelay])

  if (!visible || !currentEvent) return null

  const Icon = EVENT_ICONS[currentEvent.type] || Sparkles
  const colorClass = EVENT_COLORS[currentEvent.type] || EVENT_COLORS.custom

  return (
    <div
      className={cn(
        "fixed left-0 right-0 z-50 px-4 transition-all duration-500",
        position === "top" ? "top-4" : "bottom-4",
        visible ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-full",
        className,
      )}
    >
      <div
        className={cn(
          "max-w-2xl mx-auto rounded-xl border bg-gradient-to-r p-4",
          colorClass,
          theme === "akashic" && "border-[#FF3131]/30 bg-black/90",
        )}
      >
        <div className="flex items-center gap-4">
          <div
            className={cn(
              "h-12 w-12 rounded-full flex items-center justify-center",
              theme === "akashic" ? "bg-[#00FFFF]/20" : "bg-white/10",
            )}
          >
            <Icon className={cn("h-6 w-6", theme === "akashic" ? "text-[#00FFFF]" : "text-white")} />
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className={cn("font-bold", theme === "akashic" ? "text-[#00FFFF]" : "text-foreground")}>
                {currentEvent.payload.displayName || currentEvent.payload.username}
              </span>
              {currentEvent.type === "donation" && (
                <span className="text-green-500 font-bold">
                  {currentEvent.payload.currency}
                  {currentEvent.payload.amount}
                </span>
              )}
            </div>
            {currentEvent.payload.message && (
              <p className={cn("text-sm truncate", theme === "akashic" ? "text-white/70" : "text-muted-foreground")}>
                {currentEvent.payload.message}
              </p>
            )}
          </div>

          <button
            onClick={() => setVisible(false)}
            className={cn(
              "p-2 rounded-lg transition-colors",
              theme === "akashic"
                ? "hover:bg-[#FF3131]/20 text-white/50 hover:text-white"
                : "hover:bg-white/10 text-muted-foreground hover:text-foreground",
            )}
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Animated border for akashic theme */}
        {theme === "akashic" && (
          <div className="absolute inset-0 rounded-xl border border-[#00FFFF]/20 animate-pulse pointer-events-none" />
        )}
      </div>
    </div>
  )
}
