"use client"

import { useStreamStatus } from "../hooks"
import { cn } from "@/lib/utils"
import { Radio } from "lucide-react"

interface NowLiveBadgeProps {
  patchId: string
  className?: string
  size?: "sm" | "md" | "lg"
  showLabel?: boolean
  pulseAnimation?: boolean
  linkToStream?: boolean
}

export function NowLiveBadge({
  patchId,
  className,
  size = "md",
  showLabel = true,
  pulseAnimation = true,
  linkToStream = true,
}: NowLiveBadgeProps) {
  const { isLive, streamUrl } = useStreamStatus(patchId)

  if (!isLive) return null

  const sizeClasses = {
    sm: "text-xs px-2 py-0.5 gap-1",
    md: "text-sm px-3 py-1 gap-1.5",
    lg: "text-base px-4 py-1.5 gap-2",
  }

  const iconSizes = {
    sm: "h-3 w-3",
    md: "h-4 w-4",
    lg: "h-5 w-5",
  }

  const badge = (
    <span
      className={cn(
        "inline-flex items-center rounded-full font-bold uppercase tracking-wider",
        "bg-red-500 text-white",
        pulseAnimation && "animate-pulse",
        sizeClasses[size],
        className,
      )}
    >
      <Radio className={cn(iconSizes[size], "animate-pulse")} />
      {showLabel && <span>LIVE</span>}
    </span>
  )

  if (linkToStream && streamUrl) {
    return (
      <a
        href={streamUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-block hover:scale-105 transition-transform"
      >
        {badge}
      </a>
    )
  }

  return badge
}
