"use client"

import { useStreamlabsEvents } from "../hooks"
import { cn } from "@/lib/utils"
import { DollarSign, Heart, Loader2 } from "lucide-react"
import { formatDistanceToNow } from "date-fns"

interface TipFeedProps {
  patchId: string
  className?: string
  limit?: number
  showMessages?: boolean
  variant?: "list" | "ticker" | "cards"
}

export function TipFeed({ patchId, className, limit = 10, showMessages = true, variant = "list" }: TipFeedProps) {
  const { events, loading, error } = useStreamlabsEvents(patchId, {
    types: ["donation"],
    limit,
  })

  if (loading) {
    return (
      <div className={cn("flex items-center justify-center p-8", className)}>
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (error) {
    return <div className={cn("text-sm text-destructive p-4 text-center", className)}>Failed to load tips</div>
  }

  if (events.length === 0) {
    return (
      <div className={cn("text-sm text-muted-foreground p-4 text-center", className)}>No tips yet — be the first!</div>
    )
  }

  if (variant === "ticker") {
    return (
      <div className={cn("overflow-hidden", className)}>
        <div className="flex animate-marquee gap-8">
          {events.map((event) => (
            <div key={event.id} className="flex items-center gap-2 whitespace-nowrap text-sm">
              <DollarSign className="h-4 w-4 text-green-500" />
              <span className="font-medium text-foreground">{event.payload.displayName || event.payload.username}</span>
              <span className="text-green-500 font-bold">
                {event.payload.currency}
                {event.payload.amount}
              </span>
            </div>
          ))}
        </div>
      </div>
    )
  }

  if (variant === "cards") {
    return (
      <div className={cn("grid gap-3 sm:grid-cols-2", className)}>
        {events.map((event) => (
          <div
            key={event.id}
            className="relative overflow-hidden rounded-lg border border-green-500/20 bg-green-500/5 p-4"
          >
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-full bg-green-500/20 flex items-center justify-center">
                  <Heart className="h-4 w-4 text-green-500" />
                </div>
                <div>
                  <div className="font-medium text-sm">{event.payload.displayName || event.payload.username}</div>
                  <div className="text-xs text-muted-foreground">
                    {formatDistanceToNow(event.timestamp, { addSuffix: true })}
                  </div>
                </div>
              </div>
              <div className="text-lg font-bold text-green-500">
                {event.payload.currency}
                {event.payload.amount}
              </div>
            </div>
            {showMessages && event.payload.message && (
              <p className="text-sm text-muted-foreground line-clamp-2">"{event.payload.message}"</p>
            )}
          </div>
        ))}
      </div>
    )
  }

  // Default list variant
  return (
    <div className={cn("space-y-2", className)}>
      {events.map((event) => (
        <div
          key={event.id}
          className="flex items-center gap-3 p-3 rounded-lg bg-card/50 border border-border/50 hover:border-green-500/30 transition-colors"
        >
          <div className="h-10 w-10 rounded-full bg-green-500/10 flex items-center justify-center flex-shrink-0">
            <DollarSign className="h-5 w-5 text-green-500" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2">
              <span className="font-medium text-sm truncate">
                {event.payload.displayName || event.payload.username}
              </span>
              <span className="text-green-500 font-bold text-sm whitespace-nowrap">
                {event.payload.currency}
                {event.payload.amount}
              </span>
            </div>
            {showMessages && event.payload.message && (
              <p className="text-xs text-muted-foreground truncate mt-0.5">{event.payload.message}</p>
            )}
            <p className="text-xs text-muted-foreground/60 mt-1">
              {formatDistanceToNow(event.timestamp, { addSuffix: true })}
            </p>
          </div>
        </div>
      ))}
    </div>
  )
}
