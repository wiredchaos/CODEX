"use client"

import { useStreamStatus } from "../hooks"
import { cn } from "@/lib/utils"
import { Radio, WifiOff, Activity } from "lucide-react"

interface StreamStatusCardProps {
  patchId: string
  className?: string
  variant?: "default" | "compact" | "minimal"
  showRecentActivity?: boolean
}

export function StreamStatusCard({
  patchId,
  className,
  variant = "default",
  showRecentActivity = true,
}: StreamStatusCardProps) {
  const { isLive, status, lastEvent, recentActivity, loading, streamUrl } = useStreamStatus(patchId)

  if (loading) {
    return (
      <div className={cn("animate-pulse bg-card/50 rounded-lg p-4", className)}>
        <div className="h-4 bg-muted rounded w-24 mb-2" />
        <div className="h-3 bg-muted rounded w-32" />
      </div>
    )
  }

  if (variant === "minimal") {
    return (
      <div className={cn("flex items-center gap-2", className)}>
        <span
          className={cn("h-2 w-2 rounded-full", isLive ? "bg-green-500 animate-pulse" : "bg-muted-foreground/50")}
        />
        <span className="text-xs text-muted-foreground">{isLive ? "LIVE" : "OFFLINE"}</span>
      </div>
    )
  }

  if (variant === "compact") {
    return (
      <div
        className={cn(
          "flex items-center gap-3 px-3 py-2 rounded-lg border transition-all",
          isLive ? "border-green-500/30 bg-green-500/10" : "border-border bg-card/50",
          className,
        )}
      >
        {isLive ? (
          <Radio className="h-4 w-4 text-green-500 animate-pulse" />
        ) : (
          <WifiOff className="h-4 w-4 text-muted-foreground" />
        )}
        <span className={cn("text-sm font-medium", isLive ? "text-green-500" : "text-muted-foreground")}>
          {isLive ? "LIVE NOW" : "Offline"}
        </span>
      </div>
    )
  }

  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-xl border p-4 transition-all",
        isLive ? "border-green-500/30 bg-gradient-to-br from-green-500/10 to-transparent" : "border-border bg-card/50",
        className,
      )}
    >
      {/* Status indicator */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          {isLive ? (
            <>
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500" />
              </span>
              <span className="text-sm font-bold text-green-500 uppercase tracking-wider">Live</span>
            </>
          ) : (
            <>
              <WifiOff className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium text-muted-foreground">Offline</span>
            </>
          )}
        </div>
        {isLive && streamUrl && (
          <a
            href={streamUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-cyan-400 hover:text-cyan-300 transition-colors"
          >
            Watch Stream →
          </a>
        )}
      </div>

      {/* Last event */}
      {lastEvent && (
        <div className="text-sm text-muted-foreground mb-2">
          <span className="text-foreground font-medium">
            {lastEvent.payload.displayName || lastEvent.payload.username}
          </span>{" "}
          {lastEvent.type === "donation" && `donated ${lastEvent.payload.currency}${lastEvent.payload.amount}`}
          {lastEvent.type === "follow" && "followed"}
          {lastEvent.type === "subscription" && "subscribed"}
          {lastEvent.type === "raid" && `raided with ${lastEvent.payload.viewers} viewers`}
        </div>
      )}

      {/* Recent activity */}
      {showRecentActivity && (
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Activity className="h-3 w-3" />
          <span>{recentActivity} events in last 5 min</span>
        </div>
      )}

      {/* Glow effect when live */}
      {isLive && (
        <div className="absolute inset-0 bg-gradient-to-r from-green-500/5 via-transparent to-green-500/5 pointer-events-none" />
      )}
    </div>
  )
}
