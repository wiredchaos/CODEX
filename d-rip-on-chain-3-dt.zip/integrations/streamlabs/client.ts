/**
 * WIRED CHAOS META - Streamlabs API Client
 * Global integration layer for all patches
 */

export interface StreamlabsTokens {
  access_token: string
  refresh_token: string
  expires_at: number
}

export interface StreamlabsUser {
  id: string
  username: string
  display_name: string
  avatar: string
}

export interface StreamlabsDonation {
  donation_id: string
  name: string
  message: string
  amount: string
  currency: string
  created_at: string
}

export interface StreamlabsAlert {
  type: "donation" | "follow" | "subscription" | "host" | "raid" | "bits" | "custom"
  message: string
  user_message?: string
  duration?: number
  special_text_color?: string
}

// In-memory token storage (replace with secure DB storage in production)
let storedTokens: StreamlabsTokens | null = null

export class StreamlabsClient {
  private clientId: string
  private clientSecret: string
  private redirectUri: string
  private baseUrl = "https://streamlabs.com/api/v2.0"

  constructor() {
    this.clientId = process.env.STREAMLABS_CLIENT_ID || ""
    this.clientSecret = process.env.STREAMLABS_CLIENT_SECRET || ""
    this.redirectUri = process.env.STREAMLABS_REDIRECT_URI || ""
  }

  /**
   * Generate OAuth authorization URL
   */
  getAuthUrl(state?: string): string {
    const params = new URLSearchParams({
      client_id: this.clientId,
      redirect_uri: this.redirectUri,
      response_type: "code",
      scope: "donations.read donations.create alerts.create alerts.write socket.token",
    })
    if (state) params.set("state", state)
    return `https://streamlabs.com/api/v2.0/authorize?${params.toString()}`
  }

  /**
   * Exchange authorization code for tokens
   */
  async exchangeCode(code: string): Promise<StreamlabsTokens> {
    const response = await fetch(`${this.baseUrl}/token`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        grant_type: "authorization_code",
        client_id: this.clientId,
        client_secret: this.clientSecret,
        redirect_uri: this.redirectUri,
        code,
      }),
    })

    if (!response.ok) {
      throw new Error(`Token exchange failed: ${response.statusText}`)
    }

    const data = await response.json()
    const tokens: StreamlabsTokens = {
      access_token: data.access_token,
      refresh_token: data.refresh_token,
      expires_at: Date.now() + data.expires_in * 1000,
    }

    storedTokens = tokens
    return tokens
  }

  /**
   * Refresh access token
   */
  async refreshTokens(): Promise<StreamlabsTokens> {
    if (!storedTokens?.refresh_token) {
      throw new Error("No refresh token available")
    }

    const response = await fetch(`${this.baseUrl}/token`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        grant_type: "refresh_token",
        client_id: this.clientId,
        client_secret: this.clientSecret,
        refresh_token: storedTokens.refresh_token,
      }),
    })

    if (!response.ok) {
      throw new Error(`Token refresh failed: ${response.statusText}`)
    }

    const data = await response.json()
    const tokens: StreamlabsTokens = {
      access_token: data.access_token,
      refresh_token: data.refresh_token || storedTokens.refresh_token,
      expires_at: Date.now() + data.expires_in * 1000,
    }

    storedTokens = tokens
    return tokens
  }

  /**
   * Get valid access token (refreshes if expired)
   */
  async getAccessToken(): Promise<string> {
    if (!storedTokens) {
      throw new Error("Not authenticated with Streamlabs")
    }

    if (Date.now() >= storedTokens.expires_at - 60000) {
      await this.refreshTokens()
    }

    return storedTokens.access_token
  }

  /**
   * Check if authenticated
   */
  isAuthenticated(): boolean {
    return storedTokens !== null
  }

  /**
   * Generic GET request
   */
  async get<T>(endpoint: string): Promise<T> {
    const token = await this.getAccessToken()
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    })

    if (!response.ok) {
      throw new Error(`GET ${endpoint} failed: ${response.statusText}`)
    }

    return response.json()
  }

  /**
   * Generic POST request
   */
  async post<T>(endpoint: string, data: Record<string, unknown>): Promise<T> {
    const token = await this.getAccessToken()
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    })

    if (!response.ok) {
      throw new Error(`POST ${endpoint} failed: ${response.statusText}`)
    }

    return response.json()
  }

  /**
   * Get current user info
   */
  async getUser(): Promise<StreamlabsUser> {
    return this.get<StreamlabsUser>("/user")
  }

  /**
   * Get recent donations
   */
  async getDonations(limit = 25): Promise<StreamlabsDonation[]> {
    const data = await this.get<{ data: StreamlabsDonation[] }>(`/donations?limit=${limit}`)
    return data.data
  }

  /**
   * Create a custom alert
   */
  async createAlert(alert: StreamlabsAlert): Promise<void> {
    await this.post("/alerts", alert)
  }

  /**
   * Get socket token for real-time events
   */
  async getSocketToken(): Promise<string> {
    const data = await this.get<{ socket_token: string }>("/socket/token")
    return data.socket_token
  }
}

// Singleton instance
export const streamlabsClient = new StreamlabsClient()
