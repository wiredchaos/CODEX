/**
 * WIRED CHAOS META - Streamlabs Event Bus
 * Routes events to patches with filtering
 */

export type StreamEventType = "donation" | "follow" | "subscription" | "host" | "raid" | "bits" | "superchat" | "custom"

export interface StreamEvent {
  id: string
  type: StreamEventType
  patchId?: string
  timestamp: number
  payload: {
    username?: string
    displayName?: string
    message?: string
    amount?: number
    currency?: string
    tier?: string
    viewers?: number
    months?: number
    [key: string]: unknown
  }
  metadata?: {
    source: "streamlabs" | "manual"
    processed: boolean
    alertSent: boolean
  }
}

export interface EventFilters {
  types?: StreamEventType[]
  since?: number
  until?: number
  limit?: number
  username?: string
}

// In-memory event store (replace with DB in production)
const eventStore: StreamEvent[] = []
const MAX_EVENTS = 1000

/**
 * Publish an event to the bus
 */
export function publishEvent(event: Omit<StreamEvent, "id" | "timestamp">, patchId?: string): StreamEvent {
  const fullEvent: StreamEvent = {
    ...event,
    id: `evt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    timestamp: Date.now(),
    patchId,
    metadata: {
      source: "streamlabs",
      processed: false,
      alertSent: false,
      ...event.metadata,
    },
  }

  eventStore.unshift(fullEvent)

  // Trim to max size
  if (eventStore.length > MAX_EVENTS) {
    eventStore.pop()
  }

  return fullEvent
}

/**
 * Get events for a specific patch with optional filters
 */
export function getEventsForPatch(patchId: string, filters?: EventFilters): StreamEvent[] {
  let events = eventStore.filter((e) => !e.patchId || e.patchId === patchId)

  if (filters?.types?.length) {
    events = events.filter((e) => filters.types!.includes(e.type))
  }

  if (filters?.since) {
    events = events.filter((e) => e.timestamp >= filters.since!)
  }

  if (filters?.until) {
    events = events.filter((e) => e.timestamp <= filters.until!)
  }

  if (filters?.username) {
    events = events.filter(
      (e) =>
        e.payload.username?.toLowerCase() === filters.username!.toLowerCase() ||
        e.payload.displayName?.toLowerCase() === filters.username!.toLowerCase(),
    )
  }

  if (filters?.limit) {
    events = events.slice(0, filters.limit)
  }

  return events
}

/**
 * Get all events (admin use only)
 */
export function getAllEvents(filters?: EventFilters): StreamEvent[] {
  let events = [...eventStore]

  if (filters?.types?.length) {
    events = events.filter((e) => filters.types!.includes(e.type))
  }

  if (filters?.since) {
    events = events.filter((e) => e.timestamp >= filters.since!)
  }

  if (filters?.limit) {
    events = events.slice(0, filters.limit)
  }

  return events
}

/**
 * Get the latest event for a patch
 */
export function getLatestEvent(patchId: string): StreamEvent | null {
  return eventStore.find((e) => !e.patchId || e.patchId === patchId) || null
}

/**
 * Mark an event as processed
 */
export function markEventProcessed(eventId: string): void {
  const event = eventStore.find((e) => e.id === eventId)
  if (event?.metadata) {
    event.metadata.processed = true
  }
}

/**
 * Mark an event as alerted
 */
export function markEventAlerted(eventId: string): void {
  const event = eventStore.find((e) => e.id === eventId)
  if (event?.metadata) {
    event.metadata.alertSent = true
  }
}

/**
 * Get event statistics for a patch
 */
export function getEventStats(patchId: string): {
  total: number
  byType: Record<StreamEventType, number>
  totalDonations: number
  recentActivity: number
} {
  const events = getEventsForPatch(patchId)
  const now = Date.now()
  const oneHourAgo = now - 60 * 60 * 1000

  const byType = events.reduce(
    (acc, e) => {
      acc[e.type] = (acc[e.type] || 0) + 1
      return acc
    },
    {} as Record<StreamEventType, number>,
  )

  const totalDonations = events
    .filter((e) => e.type === "donation")
    .reduce((sum, e) => sum + (e.payload.amount || 0), 0)

  const recentActivity = events.filter((e) => e.timestamp > oneHourAgo).length

  return {
    total: events.length,
    byType,
    totalDonations,
    recentActivity,
  }
}
