"use client"

import { useState, useEffect, useCallback } from "react"
import type { StreamEvent, EventFilters } from "./events-bus"

export interface UseStreamlabsEventsOptions extends EventFilters {
  pollInterval?: number
  autoRefresh?: boolean
}

export interface StreamlabsEventsResult {
  events: StreamEvent[]
  loading: boolean
  error: Error | null
  refresh: () => Promise<void>
  latestEvent: StreamEvent | null
}

/**
 * Hook to subscribe to Streamlabs events for a patch
 */
export function useStreamlabsEvents(patchId: string, options: UseStreamlabsEventsOptions = {}): StreamlabsEventsResult {
  const { pollInterval = 10000, autoRefresh = true, ...filters } = options
  const [events, setEvents] = useState<StreamEvent[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)

  const fetchEvents = useCallback(async () => {
    try {
      const params = new URLSearchParams({ patchId })
      if (filters.types?.length) params.set("types", filters.types.join(","))
      if (filters.limit) params.set("limit", String(filters.limit))
      if (filters.since) params.set("since", String(filters.since))

      const response = await fetch(`/api/streamlabs/events?${params}`)
      if (!response.ok) throw new Error("Failed to fetch events")

      const data = await response.json()
      setEvents(data.events || [])
      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err : new Error("Unknown error"))
    } finally {
      setLoading(false)
    }
  }, [patchId, filters.types, filters.limit, filters.since])

  useEffect(() => {
    fetchEvents()

    if (autoRefresh && pollInterval > 0) {
      const interval = setInterval(fetchEvents, pollInterval)
      return () => clearInterval(interval)
    }
  }, [fetchEvents, autoRefresh, pollInterval])

  return {
    events,
    loading,
    error,
    refresh: fetchEvents,
    latestEvent: events[0] || null,
  }
}

export interface StreamStatusResult {
  isLive: boolean
  status: "live" | "offline" | "unknown"
  lastEvent: StreamEvent | null
  recentActivity: number
  streamUrl?: string
  loading: boolean
  error: Error | null
}

/**
 * Hook to get stream status for a patch
 */
export function useStreamStatus(patchId: string): StreamStatusResult {
  const [status, setStatus] = useState<StreamStatusResult>({
    isLive: false,
    status: "unknown",
    lastEvent: null,
    recentActivity: 0,
    loading: true,
    error: null,
  })

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const response = await fetch(`/api/streamlabs/events?patchId=${patchId}&limit=10`)
        if (!response.ok) throw new Error("Failed to fetch status")

        const data = await response.json()
        const events: StreamEvent[] = data.events || []
        const now = Date.now()
        const fiveMinutesAgo = now - 5 * 60 * 1000

        // Consider "live" if there's recent activity
        const recentEvents = events.filter((e) => e.timestamp > fiveMinutesAgo)
        const isLive = recentEvents.length > 0

        setStatus({
          isLive,
          status: isLive ? "live" : "offline",
          lastEvent: events[0] || null,
          recentActivity: recentEvents.length,
          streamUrl: data.streamUrl,
          loading: false,
          error: null,
        })
      } catch (err) {
        setStatus((prev) => ({
          ...prev,
          loading: false,
          error: err instanceof Error ? err : new Error("Unknown error"),
        }))
      }
    }

    fetchStatus()
    const interval = setInterval(fetchStatus, 30000) // Check every 30s
    return () => clearInterval(interval)
  }, [patchId])

  return status
}

export interface DonationStatsResult {
  total: number
  count: number
  topDonor?: { name: string; amount: number }
  recentDonations: StreamEvent[]
  loading: boolean
}

/**
 * Hook to get donation statistics for a patch
 */
export function useDonationStats(patchId: string): DonationStatsResult {
  const [stats, setStats] = useState<DonationStatsResult>({
    total: 0,
    count: 0,
    recentDonations: [],
    loading: true,
  })

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const response = await fetch(`/api/streamlabs/events?patchId=${patchId}&types=donation&limit=50`)
        if (!response.ok) throw new Error("Failed to fetch stats")

        const data = await response.json()
        const donations: StreamEvent[] = data.events || []

        const total = donations.reduce((sum, d) => sum + (d.payload.amount || 0), 0)

        // Find top donor
        const donorTotals = donations.reduce(
          (acc, d) => {
            const name = d.payload.displayName || d.payload.username || "Anonymous"
            acc[name] = (acc[name] || 0) + (d.payload.amount || 0)
            return acc
          },
          {} as Record<string, number>,
        )

        const topDonorEntry = Object.entries(donorTotals).sort((a, b) => b[1] - a[1])[0]

        setStats({
          total,
          count: donations.length,
          topDonor: topDonorEntry ? { name: topDonorEntry[0], amount: topDonorEntry[1] } : undefined,
          recentDonations: donations.slice(0, 5),
          loading: false,
        })
      } catch {
        setStats((prev) => ({ ...prev, loading: false }))
      }
    }

    fetchStats()
    const interval = setInterval(fetchStats, 60000)
    return () => clearInterval(interval)
  }, [patchId])

  return stats
}
