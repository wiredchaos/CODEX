# WIRED CHAOS META - Streamlabs Integration Layer

A global integration layer that provides Streamlabs connectivity, alerts, and event routing to all patches via a shared client, event bus, and React hooks — with strict firewalls and per-patch opt-in.

## Overview

This integration layer enables any WIRED CHAOS patch to:
- Receive real-time donation, follow, subscription, and raid alerts
- Display stream status and tip feeds
- Show contextual alert banners
- Access donation statistics and event history

## Environment Variables

Add these to your Vercel project:

```env
STREAMLABS_CLIENT_ID=your_client_id
STREAMLABS_CLIENT_SECRET=your_client_secret
STREAMLABS_REDIRECT_URI=https://your-domain.com/api/streamlabs/auth
STREAMLABS_WEBHOOK_SECRET=your_webhook_secret
```

## Setup Instructions

### 1. Create Streamlabs App

1. Go to [Streamlabs Developer Portal](https://streamlabs.com/dashboard#/settings/api-settings)
2. Create a new application
3. Set redirect URI to: \`https://your-domain.com/api/streamlabs/auth\`
4. Copy Client ID and Client Secret

### 2. Configure Webhooks

1. In Streamlabs dashboard, go to Alert Box settings
2. Add webhook URL: \`https://your-domain.com/api/streamlabs/webhook\`
3. Enable events: donations, follows, subscriptions, raids

### 3. Connect Account

Navigate to \`/api/streamlabs/connect\` to initiate OAuth flow.

## Usage

### React Components

```tsx
import { StreamStatusCard } from '@/integrations/streamlabs/components/StreamStatusCard'
import { TipFeed } from '@/integrations/streamlabs/components/TipFeed'
import { AlertBanner } from '@/integrations/streamlabs/components/AlertBanner'
import { NowLiveBadge } from '@/integrations/streamlabs/components/NowLiveBadge'

// In your patch page
export default function MyPatchPage() {
  const PATCH_ID = 'MY-PATCH'
  
  return (
    <div>
      <NowLiveBadge patchId={PATCH_ID} />
      <StreamStatusCard patchId={PATCH_ID} />
      <TipFeed patchId={PATCH_ID} limit={5} />
      <AlertBanner patchId={PATCH_ID} theme="akashic" />
    </div>
  )
}
```

### React Hooks

```tsx
import { useStreamlabsEvents, useStreamStatus, useDonationStats } from '@/integrations/streamlabs/hooks'

function MyComponent() {
  const { events, loading, refresh } = useStreamlabsEvents('MY-PATCH', {
    types: ['donation', 'follow'],
    limit: 10,
  })
  
  const { isLive, lastEvent, recentActivity } = useStreamStatus('MY-PATCH')
  
  const { total, topDonor } = useDonationStats('MY-PATCH')
  
  // Use the data...
}
```

## Known Patch IDs

| Patch ID | Display Name |
|----------|--------------|
| 789-STUDIOS | 789 Studios |
| AKIRA-CODEX | Akira Codex |
| CREATOR-CODEX | Creator Codex |
| NPC | NPC Interface |
| CBE | Chaos Builder Exchange |
| 33FM | 33.3 FM Radio |

## API Endpoints

### GET /api/streamlabs/connect
Initiates OAuth flow with Streamlabs.

### GET /api/streamlabs/auth
OAuth callback handler.

### POST /api/streamlabs/webhook
Receives events from Streamlabs. Validates signature and publishes to event bus.

### GET /api/streamlabs/events
Returns filtered events for a patch.

**Parameters:**
- \`patchId\` (required): The patch identifier
- \`types\`: Comma-separated event types (donation,follow,subscription,raid)
- \`limit\`: Max events to return (default: 25, max: 100)
- \`since\`: Unix timestamp to filter events after
- \`stats\`: Set to "true" to include statistics

## Security Notes

- Webhook signatures are verified using HMAC-SHA256
- Each patch can only access its own events (firewall enforced)
- Tokens are stored securely and refreshed automatically
- No patch can modify another patch's configuration

## Firewalls

This integration layer is a **shared service**. Patches may CALL this integration but may NOT:
- Own or modify core integration logic
- Access other patches' event streams
- Bypass the patch registry system
- Modify global Streamlabs configuration

## Component Variants

### StreamStatusCard
- \`default\`: Full card with activity stats
- \`compact\`: Inline status indicator
- \`minimal\`: Dot + text only

### TipFeed
- \`list\`: Vertical list (default)
- \`cards\`: Grid of donation cards
- \`ticker\`: Horizontal scrolling marquee

### AlertBanner
- Supports \`akashic\` and \`corporate\` themes
- Auto-hide with configurable delay
- Top or bottom positioning
