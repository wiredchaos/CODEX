import type { ReactNode } from "react"

interface FilmCardProps {
  title: string
  subtitle?: string
  chapter?: string
  children?: ReactNode
  accentColor?: "red" | "cyan"
}

export function FilmCard({ title, subtitle, chapter, children, accentColor = "red" }: FilmCardProps) {
  const accent = accentColor === "red" ? "#FF3131" : "#00FFFF"

  return (
    <div className="rupture-card rounded-lg p-6 relative">
      <div className="rupture-accent-bar" style={{ background: accent, boxShadow: `0 0 20px ${accent}` }} />

      <div className="pl-4">
        {chapter && <span className="film-label mb-4 block w-fit">{chapter}</span>}

        <h3
          className="text-xl font-bold tracking-wider mb-2"
          style={{ color: accent, textShadow: `0 0 10px ${accent}` }}
        >
          {title}
        </h3>

        {subtitle && <p className="text-sm text-white/60 font-mono tracking-wide mb-4">{subtitle}</p>}

        {children}
      </div>
    </div>
  )
}
