import Link from "next/link"

interface EnterChaosCTAProps {
  href: string
  label?: string
}

export function EnterChaosCTA({ href, label = "ENTER THE CHAOS" }: EnterChaosCTAProps) {
  return (
    <div className="flex justify-center py-12">
      <Link href={href} className="rupture-cta">
        {label}
      </Link>
    </div>
  )
}
