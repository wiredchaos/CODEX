interface CinematicHeaderProps {
  title: string
  subtitle?: string
  chapter?: string
  tagline?: string
  classification?: string
}

export function CinematicHeader({ title, subtitle, chapter, tagline, classification }: CinematicHeaderProps) {
  return (
    <div className="relative min-h-[60vh] flex flex-col items-center justify-center text-center px-4 overflow-hidden">
      {/* Ambient glow effects */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#FF3131] rounded-full ambient-pulse opacity-20" />
      <div
        className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-[#00FFFF] rounded-full ambient-pulse opacity-15"
        style={{ animationDelay: "1.5s" }}
      />

      {/* Red vertical bars */}
      <div className="absolute left-8 top-0 bottom-0 w-1 bg-[#FF3131]/30" />
      <div className="absolute right-8 top-0 bottom-0 w-1 bg-[#FF3131]/30" />

      <div className="relative z-10 space-y-6">
        {classification && (
          <div className="text-xs font-mono tracking-[0.3em] text-zinc-500 uppercase">{classification}</div>
        )}

        {chapter && <div className="film-label">{chapter}</div>}

        <h1 className="rupture-title">{title}</h1>

        {subtitle && <p className="rupture-subtitle">{subtitle}</p>}

        {tagline && <p className="film-quote">"{tagline}"</p>}
      </div>
    </div>
  )
}
