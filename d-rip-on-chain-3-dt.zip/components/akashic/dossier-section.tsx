import type { ReactNode } from "react"

interface DossierSectionProps {
  title: string
  classification?: string
  children: ReactNode
}

export function DossierSection({ title, classification = "CLASSIFIED", children }: DossierSectionProps) {
  return (
    <section className="relative my-12">
      {/* Top border line */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#FF3131] to-transparent" />

      <div className="pt-6 pb-8">
        <div className="flex items-center gap-4 mb-6">
          <span className="film-label">{classification}</span>
          <h2 className="text-lg font-mono tracking-[0.3em] text-[#00FFFF]">{title}</h2>
        </div>

        <div className="text-white/70 leading-relaxed">{children}</div>
      </div>

      {/* Bottom border line */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#FF3131] to-transparent" />
    </section>
  )
}
