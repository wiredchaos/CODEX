"use client"

import type React from "react"

import { cn } from "@/lib/utils"

interface AuronBadgeProps {
  children: React.ReactNode
  color?: "cyan" | "red" | "green" | "black"
  pulse?: boolean
  className?: string
}

const colorMap = {
  cyan: {
    bg: "bg-[#00FFFF]/10",
    text: "text-[#00FFFF]",
    border: "border-[#00FFFF]/40",
    glow: "shadow-[0_0_10px_rgba(0,255,255,0.3)]",
  },
  red: {
    bg: "bg-[#FF3131]/10",
    text: "text-[#FF3131]",
    border: "border-[#FF3131]/40",
    glow: "shadow-[0_0_10px_rgba(255,49,49,0.3)]",
  },
  green: {
    bg: "bg-[#39FF14]/10",
    text: "text-[#39FF14]",
    border: "border-[#39FF14]/40",
    glow: "shadow-[0_0_10px_rgba(57,255,20,0.3)]",
  },
  black: {
    bg: "bg-[#0C0C0C]",
    text: "text-zinc-400",
    border: "border-zinc-700",
    glow: "",
  },
}

export function AuronBadge({ children, color = "cyan", pulse = false, className }: AuronBadgeProps) {
  const colors = colorMap[color]

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 px-3 py-1 text-xs font-mono uppercase tracking-wider border rounded-sm",
        colors.bg,
        colors.text,
        colors.border,
        colors.glow,
        pulse && "animate-pulse",
        className,
      )}
    >
      <span className={cn("w-1.5 h-1.5 rounded-full", color === "black" ? "bg-zinc-500" : `bg-current`)} />
      {children}
    </span>
  )
}
