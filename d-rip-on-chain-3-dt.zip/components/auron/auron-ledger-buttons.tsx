"use client"

import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface LedgerButton {
  id: string
  label: string
  active?: boolean
}

interface AuronLedgerButtonsProps {
  buttons?: LedgerButton[]
  onSelect?: (id: string) => void
  activeId?: string
  className?: string
}

const DEFAULT_BUTTONS: LedgerButton[] = [
  { id: "auron_pact", label: "Auron Directive" },
  { id: "etherion_assembly", label: "The Etherion Assembly" },
  { id: "undernet_syndicates", label: "The Undernet Syndicates" },
]

export function AuronLedgerButtons({
  buttons = DEFAULT_BUTTONS,
  onSelect,
  activeId,
  className,
}: AuronLedgerButtonsProps) {
  return (
    <div className={cn("flex flex-wrap gap-2", className)}>
      {buttons.map((btn) => (
        <Button
          key={btn.id}
          variant="outline"
          size="sm"
          onClick={() => onSelect?.(btn.id)}
          className={cn(
            "font-mono text-xs uppercase tracking-wider transition-all",
            activeId === btn.id
              ? "bg-cyan-500/20 text-cyan-400 border-cyan-500/50"
              : "bg-black/40 text-zinc-400 border-zinc-700 hover:border-cyan-500/30 hover:text-cyan-400",
          )}
        >
          [{btn.label}]
        </Button>
      ))}
    </div>
  )
}
