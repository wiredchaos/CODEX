"use client"

import { Card } from "@/components/ui/card"
import { AuronBadge } from "./auron-badge"
import { AuronTag } from "./auron-tag"
import { cn } from "@/lib/utils"

interface AuronFactionCardProps {
  name: string
  description: string
  role: string
  color: string
  connectedPatches: string[]
  isActive?: boolean
  className?: string
}

export function AuronFactionCard({
  name,
  description,
  role,
  color,
  connectedPatches,
  isActive = false,
  className,
}: AuronFactionCardProps) {
  return (
    <Card
      className={cn(
        "bg-black/60 border-zinc-800 p-4 transition-all hover:border-opacity-60",
        isActive && "ring-1 ring-offset-1 ring-offset-black",
        className,
      )}
      style={{
        borderColor: `${color}40`,
        ...(isActive && { ringColor: color }),
      }}
    >
      <div className="flex items-start justify-between mb-3">
        <h3 className="font-bold text-white" style={{ color }}>
          {name}
        </h3>
        {isActive && (
          <AuronBadge color="green" pulse>
            ACTIVE
          </AuronBadge>
        )}
      </div>

      <p className="text-zinc-400 text-sm mb-4">{description}</p>

      <div className="flex items-center gap-2 mb-3">
        <span className="text-zinc-600 text-xs">ROLE:</span>
        <AuronTag variant="directive">{role}</AuronTag>
      </div>

      <div className="flex flex-wrap gap-1">
        {connectedPatches.map((patch) => (
          <AuronTag key={patch} variant="signal">
            {patch.toUpperCase()}
          </AuronTag>
        ))}
      </div>
    </Card>
  )
}
