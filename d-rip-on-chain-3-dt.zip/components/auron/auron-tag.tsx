"use client"

import type React from "react"

import { cn } from "@/lib/utils"

interface AuronTagProps {
  children: React.ReactNode
  variant?: "default" | "directive" | "signal" | "event"
  className?: string
}

export function AuronTag({ children, variant = "default", className }: AuronTagProps) {
  const variantStyles = {
    default: "bg-cyan-500/10 text-cyan-400 border-cyan-500/30",
    directive: "bg-red-500/10 text-red-400 border-red-500/30",
    signal: "bg-green-500/10 text-green-400 border-green-500/30",
    event: "bg-zinc-500/10 text-zinc-400 border-zinc-500/30",
  }

  return (
    <span
      className={cn(
        "inline-flex items-center px-2 py-0.5 text-xs font-mono border rounded",
        variantStyles[variant],
        className,
      )}
    >
      {children}
    </span>
  )
}
