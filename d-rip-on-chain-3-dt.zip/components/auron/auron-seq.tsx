"use client"

import type React from "react"

import { cn } from "@/lib/utils"

interface AuronSeqProps {
  children: React.ReactNode
  classification?: "VERIFIED" | "CLASSIFIED" | "REDACTED" | "AURON"
  className?: string
}

export function AuronSeq({ children, classification = "AURON", className }: AuronSeqProps) {
  const classificationStyles = {
    VERIFIED: "text-green-400 border-green-500/30",
    CLASSIFIED: "text-red-400 border-red-500/30",
    REDACTED: "text-zinc-600 border-zinc-700 line-through",
    AURON: "text-cyan-400 border-cyan-500/30",
  }

  return (
    <div
      className={cn(
        "inline-flex items-center gap-2 px-3 py-1.5 bg-black/60 border rounded font-mono text-xs",
        classificationStyles[classification],
        className,
      )}
    >
      <span className="text-zinc-600">[</span>
      <span className="uppercase tracking-wider">{classification}</span>
      <span className="text-zinc-600">]</span>
      <span className="text-zinc-400">—</span>
      <span>{children}</span>
    </div>
  )
}
