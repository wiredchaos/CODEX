import Link from "next/link"
import type { LucideIcon } from "lucide-react"
import { cn } from "@/lib/utils"

interface RoomCardProps {
  name: string
  description: string
  href: string
  icon: LucideIcon
  color: string
  status?: "active" | "locked" | "coming-soon"
}

export function RoomCard({ name, description, href, icon: Icon, color, status = "active" }: RoomCardProps) {
  const isDisabled = status !== "active"

  return (
    <Link
      href={isDisabled ? "#" : href}
      className={cn(
        "group relative block p-6 rounded-xl border transition-all overflow-hidden",
        isDisabled
          ? "border-neutral-800 bg-neutral-900/30 cursor-not-allowed opacity-60"
          : "border-red-900/50 bg-black/50 hover:border-cyan-500/50 hover:bg-red-950/20",
      )}
    >
      {/* Neon glow effect */}
      {!isDisabled && (
        <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-32 bg-cyan-500/20 blur-3xl" />
        </div>
      )}

      <div className="relative z-10">
        <div
          className={cn(
            "w-12 h-12 rounded-lg flex items-center justify-center mb-4",
            isDisabled ? "bg-neutral-800" : "bg-red-900/30 border border-red-500/30",
          )}
        >
          <Icon className={cn("w-6 h-6", isDisabled ? "text-neutral-600" : color)} />
        </div>

        <h3
          className={cn(
            "text-lg font-semibold mb-2",
            isDisabled ? "text-neutral-500" : "text-white group-hover:text-cyan-400 transition-colors",
          )}
        >
          {name}
        </h3>

        <p className="text-sm text-neutral-500">{description}</p>

        {status === "locked" && (
          <span className="mt-3 inline-block px-2 py-1 text-xs bg-yellow-900/30 border border-yellow-500/30 rounded text-yellow-400">
            Requires Verification
          </span>
        )}
        {status === "coming-soon" && (
          <span className="mt-3 inline-block px-2 py-1 text-xs bg-neutral-800 border border-neutral-700 rounded text-neutral-400">
            Coming Soon
          </span>
        )}
      </div>

      {/* Circuit trace decoration */}
      {!isDisabled && (
        <div className="absolute bottom-0 right-0 w-24 h-24 opacity-10">
          <svg viewBox="0 0 100 100" className="w-full h-full text-cyan-500">
            <path d="M100 100 L100 60 L60 60 L60 30 L30 30 L30 0" stroke="currentColor" fill="none" strokeWidth="2" />
            <circle cx="100" cy="60" r="3" fill="currentColor" />
            <circle cx="60" cy="30" r="3" fill="currentColor" />
          </svg>
        </div>
      )}
    </Link>
  )
}
