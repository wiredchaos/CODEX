"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Shield, Radio, Sliders, Disc, Settings2, Coins, ListMusic, Cpu, Lock } from "lucide-react"
import { cn } from "@/lib/utils"
import { useStudioAccess } from "@/lib/studio/use-studio-access"
import { STUDIO_ROOMS, canAccessRoom } from "@/lib/studio/tiers"

const roomIcons: Record<string, typeof Shield> = {
  overview: Shield,
  gate: Shield,
  "signal-booth": Radio,
  "producer-room": Cpu,
  "mix-room": Sliders,
  "control-room": Settings2,
  mint: Coins,
  playlists: ListMusic,
}

const roomColors: Record<string, string> = {
  overview: "text-cyan-400",
  gate: "text-yellow-400",
  "signal-booth": "text-cyan-400",
  "producer-room": "text-fuchsia-400",
  "mix-room": "text-emerald-400",
  "control-room": "text-orange-400",
  mint: "text-purple-400",
  playlists: "text-blue-400",
}

export function StudioSidebar() {
  const pathname = usePathname()
  const { activeTier, loading } = useStudioAccess()

  return (
    <aside className="w-16 md:w-56 border-r border-red-900/30 bg-black/50 flex flex-col">
      <nav className="flex-1 py-4">
        <div className="px-2 mb-2">
          <Link
            href="/33fm/studio/gate"
            className={cn(
              "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all",
              pathname === "/33fm/studio/gate"
                ? "bg-yellow-900/30 border border-yellow-500/30"
                : "hover:bg-neutral-900/50 border border-transparent",
            )}
          >
            <Shield
              className={cn(
                "w-5 h-5 flex-shrink-0",
                pathname === "/33fm/studio/gate" ? "text-yellow-400" : "text-neutral-500",
              )}
            />
            <span
              className={cn(
                "hidden md:block text-sm font-medium",
                pathname === "/33fm/studio/gate" ? "text-white" : "text-neutral-400",
              )}
            >
              Gate
            </span>
          </Link>
        </div>

        <ul className="space-y-1 px-2">
          {STUDIO_ROOMS.map((room) => {
            const isActive = pathname === room.href
            const Icon = roomIcons[room.id] || Shield
            const color = roomColors[room.id] || "text-cyan-400"
            const hasAccess = !loading && canAccessRoom(activeTier, room)
            const isLocked = room.requiredTier && !hasAccess

            return (
              <li key={room.id}>
                <Link
                  href={isLocked ? "/33fm/studio/gate" : room.href}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all",
                    isActive
                      ? "bg-red-900/30 border border-red-500/30"
                      : "hover:bg-neutral-900/50 border border-transparent",
                    isLocked && "opacity-60",
                  )}
                >
                  <Icon className={cn("w-5 h-5 flex-shrink-0", isActive ? color : "text-neutral-500")} />
                  <span
                    className={cn("hidden md:block text-sm font-medium", isActive ? "text-white" : "text-neutral-400")}
                  >
                    {room.label}
                  </span>
                  {isLocked && <Lock className="hidden md:block ml-auto w-3 h-3 text-pink-400" />}
                  {isActive && !isLocked && (
                    <div className="hidden md:block ml-auto w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                  )}
                </Link>
              </li>
            )
          })}
        </ul>
      </nav>

      {/* Status Panel */}
      <div className="p-3 border-t border-red-900/30">
        <div className="hidden md:flex items-center gap-2 text-xs text-neutral-500">
          <Disc className="w-3 h-3 text-cyan-400 animate-spin" style={{ animationDuration: "3s" }} />
          <span>
            {activeTier ? `${activeTier.charAt(0).toUpperCase() + activeTier.slice(1)} Tier` : "Signal Active"}
          </span>
        </div>
      </div>
    </aside>
  )
}
