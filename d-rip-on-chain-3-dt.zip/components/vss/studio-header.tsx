"use client"

import Link from "next/link"
import { Radio, Zap, User, Settings, ChevronLeft } from "lucide-react"

interface StudioHeaderProps {
  currentRoom?: string
  showBack?: boolean
}

export function StudioHeader({ currentRoom, showBack = true }: StudioHeaderProps) {
  return (
    <header className="sticky top-0 z-50 border-b border-red-900/50 bg-black/90 backdrop-blur-sm">
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-4">
          {showBack && (
            <Link
              href="/33fm/studio"
              className="flex items-center gap-1 text-neutral-400 hover:text-cyan-400 transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
              <span className="text-sm">Studio</span>
            </Link>
          )}
          <div className="flex items-center gap-2">
            <div className="relative">
              <Radio className="w-6 h-6 text-cyan-400" />
              <div className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full animate-pulse" />
            </div>
            <span className="text-lg font-bold tracking-tight">
              <span className="text-cyan-400">VSS</span>
              <span className="text-red-500">-33.3</span>
            </span>
            {currentRoom && (
              <span className="ml-2 px-2 py-0.5 text-xs bg-red-900/30 border border-red-500/30 rounded text-red-400 uppercase">
                {currentRoom.replace("-", " ")}
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button className="p-2 text-neutral-400 hover:text-cyan-400 transition-colors">
            <Zap className="w-5 h-5" />
          </button>
          <button className="p-2 text-neutral-400 hover:text-cyan-400 transition-colors">
            <Settings className="w-5 h-5" />
          </button>
          <button className="p-2 text-neutral-400 hover:text-cyan-400 transition-colors">
            <User className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Neon Motherboard Scanline */}
      <div className="h-px w-full bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent" />
    </header>
  )
}
