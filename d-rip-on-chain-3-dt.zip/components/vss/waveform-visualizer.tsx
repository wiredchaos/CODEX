"use client"

import { useEffect, useRef } from "react"
import { cn } from "@/lib/utils"

interface WaveformVisualizerProps {
  audioUrl?: string
  isPlaying?: boolean
  className?: string
  barCount?: number
  color?: string
}

export function WaveformVisualizer({
  audioUrl,
  isPlaying = false,
  className,
  barCount = 64,
  color = "cyan",
}: WaveformVisualizerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animationRef = useRef<number>()

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const colorMap: Record<string, string> = {
      cyan: "#22d3ee",
      red: "#ef4444",
      fuchsia: "#d946ef",
      green: "#22c55e",
    }

    const barColor = colorMap[color] || colorMap.cyan

    const draw = () => {
      const width = canvas.width
      const height = canvas.height
      const barWidth = width / barCount

      ctx.clearRect(0, 0, width, height)

      for (let i = 0; i < barCount; i++) {
        const barHeight = isPlaying ? Math.random() * height * 0.8 + height * 0.1 : height * 0.2

        const x = i * barWidth
        const y = (height - barHeight) / 2

        ctx.fillStyle = barColor
        ctx.globalAlpha = 0.8
        ctx.fillRect(x + 1, y, barWidth - 2, barHeight)
      }

      if (isPlaying) {
        animationRef.current = requestAnimationFrame(draw)
      }
    }

    draw()

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [isPlaying, barCount, color])

  return (
    <canvas
      ref={canvasRef}
      width={512}
      height={128}
      className={cn("w-full h-16 rounded-lg bg-black/50 border border-red-900/30", className)}
    />
  )
}
