"use client"

import { Volume2, VolumeX, Headphones } from "lucide-react"
import { cn } from "@/lib/utils"
import { WaveformVisualizer } from "./waveform-visualizer"

interface TrackLaneProps {
  name: string
  type: "audio" | "midi" | "drums"
  volume: number
  isMuted: boolean
  isSolo: boolean
  color: string
  onVolumeChange?: (value: number) => void
  onMuteToggle?: () => void
  onSoloToggle?: () => void
}

export function TrackLane({
  name,
  type,
  volume,
  isMuted,
  isSolo,
  color,
  onVolumeChange,
  onMuteToggle,
  onSoloToggle,
}: TrackLaneProps) {
  return (
    <div className="flex items-center gap-3 p-3 bg-black/50 border border-red-900/30 rounded-lg">
      {/* Track Info */}
      <div className="w-32 flex-shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: color }} />
          <span className="text-sm font-medium text-white truncate">{name}</span>
        </div>
        <span className="text-xs text-neutral-500 uppercase">{type}</span>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-2">
        <button
          onClick={onMuteToggle}
          className={cn(
            "p-1.5 rounded transition-colors",
            isMuted ? "bg-red-500/20 text-red-400" : "bg-neutral-800 text-neutral-400 hover:text-white",
          )}
        >
          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </button>
        <button
          onClick={onSoloToggle}
          className={cn(
            "p-1.5 rounded transition-colors",
            isSolo ? "bg-yellow-500/20 text-yellow-400" : "bg-neutral-800 text-neutral-400 hover:text-white",
          )}
        >
          <Headphones className="w-4 h-4" />
        </button>
      </div>

      {/* Volume Slider */}
      <input
        type="range"
        min="0"
        max="100"
        value={volume}
        onChange={(e) => onVolumeChange?.(Number(e.target.value))}
        className="w-20 h-1 bg-neutral-700 rounded-full appearance-none cursor-pointer"
      />
      <span className="w-8 text-xs text-neutral-500 text-right">{volume}%</span>

      {/* Waveform */}
      <div className="flex-1">
        <WaveformVisualizer isPlaying={!isMuted} color={color.replace("#", "")} />
      </div>
    </div>
  )
}
