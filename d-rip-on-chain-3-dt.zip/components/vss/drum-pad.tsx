"use client"

import { useState, useCallback } from "react"
import { cn } from "@/lib/utils"

interface DrumPadProps {
  label: string
  color: string
  soundUrl?: string
  keyBinding?: string
  onTrigger?: () => void
}

export function DrumPad({ label, color, soundUrl, keyBinding, onTrigger }: DrumPadProps) {
  const [isActive, setIsActive] = useState(false)

  const trigger = useCallback(() => {
    setIsActive(true)
    onTrigger?.()

    if (soundUrl) {
      const audio = new Audio(soundUrl)
      audio.play().catch(() => {})
    }

    setTimeout(() => setIsActive(false), 100)
  }, [soundUrl, onTrigger])

  return (
    <button
      onClick={trigger}
      className={cn(
        "relative w-full aspect-square rounded-lg border-2 transition-all",
        "flex flex-col items-center justify-center gap-1",
        isActive
          ? `border-${color}-400 bg-${color}-500/30 scale-95`
          : `border-${color}-900/50 bg-${color}-950/30 hover:border-${color}-500/50`,
      )}
      style={{
        borderColor: isActive ? `var(--${color}-400)` : undefined,
        backgroundColor: isActive ? `rgba(var(--${color}-rgb), 0.3)` : undefined,
      }}
    >
      <span className="text-lg font-bold text-white">{label}</span>
      {keyBinding && <span className="text-xs text-neutral-500 uppercase">{keyBinding}</span>}

      {/* Glow effect when active */}
      {isActive && (
        <div
          className="absolute inset-0 rounded-lg animate-ping opacity-30"
          style={{ backgroundColor: `var(--${color}-500)` }}
        />
      )}
    </button>
  )
}
