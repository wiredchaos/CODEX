"use client"

import { DynamicPreview, type DynamicPreviewMode } from "./dynamic-preview"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import Link from "next/link"

interface ShowCardProps {
  id?: string
  title: string
  logline: string
  /** Local asset: public/videos or public/images */
  mediaSrc: string
  mediaMode?: DynamicPreviewMode
  /** Motion direction for Ken Burns */
  motionDirection?: "zoom-in" | "zoom-out" | "pan-left" | "pan-right" | "pan-up" | "pan-down"
  /** Show status */
  status?: "live" | "upcoming" | "archived" | "in-production"
  /** Genre tags */
  tags?: string[]
  /** Episode count */
  episodeCount?: number
  /** Link to show page */
  href?: string
  /** Glow accent color */
  accentColor?: "cyan" | "red" | "magenta" | "amber"
  /** Show loading animation */
  showLoading?: boolean
}

export function ShowCard({
  id,
  title,
  logline,
  mediaSrc,
  mediaMode = "motion-still",
  motionDirection = "zoom-in",
  status = "upcoming",
  tags = [],
  episodeCount,
  href,
  accentColor = "cyan",
  showLoading = false,
}: ShowCardProps) {
  const statusColors = {
    live: "bg-[#FF3131]/20 text-[#FF3131] border-[#FF3131]/30",
    upcoming: "bg-[#00FFFF]/20 text-[#00FFFF] border-[#00FFFF]/30",
    archived: "bg-zinc-500/20 text-zinc-400 border-zinc-500/30",
    "in-production": "bg-amber-500/20 text-amber-400 border-amber-500/30",
  }

  const statusLabels = {
    live: "LIVE NOW",
    upcoming: "COMING SOON",
    archived: "ARCHIVED",
    "in-production": "IN PRODUCTION",
  }

  const content = (
    <article
      className={cn(
        "rounded-2xl bg-[#05060A] border border-[#00FFFF]/15 p-3 flex flex-col gap-3",
        "hover:border-[#00FFFF]/40 transition-all duration-300",
        "group cursor-pointer",
      )}
    >
      {/* Dynamic Preview */}
      <div className="relative">
        <DynamicPreview
          mode={mediaMode}
          src={mediaSrc}
          placeholderQuery={title}
          label={title}
          glowColor={accentColor}
          motionDirection={motionDirection}
          showLoading={showLoading}
          overlay="bottom"
        />

        {/* Status badge */}
        <div className="absolute top-2 left-2 z-40">
          <Badge
            variant="outline"
            className={cn(
              "text-[9px] font-mono tracking-wider backdrop-blur-sm",
              statusColors[status],
              status === "live" && "animate-pulse",
            )}
          >
            {statusLabels[status]}
          </Badge>
        </div>
      </div>

      {/* Content */}
      <div className="flex flex-col gap-2 px-1">
        <h3 className="text-sm font-semibold text-white group-hover:text-[#00FFFF] transition-colors tracking-wide">
          {title}
        </h3>
        <p className="text-[11px] text-zinc-400 line-clamp-2 leading-relaxed">{logline}</p>

        {/* Tags and meta */}
        <div className="flex items-center justify-between mt-1">
          <div className="flex gap-1.5 flex-wrap">
            {tags.slice(0, 3).map((tag) => (
              <span key={tag} className="text-[9px] font-mono text-zinc-500 bg-zinc-800/50 px-1.5 py-0.5 rounded">
                {tag}
              </span>
            ))}
          </div>
          {episodeCount !== undefined && (
            <span className="text-[9px] font-mono text-zinc-500">
              {episodeCount} EP{episodeCount !== 1 ? "S" : ""}
            </span>
          )}
        </div>
      </div>

      {/* NEURO META X credit */}
      <div className="text-[8px] font-mono text-zinc-600 text-right px-1">NEURO META X</div>
    </article>
  )

  if (href) {
    return <Link href={href}>{content}</Link>
  }

  return content
}
