"use client"

import { useEffect, useState } from "react"
import { cn } from "@/lib/utils"

export type DynamicPreviewMode = "local" | "motion-still"

interface DynamicPreviewProps {
  mode?: DynamicPreviewMode
  /** For local mode, this is a video src; for motion-still, this is an image src */
  src: string
  /** Fallback query for placeholder if src fails */
  placeholderQuery?: string
  /** Optional title / alt text */
  label?: string
  /** Aspect ratio */
  aspect?: "16:9" | "1:1" | "4:3" | "21:9"
  /** Ken Burns direction for motion-still */
  motionDirection?: "zoom-in" | "zoom-out" | "pan-left" | "pan-right" | "pan-up" | "pan-down"
  /** Animation duration in seconds */
  duration?: number
  /** Show fake loading state for drama */
  showLoading?: boolean
  /** Loading duration in ms */
  loadingDuration?: number
  /** Overlay gradient */
  overlay?: "none" | "bottom" | "full" | "vignette"
  /** Border glow color */
  glowColor?: "cyan" | "red" | "magenta" | "amber" | "none"
}

export function DynamicPreview({
  mode = "motion-still",
  src,
  placeholderQuery,
  label,
  aspect = "16:9",
  motionDirection = "zoom-in",
  duration = 18,
  showLoading = false,
  loadingDuration = 1200,
  overlay = "bottom",
  glowColor = "cyan",
}: DynamicPreviewProps) {
  const [ready, setReady] = useState(!showLoading)
  const [hasError, setHasError] = useState(false)

  useEffect(() => {
    if (showLoading) {
      const t = setTimeout(() => setReady(true), loadingDuration)
      return () => clearTimeout(t)
    }
  }, [showLoading, loadingDuration])

  const aspectClass = {
    "16:9": "aspect-video",
    "1:1": "aspect-square",
    "4:3": "aspect-[4/3]",
    "21:9": "aspect-[21/9]",
  }[aspect]

  const glowStyles = {
    cyan: "shadow-[0_0_20px_rgba(0,255,255,0.3)]",
    red: "shadow-[0_0_20px_rgba(255,49,49,0.3)]",
    magenta: "shadow-[0_0_20px_rgba(163,95,255,0.3)]",
    amber: "shadow-[0_0_20px_rgba(251,191,36,0.3)]",
    none: "",
  }[glowColor]

  const overlayStyles = {
    none: "",
    bottom: "bg-gradient-to-t from-black/80 via-black/20 to-transparent",
    full: "bg-black/40",
    vignette: "bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(0,0,0,0.7)_100%)]",
  }[overlay]

  // Motion animation classes based on direction
  const motionClass = {
    "zoom-in": "animate-kenburns-zoom-in",
    "zoom-out": "animate-kenburns-zoom-out",
    "pan-left": "animate-kenburns-pan-left",
    "pan-right": "animate-kenburns-pan-right",
    "pan-up": "animate-kenburns-pan-up",
    "pan-down": "animate-kenburns-pan-down",
  }[motionDirection]

  const imageSrc =
    hasError && placeholderQuery
      ? `/placeholder.svg?height=400&width=711&query=${encodeURIComponent(placeholderQuery)}`
      : src

  // Loading state with dramatic effect
  if (!ready) {
    return (
      <div
        className={cn(
          "relative w-full rounded-xl overflow-hidden bg-black flex items-center justify-center",
          aspectClass,
          glowStyles,
        )}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-[#00FFFF]/5 via-transparent to-[#FF3131]/5" />
        <div className="flex flex-col items-center gap-2">
          <div className="w-6 h-6 border-2 border-[#00FFFF]/30 border-t-[#00FFFF] rounded-full animate-spin" />
          <span className="text-[10px] font-mono text-[#00FFFF]/70 animate-pulse tracking-wider">
            INITIALIZING ANALOG STREAM...
          </span>
        </div>
        {/* Scanline effect */}
        <div className="absolute inset-0 pointer-events-none opacity-20">
          <div className="absolute inset-0 bg-[repeating-linear-gradient(0deg,transparent,transparent_2px,rgba(0,255,255,0.03)_2px,rgba(0,255,255,0.03)_4px)]" />
        </div>
      </div>
    )
  }

  // Local video mode
  if (mode === "local") {
    return (
      <div className={cn("relative w-full rounded-xl overflow-hidden bg-black group", aspectClass, glowStyles)}>
        <video
          className="w-full h-full object-cover"
          src={src}
          autoPlay
          muted
          loop
          playsInline
          onError={() => setHasError(true)}
        />

        {/* Overlay */}
        {overlay !== "none" && <div className={cn("absolute inset-0 pointer-events-none", overlayStyles)} />}

        {/* Label */}
        {label && (
          <div className="absolute bottom-2 left-2 text-[10px] font-mono text-[#00FFFF]/90 bg-black/70 px-2 py-1 rounded backdrop-blur-sm border border-[#00FFFF]/20">
            {label}
          </div>
        )}

        {/* Live indicator for video */}
        <div className="absolute top-2 right-2 flex items-center gap-1.5 bg-black/70 px-2 py-1 rounded backdrop-blur-sm">
          <span className="w-1.5 h-1.5 bg-[#FF3131] rounded-full animate-pulse" />
          <span className="text-[9px] font-mono text-white/80 tracking-wider">LIVE STREAM</span>
        </div>

        {/* Scanlines */}
        <div className="absolute inset-0 pointer-events-none opacity-10 group-hover:opacity-20 transition-opacity">
          <div className="absolute inset-0 bg-[repeating-linear-gradient(0deg,transparent,transparent_2px,rgba(0,0,0,0.1)_2px,rgba(0,0,0,0.1)_4px)]" />
        </div>
      </div>
    )
  }

  // Motion-still mode with Ken Burns effect
  return (
    <div className={cn("relative w-full rounded-xl overflow-hidden bg-black group", aspectClass, glowStyles)}>
      {/* Ambient corner glows */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#00FFFF]/10 via-transparent to-[#FF3131]/10 pointer-events-none z-10 opacity-50 group-hover:opacity-80 transition-opacity" />

      {/* Ken Burns animated background */}
      <div
        className={cn("w-full h-full scale-110 origin-center", motionClass)}
        style={{
          backgroundImage: `url(${imageSrc})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          animationDuration: `${duration}s`,
        }}
      />

      {/* Overlay */}
      {overlay !== "none" && <div className={cn("absolute inset-0 pointer-events-none z-20", overlayStyles)} />}

      {/* Label */}
      {label && (
        <div className="absolute bottom-2 left-2 z-30 text-[10px] font-mono text-[#00FFFF]/90 bg-black/70 px-2 py-1 rounded backdrop-blur-sm border border-[#00FFFF]/20">
          {label}
        </div>
      )}

      {/* Signal indicator */}
      <div className="absolute top-2 right-2 z-30 flex items-center gap-1.5 bg-black/70 px-2 py-1 rounded backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity">
        <span className="text-[9px] font-mono text-[#00FFFF]/80 tracking-wider">SIGNAL ACTIVE</span>
      </div>

      {/* Scanlines */}
      <div className="absolute inset-0 pointer-events-none z-10 opacity-5 group-hover:opacity-10 transition-opacity">
        <div className="absolute inset-0 bg-[repeating-linear-gradient(0deg,transparent,transparent_2px,rgba(0,0,0,0.15)_2px,rgba(0,0,0,0.15)_4px)]" />
      </div>
    </div>
  )
}
