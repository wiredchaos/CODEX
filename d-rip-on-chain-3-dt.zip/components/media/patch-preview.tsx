"use client"

import { DynamicPreview, type DynamicPreviewMode } from "./dynamic-preview"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import Link from "next/link"

interface PatchPreviewProps {
  id: string
  name: string
  description: string
  mediaSrc: string
  mediaMode?: DynamicPreviewMode
  motionDirection?: "zoom-in" | "zoom-out" | "pan-left" | "pan-right" | "pan-up" | "pan-down"
  status?: "active" | "coming-soon" | "archived" | "beta"
  patchType?: "content" | "business" | "lore" | "system"
  href?: string
  accentColor?: "cyan" | "red" | "magenta" | "amber"
}

export function PatchPreview({
  id,
  name,
  description,
  mediaSrc,
  mediaMode = "motion-still",
  motionDirection = "pan-right",
  status = "active",
  patchType = "content",
  href,
  accentColor = "cyan",
}: PatchPreviewProps) {
  const statusConfig = {
    active: { label: "ACTIVE", color: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30" },
    "coming-soon": { label: "COMING SOON", color: "bg-amber-500/20 text-amber-400 border-amber-500/30" },
    archived: { label: "ARCHIVED", color: "bg-zinc-500/20 text-zinc-400 border-zinc-500/30" },
    beta: { label: "BETA", color: "bg-purple-500/20 text-purple-400 border-purple-500/30" },
  }

  const typeConfig = {
    content: { label: "CONTENT", color: "text-[#00FFFF]" },
    business: { label: "BUSINESS", color: "text-amber-400" },
    lore: { label: "LORE", color: "text-[#FF3131]" },
    system: { label: "SYSTEM", color: "text-purple-400" },
  }

  const content = (
    <div
      className={cn(
        "relative rounded-xl overflow-hidden group cursor-pointer",
        "border border-zinc-800 hover:border-[#00FFFF]/30 transition-all duration-300",
      )}
    >
      {/* Preview */}
      <DynamicPreview
        mode={mediaMode}
        src={mediaSrc}
        placeholderQuery={`${name} patch cyberpunk`}
        aspect="16:9"
        motionDirection={motionDirection}
        glowColor={accentColor}
        overlay="vignette"
        duration={20}
      />

      {/* Overlay content */}
      <div className="absolute inset-0 flex flex-col justify-between p-4 z-30">
        {/* Top badges */}
        <div className="flex items-start justify-between">
          <Badge variant="outline" className={cn("text-[8px] font-mono tracking-wider", statusConfig[status].color)}>
            {statusConfig[status].label}
          </Badge>
          <span className={cn("text-[8px] font-mono tracking-wider", typeConfig[patchType].color)}>
            [{typeConfig[patchType].label}]
          </span>
        </div>

        {/* Bottom content */}
        <div className="space-y-1">
          <h3 className="text-lg font-bold text-white group-hover:text-[#00FFFF] transition-colors tracking-wide">
            {name}
          </h3>
          <p className="text-[11px] text-zinc-400 line-clamp-2">{description}</p>
          <div className="text-[9px] font-mono text-zinc-600 pt-1">PATCH::{id.toUpperCase()}</div>
        </div>
      </div>

      {/* Hover glow effect */}
      <div
        className={cn(
          "absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none",
          accentColor === "cyan" && "bg-[#00FFFF]/5",
          accentColor === "red" && "bg-[#FF3131]/5",
          accentColor === "magenta" && "bg-purple-500/5",
          accentColor === "amber" && "bg-amber-500/5",
        )}
      />
    </div>
  )

  if (href) {
    return <Link href={href}>{content}</Link>
  }

  return content
}
