"use client"

import { DynamicPreview, type DynamicPreviewMode } from "./dynamic-preview"
import { Button } from "@/components/ui/button"
import { Play, Info, Radio } from "lucide-react"

interface HeroPreviewProps {
  title: string
  subtitle?: string
  description?: string
  mediaSrc: string
  mediaMode?: DynamicPreviewMode
  motionDirection?: "zoom-in" | "zoom-out" | "pan-left" | "pan-right" | "pan-up" | "pan-down"
  status?: "live" | "upcoming" | "featured"
  primaryAction?: {
    label: string
    href?: string
    onClick?: () => void
  }
  secondaryAction?: {
    label: string
    href?: string
    onClick?: () => void
  }
  /** Show 33.3FM attribution */
  showRadioAttribution?: boolean
}

export function HeroPreview({
  title,
  subtitle,
  description,
  mediaSrc,
  mediaMode = "motion-still",
  motionDirection = "zoom-in",
  status = "featured",
  primaryAction,
  secondaryAction,
  showRadioAttribution = false,
}: HeroPreviewProps) {
  return (
    <div className="relative w-full min-h-[60vh] rounded-2xl overflow-hidden">
      {/* Background with Ken Burns */}
      <div className="absolute inset-0">
        <DynamicPreview
          mode={mediaMode}
          src={mediaSrc}
          placeholderQuery={title}
          aspect="21:9"
          motionDirection={motionDirection}
          duration={25}
          overlay="none"
          glowColor="none"
        />
      </div>

      {/* Heavy gradient overlay for text readability */}
      <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/30" />

      {/* Content */}
      <div className="relative z-10 flex flex-col justify-end h-full min-h-[60vh] p-8 md:p-12 lg:p-16">
        {/* Status badge */}
        {status === "live" && (
          <div className="flex items-center gap-2 mb-4">
            <span className="w-2 h-2 bg-[#FF3131] rounded-full animate-pulse" />
            <span className="text-xs font-mono text-[#FF3131] tracking-wider">LIVE NOW</span>
          </div>
        )}

        {/* Subtitle */}
        {subtitle && <p className="text-xs font-mono text-[#00FFFF] tracking-[0.3em] uppercase mb-2">{subtitle}</p>}

        {/* Title */}
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 max-w-2xl tracking-tight">{title}</h1>

        {/* Description */}
        {description && (
          <p className="text-sm md:text-base text-zinc-300 max-w-xl mb-6 leading-relaxed">{description}</p>
        )}

        {/* Actions */}
        <div className="flex items-center gap-3 flex-wrap">
          {primaryAction && (
            <Button
              size="lg"
              className="bg-[#00FFFF] text-black hover:bg-[#00FFFF]/80 font-semibold gap-2"
              onClick={primaryAction.onClick}
            >
              <Play className="w-4 h-4" />
              {primaryAction.label}
            </Button>
          )}
          {secondaryAction && (
            <Button
              size="lg"
              variant="outline"
              className="border-white/30 text-white hover:bg-white/10 gap-2 bg-transparent"
              onClick={secondaryAction.onClick}
            >
              <Info className="w-4 h-4" />
              {secondaryAction.label}
            </Button>
          )}
        </div>

        {/* Radio attribution */}
        {showRadioAttribution && (
          <div className="flex items-center gap-2 mt-6 opacity-60">
            <Radio className="w-3 h-3 text-[#FF3131]" />
            <span className="text-[10px] font-mono text-zinc-400">
              BROADCAST ON 33.3FM DOGECHAIN • CURATED BY DJ RED FANG
            </span>
          </div>
        )}
      </div>

      {/* Corner metadata */}
      <div className="absolute top-4 right-4 z-10">
        <div className="text-[9px] font-mono text-white/40 text-right">
          <div>789 STUDIOS</div>
          <div>WIRED CHAOS META</div>
        </div>
      </div>

      {/* Scanline effect */}
      <div className="absolute inset-0 pointer-events-none opacity-5">
        <div className="absolute inset-0 bg-[repeating-linear-gradient(0deg,transparent,transparent_2px,rgba(0,0,0,0.1)_2px,rgba(0,0,0,0.1)_4px)]" />
      </div>
    </div>
  )
}
