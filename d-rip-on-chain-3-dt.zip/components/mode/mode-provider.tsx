"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import { usePathname } from "next/navigation"
import { detectMode, getModeConfig, type DesignMode } from "@/config/mode"

interface ModeContextType {
  mode: DesignMode
  config: ReturnType<typeof getModeConfig>
  isAkashic: boolean
  isCorporate: boolean
}

const ModeContext = createContext<ModeContextType | null>(null)

export function ModeProvider({ children }: { children: ReactNode }) {
  const pathname = usePathname()
  const [mode, setMode] = useState<DesignMode>("corporate")

  useEffect(() => {
    const detectedMode = detectMode(pathname)
    setMode(detectedMode)
    document.documentElement.setAttribute("data-mode", detectedMode)
  }, [pathname])

  const config = getModeConfig(mode)

  return (
    <ModeContext.Provider
      value={{
        mode,
        config,
        isAkashic: mode === "akashic",
        isCorporate: mode === "corporate",
      }}
    >
      <div
        className={mode === "akashic" ? "scanlines film-grain circuit-bg min-h-screen" : "min-h-screen"}
        data-mode={mode}
      >
        {children}
      </div>
    </ModeContext.Provider>
  )
}

export function useMode() {
  const context = useContext(ModeContext)
  if (!context) {
    throw new Error("useMode must be used within ModeProvider")
  }
  return context
}
