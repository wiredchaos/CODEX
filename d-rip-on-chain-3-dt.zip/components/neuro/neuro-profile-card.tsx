"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Verified } from "lucide-react"

interface NeuroProfile {
  handle: string
  displayName: string
  avatarUrl?: string
  bio?: string
  followers?: number
  following?: number
  spacesHosted?: number
  verified?: boolean
  lastSyncedAt: string
}

export function NeuroProfileCard() {
  const [profile, setProfile] = useState<NeuroProfile | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch("/api/lurky/neuro")
      .then((res) => res.json())
      .then((data) => {
        setProfile(data)
        setLoading(false)
      })
      .catch((error) => {
        console.error("[v0] Failed to load NEURO profile:", error)
        setLoading(false)
      })
  }, [])

  if (loading) {
    return (
      <Card className="p-6 animate-pulse">
        <div className="flex items-center gap-4">
          <div className="h-20 w-20 rounded-full bg-muted" />
          <div className="flex-1 space-y-2">
            <div className="h-6 w-32 bg-muted rounded" />
            <div className="h-4 w-48 bg-muted rounded" />
          </div>
        </div>
      </Card>
    )
  }

  if (!profile) {
    return (
      <Card className="p-6 border-destructive/50">
        <p className="text-sm text-muted-foreground">NEURO profile unavailable from Lurky.app</p>
      </Card>
    )
  }

  return (
    <Card className="p-6 border-cyan-500/20 bg-gradient-to-br from-background to-cyan-950/10">
      <div className="flex items-start gap-4">
        {profile.avatarUrl && (
          <Image
            src={profile.avatarUrl || "/placeholder.svg"}
            alt={profile.displayName}
            width={80}
            height={80}
            className="rounded-full border-2 border-cyan-500"
          />
        )}

        <div className="flex-1 space-y-2">
          <div className="flex items-center gap-2">
            <h3 className="text-xl font-semibold">{profile.displayName}</h3>
            {profile.verified && <Verified className="h-5 w-5 text-cyan-500 fill-cyan-500" />}
          </div>

          <p className="text-sm text-muted-foreground">@{profile.handle}</p>

          {profile.bio && <p className="text-sm text-foreground/80 leading-relaxed">{profile.bio}</p>}

          <div className="flex gap-4 text-sm pt-2">
            {profile.followers !== undefined && (
              <div>
                <span className="font-semibold text-cyan-400">{profile.followers.toLocaleString()}</span>
                <span className="text-muted-foreground ml-1">followers</span>
              </div>
            )}
            {profile.following !== undefined && (
              <div>
                <span className="font-semibold text-cyan-400">{profile.following.toLocaleString()}</span>
                <span className="text-muted-foreground ml-1">following</span>
              </div>
            )}
            {profile.spacesHosted !== undefined && (
              <div>
                <span className="font-semibold text-cyan-400">{profile.spacesHosted}</span>
                <span className="text-muted-foreground ml-1">spaces hosted</span>
              </div>
            )}
          </div>

          <Badge variant="outline" className="text-xs mt-2">
            Powered by Lurky.app
          </Badge>
        </div>
      </div>
    </Card>
  )
}
