"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ExternalLink, Twitter, CheckCircle } from "lucide-react"
import type { CrewMember } from "@/lib/789-studios/crew-registry"

interface CrewCardProps {
  member: CrewMember
  variant?: "default" | "featured" | "compact"
}

export function CrewCard({ member, variant = "default" }: CrewCardProps) {
  const [imageError, setImageError] = useState(false)

  const roleColors: Record<string, string> = {
    founder: "bg-cyan-500/20 text-cyan-400 border-cyan-500/50",
    "creative-director": "bg-purple-500/20 text-purple-400 border-purple-500/50",
    producer: "bg-blue-500/20 text-blue-400 border-blue-500/50",
    engineer: "bg-green-500/20 text-green-400 border-green-500/50",
    artist: "bg-pink-500/20 text-pink-400 border-pink-500/50",
    host: "bg-orange-500/20 text-orange-400 border-orange-500/50",
    advisor: "bg-yellow-500/20 text-yellow-400 border-yellow-500/50",
  }

  const xSocial = member.socials.find((s) => s.platform === "x")

  return (
    <Card
      className={`
      relative overflow-hidden border-cyan-500/30 bg-black/60 backdrop-blur-sm
      transition-all duration-300 hover:border-cyan-400/60 hover:shadow-lg hover:shadow-cyan-500/20
      ${variant === "featured" ? "ring-2 ring-cyan-500/50" : ""}
    `}
    >
      {/* Glow effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 via-transparent to-purple-500/5 pointer-events-none" />

      {variant === "featured" && (
        <div className="absolute top-2 right-2">
          <Badge className="bg-cyan-500 text-black text-xs font-bold">FEATURED</Badge>
        </div>
      )}

      <CardContent className="relative p-6">
        <div className="flex items-start gap-4">
          {/* Avatar */}
          <div className="relative flex-shrink-0">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-cyan-500 to-purple-600 p-0.5">
              <div className="w-full h-full rounded-full bg-black flex items-center justify-center overflow-hidden">
                {!imageError ? (
                  <img
                    src={member.avatar || "/placeholder.svg"}
                    alt={member.name}
                    className="w-full h-full object-cover"
                    onError={() => setImageError(true)}
                  />
                ) : (
                  <span className="text-2xl font-bold text-cyan-400">{member.name.charAt(0)}</span>
                )}
              </div>
            </div>
            {/* Online indicator */}
            <div className="absolute bottom-1 right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-black" />
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="text-lg font-bold text-white truncate">{member.name}</h3>
              <CheckCircle className="w-4 h-4 text-cyan-400 flex-shrink-0" />
            </div>

            <p className="text-cyan-400 text-sm font-mono mb-2">{member.handle}</p>

            <Badge className={`${roleColors[member.role]} border text-xs mb-3`}>{member.title}</Badge>

            <p className="text-gray-400 text-sm line-clamp-2 mb-4">{member.bio}</p>

            {/* Badges */}
            <div className="flex flex-wrap gap-1 mb-4">
              {member.badges.map((badge) => (
                <span
                  key={badge}
                  className="text-xs px-2 py-0.5 rounded-full bg-white/5 text-gray-500 border border-white/10"
                >
                  {badge}
                </span>
              ))}
            </div>

            {/* Social Follow */}
            {xSocial && (
              <Button
                asChild
                className="w-full bg-black border border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10 hover:border-cyan-400"
              >
                <a
                  href={xSocial.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2"
                >
                  <Twitter className="w-4 h-4" />
                  Follow {xSocial.handle}
                  <ExternalLink className="w-3 h-3" />
                </a>
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
