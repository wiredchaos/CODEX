"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Twitter, ExternalLink, Radio, Tv, Users } from "lucide-react"
import { SOCIAL_ACCOUNTS, type SocialAccount } from "@/lib/789-studios/social-config"

function SocialAccountCard({ account }: { account: SocialAccount }) {
  return (
    <div className="flex items-center justify-between p-4 rounded-lg bg-black/40 border border-cyan-500/20 hover:border-cyan-400/40 transition-all">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-500 to-purple-600 flex items-center justify-center">
          <Twitter className="w-5 h-5 text-white" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-semibold text-white">{account.name}</span>
            {account.verified && (
              <svg className="w-4 h-4 text-cyan-400" viewBox="0 0 24 24" fill="currentColor">
                <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z" />
              </svg>
            )}
          </div>
          <p className="text-cyan-400 text-sm font-mono">{account.handle}</p>
        </div>
      </div>
      <Button asChild size="sm" className="bg-cyan-500/10 border border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/20">
        <a href={account.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1">
          Follow <ExternalLink className="w-3 h-3" />
        </a>
      </Button>
    </div>
  )
}

export function SocialPanel() {
  const [activeTab, setActiveTab] = useState("all")

  const wiredChaosSocials = SOCIAL_ACCOUNTS.filter((s) => s.category === "wired-chaos")
  const studiosSocials = SOCIAL_ACCOUNTS.filter((s) => s.category === "789-studios")
  const fmSocials = SOCIAL_ACCOUNTS.filter((s) => s.category === "33fm")
  const crewSocials = SOCIAL_ACCOUNTS.filter((s) => s.category === "crew")

  return (
    <Card className="border-cyan-500/30 bg-black/80 backdrop-blur-sm">
      <CardHeader className="border-b border-cyan-500/20">
        <CardTitle className="flex items-center gap-2 text-cyan-400">
          <Users className="w-5 h-5" />
          WIRED CHAOS NETWORK
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-4 gap-1 bg-black/60 border border-cyan-500/30 p-1 mb-4">
            <TabsTrigger value="all" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
              All
            </TabsTrigger>
            <TabsTrigger
              value="wired-chaos"
              className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
            >
              <Tv className="w-3 h-3 mr-1" /> WCM
            </TabsTrigger>
            <TabsTrigger
              value="789-studios"
              className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
            >
              789
            </TabsTrigger>
            <TabsTrigger value="33fm" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
              <Radio className="w-3 h-3 mr-1" /> FM
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-3 mt-0">
            {SOCIAL_ACCOUNTS.map((account) => (
              <SocialAccountCard key={account.id} account={account} />
            ))}
          </TabsContent>

          <TabsContent value="wired-chaos" className="space-y-3 mt-0">
            {wiredChaosSocials.map((account) => (
              <SocialAccountCard key={account.id} account={account} />
            ))}
            {crewSocials.map((account) => (
              <SocialAccountCard key={account.id} account={account} />
            ))}
          </TabsContent>

          <TabsContent value="789-studios" className="space-y-3 mt-0">
            {studiosSocials.map((account) => (
              <SocialAccountCard key={account.id} account={account} />
            ))}
          </TabsContent>

          <TabsContent value="33fm" className="space-y-3 mt-0">
            {fmSocials.map((account) => (
              <SocialAccountCard key={account.id} account={account} />
            ))}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
