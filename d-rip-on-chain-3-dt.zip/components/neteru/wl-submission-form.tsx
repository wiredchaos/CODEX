"use client"

import type React from "react"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { GlitchText } from "./glitch-text"
import { Loader2, Check, X, Fingerprint } from "lucide-react"
import { cn } from "@/lib/utils"

const CORRECT_KEY = "589-OUTSIDE_YOUR_ASSIGNMENT-33.9N-118.2W-NTRU-3:33-THE_LEDGER_REMEMBERS-33"

export function WLSubmissionForm() {
  const [key, setKey] = useState("")
  const [wallet, setWallet] = useState("")
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle")
  const [showSuccess, setShowSuccess] = useState(false)

  const validateKey = (input: string): boolean => {
    return input.trim().toUpperCase() === CORRECT_KEY.toUpperCase()
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!key || !wallet) return

    setStatus("loading")

    // Simulate validation delay
    await new Promise((r) => setTimeout(r, 1500))

    if (validateKey(key)) {
      setStatus("success")
      setShowSuccess(true)
    } else {
      setStatus("error")
      setTimeout(() => setStatus("idle"), 3000)
    }
  }

  if (showSuccess) {
    return (
      <Card className="border-emerald-500/50 bg-emerald-500/10 p-8 text-center">
        <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-emerald-500/20 flex items-center justify-center animate-pulse">
          <Fingerprint className="w-10 h-10 text-emerald-400" />
        </div>
        <h2 className="text-2xl font-bold text-emerald-400 mb-2">ACCESS GRANTED</h2>
        <p className="text-emerald-300/70 mb-4">Echo Engineer Status Confirmed</p>
        <code className="text-xs text-emerald-400/50 font-mono">
          WALLET: {wallet.slice(0, 6)}...{wallet.slice(-4)}
        </code>
      </Card>
    )
  }

  return (
    <Card
      className={cn(
        "border-amber-500/30 bg-zinc-900/90 p-6 transition-all",
        status === "error" && "border-red-500/50 animate-shake",
      )}
    >
      <div className="text-center mb-6">
        <GlitchText text="VRG33589 WHITELIST PORTAL" as="h2" className="text-xl font-bold text-amber-400" />
        <p className="text-zinc-500 text-sm mt-2">Enter your assembled key sequence</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="text-xs text-zinc-500 font-mono mb-2 block">CONCATENATED WL KEY</label>
          <Input
            value={key}
            onChange={(e) => setKey(e.target.value)}
            placeholder="ENTER CONCATENATED WL KEY..."
            className={cn(
              "bg-black/50 border-amber-500/30 text-amber-100 font-mono placeholder:text-zinc-600",
              status === "error" && "border-red-500/50 text-red-400",
            )}
          />
        </div>

        <div>
          <label className="text-xs text-zinc-500 font-mono mb-2 block">WALLET ADDRESS</label>
          <Input
            value={wallet}
            onChange={(e) => setWallet(e.target.value)}
            placeholder="0x... or ENS"
            className="bg-black/50 border-amber-500/30 text-amber-100 font-mono placeholder:text-zinc-600"
          />
        </div>

        <Button
          type="submit"
          disabled={!key || !wallet || status === "loading"}
          className={cn(
            "w-full font-mono tracking-wider",
            status === "error" ? "bg-red-500 hover:bg-red-600" : "bg-amber-500 hover:bg-amber-600 text-black",
          )}
        >
          {status === "loading" && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
          {status === "success" && <Check className="w-4 h-4 mr-2" />}
          {status === "error" && <X className="w-4 h-4 mr-2" />}
          {status === "loading" ? "VALIDATING..." : status === "error" ? "INVALID KEY SEQUENCE" : "VALIDATE & SUBMIT"}
        </Button>
      </form>

      {status === "error" && (
        <p className="text-red-400 text-xs text-center mt-4 font-mono animate-pulse">
          KEY SEQUENCE DOES NOT MATCH. ACCESS DENIED.
        </p>
      )}
    </Card>
  )
}
