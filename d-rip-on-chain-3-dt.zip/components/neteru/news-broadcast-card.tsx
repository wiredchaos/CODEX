import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Radio, Lock, Unlock, Waves, Eye } from "lucide-react"
import { cn } from "@/lib/utils"

interface NewsBroadcastCardProps {
  title: string
  description?: string
  type: "live" | "classified" | "declassified" | "echo" | "akashic"
  signalStrength: number
  timestamp?: string
}

const TYPE_CONFIG = {
  live: { label: "LIVE", color: "text-red-400", bg: "bg-red-500/10", border: "border-red-500/30", icon: Radio },
  classified: {
    label: "CLASSIFIED",
    color: "text-amber-400",
    bg: "bg-amber-500/10",
    border: "border-amber-500/30",
    icon: Lock,
  },
  declassified: {
    label: "DECLASSIFIED",
    color: "text-emerald-400",
    bg: "bg-emerald-500/10",
    border: "border-emerald-500/30",
    icon: Unlock,
  },
  echo: {
    label: "ECHO TRANSMISSION",
    color: "text-cyan-400",
    bg: "bg-cyan-500/10",
    border: "border-cyan-500/30",
    icon: Waves,
  },
  akashic: {
    label: "AKASHIC UPDATE",
    color: "text-purple-400",
    bg: "bg-purple-500/10",
    border: "border-purple-500/30",
    icon: Eye,
  },
}

export function NewsBroadcastCard({ title, description, type, signalStrength, timestamp }: NewsBroadcastCardProps) {
  const config = TYPE_CONFIG[type]
  const Icon = config.icon

  return (
    <Card className={cn("p-4 transition-all hover:scale-[1.02]", config.bg, config.border)}>
      <div className="flex items-start gap-3">
        <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center", config.bg)}>
          <Icon className={cn("w-5 h-5", config.color)} />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <Badge variant="outline" className={cn("text-xs", config.color, config.border)}>
              {config.label}
            </Badge>
            {type === "live" && (
              <span className="flex items-center gap-1 text-xs text-red-400">
                <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                LIVE
              </span>
            )}
          </div>

          <h3 className={cn("font-semibold mb-1 line-clamp-2", config.color)}>{title}</h3>

          {description && <p className="text-sm text-zinc-500 line-clamp-2">{description}</p>}
        </div>

        {/* Signal strength meter */}
        <div className="flex flex-col items-center gap-0.5">
          {[5, 4, 3, 2, 1].map((level) => (
            <div
              key={level}
              className={cn(
                "w-3 rounded-sm transition-colors",
                level <= signalStrength ? config.color.replace("text-", "bg-") : "bg-zinc-700",
                level === 5 ? "h-1" : level === 4 ? "h-1.5" : level === 3 ? "h-2" : level === 2 ? "h-2.5" : "h-3",
              )}
            />
          ))}
        </div>
      </div>

      {timestamp && <p className="text-xs text-zinc-600 mt-3 font-mono">{timestamp}</p>}
    </Card>
  )
}
