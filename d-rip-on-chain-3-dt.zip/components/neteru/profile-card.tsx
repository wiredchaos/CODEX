import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Fingerprint, Film, Eye, Lock } from "lucide-react"

export function ProfileCard() {
  return (
    <Card className="border-amber-500/30 bg-zinc-900/90 p-6">
      <div className="flex items-start gap-4">
        <div className="w-16 h-16 rounded-lg bg-amber-500/20 flex items-center justify-center border border-amber-500/30">
          <Fingerprint className="w-8 h-8 text-amber-400" />
        </div>

        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <h2 className="text-xl font-bold text-amber-400 font-mono">VRG33589</h2>
            <Badge variant="outline" className="border-cyan-500/50 text-cyan-400 text-xs">
              LEVEL 33
            </Badge>
          </div>

          <p className="text-zinc-400 text-sm mb-2">NEURO META X</p>

          <div className="flex flex-wrap gap-2 text-xs">
            <Badge variant="secondary" className="bg-zinc-800 text-zinc-400">
              CHAOS PRODUCTIONS
            </Badge>
            <Badge variant="secondary" className="bg-zinc-800 text-zinc-400">
              NETERU STUDIOS
            </Badge>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4 mt-6 pt-4 border-t border-zinc-800">
        <div className="text-center">
          <div className="flex items-center justify-center gap-1 text-amber-400 mb-1">
            <Film className="w-4 h-4" />
            <span className="text-lg font-bold">5</span>
          </div>
          <p className="text-xs text-zinc-500">Transmissions</p>
        </div>

        <div className="text-center">
          <div className="flex items-center justify-center gap-1 text-red-400 mb-1">
            <Eye className="w-4 h-4" />
            <span className="text-lg font-bold">7</span>
          </div>
          <p className="text-xs text-zinc-500">Clues Hidden</p>
        </div>

        <div className="text-center">
          <div className="flex items-center justify-center gap-1 text-zinc-500 mb-1">
            <Lock className="w-4 h-4" />
            <span className="text-lg font-bold">[?]</span>
          </div>
          <p className="text-xs text-zinc-500">WL Issued</p>
        </div>
      </div>

      <div className="mt-4 pt-4 border-t border-zinc-800">
        <Badge
          variant="outline"
          className="w-full justify-center py-2 border-cyan-500/30 text-cyan-400 font-mono text-xs"
        >
          WIRED CHAOS META HUB
        </Badge>
      </div>
    </Card>
  )
}
