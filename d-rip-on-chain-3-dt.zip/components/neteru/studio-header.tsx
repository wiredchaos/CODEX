"use client"

import Link from "next/link"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { GlitchText } from "./glitch-text"
import { Fingerprint, Menu, X } from "lucide-react"
import { cn } from "@/lib/utils"

const NAV_ITEMS = [
  { label: "TRANSMISSIONS", href: "/neteru-studios" },
  { label: "BARBED WIRE", href: "/neteru-studios/barbed-wire-broadcast" },
  { label: "CLUES", href: "/neteru-studios/clues" },
  { label: "WHITELIST", href: "/neteru-studios/whitelist" },
]

export function StudioHeader() {
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 bg-black/90 backdrop-blur-sm border-b border-amber-500/20">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/neteru-studios" className="flex items-center gap-3">
            <div className="relative">
              <Fingerprint className="w-8 h-8 text-amber-400 animate-pulse" />
              <div className="absolute inset-0 bg-amber-400/20 blur-lg" />
            </div>
            <div>
              <GlitchText text="VRG33589" className="text-lg font-bold text-amber-400 font-mono" />
              <p className="text-[10px] text-zinc-500 tracking-[0.2em]">ECHO ENGINEERS</p>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-6">
            {NAV_ITEMS.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="text-sm font-mono text-zinc-400 hover:text-amber-400 transition-colors tracking-wider"
              >
                {item.label}
              </Link>
            ))}
          </nav>

          {/* Branding + Mobile Toggle */}
          <div className="flex items-center gap-4">
            <div className="hidden sm:block text-right">
              <p className="text-xs text-amber-400 font-mono">NETERU STUDIOS</p>
              <p className="text-[10px] text-zinc-600">NEURO META X</p>
            </div>

            <Button
              variant="ghost"
              size="icon"
              className="md:hidden text-amber-400"
              onClick={() => setMobileOpen(!mobileOpen)}
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Nav */}
        <div
          className={cn(
            "md:hidden overflow-hidden transition-all duration-300",
            mobileOpen ? "max-h-64 pb-4" : "max-h-0",
          )}
        >
          <nav className="flex flex-col gap-2 pt-4 border-t border-zinc-800">
            {NAV_ITEMS.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                className="text-sm font-mono text-zinc-400 hover:text-amber-400 py-2 px-4 rounded-lg hover:bg-amber-500/10 transition-colors"
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      </div>
    </header>
  )
}
