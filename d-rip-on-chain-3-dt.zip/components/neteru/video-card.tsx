"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Lock, Eye, Clock } from "lucide-react"
import { cn } from "@/lib/utils"

interface VideoCardProps {
  code: string
  title: string
  duration: number
  thumbnailUrl?: string
  clueType: string
  clueFound: boolean
  isLocked?: boolean
  viewCount?: number
  onClick?: () => void
}

function formatDuration(seconds: number): string {
  const mins = Math.floor(seconds / 60)
  const secs = seconds % 60
  return `${mins}:${secs.toString().padStart(2, "0")}`
}

export function VideoCard({
  code,
  title,
  duration,
  thumbnailUrl,
  clueType,
  clueFound,
  isLocked = false,
  viewCount = 0,
  onClick,
}: VideoCardProps) {
  return (
    <Card
      className={cn(
        "group relative overflow-hidden cursor-pointer transition-all duration-300",
        "border-amber-500/20 bg-zinc-900/80 hover:border-amber-500/50",
        "hover:shadow-lg hover:shadow-amber-500/10",
        isLocked && "opacity-60",
      )}
      onClick={onClick}
    >
      {/* Thumbnail with scanline overlay */}
      <div className="relative aspect-video overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-110"
          style={{
            backgroundImage: thumbnailUrl
              ? `url(${thumbnailUrl})`
              : `url(/placeholder.svg?height=180&width=320&query=${encodeURIComponent(title)})`,
          }}
        />

        {/* Scanline overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/5 to-transparent bg-[length:100%_4px] animate-scanline opacity-30" />

        {/* Glitch frame on hover */}
        <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
          <div className="absolute inset-0 bg-red-500/10 translate-x-[2px]" />
          <div className="absolute inset-0 bg-cyan-500/10 translate-x-[-2px]" />
        </div>

        {/* Lock overlay */}
        {isLocked && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
            <Lock className="w-8 h-8 text-amber-500" />
          </div>
        )}

        {/* Duration badge */}
        <div className="absolute bottom-2 right-2 bg-black/80 px-2 py-1 rounded text-xs font-mono text-amber-400 flex items-center gap-1">
          <Clock className="w-3 h-3" />
          {formatDuration(duration)}
        </div>

        {/* Transmission code badge */}
        <div className="absolute top-2 left-2">
          <Badge variant="outline" className="bg-black/80 border-amber-500/50 text-amber-400 font-mono text-xs">
            {code}
          </Badge>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        <h3 className="font-semibold text-amber-100 mb-2 line-clamp-2 group-hover:text-amber-400 transition-colors">
          {title}
        </h3>

        <div className="flex items-center justify-between text-xs">
          <Badge
            variant="outline"
            className={cn(
              "font-mono",
              clueFound
                ? "border-emerald-500/50 text-emerald-400 bg-emerald-500/10"
                : "border-red-500/50 text-red-400 bg-red-500/10",
            )}
          >
            CLUE: {clueFound ? "FOUND" : "HIDDEN"}
          </Badge>

          <div className="flex items-center gap-1 text-zinc-500">
            <Eye className="w-3 h-3" />
            <span>{viewCount.toLocaleString()}</span>
          </div>
        </div>

        <p className="text-xs text-zinc-500 mt-2 font-mono uppercase tracking-wider">{clueType.replace(/_/g, " ")}</p>
      </div>

      {/* NEURO META X credit */}
      <div className="absolute bottom-2 right-2 text-[10px] text-zinc-600 font-mono">NEURO META X</div>
    </Card>
  )
}
