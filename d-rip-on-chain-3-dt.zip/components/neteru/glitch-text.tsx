"use client"

import { cn } from "@/lib/utils"

interface GlitchTextProps {
  text: string
  className?: string
  as?: "h1" | "h2" | "h3" | "span" | "p"
}

export function GlitchText({ text, className, as: Component = "span" }: GlitchTextProps) {
  return (
    <Component className={cn("relative inline-block", className)} data-text={text}>
      <span className="relative z-10">{text}</span>
      {/* Red layer */}
      <span
        className="absolute top-0 left-0 w-full h-full text-red-500 opacity-70 animate-glitch-1"
        style={{ clipPath: "polygon(0 0, 100% 0, 100% 45%, 0 45%)" }}
        aria-hidden="true"
      >
        {text}
      </span>
      {/* Cyan layer */}
      <span
        className="absolute top-0 left-0 w-full h-full text-cyan-400 opacity-70 animate-glitch-2"
        style={{ clipPath: "polygon(0 55%, 100% 55%, 100% 100%, 0 100%)" }}
        aria-hidden="true"
      >
        {text}
      </span>
    </Component>
  )
}
