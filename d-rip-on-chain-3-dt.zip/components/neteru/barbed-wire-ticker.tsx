"use client"

import { useEffect, useState } from "react"

const TICKER_MESSAGES = [
  "SIGNAL INTERCEPT: NILOTIC FREQUENCY DETECTED AT 33.9N COORDINATES...",
  "WIRED CHAOS META HUB: ALL SYSTEMS NOMINAL...",
  "VRG33589 TRANSMISSION INCOMING...",
  "OPERATION ANCESTRY: NEW DATA DECLASSIFIED...",
  "NETERU STUDIOS: ECHO ENGINEERS ACTIVE...",
  "TIME MATRIX: ANOMALY DETECTED AT NODE 33...",
  "BARBED WIRE BROADCAST: SIGNAL STRENGTH OPTIMAL...",
  "AKASHIC RECORDS: TEMPORAL BREACH SEALED...",
]

export function BarbedWireTicker() {
  const [offset, setOffset] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setOffset((prev) => prev - 1)
    }, 30)
    return () => clearInterval(interval)
  }, [])

  const tickerContent = TICKER_MESSAGES.join(" ◆ ")

  return (
    <div className="relative w-full overflow-hidden bg-black/80 border-y border-amber-500/30 py-2">
      {/* Barbed wire left edge */}
      <div className="absolute left-0 top-0 bottom-0 w-8 bg-gradient-to-r from-black to-transparent z-10 flex items-center">
        <svg className="w-6 h-6 text-amber-500" viewBox="0 0 24 24" fill="none" stroke="currentColor">
          <path d="M2 12h20M6 8l-4 4 4 4M18 8l4 4-4 4" strokeWidth="2" />
        </svg>
      </div>

      {/* Scrolling content */}
      <div
        className="whitespace-nowrap text-amber-400 font-mono text-sm tracking-wider"
        style={{ transform: `translateX(${offset % (tickerContent.length * 10)}px)` }}
      >
        {tickerContent} ◆ {tickerContent}
      </div>

      {/* Barbed wire right edge */}
      <div className="absolute right-0 top-0 bottom-0 w-8 bg-gradient-to-l from-black to-transparent z-10 flex items-center justify-end">
        <svg className="w-6 h-6 text-amber-500" viewBox="0 0 24 24" fill="none" stroke="currentColor">
          <path d="M2 12h20M6 8l-4 4 4 4M18 8l4 4-4 4" strokeWidth="2" />
        </svg>
      </div>
    </div>
  )
}
