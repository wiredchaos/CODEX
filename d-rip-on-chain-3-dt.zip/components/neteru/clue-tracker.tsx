"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Eye, EyeOff, Lock, Unlock, Copy, Check } from "lucide-react"
import { cn } from "@/lib/utils"

interface Clue {
  id: number
  type: string
  source: string
  segment: string
}

const CLUES: Clue[] = [
  { id: 1, type: "VISIBLE CIPHER", source: "Video 1", segment: "589" },
  { id: 2, type: "GLITCH FRAME GLYPH", source: "Video 2", segment: "OUTSIDE_YOUR_ASSIGNMENT" },
  { id: 3, type: "COORDINATE EMBED", source: "Video 3", segment: "33.9N-118.2W" },
  { id: 4, type: "TOKEN REFERENCE", source: "Video 3-4", segment: "NTRU" },
  { id: 5, type: "TIMESTAMP CIPHER", source: "Video 4", segment: "3:33" },
  { id: 6, type: "METADATA EXTRACTION", source: "Video 5", segment: "THE_LEDGER_REMEMBERS" },
  { id: 7, type: "GEOMETRY CODE", source: "Video 5", segment: "33" },
]

const CORRECT_KEY = "589-OUTSIDE_YOUR_ASSIGNMENT-33.9N-118.2W-NTRU-3:33-THE_LEDGER_REMEMBERS-33"

export function ClueTracker() {
  const [foundClues, setFoundClues] = useState<number[]>([])
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    const saved = localStorage.getItem("neteru_clues_found")
    if (saved) {
      setFoundClues(JSON.parse(saved))
    }
  }, [])

  const toggleClue = (id: number) => {
    const newFound = foundClues.includes(id) ? foundClues.filter((c) => c !== id) : [...foundClues, id]
    setFoundClues(newFound)
    localStorage.setItem("neteru_clues_found", JSON.stringify(newFound))
  }

  const progress = Math.round((foundClues.length / CLUES.length) * 100)
  const allFound = foundClues.length === CLUES.length

  const assembledKey = CLUES.filter((c) => foundClues.includes(c.id))
    .map((c) => c.segment)
    .join("-")

  const copyKey = async () => {
    if (allFound) {
      await navigator.clipboard.writeText(CORRECT_KEY)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  return (
    <Card className="border-amber-500/30 bg-zinc-900/90 p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-amber-400 font-mono tracking-wider">WL CLUE TRACKER</h2>
        <div className="text-right">
          <p className="text-2xl font-bold text-amber-400">{progress}%</p>
          <p className="text-xs text-zinc-500">ELIGIBILITY</p>
        </div>
      </div>

      <Progress value={progress} className="mb-6 h-2 bg-zinc-800" />

      <div className="space-y-3">
        {CLUES.map((clue) => {
          const isFound = foundClues.includes(clue.id)
          return (
            <div
              key={clue.id}
              className={cn(
                "flex items-center gap-4 p-3 rounded-lg border transition-all",
                isFound ? "border-emerald-500/50 bg-emerald-500/10" : "border-zinc-700 bg-zinc-800/50",
              )}
            >
              <div className="w-8 h-8 rounded-full bg-zinc-900 flex items-center justify-center text-sm font-bold text-amber-400 border border-amber-500/30">
                {clue.id}
              </div>

              <div className="flex-1 min-w-0">
                <p className="text-sm font-mono text-amber-300">{clue.type}</p>
                <p className="text-xs text-zinc-500">{clue.source}</p>
              </div>

              {isFound && (
                <code className="text-xs text-emerald-400 font-mono bg-emerald-500/10 px-2 py-1 rounded hidden sm:block">
                  {clue.segment}
                </code>
              )}

              <Button
                variant="ghost"
                size="sm"
                onClick={() => toggleClue(clue.id)}
                className={cn("gap-2", isFound ? "text-emerald-400" : "text-zinc-500")}
              >
                {isFound ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                {isFound ? "FOUND" : "HIDDEN"}
              </Button>
            </div>
          )
        })}
      </div>

      {/* Assembled key display */}
      <div className="mt-6 p-4 rounded-lg border border-amber-500/30 bg-black/50">
        <div className="flex items-center justify-between mb-2">
          <p className="text-xs text-zinc-500 font-mono">CONCATENATED KEY</p>
          {allFound ? <Unlock className="w-4 h-4 text-emerald-400" /> : <Lock className="w-4 h-4 text-red-400" />}
        </div>

        <div className="flex items-center gap-2">
          <code
            className={cn(
              "flex-1 text-xs font-mono p-2 rounded bg-zinc-900 break-all",
              allFound ? "text-emerald-400" : "text-zinc-600",
            )}
          >
            {allFound ? CORRECT_KEY : assembledKey || "[ FIND ALL CLUES TO ASSEMBLE KEY ]"}
          </code>

          {allFound && (
            <Button variant="ghost" size="sm" onClick={copyKey} className="text-amber-400">
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            </Button>
          )}
        </div>
      </div>
    </Card>
  )
}
