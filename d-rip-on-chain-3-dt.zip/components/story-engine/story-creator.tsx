"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import type { StorySeed, Novella, StoryGenre, StoryTone } from "@/config/story-engine"

type PipelineStage = "prompt" | "seed" | "expand" | "convert" | "publish" | "complete"

export function StoryCreator() {
  const [stage, setStage] = useState<PipelineStage>("prompt")
  const [prompt, setPrompt] = useState("")
  const [genre, setGenre] = useState<StoryGenre>("cyberpunk")
  const [tone, setTone] = useState<StoryTone>("dark")
  const [seed, setSeed] = useState<StorySeed | null>(null)
  const [novella, setNovella] = useState<Novella | null>(null)
  const [loading, setLoading] = useState(false)

  const handleGenerateSeed = async () => {
    setLoading(true)
    try {
      const res = await fetch("/api/akira/seed", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, genre, tone }),
      })
      const data = await res.json()
      if (data.success) {
        setSeed(data.seed)
        setStage("seed")
      }
    } catch (error) {
      console.error("Failed to generate seed:", error)
    }
    setLoading(false)
  }

  const handleExpandSeed = async () => {
    if (!seed) return
    setLoading(true)
    try {
      const res = await fetch("/api/akira/expand", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ seed }),
      })
      const data = await res.json()
      if (data.success) {
        setNovella(data.novella)
        setStage("expand")
      }
    } catch (error) {
      console.error("Failed to expand seed:", error)
    }
    setLoading(false)
  }

  return (
    <div className="space-y-6">
      {/* Stage Indicator */}
      <div className="flex items-center gap-2 text-xs font-mono">
        {["prompt", "seed", "expand", "convert", "publish", "complete"].map((s, i) => (
          <div key={s} className="flex items-center">
            <span
              className={`px-2 py-1 rounded ${
                stage === s ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/50" : "text-zinc-600"
              }`}
            >
              {s.toUpperCase()}
            </span>
            {i < 5 && <span className="text-zinc-700 mx-1">→</span>}
          </div>
        ))}
      </div>

      {/* Prompt Stage */}
      {stage === "prompt" && (
        <div className="space-y-4 p-6 border border-cyan-500/20 rounded-lg bg-zinc-900/50">
          <h3 className="text-lg font-mono text-cyan-400">NPC-STORYSMITH</h3>
          <p className="text-sm text-zinc-400">
            Enter your story concept. The AKIRA-SEED agent will transform it into a structured narrative blueprint.
          </p>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="A rogue frequency hacker discovers a signal that reveals the true nature of reality..."
            className="w-full h-32 p-4 bg-black/50 border border-zinc-700 rounded text-zinc-200 placeholder:text-zinc-600 focus:border-cyan-500 focus:outline-none font-mono text-sm"
          />
          <div className="flex gap-4">
            <select
              value={genre}
              onChange={(e) => setGenre(e.target.value as StoryGenre)}
              className="px-3 py-2 bg-black/50 border border-zinc-700 rounded text-zinc-200 text-sm"
            >
              <option value="cyberpunk">Cyberpunk</option>
              <option value="occult-noir">Occult Noir</option>
              <option value="techno-thriller">Techno Thriller</option>
              <option value="cosmic-horror">Cosmic Horror</option>
              <option value="dystopian">Dystopian</option>
              <option value="metaphysical">Metaphysical</option>
            </select>
            <select
              value={tone}
              onChange={(e) => setTone(e.target.value as StoryTone)}
              className="px-3 py-2 bg-black/50 border border-zinc-700 rounded text-zinc-200 text-sm"
            >
              <option value="dark">Dark</option>
              <option value="mysterious">Mysterious</option>
              <option value="chaotic">Chaotic</option>
              <option value="philosophical">Philosophical</option>
              <option value="intense">Intense</option>
              <option value="surreal">Surreal</option>
            </select>
          </div>
          <Button
            onClick={handleGenerateSeed}
            disabled={!prompt || loading}
            className="bg-cyan-500 hover:bg-cyan-400 text-black font-mono"
          >
            {loading ? "PROCESSING..." : "GENERATE SEED"}
          </Button>
        </div>
      )}

      {/* Seed Stage */}
      {stage === "seed" && seed && (
        <div className="space-y-4 p-6 border border-amber-500/20 rounded-lg bg-zinc-900/50">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-mono text-amber-400">STORY SEED: {seed.title}</h3>
            <span className="text-xs text-zinc-500 font-mono">{seed.id}</span>
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-zinc-500">Genre:</span> <span className="text-zinc-200">{seed.genre}</span>
            </div>
            <div>
              <span className="text-zinc-500">Tone:</span> <span className="text-zinc-200">{seed.tone}</span>
            </div>
          </div>
          <div>
            <h4 className="text-xs text-zinc-500 uppercase mb-2">Characters</h4>
            <div className="space-y-2">
              {seed.characters.map((char, i) => (
                <div key={i} className="p-2 bg-black/30 rounded text-sm">
                  <span className="text-amber-400">{char.name}</span>
                  <span className="text-zinc-500"> — {char.archetype}</span>
                </div>
              ))}
            </div>
          </div>
          <div>
            <h4 className="text-xs text-zinc-500 uppercase mb-2">Story Beats</h4>
            <div className="space-y-2">
              {seed.beats.map((beat, i) => (
                <div key={i} className="p-2 bg-black/30 rounded text-sm flex items-center gap-3">
                  <span className="text-cyan-400 font-mono">ACT {beat.act}</span>
                  <span className="text-zinc-200">{beat.title}</span>
                  <span className="text-zinc-500 text-xs">{beat.description}</span>
                </div>
              ))}
            </div>
          </div>
          <Button
            onClick={handleExpandSeed}
            disabled={loading}
            className="bg-amber-500 hover:bg-amber-400 text-black font-mono"
          >
            {loading ? "SWARM EXPANDING..." : "EXPAND TO NOVELLA"}
          </Button>
        </div>
      )}

      {/* Expand Stage */}
      {stage === "expand" && novella && (
        <div className="space-y-4 p-6 border border-fuchsia-500/20 rounded-lg bg-zinc-900/50">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-mono text-fuchsia-400">{novella.title}</h3>
            <span className="text-xs text-zinc-500 font-mono">{novella.word_count.toLocaleString()} words</span>
          </div>
          <div className="flex gap-2">
            {novella.themes.map((theme) => (
              <span key={theme} className="px-2 py-1 text-xs bg-fuchsia-500/10 text-fuchsia-400 rounded">
                {theme}
              </span>
            ))}
          </div>
          <div className="space-y-3">
            {novella.chapters.map((chapter) => (
              <div key={chapter.number} className="p-3 bg-black/30 rounded">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-fuchsia-400 font-mono">
                    Chapter {chapter.number}: {chapter.title}
                  </span>
                  <span className="text-xs text-zinc-500">{chapter.word_count.toLocaleString()} words</span>
                </div>
                <p className="text-sm text-zinc-400">{chapter.summary}</p>
              </div>
            ))}
          </div>
          <div className="flex items-center gap-2 text-sm">
            <span className="text-zinc-500">Continuity Score:</span>
            <span className="text-emerald-400">{(novella.continuity_score * 100).toFixed(1)}%</span>
          </div>
          <Button
            onClick={() => setStage("convert")}
            className="bg-fuchsia-500 hover:bg-fuchsia-400 text-black font-mono"
          >
            CONVERT TO EBOOK
          </Button>
        </div>
      )}
    </div>
  )
}
