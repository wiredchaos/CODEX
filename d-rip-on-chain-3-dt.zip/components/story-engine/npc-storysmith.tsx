"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"

interface DialogueLine {
  speaker: "npc" | "user" | "system"
  text: string
  action?: string
}

const STORYSMITH_DIALOGUE: DialogueLine[] = [
  { speaker: "system", text: "[ SIGNAL ESTABLISHED — NPC-STORYSMITH ONLINE ]" },
  {
    speaker: "npc",
    text: "Operative detected. I am NPC-STORYSMITH, your guide through the AKIRA-CREATOR pipeline.",
  },
  { speaker: "npc", text: "Ready to forge a new story from the chaos? Or perhaps you seek guidance first?" },
]

const COMMAND_RESPONSES: Record<string, DialogueLine[]> = {
  help: [
    { speaker: "npc", text: "Available commands:" },
    { speaker: "system", text: "CREATE — Begin a new story seed" },
    { speaker: "system", text: "STATUS — Check your creative rank" },
    { speaker: "system", text: "LIBRARY — View your published works" },
    { speaker: "system", text: "LORE — Access the Akira Codex connection" },
  ],
  create: [
    { speaker: "npc", text: "Initiating AKIRA-SEED protocol..." },
    { speaker: "system", text: "[ NARRATIVE GENESIS MODE ACTIVATED ]" },
    {
      speaker: "npc",
      text: "Describe your story concept. What world do you wish to manifest?",
      action: "prompt_input",
    },
  ],
  status: [
    { speaker: "system", text: "[ QUERYING CHAOS-GATE... ]" },
    { speaker: "npc", text: "Your current rank: INITIATE" },
    { speaker: "npc", text: "Stories created: 0 | Published: 0 | XP: 0" },
    { speaker: "npc", text: "Complete your first story to advance to SCRIBE rank." },
  ],
  lore: [
    { speaker: "npc", text: "The AKIRA CODEX holds the narrative heart of WIRED CHAOS META." },
    { speaker: "npc", text: "Every story you create can be woven into the greater lore..." },
    { speaker: "system", text: "[ CODEX LINK: /akira ]" },
  ],
}

export function NPCStorysmith() {
  const [dialogue, setDialogue] = useState<DialogueLine[]>([])
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const [currentIndex, setCurrentIndex] = useState(0)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (currentIndex < STORYSMITH_DIALOGUE.length) {
      setIsTyping(true)
      const timer = setTimeout(() => {
        setDialogue((prev) => [...prev, STORYSMITH_DIALOGUE[currentIndex]])
        setCurrentIndex((i) => i + 1)
        setIsTyping(false)
      }, 800)
      return () => clearTimeout(timer)
    }
  }, [currentIndex])

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [dialogue])

  const handleCommand = (cmd: string) => {
    const normalizedCmd = cmd.toLowerCase().trim()
    setDialogue((prev) => [...prev, { speaker: "user", text: cmd }])
    setInput("")

    setTimeout(() => {
      const response = COMMAND_RESPONSES[normalizedCmd] || [
        { speaker: "npc", text: `Unknown command: "${cmd}". Type HELP for available commands.` },
      ]
      response.forEach((line, i) => {
        setTimeout(() => {
          setDialogue((prev) => [...prev, line])
        }, i * 500)
      })
    }, 300)
  }

  return (
    <div className="border border-cyan-500/30 rounded-lg bg-black/80 overflow-hidden">
      {/* Terminal Header */}
      <div className="px-4 py-2 border-b border-cyan-500/20 bg-cyan-500/5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
          <span className="text-xs font-mono text-cyan-400">NPC-STORYSMITH</span>
        </div>
        <span className="text-xs text-zinc-600 font-mono">WIRED CHAOS META // CREATION SYSTEMS</span>
      </div>

      {/* Dialogue Area */}
      <div ref={scrollRef} className="h-80 overflow-y-auto p-4 space-y-3 font-mono text-sm">
        {dialogue.map((line, i) => (
          <div
            key={i}
            className={`${
              line.speaker === "system"
                ? "text-amber-400 text-xs"
                : line.speaker === "npc"
                  ? "text-cyan-300"
                  : "text-emerald-400 pl-4"
            }`}
          >
            {line.speaker === "user" && <span className="text-zinc-600">{"> "}</span>}
            {line.text}
          </div>
        ))}
        {isTyping && (
          <div className="text-cyan-500 animate-pulse">
            <span className="inline-block w-2 h-4 bg-cyan-500 animate-blink" />
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="border-t border-cyan-500/20 p-3 flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && input && handleCommand(input)}
          placeholder="Enter command..."
          className="flex-1 bg-black/50 border border-zinc-800 rounded px-3 py-2 text-sm font-mono text-cyan-300 placeholder:text-zinc-600 focus:border-cyan-500 focus:outline-none"
        />
        <Button
          onClick={() => input && handleCommand(input)}
          size="sm"
          className="bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 hover:bg-cyan-500/30 font-mono"
        >
          EXECUTE
        </Button>
      </div>

      {/* Quick Commands */}
      <div className="px-3 pb-3 flex gap-2 flex-wrap">
        {["HELP", "CREATE", "STATUS", "LORE"].map((cmd) => (
          <button
            key={cmd}
            onClick={() => handleCommand(cmd)}
            className="px-2 py-1 text-xs font-mono text-zinc-500 bg-zinc-900 rounded hover:bg-zinc-800 hover:text-cyan-400 transition-colors"
          >
            {cmd}
          </button>
        ))}
      </div>
    </div>
  )
}
