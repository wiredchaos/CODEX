"use client"

import { useState } from "react"
import { STORY_AGENTS, type StoryAgent } from "@/config/story-engine"

export function PipelineDashboard() {
  const [activeAgent, setActiveAgent] = useState<string | null>(null)

  const systemGroups = {
    akira: STORY_AGENTS.filter((a) => a.system === "akira"),
    creator: STORY_AGENTS.filter((a) => a.system === "creator"),
    npc: STORY_AGENTS.filter((a) => a.system === "npc"),
    chaos: STORY_AGENTS.filter((a) => a.system === "chaos"),
  }

  return (
    <div className="space-y-8">
      {/* Pipeline Flow */}
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/5 via-fuchsia-500/5 to-red-500/5 rounded-lg" />
        <div className="relative p-6 border border-cyan-500/20 rounded-lg">
          <h3 className="text-xs uppercase tracking-widest text-cyan-400 mb-4">Pipeline Architecture</h3>
          <div className="flex items-center justify-between gap-2 overflow-x-auto pb-4">
            {["NPC-STORYSMITH", "AKIRA-SEED", "AKIRA-SWARM", "CC-CONVERT", "CC-PUBLISH", "CC-WEB", "CHAOS-GATE"].map(
              (node, i) => (
                <div key={node} className="flex items-center">
                  <div
                    className={`px-3 py-2 rounded border text-xs font-mono whitespace-nowrap transition-all cursor-pointer
                    ${
                      activeAgent === node.toLowerCase().replace("-", "_")
                        ? "bg-cyan-500/20 border-cyan-400 text-cyan-300"
                        : "bg-zinc-900/50 border-zinc-700 text-zinc-400 hover:border-cyan-500/50"
                    }`}
                    onClick={() => setActiveAgent(node.toLowerCase().replace("-", "_"))}
                  >
                    {node}
                  </div>
                  {i < 6 && <div className="w-8 h-px bg-gradient-to-r from-cyan-500 to-fuchsia-500 mx-1" />}
                </div>
              ),
            )}
          </div>
        </div>
      </div>

      {/* Agent Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {Object.entries(systemGroups).map(([system, agents]) => (
          <div key={system} className="space-y-3">
            <h4 className="text-xs uppercase tracking-widest text-zinc-500">
              {system === "akira" && "AKIRA CODEX"}
              {system === "creator" && "CREATOR CODEX"}
              {system === "npc" && "NPC LAYER"}
              {system === "chaos" && "CHAOS OS"}
            </h4>
            {agents.map((agent) => (
              <AgentCard key={agent.id} agent={agent} />
            ))}
          </div>
        ))}
      </div>
    </div>
  )
}

function AgentCard({ agent }: { agent: StoryAgent }) {
  const systemColors = {
    akira: "border-amber-500/30 hover:border-amber-400",
    creator: "border-cyan-500/30 hover:border-cyan-400",
    npc: "border-emerald-500/30 hover:border-emerald-400",
    chaos: "border-fuchsia-500/30 hover:border-fuchsia-400",
  }

  return (
    <div className={`p-4 rounded-lg border bg-zinc-900/50 transition-all ${systemColors[agent.system]}`}>
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-mono text-zinc-200">{agent.name}</span>
        <span
          className={`w-2 h-2 rounded-full ${
            agent.status === "active"
              ? "bg-green-400 animate-pulse"
              : agent.status === "processing"
                ? "bg-amber-400 animate-pulse"
                : "bg-zinc-600"
          }`}
        />
      </div>
      <p className="text-xs text-zinc-500">{agent.role}</p>
    </div>
  )
}
