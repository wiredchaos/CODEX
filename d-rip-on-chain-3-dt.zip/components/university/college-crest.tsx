"use client"

import type { UniversityNode } from "@/config/university"
import { Brain, Link2, BadgeCheck, Eye, Users } from "lucide-react"

interface CollegeCrestProps {
  node: UniversityNode
  size?: "sm" | "md" | "lg"
  isActive?: boolean
  onClick?: () => void
}

const CREST_ICONS = {
  brain: Brain,
  chain: Link2,
  badge: BadgeCheck,
  eye: Eye,
  hood: Users,
}

export function CollegeCrest({ node, size = "md", isActive = false, onClick }: CollegeCrestProps) {
  const Icon = CREST_ICONS[node.crestSymbol as keyof typeof CREST_ICONS] || Brain

  const sizeClasses = {
    sm: "w-20 h-20",
    md: "w-32 h-32",
    lg: "w-44 h-44",
  }

  const iconSizes = {
    sm: "w-8 h-8",
    md: "w-12 h-12",
    lg: "w-16 h-16",
  }

  return (
    <button
      onClick={onClick}
      className={`
        relative ${sizeClasses[size]} rounded-full 
        flex items-center justify-center
        transition-all duration-500 cursor-pointer
        ${isActive ? "scale-110" : "hover:scale-105"}
      `}
      style={{
        background: `radial-gradient(circle at center, ${node.color}20 0%, transparent 70%)`,
        boxShadow: isActive
          ? `0 0 40px ${node.glowColor}, 0 0 80px ${node.glowColor}, inset 0 0 30px ${node.glowColor}`
          : `0 0 20px ${node.glowColor}`,
      }}
    >
      {/* Outer ring */}
      <div
        className="absolute inset-0 rounded-full border-2 animate-pulse"
        style={{
          borderColor: node.color,
          animationDuration: isActive ? "1s" : "3s",
        }}
      />

      {/* Inner ring */}
      <div className="absolute inset-3 rounded-full border" style={{ borderColor: `${node.color}50` }} />

      {/* Icon */}
      <Icon
        className={`${iconSizes[size]} transition-all duration-300`}
        style={{
          color: node.color,
          filter: isActive ? `drop-shadow(0 0 10px ${node.color})` : "none",
        }}
      />

      {/* Glow pulse */}
      {isActive && (
        <div
          className="absolute inset-0 rounded-full animate-ping opacity-30"
          style={{ backgroundColor: node.color }}
        />
      )}
    </button>
  )
}
