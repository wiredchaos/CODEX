"use client"

import { cn } from "@/lib/utils"
import type { House } from "@/config/university"
import { Users, Target, CheckCircle } from "lucide-react"

interface HouseCardProps {
  house: House
  isSelected?: boolean
  onSelect?: () => void
}

export function HouseCard({ house, isSelected, onSelect }: HouseCardProps) {
  return (
    <button
      onClick={onSelect}
      className={cn(
        "w-full text-left p-5 rounded-lg border transition-all duration-300",
        house.color,
        isSelected ? house.borderColor + " border-2" : "border-border hover:border-primary/30",
      )}
    >
      <div className="flex items-center justify-between mb-3">
        <div>
          <h3 className="text-lg font-bold text-foreground">{house.name}</h3>
          <p className="text-xs text-muted-foreground">{house.fullName}</p>
        </div>
        {isSelected && <CheckCircle className="h-5 w-5 text-primary" />}
      </div>

      <p className="text-sm text-muted-foreground mb-4">{house.description}</p>

      <div className="space-y-2">
        <div className="flex items-center gap-2 text-xs">
          <Target className="h-3 w-3 text-primary" />
          <span className="text-foreground">{house.focus}</span>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <Users className="h-3 w-3 text-accent" />
          <span className="text-muted-foreground">{house.requirements.length} requirements</span>
        </div>
      </div>
    </button>
  )
}
