import { cn } from "@/lib/utils"
import { BADGE_PROGRESSION, getRankColor } from "@/config/university"
import { Shield, ChevronRight, Star, Lock } from "lucide-react"

interface RankProgressionProps {
  currentRank?: string
}

export function RankProgression({ currentRank = "Initiate" }: RankProgressionProps) {
  const currentIndex = BADGE_PROGRESSION.findIndex((b) => b.rank === currentRank)

  return (
    <div className="space-y-4">
      {BADGE_PROGRESSION.map((badge, index) => {
        const isUnlocked = index <= currentIndex
        const isCurrent = badge.rank === currentRank

        return (
          <div
            key={badge.rank}
            className={cn(
              "relative p-4 rounded-lg border transition-all",
              isUnlocked ? "bg-card/50" : "bg-card/20 opacity-60",
              isCurrent ? "border-primary neon-border-cyan" : "border-border",
            )}
          >
            <div className="flex items-start gap-4">
              <div
                className={cn(
                  "p-2 rounded-md border",
                  getRankColor(badge.rank),
                  isUnlocked ? "bg-primary/10" : "bg-muted",
                )}
              >
                {isUnlocked ? <Shield className="h-5 w-5" /> : <Lock className="h-5 w-5" />}
              </div>

              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <h3 className={cn("font-bold", getRankColor(badge.rank))}>{badge.rank}</h3>
                  <span className="text-xs text-muted-foreground">{badge.tier}</span>
                </div>

                <div className="space-y-2 mt-3">
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Requirements:</p>
                    <ul className="space-y-1">
                      {badge.requirements.map((req, i) => (
                        <li key={i} className="flex items-center gap-2 text-xs text-foreground">
                          <ChevronRight className="h-3 w-3 text-primary" />
                          {req}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Perks:</p>
                    <ul className="space-y-1">
                      {badge.perks.map((perk, i) => (
                        <li key={i} className="flex items-center gap-2 text-xs text-foreground">
                          <Star className="h-3 w-3 text-amber-400" />
                          {perk}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            {isCurrent && (
              <div className="absolute -top-2 -right-2 px-2 py-0.5 text-[10px] font-bold bg-primary text-primary-foreground rounded">
                CURRENT
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}
