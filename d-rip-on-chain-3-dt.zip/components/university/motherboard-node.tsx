"use client"

import Link from "next/link"
import type { MotherboardSubsystem } from "@/config/university"
import { Activity, Wifi, WifiOff } from "lucide-react"

interface MotherboardNodeProps {
  subsystem: MotherboardSubsystem
}

export function MotherboardNode({ subsystem }: MotherboardNodeProps) {
  const statusIcons = {
    active: Activity,
    standby: Wifi,
    offline: WifiOff,
  }
  const StatusIcon = statusIcons[subsystem.status]

  return (
    <Link href={subsystem.route}>
      <div
        className="relative p-4 rounded-lg border bg-black/50 transition-all duration-300 hover:scale-105 cursor-pointer group"
        style={{
          borderColor: subsystem.status === "active" ? `${subsystem.color}50` : "rgba(255,255,255,0.1)",
          boxShadow: subsystem.status === "active" ? `0 0 20px ${subsystem.color}30` : "none",
        }}
      >
        {/* Status indicator */}
        <div className="absolute top-2 right-2 flex items-center gap-1">
          <StatusIcon
            className="w-3 h-3"
            style={{
              color:
                subsystem.status === "active" ? subsystem.color : subsystem.status === "standby" ? "#FFE066" : "#666",
            }}
          />
          <span
            className={`w-2 h-2 rounded-full ${subsystem.status === "active" ? "animate-pulse" : ""}`}
            style={{
              backgroundColor:
                subsystem.status === "active" ? subsystem.color : subsystem.status === "standby" ? "#FFE066" : "#444",
            }}
          />
        </div>

        {/* Node name */}
        <h3
          className="font-mono text-sm font-bold tracking-wider mb-1 group-hover:text-shadow-glow transition-all"
          style={{ color: subsystem.color }}
        >
          {subsystem.name}
        </h3>

        {/* Description */}
        <p className="text-xs text-white/40 font-mono">{subsystem.description}</p>

        {/* Connection line indicator */}
        <div
          className="absolute -bottom-px left-1/2 -translate-x-1/2 w-8 h-0.5 opacity-0 group-hover:opacity-100 transition-opacity"
          style={{ backgroundColor: subsystem.color }}
        />
      </div>
    </Link>
  )
}
