import { cn } from "@/lib/utils"
import { type BroadcastEpisode, getCategoryColor, getStatusColor, BROADCAST_AVATARS } from "@/config/broadcast"
import { Radio, Clock, Eye, EyeOff, Sparkles } from "lucide-react"
import Link from "next/link"

interface EpisodeCardProps {
  episode: BroadcastEpisode
}

export function EpisodeCard({ episode }: EpisodeCardProps) {
  const avatarInfo = BROADCAST_AVATARS[episode.primaryAvatar]
  const visibleClues = episode.clues.filter((c) => c.type === "visible").length
  const hiddenClues = episode.clues.filter((c) => c.type !== "visible").length

  return (
    <Link
      href={`/broadcast/${episode.id}`}
      className="group block p-5 rounded-lg border border-border bg-card/50 hover:bg-card/80 hover:border-primary/30 transition-all duration-300"
    >
      <div className="flex items-start justify-between gap-4 mb-3">
        <div className="flex items-center gap-2">
          <Radio className={cn("h-4 w-4", episode.status === "Live" ? "text-red-400 animate-pulse" : "text-primary")} />
          <span className={cn("px-2 py-0.5 text-xs font-medium rounded", getStatusColor(episode.status))}>
            {episode.status}
          </span>
        </div>
        <span className={cn("px-2 py-0.5 text-xs font-medium rounded border", getCategoryColor(episode.category))}>
          {episode.category}
        </span>
      </div>

      <h3 className="text-lg font-semibold text-foreground mb-2 group-hover:text-primary transition-colors">
        {episode.title}
      </h3>

      <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{episode.script.open}</p>

      <div className="flex items-center gap-4 text-xs text-muted-foreground mb-3">
        <div className="flex items-center gap-1">
          <Clock className="h-3 w-3" />
          <span>{new Date(episode.datetime).toLocaleDateString()}</span>
        </div>
        <div className="flex items-center gap-1">
          <Sparkles className="h-3 w-3 text-amber-400" />
          <span>{avatarInfo.name}</span>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex gap-1">
          {episode.realms.map((realm) => (
            <span
              key={realm}
              className="px-2 py-0.5 text-[10px] font-medium rounded bg-secondary text-secondary-foreground"
            >
              {realm}
            </span>
          ))}
        </div>
        <div className="flex items-center gap-2 text-xs">
          <div className="flex items-center gap-1 text-cyan-400">
            <Eye className="h-3 w-3" />
            <span>{visibleClues}</span>
          </div>
          <div className="flex items-center gap-1 text-fuchsia-400">
            <EyeOff className="h-3 w-3" />
            <span>{hiddenClues}</span>
          </div>
        </div>
      </div>
    </Link>
  )
}
