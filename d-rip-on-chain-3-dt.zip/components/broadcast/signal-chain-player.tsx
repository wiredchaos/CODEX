"use client"

import { useState, useRef, useEffect } from "react"
import { Volume2, VolumeX, Radio, Music2, ChevronUp, ChevronDown } from "lucide-react"
import { cn } from "@/lib/utils"
import { AUDIO_SOURCES, DJ_PERSONAS, DEFAULT_SIGNAL_CHAIN_VOLUME, SIGNAL_CHAIN_IDENTS } from "@/lib/pos/config"
import type { SignalChainMode, SignalChainState } from "@/lib/pos/types"

export function SignalChainPlayer() {
  const audioRef = useRef<HTMLAudioElement>(null)
  const [expanded, setExpanded] = useState(false)
  const [state, setState] = useState<SignalChainState>({
    mode: "LOW",
    volume: DEFAULT_SIGNAL_CHAIN_VOLUME,
    currentSource: "FM33",
    curator: "CHROME_FANG",
    isPlaying: false,
    currentTrack: {
      title: "Signal Chain Active",
      artist: "DJ Chrome Fang",
    },
  })

  const chromeFang = DJ_PERSONAS.find((d) => d.id === "CHROME_FANG")
  const fm33Source = AUDIO_SOURCES.find((s) => s.id === "fm33-main")

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = state.volume / 100
    }
  }, [state.volume])

  const togglePlay = () => {
    if (!audioRef.current) return

    if (state.isPlaying) {
      audioRef.current.pause()
    } else {
      audioRef.current.play()
    }
    setState((prev) => ({ ...prev, isPlaying: !prev.isPlaying }))
  }

  const setMode = (mode: SignalChainMode) => {
    const volumeMap: Record<SignalChainMode, number> = {
      OFF: 0,
      LOW: 12,
      MEDIUM: 35,
      FOCUS_MUTE: 0,
    }
    setState((prev) => ({
      ...prev,
      mode,
      volume: volumeMap[mode],
      isPlaying: mode !== "OFF" && mode !== "FOCUS_MUTE",
    }))
  }

  const switchSource = (source: "FM33" | "SPOTIFY") => {
    setState((prev) => ({ ...prev, currentSource: source }))
  }

  const randomIdent = SIGNAL_CHAIN_IDENTS[Math.floor(Math.random() * SIGNAL_CHAIN_IDENTS.length)]

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50">
      {/* Hidden audio element */}
      <audio ref={audioRef} src={fm33Source?.url} preload="none" loop />

      {/* Collapsed bar */}
      <div
        className={cn(
          "bg-zinc-950/95 backdrop-blur-lg border-t border-zinc-800 transition-all duration-300",
          expanded ? "h-48" : "h-14",
        )}
      >
        {/* Main control bar */}
        <div className="h-14 px-4 flex items-center justify-between">
          {/* Left: Status + DJ */}
          <div className="flex items-center gap-3">
            <button
              onClick={togglePlay}
              className={cn(
                "w-10 h-10 rounded-full flex items-center justify-center transition-all",
                state.isPlaying
                  ? "bg-cyan-500/20 text-cyan-400 animate-pulse"
                  : "bg-zinc-800 text-zinc-400 hover:bg-zinc-700",
              )}
            >
              {state.currentSource === "FM33" ? <Radio className="w-5 h-5" /> : <Music2 className="w-5 h-5" />}
            </button>

            <div className="hidden sm:block">
              <div className="text-xs text-zinc-500">Signal Chain by</div>
              <div className="text-sm font-medium text-cyan-400">{chromeFang?.name}</div>
            </div>

            {state.isPlaying && (
              <div className="hidden md:flex items-center gap-2 px-3 py-1 bg-cyan-500/10 rounded-full">
                <span className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" />
                <span className="text-xs text-cyan-400">LIVE</span>
              </div>
            )}
          </div>

          {/* Center: Track info */}
          <div className="flex-1 text-center px-4 hidden sm:block">
            <div className="text-sm font-medium text-white truncate">{state.currentTrack?.title}</div>
            <div className="text-xs text-zinc-500 truncate">{state.currentTrack?.artist}</div>
          </div>

          {/* Right: Controls */}
          <div className="flex items-center gap-3">
            {/* Source switcher */}
            <div className="hidden md:flex items-center gap-1 bg-zinc-900 rounded-lg p-1">
              <button
                onClick={() => switchSource("FM33")}
                className={cn(
                  "px-3 py-1 text-xs rounded-md transition-all",
                  state.currentSource === "FM33"
                    ? "bg-cyan-500 text-black font-medium"
                    : "text-zinc-400 hover:text-white",
                )}
              >
                33.3FM
              </button>
              <button
                onClick={() => switchSource("SPOTIFY")}
                className={cn(
                  "px-3 py-1 text-xs rounded-md transition-all",
                  state.currentSource === "SPOTIFY"
                    ? "bg-green-500 text-black font-medium"
                    : "text-zinc-400 hover:text-white",
                )}
              >
                Spotify
              </button>
            </div>

            {/* Volume */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setMode(state.mode === "FOCUS_MUTE" ? "LOW" : "FOCUS_MUTE")}
                className="text-zinc-400 hover:text-white transition-colors"
              >
                {state.mode === "FOCUS_MUTE" || state.volume === 0 ? (
                  <VolumeX className="w-5 h-5" />
                ) : (
                  <Volume2 className="w-5 h-5" />
                )}
              </button>
              <input
                type="range"
                min="0"
                max="100"
                value={state.volume}
                onChange={(e) => setState((prev) => ({ ...prev, volume: Number.parseInt(e.target.value) }))}
                className="w-20 h-1 bg-zinc-700 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:bg-cyan-400 [&::-webkit-slider-thumb]:rounded-full"
              />
              <span className="text-xs text-zinc-500 w-8">{state.volume}%</span>
            </div>

            {/* Expand toggle */}
            <button onClick={() => setExpanded(!expanded)} className="text-zinc-400 hover:text-white transition-colors">
              {expanded ? <ChevronDown className="w-5 h-5" /> : <ChevronUp className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Expanded panel */}
        {expanded && (
          <div className="px-4 py-3 border-t border-zinc-800/50">
            {/* Mode selector */}
            <div className="flex items-center gap-2 mb-3">
              <span className="text-xs text-zinc-500 w-20">Mode:</span>
              <div className="flex gap-1">
                {(["OFF", "LOW", "MEDIUM", "FOCUS_MUTE"] as SignalChainMode[]).map((mode) => (
                  <button
                    key={mode}
                    onClick={() => setMode(mode)}
                    className={cn(
                      "px-3 py-1 text-xs rounded-md transition-all",
                      state.mode === mode
                        ? "bg-cyan-500 text-black font-medium"
                        : "bg-zinc-800 text-zinc-400 hover:bg-zinc-700",
                    )}
                  >
                    {mode === "FOCUS_MUTE" ? "Focus" : mode}
                  </button>
                ))}
              </div>
            </div>

            {/* DJ Ident */}
            <div className="p-3 bg-zinc-900/50 rounded-lg border border-zinc-800">
              <p className="text-sm text-zinc-400 italic">"{randomIdent}"</p>
              <p className="text-xs text-cyan-500 mt-1">
                — {chromeFang?.name}, {chromeFang?.role}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
