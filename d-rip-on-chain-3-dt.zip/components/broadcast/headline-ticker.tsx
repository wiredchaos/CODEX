"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"
import type { HeadlineTicker as TickerType } from "@/lib/pos/types"

const MOCK_HEADLINES: TickerType[] = [
  {
    id: "1",
    text: "BREAKING: New governance proposal passes with 67% approval",
    category: "BREAKING",
    timestamp: new Date(),
  },
  {
    id: "2",
    text: "DOGE surges 12% as meme season returns to crypto markets",
    category: "MARKETS",
    timestamp: new Date(),
  },
  {
    id: "3",
    text: "Red Chain and Blue Chain prepare for primetime debate",
    category: "POLITICS",
    timestamp: new Date(),
  },
  {
    id: "4",
    text: "AI regulatory framework advances through Circuit Court review",
    category: "TECH",
    timestamp: new Date(),
  },
  { id: "5", text: "Web3 creators break streaming records on 33.3FM", category: "CULTURE", timestamp: new Date() },
]

const categoryColors: Record<string, string> = {
  BREAKING: "bg-red-600 text-white",
  MARKETS: "bg-green-600 text-white",
  POLITICS: "bg-purple-600 text-white",
  TECH: "bg-blue-600 text-white",
  CULTURE: "bg-pink-600 text-white",
}

export function HeadlineTicker({ className }: { className?: string }) {
  const [headlines] = useState<TickerType[]>(MOCK_HEADLINES)

  return (
    <div className={cn("bg-zinc-950 border-y border-zinc-800 overflow-hidden", className)}>
      <div className="flex animate-ticker">
        {[...headlines, ...headlines].map((headline, idx) => (
          <div key={`${headline.id}-${idx}`} className="flex items-center shrink-0 px-4 py-2">
            <span className={cn("px-2 py-0.5 text-xs font-bold rounded mr-3", categoryColors[headline.category])}>
              {headline.category}
            </span>
            <span className="text-sm text-zinc-300 whitespace-nowrap">{headline.text}</span>
            <span className="mx-6 text-zinc-700">|</span>
          </div>
        ))}
      </div>

      <style jsx>{`
        @keyframes ticker {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-ticker {
          animation: ticker 60s linear infinite;
        }
        .animate-ticker:hover {
          animation-play-state: paused;
        }
      `}</style>
    </div>
  )
}
