import type { POSChannel, BroadcastStatus } from "@/lib/pos/types"
import { RadioTower, MessageSquare, TrendingUp, Sparkles, Scale, Swords } from "lucide-react"

const iconMap: Record<string, typeof RadioTower> = {
  "radio-tower": RadioTower,
  "message-square": MessageSquare,
  "trending-up": TrendingUp,
  sparkles: Sparkles,
  scale: Scale,
  swords: Swords,
}

interface ChannelHeaderProps {
  channel: POSChannel
  status?: BroadcastStatus
  currentShow?: string
}

export function ChannelHeader({ channel, status = "LIVE", currentShow }: ChannelHeaderProps) {
  const Icon = iconMap[channel.icon] || RadioTower

  return (
    <div className="relative overflow-hidden">
      {/* Background gradient */}
      <div
        className="absolute inset-0 opacity-20"
        style={{ background: `linear-gradient(135deg, ${channel.color}40, transparent)` }}
      />

      <div className="relative px-6 py-8 md:py-12">
        <div className="flex items-start gap-4">
          {/* Icon */}
          <div className="p-3 rounded-xl" style={{ backgroundColor: `${channel.color}20` }}>
            <Icon className="w-8 h-8" style={{ color: channel.color }} />
          </div>

          {/* Info */}
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <span className="text-xs font-mono text-zinc-500">POS //</span>
              <h1 className="text-2xl md:text-3xl font-bold text-white">{channel.name}</h1>
              {status === "LIVE" && (
                <span className="px-2 py-0.5 bg-red-600 text-white text-xs font-bold rounded animate-pulse">LIVE</span>
              )}
            </div>
            <p className="text-lg text-zinc-400 font-medium mb-1">{channel.tagline}</p>
            <p className="text-sm text-zinc-500">{channel.description}</p>

            {currentShow && (
              <div className="mt-4 inline-flex items-center gap-2 px-3 py-1.5 bg-zinc-900/80 rounded-lg border border-zinc-800">
                <span className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: channel.color }} />
                <span className="text-sm text-zinc-300">Now: {currentShow}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
