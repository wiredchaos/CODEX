"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Radio, Play, Pause, Volume2 } from "lucide-react"
import { cn } from "@/lib/utils"

interface RadioEmbedProps {
  streamUrl: string
  stationName?: string
  tagline?: string
  className?: string
}

export function RadioEmbed({
  streamUrl,
  stationName = "33.3FM DOGECHAIN",
  tagline = "The Signal Never Stops",
  className,
}: RadioEmbedProps) {
  const audioRef = useRef<HTMLAudioElement>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [volume, setVolume] = useState(50)

  const togglePlay = () => {
    if (!audioRef.current) return

    if (isPlaying) {
      audioRef.current.pause()
    } else {
      audioRef.current.play()
    }
    setIsPlaying(!isPlaying)
  }

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = Number.parseInt(e.target.value)
    setVolume(newVolume)
    if (audioRef.current) {
      audioRef.current.volume = newVolume / 100
    }
  }

  return (
    <div className={cn("p-4 bg-zinc-900 rounded-xl border border-zinc-800", className)}>
      <audio ref={audioRef} src={streamUrl} preload="none" />

      <div className="flex items-center gap-4">
        {/* Play button */}
        <button
          onClick={togglePlay}
          className={cn(
            "w-14 h-14 rounded-full flex items-center justify-center transition-all",
            isPlaying ? "bg-cyan-500 text-black" : "bg-zinc-800 text-cyan-400 hover:bg-zinc-700",
          )}
        >
          {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-1" />}
        </button>

        {/* Station info */}
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-cyan-400" />
            <span className="font-bold text-white">{stationName}</span>
            {isPlaying && (
              <span className="px-1.5 py-0.5 bg-red-600 text-white text-[10px] font-bold rounded animate-pulse">
                LIVE
              </span>
            )}
          </div>
          <p className="text-sm text-zinc-500">{tagline}</p>
        </div>

        {/* Volume */}
        <div className="flex items-center gap-2">
          <Volume2 className="w-4 h-4 text-zinc-500" />
          <input
            type="range"
            min="0"
            max="100"
            value={volume}
            onChange={handleVolumeChange}
            className="w-20 h-1 bg-zinc-700 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:bg-cyan-400 [&::-webkit-slider-thumb]:rounded-full"
          />
        </div>
      </div>
    </div>
  )
}
