"use client"

interface SpotifyEmbedProps {
  playlistId?: string
  albumId?: string
  episodeId?: string
  theme?: "dark" | "light"
  compact?: boolean
}

export function SpotifyEmbed({ playlistId, albumId, episodeId, theme = "dark", compact = false }: SpotifyEmbedProps) {
  let embedType = "playlist"
  let embedId = playlistId

  if (albumId) {
    embedType = "album"
    embedId = albumId
  } else if (episodeId) {
    embedType = "episode"
    embedId = episodeId
  }

  if (!embedId) {
    return (
      <div className="p-4 bg-zinc-900 rounded-xl border border-zinc-800 text-center">
        <p className="text-sm text-zinc-500">No Spotify content configured</p>
      </div>
    )
  }

  const height = compact ? 152 : 352

  return (
    <div className="rounded-xl overflow-hidden">
      <iframe
        style={{ borderRadius: "12px" }}
        src={`https://open.spotify.com/embed/${embedType}/${embedId}?utm_source=generator&theme=${theme === "dark" ? "0" : "1"}`}
        width="100%"
        height={height}
        frameBorder="0"
        allowFullScreen
        allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
        loading="lazy"
      />
    </div>
  )
}
