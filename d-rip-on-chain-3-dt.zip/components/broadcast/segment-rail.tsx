"use client"

import { cn } from "@/lib/utils"
import type { BWBSegment } from "@/lib/pos/types"
import { Play, Clock, Calendar } from "lucide-react"

interface SegmentRailProps {
  segments: BWBSegment[]
  title?: string
}

export function SegmentRail({ segments, title = "Schedule" }: SegmentRailProps) {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-white flex items-center gap-2">
        <Calendar className="w-5 h-5 text-zinc-400" />
        {title}
      </h3>

      <div className="grid gap-3">
        {segments.map((segment) => (
          <div
            key={segment.id}
            className={cn(
              "p-4 rounded-xl border transition-all cursor-pointer hover:scale-[1.02]",
              segment.status === "LIVE"
                ? "bg-red-950/30 border-red-500/50"
                : segment.status === "UPCOMING"
                  ? "bg-zinc-900/50 border-zinc-700 hover:border-cyan-500/50"
                  : "bg-zinc-900/30 border-zinc-800",
            )}
          >
            <div className="flex items-start gap-3">
              {/* Thumbnail */}
              <div className="w-20 h-14 rounded-lg bg-zinc-800 flex items-center justify-center shrink-0 overflow-hidden">
                {segment.thumbnailUrl ? (
                  <img src={segment.thumbnailUrl || "/placeholder.svg"} alt="" className="w-full h-full object-cover" />
                ) : (
                  <Play className="w-6 h-6 text-zinc-600" />
                )}
                {segment.status === "LIVE" && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                    <span className="px-1.5 py-0.5 bg-red-600 text-white text-[10px] font-bold rounded">LIVE</span>
                  </div>
                )}
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <h4 className="font-medium text-white truncate">{segment.title}</h4>
                <p className="text-sm text-zinc-500 line-clamp-1">{segment.description}</p>
                <div className="flex items-center gap-3 mt-1.5 text-xs text-zinc-600">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {segment.duration} min
                  </span>
                  {segment.hosts.length > 0 && <span>with {segment.hosts.join(", ")}</span>}
                </div>
              </div>

              {/* Status badge */}
              <div
                className={cn(
                  "px-2 py-1 text-xs font-medium rounded shrink-0",
                  segment.status === "LIVE"
                    ? "bg-red-600 text-white"
                    : segment.status === "UPCOMING"
                      ? "bg-cyan-500/20 text-cyan-400"
                      : "bg-zinc-800 text-zinc-500",
                )}
              >
                {segment.status}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
