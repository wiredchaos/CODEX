import { cn } from "@/lib/utils"
import { ARTIFACT_CLASSES, getArtifactTypeColor, type ArtifactType } from "@/config/artifacts"

export function ArtifactClassOverview() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {(Object.entries(ARTIFACT_CLASSES) as [ArtifactType, (typeof ARTIFACT_CLASSES)[ArtifactType]][]).map(
        ([type, info]) => (
          <div key={type} className={cn("p-4 rounded-lg border", getArtifactTypeColor(type))}>
            <div className="text-2xl mb-2">{info.icon}</div>
            <h3 className="font-semibold mb-1">{info.name}</h3>
            <p className="text-xs opacity-80">{info.description}</p>
          </div>
        ),
      )}
    </div>
  )
}
