import { cn } from "@/lib/utils"
import { type Artifact, getArtifactTypeColor, getRarityColor, ARTIFACT_CLASSES } from "@/config/artifacts"

interface ArtifactCardProps {
  artifact: Artifact
  owned?: boolean
}

export function ArtifactCard({ artifact, owned = false }: ArtifactCardProps) {
  const classInfo = ARTIFACT_CLASSES[artifact.type]

  return (
    <div
      className={cn(
        "relative p-4 rounded-lg border transition-all duration-300",
        owned
          ? "bg-card/80 border-primary/50"
          : "bg-card/30 border-border opacity-60 grayscale hover:grayscale-0 hover:opacity-100",
      )}
    >
      {owned && (
        <div className="absolute -top-2 -right-2 px-2 py-0.5 text-[10px] font-bold bg-primary text-primary-foreground rounded">
          OWNED
        </div>
      )}

      <div className="flex items-start gap-3 mb-3">
        <div className={cn("p-2 rounded-md border text-lg", getArtifactTypeColor(artifact.type))}>{classInfo.icon}</div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-foreground truncate">{artifact.name}</h3>
          <div className="flex items-center gap-2 mt-1">
            <span className={cn("text-xs font-medium", getRarityColor(artifact.rarity))}>{artifact.rarity}</span>
            <span className="text-xs text-muted-foreground">via {artifact.source}</span>
          </div>
        </div>
      </div>

      <p className="text-sm text-muted-foreground mb-3">{artifact.description}</p>

      <div className="pt-3 border-t border-border">
        <p className="text-xs text-muted-foreground">
          <span className="text-primary">Unlocks:</span> {artifact.unlocks}
        </p>
      </div>
    </div>
  )
}
