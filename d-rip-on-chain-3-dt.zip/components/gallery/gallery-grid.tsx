"use client"

import { useState } from "react"
import Image from "next/image"
import { neuroGalleryPhotos, type GalleryPhoto, type GalleryMode } from "@/lib/gallery/photos"
import { GalleryModal } from "./gallery-modal"

interface GalleryGridProps {
  photos?: GalleryPhoto[]
  filterMode?: GalleryMode | "ALL"
}

export function GalleryGrid({ photos = neuroGalleryPhotos, filterMode = "ALL" }: GalleryGridProps) {
  const [selectedPhoto, setSelectedPhoto] = useState<GalleryPhoto | null>(null)
  const [activeFilter, setActiveFilter] = useState<GalleryMode | "ALL">(filterMode)

  const filteredPhotos = activeFilter === "ALL" ? photos : photos.filter((p) => p.mode === activeFilter)

  const sortedPhotos = [...filteredPhotos].sort((a, b) => a.priority - b.priority)

  return (
    <div className="space-y-6">
      {/* Filter Controls */}
      <div className="flex items-center justify-center gap-2">
        <button
          onClick={() => setActiveFilter("ALL")}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
            activeFilter === "ALL"
              ? "bg-primary text-primary-foreground"
              : "bg-muted hover:bg-muted/80 text-muted-foreground"
          }`}
        >
          All
        </button>
        <button
          onClick={() => setActiveFilter("AKASHIC")}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
            activeFilter === "AKASHIC"
              ? "bg-cyan-500 text-black"
              : "bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
          }`}
        >
          AKASHIC
        </button>
        <button
          onClick={() => setActiveFilter("CORPORATE")}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
            activeFilter === "CORPORATE"
              ? "bg-primary text-primary-foreground"
              : "bg-primary/10 hover:bg-primary/20 text-primary border border-primary/30"
          }`}
        >
          CORPORATE
        </button>
      </div>

      {/* Photo Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {sortedPhotos.map((photo) => (
          <GalleryCard key={photo.id} photo={photo} onClick={() => setSelectedPhoto(photo)} />
        ))}
      </div>

      {/* Modal */}
      <GalleryModal photo={selectedPhoto} onClose={() => setSelectedPhoto(null)} />
    </div>
  )
}

interface GalleryCardProps {
  photo: GalleryPhoto
  onClick: () => void
}

function GalleryCard({ photo, onClick }: GalleryCardProps) {
  const isAkashic = photo.mode === "AKASHIC"

  return (
    <button
      onClick={onClick}
      className={`group relative aspect-[4/3] w-full overflow-hidden rounded-xl border transition-all duration-300 ${
        isAkashic
          ? "border-cyan-500/30 hover:border-cyan-500/60 hover:shadow-[0_0_30px_rgba(0,255,255,0.15)]"
          : "border-border hover:border-primary/50 hover:shadow-lg"
      }`}
      data-mode={photo.mode}
    >
      {/* Image */}
      <Image
        src={photo.src || "/placeholder.svg"}
        alt={photo.alt}
        fill
        className="object-cover transition-transform duration-500 group-hover:scale-110"
        sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
      />

      {/* Scanline overlay for AKASHIC */}
      {isAkashic && (
        <div className="absolute inset-0 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity bg-[repeating-linear-gradient(0deg,transparent,transparent_2px,rgba(0,255,255,0.05)_2px,rgba(0,255,255,0.05)_4px)]" />
      )}

      {/* Gradient Overlay */}
      <div
        className={`absolute inset-0 transition-opacity ${
          isAkashic
            ? "bg-gradient-to-t from-black via-black/50 to-transparent opacity-70 group-hover:opacity-90"
            : "bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-60 group-hover:opacity-80"
        }`}
      />

      {/* Featured Badge */}
      {photo.featured && (
        <div
          className={`absolute top-3 right-3 px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider ${
            isAkashic ? "bg-red-500/80 text-white" : "bg-primary/80 text-primary-foreground"
          }`}
        >
          Featured
        </div>
      )}

      {/* Mode Badge */}
      <div
        className={`absolute top-3 left-3 px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider ${
          isAkashic
            ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/50"
            : "bg-primary/20 text-primary border border-primary/50"
        }`}
      >
        {photo.mode}
      </div>

      {/* Content */}
      <div className="absolute bottom-0 left-0 right-0 p-4">
        <h3
          className={`font-bold text-lg tracking-tight transition-colors ${
            isAkashic ? "text-cyan-400 group-hover:text-cyan-300" : "text-white group-hover:text-primary"
          }`}
        >
          {photo.title}
        </h3>
        <p className={`text-sm ${isAkashic ? "text-cyan-300/70" : "text-neutral-300"}`}>{photo.subtitle}</p>
      </div>

      {/* Hover Glow Effect */}
      <div
        className={`absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none ${
          isAkashic
            ? "bg-gradient-to-t from-cyan-500/10 to-transparent"
            : "bg-gradient-to-t from-primary/10 to-transparent"
        }`}
      />
    </button>
  )
}
