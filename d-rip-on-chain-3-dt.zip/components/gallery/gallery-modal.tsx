"use client"

import { useEffect, useCallback } from "react"
import Image from "next/image"
import Link from "next/link"
import { X, ExternalLink, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { GalleryPhoto } from "@/lib/gallery/photos"
import { getPatchRoute } from "@/lib/gallery/photos"

interface GalleryModalProps {
  photo: GalleryPhoto | null
  onClose: () => void
}

export function GalleryModal({ photo, onClose }: GalleryModalProps) {
  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose()
    },
    [onClose],
  )

  useEffect(() => {
    if (photo) {
      document.body.style.overflow = "hidden"
      window.addEventListener("keydown", handleKeyDown)
    }
    return () => {
      document.body.style.overflow = ""
      window.removeEventListener("keydown", handleKeyDown)
    }
  }, [photo, handleKeyDown])

  if (!photo) return null

  const patchRoute = getPatchRoute(photo.patchTag)
  const isAkashic = photo.mode === "AKASHIC"

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      {/* Backdrop */}
      <div
        className={`absolute inset-0 ${
          isAkashic ? "bg-black/90 backdrop-blur-md" : "bg-background/95 backdrop-blur-sm"
        }`}
      />

      {/* Modal Content */}
      <div
        className={`relative max-w-4xl w-full max-h-[90vh] overflow-auto rounded-xl border ${
          isAkashic
            ? "border-cyan-500/50 bg-black/80 shadow-[0_0_60px_rgba(0,255,255,0.2)]"
            : "border-border bg-card shadow-xl"
        }`}
        onClick={(e) => e.stopPropagation()}
        data-mode={photo.mode}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className={`absolute top-4 right-4 z-10 p-2 rounded-full transition-colors ${
            isAkashic
              ? "bg-cyan-500/20 hover:bg-cyan-500/40 text-cyan-400"
              : "bg-muted hover:bg-muted/80 text-muted-foreground"
          }`}
        >
          <X className="w-5 h-5" />
        </button>

        {/* Image Section */}
        <div className="relative aspect-video w-full overflow-hidden">
          {/* Scanline overlay for AKASHIC mode */}
          {isAkashic && (
            <div className="absolute inset-0 z-10 pointer-events-none bg-[repeating-linear-gradient(0deg,transparent,transparent_2px,rgba(0,255,255,0.03)_2px,rgba(0,255,255,0.03)_4px)]" />
          )}
          <Image src={photo.src || "/placeholder.svg"} alt={photo.alt} fill className="object-cover" priority />
          {/* Mode badge */}
          <div
            className={`absolute top-4 left-4 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
              isAkashic
                ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/50"
                : "bg-primary/20 text-primary border border-primary/50"
            }`}
          >
            {photo.mode}
          </div>
        </div>

        {/* Content Section */}
        <div className="p-6 space-y-4">
          {/* Title */}
          <div>
            <h2 className={`text-2xl font-bold tracking-tight ${isAkashic ? "text-cyan-400" : "text-foreground"}`}>
              {photo.title}
            </h2>
            <p className={`text-sm ${isAkashic ? "text-cyan-300/70" : "text-muted-foreground"}`}>{photo.subtitle}</p>
          </div>

          {/* Description */}
          {photo.description && (
            <p className={`text-sm leading-relaxed ${isAkashic ? "text-neutral-300" : "text-muted-foreground"}`}>
              {photo.description}
            </p>
          )}

          {/* Patch Tag */}
          <div className="flex items-center gap-2">
            <span
              className={`text-xs uppercase tracking-wider ${isAkashic ? "text-cyan-500/70" : "text-muted-foreground"}`}
            >
              Patch:
            </span>
            <span
              className={`px-2 py-0.5 rounded text-xs font-mono ${
                isAkashic
                  ? "bg-red-500/20 text-red-400 border border-red-500/30"
                  : "bg-primary/10 text-primary border border-primary/20"
              }`}
            >
              {photo.patchTag}
            </span>
          </div>

          {/* CTA */}
          <div className="pt-4 flex gap-3">
            {patchRoute && !photo.comingSoon ? (
              <Link href={patchRoute} className="flex-1">
                <Button
                  className={`w-full ${
                    isAkashic ? "bg-cyan-500 hover:bg-cyan-600 text-black" : "bg-primary hover:bg-primary/90"
                  }`}
                >
                  <Zap className="w-4 h-4 mr-2" />
                  ENTER PATCH
                  <ExternalLink className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            ) : (
              <Button
                disabled
                className={`flex-1 ${
                  isAkashic
                    ? "bg-neutral-800 text-cyan-400/50 border border-cyan-500/30"
                    : "bg-muted text-muted-foreground"
                }`}
              >
                <Zap className="w-4 h-4 mr-2 animate-pulse" />
                COMING ONLINE
              </Button>
            )}
            <Button variant="outline" onClick={onClose} className={isAkashic ? "border-cyan-500/30 text-cyan-400" : ""}>
              Close
            </Button>
          </div>
        </div>

        {/* Film grain effect for AKASHIC */}
        {isAkashic && (
          <div className="absolute inset-0 pointer-events-none opacity-20 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMDAiIGhlaWdodD0iMzAwIj48ZmlsdGVyIGlkPSJhIiB4PSIwIiB5PSIwIj48ZmVUdXJidWxlbmNlIGJhc2VGcmVxdWVuY3k9Ii43NSIgc3RpdGNoVGlsZXM9InN0aXRjaCIgdHlwZT0iZnJhY3RhbE5vaXNlIi8+PGZlQ29sb3JNYXRyaXggdHlwZT0ic2F0dXJhdGUiIHZhbHVlcz0iMCIvPjwvZmlsdGVyPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbHRlcj0idXJsKCNhKSIvPjwvc3ZnPg==')]" />
        )}
      </div>
    </div>
  )
}
