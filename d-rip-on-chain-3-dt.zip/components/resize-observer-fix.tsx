"use client"

import { useEffect } from "react"

export function ResizeObserverFix() {
  useEffect(() => {
    const handler = (e: ErrorEvent) => {
      if (e.message === "ResizeObserver loop completed with undelivered notifications.") {
        e.stopImmediatePropagation()
      }
    }

    window.addEventListener("error", handler)
    return () => window.removeEventListener("error", handler)
  }, [])

  return null
}
