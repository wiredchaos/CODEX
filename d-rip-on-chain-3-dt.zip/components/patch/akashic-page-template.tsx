import Link from "next/link"
import type { PatchDefinition } from "@/config/patches"
import { CinematicHeader } from "@/components/akashic/cinematic-header"
import { FilmCard } from "@/components/akashic/film-card"
import { DossierSection } from "@/components/akashic/dossier-section"
import { EnterChaosCTA } from "@/components/akashic/enter-chaos-cta"
import { ArrowLeft } from "lucide-react"

interface AkashicPageTemplateProps {
  patch: PatchDefinition
}

export function AkashicPageTemplate({ patch }: AkashicPageTemplateProps) {
  // Map category to chapter format
  const chapter = patch.category === "Lore" ? "CODEX ENTRY" : patch.category === "ARG" ? "SIGNAL FILE" : "TRANSMISSION"

  return (
    <div className="min-h-screen bg-black">
      {/* Back navigation */}
      <div className="absolute top-4 left-4 z-20">
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-sm text-white/50 hover:text-[#00FFFF] transition-colors font-mono tracking-wider"
        >
          <ArrowLeft className="h-4 w-4" />
          EXIT TO HUB
        </Link>
      </div>

      {/* Cinematic Header */}
      <CinematicHeader
        title={patch.name}
        subtitle={patch.shortDescription.toUpperCase()}
        chapter={chapter}
        tagline={patch.howItFits}
      />

      {/* Content */}
      <div className="max-w-4xl mx-auto px-6 pb-16">
        {/* Main Dossier */}
        <DossierSection title="OPERATIONAL BRIEFING" classification="VII ACTS">
          <p className="text-lg leading-relaxed">{patch.longDescription}</p>
        </DossierSection>

        {/* Protocol Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-12">
          <FilmCard title="INITIATION SEQUENCE" chapter="F3 FILM3" accentColor="cyan">
            <ol className="space-y-3 text-sm">
              {patch.startSteps.map((step, i) => (
                <li key={i} className="flex items-start gap-3 text-white/70">
                  <span className="text-[#00FFFF] font-mono">{String(i + 1).padStart(2, "0")}</span>
                  <span>{step}</span>
                </li>
              ))}
            </ol>
          </FilmCard>

          <FilmCard title="TRAJECTORY PROTOCOL" chapter="ROADMAP" accentColor="red">
            <ul className="space-y-2 text-sm">
              {patch.roadmap.map((item, i) => (
                <li key={i} className="flex items-start gap-2 text-white/70">
                  <span className="text-[#FF3131]">→</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </FilmCard>
        </div>

        {/* CTA */}
        <EnterChaosCTA href="/patches" label="EXPLORE MORE SIGNALS" />
      </div>
    </div>
  )
}
