import type { PatchDefinition } from "@/config/patches"
import { PatchCard } from "./patch-card"

interface PatchGridProps {
  patches: PatchDefinition[]
}

export function PatchGrid({ patches }: PatchGridProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {patches.map((patch) => (
        <PatchCard key={patch.slug} patch={patch} />
      ))}
    </div>
  )
}
