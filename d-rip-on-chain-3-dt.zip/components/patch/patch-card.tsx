import Link from "next/link"
import { cn } from "@/lib/utils"
import { type PatchDefinition, getCategoryColor, getStatusColor } from "@/config/patches"
import { ArrowRight } from "lucide-react"

interface PatchCardProps {
  patch: PatchDefinition
}

export function PatchCard({ patch }: PatchCardProps) {
  return (
    <Link href={`/${patch.slug}`} className="group block">
      <div className="relative h-full rounded-lg border border-border bg-card p-5 transition-all duration-300 hover:border-primary/50 hover:shadow-[0_0_30px_-5px] hover:shadow-primary/20 hover:scale-[1.02]">
        {/* Glow effect on hover */}
        <div className="absolute inset-0 rounded-lg bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

        <div className="relative space-y-3">
          {/* Header with badges */}
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-bold text-lg tracking-tight text-foreground group-hover:text-primary transition-colors">
              {patch.name}
            </h3>
            <span
              className={cn(
                "shrink-0 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider rounded",
                getStatusColor(patch.status),
              )}
            >
              {patch.status}
            </span>
          </div>

          {/* Category badge */}
          <div className="flex items-center gap-2">
            <span className={cn("px-2.5 py-1 text-xs font-medium rounded border", getCategoryColor(patch.category))}>
              {patch.category}
            </span>
          </div>

          {/* Description */}
          <p className="text-sm text-muted-foreground leading-relaxed line-clamp-2">{patch.shortDescription}</p>

          {/* Enter button */}
          <div className="pt-2 flex items-center text-sm font-medium text-primary opacity-0 group-hover:opacity-100 transition-opacity">
            Enter Patch
            <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </div>
        </div>
      </div>
    </Link>
  )
}
