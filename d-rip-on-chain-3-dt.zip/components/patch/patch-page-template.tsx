import Link from "next/link"
import { type PatchDefinition, getCategoryColor, getStatusColor } from "@/config/patches"
import { ArrowLeft, BookOpen, Compass, Map } from "lucide-react"

interface PatchPageTemplateProps {
  patch: PatchDefinition
}

export function PatchPageTemplate({ patch }: PatchPageTemplateProps) {
  return (
    <div className="space-y-8">
      {/* Back navigation */}
      <Link
        href="/"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        <ArrowLeft className="h-4 w-4" />
        Return to Hub
      </Link>

      {/* Header - Corporate style */}
      <section className="space-y-4">
        <div className="flex flex-wrap items-center gap-3">
          <span className={`corporate-badge ${getCategoryColor(patch.category)}`}>{patch.category}</span>
          <span className={`corporate-badge ${getStatusColor(patch.status)}`}>{patch.status}</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">{patch.name}</h1>
        <p className="text-xl text-muted-foreground">{patch.shortDescription}</p>
      </section>

      {/* Two column layout - Corporate clean */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left column - About */}
        <div className="space-y-6">
          <div className="corporate-card p-6">
            <div className="flex items-center gap-2 mb-4">
              <BookOpen className="h-5 w-5 text-[#00FFFF]" />
              <h2 className="corporate-heading text-lg">What This Patch Does</h2>
            </div>
            <p className="text-muted-foreground leading-relaxed">{patch.longDescription}</p>
          </div>

          <div className="corporate-card p-6">
            <div className="flex items-center gap-2 mb-4">
              <Compass className="h-5 w-5 text-[#A35FFF]" />
              <h2 className="corporate-heading text-lg">How It Fits WIRED CHAOS META</h2>
            </div>
            <p className="text-muted-foreground leading-relaxed">{patch.howItFits}</p>
          </div>
        </div>

        {/* Right column - Actions */}
        <div className="space-y-6">
          <div className="corporate-card p-6 border-[#00FFFF]/30">
            <h2 className="corporate-heading text-lg mb-4">Start Here</h2>
            <ol className="space-y-3">
              {patch.startSteps.map((step, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-[#00FFFF]/20 text-[#00FFFF] text-sm font-medium flex items-center justify-center">
                    {i + 1}
                  </span>
                  <span className="text-muted-foreground">{step}</span>
                </li>
              ))}
            </ol>
          </div>

          <div className="corporate-card p-6">
            <div className="flex items-center gap-2 mb-4">
              <Map className="h-5 w-5 text-muted-foreground" />
              <h2 className="corporate-heading text-lg">Roadmap</h2>
            </div>
            <ul className="space-y-2">
              {patch.roadmap.map((item, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                  <span className="text-[#00FFFF] mt-0.5">→</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Footer navigation - Corporate buttons */}
      <section className="flex flex-wrap gap-4 pt-6 border-t border-border">
        <Link href="/" className="corporate-btn">
          Return to Hub
        </Link>
        <Link
          href="/patches"
          className="px-4 py-2 text-sm font-medium rounded-md border border-white/20 hover:bg-white/5 transition-colors text-white"
        >
          View All Patches
        </Link>
      </section>
    </div>
  )
}
