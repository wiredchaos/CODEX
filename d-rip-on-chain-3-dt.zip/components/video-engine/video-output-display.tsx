"use client"

import { useState } from "react"
import type { AnswerVideoResponse } from "@/config/video-engine"
import { AVATARS, ENVIRONMENTS } from "@/config/video-engine"
import { Button } from "@/components/ui/button"

interface VideoOutputDisplayProps {
  output: AnswerVideoResponse | null
  isLoading?: boolean
}

export function VideoOutputDisplay({ output, isLoading }: VideoOutputDisplayProps) {
  const [isPlaying, setIsPlaying] = useState(false)

  if (isLoading) {
    return (
      <div className="border border-cyan-500/30 rounded-lg bg-black/80 p-6">
        <div className="aspect-video bg-zinc-900 rounded-lg flex items-center justify-center mb-4">
          <div className="text-center">
            <div className="w-12 h-12 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
            <p className="text-sm font-mono text-cyan-400">GENERATING RESPONSE...</p>
            <p className="text-xs text-zinc-600 mt-1">Rendering avatar + environment</p>
          </div>
        </div>
      </div>
    )
  }

  if (!output) {
    return (
      <div className="border border-zinc-800 rounded-lg bg-zinc-900/50 p-6">
        <div className="aspect-video bg-zinc-950 rounded-lg flex items-center justify-center mb-4">
          <div className="text-center">
            <div className="w-16 h-16 border border-zinc-700 rounded-full flex items-center justify-center mx-auto mb-3">
              <svg className="w-8 h-8 text-zinc-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1.5}
                  d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"
                />
              </svg>
            </div>
            <p className="text-sm font-mono text-zinc-500">NO OUTPUT</p>
            <p className="text-xs text-zinc-700 mt-1">Submit a prompt to generate video response</p>
          </div>
        </div>
      </div>
    )
  }

  const avatar = AVATARS.find((a) => a.signature_pose === output.avatar_pose)
  const environment = ENVIRONMENTS.find((e) => e.id === output.environment)

  return (
    <div className="border border-cyan-500/30 rounded-lg bg-black/80 overflow-hidden">
      {/* Video Player Area */}
      <div className="aspect-video bg-zinc-950 relative">
        {/* Environment Background */}
        <div
          className="absolute inset-0"
          style={{
            background: environment
              ? `linear-gradient(135deg, ${environment.lighting.base_color}, ${environment.lighting.accent_color}15)`
              : "#000",
          }}
        />

        {/* Scanline Overlay */}
        <div className="absolute inset-0 pointer-events-none opacity-20 scanline-overlay" />

        {/* Play Button Overlay */}
        <div className="absolute inset-0 flex items-center justify-center">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="w-20 h-20 rounded-full bg-cyan-500/20 border-2 border-cyan-400 flex items-center justify-center hover:bg-cyan-500/30 transition-colors group"
          >
            {isPlaying ? (
              <svg className="w-8 h-8 text-cyan-400" fill="currentColor" viewBox="0 0 24 24">
                <rect x="6" y="4" width="4" height="16" />
                <rect x="14" y="4" width="4" height="16" />
              </svg>
            ) : (
              <svg className="w-8 h-8 text-cyan-400 ml-1" fill="currentColor" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z" />
              </svg>
            )}
          </button>
        </div>

        {/* Duration Badge */}
        <div className="absolute bottom-3 right-3 px-2 py-1 bg-black/80 rounded text-xs font-mono text-cyan-400">
          {output.duration_seconds}s
        </div>

        {/* Environment Badge */}
        {environment && (
          <div className="absolute top-3 left-3 px-2 py-1 bg-black/80 rounded text-xs font-mono text-zinc-400">
            {environment.name}
          </div>
        )}
      </div>

      {/* Text Response */}
      <div className="p-4 border-t border-cyan-500/20">
        <div className="flex items-start gap-3 mb-4">
          {/* Avatar Indicator */}
          {avatar && (
            <div
              className="w-10 h-10 rounded-full flex-shrink-0"
              style={{
                background: `radial-gradient(circle, ${avatar.lighting_profile.primary_color}60, ${avatar.lighting_profile.primary_color}20)`,
                boxShadow: `0 0 15px ${avatar.lighting_profile.primary_color}40`,
              }}
            />
          )}

          {/* Response Text */}
          <div className="flex-1">
            <p className="text-sm text-zinc-300 leading-relaxed font-mono">{output.text_answer}</p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-2">
          <Button
            size="sm"
            variant="outline"
            className="text-xs font-mono border-zinc-700 text-zinc-400 hover:text-cyan-400 hover:border-cyan-500/50 bg-transparent"
          >
            DOWNLOAD
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="text-xs font-mono border-zinc-700 text-zinc-400 hover:text-cyan-400 hover:border-cyan-500/50 bg-transparent"
          >
            SHARE
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="text-xs font-mono border-zinc-700 text-zinc-400 hover:text-cyan-400 hover:border-cyan-500/50 bg-transparent"
          >
            REGENERATE
          </Button>
        </div>
      </div>
    </div>
  )
}
