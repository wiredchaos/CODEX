"use client"

import { useState } from "react"
import { ENVIRONMENTS, type EnvironmentCategory } from "@/config/video-engine"

interface EnvironmentSelectorProps {
  selectedEnvironment: string
  onSelect: (envId: string) => void
  category?: EnvironmentCategory
}

const CATEGORY_LABELS: Record<EnvironmentCategory, string> = {
  business: "Business Patch",
  akira: "AKIRA Codex",
  creator: "Creator Codex",
  npc: "NPC Systems",
  fen: "FEN / Artifacts",
  vault33: "Vault 33",
  broadcast: "Broadcast",
}

const CATEGORY_COLORS: Record<EnvironmentCategory, string> = {
  business: "#FFE066",
  akira: "#FF3B3B",
  creator: "#F472B6",
  npc: "#00FFFF",
  fen: "#FFD700",
  vault33: "#A855F7",
  broadcast: "#F59E0B",
}

export function EnvironmentSelector({ selectedEnvironment, onSelect, category }: EnvironmentSelectorProps) {
  const [activeCategory, setActiveCategory] = useState<EnvironmentCategory | "all">(category || "all")

  const filteredEnvironments =
    activeCategory === "all" ? ENVIRONMENTS : ENVIRONMENTS.filter((e) => e.category === activeCategory)

  const categories = Array.from(new Set(ENVIRONMENTS.map((e) => e.category)))

  return (
    <div className="space-y-4">
      <h3 className="text-sm font-mono text-cyan-400 uppercase tracking-wider">Select Environment</h3>

      {/* Category Tabs */}
      {!category && (
        <div className="flex flex-wrap gap-2 pb-2 border-b border-zinc-800">
          <button
            onClick={() => setActiveCategory("all")}
            className={`px-3 py-1 text-xs font-mono rounded transition-colors ${
              activeCategory === "all"
                ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                : "text-zinc-500 hover:text-zinc-300"
            }`}
          >
            ALL
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1 text-xs font-mono rounded transition-colors ${
                activeCategory === cat ? "bg-zinc-800 border" : "text-zinc-500 hover:text-zinc-300"
              }`}
              style={{
                borderColor: activeCategory === cat ? CATEGORY_COLORS[cat] : "transparent",
                color: activeCategory === cat ? CATEGORY_COLORS[cat] : undefined,
              }}
            >
              {CATEGORY_LABELS[cat]}
            </button>
          ))}
        </div>
      )}

      {/* Environment Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-64 overflow-y-auto pr-2">
        {filteredEnvironments.map((env) => (
          <button
            key={env.id}
            onClick={() => onSelect(env.id)}
            className={`
              p-3 rounded-lg border text-left transition-all duration-300
              ${
                selectedEnvironment === env.id
                  ? "border-cyan-400 bg-cyan-500/10"
                  : "border-zinc-800 bg-zinc-900/50 hover:border-zinc-600"
              }
            `}
          >
            {/* Environment Preview */}
            <div
              className="h-16 rounded mb-2 relative overflow-hidden"
              style={{
                background: `linear-gradient(135deg, ${env.lighting.base_color}, ${env.lighting.accent_color}20)`,
              }}
            >
              <div
                className="absolute inset-0 opacity-30"
                style={{
                  background: `radial-gradient(circle at 30% 30%, ${env.lighting.accent_color}60, transparent 60%)`,
                }}
              />
              <span
                className="absolute bottom-1 right-1 px-1.5 py-0.5 text-[10px] font-mono rounded"
                style={{
                  backgroundColor: CATEGORY_COLORS[env.category] + "20",
                  color: CATEGORY_COLORS[env.category],
                }}
              >
                {env.category.toUpperCase()}
              </span>
            </div>

            {/* Environment Info */}
            <p className="text-sm font-mono text-zinc-200 mb-1">{env.name}</p>
            <p className="text-xs text-zinc-500 line-clamp-2">{env.description}</p>
          </button>
        ))}
      </div>
    </div>
  )
}
