"use client"

import { useState } from "react"
import { AVATARS } from "@/config/video-engine"

interface AvatarSelectorProps {
  selectedAvatar: string
  onSelect: (avatarId: string) => void
}

export function AvatarSelector({ selectedAvatar, onSelect }: AvatarSelectorProps) {
  const [hoveredAvatar, setHoveredAvatar] = useState<string | null>(null)

  return (
    <div className="space-y-4">
      <h3 className="text-sm font-mono text-cyan-400 uppercase tracking-wider">Select Avatar</h3>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
        {AVATARS.map((avatar) => (
          <button
            key={avatar.id}
            onClick={() => onSelect(avatar.id)}
            onMouseEnter={() => setHoveredAvatar(avatar.id)}
            onMouseLeave={() => setHoveredAvatar(null)}
            className={`
              relative p-3 rounded-lg border transition-all duration-300
              ${
                selectedAvatar === avatar.id
                  ? "border-cyan-400 bg-cyan-500/10"
                  : "border-zinc-800 bg-zinc-900/50 hover:border-zinc-600"
              }
            `}
          >
            {/* Avatar Glow */}
            <div
              className="w-12 h-12 mx-auto rounded-full mb-2 flex items-center justify-center"
              style={{
                background: `radial-gradient(circle, ${avatar.lighting_profile.primary_color}40, transparent)`,
                boxShadow:
                  selectedAvatar === avatar.id ? `0 0 20px ${avatar.lighting_profile.primary_color}60` : "none",
              }}
            >
              <div
                className="w-8 h-8 rounded-full"
                style={{ backgroundColor: avatar.lighting_profile.primary_color }}
              />
            </div>

            {/* Avatar Name */}
            <p className="text-xs font-mono text-center text-zinc-300 truncate">{avatar.name}</p>

            {/* Codename on hover */}
            {hoveredAvatar === avatar.id && (
              <div className="absolute -top-8 left-1/2 -translate-x-1/2 px-2 py-1 bg-black border border-zinc-700 rounded text-xs font-mono text-zinc-400 whitespace-nowrap z-10">
                {avatar.codename}
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  )
}
