"use client"

import { useState } from "react"
import { AvatarSelector } from "./avatar-selector"
import { EnvironmentSelector } from "./environment-selector"
import { VideoOutputDisplay } from "./video-output-display"
import { AVATARS, type AnswerVideoResponse, type AvatarEmotion } from "@/config/video-engine"
import { Button } from "@/components/ui/button"

const EMOTIONS: { value: AvatarEmotion; label: string }[] = [
  { value: "neutral", label: "NEUTRAL" },
  { value: "intensity", label: "INTENSITY" },
  { value: "wisdom", label: "WISDOM" },
  { value: "warning", label: "WARNING" },
  { value: "excitement", label: "EXCITEMENT" },
  { value: "mystery", label: "MYSTERY" },
  { value: "authority", label: "AUTHORITY" },
]

export function NPCVideoTerminal() {
  const [prompt, setPrompt] = useState("")
  const [selectedAvatar, setSelectedAvatar] = useState(AVATARS[0].id)
  const [selectedEnvironment, setSelectedEnvironment] = useState(AVATARS[0].default_environment)
  const [selectedEmotion, setSelectedEmotion] = useState<AvatarEmotion>("neutral")
  const [isLoading, setIsLoading] = useState(false)
  const [output, setOutput] = useState<AnswerVideoResponse | null>(null)
  const [showConfig, setShowConfig] = useState(false)

  const handleAvatarChange = (avatarId: string) => {
    setSelectedAvatar(avatarId)
    const avatar = AVATARS.find((a) => a.id === avatarId)
    if (avatar) {
      setSelectedEnvironment(avatar.default_environment)
    }
  }

  const handleSubmit = async () => {
    if (!prompt.trim()) return

    setIsLoading(true)
    try {
      const response = await fetch("/api/npc/answer-video", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt,
          avatar: selectedAvatar,
          emotion: selectedEmotion,
          environment: selectedEnvironment,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setOutput(data)
      }
    } catch (error) {
      console.error("Failed to generate response:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const currentAvatar = AVATARS.find((a) => a.id === selectedAvatar)

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      {/* Input Panel */}
      <div className="space-y-4">
        {/* Terminal Header */}
        <div className="border border-cyan-500/30 rounded-lg bg-black/80 overflow-hidden">
          <div className="px-4 py-2 border-b border-cyan-500/20 bg-cyan-500/5 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              <span className="text-xs font-mono text-cyan-400">WC META ANSWER + VIDEO ENGINE</span>
            </div>
            <span className="text-xs text-zinc-600 font-mono">v1.0</span>
          </div>

          <div className="p-4 space-y-4">
            {/* Current Avatar Display */}
            <div className="flex items-center gap-3 pb-3 border-b border-zinc-800">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center"
                style={{
                  background: currentAvatar
                    ? `radial-gradient(circle, ${currentAvatar.lighting_profile.primary_color}40, transparent)`
                    : undefined,
                  boxShadow: currentAvatar ? `0 0 20px ${currentAvatar.lighting_profile.primary_color}30` : undefined,
                }}
              >
                <div
                  className="w-8 h-8 rounded-full"
                  style={{ backgroundColor: currentAvatar?.lighting_profile.primary_color }}
                />
              </div>
              <div>
                <p className="text-sm font-mono text-zinc-200">{currentAvatar?.name}</p>
                <p className="text-xs text-zinc-500">{currentAvatar?.codename}</p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowConfig(!showConfig)}
                className="ml-auto text-xs font-mono text-zinc-500 hover:text-cyan-400"
              >
                {showConfig ? "HIDE CONFIG" : "SHOW CONFIG"}
              </Button>
            </div>

            {/* Collapsible Config */}
            {showConfig && (
              <div className="space-y-4 pb-4 border-b border-zinc-800">
                <AvatarSelector selectedAvatar={selectedAvatar} onSelect={handleAvatarChange} />
                <EnvironmentSelector selectedEnvironment={selectedEnvironment} onSelect={setSelectedEnvironment} />
              </div>
            )}

            {/* Emotion Selector */}
            <div className="space-y-2">
              <label className="text-xs font-mono text-zinc-500 uppercase">Emotion</label>
              <div className="flex flex-wrap gap-2">
                {EMOTIONS.map((emotion) => (
                  <button
                    key={emotion.value}
                    onClick={() => setSelectedEmotion(emotion.value)}
                    className={`px-3 py-1 text-xs font-mono rounded transition-colors ${
                      selectedEmotion === emotion.value
                        ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30"
                        : "bg-zinc-900 text-zinc-500 border border-zinc-800 hover:border-zinc-600"
                    }`}
                  >
                    {emotion.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Prompt Input */}
            <div className="space-y-2">
              <label className="text-xs font-mono text-zinc-500 uppercase">Prompt</label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Enter your query for the avatar..."
                rows={4}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-4 py-3 text-sm font-mono text-cyan-300 placeholder:text-zinc-600 focus:border-cyan-500 focus:outline-none resize-none"
              />
            </div>

            {/* Submit Button */}
            <Button
              onClick={handleSubmit}
              disabled={isLoading || !prompt.trim()}
              className="w-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 hover:bg-cyan-500/30 font-mono disabled:opacity-50"
            >
              {isLoading ? "GENERATING..." : "EXECUTE QUERY"}
            </Button>
          </div>
        </div>
      </div>

      {/* Output Panel */}
      <div>
        <VideoOutputDisplay output={output} isLoading={isLoading} />
      </div>
    </div>
  )
}
