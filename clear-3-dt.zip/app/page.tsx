"use client"

import { useState } from "react"
import { ChannelHeader } from "@/components/channel-header"
import { ChannelHero } from "@/components/channel-hero"
import { EpisodeRail } from "@/components/episode-rail"
import { VideoPlayer } from "@/components/video-player"
import { TrinityFloorMount } from "@/components/3d-background"
import { featuredEpisode, episodeRails, mockEpisodes } from "@/lib/mock-data"
import type { Episode } from "@/lib/types"
import { Badge } from "@/components/ui/badge"

export default function OTTPage() {
  const [selectedEpisode, setSelectedEpisode] = useState<Episode | null>(null)
  const [showPlayer, setShowPlayer] = useState(false)

  const handleEpisodeClick = (episodeId: string) => {
    const episode = mockEpisodes.find((e) => e.id === episodeId)
    if (episode) {
      setSelectedEpisode(episode)
      setShowPlayer(true)
    }
  }

  const handleClosePlayer = () => {
    setShowPlayer(false)
    setSelectedEpisode(null)
  }

  return (
    <div className="min-h-screen bg-background">
      <TrinityFloorMount floorId="CLEAR-001" timelineRef="akira-codex-main" opacity={0.4} />

      <ChannelHeader />

      <main className="pb-12">
        <ChannelHero episode={featuredEpisode} />

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 space-y-12 mt-12">
          <section className="space-y-5">
            <div className="space-y-1">
              <h2 className="text-2xl md:text-3xl font-serif font-bold tracking-tight">Latest Episodes</h2>
              <div className="glass-divider w-24" />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {mockEpisodes.slice(0, 4).map((episode) => (
                <button
                  key={episode.id}
                  onClick={() => handleEpisodeClick(episode.id)}
                  className="group relative flex flex-col focus:outline-none focus-visible:ring-2 focus-visible:ring-steel-accent/50 overflow-hidden"
                >
                  <div className="relative aspect-video overflow-hidden glass-card shadow-sm">
                    <img
                      src={episode.thumbnail || "/placeholder.svg"}
                      alt={episode.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors duration-300 flex items-center justify-center">
                      <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <div className="h-12 w-12 glass-surface flex items-center justify-center shadow-lg">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 24 24"
                            fill="currentColor"
                            className="h-5 w-5 text-white ml-0.5"
                          >
                            <path d="M8 5v14l11-7z" />
                          </svg>
                        </div>
                      </div>
                    </div>
                    <Badge variant="glass" className="absolute top-2 right-2 text-[10px]">
                      {episode.duration}
                    </Badge>
                  </div>
                  <div className="mt-3 space-y-1.5 text-left">
                    <h3 className="font-serif font-semibold text-sm line-clamp-2 group-hover:text-steel-accent transition-colors">
                      {episode.title}
                    </h3>
                    <div className="glass-divider" />
                    <p className="text-xs text-muted-foreground font-mono tracking-wider uppercase">
                      S{episode.season} E{episode.episode}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </section>

          {episodeRails.map((rail) => (
            <EpisodeRail key={rail.category} rail={rail} onEpisodeClick={handleEpisodeClick} />
          ))}
        </div>
      </main>

      {showPlayer && selectedEpisode && <VideoPlayer episode={selectedEpisode} onClose={handleClosePlayer} />}
    </div>
  )
}
