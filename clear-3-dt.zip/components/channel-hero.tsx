"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Play } from "lucide-react"
import type { Episode } from "@/lib/types"
import Image from "next/image"

interface ChannelHeroProps {
  episode: Episode
}

export function ChannelHero({ episode }: ChannelHeroProps) {
  return (
    <section className="relative w-full overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-background">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(0,217,255,0.12),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_50%,rgba(255,0,255,0.08),transparent_50%)]" />
        <div className="absolute inset-0 glass-shimmer opacity-40" />
        {/* Floating neon particles */}
        <div className="absolute top-20 left-10 h-2 w-2 rounded-full bg-cyan-400 blur-sm animate-pulse" />
        <div className="absolute top-40 right-20 h-3 w-3 rounded-full bg-fuchsia-500 blur-md animate-pulse delay-700" />
        <div className="absolute bottom-32 left-1/4 h-2 w-2 rounded-full bg-cyan-300 blur-sm animate-pulse delay-1000" />
      </div>

      <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left: Floating headline and metadata */}
          <div className="space-y-8 relative z-10">
            <div className="space-y-4">
              <Badge
                variant="outline"
                className="text-[10px] uppercase tracking-widest font-mono border-cyan-400/60 text-cyan-400 bg-cyan-400/10 backdrop-blur-sm px-3 py-1 neon-glow-cyan"
              >
                Live Channel
              </Badge>
              <h1 className="text-6xl md:text-7xl lg:text-8xl font-serif font-bold tracking-[-0.04em] text-balance leading-[0.95] text-foreground">
                CLEAR
              </h1>
              <p className="text-sm text-cyan-300/80 font-mono tracking-wide uppercase">
                The Intelligence Layer for Modern, Task-Based Economies
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              <Badge
                variant="secondary"
                className="holographic-border bg-background/40 text-foreground backdrop-blur-sm font-sans text-xs"
              >
                Business
              </Badge>
              <Badge
                variant="secondary"
                className="holographic-border bg-background/40 text-foreground backdrop-blur-sm font-sans text-xs"
              >
                Markets
              </Badge>
              <Badge
                variant="secondary"
                className="holographic-border bg-background/40 text-foreground backdrop-blur-sm font-sans text-xs"
              >
                Systems
              </Badge>
              <Badge
                variant="secondary"
                className="holographic-border bg-background/40 text-foreground backdrop-blur-sm font-sans text-xs"
              >
                Coordination
              </Badge>
            </div>

            <p className="text-[15px] text-foreground/70 text-pretty leading-relaxed max-w-lg font-sans">
              Institutional-grade briefings on coordination systems, task economies, and reputation-based work rails.
              The trusted intelligence surface before execution.
            </p>

            <div className="flex flex-wrap gap-3 pt-4">
              <Button
                size="lg"
                className="gap-2 glass-liquid text-cyan-50 hover:neon-glow-cyan font-medium relative overflow-hidden group"
              >
                <Play className="h-4 w-4 relative z-10" />
                <span className="relative z-10">Watch Now</span>
              </Button>
            </div>
          </div>

          {/* Right: Glass broadcast preview panel - 2D only per Trinity declaration */}
          <div className="relative">
            <div className="glass-liquid holographic-border relative aspect-video overflow-hidden group">
              <Image
                src={episode.thumbnail || "/placeholder.svg"}
                alt={episode.title}
                fill
                className="object-cover"
                priority
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

              {/* Broadcast metadata overlay */}
              <div className="absolute bottom-0 left-0 right-0 p-6 space-y-2">
                <div className="flex items-center gap-2 mb-3">
                  <div className="h-1.5 w-1.5 rounded-full bg-cyan-400 animate-pulse neon-glow-cyan" />
                  <span className="text-[10px] text-cyan-300/90 font-mono uppercase tracking-widest">Now Playing</span>
                </div>
                <p className="text-white font-serif font-semibold text-lg leading-tight line-clamp-2">
                  {episode.title}
                </p>
                <p className="text-cyan-200/60 text-xs font-mono tracking-wide">
                  S{episode.season} E{episode.episode} · {episode.duration}
                </p>
              </div>
            </div>

            {/* Trinity mount indicator */}
            <div className="absolute -bottom-6 right-0 text-[8px] font-mono text-cyan-500/30 uppercase tracking-widest">
              TRINITY:CLEAR-001
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
