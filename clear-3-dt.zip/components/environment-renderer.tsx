"use client"

import { useState, useEffect, useRef } from "react"
import { CLEAR_TRINITY_CONFIG, initTrinityMount } from "@/lib/trinity-mount"

/**
 * ENVIRONMENT RENDERER
 *
 * Trinity Core Consumer Mount
 * - Renders cinematic environment from shared Trinity system
 * - 3D if Trinity Core provides, video fallback otherwise
 * - No local 3D generation
 * - Hotspots + HUD supplied by core
 */

interface EnvironmentRendererProps {
  patchId: string
  kind: "lobby" | "timeline" | "portal"
  fallbackVideo?: string
  showHUD?: boolean
}

interface TrinityHotspot {
  id: string
  label: string
  position: { x: number; y: number }
  action: string
}

// Trinity Core HUD data (read-only from core)
const TRINITY_HUD_DATA = {
  patchId: "CLEAR",
  floorLabel: "BUSINESS INTELLIGENCE LAYER",
  status: "LIVE",
  accessLevel: "PUBLIC",
  realm: "BUSINESS",
}

// Trinity Core Hotspots (supplied by core, not generated)
const TRINITY_HOTSPOTS: TrinityHotspot[] = [
  { id: "hs-1", label: "MARKETS", position: { x: 15, y: 60 }, action: "navigate:markets" },
  { id: "hs-2", label: "SYSTEMS", position: { x: 75, y: 40 }, action: "navigate:systems" },
  { id: "hs-3", label: "BUILDERS", position: { x: 50, y: 80 }, action: "navigate:builders" },
]

export function EnvironmentRenderer({ patchId, kind, fallbackVideo, showHUD = true }: EnvironmentRendererProps) {
  const [mounted, setMounted] = useState(false)
  const [trinityAvailable, setTrinityAvailable] = useState(false)
  const [hotspotsVisible, setHotspotsVisible] = useState(true)
  const videoRef = useRef<HTMLVideoElement>(null)

  useEffect(() => {
    // Initialize Trinity mount (read-only)
    const status = initTrinityMount(CLEAR_TRINITY_CONFIG)

    // Check if Trinity 3D Core is available
    // In production, this would ping the Trinity Core service
    const checkTrinityCore = async () => {
      try {
        // Simulated Trinity Core availability check
        // Real implementation would call: await fetch('/api/trinity/status')
        const trinityEnabled =
          typeof window !== "undefined" && (window as unknown as { TRINITY_3D_CORE?: boolean }).TRINITY_3D_CORE === true

        setTrinityAvailable(trinityEnabled)
        console.log(`[TRINITY] Core available: ${trinityEnabled}`)
        console.log(`[TRINITY] Falling back to: ${trinityEnabled ? "3D mount" : "video/CSS"}`)
      } catch {
        setTrinityAvailable(false)
      }
    }

    checkTrinityCore()
    setMounted(true)

    return () => {
      console.log(`[TRINITY] EnvironmentRenderer unmounting: ${patchId}`)
    }
  }, [patchId])

  if (!mounted) return null

  return (
    <div
      className="fixed inset-0 -z-10 overflow-hidden"
      data-patch-id={patchId}
      data-kind={kind}
      data-trinity-mount="consumer"
      data-access-mode="read-only"
    >
      {/* LAYER 1: Base gradient (always present) */}
      <div className="absolute inset-0 bg-gradient-to-br from-black via-slate-950 to-black" />

      {/* LAYER 2: Trinity Core Mount Point or Video Fallback */}
      {trinityAvailable ? (
        // Trinity 3D Core mount point - core injects content here
        <div
          id="trinity-3d-mount"
          className="absolute inset-0"
          data-trinity-floor={CLEAR_TRINITY_CONFIG.floorId}
          data-timeline-ref={CLEAR_TRINITY_CONFIG.timelineRef}
        >
          {/* Trinity Core renders here - we don't generate content */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-cyan-500/20 font-mono text-xs">[TRINITY CORE MOUNT ACTIVE]</div>
          </div>
        </div>
      ) : (
        // Video/CSS fallback when Trinity Core unavailable
        <div className="absolute inset-0">
          {fallbackVideo ? (
            <video
              ref={videoRef}
              autoPlay
              loop
              muted
              playsInline
              className="absolute inset-0 w-full h-full object-cover opacity-30"
            >
              <source src={fallbackVideo} type="video/mp4" />
            </video>
          ) : (
            // CSS cinematic fallback
            <div className="absolute inset-0 trinity-ambient-fallback">
              {/* Animated radial glows */}
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_30%_20%,rgba(0,217,255,0.12),transparent_50%)] animate-pulse-slow" />
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_70%_80%,rgba(255,0,255,0.08),transparent_50%)] animate-pulse-slower" />
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_50%,rgba(0,217,255,0.05),transparent_70%)]" />

              {/* Grid overlay */}
              <div
                className="absolute inset-0 opacity-[0.04]"
                style={{
                  backgroundImage: `
                    linear-gradient(rgba(0,217,255,0.4) 1px, transparent 1px),
                    linear-gradient(90deg, rgba(0,217,255,0.4) 1px, transparent 1px)
                  `,
                  backgroundSize: "60px 60px",
                }}
              />

              {/* Scan line effect */}
              <div className="absolute inset-0 pointer-events-none overflow-hidden">
                <div className="absolute w-full h-[2px] bg-gradient-to-r from-transparent via-cyan-500/20 to-transparent animate-scan-line" />
              </div>
            </div>
          )}
        </div>
      )}

      {/* LAYER 3: Trinity Hotspots (supplied by core) */}
      {showHUD && hotspotsVisible && (
        <div className="absolute inset-0 pointer-events-none">
          {TRINITY_HOTSPOTS.map((hotspot) => (
            <button
              key={hotspot.id}
              className="absolute pointer-events-auto group"
              style={{ left: `${hotspot.position.x}%`, top: `${hotspot.position.y}%` }}
              onClick={() => console.log(`[TRINITY] Hotspot action: ${hotspot.action}`)}
            >
              <div className="relative">
                <div className="w-3 h-3 rounded-full bg-cyan-500/30 animate-ping absolute" />
                <div className="w-3 h-3 rounded-full bg-cyan-500/60 relative" />
                <div className="absolute left-5 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <span className="text-[10px] font-mono text-cyan-400 whitespace-nowrap bg-black/60 px-2 py-1 rounded">
                    {hotspot.label}
                  </span>
                </div>
              </div>
            </button>
          ))}
        </div>
      )}

      {/* LAYER 4: Trinity HUD (supplied by core) */}
      {showHUD && (
        <>
          {/* Top-left status */}
          <div className="absolute top-4 left-4 flex items-center gap-3">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse" />
              <span className="text-[10px] font-mono text-cyan-500/60 uppercase tracking-widest">
                {TRINITY_HUD_DATA.status}
              </span>
            </div>
            <div className="h-3 w-px bg-cyan-500/20" />
            <span className="text-[10px] font-mono text-white/40 uppercase tracking-widest">
              {TRINITY_HUD_DATA.floorLabel}
            </span>
          </div>

          {/* Top-right realm indicator */}
          <div className="absolute top-4 right-4">
            <span className="text-[10px] font-mono text-cyan-500/40 uppercase tracking-widest">
              {TRINITY_HUD_DATA.realm} REALM
            </span>
          </div>

          {/* Bottom-left mount info */}
          <div className="absolute bottom-4 left-4 space-y-1">
            <div className="text-[8px] font-mono text-cyan-500/30 uppercase tracking-widest">
              TRINITY:{CLEAR_TRINITY_CONFIG.floorId}
            </div>
            <div className="text-[8px] font-mono text-magenta-500/30 uppercase tracking-widest">
              TIMELINE:{CLEAR_TRINITY_CONFIG.timelineRef}
            </div>
          </div>

          {/* Bottom-right access level */}
          <div className="absolute bottom-4 right-4">
            <span className="text-[8px] font-mono text-white/20 uppercase tracking-widest">
              ACCESS: {TRINITY_HUD_DATA.accessLevel} | MODE: READ-ONLY
            </span>
          </div>

          {/* Hotspot toggle */}
          <button
            onClick={() => setHotspotsVisible(!hotspotsVisible)}
            className="absolute bottom-4 left-1/2 -translate-x-1/2 text-[9px] font-mono text-cyan-500/40 hover:text-cyan-500/80 transition-colors uppercase tracking-widest"
          >
            [{hotspotsVisible ? "HIDE" : "SHOW"} HOTSPOTS]
          </button>
        </>
      )}
    </div>
  )
}
