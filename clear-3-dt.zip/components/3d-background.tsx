"use client"

/**
 * DEPRECATED: 3D Background
 *
 * This file previously contained 3D generation code which violates
 * Trinity governance rules. CLEAR operates as a consumer only.
 *
 * Use <EnvironmentRenderer /> instead.
 */

import { useEffect, useState } from "react"
import { EnvironmentRenderer } from "./environment-renderer"

interface TrinityMountProps {
  floorId?: string
  timelineRef?: string
  opacity?: number
}

// Functionality removed due to Trinity governance rules
// function FloatingGlassShards() { ... }
// function NeonParticles() { ... }

export function TrinityFloorMount({
  floorId = "CLEAR-001",
  timelineRef = "akira-codex-main",
  opacity = 0.3,
}: TrinityMountProps) {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    console.log(`[TRINITY] Mounting to floor: ${floorId}`)
    console.log(`[TRINITY] Timeline reference: ${timelineRef}`)
    console.log(`[TRINITY] Access mode: READ-ONLY`)
    setMounted(true)

    return () => {
      console.log(`[TRINITY] Unmounting from floor: ${floorId}`)
    }
  }, [floorId, timelineRef])

  if (!mounted) return null

  return (
    <div
      className="fixed inset-0 -z-10 pointer-events-none"
      style={{ opacity }}
      data-trinity-floor={floorId}
      data-timeline-ref={timelineRef}
      data-access-mode="read-only"
    >
      {/* Ambient layer - CSS only, no 3D generation */}
      <div className="absolute inset-0 bg-gradient-to-br from-black via-slate-950 to-black" />

      {/* Radial glow mounts - positioned for Trinity Core overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_30%_20%,rgba(0,217,255,0.08),transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_70%_80%,rgba(255,0,255,0.06),transparent_50%)]" />

      {/* Grid overlay - visual mount point marker */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0,217,255,0.3) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0,217,255,0.3) 1px, transparent 1px)
          `,
          backgroundSize: "50px 50px",
        }}
      />

      {/* Trinity floor identifier */}
      <div className="absolute bottom-4 left-4 text-[8px] font-mono text-cyan-500/20 uppercase tracking-widest">
        TRINITY:{floorId} | {timelineRef}
      </div>

      {/* EnvironmentRenderer consumer mount */}
      <EnvironmentRenderer patchId="CLEAR" kind="lobby" showHUD={false} />
    </div>
  )
}

// Legacy export for backward compatibility
export function ThreeDBackground() {
  return <EnvironmentRenderer patchId="CLEAR" kind="lobby" showHUD={false} />
}

export function LegacyThreeDBackground() {
  return <EnvironmentRenderer patchId="CLEAR" kind="lobby" showHUD={false} />
}
