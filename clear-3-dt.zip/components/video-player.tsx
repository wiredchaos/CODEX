"use client"

import { useState } from "react"
import type { Episode } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Play, Pause, Volume2, Maximize, X } from "lucide-react"
import Image from "next/image"

interface VideoPlayerProps {
  episode: Episode
  onClose: () => void
}

export function VideoPlayer({ episode, onClose }: VideoPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false)

  return (
    <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm">
      <div className="container mx-auto px-4 py-6 h-full flex flex-col">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="h-6 w-6 bg-[var(--color-wired-accent)] flex items-center justify-center">
              <span className="text-white font-bold text-xs">WC</span>
            </div>
            <span className="text-white font-semibold">WIRED CHAOS: CLEAR</span>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-white/10">
            <X className="h-5 w-5" />
          </Button>
        </div>

        <div className="flex-1 grid lg:grid-cols-[1fr_380px] gap-6 overflow-hidden">
          <div className="relative flex items-center justify-center">
            <div className="relative w-full aspect-video bg-black rounded-sm overflow-hidden">
              <Image src={episode.thumbnail || "/placeholder.svg"} alt={episode.title} fill className="object-cover" />
              <div className="absolute inset-0 flex items-center justify-center">
                <Button size="lg" onClick={() => setIsPlaying(!isPlaying)} className="h-16 w-16 rounded-full">
                  {isPlaying ? <Pause className="h-8 w-8" /> : <Play className="h-8 w-8" />}
                </Button>
              </div>
              <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
                <div className="flex items-center justify-between text-white">
                  <div className="flex items-center gap-3">
                    <Button size="icon" variant="ghost" className="text-white hover:bg-white/10">
                      {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                    </Button>
                    <span className="text-sm">12:34 / {episode.duration}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button size="icon" variant="ghost" className="text-white hover:bg-white/10">
                      <Volume2 className="h-5 w-5" />
                    </Button>
                    <Button size="icon" variant="ghost" className="text-white hover:bg-white/10">
                      <Maximize className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-card rounded-sm border border-border p-6 overflow-y-auto space-y-6">
            <div className="space-y-3">
              <Badge variant="outline" className="text-xs">
                {episode.category}
              </Badge>
              <h2 className="text-2xl font-bold tracking-tight text-balance">{episode.title}</h2>
              <p className="text-sm text-muted-foreground">
                Season {episode.season}, Episode {episode.episode} · {episode.duration}
              </p>
            </div>

            <div className="space-y-2">
              <h3 className="font-semibold text-sm">Description</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{episode.description}</p>
            </div>

            <div className="pt-4 border-t border-border space-y-3">
              <Button className="w-full" size="lg">
                Subscribe to Channel
              </Button>
              <Button className="w-full bg-transparent" variant="outline" size="lg">
                Add to Watchlist
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
