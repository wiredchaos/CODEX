"use client"

import { Button } from "@/components/ui/button"
import { Grid3x3, User } from "lucide-react"

export function ChannelHeader() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-cyan-400/20 glass-card">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-3">
              <div className="h-8 w-8 holographic-border glass-liquid flex items-center justify-center">
                <span className="text-cyan-50 font-bold text-sm">C</span>
              </div>
              <span className="text-lg font-serif font-bold tracking-tight">CLEAR</span>
            </div>
            <nav className="hidden md:flex items-center gap-6">
              <Button variant="ghost" size="sm" className="text-sm font-medium">
                Home
              </Button>
              <Button variant="ghost" size="sm" className="text-sm font-medium">
                Episodes
              </Button>
              <Button variant="ghost" size="sm" className="text-sm font-medium">
                Library
              </Button>
            </nav>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon">
              <Grid3x3 className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <User className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  )
}
