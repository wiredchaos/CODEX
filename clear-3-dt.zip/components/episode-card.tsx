"use client"

import type { Episode } from "@/lib/types"
import Image from "next/image"
import { Play } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface EpisodeCardProps {
  episode: Episode
  onClick?: () => void
}

export function EpisodeCard({ episode, onClick }: EpisodeCardProps) {
  return (
    <button
      onClick={onClick}
      className="group relative flex-shrink-0 w-[280px] sm:w-[320px] focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400/50 overflow-hidden snap-start"
    >
      <div className="relative aspect-video overflow-hidden glass-card shadow-sm group-hover:holographic-border transition-all duration-500">
        <Image
          src={episode.thumbnail || "/placeholder.svg"}
          alt={episode.title}
          fill
          className="object-cover transition-all duration-500 group-hover:scale-105"
        />
        {/* Glass metadata overlay on hover with neon glow */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/50 transition-all duration-300 flex items-center justify-center">
          <div className="opacity-0 group-hover:opacity-100 transition-all duration-300 transform scale-90 group-hover:scale-100">
            <div className="h-12 w-12 glass-liquid flex items-center justify-center shadow-lg neon-glow-cyan">
              <Play className="h-5 w-5 text-cyan-50 fill-cyan-50 ml-0.5" />
            </div>
          </div>
        </div>
        {/* Glass duration badge with neon accent */}
        <Badge variant="glass" className="absolute top-2.5 right-2.5 text-[10px] text-cyan-50 border-0">
          {episode.duration}
        </Badge>
      </div>

      <div className="mt-3.5 space-y-2 text-left px-0.5">
        <h3 className="font-serif font-semibold text-[15px] line-clamp-2 group-hover:text-cyan-400 transition-colors leading-snug">
          {episode.title}
        </h3>
        <div className="glass-divider my-2" />
        <p className="text-[11px] text-muted-foreground font-mono tracking-wider uppercase">
          S{episode.season} E{episode.episode}
        </p>
      </div>
    </button>
  )
}
