"use client"

import { EpisodeCard } from "@/components/episode-card"
import type { EpisodeRail as EpisodeRailType } from "@/lib/types"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useRef } from "react"

interface EpisodeRailProps {
  rail: EpisodeRailType
  onEpisodeClick?: (episodeId: string) => void
}

export function EpisodeRail({ rail, onEpisodeClick }: EpisodeRailProps) {
  const scrollRef = useRef<HTMLDivElement>(null)

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const scrollAmount = 640
      const newScrollLeft = scrollRef.current.scrollLeft + (direction === "left" ? -scrollAmount : scrollAmount)
      scrollRef.current.scrollTo({ left: newScrollLeft, behavior: "smooth" })
    }
  }

  return (
    <section className="space-y-5">
      {/* Rail header with controls */}
      <div className="flex items-center justify-between px-1">
        <div className="space-y-1">
          <h2 className="text-xl md:text-2xl font-serif font-bold tracking-tight">{rail.title}</h2>
          <div className="h-[1px] w-16 bg-steel-accent/30" />
        </div>
        <div className="hidden md:flex gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={() => scroll("left")}
            className="h-8 w-8 bg-muted/40 border-border/40 hover:bg-muted/60 backdrop-blur-sm"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={() => scroll("right")}
            className="h-8 w-8 bg-muted/40 border-border/40 hover:bg-muted/60 backdrop-blur-sm"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Glass rail container with inertial scroll */}
      <div className="glass-rail p-5 overflow-hidden">
        <div
          ref={scrollRef}
          className="flex gap-5 overflow-x-auto scrollbar-hide snap-x snap-mandatory scroll-smooth pb-2"
          style={{
            scrollbarWidth: "none",
            msOverflowStyle: "none",
            WebkitOverflowScrolling: "touch",
          }}
        >
          {rail.episodes.map((episode, index) => (
            <div key={episode.id} className="rail-item" style={{ animationDelay: `${index * 0.05}s` }}>
              <EpisodeCard episode={episode} onClick={() => onEpisodeClick?.(episode.id)} />
            </div>
          ))}
        </div>
      </div>
    </section>
    // </CHANGE>
  )
}
