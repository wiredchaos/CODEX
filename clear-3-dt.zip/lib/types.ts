export interface Episode {
  id: string
  title: string
  description: string
  thumbnail: string
  duration: string
  season: number
  episode: number
  category: EpisodeCategory
  videoUrl?: string
  publishedAt: string
}

export type EpisodeCategory =
  | "CLEAR EXPLAINS"
  | "CLEAR MARKETS"
  | "CLEAR SYSTEMS"
  | "CLEAR CASES"
  | "CLEAR STARTER KITS"

export interface EpisodeRail {
  title: string
  category: EpisodeCategory
  episodes: Episode[]
}

export interface OTTPlatform {
  name: "WIRED CHAOS" | "789 STUDIOS"
  displayName: string
}
