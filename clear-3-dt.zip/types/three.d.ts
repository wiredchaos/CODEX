declare module "three" {
  interface Object3D {
    userData?: Record<string, any>
  }
}
