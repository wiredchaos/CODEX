# CLEAR OTT Platform

*Automatically synced with your [v0.app](https://v0.app) deployments*

[![Deployed on Vercel](https://img.shields.io/badge/Deployed%20on-Vercel-black?style=for-the-badge&logo=vercel)](https://vercel.com/wiredchaos-projects/v0-ai-gateway-starter)
[![Built with v0](https://img.shields.io/badge/Built%20with-v0.app-black?style=for-the-badge)](https://v0.app/chat/wwrYlsIcYK1)

## Overview

The CLEAR OTT Platform is an institutional-grade streaming interface for business, markets, and coordination systems content. Built with Next.js 15, React Three Fiber, and a liquid glass morphism design language that combines editorial authority with futuristic clarity.

This repository stays in sync with your deployed chats on [v0.app](https://v0.app). Any changes you make to your deployed app will be automatically pushed to this repository from [v0.app](https://v0.app).

## Features

### Core Platform
- **Episode Management System** - Organized content rails (CLEAR EXPLAINS, CLEAR MARKETS, CLEAR SYSTEMS, CLEAR CASES, CLEAR STARTER KITS, CLEAR BUILDERS, CLEAR EXCHANGE)
- **Video Player Module** - Full-screen playback with metadata overlay
- **Channel Hero** - Featured episode showcase with 2D/3D preview toggle
- **Responsive Design** - Mobile-first with iOS Safari optimization

### 3D Enhancements (React Three Fiber)
- **Ambient 3D Background** - Floating glass shards and neon particles
- **3D Episode Previews** - Rotating logo with holographic materials
- **Data Visualizations** - Interactive flow diagrams
- **Holographic Cards** - Glass transmission panels with chromatic aberration

### Design System
- **Liquid Glass Morphism** - Cyan (#00D9FF) and magenta (#FF00FF) neon accents
- **Typography** - IBM Plex Serif headlines + Inter body text
- **Glass Utilities** - Reusable glass-card, glass-badge, glass-metadata classes
- **Dark Mode Support** - Full theme system with OKLCH color space

## Technology Stack

- **Framework:** Next.js 15.5.4 (App Router)
- **React:** 19.1.0
- **3D Graphics:** React Three Fiber 9.4.2, Three.js 0.182.0, @react-three/drei 10.7.7
- **Styling:** Tailwind CSS v4, tw-animate-css
- **UI Components:** shadcn/ui (Radix UI primitives)
- **TypeScript:** Full type safety

## Getting Started

### Prerequisites
- Node.js 18+ and npm/yarn/pnpm

### Installation

```bash
# Clone the repository
git clone https://github.com/wiredchaos/v0-CLEAR.git
cd v0-CLEAR

# Install dependencies
npm install

# Run development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) to view the platform.

### View 3D Gallery

Access the 3D enhancement showcase at [http://localhost:3000/demo](http://localhost:3000/demo).

## Project Structure

```
.
├── app/
│   ├── page.tsx              # Main OTT channel page
│   ├── demo/page.tsx         # 3D component gallery
│   ├── layout.tsx            # Root layout with fonts
│   └── globals.css           # Theme system and glass utilities
├── components/
│   ├── channel-header.tsx    # Navigation header
│   ├── channel-hero.tsx      # Hero section with 3D toggle
│   ├── episode-card.tsx      # Episode thumbnail cards
│   ├── episode-rail.tsx      # Horizontal content rails
│   ├── video-player.tsx      # Full-screen video player
│   ├── 3d-background.tsx     # Ambient 3D layer
│   ├── 3d-episode-preview.tsx        # 3D logo preview
│   ├── 3d-data-visualization.tsx     # Data flow 3D
│   ├── 3d-holographic-card.tsx       # Glass panel 3D
│   └── ui/                   # shadcn/ui components
├── lib/
│   ├── mock-data.ts          # Episode content data
│   └── types.ts              # TypeScript interfaces
├── docs/
│   └── 3D-ENHANCEMENTS.md    # 3D component documentation
└── types/
    └── three.d.ts            # Three.js type extensions
```

## Documentation

- **[3D Enhancements Guide](docs/3D-ENHANCEMENTS.md)** - Complete 3D component documentation
- **[v0.app Chat](https://v0.app/chat/wwrYlsIcYK1)** - Continue building on v0

## Deployment

Your project is live at:

**[https://vercel.com/wiredchaos-projects/v0-ai-gateway-starter](https://vercel.com/wiredchaos-projects/v0-ai-gateway-starter)**

## How It Works

1. Create and modify your project using [v0.app](https://v0.app)
2. Deploy your chats from the v0 interface
3. Changes are automatically pushed to this repository
4. Vercel deploys the latest version from this repository

## Design Philosophy

CLEAR operates under the **WIRED CHAOS LITE** aesthetic:

- **Editorial Newsroom Standards** - Bloomberg/FT-adjacent credibility
- **Liquid Glass Morphism** - Holographic depth with institutional restraint
- **Broadcast-Grade Presentation** - Console UI meets Apple Vision spatial design
- **Business Realm Firewall** - No glitch effects, mythic symbolism, or Akashic terminology

## Performance

- **60 FPS Target** - Optimized 3D rendering with DPR controls
- **Mobile-First** - Touch-optimized with 44px minimum tap targets
- **Lazy Loading** - 3D components render conditionally
- **WebGL Required** - All 3D features require WebGL-enabled browsers

## Contributing

This repository is automatically synced from v0.app deployments. To contribute:

1. Make changes in [v0.app](https://v0.app/chat/wwrYlsIcYK1)
2. Deploy from v0 interface
3. Changes will sync to this repository

## License

Built with v0 by Vercel.
