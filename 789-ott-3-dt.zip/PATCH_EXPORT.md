# 789 STUDIOS OTT - PATCH MODULE EXPORT

## PATCH MANIFEST
```json
{
  "patch": "789_STUDIOS_OTT",
  "realm": "business",
  "mount": "/world/789",
  "ui": true,
  "scene": true
}
```

---

## FILE TREE

### 📦 ROOT CONFIGURATION
```
patch-manifest.json          # Patch metadata & dependencies
README.md                    # Full architecture documentation
package.json                 # Dependencies
next.config.mjs              # Next.js 16 configuration
postcss.config.mjs           # PostCSS config
components.json              # shadcn/ui config
tsconfig.json                # TypeScript config
```

### 🎨 GLOBAL STYLES
```
app/globals.css              # Tailwind v4 + design tokens + Smart TV utilities
```

### 🏗️ LAYOUT (Scene Logic)
```
app/layout.tsx               # Root layout with RadioPlayer integration
components/theme-provider.tsx # Dark theme provider
components/navigation.tsx    # Main navigation bar (UI + Scene)
components/radio-player.tsx  # 33.3 FM persistent radio player (Scene)
```

### 🎬 PAGES (Routes - Patch-specific)
```
app/page.tsx                 # Home - Hero carousel, featured content
app/watch/page.tsx           # Browse all videos
app/watch/[id]/page.tsx      # Video player page
app/watch/loading.tsx        # Loading state
app/creator-studio/page.tsx  # Creator dashboard
app/dd-cartoons/page.tsx     # DD CARTOONS studio hub
app/crew/page.tsx            # 789 CREW profiles
app/doginals/page.tsx        # Doginal Dogs partners
app/live/page.tsx            # 33.3 FM radio page
app/market/page.tsx          # Market data & news
app/chaincast/page.tsx       # ChainCast ads network
app/affiliates/page.tsx      # Affiliate dashboard
app/smart-tv/page.tsx        # Smart TV interface
app/not-found.tsx            # 404 page
```

### 🔌 API ROUTES (Backend Logic)
```
app/api/royalty/[episodeId]/route.ts  # Hybrid royalty endpoint
app/api/royalty/batch/route.ts        # Batch royalty queries
app/api/royalty/distribute/route.ts   # On-chain distribution
app/api/royalty/claim/route.ts        # Claim royalties
app/api/licensing/verify/route.ts     # IP verification
app/api/creator/upload/route.ts       # Video upload
app/api/creator/nft/mint/route.ts     # NFT minting
app/api/creators/[id]/token/route.ts  # Creator token info
app/api/affiliates/track/route.ts     # Affiliate tracking
app/api/affiliates/payout/route.ts    # Affiliate payouts
app/api/roku/feed/route.ts            # Roku feed
app/api/tv-platforms/manifest/route.ts # TV manifest
app/api/tv-platforms/epg/route.ts     # EPG data
app/api/videos/[id]/aeo/route.ts      # AEO metadata
app/api/sitemap/route.ts              # Dynamic sitemap
app/api/robots/route.ts               # Robots.txt
```

### 🧩 UI COMPONENTS (Reusable UI)
```
# Video Components
components/hero-carousel.tsx           # Homepage hero carousel
components/video-card.tsx              # Video thumbnail card
components/video-carousel.tsx          # Horizontal video carousel
components/video-player.tsx            # Full video player with controls

# DD CARTOONS Components
components/dd-cartoons/royalty-hud.tsx        # Royalty distribution HUD
components/dd-cartoons/studio-tier-card.tsx   # Studio tier badge
components/dd-cartoons/ip-license-viewer.tsx  # License viewer

# Creator Studio Components
components/creator-studio/creator-dashboard.tsx  # Dashboard overview
components/creator-studio/creator-stats.tsx      # Analytics stats
components/creator-studio/upload-center.tsx      # Upload interface
components/creator-studio/analytics.tsx          # Detailed analytics
components/creator-studio/nft-minting.tsx        # NFT minting UI
components/creator-studio/royalty-routing.tsx    # Royalty config
components/creator-studio/token-management.tsx   # Token staking

# ChainCast Components
components/chaincast/chaincast-dashboard.tsx  # Ads dashboard
components/chaincast/ad-creation.tsx          # Create ads
components/chaincast/ad-performance.tsx       # Ad analytics
components/chaincast/qr-tracking.tsx          # QR code tracking
components/chaincast/wallet-targeting.tsx     # Wallet targeting
components/chaincast/rewards-pool.tsx         # Rewards pool

# Affiliate Components
components/affiliates/affiliate-dashboard.tsx # Affiliate overview
components/affiliates/affiliate-stats.tsx     # Affiliate stats
components/affiliates/affiliate-links.tsx     # Link generator
components/affiliates/kyc-verification.tsx    # KYC form
components/affiliates/payout-history.tsx      # Payout history

# Blockchain Components
components/blockchain/blockchain-status.tsx   # Contract status
components/wallet/connect-wallet-button.tsx   # Wallet connector

# shadcn/ui Components (58 components)
components/ui/*                               # Full shadcn/ui library
```

### 📚 LIBRARIES (Utilities & Services)
```
# Type Definitions
lib/types.ts                 # Core types (Video, Creator, Studio, etc.)
lib/types/api.ts             # API response types
lib/types/database.ts        # Database schema types
types/royalty.ts             # Royalty-specific types

# Blockchain Services
lib/blockchain/dogechain-config.ts      # Dogechain network config
lib/blockchain/wallet-connector.ts      # Wallet connection logic
lib/blockchain/contract-interface.ts    # Contract ABIs & interfaces
lib/blockchain-utils.ts                 # General blockchain utils
lib/royalty-chain.ts                    # On-chain royalty reader
lib/royalty-service.ts                  # Off-chain royalty service
lib/royalty-service-hybrid.ts           # Hybrid mode service
lib/royalty-engine.ts                   # Royalty calculation engine

# Data & Content
lib/mock-data.ts             # Mock data (videos, creators, studios)
lib/market-data.ts           # Market data service
lib/aeo-metadata.ts          # AEO metadata generator
lib/aeo-optimizer.ts         # SEO/AEO optimizer
lib/seo-config.ts            # SEO configuration

# UI Utilities
lib/styles.ts                # Glow styles & visual effects
lib/tv-remote-navigation.ts  # Smart TV remote handling
lib/utils.ts                 # General utilities (cn, etc.)

# React Hooks
hooks/use-mobile.ts          # Mobile detection
hooks/use-toast.ts           # Toast notifications
```

### ⛓️ SMART CONTRACTS (On-chain Logic)
```
contracts/RightsRegistry.sol  # IP licensing registry
contracts/RoyaltyEngine.sol   # 40/20/20/10/10 royalty splitter
contracts/StudioToken.sol     # $CARTOON ERC20 token
```

### 📖 DOCUMENTATION
```
docs/DEPLOYMENT.md               # Deployment guide
docs/DEVELOPER_ONBOARDING.md     # Developer onboarding
docs/ENVIRONMENT_VARIABLES.md    # Environment variables
docs/VERCEL_V0_PRODUCTION_PROMPT.md # V0 production prompt
```

### 🖼️ ASSETS
```
public/*.jpg                 # 60+ generated images (avatars, logos, etc.)
public/*.png                 # Icons and favicons
public/*.svg                 # SVG icons
```

---

## COMPONENT CLASSIFICATION

### A) UI COMPONENTS (Pure Presentation)
- All `components/ui/*` (shadcn/ui library)
- `components/video-card.tsx`
- `components/video-carousel.tsx`
- `components/dd-cartoons/royalty-hud.tsx`
- `components/dd-cartoons/studio-tier-card.tsx`
- `components/dd-cartoons/ip-license-viewer.tsx`
- `components/creator-studio/creator-stats.tsx`
- `components/affiliates/affiliate-stats.tsx`
- `components/blockchain/blockchain-status.tsx`

### B) SCENE / LAYOUT LOGIC (Navigation & Global State)
- `app/layout.tsx` - Root layout
- `components/navigation.tsx` - Main navigation
- `components/radio-player.tsx` - Persistent radio player
- `components/theme-provider.tsx` - Theme management

### C) PATCH-SPECIFIC ROUTES (Pages)
- All `app/**/page.tsx` files
- All `app/api/**/*.ts` API routes

### D) BUSINESS LOGIC (Services & Utilities)
- All `lib/**/*.ts` files
- All `contracts/**/*.sol` files

---

## INTEGRATION NOTES

### Mounting in Monorepo
This patch should be mounted at `/world/789` in the parent Next.js app:

```typescript
// Parent app next.config.mjs
const nextConfig = {
  async rewrites() {
    return [
      {
        source: '/world/789/:path*',
        destination: '/789-studios/:path*',
      },
    ];
  },
};
```

### Required Environment Variables
```bash
# Off-chain Mode (minimum)
DATABASE_URL=postgresql://...

# Hybrid/On-chain Mode (additional)
DOGECHAIN_RPC_URL=https://...
ROYALTY_ENGINE_CONTRACT=0x...
RIGHTS_REGISTRY_CONTRACT=0x...
CARTOON_ERC20_CONTRACT=0x...
STAKING_VAULT_CONTRACT=0x...
```

### Database Tables Required
- `videos` - Video metadata
- `creators` - Creator profiles
- `studios` - Studio entities
- `episodes` - Episode data
- `royalty_splits` - Revenue distribution
- `ip_licenses` - License registry
- `affiliates` - Affiliate partners

---

## USAGE MODES

### Mode 1: Off-Chain (Demo/Dev)
- Uses `lib/mock-data.ts` for all content
- No blockchain required
- Perfect for Roku/Smart TV approvals

### Mode 2: Hybrid (Production - Recommended)
- Revenue from DB (`lib/royalty-service.ts`)
- Splits from chain (`lib/royalty-chain.ts`)
- Merged by `lib/royalty-service-hybrid.ts`

### Mode 3: On-Chain (Future)
- Fully trustless
- All data from Dogechain
- DB becomes cache/index only

---

## BRAND IDENTITY

### Primary Colors
- Orange: `#FF8C00` (Studio brand)
- Yellow: `#FFD700` (Accent)
- Black/Dark: Background
- White: Text

### Typography
- Headings: Geist Sans
- Body: Geist Sans
- Mono: Geist Mono

### Key Visual Elements
- Neon glow effects (orange/yellow)
- Cyberpunk aesthetic
- Smart TV optimized (dpad navigation)
- Responsive grid layouts

---

## ROYALTY MODEL (Core Business Logic)

```
40% → DD CARTOONS Studio
20% → Creator(s)
20% → NFT Holder / Licensed Character Owner
10% → Treasury
10% → Token Stakers
```

Implemented in:
- `lib/royalty-engine.ts` (calculation)
- `contracts/RoyaltyEngine.sol` (on-chain)
- `components/dd-cartoons/royalty-hud.tsx` (display)

---

## EXTERNAL INTEGRATIONS

1. **CryptoSpaces Network** - 24/7 live radio
   - URL: `https://cryptospaces.net`
   - Integration: `components/radio-player.tsx`

2. **Doginal Dogs Marketplace**
   - URL: `https://market.doginaldogs.com`
   - Integration: `lib/market-data.ts`, `app/market/page.tsx`

3. **X/Twitter Community**
   - URL: `https://x.com/i/communities/1956818120120656211`
   - Integration: Links throughout app

4. **Spotify Playlist**
   - URL: `https://open.spotify.com/playlist/2VwOYrB1C93gNIPiBZNxhH`
   - Integration: `components/radio-player.tsx`

---

## DEPLOYMENT CHECKLIST

- [ ] Configure environment variables
- [ ] Deploy smart contracts (optional)
- [ ] Set up database schema
- [ ] Configure Vercel project
- [ ] Add domain/subdomain
- [ ] Test Smart TV navigation
- [ ] Verify wallet connections
- [ ] Test royalty calculations
- [ ] Enable RSS feeds
- [ ] Configure CDN for videos

---

## SUPPORT & MAINTENANCE

**Architecture:** Next.js 16 App Router + Hybrid Mode  
**Blockchain:** Dogechain (EVM-compatible)  
**UI Framework:** Tailwind CSS v4 + shadcn/ui  
**Type Safety:** TypeScript with strict mode  
**Testing:** Smart TV remote navigation ready  

For questions or issues, refer to:
- `README.md` - Full architecture overview
- `docs/DEVELOPER_ONBOARDING.md` - Step-by-step guide
- `docs/DEPLOYMENT.md` - Deployment instructions

---

**PATCH MODULE READY FOR MONOREPO INTEGRATION**
