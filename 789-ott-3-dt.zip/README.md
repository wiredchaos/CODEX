# 789 Studios OTT Platform + DD CARTOONS Studio

Production-ready OTT streaming platform with blockchain-powered royalty distribution, IP licensing, and creator governance.

## Architecture Overview

This platform implements a **three-mode architecture** for maximum flexibility:

### Mode A: Off-Chain (Immediate Deployment)
- **Use Case**: Development, demos, Roku approval
- **Data Source**: PostgreSQL/Supabase or mock data
- **Revenue**: Tracked in database
- **Splits**: Configured in TypeScript (40/20/20/10/10)
- **Speed**: Fastest, no blockchain dependencies

### Mode B: On-Chain (Full Decentralization)
- **Use Case**: Trustless distribution, NFT integration
- **Data Source**: Dogechain smart contracts
- **Revenue**: On-chain payments and tracking
- **Splits**: Enforced by RoyaltyEngine.sol
- **Trust**: Maximum, fully decentralized

### Mode C: Hybrid (Production Recommended)
- **Use Case**: Live production environment
- **Data Source**: DB for UI, blockchain for verification
- **Revenue**: Off-chain tracking, on-chain distribution
- **Splits**: Read from chain, cached in DB
- **Optimal**: Best UX + blockchain authenticity

## Core Features

### Royalty Distribution System
- **40%** → DD CARTOONS Studio
- **20%** → Creator & Contributors
- **20%** → Character NFT Holders
- **10%** → Platform Treasury
- **10%** → Token Stakers

### Studio Tier System
1. **Executive Tier (S)** - 10,000+ $CARTOON staked, 90+ days
2. **Premium Tier (A)** - 1,000+ $CARTOON staked, 60+ days
3. **Member Tier (B)** - 100+ $CARTOON staked, 30+ days
4. **Viewer Tier (C)** - No requirements

### IP Rights Registry
- On-chain character licensing
- Granular permissions (video, merch, streaming)
- Automated royalty routing to NFT holders
- Expiration and transfer tracking

## Tech Stack

- **Frontend**: Next.js 15, TypeScript, Tailwind CSS v4
- **Blockchain**: Dogechain (EVM), Solidity 0.8.x
- **Smart Contracts**: RoyaltyEngine, RightsRegistry, StudioToken, StakingVault
- **API**: Vercel Edge Functions
- **Database**: PostgreSQL/Supabase (optional)
- **Design**: shadcn/ui components with cyberpunk neon aesthetic

## Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Environment Variables
```bash
# .env.local

# Mode selection: "offchain" | "hybrid"
ROYALTY_MODE=hybrid

# Dogechain RPC (for hybrid/on-chain modes)
NEXT_PUBLIC_DOGECHAIN_RPC_URL=https://rpc.dogechain.dog

# Smart Contract Addresses (after deployment)
# These are public blockchain addresses, not authentication credentials
NEXT_PUBLIC_ROYALTY_ENGINE_CONTRACT=0x...
NEXT_PUBLIC_RIGHTS_REGISTRY_CONTRACT=0x...
NEXT_PUBLIC_CARTOON_ERC20_CONTRACT=0x...
NEXT_PUBLIC_STAKING_VAULT_CONTRACT=0x...
NEXT_PUBLIC_STUDIO_NFT_CONTRACT=0x...

# Optional: Database (for off-chain mode)
DATABASE_URL=postgresql://...
```

### 3. Run Development Server
```bash
npm run dev
```

Visit http://localhost:3000

## Smart Contract Deployment

### 1. Install Hardhat
```bash
npm install --save-dev hardhat @nomicfoundation/hardhat-toolbox
```

### 2. Deploy to Dogechain
```bash
# Deploy to testnet first
npx hardhat run scripts/deploy.js --network dogechain-testnet

# After testing, deploy to mainnet
npx hardhat run scripts/deploy.js --network dogechain-mainnet
```

### 3. Update Environment Variables
Copy deployed contract addresses to `.env.local`

## API Routes

### Get Episode Royalty
```
GET /api/royalty/[episodeId]
Response: EpisodeRoyaltyMeta
```

### Batch Get Royalties
```
POST /api/royalty/batch
Body: { episodeIds: string[] }
Response: Record<string, EpisodeRoyaltyMeta>
```

### Distribute Revenue (Admin)
```
POST /api/royalty/distribute
Body: { episodeId: string, amount: number }
```

### Claim Royalties
```
POST /api/royalty/claim
Body: { beneficiary: string }
```

### Verify License
```
GET /api/licensing/verify?assetId=DD-DOG-0042
Response: { valid: boolean, license: IPLicense }
```

## File Structure

```
789-studios-ott/
├── app/
│   ├── api/
│   │   ├── royalty/
│   │   │   ├── [episodeId]/route.ts  # Get episode royalty
│   │   │   ├── batch/route.ts        # Batch fetch
│   │   │   ├── distribute/route.ts   # Admin: distribute revenue
│   │   │   └── claim/route.ts        # User: claim royalties
│   │   └── licensing/
│   │       └── verify/route.ts       # Verify IP license
│   ├── dd-cartoons/page.tsx          # DD CARTOONS studio page
│   └── watch/[id]/page.tsx           # Video watch page
├── components/
│   ├── dd-cartoons/
│   │   ├── royalty-hud.tsx           # Royalty visualization
│   │   ├── studio-tier-card.tsx      # Tier display
│   │   └── ip-license-viewer.tsx     # License viewer
│   └── wallet/
│       └── connect-wallet-button.tsx # Wallet connector
├── lib/
│   ├── royalty-service.ts            # Off-chain service
│   ├── royalty-chain.ts              # On-chain reader
│   ├── royalty-service-hybrid.ts     # Hybrid service
│   └── blockchain/
│       ├── dogechain-config.ts       # Chain config
│       └── wallet-connector.ts       # Wallet integration
├── types/
│   └── royalty.ts                    # Type definitions
├── contracts/
│   ├── RoyaltyEngine.sol             # Revenue distribution
│   ├── RightsRegistry.sol            # IP licensing
│   ├── StudioToken.sol               # $CARTOON token
│   └── StakingVault.sol              # Staking logic
└── docs/
    └── DEPLOYMENT.md                 # Deployment guide
```

## Switching Modes

### To Off-Chain Mode
```bash
# .env.local
ROYALTY_MODE=offchain
```
No blockchain configuration needed. Uses mock/DB data only.

### To Hybrid Mode (Recommended)
```bash
# .env.local
ROYALTY_MODE=hybrid
NEXT_PUBLIC_DOGECHAIN_RPC_URL=https://rpc.dogechain.dog
NEXT_PUBLIC_ROYALTY_ENGINE_CONTRACT=0x...
```
Reads revenue from DB, verifies splits on-chain.

### To Full On-Chain Mode
Deploy all contracts, set all addresses, and switch services to read exclusively from chain.

## Environment Variables

### Required Public Variables (Frontend)
These are public blockchain contract addresses and endpoints - safe to expose:

```bash
NEXT_PUBLIC_DOGECHAIN_RPC_URL=https://rpc.dogechain.dog
NEXT_PUBLIC_ROYALTY_ENGINE_CONTRACT=0x...       # Public contract address
NEXT_PUBLIC_CARTOON_ERC20_CONTRACT=0x...        # $CARTOON ERC20 contract address
NEXT_PUBLIC_RIGHTS_REGISTRY_CONTRACT=0x...      # Public contract address
NEXT_PUBLIC_STAKING_VAULT_CONTRACT=0x...        # Public contract address
NEXT_PUBLIC_STUDIO_NFT_CONTRACT=0x...           # Public contract address
```

See [docs/ENVIRONMENT_VARIABLES.md](./docs/ENVIRONMENT_VARIABLES.md) for detailed security information.

**Note**: Variables with `NEXT_PUBLIC_` prefix are intentionally exposed to the browser. Smart contract addresses and RPC URLs are public blockchain information and safe to share.

## Brand Guidelines

- **Primary Colors**: Electric Orange (#FF6A00), Deep Yellow (#FFC300)
- **Background**: Black with gray-900 gradients
- **Typography**: Orbitron (headings), Inter (body)
- **Style**: Cyberpunk, neon glow effects, 3D aesthetic
- **Smart TV**: Large buttons, remote-friendly navigation

## Support

- **Documentation**: See `/docs` folder
- **Issues**: GitHub Issues
- **Community**: Discord (link TBD)

## License

MIT License - See LICENSE file
