"use client"

import { useRef } from "react"
import type { Video } from "@/lib/types"
import { VideoCard } from "@/components/video-card"
import { ChevronLeft, ChevronRight } from "lucide-react"

interface VideoCarouselProps {
  videos: Video[]
}

export function VideoCarousel({ videos }: VideoCarouselProps) {
  const scrollRef = useRef<HTMLDivElement>(null)

  const scroll = (direction: "left" | "right") => {
    if (!scrollRef.current) return

    const scrollAmount = 400
    const newScrollPosition =
      direction === "left" ? scrollRef.current.scrollLeft - scrollAmount : scrollRef.current.scrollLeft + scrollAmount

    scrollRef.current.scrollTo({
      left: newScrollPosition,
      behavior: "smooth",
    })
  }

  return (
    <div className="relative group">
      <button
        onClick={() => scroll("left")}
        className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-black/70 hover:bg-black/90 backdrop-blur-sm p-2 rounded-full opacity-0 group-hover:opacity-100 transition-all hover:scale-110"
        aria-label="Scroll left"
      >
        <ChevronLeft className="h-6 w-6 text-white" />
      </button>

      <div
        ref={scrollRef}
        className="flex gap-4 overflow-x-auto scrollbar-hide scroll-smooth pb-2"
        style={{ scrollbarWidth: "none" }}
      >
        {videos.map((video) => (
          <div key={video.id} className="flex-shrink-0 w-80">
            <VideoCard video={video} />
          </div>
        ))}
      </div>

      <button
        onClick={() => scroll("right")}
        className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-black/70 hover:bg-black/90 backdrop-blur-sm p-2 rounded-full opacity-0 group-hover:opacity-100 transition-all hover:scale-110"
        aria-label="Scroll right"
      >
        <ChevronRight className="h-6 w-6 text-white" />
      </button>
    </div>
  )
}
