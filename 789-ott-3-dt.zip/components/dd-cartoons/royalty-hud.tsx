"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { glowStyles } from "@/lib/styles"
import type { EpisodeRoyaltyMeta } from "@/types/royalty"
import { Coins, Users, Vault, Wallet, TrendingUp } from "lucide-react"

interface RoyaltyHUDProps {
  meta: EpisodeRoyaltyMeta
  className?: string
}

export function RoyaltyHUD({ meta, className }: RoyaltyHUDProps) {
  const { totalRevenueUsd, split, lastUpdated, source } = meta

  const toUsd = (pct: number) => (totalRevenueUsd * pct).toFixed(2)

  const formatCurrency = (amount: number | string) => {
    const num = typeof amount === "string" ? Number.parseFloat(amount) : amount
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
    }).format(num)
  }

  const distribution = {
    studio: Number.parseFloat(toUsd(split.studio)),
    creator: Number.parseFloat(toUsd(split.creator)),
    nftHolder: Number.parseFloat(toUsd(split.nftHolder)),
    treasury: Number.parseFloat(toUsd(split.treasury)),
    stakers: Number.parseFloat(toUsd(split.stakers)),
  }

  return (
    <Card className={`border-[#FF6A00]/30 bg-black/80 ${className}`} style={glowStyles.orange}>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center gap-2 text-[#FF6A00]">
            <Coins className="h-5 w-5" />
            Episode Royalty Distribution
          </CardTitle>
          <Badge variant="secondary" className="text-xs">
            {source === "hybrid" && "🔗 Hybrid"}
            {source === "chain" && "⛓️ On-Chain"}
            {source === "db" && "💾 Off-Chain"}
            {source === "mock" && "🧪 Mock"}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-400">Total Revenue</span>
          <span className="text-xl font-bold text-[#FFC300]">{formatCurrency(totalRevenueUsd)}</span>
        </div>

        <div className="text-xs text-gray-500 text-right">Last Updated: {new Date(lastUpdated).toLocaleString()}</div>

        <div className="space-y-3">
          {/* Studio Share - 40% */}
          <div className="space-y-1">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Vault className="h-4 w-4 text-[#FF6A00]" />
                <span className="text-sm">DD CARTOONS Studio</span>
              </div>
              <span className="text-sm font-semibold">40%</span>
            </div>
            <Progress value={40} className="h-2" />
            <span className="text-xs text-gray-500">{formatCurrency(distribution.studio)}</span>
          </div>

          {/* Creator Share - 20% */}
          <div className="space-y-1">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-[#FFC300]" />
                <span className="text-sm">Creator & Contributors</span>
              </div>
              <span className="text-sm font-semibold">20%</span>
            </div>
            <Progress value={20} className="h-2" />
            <span className="text-xs text-gray-500">{formatCurrency(distribution.creator)}</span>
          </div>

          {/* NFT Holder Share - 20% */}
          <div className="space-y-1">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Wallet className="h-4 w-4 text-[#FF6A00]" />
                <span className="text-sm">Character NFT Holders</span>
              </div>
              <span className="text-sm font-semibold">20%</span>
            </div>
            <Progress value={20} className="h-2" />
            <span className="text-xs text-gray-500">{formatCurrency(distribution.nftHolder)}</span>
          </div>

          {/* Treasury Share - 10% */}
          <div className="space-y-1">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-[#FFC300]" />
                <span className="text-sm">Platform Treasury</span>
              </div>
              <span className="text-sm font-semibold">10%</span>
            </div>
            <Progress value={10} className="h-2" />
            <span className="text-xs text-gray-500">{formatCurrency(distribution.treasury)}</span>
          </div>

          {/* Staker Share - 10% */}
          <div className="space-y-1">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Coins className="h-4 w-4 text-[#FF6A00]" />
                <span className="text-sm">Token Stakers</span>
              </div>
              <span className="text-sm font-semibold">10%</span>
            </div>
            <Progress value={10} className="h-2" />
            <span className="text-xs text-gray-500">{formatCurrency(distribution.stakers)}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
