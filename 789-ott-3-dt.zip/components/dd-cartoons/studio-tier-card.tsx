"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { glowStyles } from "@/lib/styles"
import type { StudioTier } from "@/lib/types"
import { Crown, Sparkles, Video, CheckCircle } from "lucide-react"

interface StudioTierCardProps {
  tier: StudioTier
  isActive?: boolean
  onActivate?: () => void
  className?: string
}

export function StudioTierCard({ tier, isActive, onActivate, className }: StudioTierCardProps) {
  const tierIcons = {
    "Major Studio": Crown,
    "Indie Studio": Video,
    "Creator House": Sparkles,
    "Audience Studio": CheckCircle,
  }

  const TierIcon = tierIcons[tier.name]

  return (
    <Card
      className={`border-[#FF6A00]/30 bg-black/80 hover:border-[#FFC300]/50 transition-all ${className}`}
      style={isActive ? glowStyles.orange : undefined}
    >
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TierIcon className="h-6 w-6 text-[#FF6A00]" />
            <CardTitle className="text-[#FFC300]" style={glowStyles.textYellow}>
              {tier.name}
            </CardTitle>
          </div>
          {isActive && <Badge className="bg-[#FF6A00] text-white">Active</Badge>}
        </div>
        <CardDescription className="text-gray-400">
          Royalty Bonus: +{tier.royaltyBonus}% | Voting Power: {tier.votingPower}x
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="text-sm font-semibold text-gray-300">Requirements:</div>
          <ul className="text-sm text-gray-400 space-y-1">
            {tier.nftRequired && <li>• Studio NFT Required</li>}
            {tier.tokenStakeRequired > 0 && <li>• Stake {tier.tokenStakeRequired.toLocaleString()} $CARTOON tokens</li>}
          </ul>
        </div>

        <div className="space-y-2">
          <div className="text-sm font-semibold text-gray-300">Benefits:</div>
          <ul className="text-sm text-gray-400 space-y-1">
            {tier.benefits.map((benefit, index) => (
              <li key={index}>• {benefit}</li>
            ))}
          </ul>
        </div>

        <div className="space-y-2">
          <div className="text-sm font-semibold text-gray-300">Permissions:</div>
          <div className="flex flex-wrap gap-2">
            {tier.canApprovePilots && (
              <Badge variant="outline" className="text-xs border-[#FF6A00]/30">
                Approve Pilots
              </Badge>
            )}
            {tier.canSubmitScripts && (
              <Badge variant="outline" className="text-xs border-[#FFC300]/30">
                Submit Scripts
              </Badge>
            )}
            {tier.canPitchEpisodes && (
              <Badge variant="outline" className="text-xs border-[#FF6A00]/30">
                Pitch Episodes
              </Badge>
            )}
            {tier.hasVoiceRoles && (
              <Badge variant="outline" className="text-xs border-[#FFC300]/30">
                Voice Roles
              </Badge>
            )}
            {tier.hasExecutiveCredit && (
              <Badge variant="outline" className="text-xs border-[#FF6A00]/30">
                Executive Credit
              </Badge>
            )}
          </div>
        </div>

        {!isActive && onActivate && (
          <Button onClick={onActivate} className="w-full bg-[#FF6A00] hover:bg-[#FF6A00]/80 text-white">
            Activate Tier
          </Button>
        )}
      </CardContent>
    </Card>
  )
}
