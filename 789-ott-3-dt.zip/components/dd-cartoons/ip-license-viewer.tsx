"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { glowStyles } from "@/lib/styles"
import type { IPLicense } from "@/lib/types"
import { Shield, CheckCircle, XCircle, Clock } from "lucide-react"

interface IPLicenseViewerProps {
  license: IPLicense
  className?: string
}

export function IPLicenseViewer({ license, className }: IPLicenseViewerProps) {
  const statusIcons = {
    active: CheckCircle,
    revoked: XCircle,
    expired: Clock,
  }

  const StatusIcon = statusIcons[license.status]

  const statusColors = {
    active: "text-green-500",
    revoked: "text-red-500",
    expired: "text-gray-500",
  }

  return (
    <Card className={`border-[#FF6A00]/30 bg-black/80 ${className}`} style={glowStyles.orange}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-[#FFC300]">
            <Shield className="h-5 w-5" />
            IP License #{license.tokenId}
          </CardTitle>
          <StatusIcon className={`h-5 w-5 ${statusColors[license.status]}`} />
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="text-xs text-gray-400">License Type</div>
            <Badge variant="outline" className="mt-1 border-[#FF6A00]/30">
              {license.licenseType.toUpperCase()}
            </Badge>
          </div>
          <div>
            <div className="text-xs text-gray-400">Royalty Share</div>
            <div className="text-lg font-bold text-[#FFC300]">{license.revShare}%</div>
          </div>
        </div>

        <div>
          <div className="text-xs text-gray-400 mb-2">Permissions</div>
          <div className="flex flex-wrap gap-2">
            {license.permissionsMask.map((permission, index) => (
              <Badge key={index} className="bg-green-900/30 text-green-400 border-green-500/30">
                {permission}
              </Badge>
            ))}
          </div>
        </div>

        {license.restrictionsMask.length > 0 && (
          <div>
            <div className="text-xs text-gray-400 mb-2">Restrictions</div>
            <div className="flex flex-wrap gap-2">
              {license.restrictionsMask.map((restriction, index) => (
                <Badge key={index} className="bg-red-900/30 text-red-400 border-red-500/30">
                  {restriction}
                </Badge>
              ))}
            </div>
          </div>
        )}

        <div className="pt-4 border-t border-gray-700 space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Creator</span>
            <span className="font-mono text-xs">{license.creator.slice(0, 10)}...</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Current Owner</span>
            <span className="font-mono text-xs">{license.owner.slice(0, 10)}...</span>
          </div>
          {license.expiry && (
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Expires</span>
              <span>{new Date(license.expiry).toLocaleDateString()}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
