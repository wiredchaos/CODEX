"use client"

import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Copy, ExternalLink } from "lucide-react"
import { useState } from "react"
import { useToast } from "@/hooks/use-toast"
import { glowStyles } from "@/lib/styles"

export function AffiliateDashboard() {
  const { toast } = useToast()
  const [copiedWallet, setCopiedWallet] = useState(false)

  const copyWallet = () => {
    navigator.clipboard.writeText("0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb")
    setCopiedWallet(true)
    toast({
      title: "Wallet Address Copied",
      description: "Your payout wallet has been copied to clipboard",
    })
    setTimeout(() => setCopiedWallet(false), 2000)
  }

  const recentActivity = [
    { type: "watch", amount: 0.001, date: "2024-01-15", user: "user_7x8k" },
    { type: "referral", amount: 0.01, date: "2024-01-14", user: "user_9m2p" },
    { type: "creator_signup", amount: 0.05, date: "2024-01-13", user: "creator_5k1n" },
    { type: "watch", amount: 0.001, date: "2024-01-13", user: "user_4j7w" },
  ]

  const affiliateGoals = [
    { name: "Bronze", target: 100, reward: "0.5 ETH Bonus", current: 67 },
    { name: "Silver", target: 500, reward: "2 ETH Bonus", current: 67 },
    { name: "Gold", target: 1000, reward: "5 ETH Bonus + NFT", current: 67 },
  ]

  return (
    <Card className="p-6 bg-card border-primary/20">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold" style={glowStyles.textOrange}>
          Affiliate Dashboard
        </h2>
        <Button variant="outline" size="sm">
          <ExternalLink className="h-4 w-4 mr-2" />
          View on Blockchain
        </Button>
      </div>

      <div className="mb-6 p-4 bg-muted/50 rounded-lg border border-border">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm text-muted-foreground mb-1">Payout Wallet</div>
            <div className="font-mono text-sm">0x742d...0bEb</div>
          </div>
          <Button variant="ghost" size="sm" onClick={copyWallet}>
            <Copy className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Tabs defaultValue="activity" className="w-full">
        <TabsList className="w-full grid grid-cols-2">
          <TabsTrigger value="activity">Recent Activity</TabsTrigger>
          <TabsTrigger value="goals">Goals & Rewards</TabsTrigger>
        </TabsList>

        <TabsContent value="activity" className="mt-6">
          <div className="space-y-4">
            {recentActivity.map((activity, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                <div>
                  <div className="font-semibold capitalize">{activity.type.replace("_", " ")}</div>
                  <div className="text-sm text-muted-foreground">
                    {activity.user} • {activity.date}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-primary">+{activity.amount} ETH</div>
                  <div className="text-xs text-muted-foreground">Pending</div>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="goals" className="mt-6">
          <div className="space-y-6">
            {affiliateGoals.map((goal) => (
              <div key={goal.name} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="font-semibold">{goal.name} Tier</div>
                  <div className="text-sm text-muted-foreground">
                    {goal.current}/{goal.target} referrals
                  </div>
                </div>
                <Progress value={(goal.current / goal.target) * 100} className="h-2" />
                <div className="text-sm text-secondary">{goal.reward}</div>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </Card>
  )
}
