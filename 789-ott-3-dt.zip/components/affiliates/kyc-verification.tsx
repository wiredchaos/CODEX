"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { ShieldCheck, AlertCircle, CheckCircle, Upload } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { glowStyles } from "@/lib/styles"

export function KYCVerification() {
  const [kycStatus, setKycStatus] = useState<"pending" | "approved" | "rejected">("pending")

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Card className="border-primary/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <ShieldCheck className="h-5 w-5 text-primary" />
                KYC/AML Verification
              </CardTitle>
              <CardDescription>Complete identity verification to receive payouts over $600</CardDescription>
            </div>
            <Badge
              variant={kycStatus === "approved" ? "default" : kycStatus === "rejected" ? "destructive" : "secondary"}
            >
              {kycStatus}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {kycStatus === "pending" && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                You must complete KYC verification to receive payouts. All information is encrypted and stored securely.
              </AlertDescription>
            </Alert>
          )}

          {kycStatus === "approved" && (
            <Alert className="bg-primary/10 border-primary/30">
              <CheckCircle className="h-4 w-4 text-primary" />
              <AlertDescription className="text-primary">
                Your account has been verified. You can now receive unlimited payouts.
              </AlertDescription>
            </Alert>
          )}

          <div className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name</Label>
                <Input id="firstName" placeholder="John" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name</Label>
                <Input id="lastName" placeholder="Doe" />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email Address</Label>
              <Input id="email" type="email" placeholder="john@example.com" />
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="dob">Date of Birth</Label>
                <Input id="dob" type="date" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="country">Country of Residence</Label>
                <Select>
                  <SelectTrigger id="country">
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="us">United States</SelectItem>
                    <SelectItem value="uk">United Kingdom</SelectItem>
                    <SelectItem value="ca">Canada</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="taxId">Tax ID / SSN (Last 4 digits)</Label>
              <Input id="taxId" placeholder="****" maxLength={4} />
              <p className="text-xs text-muted-foreground">Required for US residents earning over $600</p>
            </div>

            <div className="space-y-3 pt-4 border-t border-border">
              <Label>Identity Document Upload</Label>
              <div className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-primary/50 transition-colors cursor-pointer">
                <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">Upload passport or driver's license</p>
                <Button variant="outline" size="sm" className="mt-3 bg-transparent">
                  Choose File
                </Button>
              </div>
            </div>
          </div>

          <div className="flex gap-4 pt-4">
            <Button className="flex-1" style={glowStyles.orange}>
              Submit Verification
            </Button>
            <Button variant="outline" className="flex-1 bg-transparent">
              Save Draft
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Why Verify?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p>• Required for payouts over $600 (US) or equivalent</p>
          <p>• Ensures compliance with international tax regulations</p>
          <p>• Unlocks higher payout limits and priority processing</p>
          <p>• Protects against fraud and enhances platform security</p>
          <p>• All data is encrypted and never shared with third parties</p>
        </CardContent>
      </Card>
    </div>
  )
}
