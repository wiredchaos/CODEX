"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Copy, Check } from "lucide-react"
import { useState } from "react"
import { useToast } from "@/hooks/use-toast"
import { glowStyles } from "@/lib/styles"

const affiliateLinks = [
  { name: "Homepage", url: "https://789studios.tv?ref=AFF7890" },
  { name: "Creator Signup", url: "https://789studios.tv/creator?ref=AFF7890" },
  { name: "Featured Content", url: "https://789studios.tv/watch?ref=AFF7890" },
]

export function AffiliateLinks() {
  const { toast } = useToast()
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null)

  const copyLink = (url: string, index: number) => {
    navigator.clipboard.writeText(url)
    setCopiedIndex(index)
    toast({
      title: "Link Copied",
      description: "Affiliate link copied to clipboard",
    })
    setTimeout(() => setCopiedIndex(null), 2000)
  }

  return (
    <Card className="p-6 bg-card border-primary/20">
      <h3 className="font-bold text-lg mb-4" style={glowStyles.textOrange}>
        Your Affiliate Links
      </h3>
      <div className="space-y-4">
        {affiliateLinks.map((link, idx) => (
          <div key={idx} className="space-y-2">
            <div className="text-sm font-medium">{link.name}</div>
            <div className="flex gap-2">
              <Input value={link.url} readOnly className="font-mono text-xs" />
              <Button size="icon" variant="outline" onClick={() => copyLink(link.url, idx)}>
                {copiedIndex === idx ? <Check className="h-4 w-4 text-primary" /> : <Copy className="h-4 w-4" />}
              </Button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 pt-6 border-t border-border">
        <div className="text-sm text-muted-foreground mb-2">Your Referral Code</div>
        <div className="flex gap-2">
          <Input value="AFF7890" readOnly className="font-mono font-bold" />
          <Button variant="outline" size="icon">
            <Copy className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </Card>
  )
}
