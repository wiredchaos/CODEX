import { Card } from "@/components/ui/card"
import { TrendingUp, Users, DollarSign, Eye } from "lucide-react"

const stats = [
  {
    label: "Total Earnings",
    value: "2.47 ETH",
    change: "+12.5%",
    icon: DollarSign,
    color: "text-primary",
  },
  {
    label: "Active Referrals",
    value: "67",
    change: "+8",
    icon: Users,
    color: "text-secondary",
  },
  {
    label: "Total Watches",
    value: "1,243",
    change: "+156",
    icon: Eye,
    color: "text-chart-3",
  },
  {
    label: "Conversion Rate",
    value: "8.3%",
    change: "+2.1%",
    icon: TrendingUp,
    color: "text-chart-4",
  },
]

export function AffiliateStats() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => {
        const Icon = stat.icon
        return (
          <Card key={stat.label} className="p-6 bg-card border-primary/20">
            <div className="flex items-center justify-between mb-2">
              <div className="text-sm text-muted-foreground">{stat.label}</div>
              <Icon className={`h-4 w-4 ${stat.color}`} />
            </div>
            <div className="text-2xl font-bold mb-1">{stat.value}</div>
            <div className="text-sm text-secondary">{stat.change} this month</div>
          </Card>
        )
      })}
    </div>
  )
}
