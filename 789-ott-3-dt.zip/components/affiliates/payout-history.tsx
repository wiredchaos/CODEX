import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Download } from "lucide-react"

const payouts = [
  {
    date: "2024-01-01",
    amount: "1.25 ETH",
    status: "completed",
    txHash: "0x7d3e...9f2a",
  },
  {
    date: "2023-12-01",
    amount: "0.87 ETH",
    status: "completed",
    txHash: "0x4b1c...3e8d",
  },
  {
    date: "2023-11-01",
    amount: "0.35 ETH",
    status: "completed",
    txHash: "0x9a2f...7c4b",
  },
]

export function PayoutHistory() {
  return (
    <Card className="p-6 bg-card border-primary/20">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold">Payout History</h2>
        <Button variant="outline" size="sm">
          <Download className="h-4 w-4 mr-2" />
          Export W9/W8BEN
        </Button>
      </div>

      <div className="space-y-3">
        {payouts.map((payout, idx) => (
          <div key={idx} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
            <div>
              <div className="font-semibold">{payout.amount}</div>
              <div className="text-sm text-muted-foreground">{payout.date}</div>
            </div>
            <div className="text-right">
              <Badge variant="secondary" className="mb-1">
                {payout.status}
              </Badge>
              <div className="text-xs font-mono text-muted-foreground">{payout.txHash}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-primary/10 border border-primary/20 rounded-lg">
        <div className="text-sm font-semibold mb-2">Next Payout: Feb 1, 2024</div>
        <div className="text-2xl font-bold text-primary">0.062 ETH</div>
        <div className="text-sm text-muted-foreground mt-1">Minimum payout threshold: 0.05 ETH</div>
      </div>
    </Card>
  )
}
