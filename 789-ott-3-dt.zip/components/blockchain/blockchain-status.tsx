"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, XCircle, AlertCircle } from "lucide-react"
import { DOGECHAIN_CONFIG } from "@/lib/blockchain/dogechain-config"
import { glowStyles } from "@/lib/styles"

interface ContractStatus {
  name: string
  address: string
  deployed: boolean
  verified: boolean
}

export function BlockchainStatus() {
  const [contracts, setContracts] = useState<ContractStatus[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    checkContracts()
  }, [])

  const checkContracts = () => {
    const contractStatuses: ContractStatus[] = [
      {
        name: "Rights Registry",
        address: DOGECHAIN_CONFIG.contracts.rightsRegistry,
        deployed: !!DOGECHAIN_CONFIG.contracts.rightsRegistry,
        verified: false,
      },
      {
        name: "Royalty Engine",
        address: DOGECHAIN_CONFIG.contracts.royaltyEngine,
        deployed: !!DOGECHAIN_CONFIG.contracts.royaltyEngine,
        verified: false,
      },
      {
        name: "Studio Token",
        address: DOGECHAIN_CONFIG.contracts.studioToken,
        deployed: !!DOGECHAIN_CONFIG.contracts.studioToken,
        verified: false,
      },
      {
        name: "Staking Vault",
        address: DOGECHAIN_CONFIG.contracts.stakingVault,
        deployed: !!DOGECHAIN_CONFIG.contracts.stakingVault,
        verified: false,
      },
      {
        name: "Studio NFT",
        address: DOGECHAIN_CONFIG.contracts.studioNFT,
        deployed: !!DOGECHAIN_CONFIG.contracts.studioNFT,
        verified: false,
      },
    ]

    setContracts(contractStatuses)
    setIsLoading(false)
  }

  const allDeployed = contracts.every((c) => c.deployed)

  return (
    <Card className="p-6 bg-black/80 border-white/10">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-bold text-[#FF6A00]" style={glowStyles.textOrange}>
          Blockchain Status
        </h3>
        <Badge
          variant={allDeployed ? "default" : "secondary"}
          className={allDeployed ? "bg-green-500" : "bg-yellow-500"}
        >
          {allDeployed ? "On-Chain" : "Hybrid Mode"}
        </Badge>
      </div>

      {!allDeployed && (
        <div className="mb-4 p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
          <div className="flex items-center gap-2 text-sm text-yellow-400">
            <AlertCircle className="w-4 h-4" />
            <span>Running in Hybrid Mode - Deploy contracts to enable full blockchain features</span>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {contracts.map((contract) => (
          <div
            key={contract.name}
            className="flex items-center justify-between p-3 bg-black/50 rounded-lg border border-white/5"
          >
            <div className="flex items-center gap-3">
              {contract.deployed ? (
                <CheckCircle className="w-5 h-5 text-green-500" />
              ) : (
                <XCircle className="w-5 h-5 text-gray-500" />
              )}
              <div>
                <div className="font-semibold text-sm">{contract.name}</div>
                {contract.deployed && (
                  <div className="text-xs text-gray-400 font-mono">
                    {contract.address.slice(0, 8)}...{contract.address.slice(-6)}
                  </div>
                )}
                {!contract.deployed && <div className="text-xs text-gray-500">Not deployed</div>}
              </div>
            </div>
            <Badge variant={contract.deployed ? "default" : "outline"}>
              {contract.deployed ? "Active" : "Pending"}
            </Badge>
          </div>
        ))}
      </div>

      <div className="mt-4 p-3 bg-black/50 rounded-lg border border-white/5">
        <div className="text-xs text-gray-400">
          <div className="flex justify-between mb-1">
            <span>Network:</span>
            <span className="text-[#FFC300]">Dogechain Mainnet</span>
          </div>
          <div className="flex justify-between">
            <span>Chain ID:</span>
            <span className="text-[#FFC300]">{DOGECHAIN_CONFIG.chainId}</span>
          </div>
        </div>
      </div>
    </Card>
  )
}
