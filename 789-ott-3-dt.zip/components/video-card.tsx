import Image from "next/image"
import Link from "next/link"
import type { Video } from "@/lib/types"
import { Play, Eye, Heart, Lock } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { glowStyles } from "@/lib/styles"

interface VideoCardProps {
  video: Video
  size?: "default" | "large"
}

export function VideoCard({ video, size = "default" }: VideoCardProps) {
  const isLarge = size === "large"

  return (
    <Link
      href={`/watch/${video.id}`}
      className="group block relative overflow-hidden rounded-lg bg-card transition-all hover:scale-105"
    >
      <div className={`relative ${isLarge ? "aspect-video" : "aspect-video"}`}>
        <Image
          src={video.thumbnail || "/placeholder.svg"}
          alt={video.title}
          fill
          className="object-cover transition-transform group-hover:scale-110"
        />

        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="bg-primary/90 backdrop-blur-sm rounded-full p-4" style={glowStyles.orange}>
              <Play className="h-8 w-8 text-primary-foreground fill-current" />
            </div>
          </div>
        </div>

        {video.isTokenGated && (
          <div
            className="absolute top-2 right-2 bg-secondary/90 backdrop-blur-sm rounded-full p-2"
            style={glowStyles.yellow}
          >
            <Lock className="h-4 w-4 text-secondary-foreground" />
          </div>
        )}

        <Badge className="absolute top-2 left-2 bg-primary/90 backdrop-blur-sm">{video.category}</Badge>
      </div>

      <div className="p-3">
        <h3 className={`font-semibold ${isLarge ? "text-lg" : "text-base"} line-clamp-2 text-balance`}>
          {video.title}
        </h3>

        <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{video.description}</p>

        <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
          <div className="flex items-center gap-1">
            <Eye className="h-3 w-3" />
            <span>{video.views.toLocaleString()}</span>
          </div>
          <div className="flex items-center gap-1">
            <Heart className="h-3 w-3" />
            <span>{video.likes.toLocaleString()}</span>
          </div>
          <div>{Math.floor(video.duration / 60)}m</div>
        </div>
      </div>
    </Link>
  )
}
