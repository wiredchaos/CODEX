"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Wallet, ExternalLink, AlertCircle } from "lucide-react"
import { walletConnector } from "@/lib/blockchain/wallet-connector"
import type { ConnectedWallet } from "@/lib/blockchain/wallet-connector"
import { glowStyles } from "@/lib/styles"

export function ConnectWalletButton() {
  const [wallet, setWallet] = useState<ConnectedWallet | null>(null)
  const [isConnecting, setIsConnecting] = useState(false)
  const [showOptions, setShowOptions] = useState(false)

  const handleConnectReal = async () => {
    setIsConnecting(true)
    setShowOptions(false)

    try {
      if (!walletConnector.isWalletAvailable()) {
        // Open MetaMask install page
        window.open("https://metamask.io/download/", "_blank")
        return
      }
      const connected = await walletConnector.connect("metamask")
      setWallet(connected)
    } catch (err: any) {
      console.error("Wallet connection failed:", err)
    } finally {
      setIsConnecting(false)
    }
  }

  const handleConnectDemo = async () => {
    setIsConnecting(true)
    setShowOptions(false)

    try {
      const connected = await walletConnector.connect("demo")
      setWallet(connected)
    } catch (err: any) {
      console.error("Demo connection failed:", err)
    } finally {
      setIsConnecting(false)
    }
  }

  const handleDisconnect = async () => {
    await walletConnector.disconnect()
    setWallet(null)
  }

  if (wallet) {
    return (
      <div className="flex items-center gap-3">
        <div className="px-4 py-2 rounded-lg bg-black/50 border border-white/20" style={glowStyles.orange}>
          {wallet.isDemo && (
            <div className="text-[10px] text-yellow-400 flex items-center gap-1 mb-1">
              <AlertCircle className="w-3 h-3" /> Demo Mode
            </div>
          )}
          <div className="text-xs text-gray-400">Connected</div>
          <div className="text-sm font-mono">
            {wallet.isDemo ? wallet.address : `${wallet.address.slice(0, 6)}...${wallet.address.slice(-4)}`}
          </div>
          <div className="text-xs text-orange-400">{wallet.balance} DOGE</div>
        </div>
        <Button
          onClick={handleDisconnect}
          variant="outline"
          size="sm"
          className="border-red-500/50 hover:bg-red-500/10 bg-transparent text-red-400"
        >
          Disconnect
        </Button>
      </div>
    )
  }

  return (
    <div className="relative">
      <Button
        onClick={() => setShowOptions(!showOptions)}
        disabled={isConnecting}
        className="bg-gradient-to-r from-orange-500 to-yellow-500 hover:from-orange-600 hover:to-yellow-600 text-black font-semibold"
        style={glowStyles.orange}
      >
        <Wallet className="w-4 h-4 mr-2" />
        {isConnecting ? "Connecting..." : "Connect Wallet"}
      </Button>

      {showOptions && (
        <div
          className="absolute top-full mt-2 right-0 w-64 bg-black/95 border border-white/20 rounded-lg p-3 z-50"
          style={glowStyles.orange}
        >
          <div className="text-xs text-gray-400 mb-3">Choose connection method:</div>

          <button
            onClick={handleConnectReal}
            className="w-full flex items-center gap-3 p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors mb-2 text-left"
          >
            <div className="w-8 h-8 rounded-full bg-orange-500/20 flex items-center justify-center">
              <Wallet className="w-4 h-4 text-orange-400" />
            </div>
            <div>
              <div className="text-sm font-medium text-white">MetaMask</div>
              <div className="text-xs text-gray-400">Connect real wallet</div>
            </div>
            <ExternalLink className="w-3 h-3 text-gray-500 ml-auto" />
          </button>

          <button
            onClick={handleConnectDemo}
            className="w-full flex items-center gap-3 p-3 rounded-lg bg-yellow-500/10 hover:bg-yellow-500/20 transition-colors text-left border border-yellow-500/30"
          >
            <div className="w-8 h-8 rounded-full bg-yellow-500/20 flex items-center justify-center">
              <AlertCircle className="w-4 h-4 text-yellow-400" />
            </div>
            <div>
              <div className="text-sm font-medium text-yellow-400">Demo Mode</div>
              <div className="text-xs text-gray-400">Test without wallet</div>
            </div>
          </button>

          <div className="mt-3 pt-3 border-t border-white/10 text-[10px] text-gray-500">
            Demo mode lets you explore all features. Install MetaMask for real transactions.
          </div>
        </div>
      )}
    </div>
  )
}
