"use client"

import { useEffect, useState } from "react"
import { glowStyles } from "@/lib/styles"

interface EnvironmentRendererProps {
  patchId: string
  kind: "lobby" | "floor" | "timeline"
  onHotspotClick?: (hotspotId: string) => void
}

export function EnvironmentRenderer({ patchId, kind, onHotspotClick }: EnvironmentRendererProps) {
  const [mounted, setMounted] = useState(false)
  const [fallback, setFallback] = useState(false)

  useEffect(() => {
    // Check if Trinity Core is available
    const checkTrinityCore = () => {
      // @ts-ignore - Trinity Core injected by parent WIRED CHAOS META
      if (typeof window !== "undefined" && window.TRINITY_CORE) {
        setMounted(true)
        setFallback(false)
      } else {
        // Fallback to cinematic video if Trinity Core unavailable
        setFallback(true)
      }
    }

    checkTrinityCore()
  }, [])

  if (fallback) {
    return <CinematicFallback kind={kind} />
  }

  return (
    <div className="relative w-full h-full" data-trinity-mount={patchId}>
      {/* Trinity Core will inject 3D canvas here */}
      <div id={`trinity-canvas-${patchId}`} className="absolute inset-0" />

      {/* HUD overlay provided by Trinity Core */}
      <TrinityHUD patchId={patchId} kind={kind} onHotspotClick={onHotspotClick} />
    </div>
  )
}

function TrinityHUD({
  patchId,
  kind,
  onHotspotClick,
}: {
  patchId: string
  kind: string
  onHotspotClick?: (hotspotId: string) => void
}) {
  return (
    <div className="absolute inset-0 pointer-events-none">
      {/* Trinity Core controls HUD rendering */}
      <div className="absolute top-4 left-4 pointer-events-auto">
        <div className="px-4 py-2 rounded-lg bg-black/70 border border-orange-500/30 text-sm" style={glowStyles.orange}>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-orange-500 animate-pulse" />
            <span className="text-orange-400 font-mono">TRINITY MOUNTED</span>
          </div>
          <div className="text-xs text-white/60 mt-1">
            Patch: {patchId} | {kind.toUpperCase()}
          </div>
        </div>
      </div>
    </div>
  )
}

function CinematicFallback({ kind }: { kind: string }) {
  const videoMap = {
    lobby: "/videos/789-lobby-cinematic.mp4",
    floor: "/videos/789-floor-pan.mp4",
    timeline: "/videos/789-timeline-intro.mp4",
  }

  return (
    <div className="relative w-full h-full bg-black">
      <video
        autoPlay
        loop
        muted
        playsInline
        className="w-full h-full object-cover"
        src={videoMap[kind as keyof typeof videoMap] || videoMap.lobby}
      >
        <source src={videoMap[kind as keyof typeof videoMap]} type="video/mp4" />
      </video>

      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40" />

      <div
        className="absolute top-4 left-4 px-4 py-2 rounded-lg bg-black/70 border border-yellow-500/30 text-sm"
        style={glowStyles.yellow}
      >
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-yellow-500 animate-pulse" />
          <span className="text-yellow-400 font-mono">CINEMATIC MODE</span>
        </div>
        <div className="text-xs text-white/60 mt-1">Trinity Core: Fallback Active</div>
      </div>
    </div>
  )
}
