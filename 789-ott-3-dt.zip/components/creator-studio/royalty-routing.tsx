"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { DollarSign, Users, Building, Save, Plus, Trash2 } from "lucide-react"
import { glowStyles } from "@/lib/styles"

interface Beneficiary {
  id: string
  name: string
  walletAddress: string
  percentage: number
}

export function RoyaltyRouting() {
  const [beneficiaries, setBeneficiaries] = useState<Beneficiary[]>([
    { id: "1", name: "Creator", walletAddress: "0x1234...5678", percentage: 70 },
    { id: "2", name: "789 Studios Platform", walletAddress: "0xabcd...efgh", percentage: 20 },
    { id: "3", name: "Affiliate Partner", walletAddress: "0x9876...5432", percentage: 10 },
  ])

  const totalPercentage = beneficiaries.reduce((sum, b) => sum + b.percentage, 0)
  const isValid = totalPercentage === 100

  const updatePercentage = (id: string, value: number) => {
    setBeneficiaries((prev) => prev.map((b) => (b.id === id ? { ...b, percentage: value } : b)))
  }

  const removeBeneficiary = (id: string) => {
    setBeneficiaries((prev) => prev.filter((b) => b.id !== id))
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Card className="border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-primary" />
            Revenue Split Configuration
          </CardTitle>
          <CardDescription>Configure automatic blockchain-based royalty routing for your content</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            {beneficiaries.map((beneficiary) => (
              <div key={beneficiary.id} className="bg-muted/30 rounded-lg p-4 space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <Label htmlFor={`name-${beneficiary.id}`} className="text-base font-semibold">
                      {beneficiary.name}
                    </Label>
                    <p className="text-xs text-muted-foreground mt-1">{beneficiary.walletAddress}</p>
                  </div>
                  {beneficiaries.length > 1 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeBeneficiary(beneficiary.id)}
                      className="text-destructive hover:text-destructive hover:bg-destructive/10"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor={`percentage-${beneficiary.id}`}>Revenue Share</Label>
                    <span className="text-2xl font-bold text-primary">{beneficiary.percentage}%</span>
                  </div>
                  <Slider
                    id={`percentage-${beneficiary.id}`}
                    min={0}
                    max={100}
                    step={1}
                    value={[beneficiary.percentage]}
                    onValueChange={(value) => updatePercentage(beneficiary.id, value[0])}
                    className="cursor-pointer"
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="flex gap-2">
            <Button variant="outline" className="flex-1 bg-transparent">
              <Plus className="mr-2 h-4 w-4" />
              Add Beneficiary
            </Button>
          </div>

          <div className="bg-muted/50 rounded-lg p-4 space-y-3">
            <h4 className="font-semibold">Split Summary</h4>
            <div className="space-y-2">
              {beneficiaries.map((b) => (
                <div key={b.id} className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{b.name}</span>
                  <span className="font-semibold">{b.percentage}%</span>
                </div>
              ))}
              <div className="flex justify-between font-bold pt-2 border-t border-border">
                <span>Total</span>
                <span className={isValid ? "text-primary" : "text-destructive"}>{totalPercentage}%</span>
              </div>
            </div>
            {!isValid && <p className="text-xs text-destructive">Total must equal 100%</p>}
          </div>

          <Button className="w-full" style={glowStyles.orange} disabled={!isValid}>
            <Save className="mr-2 h-4 w-4" />
            Save Royalty Configuration
          </Button>
        </CardContent>
      </Card>

      <div className="grid sm:grid-cols-3 gap-4">
        <Card className="border-primary/20">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="bg-primary/10 p-2 rounded-lg">
                <DollarSign className="h-5 w-5 text-primary" />
              </div>
              <h3 className="font-semibold">Automatic Splits</h3>
            </div>
            <p className="text-sm text-muted-foreground">
              Revenue is automatically distributed on-chain to all beneficiaries
            </p>
          </CardContent>
        </Card>

        <Card className="border-primary/20">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="bg-primary/10 p-2 rounded-lg">
                <Users className="h-5 w-5 text-primary" />
              </div>
              <h3 className="font-semibold">Multi-Party Support</h3>
            </div>
            <p className="text-sm text-muted-foreground">
              Split revenue with collaborators, affiliates, and platform fees
            </p>
          </CardContent>
        </Card>

        <Card className="border-primary/20">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="bg-primary/10 p-2 rounded-lg">
                <Building className="h-5 w-5 text-primary" />
              </div>
              <h3 className="font-semibold">Transparent & Trustless</h3>
            </div>
            <p className="text-sm text-muted-foreground">
              All splits are enforced by smart contracts on the blockchain
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
