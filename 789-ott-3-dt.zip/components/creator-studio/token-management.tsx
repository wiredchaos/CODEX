import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Coins, Plus, TrendingUp, Users, DollarSign, ExternalLink } from "lucide-react"
import { glowStyles } from "@/lib/styles"

export function TokenManagement() {
  const tokens = [
    {
      id: "1",
      name: "Alex Cipher Creator Token",
      symbol: "ACCT",
      blockchain: "Solana",
      contractAddress: "0x1234567890abcdef1234567890abcdef12345678",
      totalSupply: 1000000,
      currentPrice: 0.45,
      holders: 1247,
      marketCap: 450000,
    },
  ]

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Your Creator Tokens</h2>
          <p className="text-muted-foreground">Manage your blockchain-based creator economy</p>
        </div>
        <Button style={glowStyles.yellow}>
          <Plus className="mr-2 h-4 w-4" />
          Launch New Token
        </Button>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {tokens.map((token) => (
          <Card key={token.id} className="border-primary/20 col-span-full lg:col-span-2">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Coins className="h-5 w-5 text-primary" />
                    {token.symbol}
                  </CardTitle>
                  <CardDescription>{token.name}</CardDescription>
                </div>
                <Badge style={glowStyles.orange}>{token.blockchain}</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Current Price</p>
                  <p className="text-2xl font-bold text-primary">${token.currentPrice}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Market Cap</p>
                  <p className="text-2xl font-bold">${token.marketCap.toLocaleString()}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Total Supply</p>
                  <p className="text-lg font-semibold">{token.totalSupply.toLocaleString()}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Holders</p>
                  <p className="text-lg font-semibold">{token.holders.toLocaleString()}</p>
                </div>
              </div>

              <div className="pt-4 border-t border-border">
                <p className="text-xs text-muted-foreground mb-2">Contract Address</p>
                <div className="flex items-center gap-2">
                  <code className="flex-1 text-xs bg-muted p-2 rounded overflow-hidden text-ellipsis">
                    {token.contractAddress}
                  </code>
                  <Button size="sm" variant="ghost">
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="flex gap-2">
                <Button variant="outline" className="flex-1 bg-transparent">
                  View Analytics
                </Button>
                <Button variant="outline" className="flex-1 bg-transparent">
                  Manage Supply
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}

        <Card className="border-primary/20">
          <CardHeader>
            <CardTitle className="text-lg">Token Benefits</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-sm">
            <div className="flex gap-3">
              <div className="bg-primary/10 p-2 rounded-lg h-fit">
                <DollarSign className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="font-semibold mb-1">Direct Monetization</p>
                <p className="text-muted-foreground text-xs">Earn from token sales and trading fees</p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="bg-primary/10 p-2 rounded-lg h-fit">
                <Users className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="font-semibold mb-1">Community Building</p>
                <p className="text-muted-foreground text-xs">Create exclusive holder benefits</p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="bg-primary/10 p-2 rounded-lg h-fit">
                <TrendingUp className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="font-semibold mb-1">Value Appreciation</p>
                <p className="text-muted-foreground text-xs">Token value grows with your success</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Launch a New Creator Token</CardTitle>
          <CardDescription>Create your own cryptocurrency to monetize your content and build community</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-3 gap-6">
            <div className="text-center p-6 border border-border rounded-lg hover:border-primary/50 transition-colors">
              <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-xl font-bold text-primary">1</span>
              </div>
              <h3 className="font-semibold mb-2">Choose Blockchain</h3>
              <p className="text-sm text-muted-foreground">XRPL, Solana, or Polygon</p>
            </div>
            <div className="text-center p-6 border border-border rounded-lg hover:border-primary/50 transition-colors">
              <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-xl font-bold text-primary">2</span>
              </div>
              <h3 className="font-semibold mb-2">Configure Token</h3>
              <p className="text-sm text-muted-foreground">Set supply, symbol, and utility</p>
            </div>
            <div className="text-center p-6 border border-border rounded-lg hover:border-primary/50 transition-colors">
              <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-xl font-bold text-primary">3</span>
              </div>
              <h3 className="font-semibold mb-2">Deploy & Earn</h3>
              <p className="text-sm text-muted-foreground">Launch and start earning</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
