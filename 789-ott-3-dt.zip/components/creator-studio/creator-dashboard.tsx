import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { VideoCard } from "@/components/video-card"
import { mockVideos } from "@/lib/mock-data"
import { Plus, TrendingUp, Calendar } from "lucide-react"
import Link from "next/link"
import { glowStyles } from "@/lib/styles"

export function CreatorDashboard() {
  const recentVideos = mockVideos.slice(0, 3)

  return (
    <div className="space-y-6">
      <Card className="border-primary/20">
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>Start creating Film3 content</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-3 gap-4">
            <Button className="h-auto py-4 flex-col gap-2" style={glowStyles.orange}>
              <Plus className="h-6 w-6" />
              <span>Upload Video</span>
            </Button>
            <Button variant="outline" className="h-auto py-4 flex-col gap-2 bg-transparent">
              <TrendingUp className="h-6 w-6" />
              <span>Launch Token</span>
            </Button>
            <Button variant="outline" className="h-auto py-4 flex-col gap-2 bg-transparent">
              <Calendar className="h-6 w-6" />
              <span>Schedule Release</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Recent Uploads</CardTitle>
              <CardDescription>Your latest Film3 content</CardDescription>
            </div>
            <Link href="/creator-studio?tab=upload">
              <Button variant="ghost" size="sm">
                View All
              </Button>
            </Link>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {recentVideos.map((video) => (
              <VideoCard key={video.id} video={video} />
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Revenue Breakdown</CardTitle>
            <CardDescription>This month</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Video Views</span>
              <span className="font-semibold">$8,200</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Token Sales</span>
              <span className="font-semibold">$3,100</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Affiliate Commission</span>
              <span className="font-semibold">$950</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Tips & Donations</span>
              <span className="font-semibold">$200</span>
            </div>
            <div className="border-t border-border pt-4 flex items-center justify-between">
              <span className="font-semibold">Total</span>
              <span className="font-bold text-xl text-primary">$12,450</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Community Insights</CardTitle>
            <CardDescription>Audience demographics</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Crypto Holders</span>
                <span className="text-sm font-semibold">65%</span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div className="h-full bg-primary w-[65%]" style={glowStyles.orange} />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Film3 Enthusiasts</span>
                <span className="text-sm font-semibold">52%</span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div className="h-full bg-secondary w-[52%]" style={glowStyles.yellow} />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Token Holders</span>
                <span className="text-sm font-semibold">38%</span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div className="h-full bg-primary w-[38%]" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
