"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Sparkles, ImageIcon, FileText, CheckCircle } from "lucide-react"
import { glowStyles } from "@/lib/styles"

export function NFTMinting() {
  const [mintingStatus, setMintingStatus] = useState<"idle" | "minting" | "success">("idle")
  const [selectedVideo, setSelectedVideo] = useState("")

  const handleMint = async () => {
    setMintingStatus("minting")
    await new Promise((resolve) => setTimeout(resolve, 3000))
    setMintingStatus("success")
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Card className="border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            Mint Episode NFT
          </CardTitle>
          <CardDescription>Create collectible NFTs tied to your episodes for exclusive access</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {mintingStatus === "success" ? (
            <div className="text-center py-8 space-y-4">
              <div className="bg-primary/10 w-20 h-20 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle className="h-10 w-10 text-primary" />
              </div>
              <h3 className="text-2xl font-bold text-primary">NFT Minted Successfully!</h3>
              <p className="text-muted-foreground">Your episode NFT is now live on the blockchain</p>
              <div className="flex gap-4 justify-center pt-4">
                <Button variant="outline" onClick={() => setMintingStatus("idle")}>
                  Mint Another
                </Button>
                <Button style={glowStyles.orange}>View on Explorer</Button>
              </div>
            </div>
          ) : (
            <>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="select-video">Select Video</Label>
                  <Select value={selectedVideo} onValueChange={setSelectedVideo}>
                    <SelectTrigger id="select-video">
                      <SelectValue placeholder="Choose a video to mint as NFT" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="video1">Genesis Protocol: The First Block</SelectItem>
                      <SelectItem value="video2">Doginal Dogs: Episode 1</SelectItem>
                      <SelectItem value="video3">WIRED CHAOS META: Quantum Heist</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="blockchain">Blockchain Network</Label>
                  <Select defaultValue="solana">
                    <SelectTrigger id="blockchain">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="xrpl">XRPL</SelectItem>
                      <SelectItem value="solana">Solana</SelectItem>
                      <SelectItem value="polygon">Polygon</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="nft-name">NFT Name</Label>
                    <Input id="nft-name" placeholder="Genesis Protocol #001" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="nft-supply">Total Supply</Label>
                    <Input id="nft-supply" type="number" placeholder="100" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="royalty">Creator Royalty Percentage</Label>
                  <Input id="royalty" type="number" min="0" max="10" defaultValue="5" />
                  <p className="text-xs text-muted-foreground">Earn royalties on secondary sales (0-10%)</p>
                </div>

                <div className="space-y-4 pt-4 border-t border-border">
                  <h3 className="font-semibold">NFT Metadata</h3>
                  <div className="grid sm:grid-cols-3 gap-4">
                    <div className="flex items-center gap-2 text-sm">
                      <ImageIcon className="h-4 w-4 text-muted-foreground" />
                      <span>Thumbnail Included</span>
                      <Badge variant="secondary" className="ml-auto text-xs">
                        Auto
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <span>Description</span>
                      <Badge variant="secondary" className="ml-auto text-xs">
                        Auto
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Sparkles className="h-4 w-4 text-muted-foreground" />
                      <span>Attributes</span>
                      <Badge variant="secondary" className="ml-auto text-xs">
                        Auto
                      </Badge>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-muted/50 rounded-lg p-4 space-y-2">
                <h4 className="font-semibold text-sm">Minting Cost Estimate</h4>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Network Fee</span>
                    <span>~0.005 SOL</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Storage Fee</span>
                    <span>~0.001 SOL</span>
                  </div>
                  <div className="flex justify-between font-semibold pt-2 border-t border-border">
                    <span>Total</span>
                    <span>~0.006 SOL ($1.20)</span>
                  </div>
                </div>
              </div>

              <Button
                className="w-full"
                style={glowStyles.orange}
                onClick={handleMint}
                disabled={mintingStatus === "minting"}
              >
                {mintingStatus === "minting" ? "Minting..." : "Mint NFT"}
              </Button>
            </>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Why Mint Episode NFTs?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p>• Create exclusive collectibles for your biggest fans</p>
          <p>• Earn ongoing royalties from secondary sales</p>
          <p>• Gate premium content with NFT ownership</p>
          <p>• Build a tradeable creator economy</p>
          <p>• Increase engagement with limited editions</p>
        </CardContent>
      </Card>
    </div>
  )
}
