"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Upload, Film, Lock } from "lucide-react"
import { categories } from "@/lib/mock-data"
import { glowStyles } from "@/lib/styles"

export function UploadCenter() {
  const [isTokenGated, setIsTokenGated] = useState(false)

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Card className="border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Film className="h-5 w-5" />
            Upload New Video
          </CardTitle>
          <CardDescription>Share your Film3 content with the world</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="border-2 border-dashed border-border rounded-lg p-12 text-center hover:border-primary/50 transition-colors cursor-pointer">
            <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <p className="text-sm text-muted-foreground mb-2">Drag and drop your video file here, or click to browse</p>
            <p className="text-xs text-muted-foreground">Supports MP4, MOV, AVI up to 10GB</p>
            <Button className="mt-4" style={glowStyles.orange}>
              Select File
            </Button>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Video Title</Label>
              <Input id="title" placeholder="Enter an engaging title for your video" />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea id="description" placeholder="Describe your video content..." rows={4} />
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select>
                  <SelectTrigger id="category">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="tags">Tags</Label>
                <Input id="tags" placeholder="e.g., Film3, Web3, NFT" />
              </div>
            </div>

            <div className="space-y-4 pt-4 border-t border-border">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="token-gate" className="flex items-center gap-2">
                    <Lock className="h-4 w-4" />
                    Token Gate This Video
                  </Label>
                  <p className="text-sm text-muted-foreground">Require token ownership to view</p>
                </div>
                <Switch id="token-gate" checked={isTokenGated} onCheckedChange={setIsTokenGated} />
              </div>

              {isTokenGated && (
                <div className="space-y-4 pl-6 border-l-2 border-primary/30">
                  <div className="space-y-2">
                    <Label htmlFor="blockchain">Blockchain</Label>
                    <Select>
                      <SelectTrigger id="blockchain">
                        <SelectValue placeholder="Select blockchain" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="xrpl">XRPL</SelectItem>
                        <SelectItem value="solana">Solana</SelectItem>
                        <SelectItem value="polygon">Polygon</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="token-address">Token Contract Address</Label>
                    <Input id="token-address" placeholder="0x..." />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="min-tokens">Minimum Tokens Required</Label>
                    <Input id="min-tokens" type="number" placeholder="1" />
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="flex gap-4 pt-4">
            <Button className="flex-1" style={glowStyles.orange}>
              Publish Now
            </Button>
            <Button variant="outline" className="flex-1 bg-transparent">
              Save as Draft
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Upload Tips</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p>• Use eye-catching thumbnails to increase click-through rates</p>
          <p>• Add relevant tags to improve discoverability</p>
          <p>• Token-gated content can increase exclusivity and value</p>
          <p>• Optimize titles and descriptions for AI search engines (AEO)</p>
          <p>• Add captions and transcripts for better accessibility</p>
        </CardContent>
      </Card>
    </div>
  )
}
