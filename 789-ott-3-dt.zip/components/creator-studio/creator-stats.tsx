import { Card, CardContent } from "@/components/ui/card"
import { Eye, Heart, Users, DollarSign, TrendingUp, Video } from "lucide-react"

export function CreatorStats() {
  const stats = [
    {
      label: "Total Views",
      value: "1.2M",
      change: "+12.5%",
      icon: Eye,
      trend: "up",
    },
    {
      label: "Subscribers",
      value: "45.2K",
      change: "+8.3%",
      icon: Users,
      trend: "up",
    },
    {
      label: "Total Earnings",
      value: "$12,450",
      change: "+18.2%",
      icon: DollarSign,
      trend: "up",
    },
    {
      label: "Videos Published",
      value: "24",
      change: "+4",
      icon: Video,
      trend: "up",
    },
    {
      label: "Engagement Rate",
      value: "8.7%",
      change: "+2.1%",
      icon: Heart,
      trend: "up",
    },
    {
      label: "Revenue Growth",
      value: "+125%",
      change: "This month",
      icon: TrendingUp,
      trend: "up",
    },
  ]

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {stats.map((stat) => {
        const Icon = stat.icon
        return (
          <Card key={stat.label} className="border-primary/20 hover:border-primary/40 transition-all">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
                  <p className="text-3xl font-bold">{stat.value}</p>
                  <p className={`text-sm mt-1 ${stat.trend === "up" ? "text-primary" : "text-destructive"}`}>
                    {stat.change}
                  </p>
                </div>
                <div className="bg-primary/10 p-3 rounded-lg">
                  <Icon className="h-6 w-6 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
