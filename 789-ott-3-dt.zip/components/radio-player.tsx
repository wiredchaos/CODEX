"use client"

import { useState, useEffect, useRef } from "react"
import { Radio, Volume2, VolumeX, ExternalLink, Mic, X, ChevronUp, Waves, Music, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { glowStyles } from "@/lib/styles"

interface SpaceHost {
  name: string
  handle: string
  timeSlot: string
  showName?: string
  avatar: string
}

const spaceHosts: SpaceHost[] = [
  { name: "Edge", handle: "edgemeta", timeSlot: "4 - 5 AM EST", avatar: "/pixel-art-dog-edge-cyberpunk.jpg" },
  { name: "Tengu", handle: "TenguXL", timeSlot: "4 - 5 AM EST", avatar: "/pixel-art-dog-tengu-samurai.jpg" },
  { name: "Leah", handle: "leahbluewater", timeSlot: "6 - 7 AM EST", avatar: "/pixel-art-dog-leah-blue-water.jpg" },
  { name: "Vee", handle: "veemeta", timeSlot: "7 - 9 AM EST", avatar: "/pixel-art-dog-vee-purple-neon.jpg" },
  { name: "Mouse", handle: "Mousemeta", timeSlot: "9 - 10 AM EST", avatar: "/pixel-art-dog-mouse-tech.jpg" },
  { name: "Web", handle: "web3smb", timeSlot: "9 - 10 AM EST", avatar: "/pixel-art-dog-web3-digital.jpg" },
  {
    name: "Shibo",
    handle: "godsburnt",
    timeSlot: "10 AM - 12 PM EST",
    showName: "The Crypto Show",
    avatar: "/pixel-art-dog-shibo-gold-crown.jpg",
  },
  { name: "Ant", handle: "KingAnt", timeSlot: "12 - 2 PM EST", avatar: "/pixel-art-dog-king-ant-royal.jpg" },
  { name: "Defi", handle: "lil_defi", timeSlot: "12 - 2 PM EST", avatar: "/pixel-art-dog-defi-finance-green.jpg" },
  { name: "Paws", handle: "PawsMeta", timeSlot: "1 - 3 PM EST", avatar: "/pixel-art-dog-paws-cute.jpg" },
  { name: "Shield", handle: "Shieldmetax", timeSlot: "2 - 3 PM EST", avatar: "/pixel-art-dog-shield-armor.jpg" },
  { name: "Order", handle: "orderup", timeSlot: "3 - 5 PM EST", avatar: "/pixel-art-dog-order-chef.jpg" },
  { name: "High", handle: "Hightv", timeSlot: "4 - 5 PM EST", avatar: "/pixel-art-dog-high-tv-broadcast.jpg" },
  {
    name: "Bark",
    handle: "barkmeta",
    timeSlot: "5 - 7 PM EST",
    showName: "State of Crypto",
    avatar: "/pixel-art-dog-bark-news-anchor.jpg",
  },
  { name: "Vibes", handle: "Vibesmetax", timeSlot: "7 - 8 PM EST", avatar: "/pixel-art-dog-vibes-chill-sunset.jpg" },
  { name: "0xG", handle: "0x_TOPG", timeSlot: "7 - 9 PM EST", avatar: "/placeholder.svg?height=80&width=80" },
  { name: "Tall", handle: "tall_data", timeSlot: "8 - 10 PM EST", avatar: "/placeholder.svg?height=80&width=80" },
  { name: "Gator", handle: "gatormetaX", timeSlot: "9 - 10 PM EST", avatar: "/placeholder.svg?height=80&width=80" },
  { name: "Rus", handle: "RusMetaX", timeSlot: "9 - 10 PM EST", avatar: "/placeholder.svg?height=80&width=80" },
  { name: "Riv", handle: "RivAuraX", timeSlot: "10 - 11 PM EST", avatar: "/placeholder.svg?height=80&width=80" },
  { name: "Dream", handle: "DreamMetaX", timeSlot: "11 PM - 1 AM EST", avatar: "/placeholder.svg?height=80&width=80" },
  { name: "Luis", handle: "luismetax", timeSlot: "12 - 1 AM EST", avatar: "/placeholder.svg?height=80&width=80" },
  { name: "Lamb", handle: "LambMetaX", timeSlot: "1 - 3 AM EST", avatar: "/placeholder.svg?height=80&width=80" },
]

function getCurrentHost(): SpaceHost | null {
  const now = new Date()
  const estHour = now.getUTCHours() - 5
  const normalizedHour = estHour < 0 ? estHour + 24 : estHour

  for (const host of spaceHosts) {
    const [startStr] = host.timeSlot.split(" - ")
    const startHour = Number.parseInt(startStr)
    const isPM = host.timeSlot.includes("PM") && !host.timeSlot.startsWith("12")

    let adjustedStart = startHour
    if (isPM) adjustedStart += 12
    if (host.timeSlot.includes("12 PM")) adjustedStart = 12
    if (host.timeSlot.includes("12 AM") || host.timeSlot.includes("12 - 1 AM")) adjustedStart = 0

    const endParts = host.timeSlot.split(" - ")[1]
    let endHour = Number.parseInt(endParts)
    if (endParts.includes("PM") && !endParts.startsWith("12")) endHour += 12
    if (endParts.includes("12 PM")) endHour = 12

    if (normalizedHour >= adjustedStart && normalizedHour < endHour) {
      return host
    }
  }
  return spaceHosts[0]
}

export function RadioPlayer() {
  const [isExpanded, setIsExpanded] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [showSpotify, setShowSpotify] = useState(false)
  const [currentHost, setCurrentHost] = useState<SpaceHost | null>(null)
  const [volume, setVolume] = useState(75)
  const [isMuted, setIsMuted] = useState(false)
  const [currentTime, setCurrentTime] = useState(new Date())
  const [audioVisualizerBars, setAudioVisualizerBars] = useState<number[]>([])
  const animationRef = useRef<number>()

  useEffect(() => {
    setCurrentHost(getCurrentHost())
    const interval = setInterval(() => {
      setCurrentTime(new Date())
      setCurrentHost(getCurrentHost())
    }, 60000)
    return () => clearInterval(interval)
  }, [])

  // Audio visualizer animation
  useEffect(() => {
    const animateBars = () => {
      const bars = Array.from({ length: 20 }, () => Math.random() * 100)
      setAudioVisualizerBars(bars)
      animationRef.current = requestAnimationFrame(animateBars)
    }

    const timeout = setTimeout(() => {
      animationRef.current = requestAnimationFrame(animateBars)
    }, 100)

    return () => {
      clearTimeout(timeout)
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [])

  const formatESTTime = (date: Date) => {
    return date.toLocaleTimeString("en-US", {
      timeZone: "America/New_York",
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    })
  }

  if (isMinimized) {
    return (
      <button
        onClick={() => setIsMinimized(false)}
        className="fixed bottom-4 right-4 z-50 bg-black/90 border border-orange-500/50 rounded-full p-3 hover:scale-110 transition-transform"
        style={glowStyles.orange}
      >
        <div className="relative">
          <Radio className="h-6 w-6 text-orange-500" />
          <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse" />
        </div>
      </button>
    )
  }

  return (
    <div
      className={`fixed bottom-0 left-0 right-0 z-50 transition-all duration-300 ${isExpanded ? "h-auto" : "h-auto"}`}
    >
      {showSpotify && (
        <div className="fixed inset-0 z-[60] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div
            className="bg-black/95 border border-orange-500/50 rounded-2xl p-4 max-w-md w-full"
            style={glowStyles.orange}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Music className="h-5 w-5 text-orange-500" />
                <h3 className="font-bold text-lg">33.3 FM Dogechain Playlist</h3>
              </div>
              <Button variant="ghost" size="icon" onClick={() => setShowSpotify(false)}>
                <X className="h-5 w-5" />
              </Button>
            </div>
            <iframe
              style={{ borderRadius: 12 }}
              src="https://open.spotify.com/embed/playlist/2VwOYrB1C93gNIPiBZNxhH?utm_source=generator&theme=0"
              width="100%"
              height="352"
              frameBorder="0"
              allowFullScreen
              allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
              loading="lazy"
            />
            <p className="text-xs text-muted-foreground mt-3 text-center">
              Official 33.3 FM Dogechain playlist on Spotify
            </p>
          </div>
        </div>
      )}

      {/* Expanded View */}
      {isExpanded && currentHost && (
        <div className="bg-black/95 border-t border-orange-500/30 backdrop-blur-xl p-4" style={glowStyles.orange}>
          <div className="container mx-auto">
            <div className="flex flex-col md:flex-row items-center gap-6">
              {/* Host Info */}
              <div className="flex items-center gap-4">
                <div className="relative">
                  <img
                    src={currentHost.avatar || "/placeholder.svg"}
                    alt={currentHost.name}
                    className="w-20 h-20 rounded-full border-2 border-orange-500"
                  />
                  <div className="absolute -bottom-1 -right-1 bg-red-500 rounded-full p-1.5">
                    <Mic className="h-3 w-3 text-white" />
                  </div>
                </div>
                <div>
                  <p className="text-xs text-orange-500 font-semibold uppercase tracking-wider">Now Playing</p>
                  <h3 className="text-xl font-bold" style={glowStyles.textOrange}>
                    {currentHost.name}
                  </h3>
                  {currentHost.showName && <p className="text-sm text-orange-400">{currentHost.showName}</p>}
                  <p className="text-xs text-muted-foreground">
                    @{currentHost.handle} • {currentHost.timeSlot}
                  </p>
                </div>
              </div>

              {/* Audio Visualizer */}
              <div className="flex-1 flex items-end justify-center h-16 gap-0.5 px-4">
                {audioVisualizerBars.map((height, i) => (
                  <div
                    key={i}
                    className="w-1.5 bg-gradient-to-t from-orange-600 to-yellow-400 rounded-full transition-all duration-75"
                    style={{ height: `${Math.max(10, height * 0.6)}%` }}
                  />
                ))}
              </div>

              {/* Controls */}
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <button onClick={() => setIsMuted(!isMuted)}>
                    {isMuted ? (
                      <VolumeX className="h-5 w-5 text-muted-foreground" />
                    ) : (
                      <Volume2 className="h-5 w-5 text-orange-500" />
                    )}
                  </button>
                  <Slider
                    value={[isMuted ? 0 : volume]}
                    onValueChange={(v) => {
                      setVolume(v[0])
                      setIsMuted(false)
                    }}
                    max={100}
                    step={1}
                    className="w-24"
                  />
                </div>
                <Button variant="outline" size="sm" onClick={() => setShowSpotify(true)}>
                  <Music className="h-4 w-4 mr-1" />
                  Playlist
                </Button>
                <Button asChild style={glowStyles.orange}>
                  <a href={`https://x.com/${currentHost.handle}`} target="_blank" rel="noopener noreferrer">
                    Join Space
                    <ExternalLink className="ml-2 h-4 w-4" />
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Radio Bar */}
      <div className="bg-black/95 border-t border-orange-500/50 backdrop-blur-xl" style={glowStyles.orange}>
        <div className="container mx-auto px-4 py-2">
          <div className="flex items-center justify-between gap-4">
            {/* Station Branding - Added Dogechain branding */}
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-12 h-12 bg-gradient-to-br from-orange-600 to-yellow-500 rounded-lg flex flex-col items-center justify-center">
                  <span className="text-black font-black text-xs leading-none">33.3</span>
                  <span className="text-black font-bold text-[8px]">FM</span>
                </div>
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse" />
              </div>
              <div className="hidden sm:block">
                <div className="flex items-center gap-2">
                  <h2 className="font-black text-lg tracking-tight" style={glowStyles.textOrange}>
                    33.3 FM
                  </h2>
                  <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/50 text-[10px]">DOGECHAIN</Badge>
                  <Badge variant="destructive" className="animate-pulse text-xs">
                    LIVE
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground">CryptoSpaces Radio</p>
              </div>
            </div>

            {/* Now Playing - Compact */}
            {currentHost && (
              <div className="flex items-center gap-3 flex-1 max-w-md">
                <img
                  src={currentHost.avatar || "/placeholder.svg"}
                  alt={currentHost.name}
                  className="w-10 h-10 rounded-full border border-orange-500/50 hidden sm:block"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <Waves className="h-4 w-4 text-orange-500 animate-pulse" />
                    <span className="text-sm font-semibold truncate">{currentHost.name}</span>
                    {currentHost.showName && (
                      <span className="text-xs text-orange-400 truncate hidden md:inline">
                        - {currentHost.showName}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground truncate">
                    @{currentHost.handle} • {formatESTTime(currentTime)} EST
                  </p>
                </div>
              </div>
            )}

            {/* Mini Visualizer */}
            <div className="hidden lg:flex items-end h-8 gap-0.5">
              {audioVisualizerBars.slice(0, 10).map((height, i) => (
                <div
                  key={i}
                  className="w-1 bg-gradient-to-t from-orange-600 to-yellow-400 rounded-full transition-all duration-75"
                  style={{ height: `${Math.max(15, height * 0.3)}%` }}
                />
              ))}
            </div>

            {/* Actions - Added Spotify and Community buttons */}
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowSpotify(true)}
                className="hidden sm:flex"
                title="Spotify Playlist"
              >
                <Music className="h-4 w-4" />
              </Button>

              <Button variant="ghost" size="icon" asChild className="hidden sm:flex" title="789 Community">
                <a href="https://x.com/i/communities/1956818120120656211" target="_blank" rel="noopener noreferrer">
                  <Users className="h-4 w-4" />
                </a>
              </Button>

              <Button variant="ghost" size="sm" onClick={() => setIsExpanded(!isExpanded)} className="hidden sm:flex">
                <ChevronUp className={`h-4 w-4 transition-transform ${isExpanded ? "rotate-180" : ""}`} />
              </Button>

              <Button asChild size="sm" className="bg-orange-600 hover:bg-orange-700 text-white">
                <a
                  href={currentHost ? `https://x.com/${currentHost.handle}` : "https://cryptospaces.net/"}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Radio className="h-4 w-4 mr-1" />
                  <span className="hidden sm:inline">Listen Live</span>
                  <span className="sm:hidden">Live</span>
                </a>
              </Button>

              <Button variant="ghost" size="icon" onClick={() => setIsMinimized(true)} className="h-8 w-8">
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
