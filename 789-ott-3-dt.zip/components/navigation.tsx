"use client"

import Link from "next/link"
import { Film, Home, Play, DollarSign, Radio, Sparkles, Clapperboard, Users, Dog, TrendingUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { usePathname } from "next/navigation"
import { glowStyles } from "@/lib/styles"
import { ConnectWalletButton } from "@/components/wallet/connect-wallet-button"

export function Navigation() {
  const pathname = usePathname()

  const navItems = [
    { href: "/", label: "Home", icon: Home },
    { href: "/watch", label: "Watch", icon: Play },
    { href: "/live", label: "Live", icon: Radio },
    { href: "/market", label: "Market", icon: TrendingUp },
    { href: "/dd-cartoons", label: "DD CARTOONS", icon: Clapperboard },
    { href: "/doginals", label: "Doginals", icon: Dog },
    { href: "/crew", label: "789 CREW", icon: Users },
    { href: "/creator-studio", label: "Creator Studio", icon: Film },
    { href: "/affiliates", label: "Affiliates", icon: DollarSign },
  ]

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4">
        <Link href="/" className="flex items-center gap-2">
          <div className="flex items-center gap-2">
            <Sparkles className="h-8 w-8 text-primary" style={glowStyles.orange} />
            <div className="flex flex-col">
              <span className="text-xl font-bold text-primary" style={glowStyles.textOrange}>
                789 STUDIOS
              </span>
              <span className="text-xs text-muted-foreground">Film3 OTT Platform</span>
            </div>
          </div>
        </Link>

        <div className="hidden md:flex items-center gap-1">
          {navItems.map((item) => {
            const Icon = item.icon
            const isActive = pathname === item.href
            const isLive = item.href === "/live"
            return (
              <Link key={item.href} href={item.href}>
                <Button
                  variant={isActive ? "default" : "ghost"}
                  size="sm"
                  style={isActive ? glowStyles.orange : undefined}
                  className={isLive && !isActive ? "text-red-500" : ""}
                >
                  <Icon className={`mr-2 h-4 w-4 ${isLive ? "animate-pulse" : ""}`} />
                  {item.label}
                </Button>
              </Link>
            )
          })}
        </div>

        <div className="flex items-center gap-2">
          <ConnectWalletButton />
        </div>
      </div>
    </nav>
  )
}
