"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import type { Video } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Play, Info, ChevronLeft, ChevronRight } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { glowStyles } from "@/lib/styles"

interface HeroCarouselProps {
  videos: Video[]
}

export function HeroCarousel({ videos }: HeroCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isAutoPlaying, setIsAutoPlaying] = useState(true)

  useEffect(() => {
    if (!isAutoPlaying) return

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % videos.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [isAutoPlaying, videos.length])

  const goToPrevious = () => {
    setIsAutoPlaying(false)
    setCurrentIndex((prev) => (prev - 1 + videos.length) % videos.length)
  }

  const goToNext = () => {
    setIsAutoPlaying(false)
    setCurrentIndex((prev) => (prev + 1) % videos.length)
  }

  const currentVideo = videos[currentIndex]

  return (
    <div className="relative h-[70vh] w-full overflow-hidden bg-black">
      <div className="absolute inset-0">
        <Image
          src={currentVideo.thumbnail || "/placeholder.svg"}
          alt={currentVideo.title}
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/50 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
      </div>

      <div className="relative h-full container px-4 flex items-center">
        <div className="max-w-2xl space-y-4">
          <Badge className="bg-primary/90 backdrop-blur-sm text-primary-foreground text-sm">
            {currentVideo.category}
          </Badge>

          <h1 className="text-5xl font-bold text-white leading-tight" style={glowStyles.textOrange}>
            {currentVideo.title}
          </h1>

          <p className="text-lg text-white/90 line-clamp-3 text-pretty">{currentVideo.description}</p>

          <div className="flex items-center gap-4 text-sm text-white/70">
            <span>{currentVideo.views.toLocaleString()} views</span>
            <span>•</span>
            <span>{Math.floor(currentVideo.duration / 60)} minutes</span>
            {currentVideo.isTokenGated && (
              <>
                <span>•</span>
                <Badge variant="secondary" style={glowStyles.yellow}>
                  Token Gated
                </Badge>
              </>
            )}
          </div>

          <div className="flex gap-3 pt-2">
            <Link href={`/watch/${currentVideo.id}`}>
              <Button size="lg" style={glowStyles.orange}>
                <Play className="mr-2 h-5 w-5 fill-current" />
                Play Now
              </Button>
            </Link>
            <Button size="lg" variant="outline">
              <Info className="mr-2 h-5 w-5" />
              More Info
            </Button>
          </div>
        </div>
      </div>

      <button
        onClick={goToPrevious}
        className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 backdrop-blur-sm p-3 rounded-full transition-all hover:scale-110"
        aria-label="Previous video"
      >
        <ChevronLeft className="h-6 w-6 text-white" />
      </button>

      <button
        onClick={goToNext}
        className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 backdrop-blur-sm p-3 rounded-full transition-all hover:scale-110"
        aria-label="Next video"
      >
        <ChevronRight className="h-6 w-6 text-white" />
      </button>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-2">
        {videos.map((_, index) => (
          <button
            key={index}
            onClick={() => {
              setCurrentIndex(index)
              setIsAutoPlaying(false)
            }}
            className={`h-1 rounded-full transition-all ${
              index === currentIndex ? "w-12 bg-primary" : "w-8 bg-white/30 hover:bg-white/50"
            }`}
            style={index === currentIndex ? glowStyles.orange : undefined}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </div>
  )
}
