"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Coins, Users, TrendingUp, Award } from "lucide-react"
import { glowStyles } from "@/lib/styles"

export function RewardsPool() {
  const poolBalance = 127.5
  const totalDistributed = 456.3
  const activeParticipants = 8942
  const yourEarnings = 2.47

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Card className="border-primary/20 bg-gradient-to-br from-primary/10 to-secondary/10">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-2xl">
            <Coins className="h-6 w-6 text-primary" />
            DeFi Ad Rewards Pool
          </CardTitle>
          <CardDescription>Earn crypto rewards for watching ads and engaging with sponsored content</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid sm:grid-cols-2 gap-6">
            <div className="bg-card rounded-lg p-6 border border-border">
              <div className="flex items-center gap-2 mb-2">
                <Coins className="h-5 w-5 text-primary" />
                <span className="text-sm text-muted-foreground">Current Pool Balance</span>
              </div>
              <p className="text-3xl font-bold text-primary">{poolBalance} ETH</p>
              <p className="text-sm text-muted-foreground mt-1">Refreshes daily</p>
            </div>

            <div className="bg-card rounded-lg p-6 border border-border">
              <div className="flex items-center gap-2 mb-2">
                <Award className="h-5 w-5 text-secondary" />
                <span className="text-sm text-muted-foreground">Your Earnings</span>
              </div>
              <p className="text-3xl font-bold text-secondary">{yourEarnings} ETH</p>
              <Button size="sm" className="mt-3" style={glowStyles.yellow}>
                Claim Rewards
              </Button>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-semibold">Pool Distribution Progress</span>
                <span className="text-sm text-muted-foreground">72% claimed today</span>
              </div>
              <Progress value={72} className="h-2" />
            </div>

            <div className="grid sm:grid-cols-2 gap-4 text-sm">
              <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <span className="text-muted-foreground">Active Participants</span>
                </div>
                <span className="font-semibold">{activeParticipants.toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                  <span className="text-muted-foreground">Total Distributed</span>
                </div>
                <span className="font-semibold">{totalDistributed} ETH</span>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-border">
            <h3 className="font-semibold mb-3">How to Earn More Rewards</h3>
            <div className="space-y-2 text-sm">
              <div className="flex items-start gap-3 p-3 bg-card rounded-lg">
                <Badge className="mt-0.5">1</Badge>
                <div>
                  <p className="font-semibold">Watch Full Ads</p>
                  <p className="text-muted-foreground">Complete pre-roll and mid-roll ads to earn base rewards</p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-3 bg-card rounded-lg">
                <Badge className="mt-0.5">2</Badge>
                <div>
                  <p className="font-semibold">Scan QR Codes</p>
                  <p className="text-muted-foreground">Interact with Smart TV QR pop-ups for bonus earnings</p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-3 bg-card rounded-lg">
                <Badge className="mt-0.5">3</Badge>
                <div>
                  <p className="font-semibold">Convert via Ads</p>
                  <p className="text-muted-foreground">Purchase or sign up through ads for 10x rewards multiplier</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Rewards Pool Mechanics</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p>• Pool funded by a portion of advertiser spending</p>
          <p>• Rewards distributed proportionally based on engagement</p>
          <p>• Claims processed instantly via smart contracts</p>
          <p>• Minimum withdrawal: 0.01 ETH to reduce gas fees</p>
          <p>• Premium members earn 2x rewards multiplier</p>
        </CardContent>
      </Card>
    </div>
  )
}
