import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { MoreHorizontal, Pause, Play, TrendingUp } from "lucide-react"

const campaigns = [
  {
    name: "Q1 Product Launch",
    format: "Pre-roll Video",
    status: "active",
    impressions: "234K",
    ctr: "4.8%",
    spent: "3.2 ETH",
    remaining: "1.8 ETH",
  },
  {
    name: "Holiday NFT Drop",
    format: "NFT Billboard",
    status: "active",
    impressions: "189K",
    ctr: "6.2%",
    spent: "2.5 ETH",
    remaining: "2.5 ETH",
  },
  {
    name: "Crypto Gaming Promo",
    format: "Mid-roll Video",
    status: "paused",
    impressions: "156K",
    ctr: "3.9%",
    spent: "1.8 ETH",
    remaining: "0.2 ETH",
  },
]

export function AdPerformance() {
  return (
    <Card className="p-6 bg-card border-primary/20">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold">Campaign Performance</h2>
        <Button variant="outline" size="sm">
          <TrendingUp className="h-4 w-4 mr-2" />
          View Analytics
        </Button>
      </div>

      <div className="space-y-4">
        {campaigns.map((campaign, idx) => (
          <div
            key={idx}
            className="p-4 bg-muted/30 rounded-lg border border-border hover:border-primary/50 transition-colors"
          >
            <div className="flex items-start justify-between mb-3">
              <div>
                <div className="font-semibold text-lg">{campaign.name}</div>
                <div className="text-sm text-muted-foreground">{campaign.format}</div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant={campaign.status === "active" ? "default" : "secondary"}>{campaign.status}</Badge>
                <Button variant="ghost" size="icon">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-4 gap-4 mb-3">
              <div>
                <div className="text-xs text-muted-foreground">Impressions</div>
                <div className="font-semibold">{campaign.impressions}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">CTR</div>
                <div className="font-semibold text-secondary">{campaign.ctr}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Spent</div>
                <div className="font-semibold">{campaign.spent}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Remaining</div>
                <div className="font-semibold text-primary">{campaign.remaining}</div>
              </div>
            </div>

            <div className="flex gap-2">
              <Button size="sm" variant="outline">
                {campaign.status === "active" ? (
                  <>
                    <Pause className="h-3 w-3 mr-2" />
                    Pause
                  </>
                ) : (
                  <>
                    <Play className="h-3 w-3 mr-2" />
                    Resume
                  </>
                )}
              </Button>
              <Button size="sm" variant="ghost">
                View Report
              </Button>
            </div>
          </div>
        ))}
      </div>
    </Card>
  )
}
