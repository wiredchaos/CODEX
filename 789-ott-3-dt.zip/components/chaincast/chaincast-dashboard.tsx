import { Card } from "@/components/ui/card"
import { Eye, MousePointer, Wallet, TrendingUp } from "lucide-react"

const stats = [
  {
    label: "Total Impressions",
    value: "847K",
    change: "+23%",
    icon: Eye,
    color: "text-primary",
  },
  {
    label: "Click-through Rate",
    value: "4.2%",
    change: "+0.8%",
    icon: MousePointer,
    color: "text-secondary",
  },
  {
    label: "Ad Spend (ETH)",
    value: "12.5",
    change: "+5.3",
    icon: Wallet,
    color: "text-chart-3",
  },
  {
    label: "ROAS",
    value: "3.2x",
    change: "+0.4x",
    icon: TrendingUp,
    color: "text-chart-4",
  },
]

export function ChainCastDashboard() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => {
        const Icon = stat.icon
        return (
          <Card key={stat.label} className="p-6 bg-card border-primary/20">
            <div className="flex items-center justify-between mb-2">
              <div className="text-sm text-muted-foreground">{stat.label}</div>
              <Icon className={`h-4 w-4 ${stat.color}`} />
            </div>
            <div className="text-2xl font-bold mb-1">{stat.value}</div>
            <div className="text-sm text-secondary">{stat.change} vs last month</div>
          </Card>
        )
      })}
    </div>
  )
}
