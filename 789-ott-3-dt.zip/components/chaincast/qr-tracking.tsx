"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { QrCode, Scan, TrendingUp, ExternalLink } from "lucide-react"
import { glowStyles } from "@/lib/styles"

const qrCampaigns = [
  {
    id: "qr-001",
    name: "Smart TV Launch Promo",
    scans: 1247,
    conversions: 184,
    conversionRate: 14.8,
    status: "active",
  },
  {
    id: "qr-002",
    name: "NFT Drop Announcement",
    scans: 892,
    conversions: 156,
    conversionRate: 17.5,
    status: "active",
  },
  {
    id: "qr-003",
    name: "Creator Token Sale",
    scans: 2103,
    conversions: 312,
    conversionRate: 14.8,
    status: "completed",
  },
]

export function QRTracking() {
  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Card className="border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <QrCode className="h-5 w-5 text-primary" />
            QR Code Campaign Tracking
          </CardTitle>
          <CardDescription>Monitor Smart TV QR pop-ups and interactive billboard performance</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            {qrCampaigns.map((campaign) => (
              <div key={campaign.id} className="p-4 bg-muted/30 rounded-lg border border-border">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-semibold text-lg">{campaign.name}</h3>
                    <p className="text-sm text-muted-foreground">Campaign ID: {campaign.id}</p>
                  </div>
                  <Badge variant={campaign.status === "active" ? "default" : "secondary"}>{campaign.status}</Badge>
                </div>

                <div className="grid grid-cols-3 gap-4 mt-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Scan className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">Total Scans</span>
                    </div>
                    <p className="text-2xl font-bold text-primary">{campaign.scans.toLocaleString()}</p>
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <TrendingUp className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">Conversions</span>
                    </div>
                    <p className="text-2xl font-bold">{campaign.conversions}</p>
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">Conv. Rate</span>
                    </div>
                    <p className="text-2xl font-bold text-secondary">{campaign.conversionRate}%</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-6 border-t border-border">
            <h3 className="font-semibold text-lg mb-4">Create New QR Campaign</h3>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="campaign-name">Campaign Name</Label>
                <Input id="campaign-name" placeholder="e.g., Season 2 Launch" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="destination">Destination URL</Label>
                <Input id="destination" placeholder="https://789studios.tv/..." />
              </div>

              <Button className="w-full" style={glowStyles.orange}>
                Generate QR Code
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>QR Code Best Practices</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p>• Place QR codes during natural pause points in content</p>
          <p>• Display for 8-12 seconds for optimal scanning time</p>
          <p>• Include clear call-to-action text with the QR code</p>
          <p>• Test on multiple Smart TV platforms before deployment</p>
          <p>• Use deep links to provide seamless user experience</p>
        </CardContent>
      </Card>
    </div>
  )
}
