"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus } from "lucide-react"
import { glowStyles } from "@/lib/styles"

export function AdCreation() {
  return (
    <Card className="p-6 bg-card border-primary/20">
      <h2 className="text-2xl font-bold mb-6" style={glowStyles.textOrange}>
        Create New Ad Campaign
      </h2>

      <form className="space-y-6">
        <div className="grid gap-6 md:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="campaign-name">Campaign Name</Label>
            <Input id="campaign-name" placeholder="Q1 2024 Product Launch" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="ad-format">Ad Format</Label>
            <Select>
              <SelectTrigger id="ad-format">
                <SelectValue placeholder="Select format" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="preroll">Pre-roll Video</SelectItem>
                <SelectItem value="midroll">Mid-roll Video</SelectItem>
                <SelectItem value="banner">Banner Overlay</SelectItem>
                <SelectItem value="nft-billboard">NFT Billboard</SelectItem>
                <SelectItem value="smarttv-qr">Smart TV QR Pop-up</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="target-wallets">Target Wallet Segment</Label>
          <Select>
            <SelectTrigger id="target-wallets">
              <SelectValue placeholder="Select audience" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Viewers</SelectItem>
              <SelectItem value="nft-holders">NFT Holders</SelectItem>
              <SelectItem value="defi-users">DeFi Users</SelectItem>
              <SelectItem value="high-value">High-Value Wallets (&gt;10 ETH)</SelectItem>
              <SelectItem value="creators">Content Creators</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="video-url">Video Asset URL</Label>
          <Input id="video-url" placeholder="https://cdn.789studios.tv/ads/..." />
        </div>

        <div className="space-y-2">
          <Label htmlFor="landing-url">Landing Page URL</Label>
          <Input id="landing-url" placeholder="https://yoursite.com" />
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Campaign Description</Label>
          <Textarea id="description" placeholder="Describe your campaign..." rows={4} />
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          <div className="space-y-2">
            <Label htmlFor="budget">Budget (ETH)</Label>
            <Input id="budget" type="number" step="0.01" placeholder="5.0" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="duration">Duration (days)</Label>
            <Input id="duration" type="number" placeholder="30" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="max-cpm">Max CPM (ETH)</Label>
            <Input id="max-cpm" type="number" step="0.001" placeholder="0.015" />
          </div>
        </div>

        <div className="flex gap-4 pt-4">
          <Button type="submit" style={glowStyles.yellow}>
            <Plus className="h-4 w-4 mr-2" />
            Launch Campaign
          </Button>
          <Button type="button" variant="outline">
            Save as Draft
          </Button>
        </div>
      </form>
    </Card>
  )
}
