"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Wallet, Target, Users } from "lucide-react"
import { glowStyles } from "@/lib/styles"

const walletSegments = [
  {
    id: "nft-holders",
    name: "NFT Holders",
    description: "Wallets with NFT assets",
    count: 45000,
    engagement: "High",
  },
  {
    id: "defi-users",
    name: "DeFi Users",
    description: "Active DeFi protocol users",
    count: 32000,
    engagement: "Very High",
  },
  {
    id: "token-holders",
    name: "Creator Token Holders",
    description: "Holds 789 Studios creator tokens",
    count: 18000,
    engagement: "Very High",
  },
  {
    id: "crypto-whales",
    name: "Crypto Whales",
    description: "Wallets with $10K+ balance",
    count: 8500,
    engagement: "Premium",
  },
  {
    id: "new-users",
    name: "New Web3 Users",
    description: "Recently created wallets",
    count: 67000,
    engagement: "Medium",
  },
]

export function WalletTargeting() {
  const [selectedSegments, setSelectedSegments] = useState<string[]>([])

  const toggleSegment = (segmentId: string) => {
    setSelectedSegments((prev) =>
      prev.includes(segmentId) ? prev.filter((id) => id !== segmentId) : [...prev, segmentId],
    )
  }

  const totalReach = walletSegments.filter((s) => selectedSegments.includes(s.id)).reduce((sum, s) => sum + s.count, 0)

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Card className="border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5 text-primary" />
            Wallet Segmentation Targeting
          </CardTitle>
          <CardDescription>
            Target ads based on blockchain activity and wallet attributes for maximum ROI
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            {walletSegments.map((segment) => (
              <div
                key={segment.id}
                className={`p-4 rounded-lg border-2 transition-all cursor-pointer ${
                  selectedSegments.includes(segment.id)
                    ? "border-primary bg-primary/10"
                    : "border-border bg-muted/30 hover:border-primary/50"
                }`}
                onClick={() => toggleSegment(segment.id)}
              >
                <div className="flex items-start gap-4">
                  <Checkbox
                    id={segment.id}
                    checked={selectedSegments.includes(segment.id)}
                    onCheckedChange={() => toggleSegment(segment.id)}
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Label htmlFor={segment.id} className="font-semibold cursor-pointer">
                        {segment.name}
                      </Label>
                      <Badge variant="secondary" className="text-xs">
                        {segment.engagement}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{segment.description}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-semibold">{segment.count.toLocaleString()} wallets</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-muted/50 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Wallet className="h-5 w-5 text-primary" />
                <h4 className="font-semibold">Campaign Reach</h4>
              </div>
              <span className="text-2xl font-bold text-primary">{totalReach.toLocaleString()}</span>
            </div>
            <p className="text-sm text-muted-foreground">
              {selectedSegments.length === 0
                ? "Select segments to see estimated reach"
                : `Your ad will reach approximately ${totalReach.toLocaleString()} unique wallets`}
            </p>
          </div>

          <Button className="w-full" style={glowStyles.orange} disabled={selectedSegments.length === 0}>
            Apply Targeting
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Why Wallet Targeting?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p>• Target users based on verified on-chain behavior</p>
          <p>• Higher engagement rates than traditional demographics</p>
          <p>• Reach audiences proven to interact with crypto products</p>
          <p>• Privacy-preserving targeting without personal data</p>
          <p>• Real-time segmentation based on latest blockchain data</p>
        </CardContent>
      </Card>
    </div>
  )
}
