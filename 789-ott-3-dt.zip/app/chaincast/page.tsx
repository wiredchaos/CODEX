import { Navigation } from "@/components/navigation"
import { ChainCastDashboard } from "@/components/chaincast/chaincast-dashboard"
import { AdCreation } from "@/components/chaincast/ad-creation"
import { AdPerformance } from "@/components/chaincast/ad-performance"
import { WalletTargeting } from "@/components/chaincast/wallet-targeting"
import { QRTracking } from "@/components/chaincast/qr-tracking"
import { RewardsPool } from "@/components/chaincast/rewards-pool"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Zap } from "lucide-react"
import { glowStyles } from "@/lib/styles"

export const metadata = {
  title: "ChainCast - Blockchain Ad Network | 789 Studios",
  description: "Film3 advertising network with crypto payments, wallet segmentation, and DeFi rewards pool",
}

export default function ChainCastPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="pt-16">
        <div className="bg-gradient-to-r from-primary/20 to-secondary/20 border-b border-primary/30">
          <div className="container px-4 py-12">
            <div className="flex items-center gap-3 mb-4">
              <Zap className="h-10 w-10 text-primary" style={glowStyles.orange} />
              <h1 className="text-4xl font-bold" style={glowStyles.textOrange}>
                ChainCast™
              </h1>
              <Badge variant="secondary" className="text-xs">
                BETA
              </Badge>
            </div>
            <p className="text-lg text-muted-foreground max-w-2xl">
              The first blockchain-powered ad network for Film3. Buy ad placements with crypto, target by wallet
              segmentation, and track ROI with QR-based attribution.
            </p>
          </div>
        </div>

        <div className="container px-4 py-8">
          <ChainCastDashboard />

          <Tabs defaultValue="performance" className="mt-8">
            <TabsList className="grid w-full grid-cols-5 max-w-3xl">
              <TabsTrigger value="performance">Performance</TabsTrigger>
              <TabsTrigger value="create">Create Ad</TabsTrigger>
              <TabsTrigger value="targeting">Targeting</TabsTrigger>
              <TabsTrigger value="qr">QR Tracking</TabsTrigger>
              <TabsTrigger value="rewards">Rewards</TabsTrigger>
            </TabsList>

            <TabsContent value="performance" className="mt-6">
              <div className="grid gap-8 lg:grid-cols-3">
                <div className="lg:col-span-2">
                  <AdPerformance />
                </div>
                <div>
                  <Card className="p-6 bg-card border-primary/20">
                    <h3 className="font-bold text-lg mb-4" style={glowStyles.textYellow}>
                      Ad Formats
                    </h3>
                    <div className="space-y-4 text-sm">
                      <div className="p-3 bg-muted/30 rounded-lg">
                        <div className="font-semibold">Pre-roll Video</div>
                        <div className="text-muted-foreground mt-1">15-30s before content</div>
                        <div className="text-primary mt-2">0.01 ETH per 1K views</div>
                      </div>
                      <div className="p-3 bg-muted/30 rounded-lg">
                        <div className="font-semibold">Mid-roll Video</div>
                        <div className="text-muted-foreground mt-1">During long-form content</div>
                        <div className="text-primary mt-2">0.015 ETH per 1K views</div>
                      </div>
                      <div className="p-3 bg-muted/30 rounded-lg">
                        <div className="font-semibold">NFT Billboard</div>
                        <div className="text-muted-foreground mt-1">Featured placement</div>
                        <div className="text-primary mt-2">0.05 ETH per day</div>
                      </div>
                      <div className="p-3 bg-muted/30 rounded-lg">
                        <div className="font-semibold">Smart TV QR Pop-up</div>
                        <div className="text-muted-foreground mt-1">Interactive QR code</div>
                        <div className="text-primary mt-2">0.02 ETH per 1K views</div>
                      </div>
                    </div>
                  </Card>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="create" className="mt-6">
              <AdCreation />
            </TabsContent>

            <TabsContent value="targeting" className="mt-6">
              <WalletTargeting />
            </TabsContent>

            <TabsContent value="qr" className="mt-6">
              <QRTracking />
            </TabsContent>

            <TabsContent value="rewards" className="mt-6">
              <RewardsPool />
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
