import { Navigation } from "@/components/navigation"
import { RoyaltyHUD } from "@/components/dd-cartoons/royalty-hud"
import { StudioTierCard } from "@/components/dd-cartoons/studio-tier-card"
import { IPLicenseViewer } from "@/components/dd-cartoons/ip-license-viewer"
import { glowStyles } from "@/lib/styles"
import type { StudioTier, IPLicense } from "@/lib/types"
import type { EpisodeRoyaltyMeta } from "@/types/royalty"

// Mock data for demonstration
const mockStudioTiers: StudioTier[] = [
  {
    id: "tier-1",
    name: "Major Studio",
    nftRequired: true,
    tokenStakeRequired: 100000,
    benefits: ["Largest royalty share", "Studio branding on episodes", "Final cut authority", "Merchandise rights"],
    royaltyBonus: 15,
    votingPower: 10,
    canApprovePilots: true,
    canSubmitScripts: true,
    canPitchEpisodes: true,
    hasVoiceRoles: true,
    hasExecutiveCredit: true,
  },
  {
    id: "tier-2",
    name: "Indie Studio",
    nftRequired: true,
    tokenStakeRequired: 50000,
    benefits: ["Submit scripts", "Pitch episodes", "Producer credit", "Revenue share"],
    royaltyBonus: 10,
    votingPower: 5,
    canApprovePilots: false,
    canSubmitScripts: true,
    canPitchEpisodes: true,
    hasVoiceRoles: true,
    hasExecutiveCredit: false,
  },
  {
    id: "tier-3",
    name: "Creator House",
    nftRequired: false,
    tokenStakeRequired: 25000,
    benefits: ["Cameo opportunities", "Voice roles", "Royalties", "Community voting"],
    royaltyBonus: 5,
    votingPower: 2,
    canApprovePilots: false,
    canSubmitScripts: false,
    canPitchEpisodes: false,
    hasVoiceRoles: true,
    hasExecutiveCredit: false,
  },
  {
    id: "tier-4",
    name: "Audience Studio",
    nftRequired: false,
    tokenStakeRequired: 5000,
    benefits: ["Voting rights", "Limited revenue share", "Early access", "Behind-the-scenes"],
    royaltyBonus: 2,
    votingPower: 1,
    canApprovePilots: false,
    canSubmitScripts: false,
    canPitchEpisodes: false,
    hasVoiceRoles: false,
    hasExecutiveCredit: false,
  },
]

const mockIPLicense: IPLicense = {
  id: "license-1",
  tokenId: "DD-DOG-0042",
  licenseType: "community",
  licensee: "0xdd123456789abcdef",
  creator: "0xabc123456789def",
  owner: "0xdef987654321abc",
  revShare: 20,
  permissionsMask: ["video", "animation", "streaming", "merchandise"],
  restrictionsMask: ["political", "adult", "hate speech"],
  metadataURI: "ipfs://Qm...",
  status: "active",
  createdAt: new Date("2024-01-01"),
}

async function getRoyaltyData(): Promise<EpisodeRoyaltyMeta> {
  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_APP_URL || ""}/api/royalty/1`, {
      cache: "no-store",
    })
    if (!res.ok) throw new Error("Failed to fetch")
    return await res.json()
  } catch (error) {
    console.error("[v0] Error fetching royalty data:", error)
    // Fallback to mock data
    return {
      episodeId: "1",
      totalRevenueUsd: 125000,
      split: {
        studio: 0.4,
        creator: 0.2,
        nftHolder: 0.2,
        treasury: 0.1,
        stakers: 0.1,
      },
      lastUpdated: new Date().toISOString(),
      source: "mock",
    }
  }
}

export default async function DDCartoonsPage() {
  const royaltyMeta = await getRoyaltyData()

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-gray-900 to-black">
      <Navigation />

      <main className="container mx-auto px-4 py-8 space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-5xl font-bold text-[#FF6A00]" style={glowStyles.textOrange}>
            DD CARTOONS Studio
          </h1>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Independent animation studio powered by blockchain royalties, IP licensing, and community governance
          </p>
        </div>

        {/* Royalty HUD */}
        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-[#FFC300]">Episode Royalty Tracking</h2>
          <RoyaltyHUD meta={royaltyMeta} />
        </section>

        {/* Studio Tiers */}
        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-[#FFC300]">Studio Tiers</h2>
          <p className="text-gray-400">Stake tokens and unlock creator benefits, voting rights, and revenue sharing</p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {mockStudioTiers.map((tier, index) => (
              <StudioTierCard key={tier.id} tier={tier} isActive={index === 0} />
            ))}
          </div>
        </section>

        {/* IP License Example */}
        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-[#FFC300]">IP License Registry</h2>
          <p className="text-gray-400">On-chain licensing for characters, assets, and intellectual property</p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <IPLicenseViewer license={mockIPLicense} />
            <IPLicenseViewer
              license={{ ...mockIPLicense, id: "license-2", tokenId: "DD-DOG-0088", status: "active" }}
            />
            <IPLicenseViewer
              license={{
                ...mockIPLicense,
                id: "license-3",
                tokenId: "DD-DOG-0124",
                status: "expired",
              }}
            />
          </div>
        </section>

        {/* Features Overview */}
        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-[#FFC300]">Platform Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 bg-black/80 border border-[#FF6A00]/30 rounded-lg">
              <h3 className="text-lg font-semibold text-[#FF6A00] mb-2">Smart Royalty Engine</h3>
              <p className="text-sm text-gray-400">
                Automated revenue splits with on-chain verification and trustless distribution
              </p>
            </div>
            <div className="p-6 bg-black/80 border border-[#FFC300]/30 rounded-lg">
              <h3 className="text-lg font-semibold text-[#FFC300] mb-2">IP Rights Registry</h3>
              <p className="text-sm text-gray-400">
                Blockchain-verified licensing with granular permissions and restrictions
              </p>
            </div>
            <div className="p-6 bg-black/80 border border-[#FF6A00]/30 rounded-lg">
              <h3 className="text-lg font-semibold text-[#FF6A00] mb-2">Token Governance</h3>
              <p className="text-sm text-gray-400">
                Community voting, staking rewards, and tiered access to production decisions
              </p>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}
