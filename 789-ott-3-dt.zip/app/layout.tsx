import type React from "react"
import type { Metadata } from "next"
import { Orbitron, Inter } from "next/font/google"
import "./globals.css"
import { seoConfig, generatePageMetadata } from "@/lib/seo-config"
import { RadioPlayer } from "@/components/radio-player"

const orbitron = Orbitron({ subsets: ["latin"], variable: "--font-orbitron" })
const inter = Inter({ subsets: ["latin"], variable: "--font-inter" })

export const metadata: Metadata = generatePageMetadata({
  title: seoConfig.defaultTitle,
  description: seoConfig.defaultDescription,
  keywords: seoConfig.defaultKeywords,
  path: "/",
})

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`${orbitron.variable} ${inter.variable}`}>
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Organization",
              name: "789 Studios",
              url: "https://789studios.tv",
              logo: "https://789studios.tv/icon.svg",
              description: "Film3 streaming platform with blockchain-powered content",
              sameAs: [
                "https://twitter.com/789Studios",
                "https://github.com/789Studios",
                "https://discord.gg/789Studios",
              ],
            }),
          }}
        />
      </head>
      <body className="font-sans antialiased">
        {children}
        <RadioPlayer />
      </body>
    </html>
  )
}
