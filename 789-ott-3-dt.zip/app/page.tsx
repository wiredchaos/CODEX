import { Navigation } from "@/components/navigation"
import { HeroCarousel } from "@/components/hero-carousel"
import { VideoCarousel } from "@/components/video-carousel"
import { mockVideos, categories } from "@/lib/mock-data"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import Link from "next/link"
import { glowStyles } from "@/lib/styles"

export default function HomePage() {
  const featuredVideos = mockVideos.slice(0, 5)
  const videosByCategory = categories
    .map((category) => ({
      category,
      videos: mockVideos.filter((v) => v.category === category),
    }))
    .filter((c) => c.videos.length > 0)

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="pt-16">
        <HeroCarousel videos={featuredVideos} />

        <div className="container px-4 py-8 space-y-12">
          <section>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-3xl font-bold" style={glowStyles.textOrange}>
                  Trending Now
                </h2>
                <p className="text-muted-foreground mt-1">Most watched Film3 content</p>
              </div>
              <Link href="/watch">
                <Button variant="outline" className="group bg-transparent">
                  View All
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Button>
              </Link>
            </div>
            <VideoCarousel videos={mockVideos.slice(0, 6)} />
          </section>

          {videosByCategory.map(({ category, videos }) => (
            <section key={category}>
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold">{category}</h2>
                  <p className="text-sm text-muted-foreground mt-1">
                    Explore {videos.length} {videos.length === 1 ? "video" : "videos"}
                  </p>
                </div>
                <Link href={`/watch?category=${encodeURIComponent(category)}`}>
                  <Button variant="ghost" size="sm" className="group">
                    View All
                    <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Button>
                </Link>
              </div>
              <VideoCarousel videos={videos} />
            </section>
          ))}

          <section
            className="bg-gradient-to-r from-primary/20 to-secondary/20 rounded-lg p-8 text-center border border-primary/30"
            style={glowStyles.orange}
          >
            <h2 className="text-3xl font-bold mb-4" style={glowStyles.textOrange}>
              Join 789 Studios Creator Program
            </h2>
            <p className="text-lg text-muted-foreground mb-6 max-w-2xl mx-auto">
              Launch your Film3 content with blockchain-powered tools, token-gated episodes, and instant crypto payments
            </p>
            <div className="flex gap-4 justify-center">
              <Link href="/creator-studio">
                <Button size="lg" style={glowStyles.yellow}>
                  Start Creating
                </Button>
              </Link>
              <Link href="/affiliates">
                <Button size="lg" variant="outline">
                  Become an Affiliate
                </Button>
              </Link>
            </div>
          </section>
        </div>
      </main>
    </div>
  )
}
