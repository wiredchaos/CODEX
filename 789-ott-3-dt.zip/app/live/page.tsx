"use client"

import { useState, useEffect, useRef } from "react"
import { Radio, Users, Clock, ExternalLink, Mic, Calendar, Globe, Volume2, Music, Link2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { glowStyles } from "@/lib/styles"
import { Navigation } from "@/components/navigation"

interface SpaceHost {
  name: string
  handle: string
  timeSlot: string
  showName?: string
  avatar: string
  isLive?: boolean
}

const spaceHosts: SpaceHost[] = [
  { name: "Edge", handle: "edgemeta", timeSlot: "4 - 5 AM EST", avatar: "/pixel-art-dog-edge-cyberpunk.jpg" },
  { name: "Tengu", handle: "TenguXL", timeSlot: "4 - 5 AM EST", avatar: "/pixel-art-dog-tengu-samurai.jpg" },
  { name: "Leah", handle: "leahbluewater", timeSlot: "6 - 7 AM EST", avatar: "/pixel-art-dog-leah-blue-water.jpg" },
  { name: "Vee", handle: "veemeta", timeSlot: "7 - 9 AM EST", avatar: "/pixel-art-dog-vee-purple-neon.jpg" },
  { name: "Mouse", handle: "Mousemeta", timeSlot: "9 - 10 AM EST", avatar: "/pixel-art-dog-mouse-tech.jpg" },
  { name: "Web", handle: "web3smb", timeSlot: "9 - 10 AM EST", avatar: "/pixel-art-dog-web3-digital.jpg" },
  {
    name: "Shibo",
    handle: "godsburnt",
    timeSlot: "10 AM - 12 PM EST",
    showName: "The Crypto Show",
    avatar: "/pixel-art-dog-shibo-gold-crown.jpg",
  },
  { name: "Ant", handle: "KingAnt", timeSlot: "12 - 2 PM EST", avatar: "/pixel-art-dog-king-ant-royal.jpg" },
  { name: "Defi", handle: "lil_defi", timeSlot: "12 - 2 PM EST", avatar: "/pixel-art-dog-defi-finance-green.jpg" },
  { name: "Paws", handle: "PawsMeta", timeSlot: "1 - 3 PM EST", avatar: "/pixel-art-dog-paws-cute.jpg" },
  { name: "Shield", handle: "Shieldmetax", timeSlot: "2 - 3 PM EST", avatar: "/pixel-art-dog-shield-armor.jpg" },
  { name: "Order", handle: "orderup", timeSlot: "3 - 5 PM EST", avatar: "/pixel-art-dog-order-chef.jpg" },
  { name: "High", handle: "Hightv", timeSlot: "4 - 5 PM EST", avatar: "/pixel-art-dog-high-tv-broadcast.jpg" },
  {
    name: "Bark",
    handle: "barkmeta",
    timeSlot: "5 - 7 PM EST",
    showName: "State of Crypto",
    avatar: "/pixel-art-dog-bark-news-anchor.jpg",
  },
  { name: "Vibes", handle: "Vibesmetax", timeSlot: "7 - 8 PM EST", avatar: "/pixel-art-dog-vibes-chill-sunset.jpg" },
  { name: "0xG", handle: "0x_TOPG", timeSlot: "7 - 9 PM EST", avatar: "/placeholder.svg?height=80&width=80" },
  { name: "Tall", handle: "tall_data", timeSlot: "8 - 10 PM EST", avatar: "/placeholder.svg?height=80&width=80" },
  { name: "Gator", handle: "gatormetaX", timeSlot: "9 - 10 PM EST", avatar: "/placeholder.svg?height=80&width=80" },
  { name: "Rus", handle: "RusMetaX", timeSlot: "9 - 10 PM EST", avatar: "/placeholder.svg?height=80&width=80" },
  { name: "Riv", handle: "RivAuraX", timeSlot: "10 - 11 PM EST", avatar: "/placeholder.svg?height=80&width=80" },
  { name: "Dream", handle: "DreamMetaX", timeSlot: "11 PM - 1 AM EST", avatar: "/placeholder.svg?height=80&width=80" },
  { name: "Luis", handle: "luismetax", timeSlot: "12 - 1 AM EST", avatar: "/placeholder.svg?height=80&width=80" },
  { name: "Lamb", handle: "LambMetaX", timeSlot: "1 - 3 AM EST", avatar: "/placeholder.svg?height=80&width=80" },
]

function getCurrentHost(): SpaceHost | null {
  const now = new Date()
  const estHour = now.getUTCHours() - 5
  const normalizedHour = estHour < 0 ? estHour + 24 : estHour

  for (const host of spaceHosts) {
    const [startStr] = host.timeSlot.split(" - ")
    const startHour = Number.parseInt(startStr)
    const isPM = host.timeSlot.includes("PM") && !host.timeSlot.startsWith("12")

    let adjustedStart = startHour
    if (isPM) adjustedStart += 12
    if (host.timeSlot.includes("12 PM")) adjustedStart = 12
    if (host.timeSlot.includes("12 AM") || host.timeSlot.includes("12 - 1 AM")) adjustedStart = 0

    const endParts = host.timeSlot.split(" - ")[1]
    let endHour = Number.parseInt(endParts)
    if (endParts.includes("PM") && !endParts.startsWith("12")) endHour += 12
    if (endParts.includes("12 PM")) endHour = 12

    if (normalizedHour >= adjustedStart && normalizedHour < endHour) {
      return { ...host, isLive: true }
    }
  }
  return spaceHosts[0]
}

export default function LivePage() {
  const [currentHost, setCurrentHost] = useState<SpaceHost | null>(null)
  const [currentTime, setCurrentTime] = useState(new Date())
  const [audioVisualizerBars, setAudioVisualizerBars] = useState<number[]>([])
  const animationRef = useRef<number>()

  useEffect(() => {
    setCurrentHost(getCurrentHost())
    const interval = setInterval(() => {
      setCurrentTime(new Date())
      setCurrentHost(getCurrentHost())
    }, 60000)
    return () => clearInterval(interval)
  }, [])

  // Audio visualizer animation
  useEffect(() => {
    const animateBars = () => {
      const bars = Array.from({ length: 40 }, () => Math.random() * 100)
      setAudioVisualizerBars(bars)
      animationRef.current = requestAnimationFrame(animateBars)
    }

    const timeout = setTimeout(() => {
      animationRef.current = requestAnimationFrame(animateBars)
    }, 100)

    return () => {
      clearTimeout(timeout)
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [])

  const formatESTTime = (date: Date) => {
    return date.toLocaleTimeString("en-US", {
      timeZone: "America/New_York",
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    })
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      <Navigation />

      <div className="pt-20 pb-12">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <div
              className="inline-flex items-center justify-center gap-4 mb-6 p-6 bg-black/60 rounded-2xl border border-orange-500/30"
              style={glowStyles.orange}
            >
              <div className="w-24 h-24 bg-gradient-to-br from-orange-600 via-orange-500 to-yellow-500 rounded-xl flex flex-col items-center justify-center shadow-2xl">
                <span className="text-black font-black text-3xl leading-none">33.3</span>
                <span className="text-black font-bold text-xs">FM</span>
              </div>
              <div className="text-left">
                <h1 className="text-4xl md:text-5xl font-black" style={glowStyles.textOrange}>
                  33.3 FM
                </h1>
                <div className="flex items-center gap-2">
                  <p className="text-xl text-muted-foreground">CryptoSpaces Radio</p>
                  <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/50">DOGECHAIN</Badge>
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <Badge variant="destructive" className="animate-pulse">
                    <span className="mr-1">●</span> LIVE 24/7
                  </Badge>
                  <span className="text-sm text-muted-foreground">{formatESTTime(currentTime)} EST</span>
                </div>
              </div>
            </div>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Your 24/7 connection to the crypto community. Powered by Doginal Dogs creators and the CryptoSpaces
              Network on Dogechain.
            </p>

            <div className="mt-4">
              <Button asChild variant="outline" className="border-orange-500/50 bg-transparent">
                <a href="https://x.com/i/communities/1956818120120656211" target="_blank" rel="noopener noreferrer">
                  <Users className="mr-2 h-4 w-4" />
                  Join 789 Community on X
                  <ExternalLink className="ml-2 h-4 w-4" />
                </a>
              </Button>
            </div>
          </div>

          {/* Current Host Card */}
          {currentHost && (
            <Card className="mb-12 border-2 border-orange-500/50 bg-black/60 overflow-hidden" style={glowStyles.orange}>
              <CardHeader className="border-b border-orange-500/20">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Badge variant="destructive" className="animate-pulse">
                      <span className="mr-1">●</span> ON AIR
                    </Badge>
                    <CardTitle>Currently Broadcasting</CardTitle>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    <span>{formatESTTime(currentTime)} EST</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row items-center gap-8">
                  {/* Host Avatar */}
                  <div className="relative shrink-0">
                    <div className="absolute inset-0 bg-orange-500/20 rounded-full animate-ping" />
                    <img
                      src={currentHost.avatar || "/placeholder.svg"}
                      alt={currentHost.name}
                      className="w-40 h-40 rounded-full border-4 border-orange-500 relative z-10"
                    />
                    <div className="absolute -bottom-2 -right-2 bg-red-500 rounded-full p-3 z-20">
                      <Mic className="h-6 w-6 text-white" />
                    </div>
                  </div>

                  {/* Host Info */}
                  <div className="text-center lg:text-left flex-1">
                    <p className="text-sm text-orange-500 font-semibold uppercase tracking-wider mb-1">
                      Now Playing on 33.3 FM Dogechain
                    </p>
                    <h2 className="text-4xl font-black mb-2" style={glowStyles.textOrange}>
                      {currentHost.name}
                    </h2>
                    {currentHost.showName && <p className="text-2xl text-orange-400 mb-2">{currentHost.showName}</p>}
                    <p className="text-lg text-muted-foreground mb-2">@{currentHost.handle}</p>
                    <p className="text-sm text-muted-foreground mb-6">{currentHost.timeSlot}</p>

                    <div className="flex flex-wrap gap-3 justify-center lg:justify-start">
                      <Button size="lg" asChild className="bg-orange-600 hover:bg-orange-700">
                        <a href={`https://x.com/${currentHost.handle}`} target="_blank" rel="noopener noreferrer">
                          <Volume2 className="mr-2 h-5 w-5" />
                          Listen Live
                          <ExternalLink className="ml-2 h-4 w-4" />
                        </a>
                      </Button>
                      <Button size="lg" variant="outline" asChild>
                        <a href={`https://x.com/${currentHost.handle}`} target="_blank" rel="noopener noreferrer">
                          <Users className="mr-2 h-5 w-5" />
                          Join Space
                        </a>
                      </Button>
                      <Button size="lg" variant="outline" asChild>
                        <a
                          href="https://x.com/i/communities/1956818120120656211"
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <Link2 className="mr-2 h-5 w-5" />
                          789 Community
                        </a>
                      </Button>
                    </div>
                  </div>

                  {/* Audio Visualizer */}
                  <div className="w-full lg:w-64 h-32 flex items-end justify-center gap-1 p-4 bg-black/40 rounded-xl border border-orange-500/20">
                    {audioVisualizerBars.slice(0, 20).map((height, i) => (
                      <div
                        key={i}
                        className="w-2 bg-gradient-to-t from-orange-600 via-orange-500 to-yellow-400 rounded-full transition-all duration-75"
                        style={{ height: `${Math.max(10, height * 0.9)}%` }}
                      />
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Spotify Playlist Section */}
          <Card className="mb-12 bg-black/60 border-orange-500/30" style={glowStyles.orange}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Music className="h-5 w-5 text-green-500" />
                33.3 FM Dogechain Official Playlist
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <iframe
                    style={{ borderRadius: 12 }}
                    src="https://open.spotify.com/embed/playlist/2VwOYrB1C93gNIPiBZNxhH?utm_source=generator&theme=0"
                    width="100%"
                    height="352"
                    frameBorder="0"
                    allowFullScreen
                    allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
                    loading="lazy"
                  />
                </div>
                <div className="flex flex-col justify-center">
                  <h3 className="text-2xl font-bold mb-4" style={glowStyles.textOrange}>
                    Stream While You Watch
                  </h3>
                  <p className="text-muted-foreground mb-4">
                    The official 33.3 FM Dogechain playlist on Spotify. Listen to the vibes of the crypto community
                    curated by Doginal Dogs creators and the CryptoSpaces Network.
                  </p>
                  <ul className="space-y-2 text-sm text-muted-foreground mb-6">
                    <li className="flex items-center gap-2">
                      <span className="w-2 h-2 bg-green-500 rounded-full" />
                      Curated crypto & Web3 beats
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="w-2 h-2 bg-green-500 rounded-full" />
                      Updated weekly by the community
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="w-2 h-2 bg-green-500 rounded-full" />
                      Perfect for trading, coding, or vibing
                    </li>
                  </ul>
                  <div className="flex gap-3">
                    <Button asChild className="bg-green-600 hover:bg-green-700">
                      <a
                        href="https://open.spotify.com/playlist/2VwOYrB1C93gNIPiBZNxhH"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <Music className="mr-2 h-4 w-4" />
                        Open in Spotify
                        <ExternalLink className="ml-2 h-4 w-4" />
                      </a>
                    </Button>
                    <Button variant="outline" asChild>
                      <a
                        href="https://x.com/i/communities/1956818120120656211"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <Users className="mr-2 h-4 w-4" />
                        Join Community
                      </a>
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* How to Listen Section */}
          <Card className="mb-12 bg-black/40 border-orange-500/30">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Radio className="h-5 w-5 text-orange-500" />
                How to Listen to 33.3 FM Dogechain
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="p-6 bg-black/40 rounded-xl border border-border text-center">
                  <div className="w-16 h-16 bg-orange-600/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-black text-orange-500">1</span>
                  </div>
                  <h3 className="font-semibold mb-2">Click "Listen Live"</h3>
                  <p className="text-sm text-muted-foreground">
                    Use the 33.3 FM radio bar at the bottom of any page or click the button above
                  </p>
                </div>
                <div className="p-6 bg-black/40 rounded-xl border border-border text-center">
                  <div className="w-16 h-16 bg-orange-600/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-black text-orange-500">2</span>
                  </div>
                  <h3 className="font-semibold mb-2">Join the X Space</h3>
                  <p className="text-sm text-muted-foreground">
                    You'll be taken directly to the live X/Twitter Space with the current host
                  </p>
                </div>
                <div className="p-6 bg-black/40 rounded-xl border border-border text-center">
                  <div className="w-16 h-16 bg-orange-600/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-black text-orange-500">3</span>
                  </div>
                  <h3 className="font-semibold mb-2">Engage & Enjoy</h3>
                  <p className="text-sm text-muted-foreground">
                    Request to speak, react, and participate in 24/7 crypto conversations
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Schedule Grid */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-6">
              <Calendar className="h-6 w-6 text-orange-500" />
              <h2 className="text-2xl font-bold">Daily Schedule (EST)</h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {spaceHosts.map((host) => (
                <Card
                  key={host.handle}
                  className={`bg-black/40 border-border hover:border-orange-500/50 transition-all cursor-pointer ${
                    currentHost?.handle === host.handle ? "border-orange-500 ring-2 ring-orange-500/30" : ""
                  }`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={host.avatar || "/placeholder.svg"}
                        alt={host.name}
                        className="w-12 h-12 rounded-full border-2 border-border"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold truncate">{host.name}</h3>
                          {currentHost?.handle === host.handle && (
                            <Badge variant="destructive" className="text-xs">
                              LIVE
                            </Badge>
                          )}
                        </div>
                        {host.showName && <p className="text-xs text-orange-400 truncate">{host.showName}</p>}
                        <p className="text-xs text-muted-foreground">{host.timeSlot}</p>
                      </div>
                      <a
                        href={`https://x.com/${host.handle}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="shrink-0"
                      >
                        <Button size="icon" variant="ghost">
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      </a>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* CryptoSpaces Services */}
          <Card className="bg-black/40 border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5 text-orange-500" />
                CryptoSpaces Network Services
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
                {[
                  { title: "Consultation & Advisory", tags: ["Web3 Strategy", "NFT Advisory", "Go To Marketing"] },
                  { title: "Project Infrastructure", tags: ["Tokenomics", "Community Building", "Development"] },
                  { title: "Art & Media Design", tags: ["NFT Collections", "Branding", "Motion Graphics"] },
                  { title: "Press Release Campaigns", tags: ["Crypto PR", "SEO Optimization", "Growth"] },
                  { title: "Reputational Consultations", tags: ["Trust Building", "Brand Recognition", "Advising"] },
                ].map((service) => (
                  <div key={service.title} className="p-4 bg-black/40 rounded-lg border border-border">
                    <h4 className="font-semibold mb-2 text-sm">{service.title}</h4>
                    <div className="flex flex-wrap gap-1">
                      {service.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-6 flex flex-wrap gap-3 justify-center">
                <Button asChild className="bg-orange-600 hover:bg-orange-700">
                  <a href="https://cryptospaces.net/" target="_blank" rel="noopener noreferrer">
                    <Globe className="mr-2 h-4 w-4" />
                    Visit CryptoSpaces.net
                    <ExternalLink className="ml-2 h-4 w-4" />
                  </a>
                </Button>
                <Button asChild variant="outline">
                  <a href="https://x.com/i/communities/1956818120120656211" target="_blank" rel="noopener noreferrer">
                    <Users className="mr-2 h-4 w-4" />
                    789 Community
                    <ExternalLink className="ml-2 h-4 w-4" />
                  </a>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
