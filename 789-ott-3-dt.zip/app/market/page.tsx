"use client"

import { useState, useEffect } from "react"
import { Navigation } from "@/components/navigation"
import { glowStyles } from "@/lib/styles"
import {
  mockMarketData,
  mockNewsItems,
  mockListings,
  mockRecentSales,
  rssFeedSources,
  timeAgo,
  formatDoge,
  formatUsd,
} from "@/lib/market-data"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  TrendingUp,
  TrendingDown,
  ExternalLink,
  RefreshCw,
  Newspaper,
  ShoppingCart,
  History,
  BarChart3,
  Rss,
  Dog,
  DollarSign,
  Users,
  Activity,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function MarketPage() {
  const [marketData, setMarketData] = useState(mockMarketData)
  const [news, setNews] = useState(mockNewsItems)
  const [listings, setListings] = useState(mockListings)
  const [sales, setSales] = useState(mockRecentSales)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [lastRefresh, setLastRefresh] = useState(new Date())
  const [activeNewsTab, setActiveNewsTab] = useState<string>("all")

  // Simulate live data refresh
  const refreshData = () => {
    setIsRefreshing(true)
    setTimeout(() => {
      // Simulate small price fluctuations
      setMarketData((prev) => ({
        ...prev,
        doginalDogs: {
          ...prev.doginalDogs,
          floorPrice: prev.doginalDogs.floorPrice + Math.floor((Math.random() - 0.5) * 5000),
          priceChange24h: prev.doginalDogs.priceChange24h + (Math.random() - 0.5) * 0.5,
        },
        dogecoin: {
          ...prev.dogecoin,
          price: prev.dogecoin.price + (Math.random() - 0.5) * 0.01,
          priceChange24h: prev.dogecoin.priceChange24h + (Math.random() - 0.5) * 0.2,
        },
        lastUpdated: new Date(),
      }))
      setLastRefresh(new Date())
      setIsRefreshing(false)
    }, 1000)
  }

  // Auto-refresh every 30 seconds
  useEffect(() => {
    const interval = setInterval(refreshData, 30000)
    return () => clearInterval(interval)
  }, [])

  const filteredNews = activeNewsTab === "all" ? news : news.filter((item) => item.category === activeNewsTab)

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "crypto":
        return "bg-blue-500/20 text-blue-400"
      case "nft":
        return "bg-purple-500/20 text-purple-400"
      case "defi":
        return "bg-green-500/20 text-green-400"
      case "regulation":
        return "bg-yellow-500/20 text-yellow-400"
      case "market":
        return "bg-orange-500/20 text-orange-400"
      default:
        return "bg-gray-500/20 text-gray-400"
    }
  }

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case "Common":
        return "bg-gray-500/20 text-gray-400"
      case "Uncommon":
        return "bg-green-500/20 text-green-400"
      case "Rare":
        return "bg-blue-500/20 text-blue-400"
      case "Epic":
        return "bg-purple-500/20 text-purple-400"
      case "Legendary":
        return "bg-yellow-500/20 text-yellow-400"
      default:
        return "bg-gray-500/20 text-gray-400"
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="container mx-auto px-4 pt-24 pb-16">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <h1 className="text-4xl font-bold" style={glowStyles.textOrange}>
              Market Dashboard
            </h1>
            <p className="text-muted-foreground mt-2">Live Doginal Dogs marketplace data and crypto news</p>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">Last updated: {lastRefresh.toLocaleTimeString()}</span>
            <Button variant="outline" size="sm" onClick={refreshData} disabled={isRefreshing}>
              <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? "animate-spin" : ""}`} />
              Refresh
            </Button>
            <Link href="https://market.doginaldogs.com/" target="_blank">
              <Button style={glowStyles.orange}>
                <ExternalLink className="h-4 w-4 mr-2" />
                Open Marketplace
              </Button>
            </Link>
          </div>
        </div>

        {/* Market Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4 mb-8">
          <Card className="bg-card/50 border-border/50">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
                <Dog className="h-3 w-3" />
                Floor Price
              </div>
              <div className="text-lg font-bold" style={glowStyles.textOrange}>
                {formatDoge(marketData.doginalDogs.floorPrice)} DOGE
              </div>
              <div className="text-xs text-muted-foreground">{formatUsd(marketData.doginalDogs.floorPriceUsd)}</div>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-border/50">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
                <Activity className="h-3 w-3" />
                24h Change
              </div>
              <div
                className={`text-lg font-bold flex items-center gap-1 ${
                  marketData.doginalDogs.priceChange24h >= 0 ? "text-green-400" : "text-red-400"
                }`}
              >
                {marketData.doginalDogs.priceChange24h >= 0 ? (
                  <TrendingUp className="h-4 w-4" />
                ) : (
                  <TrendingDown className="h-4 w-4" />
                )}
                {marketData.doginalDogs.priceChange24h.toFixed(2)}%
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-border/50">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
                <BarChart3 className="h-3 w-3" />
                24h Volume
              </div>
              <div className="text-lg font-bold">{formatDoge(marketData.doginalDogs.volume24h)}</div>
              <div className="text-xs text-muted-foreground">DOGE</div>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-border/50">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
                <ShoppingCart className="h-3 w-3" />
                24h Sales
              </div>
              <div className="text-lg font-bold">{marketData.doginalDogs.sales24h}</div>
              <div className="text-xs text-muted-foreground">transactions</div>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-border/50">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
                <Users className="h-3 w-3" />
                Owners
              </div>
              <div className="text-lg font-bold">{marketData.doginalDogs.owners.toLocaleString()}</div>
              <div className="text-xs text-muted-foreground">unique holders</div>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-border/50">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
                <ShoppingCart className="h-3 w-3" />
                Listed
              </div>
              <div className="text-lg font-bold">{marketData.doginalDogs.listed}</div>
              <div className="text-xs text-muted-foreground">for sale</div>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-border/50">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
                <DollarSign className="h-3 w-3" />
                DOGE Price
              </div>
              <div className="text-lg font-bold">${marketData.dogecoin.price.toFixed(4)}</div>
              <div className={`text-xs ${marketData.dogecoin.priceChange24h >= 0 ? "text-green-400" : "text-red-400"}`}>
                {marketData.dogecoin.priceChange24h >= 0 ? "+" : ""}
                {marketData.dogecoin.priceChange24h.toFixed(2)}%
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-border/50">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
                <BarChart3 className="h-3 w-3" />
                All-Time Vol
              </div>
              <div className="text-lg font-bold" style={glowStyles.textYellow}>
                $3.7M
              </div>
              <div className="text-xs text-muted-foreground">USD</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* News Feed */}
          <div className="lg:col-span-2">
            <Card className="bg-card/50 border-border/50">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Newspaper className="h-5 w-5" />
                  Crypto News Feed
                </CardTitle>
                <div className="flex items-center gap-2">
                  <Rss className="h-4 w-4 text-orange-500" />
                  <span className="text-xs text-muted-foreground">{rssFeedSources.length} sources</span>
                </div>
              </CardHeader>
              <CardContent>
                <Tabs value={activeNewsTab} onValueChange={setActiveNewsTab}>
                  <TabsList className="mb-4">
                    <TabsTrigger value="all">All</TabsTrigger>
                    <TabsTrigger value="crypto">Crypto</TabsTrigger>
                    <TabsTrigger value="nft">NFT</TabsTrigger>
                    <TabsTrigger value="market">Market</TabsTrigger>
                    <TabsTrigger value="regulation">Regulation</TabsTrigger>
                  </TabsList>
                  <TabsContent value={activeNewsTab} className="space-y-4">
                    {filteredNews.map((item) => (
                      <Link key={item.id} href={item.url} target="_blank" className="block">
                        <div className="p-4 rounded-lg bg-background/50 border border-border/30 hover:border-primary/50 transition-all group">
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <Badge className={getCategoryColor(item.category)}>{item.category.toUpperCase()}</Badge>
                                <span className="text-xs text-muted-foreground">{item.source}</span>
                                <span className="text-xs text-muted-foreground">{timeAgo(item.publishedAt)}</span>
                              </div>
                              <h3 className="font-semibold group-hover:text-primary transition-colors">{item.title}</h3>
                              <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{item.description}</p>
                            </div>
                            <ExternalLink className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors flex-shrink-0" />
                          </div>
                        </div>
                      </Link>
                    ))}
                  </TabsContent>
                </Tabs>

                {/* RSS Sources */}
                <div className="mt-6 pt-6 border-t border-border/30">
                  <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
                    <Rss className="h-4 w-4 text-orange-500" />
                    RSS Feed Sources
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {rssFeedSources.map((source) => (
                      <Link key={source.name} href={source.url} target="_blank">
                        <Badge variant="outline" className="hover:bg-primary/10 transition-colors">
                          {source.name}
                          <ExternalLink className="h-3 w-3 ml-1" />
                        </Badge>
                      </Link>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Marketplace Activity */}
          <div className="space-y-6">
            {/* Live Listings */}
            <Card className="bg-card/50 border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <ShoppingCart className="h-5 w-5" />
                  Live Listings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {listings.map((listing) => (
                  <Link key={listing.id} href="https://market.doginaldogs.com/" target="_blank" className="block">
                    <div className="flex items-center gap-3 p-2 rounded-lg bg-background/50 hover:bg-background/80 transition-all group">
                      <div className="relative w-12 h-12 rounded-lg overflow-hidden">
                        <Image
                          src={listing.image || "/placeholder.svg"}
                          alt={listing.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-medium truncate text-sm">{listing.name}</span>
                          <Badge className={`${getRarityColor(listing.rarity)} text-xs`}>{listing.rarity}</Badge>
                        </div>
                        <div className="text-sm" style={glowStyles.textOrange}>
                          {formatDoge(listing.price)} DOGE
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {formatUsd(listing.priceUsd)} · {timeAgo(listing.listedAt)}
                        </div>
                      </div>
                      <ExternalLink className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                    </div>
                  </Link>
                ))}
                <Link href="https://market.doginaldogs.com/" target="_blank">
                  <Button variant="outline" className="w-full mt-2 bg-transparent">
                    View All Listings
                    <ExternalLink className="h-4 w-4 ml-2" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Recent Sales */}
            <Card className="bg-card/50 border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <History className="h-5 w-5" />
                  Recent Sales
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {sales.map((sale) => (
                  <div key={sale.id} className="flex items-center gap-3 p-2 rounded-lg bg-background/50">
                    <div className="relative w-12 h-12 rounded-lg overflow-hidden">
                      <Image src={sale.image || "/placeholder.svg"} alt={sale.name} fill className="object-cover" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className="font-medium truncate text-sm block">{sale.name}</span>
                      <div className="text-sm text-green-400">{formatDoge(sale.price)} DOGE</div>
                      <div className="text-xs text-muted-foreground">
                        {formatUsd(sale.priceUsd)} · {timeAgo(sale.soldAt)}
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Quick Links */}
            <Card className="bg-card/50 border-border/50" style={glowStyles.orange}>
              <CardHeader>
                <CardTitle className="text-lg">Quick Links</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link href="https://market.doginaldogs.com/" target="_blank">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <Dog className="h-4 w-4 mr-2" />
                    Doginal Dogs Marketplace
                    <ExternalLink className="h-4 w-4 ml-auto" />
                  </Button>
                </Link>
                <Link href="https://www.doginaldogs.com/" target="_blank">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <Dog className="h-4 w-4 mr-2" />
                    Doginal Dogs Website
                    <ExternalLink className="h-4 w-4 ml-auto" />
                  </Button>
                </Link>
                <Link href="https://doge-labs.com/collectible/doginal-dogs" target="_blank">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <BarChart3 className="h-4 w-4 mr-2" />
                    Doge Labs Analytics
                    <ExternalLink className="h-4 w-4 ml-auto" />
                  </Button>
                </Link>
                <Link href="https://cryptospaces.net/" target="_blank">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <Rss className="h-4 w-4 mr-2" />
                    CryptoSpaces Network
                    <ExternalLink className="h-4 w-4 ml-auto" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
