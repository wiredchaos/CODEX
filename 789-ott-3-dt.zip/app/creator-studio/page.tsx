import { Navigation } from "@/components/navigation"
import { CreatorDashboard } from "@/components/creator-studio/creator-dashboard"
import { CreatorStats } from "@/components/creator-studio/creator-stats"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { UploadCenter } from "@/components/creator-studio/upload-center"
import { TokenManagement } from "@/components/creator-studio/token-management"
import { Analytics } from "@/components/creator-studio/analytics"
import { NFTMinting } from "@/components/creator-studio/nft-minting"
import { RoyaltyRouting } from "@/components/creator-studio/royalty-routing"
import { glowStyles } from "@/lib/styles"

export const metadata = {
  title: "Creator Studio - 789 Studios",
  description: "Blockchain-powered creator tools for Film3 content",
}

export default function CreatorStudioPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="pt-16">
        <div className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-16 z-40">
          <div className="container px-4 py-4">
            <h1 className="text-3xl font-bold" style={glowStyles.textOrange}>
              Creator Studio
            </h1>
            <p className="text-muted-foreground">Blockchain-powered content management for Film3</p>
          </div>
        </div>

        <div className="container px-4 py-8">
          <CreatorStats />

          <Tabs defaultValue="dashboard" className="mt-8">
            <TabsList className="grid w-full grid-cols-6 max-w-4xl">
              <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
              <TabsTrigger value="upload">Upload</TabsTrigger>
              <TabsTrigger value="tokens">Tokens</TabsTrigger>
              <TabsTrigger value="nft">Mint NFT</TabsTrigger>
              <TabsTrigger value="royalty">Royalty</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>

            <TabsContent value="dashboard" className="mt-6">
              <CreatorDashboard />
            </TabsContent>

            <TabsContent value="upload" className="mt-6">
              <UploadCenter />
            </TabsContent>

            <TabsContent value="tokens" className="mt-6">
              <TokenManagement />
            </TabsContent>

            <TabsContent value="nft" className="mt-6">
              <NFTMinting />
            </TabsContent>

            <TabsContent value="royalty" className="mt-6">
              <RoyaltyRouting />
            </TabsContent>

            <TabsContent value="analytics" className="mt-6">
              <Analytics />
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
