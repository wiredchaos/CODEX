import { EnvironmentRenderer } from "@/components/trinity/environment-mount"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "789 Studios Trinity Lobby | WIRED CHAOS",
  description: "Enter the 789 Studios cinematic environment via Trinity 3D Core",
}

export default function TrinityLobbyPage() {
  return (
    <main className="h-screen w-full bg-black">
      <EnvironmentRenderer
        patchId="789_STUDIOS_OTT"
        kind="lobby"
        onHotspotClick={(hotspotId) => {
          console.log("[v0] Trinity hotspot clicked:", hotspotId)
          // Hotspot navigation handled by Trinity Core
        }}
      />

      {/* Business realm navigation overlay */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-50">
        <div className="flex gap-4">
          <a
            href="/"
            className="px-6 py-3 rounded-lg bg-orange-500/20 border border-orange-500/50 text-orange-400 hover:bg-orange-500/30 transition-all"
          >
            Exit to OTT
          </a>
          <a
            href="/crew"
            className="px-6 py-3 rounded-lg bg-orange-500/20 border border-orange-500/50 text-orange-400 hover:bg-orange-500/30 transition-all"
          >
            789 CREW
          </a>
          <a
            href="/live"
            className="px-6 py-3 rounded-lg bg-orange-500/20 border border-orange-500/50 text-orange-400 hover:bg-orange-500/30 transition-all"
          >
            33.3 FM
          </a>
        </div>
      </div>
    </main>
  )
}
