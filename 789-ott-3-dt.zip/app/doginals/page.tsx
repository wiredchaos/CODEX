import type { DoginalDog } from "@/lib/types"
import { mockDoginalDogs, doginalDogsCollection } from "@/lib/mock-data"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ExternalLink, Twitter, Users, TrendingUp, Coins, Film, Star } from "lucide-react"
import Image from "next/image"
import { glowStyles } from "@/lib/styles"

function getRarityColor(rarity: DoginalDog["rarity"]) {
  switch (rarity) {
    case "Legendary":
      return "bg-yellow-500/20 text-yellow-400 border-yellow-500/50"
    case "Epic":
      return "bg-purple-500/20 text-purple-400 border-purple-500/50"
    case "Rare":
      return "bg-blue-500/20 text-blue-400 border-blue-500/50"
    case "Uncommon":
      return "bg-green-500/20 text-green-400 border-green-500/50"
    default:
      return "bg-gray-500/20 text-gray-400 border-gray-500/50"
  }
}

export default function DoginalsPage() {
  const partnerDogs = mockDoginalDogs.filter((dog) => dog.is789Partner)
  const totalRoyalties = partnerDogs.reduce((sum, dog) => sum + (dog.royaltyEarnings || 0), 0)

  return (
    <main className="min-h-screen bg-background pt-20 pb-12">
      <div className="container px-4 mx-auto">
        {/* Hero Section */}
        <section className="mb-12">
          <div className="relative rounded-3xl overflow-hidden p-8 md:p-12" style={glowStyles.yellow}>
            <div className="absolute inset-0 bg-gradient-to-br from-yellow-900/40 via-orange-900/30 to-black/80" />
            <div className="relative z-10">
              <Badge className="mb-4 bg-yellow-500/20 text-yellow-400 border-yellow-500/50">
                Official Partner Collection
              </Badge>
              <h1 className="text-4xl md:text-6xl font-bold mb-4" style={glowStyles.textYellow}>
                Doginal Dogs
              </h1>
              <p className="text-xl text-muted-foreground max-w-2xl mb-6">{doginalDogsCollection.description}</p>
              <div className="flex flex-wrap gap-4 mb-8">
                <a href={doginalDogsCollection.website} target="_blank" rel="noopener noreferrer">
                  <Button style={glowStyles.orange}>
                    <ExternalLink className="mr-2 h-4 w-4" />
                    Visit Website
                  </Button>
                </a>
                <a href={doginalDogsCollection.twitter} target="_blank" rel="noopener noreferrer">
                  <Button variant="outline">
                    <Twitter className="mr-2 h-4 w-4" />
                    Follow on X
                  </Button>
                </a>
                <a href={doginalDogsCollection.discord} target="_blank" rel="noopener noreferrer">
                  <Button variant="outline">Join Discord</Button>
                </a>
              </div>

              {/* Collection Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-black/40 rounded-xl p-4 backdrop-blur-sm border border-white/10">
                  <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
                    <Users className="h-4 w-4" />
                    Total Supply
                  </div>
                  <p className="text-2xl font-bold">{doginalDogsCollection.totalSupply.toLocaleString()}</p>
                </div>
                <div className="bg-black/40 rounded-xl p-4 backdrop-blur-sm border border-white/10">
                  <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
                    <Coins className="h-4 w-4" />
                    Floor Price
                  </div>
                  <p className="text-2xl font-bold">{doginalDogsCollection.floorPrice.toLocaleString()} DOGE</p>
                </div>
                <div className="bg-black/40 rounded-xl p-4 backdrop-blur-sm border border-white/10">
                  <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
                    <TrendingUp className="h-4 w-4" />
                    24h Volume
                  </div>
                  <p className="text-2xl font-bold">{doginalDogsCollection.volume24h.toLocaleString()} DOGE</p>
                </div>
                <div className="bg-black/40 rounded-xl p-4 backdrop-blur-sm border border-white/10">
                  <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
                    <Users className="h-4 w-4" />
                    Owners
                  </div>
                  <p className="text-2xl font-bold">{doginalDogsCollection.owners.toLocaleString()}</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 789 Studios Partnership Banner */}
        <section className="mb-12">
          <Card className="bg-gradient-to-r from-primary/10 via-orange-900/20 to-yellow-900/10 border-primary/30">
            <CardContent className="p-6 md:p-8">
              <div className="flex flex-col md:flex-row items-center justify-between gap-6">
                <div>
                  <h2 className="text-2xl font-bold mb-2" style={glowStyles.textOrange}>
                    789 Studios x Doginal Dogs
                  </h2>
                  <p className="text-muted-foreground max-w-xl">
                    Doginal Dogs NFT holders earn royalties from episode appearances in DD CARTOONS and other 789
                    Studios productions. Partner dogs receive revenue share and exclusive credits.
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-muted-foreground mb-1">Total Partner Royalties</p>
                  <p className="text-3xl font-bold text-primary">${totalRoyalties.toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Partner Dogs Grid */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">789 Studios Partner Dogs</h2>
            <Badge variant="outline" className="text-primary border-primary">
              {partnerDogs.length} Partners
            </Badge>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {partnerDogs.map((dog) => (
              <Card
                key={dog.id}
                className="group overflow-hidden bg-card/50 backdrop-blur-sm border-white/10 hover:border-primary/50 transition-all duration-300"
              >
                <div className="relative aspect-square overflow-hidden">
                  <Image
                    src={dog.image || "/placeholder.svg"}
                    alt={dog.name}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-3 left-3">
                    <Badge className={getRarityColor(dog.rarity)}>{dog.rarity}</Badge>
                  </div>
                  {dog.isListed && (
                    <div className="absolute top-3 right-3">
                      <Badge className="bg-green-500/20 text-green-400 border-green-500/50">
                        Listed: {dog.listPrice?.toLocaleString()} DOGE
                      </Badge>
                    </div>
                  )}
                </div>

                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-xl">{dog.name}</CardTitle>
                      {dog.ownerHandle && <p className="text-sm text-muted-foreground">{dog.ownerHandle}</p>}
                    </div>
                    {dog.studioRole && (
                      <Badge variant="outline" className="text-xs">
                        {dog.studioRole}
                      </Badge>
                    )}
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground line-clamp-2">{dog.description}</p>

                  {/* Attributes */}
                  <div className="flex flex-wrap gap-1">
                    {dog.attributes.slice(0, 3).map((attr) => (
                      <Badge key={attr.trait_type} variant="secondary" className="text-xs">
                        {attr.trait_type}: {attr.value}
                      </Badge>
                    ))}
                  </div>

                  {/* Stats */}
                  <div className="grid grid-cols-2 gap-4 pt-2 border-t border-white/10">
                    {dog.episodeAppearances && dog.episodeAppearances.length > 0 && (
                      <div className="flex items-center gap-2">
                        <Film className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">
                          {dog.episodeAppearances.length} Episode{dog.episodeAppearances.length > 1 ? "s" : ""}
                        </span>
                      </div>
                    )}
                    {dog.royaltyEarnings && (
                      <div className="flex items-center gap-2">
                        <Star className="h-4 w-4 text-yellow-500" />
                        <span className="text-sm">${dog.royaltyEarnings.toLocaleString()} earned</span>
                      </div>
                    )}
                  </div>

                  {/* Social Links */}
                  {dog.socialLinks?.twitter && (
                    <a
                      href={dog.socialLinks.twitter}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-sm text-primary hover:underline"
                    >
                      <Twitter className="h-4 w-4" />
                      View on X
                    </a>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* How It Works */}
        <section className="mt-16">
          <h2 className="text-2xl font-bold mb-6 text-center">How Doginal Dogs Earn with 789 Studios</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="bg-card/50 backdrop-blur-sm border-white/10 text-center p-6">
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-primary">1</span>
              </div>
              <h3 className="font-semibold mb-2">Hold a Doginal Dog</h3>
              <p className="text-sm text-muted-foreground">
                Own one of the 10,000 pixel dogs inscribed on the Dogecoin blockchain.
              </p>
            </Card>
            <Card className="bg-card/50 backdrop-blur-sm border-white/10 text-center p-6">
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-primary">2</span>
              </div>
              <h3 className="font-semibold mb-2">License for Episodes</h3>
              <p className="text-sm text-muted-foreground">
                Grant permission for your Doginal Dog to appear in DD CARTOONS episodes and earn IP royalties.
              </p>
            </Card>
            <Card className="bg-card/50 backdrop-blur-sm border-white/10 text-center p-6">
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-primary">3</span>
              </div>
              <h3 className="font-semibold mb-2">Earn Revenue Share</h3>
              <p className="text-sm text-muted-foreground">
                Receive 20% of episode revenue through the 789 Studios royalty engine whenever your dog appears.
              </p>
            </Card>
          </div>
        </section>
      </div>
    </main>
  )
}
