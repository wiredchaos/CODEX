import { NextResponse } from "next/server"
import { mockVideos, mockCreators } from "@/lib/mock-data"

export async function GET() {
  const baseUrl = "https://789studios.tv"

  const staticPages = [
    { url: baseUrl, lastmod: new Date().toISOString(), priority: 1.0 },
    { url: `${baseUrl}/watch`, lastmod: new Date().toISOString(), priority: 0.9 },
    { url: `${baseUrl}/creator-studio`, lastmod: new Date().toISOString(), priority: 0.8 },
    { url: `${baseUrl}/affiliates`, lastmod: new Date().toISOString(), priority: 0.8 },
    { url: `${baseUrl}/chaincast`, lastmod: new Date().toISOString(), priority: 0.8 },
    { url: `${baseUrl}/smart-tv`, lastmod: new Date().toISOString(), priority: 0.7 },
  ]

  const videoPages = mockVideos.map((video) => ({
    url: `${baseUrl}/watch/${video.id}`,
    lastmod: video.updatedAt.toISOString(),
    priority: 0.9,
    changefreq: "weekly",
    video: {
      title: video.title,
      description: video.description,
      thumbnail: video.thumbnail,
      duration: video.duration,
      category: video.category,
    },
  }))

  const creatorPages = mockCreators.map((creator) => ({
    url: `${baseUrl}/creator/${creator.id}`,
    lastmod: new Date().toISOString(),
    priority: 0.7,
  }))

  const sitemap = [...staticPages, ...videoPages, ...creatorPages]

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:video="http://www.google.com/schemas/sitemap-video/1.1"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
${sitemap
  .map(
    (page) => `  <url>
    <loc>${page.url}</loc>
    <lastmod>${page.lastmod}</lastmod>
    <changefreq>${(page as any).changefreq || "weekly"}</changefreq>
    <priority>${page.priority}</priority>${
      (page as any).video
        ? `
    <video:video>
      <video:title>${(page as any).video.title}</video:title>
      <video:description>${(page as any).video.description}</video:description>
      <video:thumbnail_loc>${(page as any).video.thumbnail}</video:thumbnail_loc>
      <video:duration>${(page as any).video.duration}</video:duration>
      <video:category>${(page as any).video.category}</video:category>
    </video:video>`
        : ""
    }
  </url>`,
  )
  .join("\n")}
</urlset>`

  return new NextResponse(xml, {
    headers: {
      "Content-Type": "application/xml",
      "Cache-Control": "public, s-maxage=3600, stale-while-revalidate=7200",
    },
  })
}
