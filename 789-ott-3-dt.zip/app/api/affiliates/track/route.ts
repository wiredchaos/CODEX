import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { affiliateCode, eventType, videoId, userId } = body

    if (!affiliateCode || !eventType) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    console.log("[v0] Tracking affiliate event:", eventType)
    console.log("[v0] Affiliate code:", affiliateCode)
    console.log("[v0] Video ID:", videoId)
    console.log("[v0] User ID:", userId)

    // Calculate earnings based on event type
    let earnings = 0
    switch (eventType) {
      case "watch":
        earnings = 0.001
        break
      case "referral":
        earnings = 0.01
        break
      case "creator_signup":
        earnings = 0.05
        break
      case "sponsored_content":
        earnings = 0.5
        break
    }

    return NextResponse.json({
      success: true,
      data: {
        affiliateCode,
        eventType,
        earnings,
        timestamp: new Date().toISOString(),
      },
      message: "Event tracked successfully",
    })
  } catch (error) {
    console.error("[v0] Error tracking affiliate event:", error)
    return NextResponse.json({ error: "Failed to track event" }, { status: 500 })
  }
}
