import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { title, description, category, tags, videoFile, isTokenGated, blockchain, tokenAddress } = body

    if (!title || !description || !category) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    console.log("[v0] Processing video upload:", title)
    console.log("[v0] Token-gated:", isTokenGated)
    if (isTokenGated) {
      console.log("[v0] Blockchain:", blockchain)
      console.log("[v0] Token address:", tokenAddress)
    }

    // Simulate upload processing
    await new Promise((resolve) => setTimeout(resolve, 2000))

    const videoId = `video-${Date.now()}`

    return NextResponse.json({
      success: true,
      data: {
        videoId,
        title,
        uploadedAt: new Date().toISOString(),
        status: "processing",
      },
      message: "Video uploaded successfully",
    })
  } catch (error) {
    console.error("[v0] Error uploading video:", error)
    return NextResponse.json({ error: "Failed to upload video" }, { status: 500 })
  }
}
