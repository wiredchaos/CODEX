import { type NextRequest, NextResponse } from "next/server"
import { mintEpisodeNFT, type BlockchainNetwork } from "@/lib/blockchain-utils"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { videoId, blockchain, nftName, supply, royaltyPercentage, creatorWallet } = body

    if (!videoId || !blockchain || !nftName || !supply || !creatorWallet) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    console.log("[v0] Minting NFT for video:", videoId)

    const metadata = {
      name: nftName,
      description: `Exclusive NFT collectible for ${nftName}`,
      image: `https://789studios.tv/thumbnails/${videoId}.jpg`,
      attributes: [
        { trait_type: "Platform", value: "789 Studios" },
        { trait_type: "Type", value: "Episode NFT" },
        { trait_type: "Royalty", value: royaltyPercentage },
      ],
    }

    const result = await mintEpisodeNFT(blockchain as BlockchainNetwork, videoId, metadata, creatorWallet)

    return NextResponse.json({
      success: true,
      data: {
        tokenId: result.tokenId,
        transactionHash: result.transactionHash,
        blockchain,
        supply,
      },
      message: "NFT minted successfully",
    })
  } catch (error) {
    console.error("[v0] Error minting NFT:", error)
    return NextResponse.json({ error: "Failed to mint NFT" }, { status: 500 })
  }
}
