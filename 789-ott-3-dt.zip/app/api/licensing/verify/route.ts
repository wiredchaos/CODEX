import { type NextRequest, NextResponse } from "next/server"
import { contractInterface } from "@/lib/blockchain/contract-interface"
import { mockIPLicenses } from "@/lib/mock-data"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const ipId = searchParams.get("ipId")

    if (!ipId) {
      return NextResponse.json({ error: "Missing ipId parameter" }, { status: 400 })
    }

    // Try on-chain verification first
    let license = null
    let source = "mock"

    try {
      license = await contractInterface.getIPLicense(ipId)
      if (license) {
        source = "blockchain"
      }
    } catch (error) {
      console.log("[v0] Blockchain verification unavailable, using mock data")
    }

    // Fallback to mock data
    if (!license) {
      license = mockIPLicenses.find((l) => l.ipId === ipId)
      source = "mock"
    }

    if (!license) {
      return NextResponse.json({ error: "License not found" }, { status: 404 })
    }

    return NextResponse.json({
      license,
      source,
      verified: source === "blockchain",
      timestamp: new Date().toISOString(),
    })
  } catch (error: any) {
    console.error("[v0] License verification error:", error)
    return NextResponse.json({ error: error.message || "Failed to verify license" }, { status: 500 })
  }
}
