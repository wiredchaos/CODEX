import { type NextRequest, NextResponse } from "next/server"
import { mockVideos, mockCreators } from "@/lib/mock-data"
import { generateAEOMetadata } from "@/lib/aeo-metadata"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const video = mockVideos.find((v) => v.id === params.id)

    if (!video) {
      return NextResponse.json({ error: "Video not found" }, { status: 404 })
    }

    const creator = mockCreators.find((c) => c.id === video.creatorId)
    const aeoMetadata = generateAEOMetadata(video, creator)

    return NextResponse.json({
      success: true,
      data: aeoMetadata,
    })
  } catch (error) {
    console.error("[v0] Error generating AEO metadata:", error)
    return NextResponse.json({ error: "Failed to generate AEO metadata" }, { status: 500 })
  }
}
