import { NextResponse } from "next/server"

export async function GET() {
  const manifest = {
    name: "789 Studios OTT",
    short_name: "789 Studios",
    description: "Film3 streaming platform with blockchain-powered content",
    version: "1.0.0",
    author: "789 Studios",
    homepage: "https://789studios.tv",
    icon: "/icon.svg",
    platforms: {
      roku: {
        feedUrl: "https://789studios.tv/api/roku/feed",
        channelId: "789studios",
        supported: true,
      },
      amazonFireTV: {
        appId: "com.789studios.ottapp",
        supported: true,
      },
      appleTv: {
        bundleId: "com.789studios.ottapp",
        supported: true,
      },
      androidTv: {
        packageName: "com.studios789.ott",
        supported: true,
      },
      samsungTv: {
        appId: "789studios",
        supported: true,
      },
      lgTv: {
        appId: "789studios",
        supported: true,
      },
    },
    categories: ["Entertainment", "Technology", "Documentary", "Animation"],
    contentRating: "TV-14",
    features: [
      "4K Support",
      "Closed Captions",
      "Multi-language",
      "Crypto Payments",
      "NFT Integration",
      "Token-gated Content",
    ],
    navigation: {
      remoteControl: true,
      voiceControl: true,
      gestureControl: false,
    },
  }

  return NextResponse.json(manifest, {
    headers: {
      "Content-Type": "application/json",
    },
  })
}
