import { NextResponse } from "next/server"
import { mockVideos } from "@/lib/mock-data"

export async function GET() {
  const now = new Date()
  const epg = {
    channel: {
      id: "789-studios-main",
      name: "789 Studios",
      logo: "https://789studios.tv/icon.svg",
    },
    programs: mockVideos.map((video, index) => {
      const startTime = new Date(now.getTime() + index * 3600000) // Hourly slots
      const endTime = new Date(startTime.getTime() + video.duration * 1000)

      return {
        id: video.id,
        title: video.title,
        description: video.description,
        startTime: startTime.toISOString(),
        endTime: endTime.toISOString(),
        duration: video.duration,
        category: video.category,
        thumbnail: video.thumbnail,
        isLive: false,
        isTokenGated: video.isTokenGated,
      }
    }),
  }

  return NextResponse.json(epg, {
    headers: {
      "Content-Type": "application/json",
      "Cache-Control": "public, s-maxage=300, stale-while-revalidate=600",
    },
  })
}
