import { NextResponse } from "next/server"
import { getEpisodeRoyaltyHybrid } from "@/lib/royalty-service-hybrid"
import { getEpisodeRoyaltyOffChain } from "@/lib/royalty-service"

const MODE = process.env.ROYALTY_MODE || "hybrid" // "offchain" | "hybrid"

export async function GET(req: Request, { params }: { params: { episodeId: string } }) {
  try {
    const { episodeId } = params

    // Choose service based on environment configuration
    const data =
      MODE === "offchain" ? await getEpisodeRoyaltyOffChain(episodeId) : await getEpisodeRoyaltyHybrid(episodeId)

    return NextResponse.json(data)
  } catch (error) {
    console.error("[v0] Error fetching royalty data:", error)
    return NextResponse.json({ error: "Failed to fetch royalty data" }, { status: 500 })
  }
}
