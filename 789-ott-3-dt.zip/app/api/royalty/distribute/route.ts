import { type NextRequest, NextResponse } from "next/server"
import { contractInterface } from "@/lib/blockchain/contract-interface"
import { calculateRoyaltySplit } from "@/lib/royalty-engine"

export async function POST(request: NextRequest) {
  try {
    const { contentId, amount, walletAddress } = await request.json()

    if (!contentId || !amount) {
      return NextResponse.json({ error: "Missing required fields: contentId, amount" }, { status: 400 })
    }

    // Calculate distribution
    const distribution = calculateRoyaltySplit(Number.parseFloat(amount))

    // Try on-chain distribution if wallet connected
    let txHash = null
    let onChainVerified = false

    if (walletAddress) {
      try {
        txHash = await contractInterface.distributeRevenue(contentId, amount)
        onChainVerified = true
      } catch (error) {
        console.error("[v0] On-chain distribution failed, using off-chain:", error)
      }
    }

    // Return distribution data (hybrid: off-chain calculation, on-chain verification)
    return NextResponse.json({
      success: true,
      contentId,
      distribution: {
        ...distribution,
        totalAmount: amount,
        onChainVerified,
        txHash,
        timestamp: new Date().toISOString(),
      },
    })
  } catch (error: any) {
    console.error("[v0] Revenue distribution error:", error)
    return NextResponse.json({ error: error.message || "Failed to distribute revenue" }, { status: 500 })
  }
}
