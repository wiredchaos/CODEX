import { type NextRequest, NextResponse } from "next/server"
import { contractInterface } from "@/lib/blockchain/contract-interface"

export async function POST(request: NextRequest) {
  try {
    const { walletAddress } = await request.json()

    if (!walletAddress) {
      return NextResponse.json({ error: "Wallet address required" }, { status: 400 })
    }

    // Try on-chain claim
    try {
      const txHash = await contractInterface.claimRoyalties()

      return NextResponse.json({
        success: true,
        txHash,
        message: "Royalties claimed successfully",
        timestamp: new Date().toISOString(),
      })
    } catch (error: any) {
      // Fallback to off-chain processing
      console.error("[v0] On-chain claim failed:", error)

      return NextResponse.json(
        {
          success: false,
          error: "On-chain claim failed. Please ensure contracts are deployed.",
          fallbackMode: true,
        },
        { status: 500 },
      )
    }
  } catch (error: any) {
    console.error("[v0] Claim royalties error:", error)
    return NextResponse.json({ error: error.message || "Failed to claim royalties" }, { status: 500 })
  }
}
