import { NextResponse } from "next/server"
import { getEpisodesRoyaltyBatch } from "@/lib/royalty-service-hybrid"

export async function POST(req: Request) {
  try {
    const { episodeIds } = await req.json()

    if (!Array.isArray(episodeIds)) {
      return NextResponse.json({ error: "episodeIds must be an array" }, { status: 400 })
    }

    const resultsMap = await getEpisodesRoyaltyBatch(episodeIds)

    // Convert Map to object for JSON serialization
    const results = Object.fromEntries(resultsMap)

    return NextResponse.json(results)
  } catch (error) {
    console.error("[v0] Error fetching batch royalty data:", error)
    return NextResponse.json({ error: "Failed to fetch batch royalty data" }, { status: 500 })
  }
}
