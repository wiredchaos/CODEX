import { type NextRequest, NextResponse } from "next/server"
import { deployCreatorToken, type BlockchainNetwork } from "@/lib/blockchain-utils"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()
    const { tokenName, tokenSymbol, totalSupply, network, creatorWallet } = body

    if (!tokenName || !tokenSymbol || !totalSupply || !network || !creatorWallet) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const deployment = await deployCreatorToken(
      network as BlockchainNetwork,
      tokenName,
      tokenSymbol,
      totalSupply,
      creatorWallet,
    )

    return NextResponse.json({
      success: true,
      data: deployment,
      message: "Creator token deployed successfully",
    })
  } catch (error) {
    console.error("[v0] Error deploying creator token:", error)
    return NextResponse.json({ error: "Failed to deploy token" }, { status: 500 })
  }
}
