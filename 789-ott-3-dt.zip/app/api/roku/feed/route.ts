import { NextResponse } from "next/server"
import { mockVideos, mockCreators } from "@/lib/mock-data"

export async function GET() {
  const rokuFeed = {
    providerName: "789 Studios OTT",
    language: "en-US",
    lastUpdated: new Date().toISOString(),
    categories: [
      {
        name: "Featured Films",
        query: "Featured Films",
        order: "manual",
      },
      {
        name: "Web3 Specials",
        query: "Web3 Specials",
        order: "manual",
      },
      {
        name: "Documentary Vault",
        query: "Documentary Vault",
        order: "manual",
      },
      {
        name: "Doginal Dogs Originals",
        query: "Doginal Dogs Originals",
        order: "manual",
      },
      {
        name: "WIRED CHAOS META",
        query: "WIRED CHAOS META",
        order: "manual",
      },
    ],
    movies: mockVideos
      .filter((v) => !v.episodeNumber)
      .map((video) => {
        const creator = mockCreators.find((c) => c.id === video.creatorId)
        return {
          id: video.id,
          title: video.title,
          content: {
            dateAdded: video.createdAt.toISOString(),
            videos: [
              {
                url: video.videoUrl,
                quality: "HD",
                videoType: "MP4",
              },
            ],
            duration: video.duration,
            language: "en-US",
            captions: [],
          },
          thumbnail: video.thumbnail,
          shortDescription: video.description.substring(0, 200),
          longDescription: video.description,
          tags: video.tags,
          genres: [video.category],
          releaseDate: video.createdAt.toISOString().split("T")[0],
          credits: creator
            ? [
                {
                  name: creator.name,
                  role: "director",
                  birthDate: "",
                },
              ]
            : [],
          rating: {
            rating: "UNRATED",
            ratingSource: "DEFAULT",
          },
        }
      }),
    series: [],
    shortFormVideos: mockVideos
      .filter((v) => v.episodeNumber)
      .map((video) => {
        const creator = mockCreators.find((c) => c.id === video.creatorId)
        return {
          id: video.id,
          title: video.title,
          content: {
            dateAdded: video.createdAt.toISOString(),
            videos: [
              {
                url: video.videoUrl,
                quality: "HD",
                videoType: "MP4",
              },
            ],
            duration: video.duration,
            language: "en-US",
          },
          thumbnail: video.thumbnail,
          shortDescription: video.description.substring(0, 200),
          longDescription: video.description,
          tags: video.tags,
          genres: [video.category],
          releaseDate: video.createdAt.toISOString().split("T")[0],
          credits: creator
            ? [
                {
                  name: creator.name,
                  role: "creator",
                },
              ]
            : [],
        }
      }),
  }

  return NextResponse.json(rokuFeed, {
    headers: {
      "Content-Type": "application/json",
      "Cache-Control": "public, s-maxage=3600, stale-while-revalidate=7200",
    },
  })
}
