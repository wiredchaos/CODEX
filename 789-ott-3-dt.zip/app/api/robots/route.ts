import { NextResponse } from "next/server"

export async function GET() {
  const robotsTxt = `# 789 Studios OTT - Robots.txt
User-agent: *
Allow: /
Allow: /watch/
Allow: /creator-studio
Allow: /affiliates
Allow: /chaincast
Allow: /smart-tv

# Sitemap location
Sitemap: https://789studios.tv/api/sitemap

# Crawl delay for rate limiting
Crawl-delay: 1

# Block admin and private areas
Disallow: /api/admin/
Disallow: /api/private/

# Allow video thumbnails and images
User-agent: Googlebot-Image
Allow: /public/
Allow: /*.jpg
Allow: /*.png
Allow: /*.svg

# Special rules for video bots
User-agent: Googlebot-Video
Allow: /watch/
Allow: /api/roku/feed

# Allow AI search bots for AEO
User-agent: GPTBot
Allow: /
Allow: /api/videos/*/aeo

User-agent: ChatGPT-User
Allow: /

User-agent: CCBot
Allow: /

# Block scrapers
User-agent: MJ12bot
Disallow: /

User-agent: AhrefsBot
Disallow: /
`

  return new NextResponse(robotsTxt, {
    headers: {
      "Content-Type": "text/plain",
    },
  })
}
