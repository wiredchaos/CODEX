"use client"

import { Navigation } from "@/components/navigation"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { mockVideos } from "@/lib/mock-data"
import { Play, Tv } from "lucide-react"
import Link from "next/link"
import { useState, useEffect } from "react"
import { glowStyles } from "@/lib/styles"

export default function SmartTVPage() {
  const [selectedIndex, setSelectedIndex] = useState(0)
  const [selectedCategory, setSelectedCategory] = useState(0)

  const categories = ["Featured", "Trending", "Web3 Specials", "Documentaries"]

  // Keyboard navigation for Smart TV remotes
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      switch (e.key) {
        case "ArrowRight":
          setSelectedIndex((prev) => Math.min(prev + 1, mockVideos.length - 1))
          break
        case "ArrowLeft":
          setSelectedIndex((prev) => Math.max(prev - 1, 0))
          break
        case "ArrowUp":
          setSelectedCategory((prev) => Math.max(prev - 1, 0))
          break
        case "ArrowDown":
          setSelectedCategory((prev) => Math.min(prev + 1, categories.length - 1))
          break
        case "Enter":
          // Navigate to video
          window.location.href = `/watch/${mockVideos[selectedIndex].id}`
          break
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [selectedIndex, selectedCategory])

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="pt-16">
        <div className="bg-gradient-to-r from-primary/20 to-secondary/20 border-b border-primary/30">
          <div className="container px-4 py-8">
            <div className="flex items-center gap-3">
              <Tv className="h-8 w-8 text-primary" />
              <h1 className="text-3xl font-bold" style={glowStyles.textOrange}>
                Smart TV Experience
              </h1>
              <Badge>ROKU Compatible</Badge>
            </div>
            <p className="text-muted-foreground mt-2">Navigate with arrow keys • Select with Enter</p>
          </div>
        </div>

        <div className="container px-4 py-8">
          {/* Categories Navigation */}
          <div className="flex gap-4 mb-8 overflow-x-auto pb-4">
            {categories.map((category, idx) => (
              <Button
                key={category}
                variant={selectedCategory === idx ? "default" : "outline"}
                size="lg"
                className={`text-lg min-w-[200px] ${selectedCategory === idx ? "ring-2 ring-primary" : ""}`}
                style={selectedCategory === idx ? glowStyles.orange : undefined}
                onClick={() => setSelectedCategory(idx)}
              >
                {category}
              </Button>
            ))}
          </div>

          {/* Featured Hero */}
          <Card className="relative overflow-hidden mb-8 border-primary/30">
            <div className="aspect-video relative">
              <img
                src={mockVideos[selectedIndex].thumbnail || "/placeholder.svg"}
                alt={mockVideos[selectedIndex].title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
              <div className="absolute bottom-0 left-0 p-8 space-y-4">
                <Badge className="text-lg px-4 py-1">FEATURED</Badge>
                <h2 className="text-4xl font-bold max-w-2xl" style={glowStyles.textOrange}>
                  {mockVideos[selectedIndex].title}
                </h2>
                <p className="text-lg text-muted-foreground max-w-xl">{mockVideos[selectedIndex].description}</p>
                <div className="flex gap-4">
                  <Link href={`/watch/${mockVideos[selectedIndex].id}`}>
                    <Button size="lg" className="text-xl px-8 py-6" style={glowStyles.yellow}>
                      <Play className="h-6 w-6 mr-3" />
                      Play Now
                    </Button>
                  </Link>
                  <Button size="lg" variant="outline" className="text-xl px-8 py-6 bg-transparent">
                    More Info
                  </Button>
                </div>
              </div>
            </div>
          </Card>

          {/* Video Grid - Large clickable targets */}
          <div className="grid gap-6 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            {mockVideos.slice(0, 9).map((video, idx) => (
              <Link key={video.id} href={`/watch/${video.id}`}>
                <Card
                  className={`group cursor-pointer transition-all hover:scale-105 ${
                    selectedIndex === idx ? "ring-4 ring-primary" : "hover:border-primary/50"
                  }`}
                  style={selectedIndex === idx ? glowStyles.orange : undefined}
                >
                  <div className="aspect-video relative overflow-hidden rounded-t-lg">
                    <img
                      src={video.thumbnail || "/placeholder.svg"}
                      alt={video.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center">
                      <Play className="h-16 w-16 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="font-bold text-xl mb-2 line-clamp-2">{video.title}</h3>
                    <p className="text-muted-foreground text-sm line-clamp-2">{video.description}</p>
                    <div className="flex items-center gap-3 mt-4">
                      <Badge variant="secondary">{video.category}</Badge>
                      <span className="text-sm text-muted-foreground">{video.views.toLocaleString()} views</span>
                    </div>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
