import { Navigation } from "@/components/navigation"
import { AffiliateDashboard } from "@/components/affiliates/affiliate-dashboard"
import { AffiliateStats } from "@/components/affiliates/affiliate-stats"
import { AffiliateLinks } from "@/components/affiliates/affiliate-links"
import { PayoutHistory } from "@/components/affiliates/payout-history"
import { KYCVerification } from "@/components/affiliates/kyc-verification"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { glowStyles } from "@/lib/styles"

export const metadata = {
  title: "Affiliate Program - 789 Studios OTT",
  description: "Earn crypto rewards by promoting Film3 content and recruiting creators to 789 Studios",
}

export default function AffiliatesPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="pt-16">
        <div className="bg-gradient-to-r from-primary/20 to-secondary/20 border-b border-primary/30">
          <div className="container px-4 py-12">
            <h1 className="text-4xl font-bold mb-4" style={glowStyles.textOrange}>
              Affiliate Partner Program
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl">
              Earn crypto rewards for every watch, referral, and creator signup. Join the Film3 revolution and monetize
              your audience with blockchain-powered affiliate tracking.
            </p>
          </div>
        </div>

        <div className="container px-4 py-8">
          <AffiliateStats />

          <Tabs defaultValue="dashboard" className="mt-8">
            <TabsList className="grid w-full grid-cols-4 max-w-2xl">
              <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
              <TabsTrigger value="links">Links</TabsTrigger>
              <TabsTrigger value="payouts">Payouts</TabsTrigger>
              <TabsTrigger value="kyc">KYC</TabsTrigger>
            </TabsList>

            <TabsContent value="dashboard" className="mt-6">
              <div className="grid gap-8 lg:grid-cols-3">
                <div className="lg:col-span-2">
                  <AffiliateDashboard />
                </div>
                <div>
                  <Card className="p-6 bg-card border-primary/20">
                    <h3 className="font-bold text-lg mb-3" style={glowStyles.textYellow}>
                      Tier System
                    </h3>
                    <div className="space-y-4 text-sm">
                      <div>
                        <div className="font-semibold text-primary">Tier A - Audience Affiliates</div>
                        <ul className="text-muted-foreground mt-1 space-y-1 ml-4">
                          <li>• Earn per watch (0.001 ETH)</li>
                          <li>• Earn per referral (0.01 ETH)</li>
                          <li>• Earn per creator signup (0.05 ETH)</li>
                        </ul>
                      </div>
                      <div>
                        <div className="font-semibold text-secondary">Tier B - Creator Affiliates</div>
                        <ul className="text-muted-foreground mt-1 space-y-1 ml-4">
                          <li>• Earn from sponsored content (5%)</li>
                          <li>• Earn from premium distribution (10%)</li>
                          <li>• Earn when recruits publish (2%)</li>
                        </ul>
                      </div>
                    </div>
                    <Button className="w-full mt-4" style={glowStyles.yellow}>
                      Upgrade to Tier B
                    </Button>
                  </Card>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="links" className="mt-6">
              <AffiliateLinks />
            </TabsContent>

            <TabsContent value="payouts" className="mt-6">
              <PayoutHistory />
            </TabsContent>

            <TabsContent value="kyc" className="mt-6">
              <KYCVerification />
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
