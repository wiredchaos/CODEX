import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Navigation } from "@/components/navigation"
import { Home } from "lucide-react"
import { glowStyles } from "@/lib/styles"

export default function NotFound() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="pt-16 flex items-center justify-center min-h-[calc(100vh-4rem)]">
        <div className="container px-4 text-center">
          <h1 className="text-6xl font-bold mb-4" style={glowStyles.textOrange}>
            404
          </h1>
          <h2 className="text-2xl font-semibold mb-4">Video Not Found</h2>
          <p className="text-muted-foreground mb-8 max-w-md mx-auto">
            The video you're looking for doesn't exist or has been removed from 789 Studios.
          </p>
          <Link href="/">
            <Button style={glowStyles.yellow}>
              <Home className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
        </div>
      </main>
    </div>
  )
}
