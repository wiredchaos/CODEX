import { Navigation } from "@/components/navigation"
import { VideoCard } from "@/components/video-card"
import { mockVideos, categories } from "@/lib/mock-data"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, Filter } from "lucide-react"
import { glowStyles } from "@/lib/styles"

export const metadata = {
  title: "Watch - 789 Studios OTT",
  description: "Browse all Film3 content on 789 Studios streaming platform",
}

export default function BrowsePage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="pt-16">
        <div className="container px-4 py-8">
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2" style={glowStyles.textOrange}>
              Watch
            </h1>
            <p className="text-muted-foreground">Explore all Film3 content</p>
          </div>

          <div className="flex gap-4 mb-8">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search videos..." className="pl-10" />
            </div>
            <Button variant="outline">
              <Filter className="mr-2 h-4 w-4" />
              Filter
            </Button>
          </div>

          <div className="mb-6">
            <div className="flex gap-2 overflow-x-auto pb-2">
              <Button variant="default" size="sm" style={glowStyles.orange}>
                All
              </Button>
              {categories.map((category) => (
                <Button key={category} variant="outline" size="sm">
                  {category}
                </Button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {mockVideos.map((video) => (
              <VideoCard key={video.id} video={video} />
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
