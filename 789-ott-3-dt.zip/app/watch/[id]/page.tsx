import { Navigation } from "@/components/navigation"
import { VideoPlayer } from "@/components/video-player"
import { VideoCard } from "@/components/video-card"
import { mockVideos, mockCreators } from "@/lib/mock-data"
import { notFound } from "next/navigation"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Eye, Heart, Share2, ThumbsUp, Lock } from "lucide-react"
import { glowStyles } from "@/lib/styles"

export async function generateMetadata({ params }: { params: { id: string } }) {
  const video = mockVideos.find((v) => v.id === params.id)

  if (!video) {
    return {
      title: "Video Not Found - 789 Studios",
    }
  }

  const creator = mockCreators.find((c) => c.id === video.creatorId)

  return {
    title: `${video.title} - 789 Studios OTT`,
    description: video.description,
    keywords: [...video.tags, "Film3", "Web3", "Streaming", video.category],
    openGraph: {
      title: video.title,
      description: video.description,
      images: [video.thumbnail],
      type: "video.other",
    },
    twitter: {
      card: "player",
      title: video.title,
      description: video.description,
      images: [video.thumbnail],
    },
    other: {
      "video:duration": video.duration.toString(),
      "video:release_date": video.createdAt.toISOString(),
      creator: creator?.name || "789 Studios",
    },
  }
}

export default function WatchPage({ params }: { params: { id: string } }) {
  const video = mockVideos.find((v) => v.id === params.id)

  if (!video) {
    notFound()
  }

  const creator = mockCreators.find((c) => c.id === video.creatorId)
  const relatedVideos = mockVideos.filter((v) => v.id !== video.id && v.category === video.category).slice(0, 6)

  const videoSchema = {
    "@context": "https://schema.org",
    "@type": "VideoObject",
    name: video.title,
    description: video.description,
    thumbnailUrl: video.thumbnail,
    uploadDate: video.createdAt.toISOString(),
    duration: `PT${video.duration}S`,
    contentUrl: video.videoUrl,
    embedUrl: `https://789studios.tv/watch/${video.id}`,
    interactionStatistic: {
      "@type": "InteractionCounter",
      interactionType: { "@type": "WatchAction" },
      userInteractionCount: video.views,
    },
    creator: creator
      ? {
          "@type": "Person",
          name: creator.name,
          url: creator.socialLinks?.website,
        }
      : undefined,
  }

  return (
    <div className="min-h-screen bg-background">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(videoSchema) }} />

      <Navigation />

      <main className="pt-16">
        <div className="bg-black">
          <div className="container px-4 py-8">
            <VideoPlayer video={video} />
          </div>
        </div>

        <div className="container px-4 py-8">
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <div>
                <div className="flex items-start gap-3 mb-4">
                  <Badge className="bg-primary/90 backdrop-blur-sm">{video.category}</Badge>
                  {video.isTokenGated && (
                    <Badge variant="secondary" style={glowStyles.yellow}>
                      <Lock className="mr-1 h-3 w-3" />
                      Token Gated
                    </Badge>
                  )}
                </div>

                <h1 className="text-3xl font-bold mb-3 text-balance" style={glowStyles.textOrange}>
                  {video.title}
                </h1>

                <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center gap-1">
                    <Eye className="h-4 w-4" />
                    <span>{video.views.toLocaleString()} views</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Heart className="h-4 w-4" />
                    <span>{video.likes.toLocaleString()} likes</span>
                  </div>
                  <span>
                    {new Date(video.createdAt).toLocaleDateString("en-US", {
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </span>
                </div>

                <div className="flex gap-2">
                  <Button size="sm" style={glowStyles.orange}>
                    <ThumbsUp className="mr-2 h-4 w-4" />
                    Like
                  </Button>
                  <Button size="sm" variant="outline">
                    <Share2 className="mr-2 h-4 w-4" />
                    Share
                  </Button>
                </div>
              </div>

              {creator && (
                <div className="bg-card border border-border rounded-lg p-6">
                  <div className="flex items-start gap-4">
                    <Avatar className="h-16 w-16 border-2 border-primary" style={glowStyles.orange}>
                      <AvatarImage src={creator.avatar || "/placeholder.svg"} alt={creator.name} />
                      <AvatarFallback>{creator.name[0]}</AvatarFallback>
                    </Avatar>

                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-lg">{creator.name}</h3>
                        {creator.isVerified && (
                          <Badge variant="secondary" className="text-xs">
                            Verified
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">
                        {creator.subscriberCount.toLocaleString()} subscribers
                      </p>
                      <p className="text-sm text-muted-foreground">{creator.bio}</p>
                    </div>

                    <Button style={glowStyles.yellow}>Subscribe</Button>
                  </div>
                </div>
              )}

              <div className="bg-card border border-border rounded-lg p-6">
                <h2 className="font-semibold text-xl mb-3">About This Video</h2>
                <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap text-pretty">
                  {video.description}
                </p>

                {video.tags && video.tags.length > 0 && (
                  <div className="mt-4 pt-4 border-t border-border">
                    <div className="flex flex-wrap gap-2">
                      {video.tags.map((tag) => (
                        <Badge key={tag} variant="outline">
                          #{tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-4">
              <h2 className="font-semibold text-xl">Related Videos</h2>
              {relatedVideos.map((relatedVideo) => (
                <VideoCard key={relatedVideo.id} video={relatedVideo} />
              ))}

              {relatedVideos.length === 0 && (
                <p className="text-muted-foreground text-center py-8">No related videos found</p>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
