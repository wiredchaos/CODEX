import type { Metadata } from "next"
import { mockCreators } from "@/lib/mock-data"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Navigation } from "@/components/navigation"
import { glowStyles } from "@/lib/styles"
import { Twitter, Globe, Instagram, Users, Play, Eye, CheckCircle, ExternalLink, Sparkles } from "lucide-react"
import Link from "next/link"

export const metadata: Metadata = {
  title: "789 CREW - The Team Behind 789 Studios",
  description: "Meet the visionaries powering 789 Studios OTT: VIBES, NEURO, WOOKI, GATOR, ARTSY, and JEEP",
}

export default function CrewPage() {
  const crewMembers = mockCreators.filter((creator) => creator.isCrew)

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="relative pt-24 pb-16 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-background to-secondary/20" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(255,165,0,0.15),transparent_50%)]" />

        <div className="relative max-w-7xl mx-auto text-center">
          <Badge className="mb-4 bg-primary/20 text-primary border-primary/30">
            <Sparkles className="w-3 h-3 mr-1" />
            THE TEAM
          </Badge>
          <h1
            className="text-5xl md:text-7xl font-black mb-6 bg-gradient-to-r from-primary via-secondary to-primary bg-clip-text text-transparent"
            style={glowStyles.textOrange}
          >
            789 CREW
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto mb-8">
            Meet the visionaries, builders, and creators powering the future of Film3 entertainment
          </p>
          <Link href="https://x.com/i/communities/1956818120120656211" target="_blank" rel="noopener noreferrer">
            <Button
              size="lg"
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
              style={glowStyles.orange}
            >
              <Twitter className="w-5 h-5 mr-2" />
              Join Our X Community
              <ExternalLink className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Crew Grid */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {crewMembers.map((member) => (
              <Card
                key={member.id}
                className="bg-card/50 backdrop-blur-sm border-border/50 hover:border-primary/50 transition-all duration-300 group overflow-hidden"
              >
                <CardHeader className="relative pb-0">
                  {/* Glow effect on hover */}
                  <div
                    className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                    style={{
                      background: "radial-gradient(circle at 50% 0%, rgba(255,165,0,0.15), transparent 70%)",
                    }}
                  />

                  <div className="flex items-start gap-4">
                    <Avatar className="w-20 h-20 border-2 border-primary/30 group-hover:border-primary transition-colors">
                      <AvatarImage src={member.avatar || "/placeholder.svg"} alt={member.name} />
                      <AvatarFallback className="bg-primary/20 text-primary text-2xl font-bold">
                        {member.crewHandle?.[0] || member.name[0]}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="text-2xl font-black text-primary" style={glowStyles.textOrange}>
                          {member.crewHandle || member.name}
                        </h3>
                        {member.isVerified && <CheckCircle className="w-5 h-5 text-primary fill-primary/20" />}
                      </div>
                      <p className="text-sm text-secondary font-medium">{member.crewRole}</p>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="pt-4">
                  <p className="text-muted-foreground text-sm mb-4 line-clamp-3">{member.bio}</p>

                  {/* Specialties */}
                  {member.specialties && (
                    <div className="flex flex-wrap gap-1.5 mb-4">
                      {member.specialties.map((specialty) => (
                        <Badge key={specialty} variant="outline" className="text-xs border-primary/30 text-primary/80">
                          {specialty}
                        </Badge>
                      ))}
                    </div>
                  )}

                  {/* Stats */}
                  <div className="grid grid-cols-3 gap-2 py-3 border-t border-b border-border/50 mb-4">
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-1 text-primary">
                        <Users className="w-3.5 h-3.5" />
                        <span className="font-bold text-sm">{(member.subscriberCount / 1000).toFixed(0)}K</span>
                      </div>
                      <span className="text-[10px] text-muted-foreground uppercase">Followers</span>
                    </div>
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-1 text-secondary">
                        <Play className="w-3.5 h-3.5" />
                        <span className="font-bold text-sm">{member.videoCount}</span>
                      </div>
                      <span className="text-[10px] text-muted-foreground uppercase">Videos</span>
                    </div>
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-1 text-primary">
                        <Eye className="w-3.5 h-3.5" />
                        <span className="font-bold text-sm">{(member.totalViews / 1000000).toFixed(1)}M</span>
                      </div>
                      <span className="text-[10px] text-muted-foreground uppercase">Views</span>
                    </div>
                  </div>

                  {/* NFT Collections */}
                  {member.nftCollections && member.nftCollections.length > 0 && (
                    <div className="mb-4">
                      <span className="text-[10px] text-muted-foreground uppercase tracking-wide">NFT Collections</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {member.nftCollections.map((collection) => (
                          <Badge
                            key={collection}
                            className="text-xs bg-secondary/20 text-secondary border-secondary/30"
                          >
                            {collection}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Social Links */}
                  <div className="flex items-center gap-2">
                    {member.socialLinks.twitter && (
                      <Link href={member.socialLinks.twitter} target="_blank" rel="noopener noreferrer">
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 w-8 p-0 border-primary/30 hover:bg-primary/10 hover:border-primary bg-transparent"
                        >
                          <Twitter className="w-4 h-4" />
                        </Button>
                      </Link>
                    )}
                    {member.socialLinks.instagram && (
                      <Link href={member.socialLinks.instagram} target="_blank" rel="noopener noreferrer">
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 w-8 p-0 border-primary/30 hover:bg-primary/10 hover:border-primary bg-transparent"
                        >
                          <Instagram className="w-4 h-4" />
                        </Button>
                      </Link>
                    )}
                    {member.socialLinks.website && (
                      <Link href={member.socialLinks.website} target="_blank" rel="noopener noreferrer">
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 w-8 p-0 border-primary/30 hover:bg-primary/10 hover:border-primary bg-transparent"
                        >
                          <Globe className="w-4 h-4" />
                        </Button>
                      </Link>
                    )}
                    <div className="flex-1" />
                    <Badge className="bg-primary/10 text-primary border-primary/30 font-mono text-[10px]">
                      {member.walletAddress?.slice(0, 8)}...
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Community CTA */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <Card
            className="bg-gradient-to-br from-primary/10 via-card to-secondary/10 border-primary/30"
            style={glowStyles.orange}
          >
            <CardContent className="p-8 md:p-12 text-center">
              <h2 className="text-3xl md:text-4xl font-black mb-4">Join the 789 CREW Community</h2>
              <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
                Connect with VIBES, NEURO, WOOKI, GATOR, ARTSY, JEEP and thousands of Film3 enthusiasts. Get early
                access to drops, participate in governance, and shape the future of decentralized entertainment.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link href="https://x.com/i/communities/1956818120120656211" target="_blank" rel="noopener noreferrer">
                  <Button size="lg" className="bg-primary hover:bg-primary/90">
                    <Twitter className="w-5 h-5 mr-2" />X Community
                  </Button>
                </Link>
                <Link href="/creator-studio">
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-secondary text-secondary hover:bg-secondary/10 bg-transparent"
                  >
                    <Sparkles className="w-5 h-5 mr-2" />
                    Creator Studio
                  </Button>
                </Link>
                <Link href="/dd-cartoons">
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-primary text-primary hover:bg-primary/10 bg-transparent"
                  >
                    <Play className="w-5 h-5 mr-2" />
                    DD CARTOONS
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}
