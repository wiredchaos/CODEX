# 789 Studios OTT Platform - Deployment Guide

## Hybrid Mode Architecture

The platform operates in **Hybrid Mode**, combining off-chain UI with on-chain verification:

- **Off-chain**: UI, video streaming, API routes, mock data
- **On-chain**: Royalty distribution, IP licensing, staking, governance

---

## Prerequisites

### 1. Vercel Account
- Create account at [vercel.com](https://vercel.com)
- Install Vercel CLI: `npm i -g vercel`

### 2. Dogechain Wallet
- Install MetaMask or compatible Web3 wallet
- Add Dogechain network:
  - Chain ID: 2000
  - RPC: `https://rpc.dogechain.dog`
  - Currency: DOGE
  - Explorer: `https://explorer.dogechain.dog`

### 3. Development Tools
- Node.js 18+ and npm/yarn
- Hardhat or Foundry for smart contract deployment
- Git for version control

---

## Phase 1: Deploy Frontend (Vercel)

### Step 1: Connect Repository
```bash
# Clone repository
git clone https://github.com/your-org/789-studios-ott
cd 789-studios-ott

# Link to Vercel
vercel link
```

### Step 2: Configure Environment Variables
Create `.env.local`:
```bash
# Dogechain Configuration
NEXT_PUBLIC_DOGECHAIN_RPC=https://rpc.dogechain.dog
NEXT_PUBLIC_DOGECHAIN_CHAIN_ID=2000

# Contract Addresses (leave empty until deployed)
NEXT_PUBLIC_RIGHTS_REGISTRY_CONTRACT=
NEXT_PUBLIC_ROYALTY_ENGINE_CONTRACT=
NEXT_PUBLIC_CARTOON_ERC20_CONTRACT=
NEXT_PUBLIC_STAKING_VAULT_CONTRACT=
NEXT_PUBLIC_STUDIO_NFT_CONTRACT=

# Optional: Analytics, monitoring
NEXT_PUBLIC_GA_ID=
```

### Step 3: Deploy to Vercel
```bash
# Deploy production
vercel --prod

# Your site will be live at: https://789-studios.vercel.app
```

---

## Phase 2: Deploy Smart Contracts (Dogechain)

### Step 1: Install Dependencies
```bash
npm install --save-dev hardhat @nomicfoundation/hardhat-toolbox
npm install @openzeppelin/contracts
```

### Step 2: Configure Hardhat
Create `hardhat.config.js`:
```javascript
require("@nomicfoundation/hardhat-toolbox");

module.exports = {
  solidity: "0.8.20",
  networks: {
    dogechain: {
      url: "https://rpc.dogechain.dog",
      accounts: [process.env.DEPLOYER_PRIVATE_KEY],
      chainId: 2000,
    },
  },
  etherscan: {
    apiKey: {
      dogechain: "your-dogechain-explorer-api-key"
    }
  }
};
```

### Step 3: Deploy Contracts
```bash
# Deploy Rights Registry
npx hardhat run scripts/deploy-rights-registry.js --network dogechain

# Deploy Royalty Engine
npx hardhat run scripts/deploy-royalty-engine.js --network dogechain

# Deploy Studio Token
npx hardhat run scripts/deploy-studio-token.js --network dogechain

# Deploy Staking Vault
npx hardhat run scripts/deploy-staking-vault.js --network dogechain

# Deploy Studio NFT
npx hardhat run scripts/deploy-studio-nft.js --network dogechain
```

### Step 4: Verify Contracts
```bash
npx hardhat verify --network dogechain <CONTRACT_ADDRESS> <CONSTRUCTOR_ARGS>
```

### Step 5: Update Environment Variables
Update Vercel environment variables with deployed contract addresses:
```bash
vercel env add NEXT_PUBLIC_RIGHTS_REGISTRY_CONTRACT
vercel env add NEXT_PUBLIC_ROYALTY_ENGINE_CONTRACT
vercel env add NEXT_PUBLIC_CARTOON_ERC20_CONTRACT
vercel env add NEXT_PUBLIC_STAKING_VAULT_CONTRACT
vercel env add NEXT_PUBLIC_STUDIO_NFT_CONTRACT
```

### Step 6: Redeploy Frontend
```bash
vercel --prod
```

---

## Phase 3: Configure Smart Contracts

### Set Beneficiaries
```javascript
// Update royalty engine beneficiaries
await royaltyEngine.updateBeneficiary("studio", STUDIO_WALLET);
await royaltyEngine.updateBeneficiary("creator", CREATOR_WALLET);
await royaltyEngine.updateBeneficiary("nftHolder", NFT_HOLDER_WALLET);
await royaltyEngine.updateBeneficiary("treasury", TREASURY_WALLET);
await royaltyEngine.updateBeneficiary("staker", STAKING_VAULT_ADDRESS);
```

### Grant Roles
```javascript
// Grant REGISTRY_MANAGER_ROLE
await rightsRegistry.grantRole(REGISTRY_MANAGER_ROLE, MANAGER_ADDRESS);

// Grant DISTRIBUTOR_ROLE
await royaltyEngine.grantRole(DISTRIBUTOR_ROLE, DISTRIBUTOR_ADDRESS);

// Grant MINTER_ROLE
await studioToken.grantRole(MINTER_ROLE, MINTER_ADDRESS);
```

---

## Phase 4: Testing

### Test Checklist
- [ ] Frontend loads correctly
- [ ] Wallet connection works
- [ ] Contract addresses display in Blockchain Status
- [ ] Royalty distribution can be triggered
- [ ] IP licensing can be verified
- [ ] Token staking works
- [ ] Studio tiers display correctly

### Test Transactions
```bash
# Test royalty distribution (send 1 DOGE)
cast send <ROYALTY_ENGINE_ADDRESS> \
  "distributeRevenue(string)" "test-content-001" \
  --value 1ether \
  --private-key <PRIVATE_KEY> \
  --rpc-url https://rpc.dogechain.dog

# Check pending royalties
cast call <ROYALTY_ENGINE_ADDRESS> \
  "getPendingRoyalties(address)" <YOUR_ADDRESS> \
  --rpc-url https://rpc.dogechain.dog
```

---

## Phase 5: Go Live

### Pre-Launch Checklist
- [ ] All contracts deployed and verified
- [ ] Frontend environment variables updated
- [ ] Beneficiary wallets configured
- [ ] Initial token distribution complete
- [ ] Test transactions successful
- [ ] Monitoring and analytics enabled
- [ ] Security audit completed (recommended)

### Launch
1. Announce contract addresses on official channels
2. Enable wallet connections on frontend
3. Start accepting royalty distributions
4. Open staking for studio tiers
5. Enable IP licensing registration

---

## Monitoring

### On-Chain Monitoring
- Track transactions: `https://explorer.dogechain.dog`
- Monitor contract events
- Track gas usage and costs

### Off-Chain Monitoring
- Vercel Analytics
- Error tracking (Sentry recommended)
- API performance monitoring

---

## Troubleshooting

### Wallet Connection Issues
- Ensure MetaMask is on Dogechain network
- Check chain ID matches (2000)
- Clear browser cache

### Contract Call Failures
- Verify contract addresses are correct
- Check wallet has sufficient DOGE for gas
- Ensure proper roles are granted

### Frontend Issues
- Check environment variables in Vercel dashboard
- Review deployment logs
- Verify API routes are responding

---

## Support

For deployment support:
- GitHub Issues: [github.com/your-org/789-studios-ott/issues]
- Discord: [discord.gg/789studios]
- Email: support@789studios.com

---

## Security Notes

**IMPORTANT:**
- Never commit private keys to Git
- Use hardware wallets for production deployments
- Conduct security audits before mainnet launch
- Implement multi-sig for admin roles
- Set up monitoring and alerting
- Have emergency pause mechanisms ready
