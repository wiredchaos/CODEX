# Vercel V0 Production Prompt

## 789 Studios OTT + DD CARTOONS

Use this prompt when generating new features or components for the platform.

---

## System Context

You are building features for **789 Studios OTT**, a Smart TV streaming platform with blockchain-powered royalties. The platform includes **DD CARTOONS** as the flagship animation studio.

### Architecture

- **Mode**: Hybrid (off-chain UI + on-chain verification)
- **Frontend**: Next.js 15, TypeScript, Tailwind CSS v4
- **Blockchain**: Dogechain (EVM), Solidity 0.8.x
- **Design**: Cyberpunk neon aesthetic (Orange #FF6A00, Yellow #FFC300)

### Royalty Model (40/20/20/10/10)

All revenue splits as:
- 40% to DD CARTOONS Studio
- 20% to Creators
- 20% to NFT Holders
- 10% to Treasury
- 10% to Stakers

### Studio Tiers

1. Executive (S): 10,000+ $CARTOON, 90+ days
2. Premium (A): 1,000+ $CARTOON, 60+ days
3. Member (B): 100+ $CARTOON, 30+ days
4. Viewer (C): No requirements

---

## Key Files Reference

### Types
- `types/royalty.ts` - RoyaltySplit, EpisodeRoyaltyMeta
- `lib/types.ts` - Video, Creator, Studio, IPLicense

### Services
- `lib/royalty-service.ts` - Off-chain royalty fetching
- `lib/royalty-chain.ts` - On-chain contract reading
- `lib/royalty-service-hybrid.ts` - Hybrid merger
- `lib/royalty-engine.ts` - calculateRoyaltySplit function

### Data
- `lib/mock-data.ts` - Test fixtures (mockEpisodes, mockIPLicenses)

### Styling
- `lib/styles.ts` - glowStyles object for neon effects
- Use inline `style={glowStyles.orange}` instead of custom Tailwind classes

### Components
- `components/dd-cartoons/royalty-hud.tsx` - Revenue visualization
- `components/dd-cartoons/studio-tier-card.tsx` - Tier display
- `components/wallet/connect-wallet-button.tsx` - Wallet connector

---

## Code Patterns

### Fetching Royalties

```typescript
import { getEpisodeRoyaltyHybrid } from "@/lib/royalty-service-hybrid";

const royalty = await getEpisodeRoyaltyHybrid(episodeId);
```

### Using Glow Styles

```typescript
import { glowStyles } from "@/lib/styles";

<div style={glowStyles.orange}>Neon content</div>
```

### Calculating Splits

```typescript
import { calculateRoyaltySplit } from "@/lib/royalty-engine";

const { amounts, percentages } = calculateRoyaltySplit(1000);
```

---

## Design Requirements

### Colors
- Primary: Electric Orange (#FF6A00)
- Secondary: Deep Yellow (#FFC300)
- Background: Black (#000), Gray-900 gradients
- Text: White with orange/yellow accents

### Typography
- Headings: Orbitron (cyberpunk style)
- Body: Inter (clean, readable)

### Effects
- Use `glowStyles.orange` or `glowStyles.yellow` for neon glow
- Subtle gradients on backgrounds
- Large buttons for Smart TV compatibility

### Smart TV Guidelines
- Minimum touch target: 44x44px
- Large text (16px+ body)
- High contrast ratios
- Remote-friendly navigation

---

## API Contract

### GET /api/royalty/[episodeId]

Returns:
```json
{
  "episodeId": "ep-001",
  "totalRevenueUsd": 1234.56,
  "split": {
    "studio": 0.4,
    "creator": 0.2,
    "nftHolder": 0.2,
    "treasury": 0.1,
    "stakers": 0.1
  },
  "lastUpdated": "2025-01-15T12:00:00Z",
  "source": "hybrid"
}
```

---

## When Building New Features

1. Check `lib/types.ts` for existing type definitions
2. Use `glowStyles` from `lib/styles.ts` for neon effects
3. Follow the 40/20/20/10/10 royalty model
4. Support both off-chain and on-chain modes
5. Design for Smart TV (large buttons, readable text)
6. Use mock data from `lib/mock-data.ts` for development

---

## Example: New Dashboard Component

```typescript
"use client";

import { glowStyles } from "@/lib/styles";
import { RoyaltyHUD } from "@/components/dd-cartoons/royalty-hud";
import { EpisodeRoyaltyMeta } from "@/types/royalty";

interface Props {
  royalty: EpisodeRoyaltyMeta;
}

export function NewDashboard({ royalty }: Props) {
  return (
    <div className="min-h-screen bg-black p-6">
      <h1 
        className="text-3xl font-bold text-orange-500 mb-6"
        style={glowStyles.textOrange}
      >
        Dashboard
      </h1>
      <RoyaltyHUD 
        royalty={royalty} 
        showDetails={true}
        onClaimClick={() => console.log("Claim clicked")}
      />
    </div>
  );
}
```

---

This prompt ensures all generated code follows the established architecture, design system, and royalty model.
