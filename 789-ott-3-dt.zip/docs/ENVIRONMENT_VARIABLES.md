# Environment Variables Guide

## Security Classification

### Safe PUBLIC Variables (Browser-Accessible)

These variables use the `NEXT_PUBLIC_` prefix and are intentionally exposed to the browser. They contain public blockchain information that is already visible on-chain:

#### `NEXT_PUBLIC_DOGECHAIN_RPC_URL`
- **Type**: Public RPC endpoint URL
- **Example**: `https://rpc.dogechain.dog`
- **Purpose**: Connect to Dogechain network
- **Security**: Safe - public network endpoint

#### `NEXT_PUBLIC_ROYALTY_ENGINE_CONTRACT`
- **Type**: Smart contract address
- **Example**: `0x1234567890abcdef...`
- **Purpose**: Interact with royalty distribution contract
- **Security**: Safe - public blockchain address

#### `NEXT_PUBLIC_RIGHTS_REGISTRY_CONTRACT`
- **Type**: Smart contract address
- **Purpose**: Verify IP licenses on-chain
- **Security**: Safe - public blockchain address

#### `NEXT_PUBLIC_CARTOON_ERC20_CONTRACT`
- **Type**: ERC20 smart contract address
- **Example**: `0xabcdef1234567890...`
- **Purpose**: Interact with $CARTOON ERC20 contract
- **Security**: Safe - public blockchain address, visible to all on-chain
- **Note**: This is the address of the ERC20 smart contract, not a secret credential

#### `NEXT_PUBLIC_STAKING_VAULT_CONTRACT`
- **Type**: Smart contract address
- **Purpose**: Interact with staking functionality
- **Security**: Safe - public blockchain address

#### `NEXT_PUBLIC_STUDIO_NFT_CONTRACT`
- **Type**: NFT contract address
- **Purpose**: Query NFT ownership and metadata
- **Security**: Safe - public blockchain address

### PRIVATE Variables (Server-Only)

These should NEVER use the `NEXT_PUBLIC_` prefix and must only be accessed in server-side code:

#### `DATABASE_URL`
- **Type**: Database connection string
- **Security**: SENSITIVE - Keep server-only
- **Usage**: Server components, API routes only

#### `ADMIN_WALLET_PRIVATE_KEY`
- **Type**: Private key for admin operations
- **Security**: CRITICAL - Never expose to client
- **Usage**: Server-side contract interactions only
- **Storage**: Use Vercel environment variables, not in code

#### `API_SECRET_KEY`
- **Type**: Authentication secret
- **Security**: SENSITIVE - Server-only
- **Usage**: API route authentication

## How to Set Environment Variables

### Development (.env.local)
```bash
# Create .env.local file (not committed to git)
NEXT_PUBLIC_DOGECHAIN_RPC_URL=https://rpc.dogechain.dog
NEXT_PUBLIC_ROYALTY_ENGINE_CONTRACT=0x...
NEXT_PUBLIC_CARTOON_ERC20_CONTRACT=0x...

# Server-only variables (no NEXT_PUBLIC_ prefix)
DATABASE_URL=postgresql://...
```

### Production (Vercel)
1. Go to project settings on Vercel
2. Navigate to "Environment Variables"
3. Add each variable with appropriate scope:
   - `NEXT_PUBLIC_*` variables: Expose to browser
   - Other variables: Keep server-side only

## Common Misconceptions

### Smart Contract Addresses vs API Credentials
- **Smart Contract Address**: `0x742d35Cc6634C0532925a3b844Bc454e4438f44e` - Public, everyone can see it
- **API Credential**: `sk_live_51H1d...` - Secret, must never be exposed

### Smart Contract Addresses Are Public
Contract addresses are public by design. Everyone can see them on the blockchain explorer. Hiding them provides no security benefit.

### RPC URLs Are Public
Public RPC endpoints are meant to be shared. Rate limiting is handled by the RPC provider, not by hiding the URL.

## What Should Actually Be Secret?

1. **Private Keys** - Never in environment variables accessible to frontend
2. **Database Passwords** - Server-side only
3. **API Secrets** - Server-side only
4. **Admin Authentication** - Server-side only

## Verification

To verify no sensitive data is exposed:
```bash
# Check what's exposed to browser
npm run build
# Look at .next/static - NEXT_PUBLIC_ vars will be visible here
# This is expected and correct for public blockchain data
