# Developer Onboarding Guide

## 789 Studios OTT + DD CARTOONS

Welcome to the 789 Studios development team. This guide walks you through setting up your local environment and understanding the hybrid architecture.

---

## 1. Prerequisites

### Required Tools
- Node.js 18+ (LTS recommended)
- npm, yarn, or pnpm
- Git
- MetaMask or Web3 wallet
- VS Code (recommended)

### Recommended Extensions
- ESLint
- Prettier
- Tailwind CSS IntelliSense
- Solidity (for contract work)

---

## 2. Clone and Install

```bash
# Clone the repository
git clone https://github.com/your-org/789-studios-ott.git
cd 789-studios-ott

# Install dependencies
npm install

# Copy environment template
cp .env.example .env.local
```

---

## 3. Understanding the Architecture

### Three-Mode System

The platform operates in one of three modes:

| Mode | Data Source | Use Case |
|------|-------------|----------|
| **Off-chain** | Mock/DB only | Development, demos |
| **Hybrid** | DB + Blockchain | Production |
| **On-chain** | Blockchain only | Future purist mode |

### Mode Selection

Set in `.env.local`:
```bash
ROYALTY_MODE=offchain  # or "hybrid"
```

### Key Directories

```
lib/
├── royalty-service.ts         # Off-chain service
├── royalty-chain.ts           # On-chain reader
├── royalty-service-hybrid.ts  # Hybrid merger
├── royalty-engine.ts          # Core split calculation
├── mock-data.ts               # Test fixtures
└── blockchain/
    ├── dogechain-config.ts    # Chain configuration
    └── wallet-connector.ts    # Wallet integration

types/
└── royalty.ts                 # Type definitions

components/dd-cartoons/
├── royalty-hud.tsx            # Revenue display
├── studio-tier-card.tsx       # Tier visualization
└── ip-license-viewer.tsx      # License display

contracts/
├── RoyaltyEngine.sol          # Revenue distribution
├── RightsRegistry.sol         # IP licensing
├── StudioToken.sol            # $CARTOON ERC20
└── StakingVault.sol           # Staking logic
```

---

## 4. Running Locally

### Start Development Server

```bash
npm run dev
```

Visit http://localhost:3000

### Key Pages to Explore

| Route | Description |
|-------|-------------|
| `/` | OTT Home with carousels |
| `/watch/[id]` | Video player |
| `/dd-cartoons` | Studio dashboard |
| `/creator-studio` | Creator tools |
| `/affiliates` | Affiliate dashboard |
| `/chaincast` | Ad network |
| `/smart-tv` | TV-optimized interface |

---

## 5. Understanding the Royalty System

### Default Split (40/20/20/10/10)

```typescript
const DEFAULT_SPLIT = {
  studio: 0.4,    // 40% to DD CARTOONS
  creator: 0.2,   // 20% to creators
  nftHolder: 0.2, // 20% to NFT holders
  treasury: 0.1,  // 10% to treasury
  stakers: 0.1,   // 10% to stakers
};
```

### How It Works

1. **Revenue Event** occurs (view, purchase, ad)
2. **API Route** receives event
3. **Hybrid Service** fetches:
   - Revenue from DB (off-chain)
   - Split config from chain (on-chain)
4. **Royalty HUD** displays merged result

### Testing Locally

```bash
# Fetch episode royalty
curl http://localhost:3000/api/royalty/ep-001

# Response:
{
  "episodeId": "ep-001",
  "totalRevenueUsd": 1234.56,
  "split": { "studio": 0.4, ... },
  "source": "mock"
}
```

---

## 6. Working with Blockchain

### Connecting to Dogechain

1. Install MetaMask
2. Add network:
   - Chain ID: `2000`
   - RPC: `https://rpc.dogechain.dog`
   - Currency: DOGE
3. Get testnet DOGE from faucet

### Reading Contract Data

```typescript
import { readSplitFromChain } from "@/lib/royalty-chain";

const split = await readSplitFromChain("ep-001");
// Returns RoyaltySplit or null
```

### Environment Variables for Blockchain

```bash
# Add to .env.local for hybrid mode
NEXT_PUBLIC_DOGECHAIN_RPC_URL=https://rpc.dogechain.dog
NEXT_PUBLIC_ROYALTY_ENGINE_CONTRACT=0x...
```

---

## 7. Testing

### Run Tests

```bash
# Unit tests
npm test

# E2E tests
npm run test:e2e
```

### Manual Testing Checklist

- [ ] Home page loads with carousels
- [ ] Video playback works
- [ ] Royalty HUD displays data
- [ ] Wallet connection works (if hybrid)
- [ ] Studio tiers display correctly

---

## 8. Code Style

### TypeScript
- Strict mode enabled
- Use explicit types for function params
- Prefer `interface` over `type` for objects

### React
- Use Server Components by default
- Add `"use client"` only when needed
- Keep components focused and small

### Styling
- Tailwind CSS v4 utilities
- Use `glowStyles` from `lib/styles.ts` for neon effects
- Follow brand colors: Orange (#FF6A00), Yellow (#FFC300)

---

## 9. Common Tasks

### Add a New Episode

1. Add to `lib/mock-data.ts`
2. Create watch page route
3. Add to carousel data

### Update Royalty Split

1. Modify `DEFAULT_SPLIT` in `types/royalty.ts`
2. Or set on-chain via contract

### Add New Studio Tier

1. Update `StudioTier` type in `lib/types.ts`
2. Add tier card component
3. Update staking thresholds

---

## 10. Getting Help

- **Code Questions**: Check existing components first
- **Architecture**: Read `README.md` and this guide
- **Blockchain**: Check `docs/DEPLOYMENT.md`
- **Stuck**: Ask in team Discord

---

## Quick Reference

### API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/royalty/[episodeId]` | GET | Get episode royalty |
| `/api/royalty/batch` | POST | Batch fetch royalties |
| `/api/licensing/verify` | GET | Verify IP license |

### Key Types

```typescript
interface RoyaltySplit {
  studio: number;
  creator: number;
  nftHolder: number;
  treasury: number;
  stakers: number;
}

interface EpisodeRoyaltyMeta {
  episodeId: string;
  totalRevenueUsd: number;
  split: RoyaltySplit;
  lastUpdated: string;
  source: "mock" | "db" | "chain";
}
```

### Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `ROYALTY_MODE` | Yes | "offchain" or "hybrid" |
| `NEXT_PUBLIC_DOGECHAIN_RPC_URL` | Hybrid | RPC endpoint |
| `NEXT_PUBLIC_ROYALTY_ENGINE_CONTRACT` | Hybrid | Contract address |

---

Welcome aboard. Build something amazing.
