import type { Video, Creator } from "./types"

export interface AEOMetadata {
  aiTitle: string
  aiDescription: string
  voiceSearchCues: string[]
  suggestedQueries: string[]
  topicClusters: string[]
  faqSchema: FAQItem[]
  schemaMarkup: string
}

export interface FAQItem {
  question: string
  answer: string
}

export function generateAEOMetadata(video: Video, creator?: Creator): AEOMetadata {
  const aiTitle = `Watch ${video.title} - ${video.category} Film3 Content on 789 Studios`
  const aiDescription = `${video.description} Created by ${creator?.name || "independent creator"}. Stream this ${video.category.toLowerCase()} on 789 Studios OTT platform. ${video.isTokenGated ? "Token-gated exclusive content." : "Free to watch."}`

  const voiceSearchCues = [
    `how to watch ${video.title}`,
    `what is ${video.title} about`,
    `${video.title} streaming`,
    `${video.category} on 789 studios`,
    `film3 ${video.tags[0]} content`,
  ]

  const suggestedQueries = [
    `${video.title} review`,
    `similar to ${video.title}`,
    `${creator?.name || "creator"} other work`,
    `${video.category} recommendations`,
    `blockchain ${video.tags[0]} videos`,
  ]

  const topicClusters = [
    video.category,
    ...video.tags,
    "Film3",
    "Web3 streaming",
    "blockchain content",
    "decentralized media",
  ]

  const faqSchema: FAQItem[] = [
    {
      question: `What is ${video.title}?`,
      answer: video.description,
    },
    {
      question: `How long is ${video.title}?`,
      answer: `${Math.floor(video.duration / 60)} minutes`,
    },
    {
      question: `Who created ${video.title}?`,
      answer: `${video.title} was created by ${creator?.name || "an independent creator"} on 789 Studios.`,
    },
    {
      question: `Is ${video.title} free to watch?`,
      answer: video.isTokenGated
        ? `${video.title} is token-gated content requiring access tokens.`
        : `Yes, ${video.title} is free to watch on 789 Studios.`,
    },
  ]

  const schemaMarkup = generateSchemaMarkup(video, creator, faqSchema)

  return {
    aiTitle,
    aiDescription,
    voiceSearchCues,
    suggestedQueries,
    topicClusters,
    faqSchema,
    schemaMarkup,
  }
}

function generateSchemaMarkup(video: Video, creator: Creator | undefined, faqs: FAQItem[]): string {
  const videoSchema = {
    "@context": "https://schema.org",
    "@type": "VideoObject",
    name: video.title,
    description: video.description,
    thumbnailUrl: video.thumbnail,
    uploadDate: video.createdAt.toISOString(),
    duration: `PT${video.duration}S`,
    contentUrl: video.videoUrl,
    embedUrl: `https://789studios.tv/watch/${video.id}`,
    interactionStatistic: {
      "@type": "InteractionCounter",
      interactionType: { "@type": "WatchAction" },
      userInteractionCount: video.views,
    },
    creator: creator
      ? {
          "@type": "Person",
          name: creator.name,
          url: creator.socialLinks?.website,
        }
      : undefined,
  }

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((faq) => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: faq.answer,
      },
    })),
  }

  return JSON.stringify([videoSchema, faqSchema], null, 2)
}

export function generateCreatorAEOMetadata(creator: Creator): AEOMetadata {
  const aiTitle = `${creator.name} - Film3 Creator on 789 Studios`
  const aiDescription = `${creator.bio} Watch ${creator.videoCount} videos with ${creator.totalViews.toLocaleString()} total views. ${creator.isVerified ? "Verified creator." : ""}`

  const voiceSearchCues = [
    `${creator.name} videos`,
    `who is ${creator.name}`,
    `${creator.name} film3 content`,
    `watch ${creator.name}`,
  ]

  const suggestedQueries = [
    `${creator.name} latest video`,
    `${creator.name} popular content`,
    `${creator.name} blockchain projects`,
    `follow ${creator.name}`,
  ]

  const topicClusters = ["Film3 creator", "blockchain content creator", "web3 media", "decentralized video"]

  const faqSchema: FAQItem[] = [
    {
      question: `Who is ${creator.name}?`,
      answer: creator.bio,
    },
    {
      question: `How many videos has ${creator.name} published?`,
      answer: `${creator.name} has published ${creator.videoCount} videos on 789 Studios.`,
    },
    {
      question: `How can I support ${creator.name}?`,
      answer: `You can subscribe to ${creator.name}, watch their content, and engage with their token-gated exclusives on 789 Studios.`,
    },
  ]

  const schemaMarkup = JSON.stringify(
    {
      "@context": "https://schema.org",
      "@type": "Person",
      name: creator.name,
      description: creator.bio,
      image: creator.avatar,
      url: creator.socialLinks?.website,
      sameAs: [creator.socialLinks?.twitter, creator.socialLinks?.instagram].filter(Boolean),
    },
    null,
    2,
  )

  return {
    aiTitle,
    aiDescription,
    voiceSearchCues,
    suggestedQueries,
    topicClusters,
    faqSchema,
    schemaMarkup,
  }
}
