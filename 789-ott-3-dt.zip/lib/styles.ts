export const glowStyles = {
  orange: {
    boxShadow: "0 0 20px rgba(255, 106, 0, 0.3), 0 0 40px rgba(255, 106, 0, 0.3)",
  },
  yellow: {
    boxShadow: "0 0 20px rgba(255, 195, 0, 0.3), 0 0 40px rgba(255, 195, 0, 0.3)",
  },
  textOrange: {
    textShadow: "0 0 10px rgba(255, 106, 0, 0.3), 0 0 20px rgba(255, 106, 0, 0.3)",
  },
  textYellow: {
    textShadow: "0 0 10px rgba(255, 195, 0, 0.3), 0 0 20px rgba(255, 195, 0, 0.3)",
  },
} as const
