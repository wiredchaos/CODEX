// MODE C: Hybrid royalty service (production recommended)
// Combines off-chain revenue data with on-chain verification

import { DEFAULT_SPLIT, type EpisodeRoyaltyMeta } from "@/types/royalty"
import { getEpisodeRoyaltyOffChain } from "./royalty-service"
import { readSplitFromChain } from "./royalty-chain"

/**
 * Get episode royalty with hybrid approach:
 * - Revenue from off-chain DB (fast, scalable)
 * - Split configuration from on-chain contracts (trustless)
 * - Merges both sources for accurate real-time data
 */
export async function getEpisodeRoyaltyHybrid(episodeId: string): Promise<EpisodeRoyaltyMeta> {
  // Get off-chain base data (revenue, timestamps)
  const base = await getEpisodeRoyaltyOffChain(episodeId)

  // Try to read split from chain
  const chainSplit = await readSplitFromChain(episodeId)

  // Use chain split if available, otherwise fall back to default
  const finalSplit = chainSplit ?? DEFAULT_SPLIT

  return {
    ...base,
    split: finalSplit,
    source: chainSplit ? "hybrid" : base.source,
    lastUpdated: new Date().toISOString(),
  }
}

/**
 * Batch fetch royalty data for multiple episodes
 * Optimized for homepage/browse pages
 */
export async function getEpisodesRoyaltyBatch(episodeIds: string[]): Promise<Map<string, EpisodeRoyaltyMeta>> {
  const results = await Promise.all(episodeIds.map((id) => getEpisodeRoyaltyHybrid(id)))

  const map = new Map<string, EpisodeRoyaltyMeta>()
  results.forEach((meta) => map.set(meta.episodeId, meta))

  return map
}
