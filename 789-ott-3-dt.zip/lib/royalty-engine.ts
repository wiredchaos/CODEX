import type { RoyaltySplit, RevenueDistribution } from "./types"

export class RoyaltyEngine {
  // Calculate royalty splits based on revenue and configuration
  static calculateSplit(revenue: number, split: RoyaltySplit, stakeBonus = 0): Record<string, number> {
    const adjustedStakerShare = split.stakerShare + stakeBonus

    return {
      studio: (revenue * split.studioShare) / 100,
      creator: (revenue * split.creatorShare) / 100,
      nftHolder: (revenue * split.nftHolderShare) / 100,
      treasury: (revenue * split.treasuryShare) / 100,
      staker: (revenue * adjustedStakerShare) / 100,
    }
  }

  // Calculate staking bonus based on lock duration
  static getStakingBonus(lockDuration: 30 | 60 | 90): number {
    const bonusMap = {
      30: 5, // +5% revenue share
      60: 10, // +10% revenue share
      90: 15, // +15% revenue share + executive producer credit
    }
    return bonusMap[lockDuration]
  }

  // Generate revenue distribution records
  static async distributeRevenue(
    royaltySplitId: string,
    revenue: number,
    recipients: {
      studio: string
      creator: string
      nftHolders: string[]
      treasury: string
      stakers: string[]
    },
  ): Promise<RevenueDistribution[]> {
    // This would interact with blockchain in production
    const distributions: RevenueDistribution[] = []

    // Simulate distribution creation
    console.log("[v0] Distributing revenue:", {
      royaltySplitId,
      revenue,
      recipients,
    })

    return distributions
  }

  // Verify IP license before using asset
  static verifyLicense(tokenId: string, licenseType: string): boolean {
    // In production, this checks on-chain registry
    console.log("[v0] Verifying license for token:", tokenId, licenseType)
    return true
  }

  // Calculate watch time revenue
  static calculateWatchTimeRevenue(views: number, watchTimeMinutes: number, revenuePerView = 0.01): number {
    // Simple CPM-based calculation
    return views * revenuePerView
  }
}

export function calculateRoyaltySplit(totalAmount: number) {
  return {
    studioShare: totalAmount * 0.4, // 40%
    creatorShare: totalAmount * 0.2, // 20%
    nftHolderShare: totalAmount * 0.2, // 20%
    treasuryShare: totalAmount * 0.1, // 10%
    stakerShare: totalAmount * 0.1, // 10%
  }
}
