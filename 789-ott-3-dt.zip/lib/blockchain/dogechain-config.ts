/**
 * Dogechain Configuration
 *
 * SECURITY NOTE: All variables here are PUBLIC blockchain information:
 * - RPC URLs are public network endpoints
 * - Contract addresses are public on the blockchain
 * - These are smart contract addresses, NOT authentication credentials
 *
 * These are safe to expose to the browser and required for frontend web3 interaction.
 * NEVER store private keys, API secrets, or authentication credentials here.
 */

export const DOGECHAIN_CONFIG = {
  chainId: 2000, // Dogechain Mainnet
  chainIdTestnet: 568, // Dogechain Testnet
  rpcUrl: process.env.NEXT_PUBLIC_DOGECHAIN_RPC || "https://rpc.dogechain.dog",
  rpcUrlTestnet: "https://rpc-testnet.dogechain.dog",
  blockExplorer: "https://explorer.dogechain.dog",
  nativeCurrency: {
    name: "Dogecoin",
    symbol: "DOGE",
    decimals: 18,
  },
  contracts: {
    // PUBLIC blockchain contract addresses (visible on-chain to everyone)
    // These are smart contract addresses, NOT API keys or auth credentials
    rightsRegistry: process.env.NEXT_PUBLIC_RIGHTS_REGISTRY_CONTRACT || "",
    royaltyEngine: process.env.NEXT_PUBLIC_ROYALTY_ENGINE_CONTRACT || "",
    // $CARTOON ERC20 smart contract address (public blockchain data)
    cartoonERC20: process.env.NEXT_PUBLIC_CARTOON_ERC20_CONTRACT || "",
    stakingVault: process.env.NEXT_PUBLIC_STAKING_VAULT_CONTRACT || "",
    studioNFT: process.env.NEXT_PUBLIC_STUDIO_NFT_CONTRACT || "",
  },
}

export const ABI = {
  rightsRegistry: [
    "function registerIP(string memory ipId, address owner, uint8 ipStatus) external",
    "function getIPStatus(string memory ipId) external view returns (uint8)",
    "function getLicense(string memory ipId) external view returns (tuple(string ipId, address owner, uint8 status, uint256 permissions, uint256 restrictions))",
    "function transferRights(string memory ipId, address newOwner) external",
    "event IPRegistered(string indexed ipId, address indexed owner, uint8 status)",
    "event RightsTransferred(string indexed ipId, address indexed from, address indexed to)",
  ],
  royaltyEngine: [
    "function distributeRevenue(string memory contentId, uint256 amount) external payable",
    "function getRoyaltyShares(string memory contentId) external view returns (tuple(uint256 studio, uint256 creator, uint256 nftHolder, uint256 treasury, uint256 stakers))",
    "function claimRoyalties(address beneficiary) external",
    "function getPendingRoyalties(address beneficiary) external view returns (uint256)",
    "event RevenueDistributed(string indexed contentId, uint256 amount, uint256 timestamp)",
    "event RoyaltiesClaimed(address indexed beneficiary, uint256 amount)",
  ],
  cartoonERC20: [
    "function balanceOf(address account) external view returns (uint256)",
    "function stake(uint256 amount) external",
    "function unstake(uint256 amount) external",
    "function getStakingTier(address account) external view returns (uint8)",
    "event Staked(address indexed user, uint256 amount)",
    "event Unstaked(address indexed user, uint256 amount)",
  ],
  stakingVault: [
    "function stake(uint256 amount, uint8 tier) external",
    "function unstake() external",
    "function getStake(address user) external view returns (uint256 amount, uint8 tier, uint256 stakedAt)",
    "function calculateRewards(address user) external view returns (uint256)",
    "function claimRewards() external",
  ],
  studioNFT: [
    "function mint(address to, string memory tokenURI) external returns (uint256)",
    "function ownerOf(uint256 tokenId) external view returns (address)",
    "function tokenURI(uint256 tokenId) external view returns (string memory)",
    "function getCharacterRoyaltyShare(uint256 tokenId) external view returns (uint256)",
  ],
} as const

export const NETWORK_PARAMS = {
  chainId: `0x${DOGECHAIN_CONFIG.chainId.toString(16)}`,
  chainName: "Dogechain Mainnet",
  nativeCurrency: DOGECHAIN_CONFIG.nativeCurrency,
  rpcUrls: [DOGECHAIN_CONFIG.rpcUrl],
  blockExplorerUrls: [DOGECHAIN_CONFIG.blockExplorer],
}
