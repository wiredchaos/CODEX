import { DOGECHAIN_CONFIG } from "./dogechain-config"
import { walletConnector } from "./wallet-connector"
import type { IPLicense, RoyaltyDistribution } from "../types"

export class ContractInterface {
  private provider: any = null

  async init() {
    this.provider = await walletConnector.getProvider()
    if (!this.provider) {
      throw new Error("Wallet not connected")
    }
  }

  // Rights Registry Functions
  async registerIP(ipId: string, owner: string, status: number): Promise<string> {
    await this.init()

    const contract = DOGECHAIN_CONFIG.contracts.rightsRegistry
    if (!contract) {
      throw new Error("Rights Registry contract not deployed")
    }

    const data = this.encodeFunction("registerIP", ["string", "address", "uint8"], [ipId, owner, status])

    const txHash = await this.sendTransaction(contract, data)
    return txHash
  }

  async getIPLicense(ipId: string): Promise<IPLicense | null> {
    await this.init()

    const contract = DOGECHAIN_CONFIG.contracts.rightsRegistry
    if (!contract) {
      console.log("[v0] Rights Registry not deployed, using mock data")
      return null
    }

    try {
      const result = await this.callContract(contract, "getLicense", ["string"], [ipId])

      return {
        ipId: result[0],
        owner: result[1],
        status: result[2],
        permissions: result[3],
        restrictions: result[4],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        verificationHash: "",
      }
    } catch (error) {
      console.error("[v0] Error fetching license:", error)
      return null
    }
  }

  // Royalty Engine Functions
  async distributeRevenue(contentId: string, amount: string): Promise<string> {
    await this.init()

    const contract = DOGECHAIN_CONFIG.contracts.royaltyEngine
    if (!contract) {
      throw new Error("Royalty Engine contract not deployed")
    }

    const data = this.encodeFunction("distributeRevenue", ["string", "uint256"], [contentId, amount])

    const txHash = await this.sendTransaction(contract, data, amount)
    return txHash
  }

  async getRoyaltyShares(contentId: string): Promise<RoyaltyDistribution | null> {
    await this.init()

    const contract = DOGECHAIN_CONFIG.contracts.royaltyEngine
    if (!contract) {
      console.log("[v0] Royalty Engine not deployed, using default splits")
      return null
    }

    try {
      const result = await this.callContract(contract, "getRoyaltyShares", ["string"], [contentId])

      return {
        studioShare: Number(result[0]),
        creatorShare: Number(result[1]),
        nftHolderShare: Number(result[2]),
        treasuryShare: Number(result[3]),
        stakerShare: Number(result[4]),
        totalAmount: "0",
        lastDistribution: new Date().toISOString(),
        onChainVerified: true,
      }
    } catch (error) {
      console.error("[v0] Error fetching royalty shares:", error)
      return null
    }
  }

  async claimRoyalties(): Promise<string> {
    await this.init()

    const contract = DOGECHAIN_CONFIG.contracts.royaltyEngine
    if (!contract) {
      throw new Error("Royalty Engine contract not deployed")
    }

    const accounts = await this.provider.request({
      method: "eth_requestAccounts",
    })

    const data = this.encodeFunction("claimRoyalties", ["address"], [accounts[0]])

    const txHash = await this.sendTransaction(contract, data)
    return txHash
  }

  // Studio Token Functions
  async getStakingTier(address: string): Promise<number> {
    await this.init()

    const contract = DOGECHAIN_CONFIG.contracts.studioToken
    if (!contract) {
      return 0
    }

    try {
      const result = await this.callContract(contract, "getStakingTier", ["address"], [address])

      return Number(result)
    } catch (error) {
      console.error("[v0] Error fetching staking tier:", error)
      return 0
    }
  }

  async stakeTokens(amount: string): Promise<string> {
    await this.init()

    const contract = DOGECHAIN_CONFIG.contracts.studioToken
    if (!contract) {
      throw new Error("Studio Token contract not deployed")
    }

    const data = this.encodeFunction("stake", ["uint256"], [amount])

    const txHash = await this.sendTransaction(contract, data)
    return txHash
  }

  // Helper functions
  private async sendTransaction(to: string, data: string, value = "0"): Promise<string> {
    const accounts = await this.provider.request({
      method: "eth_requestAccounts",
    })

    const txHash = await this.provider.request({
      method: "eth_sendTransaction",
      params: [
        {
          from: accounts[0],
          to,
          data,
          value: value !== "0" ? `0x${Number.parseInt(value).toString(16)}` : "0x0",
        },
      ],
    })

    return txHash
  }

  private async callContract(to: string, method: string, types: string[], values: any[]): Promise<any> {
    const data = this.encodeFunction(method, types, values)

    const result = await this.provider.request({
      method: "eth_call",
      params: [
        {
          to,
          data,
        },
        "latest",
      ],
    })

    return this.decodeResult(result)
  }

  private encodeFunction(name: string, types: string[], values: any[]): string {
    // Simple ABI encoding (in production, use ethers.js or viem)
    const signature = `${name}(${types.join(",")})`
    const hash = this.keccak256(signature).slice(0, 10)

    // This is a simplified version - use proper ABI encoding library in production
    return hash
  }

  private decodeResult(hex: string): any {
    // Simple decoding (in production, use ethers.js or viem)
    return hex
  }

  private keccak256(str: string): string {
    // Placeholder - use proper keccak256 library in production
    return "0x" + str.split("").reduce((acc, char) => acc + char.charCodeAt(0).toString(16), "")
  }
}

export const contractInterface = new ContractInterface()
