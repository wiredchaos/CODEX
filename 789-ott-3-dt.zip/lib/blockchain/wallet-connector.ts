import { DOGECHAIN_CONFIG, NETWORK_PARAMS } from "./dogechain-config"

export type WalletProvider = "metamask" | "walletconnect" | "coinbase" | "demo"

export interface ConnectedWallet {
  address: string
  chainId: number
  provider: WalletProvider
  balance: string
  isDemo?: boolean
}

const DEMO_WALLET: ConnectedWallet = {
  address: "0x789Studio...DemoWallet",
  chainId: DOGECHAIN_CONFIG.chainId,
  provider: "demo",
  balance: "10,000.00",
  isDemo: true,
}

export class WalletConnector {
  private provider: any = null
  private isDemo = false

  isWalletAvailable(): boolean {
    if (typeof window === "undefined") return false
    return !!(window as any).ethereum
  }

  async connect(providerType: WalletProvider = "metamask"): Promise<ConnectedWallet> {
    if (providerType === "demo" || !this.isWalletAvailable()) {
      this.isDemo = true
      return DEMO_WALLET
    }

    try {
      if (typeof window === "undefined") {
        throw new Error("Wallet connection only available in browser")
      }

      const ethereum = (window as any).ethereum

      // Request account access
      const accounts = await ethereum.request({
        method: "eth_requestAccounts",
      })

      if (!accounts || accounts.length === 0) {
        throw new Error("No accounts found")
      }

      const address = accounts[0]

      // Check if we're on Dogechain
      const chainId = await ethereum.request({ method: "eth_chainId" })
      const chainIdDecimal = Number.parseInt(chainId, 16)

      // If not on Dogechain, prompt to switch
      if (chainIdDecimal !== DOGECHAIN_CONFIG.chainId) {
        await this.switchToDogechain(ethereum)
      }

      // Get balance
      const balance = await ethereum.request({
        method: "eth_getBalance",
        params: [address, "latest"],
      })

      this.provider = ethereum
      this.isDemo = false

      return {
        address,
        chainId: DOGECHAIN_CONFIG.chainId,
        provider: providerType,
        balance: this.formatBalance(balance),
        isDemo: false,
      }
    } catch (error: any) {
      console.error("Wallet connection error:", error)
      throw new Error(error.message || "Failed to connect wallet")
    }
  }

  async switchToDogechain(ethereum: any) {
    try {
      await ethereum.request({
        method: "wallet_switchEthereumChain",
        params: [{ chainId: NETWORK_PARAMS.chainId }],
      })
    } catch (switchError: any) {
      // Chain not added yet, add it
      if (switchError.code === 4902) {
        await ethereum.request({
          method: "wallet_addEthereumChain",
          params: [NETWORK_PARAMS],
        })
      } else {
        throw switchError
      }
    }
  }

  async disconnect() {
    this.provider = null
    this.isDemo = false
  }

  async getProvider() {
    return this.provider
  }

  private formatBalance(hexBalance: string): string {
    const balance = Number.parseInt(hexBalance, 16)
    const doge = balance / 1e18
    return doge.toFixed(4)
  }

  async signMessage(message: string): Promise<string> {
    if (!this.provider) {
      throw new Error("Wallet not connected")
    }

    const accounts = await this.provider.request({
      method: "eth_requestAccounts",
    })

    const signature = await this.provider.request({
      method: "personal_sign",
      params: [message, accounts[0]],
    })

    return signature
  }
}

// Singleton instance
export const walletConnector = new WalletConnector()
