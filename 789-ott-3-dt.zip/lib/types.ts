// Core type definitions for 789 Studios OTT Platform

export interface Video {
  id: string
  title: string
  description: string
  thumbnail: string
  videoUrl: string
  duration: number
  category: VideoCategory
  creatorId: string
  views: number
  likes: number
  isTokenGated: boolean
  tokenAddress?: string
  createdAt: Date
  updatedAt: Date
  tags: string[]
  episodeNumber?: number
  seasonNumber?: number
  seriesId?: string
}

export type VideoCategory =
  | "Featured Films"
  | "Shows"
  | "Web3 Specials"
  | "Documentary Vault"
  | "Doginal Dogs Originals"
  | "WIRED CHAOS META"

export interface Creator {
  id: string
  name: string
  email: string
  bio: string
  avatar: string
  walletAddress?: string
  isVerified: boolean
  subscriberCount: number
  videoCount: number
  totalViews: number
  createdAt: Date
  socialLinks: {
    twitter?: string
    instagram?: string
    website?: string
  }
  isCrew?: boolean // Is this a 789 CREW member
  crewRole?: string // Role in the crew (e.g., "Creative Director", "Lead Animator")
  crewHandle?: string // Display handle (e.g., "VIBES", "NEURO")
  specialties?: string[] // Areas of expertise
  communityLink?: string // Link to X community or profile
  nftCollections?: string[] // NFT collections associated with this creator
}

export interface Affiliate {
  id: string
  userId: string
  tier: "A" | "B"
  uniqueUrl: string
  referralCode: string
  totalEarnings: number
  pendingEarnings: number
  clicks: number
  conversions: number
  createdAt: Date
}

export interface AffiliateEarning {
  id: string
  affiliateId: string
  amount: number
  type: "watch" | "referral" | "creator_signup" | "sponsored_content" | "premium_distribution"
  videoId?: string
  creatorId?: string
  timestamp: Date
  status: "pending" | "paid"
}

export interface ChainCastAd {
  id: string
  title: string
  advertiserId: string
  videoUrl: string
  imageUrl: string
  targetUrl: string
  adType: "pre-roll" | "mid-roll" | "banner" | "nft-billboard" | "smart-tv-qr"
  cryptoPayment: {
    amount: number
    currency: string
    transactionHash: string
  }
  walletSegmentation?: string[]
  impressions: number
  clicks: number
  rewardsPool: number
  status: "active" | "paused" | "completed"
  startDate: Date
  endDate: Date
}

export interface CreatorToken {
  id: string
  creatorId: string
  tokenName: string
  tokenSymbol: string
  contractAddress: string
  blockchain: "XRPL" | "Solana" | "Polygon"
  totalSupply: number
  currentPrice: number
  holders: number
}

export interface SmartTVSession {
  id: string
  userId?: string
  deviceId: string
  deviceType: "Roku" | "Fire TV" | "Apple TV" | "Android TV" | "Samsung TV" | "LG TV"
  lastActive: Date
  watchHistory: string[]
}

export interface Series {
  id: string
  title: string
  description: string
  thumbnail: string
  category: VideoCategory
  creatorId: string
  seasons: Season[]
  totalEpisodes: number
  releaseYear: number
  isActive: boolean
}

export interface Season {
  id: string
  seriesId: string
  seasonNumber: number
  title: string
  description: string
  episodes: Video[]
  releaseDate: Date
}

export interface RoyaltySplit {
  id: string
  videoId: string
  studioShare: number // DD CARTOONS studio percentage
  creatorShare: number // Original creator percentage
  nftHolderShare: number // Character NFT holder percentage
  treasuryShare: number // Platform treasury percentage
  stakerShare: number // Token stakers percentage
  totalRevenue: number
  distributedRevenue: number
  status: "active" | "pending" | "completed"
  createdAt: Date
  updatedAt: Date
}

export interface IPLicense {
  id: string
  tokenId: string // Character/asset NFT token ID
  licenseType: "internal" | "community" | "commercial"
  licensee: string // Wallet address or studio ID
  creator: string // Original artist wallet
  owner: string // Current rights holder wallet
  revShare: number // Royalty percentage
  permissionsMask: string[] // Allowed uses: video, merch, print, AI, etc.
  restrictionsMask: string[] // Disallowed uses: political, hate, adult, etc.
  expiry?: Date
  metadataURI: string
  status: "active" | "revoked" | "expired"
  createdAt: Date
}

export interface StudioTier {
  id: string
  name: "Major Studio" | "Indie Studio" | "Creator House" | "Audience Studio"
  nftRequired: boolean
  tokenStakeRequired: number
  benefits: string[]
  royaltyBonus: number // Additional % on top of base royalty
  votingPower: number
  canApprovePilots: boolean
  canSubmitScripts: boolean
  canPitchEpisodes: boolean
  hasVoiceRoles: boolean
  hasExecutiveCredit: boolean
}

export interface TokenStake {
  id: string
  userId: string
  walletAddress: string
  amount: number
  lockDuration: 30 | 60 | 90 // days
  royaltyBonus: number // Additional % based on lock duration
  startDate: Date
  endDate: Date
  status: "active" | "unlocked" | "withdrawn"
}

export interface DDCartoonsEpisode extends Video {
  studioId: "dd-cartoons"
  royaltySplitId: string
  licensedAssets: string[] // Array of tokenIds used in episode
  ipLicenses: IPLicense[]
  productionCredits: {
    writers: string[]
    voiceActors: string[]
    animators: string[]
    directors: string[]
    executiveProducers: string[]
  }
}

export interface RevenueDistribution {
  id: string
  royaltySplitId: string
  recipient: string // Wallet address
  recipientType: "studio" | "creator" | "nft_holder" | "treasury" | "staker"
  amount: number
  currency: "USD" | "DOGE" | "ETH" | "MATIC"
  transactionHash?: string
  status: "pending" | "processing" | "completed" | "failed"
  timestamp: Date
}

export interface DoginalDog {
  id: string
  inscriptionId: string // Dogecoin inscription ID
  name: string
  description: string
  image: string
  attributes: DoginalAttribute[]
  owner: string // Wallet address
  ownerHandle?: string // X/Twitter handle
  rarity: "Common" | "Uncommon" | "Rare" | "Epic" | "Legendary"
  mintedAt: Date
  lastSalePrice?: number
  lastSaleCurrency?: "DOGE" | "USD"
  isListed: boolean
  listPrice?: number
  socialLinks?: {
    twitter?: string
    discord?: string
  }
  // 789 Studios integration
  is789Partner: boolean
  studioRole?: string // Role in 789 Studios ecosystem
  episodeAppearances?: string[] // Episode IDs where this dog appears
  royaltyEarnings?: number
}

export interface DoginalAttribute {
  trait_type: string
  value: string
  rarity_percentage?: number
}

export interface DoginalCollection {
  name: string
  description: string
  totalSupply: number
  floorPrice: number
  volume24h: number
  owners: number
  website: string
  twitter: string
  discord: string
}

export interface MarketData {
  doginalDogs: {
    floorPrice: number
    floorPriceUsd: number
    volume24h: number
    volume7d: number
    volume30d: number
    volumeAllTime: number
    owners: number
    listed: number
    sales24h: number
    avgPrice24h: number
    priceChange24h: number
    priceChange7d: number
  }
  dogecoin: {
    price: number
    priceChange24h: number
    marketCap: number
    volume24h: number
  }
  lastUpdated: Date
}

export interface NewsItem {
  id: string
  title: string
  description: string
  url: string
  source: string
  sourceIcon: string
  category: "crypto" | "nft" | "defi" | "regulation" | "market" | "general"
  publishedAt: Date
  image?: string
}

export interface MarketListing {
  id: string
  inscriptionId: string
  name: string
  image: string
  price: number
  priceUsd: number
  seller: string
  listedAt: Date
  rarity: "Common" | "Uncommon" | "Rare" | "Epic" | "Legendary"
}

export interface MarketSale {
  id: string
  inscriptionId: string
  name: string
  image: string
  price: number
  priceUsd: number
  buyer: string
  seller: string
  soldAt: Date
}
