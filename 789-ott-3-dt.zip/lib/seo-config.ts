export const seoConfig = {
  siteName: "789 Studios OTT",
  siteUrl: "https://789studios.tv",
  defaultTitle: "789 Studios - Film3 Streaming Platform",
  defaultDescription:
    "Watch blockchain-powered Film3 content on the premier OTT platform for Web3 creators. Token-gated exclusives, NFT collectibles, and crypto rewards.",
  defaultKeywords: [
    "Film3",
    "Web3 streaming",
    "blockchain video",
    "OTT platform",
    "NFT content",
    "crypto streaming",
    "decentralized media",
    "token-gated content",
    "creator economy",
  ],
  twitterHandle: "@789Studios",
  socialBanner: "/social-banner.jpg",
  locale: "en_US",
  brandColors: {
    primary: "#FF6A00",
    secondary: "#FFC300",
  },
}

export function generatePageMetadata(options: {
  title?: string
  description?: string
  keywords?: string[]
  image?: string
  path?: string
  type?: "website" | "article" | "video.other"
  publishedTime?: string
  modifiedTime?: string
  author?: string
}) {
  const {
    title = seoConfig.defaultTitle,
    description = seoConfig.defaultDescription,
    keywords = seoConfig.defaultKeywords,
    image = seoConfig.socialBanner,
    path = "",
    type = "website",
    publishedTime,
    modifiedTime,
    author,
  } = options

  const url = `${seoConfig.siteUrl}${path}`

  return {
    metadataBase: new URL(seoConfig.siteUrl),
    title,
    description,
    keywords: keywords.join(", "),
    authors: author ? [{ name: author }] : undefined,
    openGraph: {
      type,
      locale: seoConfig.locale,
      url,
      title,
      description,
      siteName: seoConfig.siteName,
      images: [
        {
          url: image,
          width: 1200,
          height: 630,
          alt: title,
        },
      ],
      publishedTime,
      modifiedTime,
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [image],
      creator: seoConfig.twitterHandle,
      site: seoConfig.twitterHandle,
    },
    alternates: {
      canonical: url,
    },
    robots: {
      index: true,
      follow: true,
      googleBot: {
        index: true,
        follow: true,
        "max-video-preview": -1,
        "max-image-preview": "large",
        "max-snippet": -1,
      },
    },
  }
}
