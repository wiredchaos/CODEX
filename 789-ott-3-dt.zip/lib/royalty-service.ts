// MODE A: Off-chain royalty service (immediate, mock/DB)

import { DEFAULT_SPLIT, type EpisodeRoyaltyMeta } from "@/types/royalty"

/**
 * Get episode royalty information from off-chain sources (DB/mock)
 * Used for: Development, demos, Roku approval process
 */
export async function getEpisodeRoyaltyOffChain(episodeId: string): Promise<EpisodeRoyaltyMeta> {
  // In pure off-chain mode, revenue comes from DB / mock
  const totalRevenueUsd = await lookupEpisodeRevenueFromDB(episodeId)

  return {
    episodeId,
    totalRevenueUsd,
    split: DEFAULT_SPLIT,
    lastUpdated: new Date().toISOString(),
    source: "db",
  }
}

/**
 * Lookup episode revenue from database
 * Replace with actual Supabase/Prisma query
 */
async function lookupEpisodeRevenueFromDB(episodeId: string): Promise<number> {
  // Mock implementation - replace with actual DB query
  // Example: const result = await supabase.from('episodes').select('revenue').eq('id', episodeId)

  const mockRevenue: Record<string, number> = {
    "1": 5420.5,
    "2": 3210.75,
    "3": 8905.25,
    "4": 2150.0,
  }

  return mockRevenue[episodeId] || 1234.56
}

/**
 * Calculate royalty distribution based on split percentages
 */
export function calculateDistribution(totalRevenue: number, split: typeof DEFAULT_SPLIT) {
  return {
    studio: totalRevenue * split.studio,
    creator: totalRevenue * split.creator,
    nftHolder: totalRevenue * split.nftHolder,
    treasury: totalRevenue * split.treasury,
    stakers: totalRevenue * split.stakers,
  }
}
