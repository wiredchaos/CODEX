export class BusinessFirewall {
  private static sensitiveKeys = [
    "STRIPE_SECRET_KEY",
    "SUPABASE_SERVICE_ROLE_KEY",
    "DATABASE_URL",
    "ROYALTY_ENGINE_PRIVATE",
  ]

  static sanitizeForTrinity(data: any): any {
    if (!data) return data

    const sanitized = { ...data }

    // Remove all sensitive keys
    this.sensitiveKeys.forEach((key) => {
      delete sanitized[key]
    })

    // Remove PII
    if (sanitized.email) sanitized.email = this.maskEmail(sanitized.email)
    if (sanitized.walletAddress) sanitized.walletAddress = this.maskWallet(sanitized.walletAddress)

    return sanitized
  }

  static maskEmail(email: string): string {
    const [name, domain] = email.split("@")
    return `${name.slice(0, 2)}***@${domain}`
  }

  static maskWallet(address: string): string {
    return `${address.slice(0, 6)}...${address.slice(-4)}`
  }

  static validateTrinityAccess(operation: string): boolean {
    const readOnlyOps = ["read", "view", "query", "get"]
    return readOnlyOps.some((op) => operation.toLowerCase().includes(op))
  }
}
