export type Video = {
  id: string
  title: string
  description: string
  thumbnail: string
  videoUrl: string
  duration: number
  category: string
  tags: string[]
  views: number
  likes: number
  creatorId: string
  tokenGated: boolean
  tokenAddress?: string
  price?: number
  publishedAt: Date
  aeoMetadata: AEOMetadata
  blockchainData?: BlockchainData
}

export type Creator = {
  id: string
  username: string
  displayName: string
  avatar: string
  bio: string
  walletAddress?: string
  verified: boolean
  totalViews: number
  totalVideos: number
  subscribers: number
  creatorToken?: string
  affiliateCode: string
  earnings: Earnings
  socialLinks?: SocialLinks
}

export type AEOMetadata = {
  aiTitle: string
  aiDescription: string
  voiceSearchCues: string[]
  suggestedQueries: string[]
  topicClusters: string[]
  faqSchema: FAQItem[]
  schemaMarkup: string
}

export type FAQItem = {
  question: string
  answer: string
}

export type BlockchainData = {
  chain: "XRPL" | "Solana" | "Polygon"
  contractAddress?: string
  tokenId?: string
  royaltyPercentage?: number
  mintedAt?: Date
  nftMetadata?: Record<string, any>
}

export type Earnings = {
  total: number
  pending: number
  paid: number
  currency: "USD" | "CRYPTO"
}

export type SocialLinks = {
  twitter?: string
  instagram?: string
  youtube?: string
  website?: string
}

export type Affiliate = {
  id: string
  userId: string
  tier: "AUDIENCE" | "CREATOR"
  code: string
  referralCount: number
  earnings: Earnings
  metrics: AffiliateMetrics
  payoutMethod: PayoutMethod
  kycStatus: "PENDING" | "APPROVED" | "REJECTED"
  joinedAt: Date
}

export type AffiliateMetrics = {
  watches: number
  referrals: number
  creatorSignups: number
  conversions: number
}

export type PayoutMethod = {
  type: "BANK" | "CRYPTO" | "PAYPAL"
  details: Record<string, string>
}

export type AdCampaign = {
  id: string
  advertiserId: string
  name: string
  type: "PRE_ROLL" | "MID_ROLL" | "BANNER" | "NFT_BILLBOARD" | "QR_POPUP"
  budget: number
  spent: number
  targetAudience: TargetAudience
  creativeUrl: string
  clickThroughUrl: string
  impressions: number
  clicks: number
  conversions: number
  cryptoPayment: boolean
  walletSegmentation: boolean
  qrTracking: boolean
  active: boolean
  startDate: Date
  endDate: Date
}

export type TargetAudience = {
  categories: string[]
  walletTypes?: string[]
  minAge?: number
  maxAge?: number
  interests: string[]
}

export type User = {
  id: string
  email: string
  username: string
  avatar?: string
  walletAddress?: string
  watchHistory: string[]
  favorites: string[]
  subscriptions: string[]
  affiliateCode?: string
  adRewardsEarned: number
  createdAt: Date
}

export type Episode = {
  id: string
  seriesId: string
  season: number
  episodeNumber: number
  title: string
  description: string
  thumbnail: string
  videoUrl: string
  duration: number
  tokenGated: boolean
  publishedAt: Date
}

export type Series = {
  id: string
  title: string
  description: string
  thumbnail: string
  category: string
  creatorId: string
  totalSeasons: number
  totalEpisodes: number
  episodes: Episode[]
}
