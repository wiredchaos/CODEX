export type ApiResponse<T> = {
  success: boolean
  data?: T
  error?: string
  message?: string
}

export type PaginatedResponse<T> = {
  items: T[]
  total: number
  page: number
  pageSize: number
  hasMore: boolean
}

export type UploadVideoRequest = {
  title: string
  description: string
  category: string
  tags: string[]
  videoFile: File
  thumbnail: File
  tokenGated?: boolean
  price?: number
  chain?: "XRPL" | "Solana" | "Polygon"
}

export type CreateAdCampaignRequest = {
  name: string
  type: string
  budget: number
  targetAudience: {
    categories: string[]
    interests: string[]
  }
  creativeUrl: string
  clickThroughUrl: string
  cryptoPayment: boolean
  startDate: string
  endDate: string
}

export type AffiliateSignupRequest = {
  tier: "AUDIENCE" | "CREATOR"
  payoutMethod: {
    type: "BANK" | "CRYPTO" | "PAYPAL"
    details: Record<string, string>
  }
}
