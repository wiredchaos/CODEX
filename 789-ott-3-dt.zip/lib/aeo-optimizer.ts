export interface AEOOptimization {
  conversationalTitle: string
  voiceSearchOptimized: string[]
  questionAnswerPairs: { q: string; a: string }[]
  topicExpansion: string[]
  semanticKeywords: string[]
  intentMatchedContent: string
}

export function optimizeForAEO(content: {
  title: string
  description: string
  category: string
  tags: string[]
}): AEOOptimization {
  const { title, description, category, tags } = content

  // Generate conversational title for AI understanding
  const conversationalTitle = `How to watch ${title} - A ${category} on 789 Studios`

  // Voice search optimization
  const voiceSearchOptimized = [
    `What is ${title}`,
    `How do I watch ${title}`,
    `Where can I find ${title}`,
    `Tell me about ${title}`,
    `Play ${title} on 789 Studios`,
  ]

  // Question-answer pairs for featured snippets
  const questionAnswerPairs = [
    { q: `What is ${title}?`, a: description },
    { q: `Where can I watch ${title}?`, a: `You can watch ${title} on 789 Studios OTT platform.` },
    { q: `Is ${title} free to watch?`, a: `${title} is available to stream on 789 Studios.` },
    { q: `What category is ${title}?`, a: `${title} is categorized as ${category}.` },
  ]

  // Topic expansion for semantic SEO
  const topicExpansion = [
    ...tags,
    category,
    "Film3 content",
    "Web3 streaming",
    "blockchain video platform",
    "decentralized media",
    "crypto content",
  ]

  // Semantic keywords for context
  const semanticKeywords = generateSemanticKeywords(title, category, tags)

  // Intent-matched content for search engines
  const intentMatchedContent = `Watch ${title}, a ${category} production, exclusively on 789 Studios. ${description.substring(0, 150)}. Stream now with blockchain-powered features including token-gated access and NFT collectibles.`

  return {
    conversationalTitle,
    voiceSearchOptimized,
    questionAnswerPairs,
    topicExpansion,
    semanticKeywords,
    intentMatchedContent,
  }
}

function generateSemanticKeywords(title: string, category: string, tags: string[]): string[] {
  const keywords = new Set<string>()

  // Add base keywords
  keywords.add(title.toLowerCase())
  keywords.add(category.toLowerCase())
  tags.forEach((tag) => keywords.add(tag.toLowerCase()))

  // Add Film3/Web3 related terms
  const web3Terms = [
    "blockchain streaming",
    "crypto video platform",
    "nft content",
    "decentralized ott",
    "web3 entertainment",
    "token gated videos",
    "film3 platform",
    "creator economy",
  ]

  web3Terms.forEach((term) => keywords.add(term))

  return Array.from(keywords)
}

export function generateStructuredData(type: "video" | "creator" | "organization", data: any) {
  switch (type) {
    case "video":
      return {
        "@context": "https://schema.org",
        "@type": "VideoObject",
        name: data.title,
        description: data.description,
        thumbnailUrl: data.thumbnail,
        uploadDate: data.createdAt,
        duration: `PT${data.duration}S`,
        contentUrl: data.videoUrl,
        embedUrl: `https://789studios.tv/watch/${data.id}`,
        interactionStatistic: {
          "@type": "InteractionCounter",
          interactionType: { "@type": "WatchAction" },
          userInteractionCount: data.views,
        },
      }

    case "creator":
      return {
        "@context": "https://schema.org",
        "@type": "Person",
        name: data.name,
        description: data.bio,
        image: data.avatar,
        url: `https://789studios.tv/creator/${data.id}`,
        sameAs: [data.socialLinks?.twitter, data.socialLinks?.instagram, data.socialLinks?.website].filter(Boolean),
      }

    case "organization":
      return {
        "@context": "https://schema.org",
        "@type": "Organization",
        name: "789 Studios",
        url: "https://789studios.tv",
        logo: "https://789studios.tv/icon.svg",
        description: "Film3 streaming platform with blockchain-powered content",
        sameAs: ["https://twitter.com/789Studios", "https://github.com/789Studios", "https://discord.gg/789Studios"],
      }
  }
}
