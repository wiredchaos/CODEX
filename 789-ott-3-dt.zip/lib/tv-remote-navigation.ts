export type NavigationDirection = "up" | "down" | "left" | "right" | "select" | "back"

export interface NavigationItem {
  id: string
  element: HTMLElement
  row: number
  col: number
}

export class TVRemoteNavigator {
  private items: NavigationItem[] = []
  private currentIndex = 0
  private onSelect?: (id: string) => void
  private onBack?: () => void

  constructor(options?: { onSelect?: (id: string) => void; onBack?: () => void }) {
    this.onSelect = options?.onSelect
    this.onBack = options?.onBack
  }

  registerItems(items: NavigationItem[]) {
    this.items = items
    this.focusCurrent()
  }

  handleKeyPress(key: string): boolean {
    let handled = true

    switch (key) {
      case "ArrowUp":
        this.move("up")
        break
      case "ArrowDown":
        this.move("down")
        break
      case "ArrowLeft":
        this.move("left")
        break
      case "ArrowRight":
        this.move("right")
        break
      case "Enter":
        this.select()
        break
      case "Escape":
      case "Backspace":
        this.back()
        break
      default:
        handled = false
    }

    return handled
  }

  private move(direction: "up" | "down" | "left" | "right") {
    if (this.items.length === 0) return

    const current = this.items[this.currentIndex]
    let nextIndex = this.currentIndex

    switch (direction) {
      case "up":
        nextIndex = this.findNearest(current, (item) => item.row < current.row)
        break
      case "down":
        nextIndex = this.findNearest(current, (item) => item.row > current.row)
        break
      case "left":
        nextIndex = Math.max(0, this.currentIndex - 1)
        break
      case "right":
        nextIndex = Math.min(this.items.length - 1, this.currentIndex + 1)
        break
    }

    if (nextIndex !== this.currentIndex) {
      this.currentIndex = nextIndex
      this.focusCurrent()
    }
  }

  private findNearest(current: NavigationItem, predicate: (item: NavigationItem) => boolean): number {
    const candidates = this.items.map((item, index) => ({ item, index })).filter(({ item }) => predicate(item))

    if (candidates.length === 0) return this.currentIndex

    const nearest = candidates.reduce((closest, candidate) => {
      const currentDist = Math.abs(current.col - closest.item.col)
      const candidateDist = Math.abs(current.col - candidate.item.col)
      return candidateDist < currentDist ? candidate : closest
    })

    return nearest.index
  }

  private focusCurrent() {
    this.items.forEach((item, index) => {
      if (index === this.currentIndex) {
        item.element.classList.add("tv-focused")
        item.element.scrollIntoView({ behavior: "smooth", block: "center" })
      } else {
        item.element.classList.remove("tv-focused")
      }
    })
  }

  private select() {
    if (this.items[this.currentIndex]) {
      this.onSelect?.(this.items[this.currentIndex].id)
    }
  }

  private back() {
    this.onBack?.()
  }

  destroy() {
    this.items.forEach((item) => item.element.classList.remove("tv-focused"))
    this.items = []
  }
}
