// Market data service for Doginal Dogs and crypto markets
import type { MarketData, NewsItem, MarketListing, MarketSale } from "./types"

// Simulated live market data - in production, this would fetch from APIs
export const mockMarketData: MarketData = {
  doginalDogs: {
    floorPrice: 485000, // in DOGE
    floorPriceUsd: 2021.62,
    volume24h: 8975000, // in DOGE
    volume7d: 37490000,
    volume30d: 103700000,
    volumeAllTime: 3708000000,
    owners: 2847,
    listed: 342,
    sales24h: 18,
    avgPrice24h: 498500,
    priceChange24h: 4.2,
    priceChange7d: -2.8,
  },
  dogecoin: {
    price: 0.417,
    priceChange24h: 2.1,
    marketCap: 61200000000,
    volume24h: 2890000000,
  },
  lastUpdated: new Date(),
}

export const mockNewsItems: NewsItem[] = [
  {
    id: "news-1",
    title: "Doginal Dogs Surge From Free Mint to $5K Floor, Backed by Celebrity Support",
    description:
      "The Doginal Dogs NFT collection has seen remarkable growth since its free mint, now trading at floor prices exceeding $2,000 with strong community backing.",
    url: "https://www.nasdaq.com/press-release/doginal-dogs-surge-free-mint-5k-floor-backed-celebrity-support-2025-09-18",
    source: "NASDAQ",
    sourceIcon: "/nasdaq-logo.jpg",
    category: "nft",
    publishedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
  },
  {
    id: "news-2",
    title: "Dogecoin Network Activity Hits All-Time High as Ordinals Adoption Grows",
    description:
      "Dogecoin blockchain sees unprecedented transaction volume as Doginals (Dogecoin NFTs) continue to gain mainstream adoption.",
    url: "#",
    source: "CoinDesk",
    sourceIcon: "/coindesk-logo.jpg",
    category: "crypto",
    publishedAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
  },
  {
    id: "news-3",
    title: "Bitcoin ETF Inflows Reach Record $1.2B in Single Day",
    description:
      "Institutional investors continue to pour capital into spot Bitcoin ETFs, signaling strong institutional demand for crypto assets.",
    url: "#",
    source: "Bloomberg",
    sourceIcon: "/bloomberg-logo.jpg",
    category: "market",
    publishedAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
  },
  {
    id: "news-4",
    title: "SEC Approves New Framework for NFT Securities Classification",
    description:
      "The Securities and Exchange Commission releases guidance on when NFTs may be considered securities, providing clarity for creators.",
    url: "#",
    source: "Reuters",
    sourceIcon: "/reuters-logo.jpg",
    category: "regulation",
    publishedAt: new Date(Date.now() - 8 * 60 * 60 * 1000),
  },
  {
    id: "news-5",
    title: "Web3 Streaming Platforms See 300% Growth in Q4",
    description:
      "Decentralized streaming platforms and Film3 initiatives are experiencing explosive growth as creators seek alternative revenue models.",
    url: "#",
    source: "The Block",
    sourceIcon: "/theblock-logo.jpg",
    category: "defi",
    publishedAt: new Date(Date.now() - 10 * 60 * 60 * 1000),
  },
  {
    id: "news-6",
    title: "Ethereum Layer 2 Solutions Process 10M Daily Transactions",
    description:
      "Combined L2 networks hit milestone transaction volume, demonstrating scalability improvements for the Ethereum ecosystem.",
    url: "#",
    source: "CoinTelegraph",
    sourceIcon: "/cointelegraph-logo.jpg",
    category: "crypto",
    publishedAt: new Date(Date.now() - 12 * 60 * 60 * 1000),
  },
  {
    id: "news-7",
    title: "Major Studio Announces First Fully On-Chain Animated Series",
    description:
      "A breakthrough in entertainment as a major studio commits to releasing an animated series with all royalties distributed via smart contracts.",
    url: "#",
    source: "Variety",
    sourceIcon: "/variety-logo.jpg",
    category: "nft",
    publishedAt: new Date(Date.now() - 14 * 60 * 60 * 1000),
  },
  {
    id: "news-8",
    title: "Fed Signals Crypto-Friendly Banking Guidelines Coming in 2025",
    description:
      "Federal Reserve hints at clearer regulations for banks engaging with cryptocurrency businesses, potentially opening new custody options.",
    url: "#",
    source: "CNBC",
    sourceIcon: "/cnbc-logo.jpg",
    category: "regulation",
    publishedAt: new Date(Date.now() - 16 * 60 * 60 * 1000),
  },
]

export const mockListings: MarketListing[] = [
  {
    id: "listing-1",
    inscriptionId: "dd-7891",
    name: "Doginal Dog #7891",
    image: "/pixel-dog-rare-golden.jpg",
    price: 520000,
    priceUsd: 2168.4,
    seller: "DQn8...x4Rp",
    listedAt: new Date(Date.now() - 15 * 60 * 1000),
    rarity: "Rare",
  },
  {
    id: "listing-2",
    inscriptionId: "dd-2345",
    name: "Doginal Dog #2345",
    image: "/pixel-dog-legendary-crown.jpg",
    price: 1250000,
    priceUsd: 5212.5,
    seller: "DRk7...m2Wp",
    listedAt: new Date(Date.now() - 32 * 60 * 1000),
    rarity: "Legendary",
  },
  {
    id: "listing-3",
    inscriptionId: "dd-5678",
    name: "Doginal Dog #5678",
    image: "/pixel-dog-epic-laser-eyes.jpg",
    price: 780000,
    priceUsd: 3252.6,
    seller: "DTx9...k8Np",
    listedAt: new Date(Date.now() - 48 * 60 * 1000),
    rarity: "Epic",
  },
  {
    id: "listing-4",
    inscriptionId: "dd-9012",
    name: "Doginal Dog #9012",
    image: "/pixel-dog-uncommon-hat.jpg",
    price: 495000,
    priceUsd: 2064.15,
    seller: "DWv3...p5Qr",
    listedAt: new Date(Date.now() - 67 * 60 * 1000),
    rarity: "Uncommon",
  },
  {
    id: "listing-5",
    inscriptionId: "dd-3456",
    name: "Doginal Dog #3456",
    image: "/pixel-dog-common-blue.jpg",
    price: 485000,
    priceUsd: 2022.45,
    seller: "DYz1...n3Ts",
    listedAt: new Date(Date.now() - 89 * 60 * 1000),
    rarity: "Common",
  },
]

export const mockRecentSales: MarketSale[] = [
  {
    id: "sale-1",
    inscriptionId: "dd-1234",
    name: "Doginal Dog #1234",
    image: "/pixel-dog-epic-sunglasses.jpg",
    price: 875000,
    priceUsd: 3648.75,
    buyer: "DPm4...v7Ks",
    seller: "DQn8...x4Rp",
    soldAt: new Date(Date.now() - 12 * 60 * 1000),
  },
  {
    id: "sale-2",
    inscriptionId: "dd-6789",
    name: "Doginal Dog #6789",
    image: "/pixel-dog-rare-hoodie.jpg",
    price: 542000,
    priceUsd: 2260.14,
    buyer: "DRk7...m2Wp",
    seller: "DTx9...k8Np",
    soldAt: new Date(Date.now() - 45 * 60 * 1000),
  },
  {
    id: "sale-3",
    inscriptionId: "dd-4321",
    name: "Doginal Dog #4321",
    image: "/placeholder.svg?height=200&width=200",
    price: 1850000,
    priceUsd: 7714.5,
    buyer: "DWv3...p5Qr",
    seller: "DYz1...n3Ts",
    soldAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
  },
]

// RSS Feed sources for crypto news
export const rssFeedSources = [
  { name: "Bloomberg Crypto", url: "https://www.bloomberg.com/crypto", icon: "bloomberg" },
  { name: "CoinDesk", url: "https://www.coindesk.com/arc/outboundfeeds/rss/", icon: "coindesk" },
  { name: "CoinTelegraph", url: "https://cointelegraph.com/rss", icon: "cointelegraph" },
  { name: "The Block", url: "https://www.theblock.co/rss.xml", icon: "theblock" },
  { name: "Decrypt", url: "https://decrypt.co/feed", icon: "decrypt" },
  { name: "NASDAQ Crypto", url: "https://www.nasdaq.com/topics/cryptocurrency", icon: "nasdaq" },
  { name: "Reuters Crypto", url: "https://www.reuters.com/technology/cryptocurrency/", icon: "reuters" },
  { name: "CNBC Crypto", url: "https://www.cnbc.com/cryptoworld/", icon: "cnbc" },
]

// Function to format time ago
export function timeAgo(date: Date): string {
  const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000)

  if (seconds < 60) return `${seconds}s ago`
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`
  return `${Math.floor(seconds / 86400)}d ago`
}

// Format DOGE amount
export function formatDoge(amount: number): string {
  if (amount >= 1000000) return `${(amount / 1000000).toFixed(2)}M`
  if (amount >= 1000) return `${(amount / 1000).toFixed(1)}K`
  return amount.toLocaleString()
}

// Format USD
export function formatUsd(amount: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
  }).format(amount)
}
