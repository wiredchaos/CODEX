// Core royalty types for 789 Studios OTT + DD CARTOONS

export type RoyaltySplit = {
  studio: number // e.g., 0.4
  creator: number // 0.2
  nftHolder: number // 0.2
  treasury: number // 0.1
  stakers: number // 0.1
}

export interface EpisodeRoyaltyMeta {
  episodeId: string
  totalRevenueUsd: number
  split: RoyaltySplit
  lastUpdated: string // ISO date
  source: "mock" | "db" | "chain" | "hybrid"
}

export interface RoyaltyDistribution {
  studio: number
  creator: number
  nftHolder: number
  treasury: number
  stakers: number
}

// Pre-configured 40/20/20/10/10 split
export const DEFAULT_SPLIT: RoyaltySplit = {
  studio: 0.4,
  creator: 0.2,
  nftHolder: 0.2,
  treasury: 0.1,
  stakers: 0.1,
}

export interface StudioTier {
  tier: 0 | 1 | 2 | 3
  name: "Viewer" | "Member" | "Premium" | "Executive"
  minStake: number
  minLockDays: number
}

export const STUDIO_TIERS: StudioTier[] = [
  { tier: 0, name: "Viewer", minStake: 0, minLockDays: 0 },
  { tier: 1, name: "Member", minStake: 100, minLockDays: 30 },
  { tier: 2, name: "Premium", minStake: 1000, minLockDays: 60 },
  { tier: 3, name: "Executive", minStake: 10000, minLockDays: 90 },
]
