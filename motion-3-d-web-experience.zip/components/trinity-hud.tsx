"use client"

import { useState, useEffect } from "react"
import type { Realm } from "@/lib/trinity-core"

interface TrinityHUDProps {
  patchId: string
  patchRealm: Realm
  kind: "lobby" | "chamber" | "vault" | "portal"
}

/**
 * WIRED CHAOS META - Trinity HUD
 * Hotspot and navigation overlay supplied by Trinity Core
 * Read-only interface, no scene generation
 */
export default function TrinityHUD({ patchId, patchRealm, kind }: TrinityHUDProps) {
  const [hotspots] = useState([
    { id: "hs-001", label: "NETERU", position: { x: 20, y: 30 } },
    { id: "hs-002", label: "SIGNAL ERA", position: { x: 75, y: 45 } },
    { id: "hs-003", label: "RVP", position: { x: 50, y: 70 } },
  ])

  const [activeHotspot, setActiveHotspot] = useState<string | null>(null)
  const [telemetry, setTelemetry] = useState({
    fps: 60,
    loadTime: 0,
    hemisphere: "NEURALIS",
  })

  useEffect(() => {
    const startTime = Date.now()
    const interval = setInterval(() => {
      setTelemetry((prev) => ({
        ...prev,
        loadTime: Math.floor((Date.now() - startTime) / 1000),
        fps: Math.floor(55 + Math.random() * 10),
      }))
    }, 1000)

    return () => clearInterval(interval)
  }, [])

  return (
    <>
      <div className="fixed inset-0 pointer-events-none">
        {/* Hotspots */}
        {hotspots.map((hotspot) => (
          <div
            key={hotspot.id}
            className="absolute pointer-events-auto cursor-pointer"
            style={{
              left: `${hotspot.position.x}%`,
              top: `${hotspot.position.y}%`,
              transform: "translate(-50%, -50%)",
            }}
            onMouseEnter={() => setActiveHotspot(hotspot.id)}
            onMouseLeave={() => setActiveHotspot(null)}
          >
            <div className="relative">
              <div className="w-3 h-3 bg-primary rounded-full animate-pulse" />
              {activeHotspot === hotspot.id && (
                <div className="absolute left-6 top-0 bg-card/95 backdrop-blur-sm border border-border rounded px-3 py-2 whitespace-nowrap">
                  <p className="text-xs font-mono text-card-foreground">{hotspot.label}</p>
                  <p className="text-xs text-muted-foreground">Timeline Door</p>
                </div>
              )}
            </div>
          </div>
        ))}

        {/* Corner HUD */}
        <div className="absolute top-4 right-4 bg-card/90 backdrop-blur-sm border border-border rounded-lg p-3 pointer-events-auto">
          <div className="space-y-1.5 text-xs font-mono">
            <div className="flex items-center justify-between gap-3">
              <span className="text-muted-foreground">PATCH</span>
              <span className="text-card-foreground">{patchId}</span>
            </div>
            <div className="flex items-center justify-between gap-3">
              <span className="text-muted-foreground">REALM</span>
              <span className="text-card-foreground uppercase">{patchRealm}</span>
            </div>
            <div className="flex items-center justify-between gap-3">
              <span className="text-muted-foreground">ENV</span>
              <span className="text-card-foreground uppercase">{kind}</span>
            </div>
            <div className="h-px bg-border my-1.5" />
            <div className="flex items-center justify-between gap-3">
              <span className="text-muted-foreground">FPS</span>
              <span className="text-primary">{telemetry.fps}</span>
            </div>
            <div className="flex items-center justify-between gap-3">
              <span className="text-muted-foreground">UPTIME</span>
              <span className="text-primary">{telemetry.loadTime}s</span>
            </div>
          </div>
        </div>

        {/* Bottom status bar */}
        <div className="absolute bottom-0 left-0 right-0 bg-card/80 backdrop-blur-sm border-t border-border p-2">
          <div className="flex items-center justify-between text-xs font-mono">
            <div className="flex items-center gap-4">
              <span className="text-primary">⚡ TRINITY CORE MOUNTED</span>
              <span className="text-muted-foreground">READ ONLY</span>
              <span className="text-muted-foreground">NO GENERATION</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              <span className="text-muted-foreground">Akira Codex Active</span>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
