"use client"

import { Suspense } from "react"
import { Canvas } from "@react-three/fiber"
import { Environment, Sky } from "@react-three/drei"
import Scene from "./scene"
import LoadingScreen from "./loading-screen"

interface EnvironmentRendererProps {
  patchId: string
  kind: "lobby" | "chamber" | "vault" | "portal"
  fallback?: "video" | "none"
}

/**
 * WIRED CHAOS META - Environment Renderer
 * Cinematic 3D environment consumer component
 * Mounts to Trinity Core (read-only, no generation)
 */
export default function EnvironmentRenderer({ patchId, kind, fallback = "none" }: EnvironmentRendererProps) {
  console.log("[v0] EnvironmentRenderer mounting", { patchId, kind, fallback })

  return (
    <div className="relative w-full h-screen overflow-hidden bg-background">
      <Canvas camera={{ position: [0, 0, 5], fov: 50 }} gl={{ antialias: true, alpha: false }} dpr={[1, 2]}>
        <Suspense fallback={null}>
          {kind === "lobby" && (
            <>
              <ambientLight intensity={0.4} />
              <pointLight position={[10, 10, 10]} intensity={0.6} />
              <pointLight position={[-10, -10, -5]} intensity={0.4} color="#ff6b35" />
              <spotLight position={[0, 5, 5]} intensity={0.3} angle={0.6} penumbra={1} />
            </>
          )}

          {kind === "chamber" && (
            <>
              <ambientLight intensity={0.3} />
              <pointLight position={[5, 8, 5]} intensity={0.8} color="#4488ff" />
              <pointLight position={[-5, -8, -5]} intensity={0.5} color="#ff4488" />
            </>
          )}

          {kind === "vault" && (
            <>
              <ambientLight intensity={0.2} />
              <spotLight position={[0, 10, 0]} intensity={1.2} angle={0.5} penumbra={0.8} color="#ffffff" />
            </>
          )}

          {kind === "portal" && (
            <>
              <ambientLight intensity={0.5} />
              <pointLight position={[0, 5, 8]} intensity={1.0} color="#00ffff" />
              <Sky sunPosition={[100, 20, 100]} />
            </>
          )}

          <Scene />

          <Environment preset="warehouse" />
        </Suspense>
      </Canvas>

      {fallback === "video" && (
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute bottom-4 right-4 bg-muted/80 px-3 py-1 rounded text-xs font-mono text-muted-foreground backdrop-blur-sm">
            3D ENVIRONMENT ACTIVE • Video fallback ready
          </div>
        </div>
      )}

      <LoadingScreen />
    </div>
  )
}
