"use client"

import { useEffect, useState } from "react"
import { TrinityMount, type Realm, type TrinityFloor, type Timeline } from "@/lib/trinity-core"

interface TrinityFloorMountProps {
  floorId: string
  patchRealm: Realm
  patchId: string
  onMount?: (mount: TrinityMount) => void
}

export default function TrinityFloorMountComponent({ floorId, patchRealm, patchId, onMount }: TrinityFloorMountProps) {
  const [mount, setMount] = useState<TrinityMount | null>(null)
  const [floor, setFloor] = useState<TrinityFloor | undefined>()
  const [timeline, setTimeline] = useState<Timeline | undefined>()
  const [accessibleTimelines, setAccessibleTimelines] = useState<Timeline[]>([])
  const [selectedTimelineId, setSelectedTimelineId] = useState<string>("")

  useEffect(() => {
    console.log("[v0] Initializing Trinity Floor Mount", { floorId, patchRealm, patchId })

    try {
      const trinityMount = new TrinityMount(floorId, patchRealm)
      setMount(trinityMount)

      const mountedFloor = trinityMount.getFloor()
      setFloor(mountedFloor)

      const accessible = trinityMount.getAccessibleTimelines()
      setAccessibleTimelines(accessible)

      if (accessible.length > 0) {
        setSelectedTimelineId(accessible[0].id)
      }

      onMount?.(trinityMount)
    } catch (error) {
      console.error("[v0] Trinity Mount initialization failed:", error)
    }
  }, [floorId, patchRealm, patchId, onMount])

  const handleTimelineMount = () => {
    if (!mount || !selectedTimelineId) return

    const success = mount.mountToTimeline(selectedTimelineId)
    if (success) {
      const mountedTimeline = mount.getTimeline()
      setTimeline(mountedTimeline)
    }
  }

  if (!mount || !floor) {
    return (
      <div className="fixed bottom-4 left-4 bg-destructive/90 text-destructive-foreground p-4 rounded-lg backdrop-blur-sm">
        <p className="text-sm font-mono">TRINITY MOUNT ERROR: Floor not found in registry</p>
      </div>
    )
  }

  return (
    <div className="fixed bottom-4 left-4 bg-card/90 text-card-foreground p-4 rounded-lg backdrop-blur-sm border border-border max-w-sm">
      <div className="space-y-3">
        <div>
          <p className="text-xs font-mono text-muted-foreground uppercase mb-1">Trinity Core Status</p>
          <p className="text-sm font-medium">READ ONLY • DECLARATIVE MOUNT</p>
        </div>

        <div>
          <p className="text-xs font-mono text-muted-foreground mb-1">Patch ID</p>
          <p className="text-sm font-mono">{patchId}</p>
        </div>

        <div>
          <p className="text-xs font-mono text-muted-foreground mb-1">Realm Assignment</p>
          <p className="text-sm font-mono uppercase">{patchRealm}</p>
        </div>

        <div>
          <p className="text-xs font-mono text-muted-foreground mb-1">Trinity Floor</p>
          <p className="text-sm font-medium">{floor.name}</p>
          <p className="text-xs font-mono text-muted-foreground">
            {floor.locked ? "🔒 LOCKED" : "UNLOCKED"} • {floor.id}
          </p>
        </div>

        {accessibleTimelines.length > 0 && (
          <div>
            <p className="text-xs font-mono text-muted-foreground mb-2">Timeline Access (Akira Codex)</p>
            <select
              value={selectedTimelineId}
              onChange={(e) => setSelectedTimelineId(e.target.value)}
              className="w-full bg-background border border-border rounded px-2 py-1 text-sm font-mono mb-2"
            >
              {accessibleTimelines.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name} {t.akiraCodexAccess ? "🔐" : ""}
                </option>
              ))}
            </select>

            {!timeline && (
              <button
                onClick={handleTimelineMount}
                className="w-full bg-primary text-primary-foreground px-3 py-1.5 rounded text-sm font-medium hover:bg-primary/90 transition-colors"
              >
                Mount to Timeline
              </button>
            )}

            {timeline && (
              <div className="bg-primary/10 border border-primary/20 rounded p-2">
                <p className="text-xs font-mono text-muted-foreground mb-1">Mounted Timeline</p>
                <p className="text-sm font-medium">{timeline.name}</p>
                <p className="text-xs font-mono text-muted-foreground">
                  Sequence: {timeline.sequence} • {timeline.realm.toUpperCase()}
                </p>
              </div>
            )}
          </div>
        )}

        {accessibleTimelines.length === 0 && (
          <div className="bg-destructive/10 border border-destructive/20 rounded p-2">
            <p className="text-xs font-mono text-destructive">NO ACCESSIBLE TIMELINES • Akira Codex firewall active</p>
          </div>
        )}

        <div className="pt-2 border-t border-border">
          <p className="text-xs font-mono text-muted-foreground">⚡ Consumer patch • No generation • Trinity locked</p>
        </div>
      </div>
    </div>
  )
}
