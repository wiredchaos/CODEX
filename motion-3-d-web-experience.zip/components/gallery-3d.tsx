"use client"

import { Canvas } from "@react-three/fiber"
import { Suspense } from "react"
import Scene from "./scene"
import Overlay from "./overlay"
import LoadingScreen from "./loading-screen"

export default function Gallery3D() {
  return (
    <div className="relative w-full h-screen overflow-hidden bg-background">
      <Canvas camera={{ position: [0, 0, 5], fov: 50 }} gl={{ antialias: true, alpha: false }}>
        <Suspense fallback={null}>
          <Scene />
        </Suspense>
      </Canvas>
      <Overlay />
      <LoadingScreen />
    </div>
  )
}
