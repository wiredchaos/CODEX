import EnvironmentRenderer from "@/components/environment-renderer"
import TrinityFloorMountComponent from "@/components/trinity-floor-mount"
import TrinityHUD from "@/components/trinity-hud"

export default function Home() {
  return (
    <>
      <EnvironmentRenderer patchId="CLEAR" kind="lobby" fallback="video" />

      <TrinityHUD patchId="CLEAR" patchRealm="neuralis" kind="lobby" />

      <TrinityFloorMountComponent floorId="trinity-floor-001" patchRealm="neuralis" patchId="CLEAR" />
    </>
  )
}
