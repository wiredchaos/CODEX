-- Studio 789 Database Schema
-- Realm: business
-- Schema: business_789
--
-- Run this script to create the database tables for Studio 789 OTT platform.

-- Create schema for business realm isolation
CREATE SCHEMA IF NOT EXISTS business_789;

-- Content catalog table
CREATE TABLE IF NOT EXISTS business_789.content (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug VARCHAR(255) UNIQUE NOT NULL,
  title VARCHAR(500) NOT NULL,
  description TEXT,
  category VARCHAR(50) NOT NULL,
  tags TEXT[] DEFAULT '{}',
  thumbnail_url TEXT,
  video_url TEXT,
  duration_seconds INTEGER,
  release_date DATE,
  rating VARCHAR(10),
  featured BOOLEAN DEFAULT FALSE,
  hemisphere_neuralis INTEGER DEFAULT 50,
  hemisphere_chaosphere INTEGER DEFAULT 50,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Crew/cast table
CREATE TABLE IF NOT EXISTS business_789.content_crew (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  content_id UUID REFERENCES business_789.content(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  role VARCHAR(100) NOT NULL,
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- User subscriptions table
CREATE TABLE IF NOT EXISTS business_789.subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  stripe_customer_id VARCHAR(255),
  stripe_subscription_id VARCHAR(255),
  tier VARCHAR(50) NOT NULL,
  status VARCHAR(50) NOT NULL DEFAULT 'active',
  current_period_start TIMESTAMPTZ,
  current_period_end TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- User library (saved content)
CREATE TABLE IF NOT EXISTS business_789.user_library (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  content_id UUID REFERENCES business_789.content(id) ON DELETE CASCADE,
  added_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, content_id)
);

-- Watch history for recommendations
CREATE TABLE IF NOT EXISTS business_789.watch_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  content_id UUID REFERENCES business_789.content(id) ON DELETE CASCADE,
  progress_seconds INTEGER DEFAULT 0,
  completed BOOLEAN DEFAULT FALSE,
  last_watched_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, content_id)
);

-- AI crew chat history
CREATE TABLE IF NOT EXISTS business_789.crew_conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  crew_id VARCHAR(50) NOT NULL,
  content_id UUID REFERENCES business_789.content(id) ON DELETE SET NULL,
  messages JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_content_category ON business_789.content(category);
CREATE INDEX IF NOT EXISTS idx_content_featured ON business_789.content(featured) WHERE featured = TRUE;
CREATE INDEX IF NOT EXISTS idx_content_slug ON business_789.content(slug);
CREATE INDEX IF NOT EXISTS idx_subscriptions_user ON business_789.subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_library_user ON business_789.user_library(user_id);
CREATE INDEX IF NOT EXISTS idx_history_user ON business_789.watch_history(user_id);
CREATE INDEX IF NOT EXISTS idx_conversations_user ON business_789.crew_conversations(user_id);

-- Row Level Security (RLS) policies
ALTER TABLE business_789.subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE business_789.user_library ENABLE ROW LEVEL SECURITY;
ALTER TABLE business_789.watch_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE business_789.crew_conversations ENABLE ROW LEVEL SECURITY;

-- Users can only see their own data
CREATE POLICY "Users can view own subscriptions"
  ON business_789.subscriptions FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can view own library"
  ON business_789.user_library FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can manage own library"
  ON business_789.user_library FOR ALL
  USING (auth.uid() = user_id);

CREATE POLICY "Users can view own watch history"
  ON business_789.watch_history FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own watch history"
  ON business_789.watch_history FOR ALL
  USING (auth.uid() = user_id);

CREATE POLICY "Users can view own conversations"
  ON business_789.crew_conversations FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can manage own conversations"
  ON business_789.crew_conversations FOR ALL
  USING (auth.uid() = user_id);

-- Public content is viewable by all
CREATE POLICY "Content is publicly viewable"
  ON business_789.content FOR SELECT
  TO PUBLIC
  USING (TRUE);

CREATE POLICY "Crew is publicly viewable"
  ON business_789.content_crew FOR SELECT
  TO PUBLIC
  USING (TRUE);
