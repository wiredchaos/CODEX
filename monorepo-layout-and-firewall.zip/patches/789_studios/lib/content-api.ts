/**
 * Studio 789 Content API Client
 *
 * Client-side functions for fetching content from the API.
 *
 * @realm business
 * @patch 789_studios
 */

import type { OTTContent } from "../data/ott-content"

const API_BASE = "/api/business/789"

export interface ContentListResponse {
  data: OTTContent[]
  meta: {
    total: number
    limit: number
    offset: number
    hasMore: boolean
  }
}

export interface ContentDetailResponse {
  data: OTTContent
  playback: {
    authorized: boolean
    expiresAt: string
    quality: string[]
  }
}

/**
 * Fetch content list with optional filters
 */
export async function fetchContentList(params?: {
  category?: string
  query?: string
  featured?: boolean
  limit?: number
  offset?: number
}): Promise<ContentListResponse> {
  const searchParams = new URLSearchParams()

  if (params?.category) searchParams.set("category", params.category)
  if (params?.query) searchParams.set("q", params.query)
  if (params?.featured) searchParams.set("featured", "true")
  if (params?.limit) searchParams.set("limit", params.limit.toString())
  if (params?.offset) searchParams.set("offset", params.offset.toString())

  const response = await fetch(`${API_BASE}/content?${searchParams.toString()}`)

  if (!response.ok) {
    throw new Error(`Failed to fetch content: ${response.statusText}`)
  }

  return response.json()
}

/**
 * Fetch single content item with playback authorization
 */
export async function fetchContentDetail(id: string): Promise<ContentDetailResponse> {
  const response = await fetch(`${API_BASE}/content/${id}`)

  if (!response.ok) {
    if (response.status === 404) {
      throw new Error("Content not found")
    }
    if (response.status === 403) {
      throw new Error("Access denied - subscription required")
    }
    throw new Error(`Failed to fetch content: ${response.statusText}`)
  }

  return response.json()
}

/**
 * SWR fetcher for content list
 */
export const contentListFetcher = async (url: string): Promise<ContentListResponse> => {
  const response = await fetch(url)
  if (!response.ok) throw new Error("Failed to fetch")
  return response.json()
}

/**
 * SWR fetcher for content detail
 */
export const contentDetailFetcher = async (url: string): Promise<ContentDetailResponse> => {
  const response = await fetch(url)
  if (!response.ok) throw new Error("Failed to fetch")
  return response.json()
}
