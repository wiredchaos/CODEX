"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import { firewall, type Realm } from "@/packages/firewall"
import { telemetryBus, type HemisphereScore } from "@/packages/telemetry-bus"
import { useElevator } from "@/packages/trinity-core/elevator"

// Studio 789 Context
interface Studio789Context {
  realm: Realm
  isAuthenticated: boolean
  subscription: {
    tier: string | null
    active: boolean
  }
  hemisphereScore: HemisphereScore
  setUser: (userId: string) => void
}

const Studio789Context = createContext<Studio789Context | null>(null)

export function Studio789Provider({ children }: { children: React.ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [subscription, setSubscription] = useState<{ tier: string | null; active: boolean }>({
    tier: null,
    active: false,
  })
  const [hemisphereScore, setHemisphereScore] = useState<HemisphereScore>({
    neuralis: 50,
    chaosphere: 50,
    total: 100,
    dominant: "neuralis",
  })

  const { registerFloor } = useElevator()

  useEffect(() => {
    // Set realm context for firewall
    firewall.setRealm("business")

    registerFloor({
      id: "floor_789",
      name: "Studio 789",
      patchId: "789_studios",
      realm: "business",
      locked: false,
      requiredRole: undefined,
    })

    // Subscribe to hemisphere score updates
    const unsubscribe = telemetryBus.onAll((event) => {
      if (event.hemisphere) {
        setHemisphereScore(telemetryBus.getHemisphereScore())
      }
    })

    // Check authentication status (would call actual auth API)
    // For now, mock as unauthenticated
    setIsAuthenticated(false)

    return () => {
      unsubscribe()
    }
  }, [registerFloor])

  const setUser = (userId: string) => {
    telemetryBus.setUser(userId)
    setIsAuthenticated(true)
  }

  return (
    <Studio789Context.Provider
      value={{
        realm: "business",
        isAuthenticated,
        subscription,
        hemisphereScore,
        setUser,
      }}
    >
      {children}
    </Studio789Context.Provider>
  )
}

export function useStudio789() {
  const context = useContext(Studio789Context)
  if (!context) {
    throw new Error("useStudio789 must be used within Studio789Provider")
  }
  return context
}

// Re-export telemetry hook for convenience
export { useTelemetry } from "@/packages/telemetry-bus"
export { useFirewall } from "@/packages/firewall"
