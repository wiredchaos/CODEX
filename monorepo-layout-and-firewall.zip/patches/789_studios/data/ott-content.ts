/**
 * Studio 789 OTT Content Catalog
 *
 * Static content data for the streaming platform.
 * In production, this would be fetched from Supabase via the content API.
 *
 * @realm business
 * @patch 789_studios
 */

export interface OTTContent {
  id: string
  title: string
  description: string
  category: "originals" | "documentaries" | "series" | "films" | "shorts" | "live"
  tags: string[]
  thumbnail: string
  videoUrl: string
  duration: string
  releaseDate: string
  rating?: string
  featured: boolean
  crew?: { name: string; role: string }[]
  hemisphereScore?: {
    neuralis: number
    chaosphere: number
  }
}

export const ottContent: OTTContent[] = [
  {
    id: "wc-origins",
    title: "WIRED CHAOS: Origins",
    description:
      "The untold story of how the multiverse began. Follow the architects as they build the first realm bridges and discover the true nature of consciousness.",
    category: "originals",
    tags: ["sci-fi", "drama", "multiverse", "premium"],
    thumbnail: "/cyberpunk-city-origins-neon-purple.jpg",
    videoUrl: "/demo/wc-origins.mp4",
    duration: "2h 15m",
    releaseDate: "2025",
    rating: "TV-MA",
    featured: true,
    crew: [
      { name: "Aria Vex", role: "Director" },
      { name: "Marcus Chen", role: "Writer" },
      { name: "Nova Sterling", role: "Lead" },
    ],
    hemisphereScore: { neuralis: 75, chaosphere: 25 },
  },
  {
    id: "realm-walkers",
    title: "Realm Walkers",
    description:
      "A documentary series exploring the boundaries between business and Akashic realms. What separates reality from belief?",
    category: "documentaries",
    tags: ["documentary", "philosophy", "realms"],
    thumbnail: "/ethereal-portal-documentary-style.jpg",
    videoUrl: "/demo/realm-walkers.mp4",
    duration: "45m",
    releaseDate: "2025",
    rating: "TV-PG",
    featured: true,
    crew: [
      { name: "Dr. Elena Voss", role: "Host" },
      { name: "James Wright", role: "Director" },
    ],
    hemisphereScore: { neuralis: 50, chaosphere: 50 },
  },
  {
    id: "neural-network",
    title: "Neural Network",
    description:
      "Eight strangers wake up connected to the same AI consciousness. Their choices determine the fate of the network—and themselves.",
    category: "series",
    tags: ["thriller", "sci-fi", "AI", "mystery"],
    thumbnail: "/neural-network-sci-fi-thriller-blue.jpg",
    videoUrl: "/demo/neural-network.mp4",
    duration: "S1 • 8 Episodes",
    releaseDate: "2025",
    rating: "TV-MA",
    featured: true,
    crew: [
      { name: "Ryan Torres", role: "Showrunner" },
      { name: "Kai Nakamura", role: "Lead" },
    ],
    hemisphereScore: { neuralis: 85, chaosphere: 15 },
  },
  {
    id: "chaos-theory",
    title: "Chaos Theory",
    description:
      "When a quantum physicist discovers she can see alternate timelines, she must choose which reality to save.",
    category: "films",
    tags: ["sci-fi", "drama", "quantum", "thriller"],
    thumbnail: "/quantum-physics-woman-multiple-realities.jpg",
    videoUrl: "/demo/chaos-theory.mp4",
    duration: "1h 52m",
    releaseDate: "2024",
    rating: "PG-13",
    featured: false,
    crew: [
      { name: "Sofia Reyes", role: "Director" },
      { name: "Emma Liu", role: "Lead" },
    ],
    hemisphereScore: { neuralis: 40, chaosphere: 60 },
  },
  {
    id: "signal-lost",
    title: "Signal Lost",
    description: "A short film about connection in a disconnected world. When all networks fail, what remains?",
    category: "shorts",
    tags: ["drama", "experimental", "silent"],
    thumbnail: "/disconnected-world-static-signal-art-film.jpg",
    videoUrl: "/demo/signal-lost.mp4",
    duration: "18m",
    releaseDate: "2024",
    rating: "TV-PG",
    featured: false,
    hemisphereScore: { neuralis: 30, chaosphere: 70 },
  },
  {
    id: "live-chaos-summit",
    title: "CHAOS Summit 2025",
    description:
      "Live from the Neuralis Hub: keynotes, panels, and announcements from the annual WIRED CHAOS META summit.",
    category: "live",
    tags: ["live", "event", "conference", "tech"],
    thumbnail: "/futuristic-conference-stage-neon-lights.jpg",
    videoUrl: "/demo/live-placeholder.mp4",
    duration: "Live",
    releaseDate: "2025",
    featured: true,
    hemisphereScore: { neuralis: 60, chaosphere: 40 },
  },
  {
    id: "architects",
    title: "The Architects",
    description:
      "Meet the builders of the WIRED CHAOS infrastructure. A behind-the-scenes look at creating a digital multiverse.",
    category: "documentaries",
    tags: ["documentary", "tech", "creators", "behind-the-scenes"],
    thumbnail: "/developers-working-holographic-displays.jpg",
    videoUrl: "/demo/architects.mp4",
    duration: "1h 20m",
    releaseDate: "2024",
    rating: "TV-PG",
    featured: false,
    crew: [{ name: "Alex Kim", role: "Director" }],
    hemisphereScore: { neuralis: 80, chaosphere: 20 },
  },
  {
    id: "echo-chamber",
    title: "Echo Chamber",
    description:
      "A psychological thriller about a podcaster who discovers her listeners are living in a simulation she accidentally created.",
    category: "films",
    tags: ["thriller", "psychological", "simulation", "horror"],
    thumbnail: "/woman-podcast-microphone-dark-sinister.jpg",
    videoUrl: "/demo/echo-chamber.mp4",
    duration: "1h 45m",
    releaseDate: "2024",
    rating: "R",
    featured: false,
    crew: [
      { name: "Jordan Blake", role: "Director" },
      { name: "Mia Santos", role: "Lead" },
    ],
    hemisphereScore: { neuralis: 20, chaosphere: 80 },
  },
  {
    id: "byte-sized",
    title: "Byte-Sized",
    description:
      "Animated shorts exploring life inside the WIRED CHAOS systems. Each episode follows a different character.",
    category: "shorts",
    tags: ["animation", "comedy", "anthology"],
    thumbnail: "/cute-animated-characters-digital-world.jpg",
    videoUrl: "/demo/byte-sized.mp4",
    duration: "8-12m each",
    releaseDate: "2025",
    rating: "TV-Y7",
    featured: false,
    hemisphereScore: { neuralis: 55, chaosphere: 45 },
  },
  {
    id: "frequency",
    title: "Frequency",
    description:
      "A musician discovers that certain frequencies can open portals between realms. Now she must protect her gift from those who would exploit it.",
    category: "series",
    tags: ["fantasy", "music", "drama", "mystery"],
    thumbnail: "/woman-musician-glowing-sound-waves-portal.jpg",
    videoUrl: "/demo/frequency.mp4",
    duration: "S1 • 10 Episodes",
    releaseDate: "2025",
    rating: "TV-14",
    featured: true,
    crew: [
      { name: "Lena Park", role: "Creator" },
      { name: "Zara Ahmed", role: "Lead" },
    ],
    hemisphereScore: { neuralis: 45, chaosphere: 55 },
  },
  {
    id: "gridlock",
    title: "Gridlock",
    description:
      "In a city where traffic is controlled by AI, one driver discovers a backdoor that could free humanity—or destroy it.",
    category: "originals",
    tags: ["action", "sci-fi", "AI", "thriller"],
    thumbnail: "/futuristic-city-traffic-neon-cars-chase.jpg",
    videoUrl: "/demo/gridlock.mp4",
    duration: "1h 58m",
    releaseDate: "2025",
    rating: "PG-13",
    featured: false,
    crew: [
      { name: "Victor Huang", role: "Director" },
      { name: "Marcus Webb", role: "Lead" },
    ],
    hemisphereScore: { neuralis: 65, chaosphere: 35 },
  },
  {
    id: "the-feed",
    title: "The Feed",
    description:
      "Documentary exposing the algorithms behind social consciousness manipulation in the post-digital age.",
    category: "documentaries",
    tags: ["documentary", "social", "technology", "expose"],
    thumbnail: "/social-media-feeds-data-streams-dark.jpg",
    videoUrl: "/demo/the-feed.mp4",
    duration: "1h 35m",
    releaseDate: "2024",
    rating: "TV-14",
    featured: false,
    crew: [{ name: "Sarah Chen", role: "Director" }],
    hemisphereScore: { neuralis: 70, chaosphere: 30 },
  },
]

/**
 * Get content by ID
 */
export function getContentById(id: string): OTTContent | undefined {
  return ottContent.find((c) => c.id === id)
}

/**
 * Get content by category
 */
export function getContentByCategory(category: OTTContent["category"]): OTTContent[] {
  return ottContent.filter((c) => c.category === category)
}

/**
 * Get featured content
 */
export function getFeaturedContent(): OTTContent[] {
  return ottContent.filter((c) => c.featured)
}

/**
 * Search content by query
 */
export function searchContent(query: string): OTTContent[] {
  const q = query.toLowerCase()
  return ottContent.filter(
    (c) =>
      c.title.toLowerCase().includes(q) ||
      c.description.toLowerCase().includes(q) ||
      c.tags.some((t) => t.toLowerCase().includes(q)),
  )
}
