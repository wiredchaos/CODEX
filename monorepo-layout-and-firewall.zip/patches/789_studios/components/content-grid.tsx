import Link from "next/link"
import Image from "next/image"
import { Play, Clock, Calendar } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import type { OTTContent } from "../data/ott-content"

interface ContentGridProps {
  items: OTTContent[]
  view: "grid" | "list"
}

export function ContentGrid({ items, view }: ContentGridProps) {
  if (view === "list") {
    return (
      <div className="flex flex-col gap-4">
        {items.map((item) => (
          <ListCard key={item.id} item={item} />
        ))}
      </div>
    )
  }

  return (
    <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
      {items.map((item) => (
        <GridCard key={item.id} item={item} />
      ))}
    </div>
  )
}

function GridCard({ item }: { item: OTTContent }) {
  return (
    <Link
      href={`/world/789/watch/${item.id}`}
      className="group relative overflow-hidden rounded-lg transition-transform hover:scale-105"
    >
      {/* Thumbnail */}
      <div className="relative aspect-video w-full overflow-hidden bg-muted">
        <Image
          src={item.thumbnail || "/placeholder.svg"}
          alt={item.title}
          fill
          className="object-cover transition-transform group-hover:scale-110"
          sizes="(max-width: 768px) 50vw, (max-width: 1200px) 33vw, 20vw"
        />

        {/* Play Overlay */}
        <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 transition-opacity group-hover:opacity-100">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground">
            <Play className="h-5 w-5 fill-current" />
          </div>
        </div>

        {/* Duration */}
        <Badge className="absolute bottom-2 right-2 bg-black/70 text-white text-xs">{item.duration}</Badge>

        {/* Live Badge */}
        {item.category === "live" && (
          <Badge className="absolute left-2 top-2 bg-red-600 text-white text-xs">
            <span className="mr-1 h-1.5 w-1.5 animate-pulse rounded-full bg-white inline-block" />
            LIVE
          </Badge>
        )}

        {/* Featured Badge */}
        {item.featured && (
          <Badge className="absolute left-2 top-2 bg-primary text-primary-foreground text-xs">Featured</Badge>
        )}
      </div>

      {/* Info */}
      <div className="p-2">
        <h3 className="font-medium text-foreground line-clamp-1 text-sm">{item.title}</h3>
        <p className="text-xs text-muted-foreground capitalize">{item.category}</p>
      </div>
    </Link>
  )
}

function ListCard({ item }: { item: OTTContent }) {
  return (
    <Link
      href={`/world/789/watch/${item.id}`}
      className="group flex gap-4 rounded-lg border border-border bg-card p-4 transition-colors hover:bg-accent"
    >
      {/* Thumbnail */}
      <div className="relative h-24 w-40 flex-shrink-0 overflow-hidden rounded-md bg-muted">
        <Image
          src={item.thumbnail || "/placeholder.svg"}
          alt={item.title}
          fill
          className="object-cover"
          sizes="160px"
        />

        {/* Play Overlay */}
        <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 transition-opacity group-hover:opacity-100">
          <Play className="h-8 w-8 text-white" />
        </div>

        {/* Live Badge */}
        {item.category === "live" && (
          <Badge className="absolute left-1 top-1 bg-red-600 text-white text-xs">LIVE</Badge>
        )}
      </div>

      {/* Info */}
      <div className="flex flex-1 flex-col justify-between">
        <div>
          <div className="mb-1 flex items-center gap-2">
            <Badge variant="outline" className="capitalize text-xs">
              {item.category}
            </Badge>
            {item.rating && (
              <Badge variant="secondary" className="text-xs">
                {item.rating}
              </Badge>
            )}
          </div>
          <h3 className="font-semibold text-foreground">{item.title}</h3>
          <p className="mt-1 text-sm text-muted-foreground line-clamp-2">{item.description}</p>
        </div>

        <div className="mt-2 flex items-center gap-4 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            {item.duration}
          </span>
          <span className="flex items-center gap-1">
            <Calendar className="h-3 w-3" />
            {item.releaseDate}
          </span>
        </div>
      </div>
    </Link>
  )
}
