"use client"

import { useState, useRef, useEffect } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Send, Bot, User, Sparkles, ChevronDown } from "lucide-react"
import { crewConfig, getDefaultCrew, type CrewMember } from "../lib/crew-config"
import { cn } from "@/lib/utils"

interface CrewPanelProps {
  contentId: string
}

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

export function CrewPanel({ contentId }: CrewPanelProps) {
  const [activeCrew, setActiveCrew] = useState<CrewMember>(getDefaultCrew())
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [showCrewSelector, setShowCrewSelector] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages])

  // Initial greeting from crew
  useEffect(() => {
    const greeting: Message = {
      id: "greeting",
      role: "assistant",
      content: `Hey! I'm ${activeCrew.name}, your ${activeCrew.role}. Want me to tell you more about this content or recommend something similar?`,
      timestamp: new Date(),
    }
    setMessages([greeting])
  }, [activeCrew])

  const handleSend = async () => {
    if (!input.trim() || isLoading) return

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      role: "user",
      content: input,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      // In production, this would call the AI API with crew context
      // const response = await fetch('/api/business/789/crew/chat', {
      //   method: 'POST',
      //   body: JSON.stringify({ crewId: activeCrew.id, message: input, contentId })
      // })

      // Simulated response for demo
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const assistantMessage: Message = {
        id: `assistant-${Date.now()}`,
        role: "assistant",
        content: getSimulatedResponse(input, activeCrew, contentId),
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, assistantMessage])
    } catch (error) {
      console.error("[v0] Crew chat error:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleCrewChange = (crew: CrewMember) => {
    setActiveCrew(crew)
    setShowCrewSelector(false)
    setMessages([]) // Reset conversation
  }

  return (
    <Card className="flex h-[500px] flex-col bg-gray-900 border-gray-800">
      <CardHeader className="border-b border-gray-800 pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-white text-sm">
            <Sparkles className="h-4 w-4 text-primary" />
            AI Crew
          </CardTitle>

          {/* Crew Selector */}
          <div className="relative">
            <Button
              variant="ghost"
              size="sm"
              className="gap-2 text-gray-300 hover:text-white"
              onClick={() => setShowCrewSelector(!showCrewSelector)}
            >
              <div className="relative h-6 w-6 overflow-hidden rounded-full">
                <Image
                  src={activeCrew.avatar || "/placeholder.svg"}
                  alt={activeCrew.name}
                  fill
                  className="object-cover"
                />
              </div>
              {activeCrew.name}
              <ChevronDown className="h-3 w-3" />
            </Button>

            {showCrewSelector && (
              <div className="absolute right-0 top-full z-50 mt-1 w-48 rounded-md border border-gray-700 bg-gray-800 py-1 shadow-lg">
                {crewConfig.members.map((crew) => (
                  <button
                    key={crew.id}
                    onClick={() => handleCrewChange(crew)}
                    className={cn(
                      "flex w-full items-center gap-2 px-3 py-2 text-left text-sm transition-colors hover:bg-gray-700",
                      crew.id === activeCrew.id ? "bg-gray-700 text-white" : "text-gray-300",
                    )}
                  >
                    <div className="relative h-6 w-6 overflow-hidden rounded-full">
                      <Image src={crew.avatar || "/placeholder.svg"} alt={crew.name} fill className="object-cover" />
                    </div>
                    <div>
                      <div className="font-medium">{crew.name}</div>
                      <div className="text-xs text-gray-500">{crew.role}</div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Crew Info */}
        <div className="mt-2 flex items-center gap-2">
          <Badge
            variant="outline"
            className={cn(
              "text-xs",
              activeCrew.hemisphereAffinity === "neuralis"
                ? "border-blue-500 text-blue-400"
                : activeCrew.hemisphereAffinity === "chaosphere"
                  ? "border-purple-500 text-purple-400"
                  : "border-gray-500 text-gray-400",
            )}
          >
            {activeCrew.hemisphereAffinity}
          </Badge>
          <span className="text-xs text-gray-500">{activeCrew.role}</span>
        </div>
      </CardHeader>

      <CardContent className="flex flex-1 flex-col p-0">
        {/* Messages */}
        <ScrollArea className="flex-1 p-4" ref={scrollRef}>
          <div className="flex flex-col gap-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={cn("flex gap-2", message.role === "user" ? "flex-row-reverse" : "flex-row")}
              >
                <div
                  className={cn(
                    "flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full",
                    message.role === "user" ? "bg-primary" : "bg-gray-700",
                  )}
                >
                  {message.role === "user" ? (
                    <User className="h-4 w-4 text-primary-foreground" />
                  ) : (
                    <Bot className="h-4 w-4 text-gray-300" />
                  )}
                </div>
                <div
                  className={cn(
                    "max-w-[80%] rounded-lg px-3 py-2 text-sm",
                    message.role === "user" ? "bg-primary text-primary-foreground" : "bg-gray-800 text-gray-200",
                  )}
                >
                  {message.content}
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex gap-2">
                <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-gray-700">
                  <Bot className="h-4 w-4 text-gray-300" />
                </div>
                <div className="rounded-lg bg-gray-800 px-3 py-2">
                  <div className="flex gap-1">
                    <span
                      className="h-2 w-2 animate-bounce rounded-full bg-gray-500"
                      style={{ animationDelay: "0ms" }}
                    />
                    <span
                      className="h-2 w-2 animate-bounce rounded-full bg-gray-500"
                      style={{ animationDelay: "150ms" }}
                    />
                    <span
                      className="h-2 w-2 animate-bounce rounded-full bg-gray-500"
                      style={{ animationDelay: "300ms" }}
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Input */}
        <div className="border-t border-gray-800 p-4">
          <form
            onSubmit={(e) => {
              e.preventDefault()
              handleSend()
            }}
            className="flex gap-2"
          >
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={`Ask ${activeCrew.name}...`}
              className="flex-1 bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
              disabled={isLoading}
            />
            <Button type="submit" size="icon" disabled={isLoading || !input.trim()}>
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </div>
      </CardContent>
    </Card>
  )
}

// Simulated responses for demo (would be AI-generated in production)
function getSimulatedResponse(input: string, crew: CrewMember, contentId: string): string {
  const lowerInput = input.toLowerCase()

  if (crew.id === "sage") {
    if (lowerInput.includes("recommend") || lowerInput.includes("similar")) {
      return "Based on this content, I'd recommend checking out 'Realm Walkers' if you enjoy the philosophical aspects, or 'Neural Network' if you're more into the thriller elements. Both explore similar themes of consciousness and reality."
    }
    if (lowerInput.includes("director") || lowerInput.includes("who made")) {
      return "This was created by our in-house creative team at Studio 789. They specialize in content that bridges the gap between entertainment and deeper questions about existence."
    }
    return "That's a great question! This piece explores some fascinating themes. Would you like me to dive deeper into the narrative structure or recommend related content?"
  }

  if (crew.id === "echo") {
    if (lowerInput.includes("watch party") || lowerInput.includes("friends")) {
      return "I'd love to help you set up a watch party! Just share the link with your friends and I'll handle the synchronized playback. I can also set up live chat and reaction prompts!"
    }
    return "This would be perfect for a group watch! Want me to help you invite some friends? I can make it super interactive with live reactions and trivia!"
  }

  if (crew.id === "cipher") {
    if (lowerInput.includes("scene") || lowerInput.includes("find")) {
      return "I can help you locate specific scenes. Just describe what you're looking for - a particular dialogue, visual element, or moment - and I'll timestamp it for you."
    }
    return "There's actually some fascinating production history behind this piece. The creators used an innovative approach to visual storytelling. Want me to dig into the technical details?"
  }

  return "I'm here to help! Feel free to ask me anything about this content or the Studio 789 library."
}
