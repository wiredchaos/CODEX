"use client"

import { useRef } from "react"
import Link from "next/link"
import Image from "next/image"
import { ChevronLeft, ChevronRight, Play } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import type { OTTContent } from "../data/ott-content"

interface ContentCarouselProps {
  items: OTTContent[]
}

export function ContentCarousel({ items }: ContentCarouselProps) {
  const scrollRef = useRef<HTMLDivElement>(null)

  const scroll = (direction: "left" | "right") => {
    if (!scrollRef.current) return
    const scrollAmount = 400
    scrollRef.current.scrollBy({
      left: direction === "left" ? -scrollAmount : scrollAmount,
      behavior: "smooth",
    })
  }

  if (items.length === 0) return null

  return (
    <div className="group relative">
      {/* Scroll Buttons */}
      <Button
        variant="ghost"
        size="icon"
        className="absolute -left-4 top-1/2 z-10 h-10 w-10 -translate-y-1/2 rounded-full bg-background/80 opacity-0 shadow-lg transition-opacity group-hover:opacity-100"
        onClick={() => scroll("left")}
      >
        <ChevronLeft className="h-6 w-6" />
      </Button>

      <Button
        variant="ghost"
        size="icon"
        className="absolute -right-4 top-1/2 z-10 h-10 w-10 -translate-y-1/2 rounded-full bg-background/80 opacity-0 shadow-lg transition-opacity group-hover:opacity-100"
        onClick={() => scroll("right")}
      >
        <ChevronRight className="h-6 w-6" />
      </Button>

      {/* Carousel Container */}
      <div
        ref={scrollRef}
        className="flex gap-4 overflow-x-auto scroll-smooth pb-4 scrollbar-hide"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        {items.map((item) => (
          <ContentCard key={item.id} item={item} />
        ))}
      </div>
    </div>
  )
}

function ContentCard({ item }: { item: OTTContent }) {
  return (
    <Link
      href={`/world/789/watch/${item.id}`}
      className="group/card relative flex-shrink-0 w-[280px] overflow-hidden rounded-lg transition-transform hover:scale-105"
    >
      {/* Thumbnail */}
      <div className="relative aspect-video w-full overflow-hidden bg-muted">
        <Image
          src={item.thumbnail || "/placeholder.svg"}
          alt={item.title}
          fill
          className="object-cover transition-transform group-hover/card:scale-110"
          sizes="280px"
        />

        {/* Play Overlay */}
        <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 transition-opacity group-hover/card:opacity-100">
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary text-primary-foreground">
            <Play className="h-6 w-6 fill-current" />
          </div>
        </div>

        {/* Duration Badge */}
        <Badge className="absolute bottom-2 right-2 bg-black/70 text-white">{item.duration}</Badge>

        {/* Live Indicator */}
        {item.category === "live" && (
          <Badge className="absolute left-2 top-2 bg-red-600 text-white">
            <span className="mr-1 h-2 w-2 animate-pulse rounded-full bg-white inline-block" />
            LIVE
          </Badge>
        )}
      </div>

      {/* Info */}
      <div className="p-3">
        <h3 className="mb-1 font-semibold text-foreground line-clamp-1">{item.title}</h3>
        <p className="text-sm text-muted-foreground line-clamp-2">{item.description}</p>

        {/* Tags */}
        <div className="mt-2 flex flex-wrap gap-1">
          {item.tags.slice(0, 2).map((tag) => (
            <Badge key={tag} variant="secondary" className="text-xs">
              {tag}
            </Badge>
          ))}
        </div>
      </div>
    </Link>
  )
}
