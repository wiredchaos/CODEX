/**
 * Studio 789 AI Crew Chat API
 *
 * Handles AI crew conversations using the Vercel AI SDK.
 * Each crew member has distinct personality and capabilities.
 *
 * @route /api/business/789/crew/chat
 * @realm business
 */

import { streamText } from "ai"
import { firewall } from "@/packages/firewall"
import { telemetryBus } from "@/packages/telemetry-bus"
import { getCrewMember, buildCrewContext } from "../../../../lib/crew-config"
import { getContentById } from "../../../../data/ott-content"

export async function POST(request: Request) {
  // Firewall enforcement
  const access = await firewall.guard({
    realm: "business",
    service: "789_studios",
    action: "crew:chat",
  })

  if (!access.allowed) {
    return new Response(JSON.stringify({ error: access.reason }), {
      status: 403,
      headers: { "Content-Type": "application/json" },
    })
  }

  const { crewId, message, contentId, history = [] } = await request.json()

  // Get crew member configuration
  const crew = getCrewMember(crewId)
  if (!crew) {
    return new Response(JSON.stringify({ error: "Crew member not found" }), {
      status: 404,
      headers: { "Content-Type": "application/json" },
    })
  }

  // Build context
  const contextParts: string[] = [crew.systemPrompt]

  if (contentId) {
    const content = getContentById(contentId)
    if (content) {
      contextParts.push(`
Current content being viewed:
- Title: ${content.title}
- Category: ${content.category}
- Description: ${content.description}
- Tags: ${content.tags.join(", ")}
- Duration: ${content.duration}
`)
    }
  }

  const context = buildCrewContext({
    contentId,
    // Would include user data in production
  })

  if (context) {
    contextParts.push(context)
  }

  // Track crew interaction
  await telemetryBus.trackCrewInteraction("789_studios", crewId, "chat")

  // Stream response using AI SDK with Vercel AI Gateway
  const result = streamText({
    model: "openai/gpt-4o-mini",
    system: contextParts.join("\n\n"),
    messages: [
      ...history.map((h: { role: string; content: string }) => ({
        role: h.role as "user" | "assistant",
        content: h.content,
      })),
      { role: "user" as const, content: message },
    ],
    maxTokens: 500,
    temperature: crew.hemisphereAffinity === "chaosphere" ? 0.9 : 0.7,
  })

  return result.toUIMessageStreamResponse()
}
