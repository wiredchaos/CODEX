/**
 * Studio 789 Subscription API
 *
 * Handles subscription management via Stripe integration.
 *
 * @route /api/business/789/subscription
 * @realm business
 */

import { NextResponse } from "next/server"
import Stripe from "stripe"
import { firewall } from "@/packages/firewall"
import { telemetryBus } from "@/packages/telemetry-bus"

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2025-05-28.basil",
})

// Subscription tiers
const TIERS = {
  basic: {
    priceId: process.env.STRIPE_BASIC_PRICE_ID || "price_basic",
    name: "Basic",
    features: ["HD streaming", "1 device", "Limited library"],
  },
  premium: {
    priceId: process.env.STRIPE_PREMIUM_PRICE_ID || "price_premium",
    name: "Premium",
    features: ["4K streaming", "4 devices", "Full library", "Offline downloads"],
  },
  studio: {
    priceId: process.env.STRIPE_STUDIO_PRICE_ID || "price_studio",
    name: "Studio",
    features: ["4K streaming", "Unlimited devices", "Full library", "Creator tools", "Early access"],
  },
}

export async function GET() {
  // Firewall enforcement
  const access = await firewall.guard({
    realm: "business",
    service: "789_studios",
    action: "subscription:list",
  })

  if (!access.allowed) {
    return NextResponse.json({ error: access.reason }, { status: 403 })
  }

  return NextResponse.json({ tiers: TIERS })
}

export async function POST(request: Request) {
  // Firewall enforcement
  const access = await firewall.guard({
    realm: "business",
    service: "789_studios",
    action: "subscription:create",
  })

  if (!access.allowed) {
    return NextResponse.json({ error: access.reason }, { status: 403 })
  }

  const { tier, successUrl, cancelUrl } = await request.json()

  if (!tier || !TIERS[tier as keyof typeof TIERS]) {
    return NextResponse.json({ error: "Invalid subscription tier" }, { status: 400 })
  }

  const tierConfig = TIERS[tier as keyof typeof TIERS]

  try {
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      payment_method_types: ["card"],
      line_items: [
        {
          price: tierConfig.priceId,
          quantity: 1,
        },
      ],
      success_url: successUrl || `${process.env.NEXT_PUBLIC_APP_URL}/world/789/library?subscribed=true`,
      cancel_url: cancelUrl || `${process.env.NEXT_PUBLIC_APP_URL}/world/789/subscribe`,
      metadata: {
        patch: "789_studios",
        tier,
      },
    })

    // Track subscription initiation
    await telemetryBus.trackSubscription("789_studios", "started", tier)

    return NextResponse.json({
      sessionId: session.id,
      url: session.url,
    })
  } catch (error) {
    console.error("[789] Stripe error:", error)
    return NextResponse.json({ error: "Failed to create subscription session" }, { status: 500 })
  }
}
