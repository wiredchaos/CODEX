/**
 * Studio 789 Single Content API
 *
 * Provides individual content item access with playback authorization.
 *
 * @route /api/business/789/content/[id]
 * @realm business
 */

import { NextResponse } from "next/server"
import { firewall } from "@/packages/firewall"
import { telemetryBus } from "@/packages/telemetry-bus"
import { getContentById } from "../../../../../data/ott-content"

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params

  // Firewall enforcement
  const access = await firewall.guard({
    realm: "business",
    service: "789_studios",
    action: "content:view",
    resourceId: id,
  })

  if (!access.allowed) {
    return NextResponse.json({ error: access.reason }, { status: 403 })
  }

  const content = getContentById(id)

  if (!content) {
    return NextResponse.json({ error: "Content not found" }, { status: 404 })
  }

  // Track content view
  await telemetryBus.trackContentView(id, "789_studios", {
    title: content.title,
    category: content.category,
  })

  return NextResponse.json({
    data: content,
    playback: {
      authorized: true,
      expiresAt: new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString(), // 4 hours
      quality: ["1080p", "720p", "480p"],
    },
  })
}
