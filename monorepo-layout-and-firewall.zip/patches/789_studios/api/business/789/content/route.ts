/**
 * Studio 789 Content API
 *
 * Provides content catalog access with firewall enforcement.
 * All requests are validated against the business realm.
 *
 * @route /api/business/789/content
 * @realm business
 */

import { NextResponse } from "next/server"
import { firewall } from "@/packages/firewall"
import { telemetryBus } from "@/packages/telemetry-bus"
import { ottContent, searchContent, getContentByCategory, type OTTContent } from "../../../../data/ott-content"

export async function GET(request: Request) {
  // Firewall enforcement
  const access = await firewall.guard({
    realm: "business",
    service: "789_studios",
    action: "content:list",
  })

  if (!access.allowed) {
    return NextResponse.json({ error: access.reason }, { status: 403 })
  }

  const { searchParams } = new URL(request.url)
  const category = searchParams.get("category")
  const query = searchParams.get("q")
  const featured = searchParams.get("featured")
  const limit = Number.parseInt(searchParams.get("limit") || "50", 10)
  const offset = Number.parseInt(searchParams.get("offset") || "0", 10)

  let results: OTTContent[] = [...ottContent]

  // Apply filters
  if (category) {
    results = getContentByCategory(category as OTTContent["category"])
  }

  if (query) {
    results = searchContent(query)
  }

  if (featured === "true") {
    results = results.filter((c) => c.featured)
  }

  // Pagination
  const total = results.length
  const paginated = results.slice(offset, offset + limit)

  // Track API access
  await telemetryBus.emit(
    "789:api:content:list",
    {
      category,
      query,
      resultCount: paginated.length,
    },
    "789_studios",
  )

  return NextResponse.json({
    data: paginated,
    meta: {
      total,
      limit,
      offset,
      hasMore: offset + limit < total,
    },
  })
}
