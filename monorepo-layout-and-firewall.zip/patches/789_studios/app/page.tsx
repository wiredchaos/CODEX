import type React from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Play, Tv, Users, Sparkles } from "lucide-react"
import { ContentCarousel } from "../components/content-carousel"
import { ottContent } from "../data/ott-content"

export const metadata = {
  title: "Studio 789 | WIRED CHAOS META",
  description: "Premium streaming within the WIRED CHAOS META multiverse",
}

export default function Studio789Landing() {
  const featuredContent = ottContent.filter((c) => c.featured)
  const categories = [...new Set(ottContent.map((c) => c.category))]

  return (
    <main className="min-h-screen bg-background text-foreground">
      {/* Hero Section */}
      <section className="relative h-[80vh] overflow-hidden">
        {/* Animated gradient background */}
        <div className="absolute inset-0 z-0 bg-gradient-to-br from-indigo-950 via-slate-950 to-black">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(99,102,241,0.1),transparent_50%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(34,197,94,0.08),transparent_50%)]" />
        </div>

        {/* Gradient Overlay */}
        <div className="absolute inset-0 z-10 bg-gradient-to-t from-background via-background/60 to-transparent" />

        {/* Hero Content */}
        <div className="relative z-20 flex h-full flex-col items-center justify-center px-6 text-center">
          <div className="mb-4 flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-2">
            <Sparkles className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium">Now Streaming</span>
          </div>

          <h1 className="mb-6 text-balance text-5xl font-bold tracking-tight md:text-7xl">
            Studio <span className="text-primary">789</span>
          </h1>

          <p className="mb-8 max-w-2xl text-pretty text-lg text-muted-foreground md:text-xl">
            Original content, documentaries, and live broadcasts within the WIRED CHAOS META multiverse. Enter the
            stream.
          </p>

          <div className="flex flex-wrap justify-center gap-4">
            <Button asChild size="lg" className="gap-2">
              <Link href="/world/789/browse">
                <Play className="h-5 w-5" />
                Start Watching
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="gap-2 bg-transparent">
              <Link href="/world/789/library">
                <Tv className="h-5 w-5" />
                My Library
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section className="border-y border-border bg-card/50 py-8">
        <div className="mx-auto flex max-w-6xl flex-wrap justify-center gap-12 px-6">
          <StatItem icon={<Tv />} value="500+" label="Titles" />
          <StatItem icon={<Users />} value="10K+" label="Subscribers" />
          <StatItem icon={<Play />} value="1M+" label="Hours Streamed" />
        </div>
      </section>

      {/* Featured Content Carousel */}
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-6">
          <h2 className="mb-8 text-2xl font-semibold">Featured</h2>
          <ContentCarousel items={featuredContent} />
        </div>
      </section>

      {/* Category Rows */}
      {categories.slice(0, 3).map((category) => (
        <section key={category} className="py-8">
          <div className="mx-auto max-w-7xl px-6">
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-xl font-semibold capitalize">{category}</h2>
              <Link
                href={`/world/789/browse?category=${category}`}
                className="text-sm text-muted-foreground hover:text-primary"
              >
                View All
              </Link>
            </div>
            <ContentCarousel items={ottContent.filter((c) => c.category === category).slice(0, 8)} />
          </div>
        </section>
      ))}

      {/* CTA Section */}
      <section className="border-t border-border bg-card/30 py-20">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <h2 className="mb-4 text-balance text-3xl font-bold">Ready to Enter the Stream?</h2>
          <p className="mb-8 text-pretty text-muted-foreground">
            Subscribe now for unlimited access to all Studio 789 content.
          </p>
          <Button asChild size="lg">
            <Link href="/world/789/subscribe">Start Free Trial</Link>
          </Button>
        </div>
      </section>
    </main>
  )
}

function StatItem({
  icon,
  value,
  label,
}: {
  icon: React.ReactNode
  value: string
  label: string
}) {
  return (
    <div className="flex items-center gap-3">
      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary">{icon}</div>
      <div>
        <div className="text-2xl font-bold">{value}</div>
        <div className="text-sm text-muted-foreground">{label}</div>
      </div>
    </div>
  )
}
