import { Suspense } from "react"
import Link from "next/link"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Search, Filter, Grid3X3, List } from "lucide-react"
import { ContentGrid } from "../../components/content-grid"
import { ottContent, type OTTContent } from "../../data/ott-content"

export const metadata = {
  title: "Browse | Studio 789",
  description: "Explore the Studio 789 content catalog",
}

interface BrowsePageProps {
  searchParams: Promise<{ category?: string; q?: string; view?: string }>
}

export default async function BrowsePage({ searchParams }: BrowsePageProps) {
  const params = await searchParams
  const { category, q, view = "grid" } = params

  // Filter content based on params
  let filteredContent: OTTContent[] = ottContent

  if (category) {
    filteredContent = filteredContent.filter((c) => c.category.toLowerCase() === category.toLowerCase())
  }

  if (q) {
    const query = q.toLowerCase()
    filteredContent = filteredContent.filter(
      (c) =>
        c.title.toLowerCase().includes(query) ||
        c.description.toLowerCase().includes(query) ||
        c.tags.some((t) => t.toLowerCase().includes(query)),
    )
  }

  const categories = [...new Set(ottContent.map((c) => c.category))]

  return (
    <main className="min-h-screen bg-background pb-20">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-6 py-4">
          <Link href="/world/789" className="text-xl font-bold">
            Studio <span className="text-primary">789</span>
          </Link>

          {/* Search */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <form action="/world/789/browse" method="get">
              <Input name="q" placeholder="Search titles, genres, tags..." defaultValue={q} className="pl-10" />
            </form>
          </div>

          {/* View Toggle */}
          <div className="flex items-center gap-2">
            <Button variant={view === "grid" ? "default" : "ghost"} size="icon" asChild>
              <Link href={`/world/789/browse?view=grid${category ? `&category=${category}` : ""}${q ? `&q=${q}` : ""}`}>
                <Grid3X3 className="h-4 w-4" />
              </Link>
            </Button>
            <Button variant={view === "list" ? "default" : "ghost"} size="icon" asChild>
              <Link href={`/world/789/browse?view=list${category ? `&category=${category}` : ""}${q ? `&q=${q}` : ""}`}>
                <List className="h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-6 pt-8">
        {/* Category Filters */}
        <div className="mb-8 flex flex-wrap items-center gap-2">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <Badge variant={!category ? "default" : "outline"} className="cursor-pointer" asChild>
            <Link href="/world/789/browse">All</Link>
          </Badge>
          {categories.map((cat) => (
            <Badge
              key={cat}
              variant={category === cat ? "default" : "outline"}
              className="cursor-pointer capitalize"
              asChild
            >
              <Link href={`/world/789/browse?category=${cat}`}>{cat}</Link>
            </Badge>
          ))}
        </div>

        {/* Results Header */}
        <div className="mb-6 flex items-center justify-between">
          <h1 className="text-2xl font-semibold">
            {category ? (
              <span className="capitalize">{category}</span>
            ) : q ? (
              <>Results for &quot;{q}&quot;</>
            ) : (
              "All Content"
            )}
          </h1>
          <span className="text-sm text-muted-foreground">{filteredContent.length} titles</span>
        </div>

        {/* Content Grid */}
        <Suspense
          fallback={
            <div className="grid grid-cols-2 gap-4 md:grid-cols-4 lg:grid-cols-5">
              {Array.from({ length: 10 }).map((_, i) => (
                <div key={i} className="aspect-video animate-pulse rounded-lg bg-muted" />
              ))}
            </div>
          }
        >
          {filteredContent.length > 0 ? (
            <ContentGrid items={filteredContent} view={view as "grid" | "list"} />
          ) : (
            <div className="py-20 text-center">
              <p className="text-muted-foreground">No content found. Try a different search or category.</p>
            </div>
          )}
        </Suspense>
      </div>
    </main>
  )
}
