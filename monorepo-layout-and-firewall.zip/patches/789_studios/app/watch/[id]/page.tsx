import { Suspense } from "react"
import Link from "next/link"
import { notFound } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Share2, Heart, Plus, Clock, Calendar } from "lucide-react"
import { VideoPlayer } from "../../../components/video-player"
import { ContentCarousel } from "../../../components/content-carousel"
import { CrewPanel } from "../../../components/crew-panel"
import { ottContent } from "../../../data/ott-content"
import { firewall } from "@/packages/firewall"

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const content = ottContent.find((c) => c.id === id)

  if (!content) return { title: "Not Found | Studio 789" }

  return {
    title: `${content.title} | Studio 789`,
    description: content.description,
  }
}

interface WatchPageProps {
  params: Promise<{ id: string }>
}

export default async function WatchPage({ params }: WatchPageProps) {
  const { id } = await params

  // Firewall enforcement - ensure we're in business realm
  const access = await firewall.guard({
    realm: "business",
    service: "789_studios",
    action: "content:view",
    resourceId: id,
  })

  if (!access.allowed) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <h1 className="mb-4 text-2xl font-bold">Access Denied</h1>
          <p className="text-muted-foreground">{access.reason}</p>
        </div>
      </div>
    )
  }

  const content = ottContent.find((c) => c.id === id)

  if (!content) {
    notFound()
  }

  // Get related content
  const related = ottContent.filter((c) => c.id !== id && c.category === content.category).slice(0, 6)

  return (
    <main className="min-h-screen bg-black text-white">
      {/* Video Player Section */}
      <section className="relative aspect-video w-full bg-black">
        <Suspense
          fallback={
            <div className="flex h-full w-full items-center justify-center bg-black">
              <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent" />
            </div>
          }
        >
          <VideoPlayer src={content.videoUrl} poster={content.thumbnail} title={content.title} contentId={content.id} />
        </Suspense>

        {/* Back Button Overlay */}
        <div className="absolute left-4 top-4 z-20">
          <Button variant="ghost" size="icon" className="bg-black/50" asChild>
            <Link href="/world/789/browse">
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </Button>
        </div>
      </section>

      {/* Content Info */}
      <section className="mx-auto max-w-7xl px-6 py-8">
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Main Info */}
          <div className="lg:col-span-2">
            <div className="mb-4 flex flex-wrap items-center gap-2">
              <Badge variant="secondary" className="capitalize">
                {content.category}
              </Badge>
              {content.tags.map((tag) => (
                <Badge key={tag} variant="outline">
                  {tag}
                </Badge>
              ))}
            </div>

            <h1 className="mb-4 text-3xl font-bold text-white md:text-4xl">{content.title}</h1>

            <div className="mb-6 flex flex-wrap items-center gap-6 text-sm text-gray-400">
              <span className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                {content.duration}
              </span>
              <span className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                {content.releaseDate}
              </span>
              {content.rating && <Badge variant="outline">{content.rating}</Badge>}
            </div>

            <p className="mb-8 text-gray-300">{content.description}</p>

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-4">
              <Button variant="outline" className="gap-2 bg-transparent">
                <Plus className="h-4 w-4" />
                Add to Library
              </Button>
              <Button variant="ghost" className="gap-2">
                <Heart className="h-4 w-4" />
                Like
              </Button>
              <Button variant="ghost" className="gap-2">
                <Share2 className="h-4 w-4" />
                Share
              </Button>
            </div>

            {/* Cast & Crew */}
            {content.crew && (
              <div className="mt-8 border-t border-gray-800 pt-8">
                <h3 className="mb-4 text-lg font-semibold">Cast & Crew</h3>
                <div className="flex flex-wrap gap-4">
                  {content.crew.map((member) => (
                    <div key={member.name} className="text-sm">
                      <span className="text-gray-400">{member.role}: </span>
                      <span className="text-white">{member.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* AI Crew Panel */}
          <div className="lg:col-span-1">
            <CrewPanel contentId={content.id} />
          </div>
        </div>
      </section>

      {/* Related Content */}
      {related.length > 0 && (
        <section className="border-t border-gray-800 py-12">
          <div className="mx-auto max-w-7xl px-6">
            <h2 className="mb-8 text-xl font-semibold">More Like This</h2>
            <ContentCarousel items={related} />
          </div>
        </section>
      )}
    </main>
  )
}
