import type React from "react"
import type { Metadata } from "next"
import { Studio789Provider } from "../providers"

export const metadata: Metadata = {
  title: "Studio 789 | WIRED CHAOS META",
  description: "Premium streaming platform within the WIRED CHAOS META multiverse",
}

export default function Studio789Layout({
  children,
}: {
  children: React.ReactNode
}) {
  // This patch is a consumer, not a provider of Trinity infrastructure
  return <Studio789Provider>{children}</Studio789Provider>
}
