"use client"

import type React from "react"

/**
 * Trinity Core React Hooks
 */

import { useCallback, useEffect, useRef, useState } from "react"
import type { PatchNode, GalaxyConfig, TrinityEventMap, TrinityEventHandler } from "./types"

// Global event bus for Trinity events
type EventCallback = (data: unknown) => void
const eventListeners = new Map<string, Set<EventCallback>>()

function emitTrinityEvent<K extends keyof TrinityEventMap>(event: K, data: TrinityEventMap[K]) {
  const listeners = eventListeners.get(event)
  if (listeners) {
    listeners.forEach((callback) => callback(data))
  }
}

function onTrinityEvent<K extends keyof TrinityEventMap>(event: K, callback: TrinityEventHandler<K>): () => void {
  if (!eventListeners.has(event)) {
    eventListeners.set(event, new Set())
  }
  eventListeners.get(event)!.add(callback as EventCallback)

  return () => {
    eventListeners.get(event)?.delete(callback as EventCallback)
  }
}

/**
 * Hook for managing Galaxy navigation state
 */
export function useGalaxy(initialConfig: Partial<GalaxyConfig> = {}) {
  const [config, setConfig] = useState<GalaxyConfig>({
    patches: [],
    currentPatch: null,
    viewMode: "orbit",
    showConnections: true,
    showLabels: true,
    ...initialConfig,
  })

  const registerPatch = useCallback((patch: PatchNode) => {
    setConfig((c) => {
      if (c.patches.some((p) => p.id === patch.id)) return c
      return { ...c, patches: [...c.patches, patch] }
    })
  }, [])

  const selectPatch = useCallback((patchId: string) => {
    setConfig((c) => ({ ...c, currentPatch: patchId }))
    emitTrinityEvent("galaxy:patch:select", { patchId })
  }, [])

  const setViewMode = useCallback((mode: GalaxyConfig["viewMode"]) => {
    setConfig((c) => ({ ...c, viewMode: mode }))
    emitTrinityEvent("galaxy:view:change", { mode })
  }, [])

  const toggleConnections = useCallback(() => {
    setConfig((c) => ({ ...c, showConnections: !c.showConnections }))
  }, [])

  const toggleLabels = useCallback(() => {
    setConfig((c) => ({ ...c, showLabels: !c.showLabels }))
  }, [])

  return {
    config,
    registerPatch,
    selectPatch,
    setViewMode,
    toggleConnections,
    toggleLabels,
  }
}

/**
 * Hook for subscribing to Trinity events
 */
export function useTrinityEvent<K extends keyof TrinityEventMap>(
  event: K,
  handler: TrinityEventHandler<K>,
  deps: React.DependencyList = [],
) {
  const savedHandler = useRef(handler)

  useEffect(() => {
    savedHandler.current = handler
  }, [handler])

  useEffect(() => {
    const unsubscribe = onTrinityEvent(event, (data) => {
      savedHandler.current(data)
    })

    return unsubscribe
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)
}

/**
 * Hook for 3D scene loading state
 */
export function useSceneLoader() {
  const [isLoading, setIsLoading] = useState(true)
  const [progress, setProgress] = useState(0)
  const [error, setError] = useState<Error | null>(null)

  const startLoading = useCallback(() => {
    setIsLoading(true)
    setProgress(0)
    setError(null)
  }, [])

  const updateProgress = useCallback((value: number) => {
    setProgress(Math.min(100, Math.max(0, value)))
  }, [])

  const finishLoading = useCallback(() => {
    setProgress(100)
    setTimeout(() => setIsLoading(false), 300)
  }, [])

  const handleError = useCallback((err: Error) => {
    setError(err)
    setIsLoading(false)
  }, [])

  return {
    isLoading,
    progress,
    error,
    startLoading,
    updateProgress,
    finishLoading,
    handleError,
  }
}

/**
 * Hook for responsive 3D camera controls
 */
export function useResponsiveCamera() {
  const [cameraConfig, setCameraConfig] = useState({
    fov: 60,
    position: [0, 30, 50] as [number, number, number],
    minDistance: 20,
    maxDistance: 150,
  })

  useEffect(() => {
    const updateForViewport = () => {
      const isMobile = window.innerWidth < 768
      const isTablet = window.innerWidth < 1024

      if (isMobile) {
        setCameraConfig({
          fov: 75,
          position: [0, 40, 60],
          minDistance: 30,
          maxDistance: 100,
        })
      } else if (isTablet) {
        setCameraConfig({
          fov: 65,
          position: [0, 35, 55],
          minDistance: 25,
          maxDistance: 120,
        })
      } else {
        setCameraConfig({
          fov: 60,
          position: [0, 30, 50],
          minDistance: 20,
          maxDistance: 150,
        })
      }
    }

    updateForViewport()
    window.addEventListener("resize", updateForViewport)
    return () => window.removeEventListener("resize", updateForViewport)
  }, [])

  return cameraConfig
}

// Export event utilities
export { emitTrinityEvent, onTrinityEvent }
