"use client"

import { useRef, useState, useMemo, Suspense } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { OrbitControls, Stars, Text, Line, Float, Environment, Html } from "@react-three/drei"
import * as THREE from "three"
import type { PatchNode, GalaxyConfig } from "./types"

interface GalaxyProps {
  config: GalaxyConfig
  onPatchSelect?: (patchId: string) => void
  onPatchHover?: (patchId: string | null) => void
}

export function Galaxy({ config, onPatchSelect, onPatchHover }: GalaxyProps) {
  return (
    <div className="h-full w-full">
      <Canvas camera={{ position: [0, 30, 50], fov: 60 }} gl={{ antialias: true }}>
        <Suspense fallback={null}>
          <GalaxyScene config={config} onPatchSelect={onPatchSelect} onPatchHover={onPatchHover} />
        </Suspense>
      </Canvas>
    </div>
  )
}

function GalaxyScene({
  config,
  onPatchSelect,
  onPatchHover,
}: {
  config: GalaxyConfig
  onPatchSelect?: (patchId: string) => void
  onPatchHover?: (patchId: string | null) => void
}) {
  const groupRef = useRef<THREE.Group>(null)

  // Slow rotation for ambient movement
  useFrame(({ clock }) => {
    if (groupRef.current && config.viewMode === "orbit") {
      groupRef.current.rotation.y = Math.sin(clock.getElapsedTime() * 0.05) * 0.1
    }
  })

  return (
    <>
      {/* Lighting */}
      <ambientLight intensity={0.2} />
      <pointLight position={[0, 50, 0]} intensity={1} color="#ffffff" />
      <pointLight position={[-30, 20, 30]} intensity={0.5} color="#4fc3f7" />
      <pointLight position={[30, 20, -30]} intensity={0.5} color="#ce93d8" />

      {/* Environment */}
      <Stars radius={200} depth={100} count={5000} factor={4} fade speed={0.5} />
      <Environment preset="night" />

      {/* Galaxy Content */}
      <group ref={groupRef}>
        {/* Patch Nodes */}
        {config.patches.map((patch) => (
          <PatchNodeMesh
            key={patch.id}
            patch={patch}
            isActive={patch.id === config.currentPatch}
            showLabel={config.showLabels}
            onSelect={onPatchSelect}
            onHover={onPatchHover}
          />
        ))}

        {/* Connections */}
        {config.showConnections &&
          config.patches.map((patch) =>
            patch.connections.map((targetId) => {
              const target = config.patches.find((p) => p.id === targetId)
              if (!target) return null
              // Only render each connection once
              if (patch.id > targetId) return null

              return (
                <ConnectionLine
                  key={`${patch.id}-${targetId}`}
                  start={[patch.position.x, patch.position.y, patch.position.z]}
                  end={[target.position.x, target.position.y, target.position.z]}
                  color={patch.realm === target.realm ? "#4fc3f7" : "#ce93d8"}
                />
              )
            }),
          )}

        {/* Central Core */}
        <CentralCore />
      </group>

      {/* Controls */}
      <OrbitControls
        enablePan={config.viewMode === "map"}
        minDistance={20}
        maxDistance={150}
        minPolarAngle={Math.PI / 6}
        maxPolarAngle={Math.PI / 2}
      />
    </>
  )
}

function PatchNodeMesh({
  patch,
  isActive,
  showLabel,
  onSelect,
  onHover,
}: {
  patch: PatchNode
  isActive: boolean
  showLabel: boolean
  onSelect?: (patchId: string) => void
  onHover?: (patchId: string | null) => void
}) {
  const meshRef = useRef<THREE.Mesh>(null)
  const [hovered, setHovered] = useState(false)

  // Realm-based colors
  const realmColors = {
    business: "#4fc3f7",
    akashic: "#ce93d8",
    echo: "#81c784",
  }

  const color = patch.metadata.color || realmColors[patch.realm]
  const scale = isActive ? 1.5 : hovered ? 1.2 : 1

  useFrame(({ clock }) => {
    if (meshRef.current) {
      // Gentle floating animation
      meshRef.current.position.y = patch.position.y + Math.sin(clock.getElapsedTime() * 2 + patch.position.x) * 0.3
    }
  })

  const handleClick = () => {
    if (patch.metadata.active !== false) {
      onSelect?.(patch.id)
    }
  }

  const handlePointerEnter = () => {
    setHovered(true)
    onHover?.(patch.id)
    document.body.style.cursor = "pointer"
  }

  const handlePointerLeave = () => {
    setHovered(false)
    onHover?.(null)
    document.body.style.cursor = "default"
  }

  return (
    <Float speed={1} rotationIntensity={0.2} floatIntensity={0.5}>
      <group position={[patch.position.x, patch.position.y, patch.position.z]}>
        {/* Main sphere */}
        <mesh
          ref={meshRef}
          scale={scale}
          onClick={handleClick}
          onPointerEnter={handlePointerEnter}
          onPointerLeave={handlePointerLeave}
        >
          <sphereGeometry args={[2, 32, 32]} />
          <meshStandardMaterial
            color={color}
            emissive={color}
            emissiveIntensity={isActive ? 0.8 : hovered ? 0.5 : 0.2}
            metalness={0.3}
            roughness={0.7}
          />
        </mesh>

        {/* Glow ring */}
        {(isActive || hovered) && (
          <mesh rotation={[Math.PI / 2, 0, 0]}>
            <ringGeometry args={[2.5 * scale, 3 * scale, 32]} />
            <meshBasicMaterial color={color} transparent opacity={0.3} side={THREE.DoubleSide} />
          </mesh>
        )}

        {/* Label */}
        {showLabel && (
          <Text
            position={[0, 4, 0]}
            fontSize={1}
            color="white"
            anchorX="center"
            anchorY="middle"
            font="/fonts/Inter_Bold.json"
          >
            {patch.name}
          </Text>
        )}

        {/* Hover tooltip */}
        {hovered && (
          <Html position={[0, 6, 0]} center>
            <div className="whitespace-nowrap rounded-lg bg-black/80 px-3 py-2 text-sm text-white shadow-lg">
              <div className="font-semibold">{patch.name}</div>
              <div className="text-xs text-gray-400 capitalize">{patch.realm} realm</div>
              {patch.metadata.description && <div className="mt-1 text-xs">{patch.metadata.description}</div>}
            </div>
          </Html>
        )}
      </group>
    </Float>
  )
}

function ConnectionLine({
  start,
  end,
  color,
}: {
  start: [number, number, number]
  end: [number, number, number]
  color: string
}) {
  const points = useMemo(() => {
    const curve = new THREE.QuadraticBezierCurve3(
      new THREE.Vector3(...start),
      new THREE.Vector3((start[0] + end[0]) / 2, Math.max(start[1], end[1]) + 5, (start[2] + end[2]) / 2),
      new THREE.Vector3(...end),
    )
    return curve.getPoints(50)
  }, [start, end])

  return <Line points={points} color={color} lineWidth={1} transparent opacity={0.4} />
}

function CentralCore() {
  const coreRef = useRef<THREE.Mesh>(null)

  useFrame(({ clock }) => {
    if (coreRef.current) {
      coreRef.current.rotation.y = clock.getElapsedTime() * 0.2
      coreRef.current.rotation.x = Math.sin(clock.getElapsedTime() * 0.5) * 0.1
    }
  })

  return (
    <group position={[0, 0, 0]}>
      {/* Core sphere */}
      <mesh ref={coreRef}>
        <icosahedronGeometry args={[5, 1]} />
        <meshStandardMaterial color="#ffd54f" emissive="#ffd54f" emissiveIntensity={0.5} wireframe />
      </mesh>

      {/* Outer glow */}
      <mesh>
        <sphereGeometry args={[6, 32, 32]} />
        <meshBasicMaterial color="#ffd54f" transparent opacity={0.1} />
      </mesh>

      {/* Label */}
      <Text position={[0, 10, 0]} fontSize={1.5} color="#ffd54f" anchorX="center" anchorY="middle">
        WIRED CHAOS
      </Text>
    </group>
  )
}
