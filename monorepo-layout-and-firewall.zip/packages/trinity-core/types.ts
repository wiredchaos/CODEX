export type Realm = "business" | "akashic" | "echo"

export interface PatchNode {
  id: string
  name: string
  mountPath: string
  realm: Realm
  position: {
    x: number
    y: number
    z: number
  }
  connections: string[] // IDs of connected patches
  metadata: {
    icon?: string
    color?: string
    description?: string
    active?: boolean
  }
}

export interface GalaxyConfig {
  patches: PatchNode[]
  currentPatch: string | null
  viewMode: "orbit" | "firstPerson" | "map"
  showConnections: boolean
  showLabels: boolean
}

export interface ElevatorState {
  isOpen: boolean
  currentFloor: string | null
  targetFloor: string | null
  isTransitioning: boolean
  availableFloors: ElevatorFloor[]
}

export interface ElevatorFloor {
  id: string
  name: string
  patchId: string
  realm: Realm
  locked: boolean
  requiredRole?: string
}

export interface TransitionConfig {
  duration: number
  easing: "linear" | "easeIn" | "easeOut" | "easeInOut"
  effect: "fade" | "zoom" | "slide" | "portal"
}

export interface TrinityEventMap {
  "galaxy:patch:hover": { patchId: string }
  "galaxy:patch:select": { patchId: string }
  "galaxy:view:change": { mode: GalaxyConfig["viewMode"] }
  "elevator:open": { floor: string }
  "elevator:close": undefined
  "elevator:transit:start": { from: string; to: string }
  "elevator:transit:end": { floor: string }
  "transition:start": { from: string; to: string }
  "transition:end": { destination: string }
}

export type TrinityEventHandler<K extends keyof TrinityEventMap> = (data: TrinityEventMap[K]) => void
