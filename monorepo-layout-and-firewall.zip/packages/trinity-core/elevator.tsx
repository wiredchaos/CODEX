"use client"

import type React from "react"
import { useState, useCallback, createContext, useContext } from "react"
import { motion, AnimatePresence } from "framer-motion"
import type { ElevatorState, ElevatorFloor, TransitionConfig } from "./types"

interface ElevatorContextValue {
  state: ElevatorState
  openElevator: () => void
  closeElevator: () => void
  selectFloor: (floorId: string) => Promise<void>
  registerFloor: (floor: ElevatorFloor) => void
}

const ElevatorContext = createContext<ElevatorContextValue | null>(null)

interface ElevatorProviderProps {
  children: React.ReactNode
  initialFloor?: string
  onTransition?: (from: string, to: string) => void
  transitionConfig?: Partial<TransitionConfig>
}

export function ElevatorProvider({
  children,
  initialFloor,
  onTransition,
  transitionConfig = {},
}: ElevatorProviderProps) {
  const [state, setState] = useState<ElevatorState>({
    isOpen: false,
    currentFloor: initialFloor || null,
    targetFloor: null,
    isTransitioning: false,
    availableFloors: [],
  })

  const config: TransitionConfig = {
    duration: 800,
    easing: "easeInOut",
    effect: "portal",
    ...transitionConfig,
  }

  const openElevator = useCallback(() => {
    setState((s) => ({ ...s, isOpen: true }))
  }, [])

  const closeElevator = useCallback(() => {
    setState((s) => ({ ...s, isOpen: false }))
  }, [])

  const registerFloor = useCallback((floor: ElevatorFloor) => {
    setState((s) => {
      if (s.availableFloors.some((f) => f.id === floor.id)) return s
      return { ...s, availableFloors: [...s.availableFloors, floor] }
    })
  }, [])

  const selectFloor = useCallback(
    async (floorId: string) => {
      const floor = state.availableFloors.find((f) => f.id === floorId)
      if (!floor || floor.locked) return

      const fromFloor = state.currentFloor

      setState((s) => ({
        ...s,
        targetFloor: floorId,
        isTransitioning: true,
        isOpen: false,
      }))

      // Notify transition start
      if (fromFloor) {
        onTransition?.(fromFloor, floorId)
      }

      // Simulate transition delay
      await new Promise((resolve) => setTimeout(resolve, config.duration))

      setState((s) => ({
        ...s,
        currentFloor: floorId,
        targetFloor: null,
        isTransitioning: false,
      }))
    },
    [state.availableFloors, state.currentFloor, onTransition, config.duration],
  )

  return (
    <ElevatorContext.Provider
      value={{
        state,
        openElevator,
        closeElevator,
        selectFloor,
        registerFloor,
      }}
    >
      {children}
    </ElevatorContext.Provider>
  )
}

export function useElevator() {
  const context = useContext(ElevatorContext)
  if (!context) {
    throw new Error("useElevator must be used within ElevatorProvider")
  }
  return context
}

// Elevator UI Component
interface ElevatorUIProps {
  className?: string
}

export function ElevatorUI({ className }: ElevatorUIProps) {
  const { state, closeElevator, selectFloor } = useElevator()

  // Group floors by realm
  const floorsByRealm = state.availableFloors.reduce(
    (acc, floor) => {
      if (!acc[floor.realm]) acc[floor.realm] = []
      acc[floor.realm].push(floor)
      return acc
    },
    {} as Record<string, ElevatorFloor[]>,
  )

  return (
    <AnimatePresence>
      {state.isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeElevator}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm"
          />

          {/* Elevator Panel */}
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className={`fixed left-1/2 top-1/2 z-50 w-full max-w-md -translate-x-1/2 -translate-y-1/2 rounded-2xl border border-white/10 bg-black/90 p-6 shadow-2xl ${className}`}
          >
            {/* Header */}
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-xl font-bold text-white">Trinity Elevator</h2>
              <button
                onClick={closeElevator}
                className="rounded-full p-2 text-gray-400 hover:bg-white/10 hover:text-white"
              >
                <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            {/* Current Floor */}
            {state.currentFloor && (
              <div className="mb-6 rounded-lg bg-white/5 p-3">
                <div className="text-xs text-gray-500">Current Location</div>
                <div className="font-semibold text-white">
                  {state.availableFloors.find((f) => f.id === state.currentFloor)?.name || state.currentFloor}
                </div>
              </div>
            )}

            {/* Floor List by Realm */}
            <div className="space-y-4">
              {Object.entries(floorsByRealm).map(([realm, floors]) => (
                <div key={realm}>
                  <div className="mb-2 text-xs font-semibold uppercase tracking-wider text-gray-500">{realm} Realm</div>
                  <div className="space-y-1">
                    {floors.map((floor) => (
                      <button
                        key={floor.id}
                        onClick={() => selectFloor(floor.id)}
                        disabled={floor.locked || floor.id === state.currentFloor || state.isTransitioning}
                        className={`w-full rounded-lg p-3 text-left transition-colors ${
                          floor.id === state.currentFloor
                            ? "bg-primary/20 text-primary"
                            : floor.locked
                              ? "cursor-not-allowed bg-white/5 text-gray-600"
                              : "bg-white/5 text-white hover:bg-white/10"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{floor.name}</span>
                          {floor.locked && (
                            <svg
                              className="h-4 w-4 text-gray-600"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke="currentColor"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                              />
                            </svg>
                          )}
                          {floor.id === state.currentFloor && <span className="text-xs text-primary">Current</span>}
                        </div>
                        {floor.requiredRole && floor.locked && (
                          <div className="mt-1 text-xs text-gray-600">Requires: {floor.requiredRole}</div>
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Transition Indicator */}
            {state.isTransitioning && (
              <div className="mt-6 flex items-center justify-center gap-2 text-primary">
                <svg className="h-5 w-5 animate-spin" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                <span>Transitioning...</span>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}

// Elevator Button (trigger)
interface ElevatorButtonProps {
  className?: string
}

export function ElevatorButton({ className }: ElevatorButtonProps) {
  const { openElevator, state } = useElevator()

  return (
    <button
      onClick={openElevator}
      disabled={state.isTransitioning}
      className={`fixed bottom-6 right-6 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg transition-transform hover:scale-110 disabled:opacity-50 ${className}`}
    >
      <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
      </svg>
    </button>
  )
}
