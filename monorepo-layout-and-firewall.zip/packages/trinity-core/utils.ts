/**
 * Trinity Core Utility Functions
 */

import * as THREE from "three"
import type { PatchNode } from "./types"

/**
 * Calculate optimal camera position to view a set of patches
 */
export function calculateCameraPosition(patches: PatchNode[]): THREE.Vector3 {
  if (patches.length === 0) {
    return new THREE.Vector3(0, 30, 50)
  }

  // Find bounding box
  let minX = Number.POSITIVE_INFINITY,
    maxX = Number.NEGATIVE_INFINITY
  let minY = Number.POSITIVE_INFINITY,
    maxY = Number.NEGATIVE_INFINITY
  let minZ = Number.POSITIVE_INFINITY,
    maxZ = Number.NEGATIVE_INFINITY

  patches.forEach((patch) => {
    minX = Math.min(minX, patch.position.x)
    maxX = Math.max(maxX, patch.position.x)
    minY = Math.min(minY, patch.position.y)
    maxY = Math.max(maxY, patch.position.y)
    minZ = Math.min(minZ, patch.position.z)
    maxZ = Math.max(maxZ, patch.position.z)
  })

  // Calculate center
  const centerX = (minX + maxX) / 2
  const centerY = (minY + maxY) / 2
  const centerZ = (minZ + maxZ) / 2

  // Calculate distance based on spread
  const spread = Math.max(maxX - minX, maxZ - minZ, maxY - minY)
  const distance = spread * 1.5 + 30

  return new THREE.Vector3(centerX, centerY + distance * 0.5, centerZ + distance)
}

/**
 * Generate positions for patches in a spiral layout
 */
export function generateSpiralPositions(count: number, spacing = 15): Array<{ x: number; y: number; z: number }> {
  const positions: Array<{ x: number; y: number; z: number }> = []

  for (let i = 0; i < count; i++) {
    const angle = i * 0.5
    const radius = spacing + i * 2
    const x = Math.cos(angle) * radius
    const z = Math.sin(angle) * radius
    const y = Math.sin(i * 0.3) * 3 // Slight vertical variation

    positions.push({ x, y, z })
  }

  return positions
}

/**
 * Generate positions for patches in a grid layout
 */
export function generateGridPositions(
  count: number,
  columns = 4,
  spacing = 20,
): Array<{ x: number; y: number; z: number }> {
  const positions: Array<{ x: number; y: number; z: number }> = []

  for (let i = 0; i < count; i++) {
    const col = i % columns
    const row = Math.floor(i / columns)
    const x = (col - (columns - 1) / 2) * spacing
    const z = row * spacing
    const y = 0

    positions.push({ x, y, z })
  }

  return positions
}

/**
 * Calculate connection strength between patches
 * Used for visual line thickness
 */
export function calculateConnectionStrength(patch1: PatchNode, patch2: PatchNode): number {
  // Same realm = stronger connection
  const realmBonus = patch1.realm === patch2.realm ? 0.5 : 0

  // Direct connection = stronger
  const directBonus = patch1.connections.includes(patch2.id) ? 0.5 : 0

  return Math.min(1, realmBonus + directBonus)
}

/**
 * Interpolate between colors for transitions
 */
export function interpolateColors(color1: string, color2: string, factor: number): string {
  const c1 = new THREE.Color(color1)
  const c2 = new THREE.Color(color2)
  c1.lerp(c2, factor)
  return `#${c1.getHexString()}`
}

/**
 * Ease functions for transitions
 */
export const easings = {
  linear: (t: number) => t,
  easeIn: (t: number) => t * t,
  easeOut: (t: number) => t * (2 - t),
  easeInOut: (t: number) => (t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t),
}

/**
 * Generate a unique node ID
 */
export function generateNodeId(prefix = "node"): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
}
