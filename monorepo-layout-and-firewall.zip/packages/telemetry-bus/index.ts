/**
 * WIRED CHAOS META Telemetry Bus
 *
 * Global event system for tracking user interactions, content engagement,
 * and hemisphere scoring across all patches.
 *
 * @package @wcm/telemetry-bus
 */

export type HemisphereType = "neuralis" | "chaosphere"

export interface TelemetryEvent {
  id: string
  type: string
  patchId: string
  userId?: string
  sessionId: string
  timestamp: Date
  data: Record<string, unknown>
  hemisphere?: {
    affinity: HemisphereType
    score: number
  }
}

export interface HemisphereScore {
  neuralis: number
  chaosphere: number
  total: number
  dominant: HemisphereType
}

type EventHandler = (event: TelemetryEvent) => void | Promise<void>

class TelemetryBusService {
  private handlers: Map<string, Set<EventHandler>> = new Map()
  private globalHandlers: Set<EventHandler> = new Set()
  private sessionId: string
  private userId?: string
  private hemisphereScores: Map<string, HemisphereScore> = new Map()

  constructor() {
    this.sessionId = this.generateSessionId()
  }

  /**
   * Set the current user ID for all events
   */
  setUser(userId: string): void {
    this.userId = userId
  }

  /**
   * Emit a telemetry event
   */
  async emit(type: string, data: Record<string, unknown>, patchId = "global"): Promise<void> {
    const event: TelemetryEvent = {
      id: this.generateEventId(),
      type,
      patchId,
      userId: this.userId,
      sessionId: this.sessionId,
      timestamp: new Date(),
      data,
    }

    // Calculate hemisphere affinity if applicable
    if (data.hemisphereScore) {
      const score = data.hemisphereScore as { neuralis: number; chaosphere: number }
      event.hemisphere = {
        affinity: score.neuralis > score.chaosphere ? "neuralis" : "chaosphere",
        score: Math.max(score.neuralis, score.chaosphere),
      }

      // Update cumulative scores
      this.updateHemisphereScore(patchId, score)
    }

    // Notify specific handlers
    const handlers = this.handlers.get(type)
    if (handlers) {
      for (const handler of handlers) {
        try {
          await handler(event)
        } catch (error) {
          console.error(`[TELEMETRY] Handler error for ${type}:`, error)
        }
      }
    }

    // Notify global handlers
    for (const handler of this.globalHandlers) {
      try {
        await handler(event)
      } catch (error) {
        console.error(`[TELEMETRY] Global handler error:`, error)
      }
    }

    // In production, would send to analytics backend
    if (process.env.NODE_ENV === "development") {
      console.log(`[TELEMETRY] ${type}`, event)
    }
  }

  /**
   * Subscribe to specific event types
   */
  on(type: string, handler: EventHandler): () => void {
    if (!this.handlers.has(type)) {
      this.handlers.set(type, new Set())
    }
    this.handlers.get(type)!.add(handler)

    // Return unsubscribe function
    return () => {
      this.handlers.get(type)?.delete(handler)
    }
  }

  /**
   * Subscribe to all events
   */
  onAll(handler: EventHandler): () => void {
    this.globalHandlers.add(handler)
    return () => {
      this.globalHandlers.delete(handler)
    }
  }

  /**
   * Get hemisphere scores for a user
   */
  getHemisphereScore(userId?: string): HemisphereScore {
    const key = userId || this.userId || "anonymous"
    return (
      this.hemisphereScores.get(key) || {
        neuralis: 50,
        chaosphere: 50,
        total: 100,
        dominant: "neuralis",
      }
    )
  }

  /**
   * Update hemisphere scores based on content interaction
   */
  private updateHemisphereScore(patchId: string, score: { neuralis: number; chaosphere: number }): void {
    const key = this.userId || "anonymous"
    const current = this.hemisphereScores.get(key) || {
      neuralis: 50,
      chaosphere: 50,
      total: 100,
      dominant: "neuralis" as HemisphereType,
    }

    // Weighted average with decay
    const weight = 0.1 // How much new scores affect the total
    const newNeuralis = current.neuralis * (1 - weight) + score.neuralis * weight
    const newChaosphere = current.chaosphere * (1 - weight) + score.chaosphere * weight

    this.hemisphereScores.set(key, {
      neuralis: Math.round(newNeuralis),
      chaosphere: Math.round(newChaosphere),
      total: 100,
      dominant: newNeuralis > newChaosphere ? "neuralis" : "chaosphere",
    })
  }

  // Predefined event emitters for common actions

  /**
   * Track content view
   */
  async trackContentView(contentId: string, patchId: string, metadata?: Record<string, unknown>): Promise<void> {
    await this.emit(
      `${patchId}:content:viewed`,
      {
        contentId,
        ...metadata,
      },
      patchId,
    )
  }

  /**
   * Track playback progress
   */
  async trackPlaybackProgress(contentId: string, patchId: string, progress: number, duration: number): Promise<void> {
    await this.emit(
      `${patchId}:playback:progress`,
      {
        contentId,
        progress,
        duration,
        percentage: Math.round((progress / duration) * 100),
      },
      patchId,
    )
  }

  /**
   * Track navigation between patches
   */
  async trackNavigation(fromPatch: string, toPatch: string, method: string): Promise<void> {
    await this.emit(
      "global:navigation",
      {
        fromPatch,
        toPatch,
        method, // 'elevator', 'galaxy', 'direct'
      },
      "global",
    )
  }

  /**
   * Track subscription events
   */
  async trackSubscription(patchId: string, action: "started" | "cancelled" | "renewed", tier: string): Promise<void> {
    await this.emit(
      `${patchId}:subscription:${action}`,
      {
        tier,
        action,
      },
      patchId,
    )
  }

  /**
   * Track AI crew interactions
   */
  async trackCrewInteraction(patchId: string, crewId: string, interactionType: string): Promise<void> {
    await this.emit(
      `${patchId}:crew:interaction`,
      {
        crewId,
        interactionType,
      },
      patchId,
    )
  }

  // Private helpers

  private generateSessionId(): string {
    return `sess_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
  }

  private generateEventId(): string {
    return `evt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
  }
}

// Singleton instance
export const telemetryBus = new TelemetryBusService()

// React hook
export function useTelemetry() {
  return {
    emit: telemetryBus.emit.bind(telemetryBus),
    on: telemetryBus.on.bind(telemetryBus),
    onAll: telemetryBus.onAll.bind(telemetryBus),
    trackContentView: telemetryBus.trackContentView.bind(telemetryBus),
    trackPlaybackProgress: telemetryBus.trackPlaybackProgress.bind(telemetryBus),
    trackNavigation: telemetryBus.trackNavigation.bind(telemetryBus),
    trackSubscription: telemetryBus.trackSubscription.bind(telemetryBus),
    trackCrewInteraction: telemetryBus.trackCrewInteraction.bind(telemetryBus),
    getHemisphereScore: telemetryBus.getHemisphereScore.bind(telemetryBus),
    setUser: telemetryBus.setUser.bind(telemetryBus),
  }
}
