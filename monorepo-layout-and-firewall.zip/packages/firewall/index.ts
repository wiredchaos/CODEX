/**
 * WIRED CHAOS META Firewall Package
 *
 * Runtime enforcement for Business vs Akashic realm isolation.
 * This package provides guards that prevent cross-realm data access
 * and service calls.
 *
 * @package @wcm/firewall
 */

export type Realm = "business" | "akashic" | "echo"

export interface FirewallContext {
  realm: Realm
  service: string
  action: string
  resourceId?: string
  userId?: string
}

export interface FirewallResult {
  allowed: boolean
  reason?: string
  auditLog?: {
    timestamp: Date
    context: FirewallContext
    decision: "allow" | "deny"
  }
}

export interface FirewallConfig {
  strictMode: boolean
  allowedCrossRealmServices: string[]
  auditEnabled: boolean
}

const defaultConfig: FirewallConfig = {
  strictMode: true,
  allowedCrossRealmServices: [], // No cross-realm by default
  auditEnabled: true,
}

class FirewallService {
  private config: FirewallConfig
  private currentRealm: Realm = "business" // Default to business realm

  constructor(config: Partial<FirewallConfig> = {}) {
    this.config = { ...defaultConfig, ...config }
  }

  /**
   * Set the current realm context
   */
  setRealm(realm: Realm): void {
    this.currentRealm = realm
  }

  /**
   * Get the current realm
   */
  getRealm(): Realm {
    return this.currentRealm
  }

  /**
   * Main guard function - call this before any service access
   */
  async guard(context: FirewallContext): Promise<FirewallResult> {
    const { realm, service, action, resourceId } = context

    // Rule 1: Check if trying to access a different realm
    if (realm !== this.currentRealm) {
      // Check if cross-realm is explicitly allowed for this service
      if (!this.config.allowedCrossRealmServices.includes(service)) {
        return this.deny(context, `Cross-realm access denied: ${this.currentRealm} cannot access ${realm} realm`)
      }
    }

    // Rule 2: Akashic services are never accessible from business realm
    if (this.currentRealm === "business" && (realm === "akashic" || realm === "echo")) {
      return this.deny(context, "Business realm cannot access Akashic/Echo services")
    }

    // Rule 3: Business services are never accessible from Akashic realm
    if ((this.currentRealm === "akashic" || this.currentRealm === "echo") && realm === "business") {
      return this.deny(context, "Akashic/Echo realm cannot access Business services")
    }

    // Rule 4: Validate service-specific permissions
    const serviceAllowed = await this.validateServicePermission(service, action, resourceId)
    if (!serviceAllowed.allowed) {
      return serviceAllowed
    }

    return this.allow(context)
  }

  /**
   * Route-level guard for API routes
   */
  async guardRoute(pathname: string): Promise<FirewallResult> {
    // Business routes: /api/business/* and /world/*
    const isBusinessRoute = pathname.startsWith("/api/business") || pathname.startsWith("/world")

    // Akashic routes: /api/echo/* and /echo/*
    const isAkashicRoute =
      pathname.startsWith("/api/echo") || pathname.startsWith("/echo") || pathname.startsWith("/akashic")

    if (this.currentRealm === "business" && isAkashicRoute) {
      return this.deny(
        { realm: "akashic", service: "route", action: "access" },
        `Business realm cannot access Akashic route: ${pathname}`,
      )
    }

    if ((this.currentRealm === "akashic" || this.currentRealm === "echo") && isBusinessRoute) {
      return this.deny(
        { realm: "business", service: "route", action: "access" },
        `Akashic realm cannot access Business route: ${pathname}`,
      )
    }

    return this.allow({ realm: this.currentRealm, service: "route", action: "access" })
  }

  /**
   * Data isolation guard for database queries
   */
  async guardData(schema: string, table: string, operation: "read" | "write" | "delete"): Promise<FirewallResult> {
    // Business data lives in business_* schemas
    const isBusinessData = schema.startsWith("business_")

    // Akashic data lives in akashic_* schemas
    const isAkashicData = schema.startsWith("akashic_") || schema.startsWith("echo_")

    if (this.currentRealm === "business" && isAkashicData) {
      return this.deny(
        { realm: "akashic", service: "database", action: operation },
        `Business realm cannot ${operation} Akashic data: ${schema}.${table}`,
      )
    }

    if ((this.currentRealm === "akashic" || this.currentRealm === "echo") && isBusinessData) {
      return this.deny(
        { realm: "business", service: "database", action: operation },
        `Akashic realm cannot ${operation} Business data: ${schema}.${table}`,
      )
    }

    return this.allow({ realm: this.currentRealm, service: "database", action: operation })
  }

  /**
   * Storage bucket guard
   */
  async guardStorage(bucket: string, operation: "read" | "write" | "delete"): Promise<FirewallResult> {
    // Naming convention: business-* for business, akashic-* for akashic
    const isBusinessBucket = bucket.startsWith("business-") || bucket.includes("-content") // e.g., 789-content
    const isAkashicBucket = bucket.startsWith("akashic-") || bucket.startsWith("echo-")

    if (this.currentRealm === "business" && isAkashicBucket) {
      return this.deny(
        { realm: "akashic", service: "storage", action: operation },
        `Business realm cannot ${operation} from Akashic bucket: ${bucket}`,
      )
    }

    if ((this.currentRealm === "akashic" || this.currentRealm === "echo") && isBusinessBucket) {
      return this.deny(
        { realm: "business", service: "storage", action: operation },
        `Akashic realm cannot ${operation} from Business bucket: ${bucket}`,
      )
    }

    return this.allow({ realm: this.currentRealm, service: "storage", action: operation })
  }

  // Private helper methods

  private async validateServicePermission(
    service: string,
    action: string,
    resourceId?: string,
  ): Promise<FirewallResult> {
    // Add service-specific permission logic here
    // For now, allow all within-realm operations
    return this.allow({ realm: this.currentRealm, service, action, resourceId })
  }

  private allow(context: FirewallContext): FirewallResult {
    const result: FirewallResult = {
      allowed: true,
    }

    if (this.config.auditEnabled) {
      result.auditLog = {
        timestamp: new Date(),
        context,
        decision: "allow",
      }
    }

    return result
  }

  private deny(context: FirewallContext, reason: string): FirewallResult {
    const result: FirewallResult = {
      allowed: false,
      reason,
    }

    if (this.config.auditEnabled) {
      result.auditLog = {
        timestamp: new Date(),
        context,
        decision: "deny",
      }
      // In production, this would be sent to a logging service
      console.warn(`[FIREWALL] Denied: ${reason}`, context)
    }

    return result
  }
}

// Singleton instance
export const firewall = new FirewallService()

// React hook for client-side realm context
export function useFirewall() {
  return {
    guard: firewall.guard.bind(firewall),
    guardRoute: firewall.guardRoute.bind(firewall),
    guardData: firewall.guardData.bind(firewall),
    guardStorage: firewall.guardStorage.bind(firewall),
    setRealm: firewall.setRealm.bind(firewall),
    getRealm: firewall.getRealm.bind(firewall),
  }
}

// Server action wrapper
export function withFirewall<T extends (...args: unknown[]) => Promise<unknown>>(realm: Realm, action: T): T {
  return (async (...args: Parameters<T>) => {
    firewall.setRealm(realm)
    return action(...args)
  }) as T
}

// Middleware helper
export async function firewallMiddleware(
  request: Request,
  realm: Realm,
): Promise<{ allowed: boolean; response?: Response }> {
  firewall.setRealm(realm)
  const url = new URL(request.url)
  const result = await firewall.guardRoute(url.pathname)

  if (!result.allowed) {
    return {
      allowed: false,
      response: new Response(JSON.stringify({ error: result.reason }), {
        status: 403,
        headers: { "Content-Type": "application/json" },
      }),
    }
  }

  return { allowed: true }
}
