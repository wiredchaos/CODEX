import LoadingComponent from "@/patches/789_studios/app/browse/loading"

export default LoadingComponent
