import BrowsePage from "@/patches/789_studios/app/browse/page"

export default BrowsePage
export { metadata } from "@/patches/789_studios/app/browse/page"
