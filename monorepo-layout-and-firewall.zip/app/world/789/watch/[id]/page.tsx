import WatchPage from "@/patches/789_studios/app/watch/[id]/page"

export default WatchPage

export async function generateMetadata({ params }: { params: { id: string } }) {
  // Metadata generation logic here
}
