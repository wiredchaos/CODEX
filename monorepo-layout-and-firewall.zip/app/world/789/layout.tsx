import Layout from "@/patches/789_studios/app/layout"

export default Layout
export { metadata } from "@/patches/789_studios/app/layout"
