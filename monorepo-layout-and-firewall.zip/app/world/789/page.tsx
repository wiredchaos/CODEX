export default function Page() {
  return null // Placeholder for the actual page content
}
export { metadata } from "@/patches/789_studios/app/page"
export { default } from "@/patches/789_studios/app/page"
