export { GET, POST } from "@/patches/789_studios/api/business/789/subscription/route"
