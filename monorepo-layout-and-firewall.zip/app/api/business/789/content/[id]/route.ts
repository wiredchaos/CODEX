export { GET } from "@/patches/789_studios/api/business/789/content/[id]/route"
