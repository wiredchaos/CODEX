// /labyrinth - Start NPC Labyrinth game
import { SlashCommandBuilder, type ChatInputCommandInteraction } from "discord.js"
import type { Command } from "../types"
import { npcStart, isError } from "../api"

export const command: Command = {
  data: new SlashCommandBuilder().setName("labyrinth").setDescription("Initialize your NPC Labyrinth session"),

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply({ ephemeral: false })

    const discordId = interaction.user.id

    const response = await npcStart(discordId, "labyrinth")

    if (isError(response)) {
      await interaction.editReply({
        content: `Signal disrupted: ${response.error}`,
      })
      return
    }

    await interaction.editReply({
      content: response.message,
    })
  },
}

export default command
