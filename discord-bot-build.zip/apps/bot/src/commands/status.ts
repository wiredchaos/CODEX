// /status command - Show user's swarm progress
import { SlashCommandBuilder, type ChatInputCommandInteraction, EmbedBuilder } from "discord.js"
import { api, isError } from "../api"

export const data = new SlashCommandBuilder()
  .setName("status")
  .setDescription("View your NEURO SWARM progress and stats")

export async function execute(interaction: ChatInputCommandInteraction) {
  await interaction.deferReply()

  try {
    const result = await api.getSwarmStatus(interaction.user.id)

    if (isError(result)) {
      await interaction.editReply("Unable to fetch your status. Try `/begin` first.")
      return
    }

    const { context, progress } = result

    const embed = new EmbedBuilder()
      .setColor(0x00ff88)
      .setTitle("NEURO SWARM STATUS")
      .setDescription(`**Ascension Level:** ${context.ascension_level}\n**Chaos Score:** ${context.chaos_score}`)
      .addFields(
        {
          name: "WL Scores",
          value: `VRG33589: **${progress.wl.vrg}**\nVAULT33: **${progress.wl.vault}**\nTotal: **${progress.wl.total}**`,
          inline: true,
        },
        {
          name: "Skills",
          value: `Unlocked: **${progress.skills.unlocked}/${progress.skills.total}**${
            progress.skills.available.length > 0
              ? `\nAvailable: ${progress.skills.available.slice(0, 3).join(", ")}`
              : ""
          }`,
          inline: true,
        },
      )

    if (progress.quest) {
      embed.addFields({
        name: "Current Quest",
        value: `**${progress.quest.name}**\n${progress.quest.description}`,
        inline: false,
      })
    }

    if (progress.nextMilestone) {
      embed.addFields({
        name: "Next Milestone",
        value: progress.nextMilestone,
        inline: false,
      })
    }

    if (context.last_agent) {
      embed.setFooter({ text: `Last interaction: ${context.last_agent}` })
    }

    await interaction.editReply({ embeds: [embed] })
  } catch (error) {
    console.error("[STATUS] Error:", error)
    await interaction.editReply("An error occurred while fetching your status.")
  }
}

export default { data, execute }
