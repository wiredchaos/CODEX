// /set-gen - Set generational profile
import { SlashCommandBuilder, type ChatInputCommandInteraction } from "discord.js"
import type { Command, Generation } from "../types"
import { setGen, isError } from "../api"

const generations: Generation[] = ["Boomer", "GenX", "Millennial", "GenZ", "GenAlpha"]

export const command: Command = {
  data: new SlashCommandBuilder()
    .setName("set-gen")
    .setDescription("Set your generational profile")
    .addStringOption((option) =>
      option
        .setName("generation")
        .setDescription("Your generation")
        .setRequired(true)
        .addChoices(
          { name: "Boomer (1946-1964)", value: "Boomer" },
          { name: "Gen X (1965-1980)", value: "GenX" },
          { name: "Millennial (1981-1996)", value: "Millennial" },
          { name: "Gen Z (1997-2012)", value: "GenZ" },
          { name: "Gen Alpha (2013+)", value: "GenAlpha" },
        ),
    ),

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply({ ephemeral: true })

    const discordId = interaction.user.id
    const generation = interaction.options.getString("generation", true) as Generation

    const response = await setGen(discordId, generation)

    if (isError(response)) {
      await interaction.editReply({
        content: `Signal disrupted: ${response.error}`,
      })
      return
    }

    await interaction.editReply({
      content: response.message,
    })
  },
}

export default command
