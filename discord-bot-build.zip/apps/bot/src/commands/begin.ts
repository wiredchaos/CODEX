// /begin - Initialize user profile
import { SlashCommandBuilder, type ChatInputCommandInteraction } from "discord.js"
import type { Command } from "../types"
import { begin, isError } from "../api"

export const command: Command = {
  data: new SlashCommandBuilder().setName("begin").setDescription("Initialize your WIRED CHAOS META profile"),

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply({ ephemeral: true })

    const discordId = interaction.user.id
    const username = interaction.user.username

    const response = await begin(discordId, username)

    if (isError(response)) {
      await interaction.editReply({
        content: `Signal disrupted: ${response.error}`,
      })
      return
    }

    await interaction.editReply({
      content: response.message,
    })
  },
}

export default command
