// /move - Send a move to the NPC game
import { SlashCommandBuilder, type ChatInputCommandInteraction } from "discord.js"
import type { Command } from "../types"
import { npcMove, isError } from "../api"

export const command: Command = {
  data: new SlashCommandBuilder()
    .setName("move")
    .setDescription("Send your move to the Labyrinth")
    .addStringOption((option) => option.setName("prompt").setDescription("Your action or prompt").setRequired(true)),

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply({ ephemeral: false })

    const discordId = interaction.user.id
    const prompt = interaction.options.getString("prompt", true)

    const response = await npcMove(discordId, prompt, "labyrinth")

    if (isError(response)) {
      await interaction.editReply({
        content: `Signal disrupted: ${response.error}`,
      })
      return
    }

    // Build the response with narrative and WL note
    const content = [response.narrative, "", `---`, response.ledgerNote, `Move #${response.session.moveCount}`].join(
      "\n",
    )

    await interaction.editReply({ content })
  },
}

export default command
