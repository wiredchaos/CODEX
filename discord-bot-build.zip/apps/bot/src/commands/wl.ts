// /wl - Check whitelist scores
import { SlashCommandBuilder, type ChatInputCommandInteraction, EmbedBuilder } from "discord.js"
import type { Command } from "../types"
import { getWLScore, isError } from "../api"

export const command: Command = {
  data: new SlashCommandBuilder().setName("wl").setDescription("Check your whitelist scores"),

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply({ ephemeral: true })

    const discordId = interaction.user.id

    const response = await getWLScore(discordId)

    if (isError(response)) {
      await interaction.editReply({
        content: `Signal disrupted: ${response.error}`,
      })
      return
    }

    const { scores } = response

    const embed = new EmbedBuilder()
      .setTitle("NEURO GRYMM - Ledger Report")
      .setColor(0x1a1a2e)
      .addFields(
        { name: "VRG33589", value: `${scores.vrg33589} WL`, inline: true },
        { name: "VAULT33", value: `${scores.vault33} WL`, inline: true },
        { name: "Total Moves", value: `${scores.totalMoves}`, inline: true },
      )
      .setFooter({ text: "Your cumulative signal continues to rise." })

    if (scores.lastActivity) {
      embed.setTimestamp(new Date(scores.lastActivity))
    }

    await interaction.editReply({ embeds: [embed] })
  },
}

export default command
