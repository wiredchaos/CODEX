// /set-wallet - Bind wallet address for WL
import { SlashCommandBuilder, type ChatInputCommandInteraction } from "discord.js"
import type { Command } from "../types"
import { setWallet, isError } from "../api"

export const command: Command = {
  data: new SlashCommandBuilder()
    .setName("set-wallet")
    .setDescription("Bind your wallet address for whitelist tracking")
    .addStringOption((option) =>
      option.setName("address").setDescription("Your Ethereum (0x...) or Solana wallet address").setRequired(true),
    ),

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply({ ephemeral: true })

    const discordId = interaction.user.id
    const walletAddress = interaction.options.getString("address", true)

    const response = await setWallet(discordId, walletAddress)

    if (isError(response)) {
      await interaction.editReply({
        content: `Signal disrupted: ${response.error}`,
      })
      return
    }

    await interaction.editReply({
      content: response.message,
    })
  },
}

export default command
