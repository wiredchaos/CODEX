// /admin command - Admin-only server management
import { SlashCommandBuilder, type ChatInputCommandInteraction, PermissionFlagsBits, EmbedBuilder } from "discord.js"
import { setupServer } from "../../../scripts/discord-server-setup"

export const data = new SlashCommandBuilder()
  .setName("admin")
  .setDescription("Admin commands for server management")
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  .addSubcommand((sub) =>
    sub.setName("setup-server").setDescription("Run full server setup (roles, channels, permissions)"),
  )
  .addSubcommand((sub) => sub.setName("stats").setDescription("View server statistics"))

export async function execute(interaction: ChatInputCommandInteraction) {
  const subcommand = interaction.options.getSubcommand()

  if (subcommand === "setup-server") {
    await interaction.deferReply({ ephemeral: true })

    try {
      const guild = interaction.guild
      if (!guild) {
        await interaction.editReply("This command must be run in a server.")
        return
      }

      await setupServer(guild)

      const embed = new EmbedBuilder()
        .setColor(0x00ff88)
        .setTitle("Server Setup Complete")
        .setDescription(
          "All roles, channels, and permissions have been configured for NEURO SWARM.\n\n" +
            "**Created:**\n" +
            "- WL tier roles (VRG33589, VAULT33)\n" +
            "- NEURO mode roles\n" +
            "- Generation roles\n" +
            "- 789 CREW roles\n" +
            "- All NPC and WL channels\n" +
            "- Role-gated access channels",
        )

      await interaction.editReply({ embeds: [embed] })
    } catch (error) {
      console.error("[ADMIN] Setup error:", error)
      await interaction.editReply("An error occurred during setup. Check bot logs.")
    }
  } else if (subcommand === "stats") {
    await interaction.deferReply({ ephemeral: true })

    const guild = interaction.guild
    if (!guild) {
      await interaction.editReply("This command must be run in a server.")
      return
    }

    const embed = new EmbedBuilder()
      .setColor(0x00ff88)
      .setTitle("Server Statistics")
      .addFields(
        { name: "Members", value: `${guild.memberCount}`, inline: true },
        { name: "Channels", value: `${guild.channels.cache.size}`, inline: true },
        { name: "Roles", value: `${guild.roles.cache.size}`, inline: true },
      )

    await interaction.editReply({ embeds: [embed] })
  }
}

export default { data, execute }
