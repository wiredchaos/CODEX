// Discord Bot Configuration
// These values should be set in your deployment environment (Railway, Render, etc.)

export const BOT_TOKEN = process.env.DISCORD_BOT_TOKEN as string
export const APP_ID = process.env.DISCORD_APP_ID as string
export const GUILD_ID = process.env.DISCORD_GUILD_ID as string

// Your Next.js app URL (Vercel deployment)
export const APP_BASE_URL = process.env.APP_BASE_URL || "https://your-app.vercel.app"

// Channel IDs (optional - set in environment)
export const CHANNELS = {
  npcLabyrinth: process.env.CH_NPC_LABYRINTH_ID,
  profileSetup: process.env.CH_PROFILE_SETUP_ID,
  vrgLore: process.env.CH_VRG_LORE_ID,
  vault33Signals: process.env.CH_VAULT33_SIGNALS_ID,
  whitelistBriefings: process.env.CH_WHITELIST_BRIEFINGS_ID,
}

// Validate required environment variables
export function validateConfig(): boolean {
  const required = ["DISCORD_BOT_TOKEN", "DISCORD_APP_ID", "DISCORD_GUILD_ID", "APP_BASE_URL"]

  const missing = required.filter((key) => !process.env[key])

  if (missing.length > 0) {
    console.error(`Missing required environment variables: ${missing.join(", ")}`)
    return false
  }

  return true
}
