// NEURO SWARM Discord Bot - Main Entry Point
import { Client, GatewayIntentBits, Events, REST, Routes } from "discord.js"
import { BOT_TOKEN, APP_ID, GUILD_ID, validateConfig } from "./config"
import { commands, getCommandsData, getCommand } from "./commands"

// Validate configuration
if (!validateConfig()) {
  console.error("Bot configuration invalid. Exiting.")
  process.exit(1)
}

// Create Discord client
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
  ],
})

// Register slash commands
async function registerCommands() {
  const rest = new REST({ version: "10" }).setToken(BOT_TOKEN)

  try {
    console.log(`Registering ${commands.length} slash commands...`)

    await rest.put(Routes.applicationGuildCommands(APP_ID, GUILD_ID), {
      body: getCommandsData(),
    })

    console.log("Slash commands registered successfully.")
  } catch (error) {
    console.error("Failed to register slash commands:", error)
  }
}

// Ready event
client.once(Events.ClientReady, (readyClient) => {
  console.log(`NEURO SWARM BOT online as ${readyClient.user.tag}`)
  console.log(`Connected to ${readyClient.guilds.cache.size} guilds`)
})

// Interaction handler
client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isChatInputCommand()) return

  const command = getCommand(interaction.commandName)
  if (!command) {
    console.warn(`Unknown command: ${interaction.commandName}`)
    return
  }

  try {
    console.log(`[CMD] ${interaction.user.tag} used /${interaction.commandName}`)
    await command.execute(interaction)
  } catch (error) {
    console.error(`[CMD ERROR] /${interaction.commandName}:`, error)

    const errorMessage = "Something glitched in the signal. Try again in a moment."

    if (interaction.replied || interaction.deferred) {
      await interaction.followUp({ content: errorMessage, ephemeral: true })
    } else {
      await interaction.reply({ content: errorMessage, ephemeral: true })
    }
  }
})

// Error handling
client.on(Events.Error, (error) => {
  console.error("Discord client error:", error)
})

process.on("unhandledRejection", (error) => {
  console.error("Unhandled promise rejection:", error)
})

// Start the bot
async function main() {
  await registerCommands()
  await client.login(BOT_TOKEN)
}

main().catch(console.error)
