// API Client for Next.js backend
import { APP_BASE_URL } from "./config"
import type {
  BeginResponse,
  SetGenResponse,
  SetNeuroResponse,
  SetWalletResponse,
  NPCStartResponse,
  NPCMoveResponse,
  WLScoreResponse,
  ErrorResponse,
  Generation,
  SwarmStatusResponse,
  SwarmEventResponse,
} from "./types"

async function apiCall<T>(
  endpoint: string,
  method: "GET" | "POST" = "POST",
  body?: unknown,
): Promise<T | ErrorResponse> {
  try {
    const url = `${APP_BASE_URL}${endpoint}`
    const options: RequestInit = {
      method,
      headers: { "Content-Type": "application/json" },
    }

    if (body && method === "POST") {
      options.body = JSON.stringify(body)
    }

    const res = await fetch(url, options)
    return (await res.json()) as T | ErrorResponse
  } catch (error) {
    console.error(`[API] Error calling ${endpoint}:`, error)
    return { error: "Failed to connect to server" }
  }
}

// Onboarding commands
export async function begin(discordId: string, username?: string): Promise<BeginResponse | ErrorResponse> {
  return apiCall<BeginResponse>("/api/discord/begin", "POST", { discordId, username })
}

export async function setGen(discordId: string, generation: Generation): Promise<SetGenResponse | ErrorResponse> {
  return apiCall<SetGenResponse>("/api/discord/set-gen", "POST", { discordId, generation })
}

export async function setNeuro(discordId: string, enabled: boolean): Promise<SetNeuroResponse | ErrorResponse> {
  return apiCall<SetNeuroResponse>("/api/discord/set-neuro", "POST", { discordId, enabled })
}

export async function setWallet(discordId: string, walletAddress: string): Promise<SetWalletResponse | ErrorResponse> {
  return apiCall<SetWalletResponse>("/api/discord/set-wallet", "POST", { discordId, walletAddress })
}

// NPC Game commands
export async function npcStart(discordId: string, game = "labyrinth"): Promise<NPCStartResponse | ErrorResponse> {
  return apiCall<NPCStartResponse>("/api/npc/start", "POST", { discordId, game })
}

export async function npcMove(
  discordId: string,
  prompt: string,
  game = "labyrinth",
): Promise<NPCMoveResponse | ErrorResponse> {
  return apiCall<NPCMoveResponse>("/api/npc/move", "POST", {
    discordId,
    prompt,
    game,
    platform: "discord",
  })
}

// WL commands
export async function getWLScore(discordId: string): Promise<WLScoreResponse | ErrorResponse> {
  return apiCall<WLScoreResponse>(`/api/wl/score?discordId=${discordId}`, "GET")
}

// Swarm commands
export async function getSwarmStatus(discordId: string): Promise<SwarmStatusResponse | ErrorResponse> {
  return apiCall<SwarmStatusResponse>(`/api/swarm/status?discordId=${discordId}`, "GET")
}

export async function sendSwarmEvent(
  discordId: string,
  eventType: string,
  eventData?: Record<string, unknown>,
): Promise<SwarmEventResponse | ErrorResponse> {
  return apiCall<SwarmEventResponse>("/api/swarm/event", "POST", { discordId, eventType, eventData })
}

export const api = {
  begin,
  setGen,
  setNeuro,
  setWallet,
  npcStart,
  npcMove,
  getWLScore,
  getSwarmStatus,
  sendSwarmEvent,
  isError,
}

// Type guard
export function isError(response: unknown): response is ErrorResponse {
  return typeof response === "object" && response !== null && "error" in response
}
