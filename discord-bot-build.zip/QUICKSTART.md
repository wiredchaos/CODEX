# NEURO SWARM - Quick Start Guide

Get your Discord bot running in under 15 minutes.

## Prerequisites

- Discord account with a server you manage
- GitHub account
- Vercel account (free)
- Railway account (free $5 credit)

---

## 3-Step Deployment

### 1️⃣ Deploy Backend (5 min)

**From v0:**
1. Click **"Publish"** button (top right)
2. Connect GitHub → Deploy to Vercel
3. Copy your URL: `https://YOUR-APP.vercel.app`

---

### 2️⃣ Create Discord Bot (5 min)

1. Go to [discord.com/developers/applications](https://discord.com/developers/applications)
2. Click **"New Application"** → Name it "WIRED CHAOS"
3. Go to **Bot** tab → Click **"Add Bot"**
4. **Copy the token** (save it!)
5. Enable these intents:
   - ✅ MESSAGE CONTENT
   - ✅ SERVER MEMBERS
   - ✅ PRESENCE
6. Go to **General Information** → Copy **Application ID**
7. In Discord desktop → Enable **Developer Mode** (Settings → Advanced)
8. Right-click your server → **Copy Server ID**
9. Go to **OAuth2 → URL Generator**:
   - Select: `bot`, `applications.commands`
   - Select: Send Messages, Embed Links, Use Slash Commands
   - Copy URL and invite bot to your server

---

### 3️⃣ Deploy Bot to Railway (5 min)

1. Push code to GitHub (if not from v0):
   ```bash
   git add .
   git commit -m "Deploy bot"
   git push
   ```

2. Go to [railway.app](https://railway.app) → Sign in with GitHub

3. **New Project** → **Deploy from GitHub repo** → Select your repo

4. Click service → **Settings** → Set **Root Directory** to: `/bot`

5. Go to **Variables** tab → Add these:
   ```
   DISCORD_BOT_TOKEN=paste_your_bot_token
   DISCORD_APP_ID=paste_your_application_id
   DISCORD_GUILD_ID=paste_your_server_id
   APP_BASE_URL=https://YOUR-APP.vercel.app
   ```

6. Wait for deployment → Check logs for:
   ```
   ✅ NEURO SWARM BOT online
   ```

---

## Test It

In Discord, type:
```
/begin
```

You should see KIBA respond with generation options!

---

## What You Built

- **7 NEURO Agents** (META_X, KIBA, SHADOWLUX, GRYMM, OYALAN, NEUROLUX, UPLINK)
- **Onboarding System** (`/begin`, `/set-gen`, `/set-neuro`, `/set-wallet`)
- **NPC Games** (`/labyrinth`, `/move`)
- **WL Tracking** (`/wl` for dual leaderboards)
- **Admin Dashboard** (your Vercel URL)

---

## Next Steps

1. **Add Database** → In v0: "Migrate to Neon database"
2. **Customize Agents** → Edit `lib/neuro/voicepack.json`
3. **Add Games** → Implement Alchemist, Forge, Triage games
4. **789 CREW** → Auto-detect and grant WL bonuses

---

## Stuck?

- **Bot offline?** → Check Railway logs and verify token
- **Commands not showing?** → Wait 1 hour or kick/re-invite bot
- **API errors?** → Verify APP_BASE_URL has no trailing slash
- **Need help?** → Join [discord.gg/TsuK6wM4h](https://discord.gg/TsuK6wM4h)

Full guide: See [DEPLOYMENT.md](./DEPLOYMENT.md)
