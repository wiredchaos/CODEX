"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { HealthStatus } from "@/lib/swarm/schema"

export function NpcStatus() {
  const [health, setHealth] = useState<HealthStatus | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchHealth() {
      try {
        const res = await fetch("/api/health")
        const data = await res.json()
        setHealth(data)
      } catch (error) {
        console.error("Failed to fetch health:", error)
        setHealth({
          npcSessionsToday: 0,
          xpEventsToday: 0,
          status: "offline",
          swarmAgentsOnline: 0,
          uptime: "0ms",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchHealth()
    const interval = setInterval(fetchHealth, 30000)
    return () => clearInterval(interval)
  }, [])

  const statusColor = {
    ok: "bg-green-500",
    degraded: "bg-amber-500",
    offline: "bg-red-500",
  }

  if (loading) {
    return (
      <Card className="bg-black/40 border-primary/20">
        <CardContent className="p-6">
          <div className="h-24 animate-pulse bg-muted rounded" />
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="bg-black/40 border-primary/20">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-mono">NPC Engine Status</CardTitle>
          <Badge variant="outline" className={`${statusColor[health?.status || "offline"]} bg-opacity-20`}>
            <span className={`h-2 w-2 rounded-full ${statusColor[health?.status || "offline"]} mr-2`} />
            {health?.status?.toUpperCase() || "UNKNOWN"}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center p-3 bg-black/30 rounded-lg">
            <div className="text-2xl font-bold text-primary font-mono">{health?.npcSessionsToday || 0}</div>
            <div className="text-xs text-muted-foreground uppercase tracking-wider">Sessions Today</div>
          </div>

          <div className="text-center p-3 bg-black/30 rounded-lg">
            <div className="text-2xl font-bold text-green-400 font-mono">{health?.xpEventsToday || 0}</div>
            <div className="text-xs text-muted-foreground uppercase tracking-wider">WL Events</div>
          </div>

          <div className="text-center p-3 bg-black/30 rounded-lg">
            <div className="text-2xl font-bold text-cyan-400 font-mono">{health?.swarmAgentsOnline || 0}/7</div>
            <div className="text-xs text-muted-foreground uppercase tracking-wider">Agents Online</div>
          </div>

          <div className="text-center p-3 bg-black/30 rounded-lg">
            <div className="text-2xl font-bold text-amber-400 font-mono">{health?.uptime || "0ms"}</div>
            <div className="text-xs text-muted-foreground uppercase tracking-wider">Response Time</div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
