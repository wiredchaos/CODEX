"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { SWARM_AGENTS } from "@/lib/swarm/agents"

export function SwarmAgents() {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <span className="text-xl">⬡</span>
        <h2 className="text-xl font-bold">NEURO SWARM Agents</h2>
        <Badge variant="outline" className="ml-auto">
          7 Active
        </Badge>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {SWARM_AGENTS.map((agent) => (
          <Card
            key={agent.id}
            className="bg-black/40 border-primary/20 hover:border-primary/40 transition-colors"
            style={{ borderColor: `${agent.color}33` }}
          >
            <CardHeader className="pb-2">
              <div className="flex items-center gap-2">
                <span className="text-2xl" style={{ color: agent.color }}>
                  {agent.icon}
                </span>
                <div>
                  <CardTitle className="text-base" style={{ color: agent.color }}>
                    {agent.name}
                  </CardTitle>
                  <CardDescription className="text-xs">{agent.role}</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground leading-relaxed">{agent.description}</p>
              <div className="mt-3 flex items-center gap-2">
                <div className="h-2 w-2 rounded-full animate-pulse" style={{ backgroundColor: agent.color }} />
                <span className="text-xs text-muted-foreground font-mono">ONLINE</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
