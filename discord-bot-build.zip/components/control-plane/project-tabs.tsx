"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface TierInfo {
  name: string
  threshold: number
  color: string
}

const VRG_TIERS: TierInfo[] = [
  { name: "Signal Carrier", threshold: 333, color: "text-cyan-400 border-cyan-500/50" },
  { name: "Beacon", threshold: 589, color: "text-cyan-300 border-cyan-400/50" },
]

const VAULT_TIERS: TierInfo[] = [
  { name: "Gatewatcher", threshold: 333, color: "text-amber-400 border-amber-500/50" },
  { name: "Keyholder", threshold: 589, color: "text-amber-300 border-amber-400/50" },
]

export function ProjectTabs() {
  const [activeTab, setActiveTab] = useState("vrg33589")

  return (
    <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
      <TabsList className="grid w-full grid-cols-2 bg-black/40">
        <TabsTrigger value="vrg33589" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
          VRG33589
        </TabsTrigger>
        <TabsTrigger value="vault33" className="data-[state=active]:bg-amber-500/20 data-[state=active]:text-amber-400">
          VAULT33
        </TabsTrigger>
      </TabsList>

      <TabsContent value="vrg33589" className="mt-4">
        <Card className="bg-black/40 border-cyan-500/20">
          <CardHeader>
            <CardTitle className="text-cyan-400 flex items-center gap-2">
              <span className="text-2xl">◈</span>
              VRG33589
            </CardTitle>
            <CardDescription>
              The primary signal network. Accumulate WL through NPC interactions and community engagement.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <h4 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">WL Tiers</h4>
              <div className="grid gap-3">
                {VRG_TIERS.map((tier) => (
                  <div
                    key={tier.name}
                    className="flex items-center justify-between p-3 bg-black/30 rounded-lg border border-cyan-500/10"
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-3 w-3 rounded-full bg-cyan-500/50" />
                      <span className={tier.color}>{tier.name}</span>
                    </div>
                    <Badge variant="outline" className={tier.color}>
                      ≥ {tier.threshold} WL
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="vault33" className="mt-4">
        <Card className="bg-black/40 border-amber-500/20">
          <CardHeader>
            <CardTitle className="text-amber-400 flex items-center gap-2">
              <span className="text-2xl">▣</span>
              VAULT33
            </CardTitle>
            <CardDescription>
              The secure vault network. Higher stakes, greater rewards for dedicated participants.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <h4 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">WL Tiers</h4>
              <div className="grid gap-3">
                {VAULT_TIERS.map((tier) => (
                  <div
                    key={tier.name}
                    className="flex items-center justify-between p-3 bg-black/30 rounded-lg border border-amber-500/10"
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-3 w-3 rounded-full bg-amber-500/50" />
                      <span className={tier.color}>{tier.name}</span>
                    </div>
                    <Badge variant="outline" className={tier.color}>
                      ≥ {tier.threshold} WL
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  )
}
