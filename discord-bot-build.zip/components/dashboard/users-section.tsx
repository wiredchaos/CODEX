"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Users, Wallet, Brain, Calendar, Zap, CheckCircle } from "lucide-react"

interface User {
  discordId: string
  username: string | null
  generation: string | null
  neuroMode: string | null
  wallet: string | null
  is789Crew: boolean
  onboardingComplete: boolean
  createdAt: string
  wlScores: {
    vrg33589: number
    vault33: number
    total: number
    gamesWon: number
  } | null
}

export function UsersSection() {
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchUsers() {
      try {
        const res = await fetch("/api/admin/users?limit=50")
        const data = await res.json()
        setUsers(data.users || [])
      } catch (error) {
        console.error("Failed to fetch users:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchUsers()
  }, [])

  return (
    <Card className="border-border/50">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-foreground">
          <Users className="h-5 w-5 text-primary" />
          Registered Users
          {!loading && (
            <Badge variant="secondary" className="ml-2">
              {users.length}
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-40 animate-pulse bg-muted rounded-lg" />
            ))}
          </div>
        ) : users.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">No users registered yet</p>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {users.map((user) => (
              <div
                key={user.discordId}
                className={`rounded-lg border p-4 transition-colors ${
                  user.is789Crew
                    ? "border-accent/30 bg-accent/5"
                    : user.onboardingComplete
                      ? "border-primary/20 bg-card"
                      : "border-border/30 bg-card"
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="min-w-0 flex-1">
                    <p className="font-medium text-foreground truncate">
                      {user.username || `${user.discordId.slice(0, 12)}...`}
                    </p>
                    <div className="flex items-center gap-2 mt-1">
                      {user.generation && (
                        <Badge variant="outline" className="text-xs border-primary/30 text-primary">
                          {user.generation}
                        </Badge>
                      )}
                      {user.neuroMode && user.neuroMode !== "STANDARD" && (
                        <Badge variant="outline" className="text-xs border-chart-2/30 text-chart-2">
                          {user.neuroMode}
                        </Badge>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-1">
                    {user.onboardingComplete && (
                      <div className="flex h-6 w-6 items-center justify-center rounded bg-primary/10" title="Onboarded">
                        <CheckCircle className="h-3 w-3 text-primary" />
                      </div>
                    )}
                    {user.neuroMode === "CHAOS" && (
                      <div
                        className="flex h-6 w-6 items-center justify-center rounded bg-chart-4/10"
                        title="CHAOS Mode"
                      >
                        <Brain className="h-3 w-3 text-chart-4" />
                      </div>
                    )}
                    {user.is789Crew && (
                      <div className="flex h-6 w-6 items-center justify-center rounded bg-accent/20" title="789 CREW">
                        <Zap className="h-3 w-3 text-accent" />
                      </div>
                    )}
                  </div>
                </div>

                {user.wallet && (
                  <div className="flex items-center gap-1 text-xs text-muted-foreground mb-3">
                    <Wallet className="h-3 w-3" />
                    <span className="font-mono">{user.wallet}</span>
                  </div>
                )}

                {user.wlScores && (
                  <div className="grid grid-cols-3 gap-2 text-center mb-3">
                    <div className="rounded bg-primary/10 p-2">
                      <p className="text-sm font-bold text-primary">{user.wlScores.vrg33589}</p>
                      <p className="text-[10px] text-muted-foreground">VRG</p>
                    </div>
                    <div className="rounded bg-chart-2/10 p-2">
                      <p className="text-sm font-bold text-chart-2">{user.wlScores.vault33}</p>
                      <p className="text-[10px] text-muted-foreground">VAULT</p>
                    </div>
                    <div className="rounded bg-muted p-2">
                      <p className="text-sm font-bold text-foreground">{user.wlScores.gamesWon}</p>
                      <p className="text-[10px] text-muted-foreground">Wins</p>
                    </div>
                  </div>
                )}

                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Calendar className="h-3 w-3" />
                  <span>{new Date(user.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
