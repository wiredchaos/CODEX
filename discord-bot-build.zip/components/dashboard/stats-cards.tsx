"use client"

import { useEffect, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Users, Trophy, Gamepad2, TrendingUp, CheckCircle, Zap } from "lucide-react"

interface Stats {
  totalUsers: number
  onboardedUsers: number
  crew789Count: number
  totalWLPoints: number
  activeGames: number
  gamesCompleted: number
}

export function StatsCards() {
  const [stats, setStats] = useState<Stats | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchStats() {
      try {
        const res = await fetch("/api/admin/users?stats=true")
        const data = await res.json()
        setStats(data.stats || null)
      } catch (error) {
        console.error("Failed to fetch stats:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchStats()
  }, [])

  if (loading) {
    return (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        {[...Array(6)].map((_, i) => (
          <Card key={i}>
            <CardContent className="p-4">
              <div className="h-16 animate-pulse bg-muted rounded" />
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  const cards = [
    {
      label: "Total Users",
      value: stats?.totalUsers ?? 0,
      icon: Users,
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
    {
      label: "Onboarded",
      value: stats?.onboardedUsers ?? 0,
      icon: CheckCircle,
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
    {
      label: "789 CREW",
      value: stats?.crew789Count ?? 0,
      icon: Zap,
      color: "text-accent",
      bgColor: "bg-accent/10",
    },
    {
      label: "Total WL",
      value: stats?.totalWLPoints ?? 0,
      icon: Trophy,
      color: "text-accent",
      bgColor: "bg-accent/10",
    },
    {
      label: "Active Games",
      value: stats?.activeGames ?? 0,
      icon: Gamepad2,
      color: "text-chart-2",
      bgColor: "bg-chart-2/10",
    },
    {
      label: "Completed",
      value: stats?.gamesCompleted ?? 0,
      icon: TrendingUp,
      color: "text-chart-2",
      bgColor: "bg-chart-2/10",
    },
  ]

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
      {cards.map((card) => (
        <Card key={card.label} className="border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${card.bgColor}`}>
                <card.icon className={`h-5 w-5 ${card.color}`} />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{card.value.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">{card.label}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
