"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Activity, Bot, Gamepad2, Trophy, UserPlus } from "lucide-react"

interface ActivityEntry {
  id: string
  agent_id: string
  action_type: string
  discord_id: string | null
  template_key: string | null
  created_at: string
}

const ACTION_ICONS: Record<string, typeof Activity> = {
  ONBOARDING: UserPlus,
  WL_AWARD: Trophy,
  GAME_START: Gamepad2,
  GAME_MOVE: Gamepad2,
  SET_GENERATION: Bot,
  SET_NEURO_MODE: Bot,
  SET_WALLET: Bot,
}

const AGENT_COLORS: Record<string, string> = {
  META_X: "text-accent",
  KIBA: "text-primary",
  SHADOWLUX: "text-chart-4",
  GRYMM: "text-chart-5",
  OYALAN: "text-chart-2",
  NEUROLUX: "text-chart-3",
  UPLINK: "text-muted-foreground",
}

export function RecentActivitySection() {
  const [activity, setActivity] = useState<ActivityEntry[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchActivity() {
      try {
        const res = await fetch("/api/admin/activity?limit=15")
        const data = await res.json()
        setActivity(data.activity || [])
      } catch (error) {
        console.error("Failed to fetch activity:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchActivity()
    // Poll every 30 seconds for live updates
    const interval = setInterval(fetchActivity, 30000)
    return () => clearInterval(interval)
  }, [])

  return (
    <Card className="border-border/50">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-foreground">
          <Activity className="h-5 w-5 text-primary" />
          Agent Activity
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-2">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="h-10 animate-pulse bg-muted rounded" />
            ))}
          </div>
        ) : activity.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">No activity yet</p>
        ) : (
          <div className="space-y-2 max-h-[400px] overflow-y-auto">
            {activity.map((entry) => {
              const Icon = ACTION_ICONS[entry.action_type] || Activity
              const agentColor = AGENT_COLORS[entry.agent_id] || "text-muted-foreground"

              return (
                <div key={entry.id} className="flex items-center gap-3 rounded-lg border border-border/30 bg-card p-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded bg-muted/50">
                    <Icon className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className={`text-xs font-medium ${agentColor}`}>{entry.agent_id}</span>
                      <span className="text-xs text-muted-foreground">{entry.action_type.replace(/_/g, " ")}</span>
                    </div>
                    {entry.discord_id && (
                      <p className="text-xs text-muted-foreground truncate">{entry.discord_id.slice(0, 12)}...</p>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">{new Date(entry.created_at).toLocaleTimeString()}</p>
                </div>
              )
            })}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
