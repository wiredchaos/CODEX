# NEURO SWARM Control Plane — Vercel Builder Prompt

Use this prompt when rebuilding or extending the control plane in Vercel's AI builder or v0:

---

## PROJECT SPEC

Build a Next.js 14 App Router dashboard for the **NEURO SWARM** system with the following:

### Visual Design
- Dark cyberpunk aesthetic with neon accents
- Primary color: cyan (#00ff88)
- Secondary colors: amber for VAULT33, cyan for VRG33589
- Black backgrounds with subtle borders
- Monospace fonts for data displays

### Page Structure

**Header:**
- Title: "WIRED CHAOS META — NEURO SWARM CONTROL PLANE"
- Subtitle: "VRG33589 × VAULT33 • WL, NPC, and Agent State"

**Section 1 — Live Ticker:**
- Auto-scrolling list of WL events
- Each row shows: project badge, +delta, source, platform, timestamp
- Pauses on hover
- Fetches from GET /api/ticker

**Section 2 — Project Tabs:**
- Two tabs: VRG33589 and VAULT33
- Each tab shows:
  - Project description
  - WL tier thresholds:
    - VRG: Signal Carrier ≥333, Beacon ≥589
    - VAULT: Gatewatcher ≥333, Keyholder ≥589

**Section 3 — NPC Status:**
- Grid of 4 stat cards:
  - Sessions Today
  - WL Events Today
  - Agents Online (X/7)
  - Response Time
- Status badge: OK / DEGRADED / OFFLINE
- Fetches from GET /api/health

**Section 4 — NEURO SWARM Agents:**
- Card grid showing all 7 agents:
  - META_X (Swarm General)
  - KIBA (Onboarding)
  - SHADOWLUX (Moderation)
  - GRYMM (WL/Ledger)
  - OYALAN (Governance)
  - NEUROLUX (Lore/ARG)
  - UPLINK (Infra)
- Each card shows: icon, name, role, description, online status

### API Endpoints

- GET /api/ticker → returns { items: TickerItem[] }
- GET /api/health → returns HealthStatus
- POST /api/npc/move → NPC game interaction
- POST /api/wl/log → Log WL events
- POST /api/swarm/event → Generic agent events

### Tech Stack
- Next.js 14 App Router
- TypeScript
- Tailwind CSS
- shadcn/ui components
- Neon PostgreSQL (via DATABASE_URL)

---

END OF BUILDER PROMPT
