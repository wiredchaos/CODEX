# WIRED CHAOS META — Deployment Guide

## Zero-Touch Deployment Steps

### 1. Deploy Next.js Control Plane (Vercel)

Since you're in v0, deployment is automatic:

1. **Click "Publish"** in the top right of v0
2. Vercel will automatically:
   - Build the Next.js app
   - Deploy to a production URL
   - Set up environment variables from your Neon integration
3. Copy your deployed URL (e.g., `https://wc-dicbot.vercel.app`)

### 2. Run Database Migration

Before the bot can store data, run the migration:

1. Go to your Neon dashboard
2. Open the SQL Editor
3. Copy and paste the contents of `scripts/001-neuro-swarm-schema.sql`
4. Click "Run"

### 3. Deploy Discord Bot (Railway)

<!-- Updated path from /bot to /apps/bot -->
The `/apps/bot` folder needs to run on a long-lived server:

#### Step 1: Create Discord Application

1. Go to [discord.com/developers/applications](https://discord.com/developers/applications)
2. Click **"New Application"** → Name it "WIRED CHAOS"
3. Go to **Bot** tab → Click **"Add Bot"**
4. Copy the **TOKEN** (keep this secret!)
5. Enable these **Privileged Gateway Intents**:
   - MESSAGE CONTENT INTENT
   - SERVER MEMBERS INTENT
   - PRESENCE INTENT
6. Go to **OAuth2 → URL Generator**:
   - Scopes: `bot`, `applications.commands`
   - Permissions: `Send Messages`, `Use Slash Commands`, `Embed Links`, `Manage Roles`
   - Copy the URL and open it to invite the bot to your server

#### Step 2: Deploy to Railway

1. Download this project (click the three dots → "Download ZIP")
2. Push the code to a GitHub repository
3. Go to [railway.app](https://railway.app) and sign in with GitHub
4. Click **"New Project"** → **"Deploy from GitHub repo"**
5. Select your repository
<!-- Updated root directory path -->
6. In Settings, set **Root Directory** to `/apps/bot`
7. Add these **Environment Variables**:
   ```
   DISCORD_BOT_TOKEN=your_bot_token
   DISCORD_APP_ID=your_application_id
   DISCORD_GUILD_ID=your_server_id
   APP_BASE_URL=https://your-vercel-app.vercel.app
   ```
8. Railway will auto-build and deploy

### 4. Verify Deployment

1. The bot should come online in your Discord server
2. Slash commands auto-register on startup
3. Run `/begin` to test the onboarding flow
4. Check the control plane dashboard at your Vercel URL

---

## Environment Variables Reference

### Next.js App (Vercel)
| Variable | Description |
|----------|-------------|
| `DATABASE_URL` | Neon connection string (auto-set) |

### Discord Bot (Railway)
| Variable | Description |
|----------|-------------|
| `DISCORD_BOT_TOKEN` | Bot token from Discord Developer Portal |
| `DISCORD_APP_ID` | Application ID from Discord Developer Portal |
| `DISCORD_GUILD_ID` | Your Discord server ID (right-click server → Copy ID) |
| `APP_BASE_URL` | Your Vercel deployment URL |

---

## Troubleshooting

### Commands not appearing
- Wait 1 hour (Discord caches commands globally)
- Or kick and re-invite the bot

### Database errors
- Ensure the migration script has been run
- Check Neon dashboard for connection issues

### Bot offline
- Check Railway logs for errors
- Verify environment variables are set correctly
