-- NEURO SWARM Database Schema
-- Tables for Discord bot: WL tracking, NPC games, user profiles, agent activity

-- ============================================
-- DISCORD USERS (extends existing users table)
-- ============================================
CREATE TABLE IF NOT EXISTS discord_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  discord_id TEXT UNIQUE NOT NULL,
  discord_username TEXT,
  discord_discriminator TEXT,
  avatar_url TEXT,
  
  -- Onboarding fields
  generation TEXT CHECK (generation IN ('GEN1', 'GEN2', 'GEN3')),
  neuro_mode TEXT CHECK (neuro_mode IN ('STANDARD', 'CHAOS', 'ASCEND')),
  wallet_address TEXT,
  
  -- 789 CREW status
  is_789_crew BOOLEAN DEFAULT FALSE,
  crew_role TEXT,
  
  -- Timestamps
  onboarding_started_at TIMESTAMPTZ,
  onboarding_completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- WHITELIST LEDGER
-- ============================================
CREATE TABLE IF NOT EXISTS wl_ledger (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  discord_id TEXT NOT NULL REFERENCES discord_users(discord_id) ON DELETE CASCADE,
  
  -- Project tracking
  project TEXT NOT NULL CHECK (project IN ('VRG33589', 'VAULT33')),
  points INTEGER NOT NULL DEFAULT 0,
  source TEXT NOT NULL, -- 'NPC_WIN', 'ROLE_SYNC', 'MANUAL', 'EVENT', 'REFERRAL'
  
  -- Metadata
  reason TEXT,
  awarded_by TEXT, -- Agent or admin who awarded
  game_id UUID, -- Reference to NPC game if applicable
  
  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_wl_ledger_discord ON wl_ledger(discord_id);
CREATE INDEX IF NOT EXISTS idx_wl_ledger_project ON wl_ledger(project);

-- ============================================
-- NPC GAMES (Labyrinth, Forge, Triage, etc.)
-- ============================================
CREATE TABLE IF NOT EXISTS npc_games (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  discord_id TEXT NOT NULL REFERENCES discord_users(discord_id) ON DELETE CASCADE,
  
  -- Game info
  game_type TEXT NOT NULL CHECK (game_type IN ('LABYRINTH', 'ALCHEMIST', 'FORGE', 'TRIAGE', 'MULTIVERSE', 'SEQUENCE')),
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'WON', 'LOST', 'ABANDONED')),
  
  -- Game state (JSON for flexibility)
  state JSONB NOT NULL DEFAULT '{}',
  moves_made INTEGER DEFAULT 0,
  max_moves INTEGER,
  
  -- Rewards
  wl_reward INTEGER DEFAULT 0,
  reward_project TEXT CHECK (reward_project IN ('VRG33589', 'VAULT33')),
  
  -- Agent handling
  primary_agent TEXT, -- GRYMM, KIBA, etc.
  
  -- Timestamps
  started_at TIMESTAMPTZ DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_npc_games_discord ON npc_games(discord_id);
CREATE INDEX IF NOT EXISTS idx_npc_games_status ON npc_games(status);

-- ============================================
-- AGENT ACTIVITY LOG
-- ============================================
CREATE TABLE IF NOT EXISTS agent_activity (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Agent info
  agent_id TEXT NOT NULL, -- META_X, KIBA, SHADOWLUX, etc.
  action_type TEXT NOT NULL, -- 'RESPONSE', 'ROUTE', 'WL_AWARD', 'GAME_EVENT'
  
  -- Context
  discord_id TEXT,
  channel_id TEXT,
  guild_id TEXT,
  
  -- Details
  template_key TEXT,
  input_data JSONB,
  output_data JSONB,
  
  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_agent_activity_agent ON agent_activity(agent_id);
CREATE INDEX IF NOT EXISTS idx_agent_activity_type ON agent_activity(action_type);
CREATE INDEX IF NOT EXISTS idx_agent_activity_created ON agent_activity(created_at DESC);

-- ============================================
-- SWARM STATE (User progress & memory)
-- ============================================
CREATE TABLE IF NOT EXISTS swarm_state (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  discord_id TEXT UNIQUE NOT NULL REFERENCES discord_users(discord_id) ON DELETE CASCADE,
  
  -- Progress tracking
  skill_tree JSONB DEFAULT '{}',
  completed_paths JSONB DEFAULT '[]',
  current_quest TEXT,
  
  -- Memory (agent interactions)
  interaction_count INTEGER DEFAULT 0,
  last_agent TEXT,
  memory_snapshot JSONB DEFAULT '{}',
  
  -- Reputation
  chaos_score INTEGER DEFAULT 0,
  ascension_level INTEGER DEFAULT 0,
  
  -- Timestamps
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- WL SCORES VIEW (Aggregated)
-- ============================================
CREATE OR REPLACE VIEW wl_scores AS
SELECT 
  du.discord_id,
  du.discord_username,
  du.generation,
  du.neuro_mode,
  du.is_789_crew,
  COALESCE(SUM(CASE WHEN wl.project = 'VRG33589' THEN wl.points ELSE 0 END), 0) AS vrg33589_score,
  COALESCE(SUM(CASE WHEN wl.project = 'VAULT33' THEN wl.points ELSE 0 END), 0) AS vault33_score,
  COALESCE(SUM(wl.points), 0) AS total_score,
  COUNT(DISTINCT ng.id) FILTER (WHERE ng.status = 'WON') AS games_won,
  du.created_at
FROM discord_users du
LEFT JOIN wl_ledger wl ON du.discord_id = wl.discord_id
LEFT JOIN npc_games ng ON du.discord_id = ng.discord_id
GROUP BY du.discord_id, du.discord_username, du.generation, du.neuro_mode, du.is_789_crew, du.created_at;

-- ============================================
-- HELPER FUNCTIONS
-- ============================================

-- Auto-update timestamps
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply triggers
DROP TRIGGER IF EXISTS update_discord_users_timestamp ON discord_users;
CREATE TRIGGER update_discord_users_timestamp
  BEFORE UPDATE ON discord_users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS update_npc_games_timestamp ON npc_games;
CREATE TRIGGER update_npc_games_timestamp
  BEFORE UPDATE ON npc_games
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS update_swarm_state_timestamp ON swarm_state;
CREATE TRIGGER update_swarm_state_timestamp
  BEFORE UPDATE ON swarm_state
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
