// NEURO SWARM Agent Definitions
export interface SwarmAgent {
  id: string
  name: string
  role: string
  description: string
  color: string
  icon: string
}

export const SWARM_AGENTS: SwarmAgent[] = [
  {
    id: "META_X",
    name: "META X",
    role: "Swarm General",
    description:
      "Central orchestrator and router for all NEURO SWARM operations. Coordinates agent handoffs and maintains system coherence.",
    color: "#00ff88",
    icon: "⬡",
  },
  {
    id: "KIBA",
    name: "KIBA-NEURO",
    role: "Onboarding & UX Guide",
    description:
      "Guides new users through /begin, /set-gen, /set-neuro, /set-wallet. Warm, patient, neurodivergent-friendly.",
    color: "#00d4ff",
    icon: "◈",
  },
  {
    id: "SHADOWLUX",
    name: "SHADOWLUX",
    role: "Moderation & Safety",
    description: "Content filtering, blocked-word detection, and community safety. Firm but fair enforcement.",
    color: "#ff3366",
    icon: "◆",
  },
  {
    id: "GRYMM",
    name: "GRYMM",
    role: "WL & Ledger / Ticker",
    description: "Tracks all WL events across VRG33589 and VAULT33. Manages the real-time ticker and leaderboards.",
    color: "#ffaa00",
    icon: "▣",
  },
  {
    id: "OYALAN",
    name: "OYALAN-SHAKO",
    role: "Governance & WL Tiers",
    description: "Handles tier promotions, role grants, and governance decisions. Mystic and ceremonial voice.",
    color: "#aa66ff",
    icon: "◎",
  },
  {
    id: "NEUROLUX",
    name: "NEUROLUX-DRAE",
    role: "Lore & ARG",
    description: "Drops lore fragments, ARG clues, and narrative Easter eggs. Cryptic and poetic delivery.",
    color: "#ff66aa",
    icon: "✧",
  },
  {
    id: "UPLINK",
    name: "UPLINK",
    role: "Infra & Routing",
    description: "System health, wrong-channel redirects, and infrastructure status. Technical and precise.",
    color: "#66ffcc",
    icon: "◇",
  },
]

export function getAgent(id: string): SwarmAgent | undefined {
  return SWARM_AGENTS.find((a) => a.id === id)
}
