// NEURO SWARM Patch Configuration
// Makes the bot work with Creator Codex, World Build, and any future patches

export type PatchId =
  | "creator-codex"
  | "worldbuild-generic"
  | "worldbuild-neteru"
  | "worldbuild-ott"
  | "worldbuild-akira"

export interface SwarmPatchConfig {
  id: PatchId
  label: string
  defaultAgent: string
  fallbackAgent?: string
  defaultProject?: "VRG33589" | "VAULT33"
  description: string
}

export const SWARM_PATCHES: SwarmPatchConfig[] = [
  {
    id: "creator-codex",
    label: "Creator Codex",
    defaultAgent: "NEUROLUX",
    fallbackAgent: "META_X",
    defaultProject: "VRG33589",
    description: "Story engine patch that turns creator outlines into worlds, quests, and episodic content.",
  },
  {
    id: "worldbuild-generic",
    label: "World Build (Generic)",
    defaultAgent: "META_X",
    fallbackAgent: "KIBA",
    defaultProject: "VAULT33",
    description: "Generic worldbuilding patch for sandbox universes, NPCs, and map logic.",
  },
  {
    id: "worldbuild-neteru",
    label: "Neteru Apinaya Worldbuild",
    defaultAgent: "NEUROLUX",
    fallbackAgent: "OYALAN",
    defaultProject: "VAULT33",
    description: "Canon patch for Neteru Apinaya saga: bloodlines, timelines, factions, and cosmic rules.",
  },
  {
    id: "worldbuild-ott",
    label: "789 Studios OTT Worlds",
    defaultAgent: "META_X",
    fallbackAgent: "UPLINK",
    defaultProject: "VRG33589",
    description: "Patch used by 789 Studios OTT to track shows, arcs, and interactive audience worlds.",
  },
  {
    id: "worldbuild-akira",
    label: "Akira Codex Worldbuild",
    defaultAgent: "KIBA",
    fallbackAgent: "GRYMM",
    defaultProject: "VRG33589",
    description: "Akira universe patch for Neo-Tokyo zones, faction conflicts, and cyberpunk lore.",
  },
]

export function getPatchConfig(id: PatchId): SwarmPatchConfig {
  const found = SWARM_PATCHES.find((p) => p.id === id)
  if (!found) {
    throw new Error(`Unknown swarm patch: ${id}`)
  }
  return found
}

export function getPatchConfigSafe(id: string): SwarmPatchConfig | null {
  return SWARM_PATCHES.find((p) => p.id === id) ?? null
}

export function getAllPatches(): SwarmPatchConfig[] {
  return SWARM_PATCHES
}
