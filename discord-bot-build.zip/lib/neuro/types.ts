// NEURO SWARM Types

export type AgentId = "META_X" | "KIBA" | "SHADOWLUX" | "GRYMM" | "OYALAN" | "NEUROLUX" | "UPLINK"

export type Generation = "Boomer" | "GenX" | "Millennial" | "GenZ" | "GenAlpha"

export type Platform = "discord" | "telegram" | "web"

export type Project = "VRG33589" | "VAULT33"

export type WLSource =
  | "ONBOARDING"
  | "NPC_LABYRINTH"
  | "NPC_ALCHEMIST"
  | "NPC_FORGE"
  | "NPC_TRIAGE"
  | "NPC_MULTIVERSE"
  | "NPC_SEQUENCE"
  | "MANUAL_ADMIN"
  | "789_CREW_AUTO"

export interface WLEntry {
  id: string
  userId: string
  platform: Platform
  project: Project
  source: WLSource
  delta: number
  timestamp: string
  meta?: Record<string, unknown>
}

export interface UserProfile {
  id: string
  discordId?: string
  telegramId?: string
  walletAddress?: string
  generation?: Generation
  neuroMode: boolean
  is789Crew: boolean
  createdAt: string
  updatedAt: string
}

export interface NPCSession {
  id: string
  userId: string
  game: "labyrinth" | "alchemist" | "forge" | "triage" | "multiverse" | "sequence"
  state: Record<string, unknown>
  moveCount: number
  lastMoveAt: string
  createdAt: string
}

export interface WLScore {
  userId: string
  vrg33589: number
  vault33: number
  totalMoves: number
  lastActivity: string
}

// VoicePack types
export interface AgentConfig {
  id: AgentId
  name: string
  role: string
  style: {
    tone: string
    keywords: string[]
  }
  templates: Record<string, string>
}

export interface VoicePack {
  version: string
  name: string
  global: {
    tone: {
      description: string
      rules: string[]
    }
  }
  agents: Record<AgentId, AgentConfig>
  contextualDefaults: {
    channels: Record<
      string,
      {
        defaultAgent: AgentId
        secondaryAgents: AgentId[]
      }
    >
    eventRouting: Record<string, AgentId>
  }
}
