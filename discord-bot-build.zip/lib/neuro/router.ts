// NEURO SWARM Agent Router
import voicepack from "./voicepack.json"
import type { AgentId, VoicePack } from "./types"

const pack = voicepack as VoicePack

type TemplateVars = Record<string, string | number>

/**
 * Get a formatted reply from an agent using a template
 */
export function getReply(agent: AgentId, templateKey: string, vars: TemplateVars = {}): string {
  const agentCfg = pack.agents[agent]
  if (!agentCfg) {
    throw new Error(`Unknown agent: ${agent}`)
  }

  const template = agentCfg.templates[templateKey]
  if (!template) {
    throw new Error(`Missing template '${templateKey}' for agent ${agent}`)
  }

  return Object.entries(vars).reduce((acc, [key, value]) => {
    const token = `{${key}}`
    return acc.split(token).join(String(value))
  }, template)
}

/**
 * Get the default agent for a channel
 */
export function getDefaultAgentForChannel(channelKey: string): AgentId | null {
  const map = pack.contextualDefaults.channels
  return map[channelKey]?.defaultAgent ?? null
}

/**
 * Get the agent for a specific event type
 */
export function getAgentForEvent(eventType: string): AgentId | null {
  return pack.contextualDefaults.eventRouting[eventType] ?? null
}

/**
 * Get agent configuration
 */
export function getAgentConfig(agent: AgentId) {
  return pack.agents[agent]
}

/**
 * Get all available template keys for an agent
 */
export function getAgentTemplateKeys(agent: AgentId): string[] {
  const agentCfg = pack.agents[agent]
  if (!agentCfg) return []
  return Object.keys(agentCfg.templates)
}
