// NEURO SWARM State Engine
// META X coordination logic - user progress, skill trees, agent memory
import { getSwarmState, updateSwarmState, logAgentActivity, getWLScore } from "./db-store"
import { getReply, getAgentForEvent } from "./router"
import type { AgentId } from "./types"

// ============================================
// SKILL TREE DEFINITIONS
// ============================================

export interface SkillNode {
  id: string
  name: string
  description: string
  requirements: {
    chaos_score?: number
    wl_vrg?: number
    wl_vault?: number
    games_won?: number
    paths_completed?: string[]
  }
  rewards: {
    chaos_bonus?: number
    wl_multiplier?: number
    unlock_quest?: string
    unlock_agent?: AgentId
  }
}

export const SKILL_TREE: Record<string, SkillNode> = {
  // Tier 1 - Entry
  SIGNAL_AWAKENING: {
    id: "SIGNAL_AWAKENING",
    name: "Signal Awakening",
    description: "Complete onboarding to awaken your signal",
    requirements: {},
    rewards: { chaos_bonus: 10, unlock_quest: "FIRST_LABYRINTH" },
  },
  FIRST_MOVE: {
    id: "FIRST_MOVE",
    name: "First Move",
    description: "Make your first NPC game move",
    requirements: {},
    rewards: { chaos_bonus: 5 },
  },

  // Tier 2 - Foundation
  LABYRINTH_WALKER: {
    id: "LABYRINTH_WALKER",
    name: "Labyrinth Walker",
    description: "Complete 5 Labyrinth moves",
    requirements: { games_won: 0, chaos_score: 10 },
    rewards: { chaos_bonus: 25, wl_multiplier: 1.1 },
  },
  VRG_INITIATE: {
    id: "VRG_INITIATE",
    name: "VRG Initiate",
    description: "Reach 100 VRG33589 WL",
    requirements: { wl_vrg: 100 },
    rewards: { chaos_bonus: 20, unlock_agent: "OYALAN" },
  },
  VAULT_INITIATE: {
    id: "VAULT_INITIATE",
    name: "VAULT Initiate",
    description: "Reach 100 VAULT33 WL",
    requirements: { wl_vault: 100 },
    rewards: { chaos_bonus: 20 },
  },

  // Tier 3 - Intermediate
  CHAOS_WALKER: {
    id: "CHAOS_WALKER",
    name: "Chaos Walker",
    description: "Reach 100 chaos score",
    requirements: { chaos_score: 100 },
    rewards: { chaos_bonus: 50, unlock_quest: "SHADOW_PATH" },
  },
  GAME_MASTER: {
    id: "GAME_MASTER",
    name: "Game Master",
    description: "Win 3 NPC games",
    requirements: { games_won: 3 },
    rewards: { chaos_bonus: 75, wl_multiplier: 1.25 },
  },
  DUAL_PATH: {
    id: "DUAL_PATH",
    name: "Dual Path",
    description: "Reach 250 WL in both projects",
    requirements: { wl_vrg: 250, wl_vault: 250 },
    rewards: { chaos_bonus: 100, unlock_agent: "NEUROLUX" },
  },

  // Tier 4 - Advanced
  ASCENSION_READY: {
    id: "ASCENSION_READY",
    name: "Ascension Ready",
    description: "Reach 500 chaos score and complete all Tier 3 paths",
    requirements: {
      chaos_score: 500,
      paths_completed: ["CHAOS_WALKER", "GAME_MASTER", "DUAL_PATH"],
    },
    rewards: { chaos_bonus: 200, unlock_quest: "FINAL_ASCENSION" },
  },
}

// ============================================
// QUEST DEFINITIONS
// ============================================

export interface Quest {
  id: string
  name: string
  description: string
  objectives: {
    type: "wl" | "game" | "chaos" | "interact"
    target: number
    project?: "VRG33589" | "VAULT33"
    game_type?: string
  }[]
  rewards: {
    wl_vrg?: number
    wl_vault?: number
    chaos?: number
    unlock_path?: string
  }
}

export const QUESTS: Record<string, Quest> = {
  FIRST_LABYRINTH: {
    id: "FIRST_LABYRINTH",
    name: "Enter the Labyrinth",
    description: "Complete your first Labyrinth session",
    objectives: [{ type: "game", target: 1, game_type: "LABYRINTH" }],
    rewards: { wl_vault: 50, chaos: 25 },
  },
  SHADOW_PATH: {
    id: "SHADOW_PATH",
    name: "Walk the Shadow Path",
    description: "Explore the darker frequencies",
    objectives: [
      { type: "wl", target: 100, project: "VAULT33" },
      { type: "chaos", target: 50 },
    ],
    rewards: { wl_vrg: 100, wl_vault: 100, chaos: 50 },
  },
  FINAL_ASCENSION: {
    id: "FINAL_ASCENSION",
    name: "Final Ascension",
    description: "Complete the ultimate challenge",
    objectives: [
      { type: "wl", target: 500, project: "VRG33589" },
      { type: "wl", target: 500, project: "VAULT33" },
      { type: "game", target: 10 },
    ],
    rewards: { wl_vrg: 500, wl_vault: 500, chaos: 500 },
  },
}

// ============================================
// SWARM ENGINE CORE
// ============================================

export interface SwarmContext {
  discordId: string
  chaos_score: number
  ascension_level: number
  skill_tree: Record<string, boolean>
  completed_paths: string[]
  current_quest: string | null
  last_agent: AgentId | null
  wl_vrg: number
  wl_vault: number
  games_won: number
}

/**
 * Load full swarm context for a user
 */
export async function loadSwarmContext(discordId: string): Promise<SwarmContext> {
  const [state, scores] = await Promise.all([getSwarmState(discordId), getWLScore(discordId)])

  const swarmState = state as {
    skill_tree?: Record<string, boolean>
    completed_paths?: string[]
    current_quest?: string
    last_agent?: AgentId
    chaos_score?: number
    ascension_level?: number
  } | null

  return {
    discordId,
    chaos_score: swarmState?.chaos_score ?? 0,
    ascension_level: swarmState?.ascension_level ?? 0,
    skill_tree: swarmState?.skill_tree ?? {},
    completed_paths: swarmState?.completed_paths ?? [],
    current_quest: swarmState?.current_quest ?? null,
    last_agent: swarmState?.last_agent ?? null,
    wl_vrg: scores?.vrg33589_score ?? 0,
    wl_vault: scores?.vault33_score ?? 0,
    games_won: scores?.games_won ?? 0,
  }
}

/**
 * Check if a skill node can be unlocked
 */
export function canUnlockSkill(ctx: SwarmContext, nodeId: string): boolean {
  const node = SKILL_TREE[nodeId]
  if (!node) return false
  if (ctx.skill_tree[nodeId]) return false // Already unlocked

  const req = node.requirements
  if (req.chaos_score && ctx.chaos_score < req.chaos_score) return false
  if (req.wl_vrg && ctx.wl_vrg < req.wl_vrg) return false
  if (req.wl_vault && ctx.wl_vault < req.wl_vault) return false
  if (req.games_won && ctx.games_won < req.games_won) return false
  if (req.paths_completed) {
    for (const path of req.paths_completed) {
      if (!ctx.completed_paths.includes(path)) return false
    }
  }

  return true
}

/**
 * Unlock a skill and apply rewards
 */
export async function unlockSkill(
  discordId: string,
  nodeId: string,
): Promise<{ success: boolean; message: string; rewards?: SkillNode["rewards"] }> {
  const ctx = await loadSwarmContext(discordId)

  if (!canUnlockSkill(ctx, nodeId)) {
    return { success: false, message: "Requirements not met for this skill" }
  }

  const node = SKILL_TREE[nodeId]
  const newSkillTree = { ...ctx.skill_tree, [nodeId]: true }
  const newChaos = ctx.chaos_score + (node.rewards.chaos_bonus ?? 0)
  const newPaths = [...ctx.completed_paths, nodeId]

  await updateSwarmState(discordId, {
    skill_tree: newSkillTree,
    completed_paths: newPaths,
    chaos_score: newChaos,
    current_quest: node.rewards.unlock_quest ?? ctx.current_quest,
  })

  await logAgentActivity("META_X", "SKILL_UNLOCK", discordId, undefined, undefined, "skillUnlock", {
    nodeId,
    rewards: node.rewards,
  })

  return {
    success: true,
    message: `Skill unlocked: ${node.name}`,
    rewards: node.rewards,
  }
}

/**
 * Check and auto-unlock any available skills
 */
export async function checkAndUnlockSkills(discordId: string): Promise<string[]> {
  const ctx = await loadSwarmContext(discordId)
  const unlocked: string[] = []

  for (const nodeId of Object.keys(SKILL_TREE)) {
    if (canUnlockSkill(ctx, nodeId)) {
      const result = await unlockSkill(discordId, nodeId)
      if (result.success) {
        unlocked.push(nodeId)
        // Reload context after each unlock to check cascading unlocks
        Object.assign(ctx, await loadSwarmContext(discordId))
      }
    }
  }

  return unlocked
}

/**
 * Process an event through the swarm and return agent responses
 */
export async function processSwarmEvent(
  discordId: string,
  eventType: string,
  eventData: Record<string, unknown>,
): Promise<{
  agent: AgentId
  message: string
  skillsUnlocked: string[]
  chaosGained: number
}> {
  // Route to appropriate agent
  const agent = getAgentForEvent(eventType) || "META_X"

  // Update last agent interaction
  await updateSwarmState(discordId, { last_agent: agent })

  // Log agent activity
  await logAgentActivity(agent, eventType.toUpperCase(), discordId, undefined, undefined, eventType, eventData)

  // Check for skill unlocks
  const skillsUnlocked = await checkAndUnlockSkills(discordId)

  // Calculate chaos gained from this event
  let chaosGained = 0
  if (eventType === "npcMove") chaosGained = 2
  if (eventType === "wlEvent") chaosGained = 1
  if (eventType === "onboarding") chaosGained = 10

  if (chaosGained > 0) {
    const ctx = await loadSwarmContext(discordId)
    await updateSwarmState(discordId, {
      chaos_score: ctx.chaos_score + chaosGained,
    })
  }

  // Generate agent message
  let message = ""
  try {
    message = getReply(agent, eventType, eventData as Record<string, string | number>)
  } catch {
    message = `[${agent}] Event processed: ${eventType}`
  }

  return {
    agent,
    message,
    skillsUnlocked,
    chaosGained,
  }
}

/**
 * Get user's current progress summary
 */
export async function getProgressSummary(discordId: string): Promise<{
  level: number
  chaos: number
  wl: { vrg: number; vault: number; total: number }
  skills: { unlocked: number; total: number; available: string[] }
  quest: Quest | null
  nextMilestone: string | null
}> {
  const ctx = await loadSwarmContext(discordId)

  const unlockedCount = Object.values(ctx.skill_tree).filter(Boolean).length
  const totalSkills = Object.keys(SKILL_TREE).length

  // Find available skills
  const available = Object.keys(SKILL_TREE).filter((id) => canUnlockSkill(ctx, id))

  // Current quest
  const quest = ctx.current_quest ? QUESTS[ctx.current_quest] : null

  // Next milestone - first unmet requirement
  let nextMilestone: string | null = null
  for (const [nodeId, node] of Object.entries(SKILL_TREE)) {
    if (!ctx.skill_tree[nodeId] && !canUnlockSkill(ctx, nodeId)) {
      const req = node.requirements
      if (req.chaos_score && ctx.chaos_score < req.chaos_score) {
        nextMilestone = `Reach ${req.chaos_score} chaos (current: ${ctx.chaos_score})`
        break
      }
      if (req.wl_vrg && ctx.wl_vrg < req.wl_vrg) {
        nextMilestone = `Reach ${req.wl_vrg} VRG33589 WL (current: ${ctx.wl_vrg})`
        break
      }
      if (req.wl_vault && ctx.wl_vault < req.wl_vault) {
        nextMilestone = `Reach ${req.wl_vault} VAULT33 WL (current: ${ctx.wl_vault})`
        break
      }
    }
  }

  return {
    level: ctx.ascension_level,
    chaos: ctx.chaos_score,
    wl: {
      vrg: ctx.wl_vrg,
      vault: ctx.wl_vault,
      total: ctx.wl_vrg + ctx.wl_vault,
    },
    skills: {
      unlocked: unlockedCount,
      total: totalSkills,
      available,
    },
    quest,
    nextMilestone,
  }
}
