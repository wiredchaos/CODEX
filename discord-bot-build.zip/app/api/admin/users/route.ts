// Admin endpoint to list all users - upgraded to use Neon DB
import { type NextRequest, NextResponse } from "next/server"
import { getAllUsers, getWLScore, getDashboardStats } from "@/lib/neuro/db-store"

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const includeStats = searchParams.get("stats") === "true"
    const limit = Number.parseInt(searchParams.get("limit") || "100", 10)

    const users = await getAllUsers(Math.min(limit, 500))

    // Enrich with WL scores
    const enrichedUsers = await Promise.all(
      users.map(async (user) => {
        const scores = await getWLScore(user.discord_id)
        return {
          discordId: user.discord_id,
          username: user.discord_username,
          generation: user.generation,
          neuroMode: user.neuro_mode,
          wallet: user.wallet_address ? `${user.wallet_address.slice(0, 6)}...${user.wallet_address.slice(-4)}` : null,
          is789Crew: user.is_789_crew,
          onboardingComplete: !!user.onboarding_completed_at,
          createdAt: user.created_at,
          wlScores: scores
            ? {
                vrg33589: scores.vrg33589_score,
                vault33: scores.vault33_score,
                total: scores.total_score,
                gamesWon: scores.games_won,
              }
            : null,
        }
      }),
    )

    const response: Record<string, unknown> = {
      ok: true,
      count: users.length,
      users: enrichedUsers,
    }

    if (includeStats) {
      response.stats = await getDashboardStats()
    }

    return NextResponse.json(response)
  } catch (error) {
    console.error("[ADMIN_USERS] Error:", error)
    return NextResponse.json({ error: "Internal error" }, { status: 500 })
  }
}
