// Admin endpoint for agent activity - new endpoint
import { type NextRequest, NextResponse } from "next/server"
import { getRecentActivity, getDashboardStats } from "@/lib/neuro/db-store"

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const limit = Number.parseInt(searchParams.get("limit") || "50", 10)

    const [activity, stats] = await Promise.all([getRecentActivity(Math.min(limit, 200)), getDashboardStats()])

    return NextResponse.json({
      ok: true,
      stats,
      activity,
    })
  } catch (error) {
    console.error("[ADMIN_ACTIVITY] Error:", error)
    return NextResponse.json({ error: "Internal error" }, { status: 500 })
  }
}
