// Admin endpoint to view WL ledger
import { type NextRequest, NextResponse } from "next/server"
import { getAllWLEntries, getAllUsers } from "@/lib/neuro/store"

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const limit = Number.parseInt(searchParams.get("limit") || "100", 10)
    const project = searchParams.get("project")
    const source = searchParams.get("source")

    let entries = getAllWLEntries()
    const users = getAllUsers()

    // Filter by project
    if (project) {
      entries = entries.filter((e) => e.project === project)
    }

    // Filter by source
    if (source) {
      entries = entries.filter((e) => e.source === source)
    }

    // Sort by timestamp descending and limit
    entries = entries.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).slice(0, limit)

    // Enrich with user info
    const enriched = entries.map((entry) => {
      const user = users.find((u) => u.id === entry.userId)
      return {
        ...entry,
        discordId: user?.discordId,
      }
    })

    return NextResponse.json({
      ok: true,
      count: enriched.length,
      entries: enriched,
    })
  } catch (error) {
    console.error("[ADMIN_WL] Error:", error)
    return NextResponse.json({ error: "Internal error" }, { status: 500 })
  }
}
