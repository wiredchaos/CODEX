// Unlock a skill manually
import { type NextRequest, NextResponse } from "next/server"
import { unlockSkill, SKILL_TREE } from "@/lib/neuro/swarm-engine"

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { discordId, skillId } = body as {
      discordId: string
      skillId: string
    }

    if (!discordId || !skillId) {
      return NextResponse.json({ error: "discordId and skillId required" }, { status: 400 })
    }

    if (!SKILL_TREE[skillId]) {
      return NextResponse.json(
        {
          error: "Invalid skill",
          valid: Object.keys(SKILL_TREE),
        },
        { status: 400 },
      )
    }

    const result = await unlockSkill(discordId, skillId)

    return NextResponse.json({
      ok: result.success,
      ...result,
    })
  } catch (error) {
    console.error("[SWARM_SKILL] Error:", error)
    return NextResponse.json({ error: "Internal error" }, { status: 500 })
  }
}
