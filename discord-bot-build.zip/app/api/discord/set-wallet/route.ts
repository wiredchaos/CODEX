// /set-wallet command handler - upgraded to use Neon DB
import { type NextRequest, NextResponse } from "next/server"
import { getOrCreateUser, updateUserWallet, logAgentActivity, logWLPoints } from "@/lib/neuro/db-store"

// Basic wallet address validation
function isValidWalletAddress(address: string): boolean {
  // Ethereum-style address (0x...)
  if (/^0x[a-fA-F0-9]{40}$/.test(address)) return true
  // Solana-style address (base58, 32-44 chars)
  if (/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(address)) return true
  return false
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { discordId, walletAddress } = body as {
      discordId: string
      walletAddress: string
    }

    if (!discordId) {
      return NextResponse.json({ error: "discordId required" }, { status: 400 })
    }

    if (!walletAddress) {
      return NextResponse.json({ error: "walletAddress required" }, { status: 400 })
    }

    if (!isValidWalletAddress(walletAddress)) {
      return NextResponse.json(
        {
          error: "Invalid wallet address format. Provide an Ethereum (0x...) or Solana address.",
        },
        { status: 400 },
      )
    }

    // Ensure user exists
    await getOrCreateUser(discordId)

    // Update wallet (also marks onboarding as complete)
    const updated = await updateUserWallet(discordId, walletAddress)

    // Award bonus WL for completing onboarding
    await Promise.all([
      logWLPoints(discordId, "VRG33589", 25, "ONBOARDING_COMPLETE", "Wallet bound - onboarding complete", "GRYMM"),
      logWLPoints(discordId, "VAULT33", 25, "ONBOARDING_COMPLETE", "Wallet bound - onboarding complete", "GRYMM"),
    ])

    // Log activity
    await logAgentActivity("GRYMM", "SET_WALLET", discordId, undefined, undefined, "setWallet", {
      wallet: `${walletAddress.slice(0, 6)}...${walletAddress.slice(-4)}`,
    })

    return NextResponse.json({
      ok: true,
      message: `Wallet bound: \`${walletAddress.slice(0, 6)}...${walletAddress.slice(-4)}\`\nOnboarding complete! +25 WL awarded to both VRG33589 and VAULT33.`,
      user: {
        discordId: updated.discord_id,
        wallet: updated.wallet_address,
        onboardingComplete: !!updated.onboarding_completed_at,
      },
      wlAwarded: { vrg33589: 25, vault33: 25 },
    })
  } catch (error) {
    console.error("[SET-WALLET] Error:", error)
    return NextResponse.json({ error: "Internal error" }, { status: 500 })
  }
}
