// /set-gen command handler - upgraded to use Neon DB
import { type NextRequest, NextResponse } from "next/server"
import { getOrCreateUser, updateUserGeneration, logAgentActivity } from "@/lib/neuro/db-store"

const VALID_GENERATIONS = ["GEN1", "GEN2", "GEN3"] as const

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { discordId, generation } = body as {
      discordId: string
      generation: string
    }

    if (!discordId) {
      return NextResponse.json({ error: "discordId required" }, { status: 400 })
    }

    if (!generation || !VALID_GENERATIONS.includes(generation as (typeof VALID_GENERATIONS)[number])) {
      return NextResponse.json(
        {
          error: "Invalid generation",
          valid: VALID_GENERATIONS,
        },
        { status: 400 },
      )
    }

    // Ensure user exists
    await getOrCreateUser(discordId)

    // Update generation
    const updated = await updateUserGeneration(discordId, generation)

    // Log activity
    await logAgentActivity("KIBA", "SET_GENERATION", discordId, undefined, undefined, "setGen", { generation })

    return NextResponse.json({
      ok: true,
      message: `Generation set to **${generation}**. Your signal profile has been updated.`,
      user: {
        discordId: updated.discord_id,
        generation: updated.generation,
      },
    })
  } catch (error) {
    console.error("[SET-GEN] Error:", error)
    return NextResponse.json({ error: "Internal error" }, { status: 500 })
  }
}
