// /begin command handler
import { type NextRequest, NextResponse } from "next/server"
import { getReply } from "@/lib/neuro/router"
import { getOrCreateUser, logWLPoints, logAgentActivity } from "@/lib/neuro/db-store"

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { discordId, username } = body as {
      discordId: string
      username?: string
    }

    if (!discordId) {
      return NextResponse.json({ error: "discordId required" }, { status: 400 })
    }

    const user = await getOrCreateUser(discordId, username)

    // Log onboarding WL for both projects (10 points each)
    await Promise.all([
      logWLPoints(discordId, "VRG33589", 10, "ONBOARDING", "Initial onboarding bonus", "KIBA"),
      logWLPoints(discordId, "VAULT33", 10, "ONBOARDING", "Initial onboarding bonus", "KIBA"),
    ])

    // Log agent activity
    await logAgentActivity("KIBA", "ONBOARDING", discordId, undefined, undefined, "combinedBegin", { username })

    // Get the combined begin message from KIBA
    const message = getReply("KIBA", "combinedBegin", {})

    return NextResponse.json({
      ok: true,
      discordId: user.discord_id,
      message,
      wlAwarded: { vrg33589: 10, vault33: 10 },
    })
  } catch (error) {
    console.error("[BEGIN] Error:", error)
    return NextResponse.json({ error: "Internal error" }, { status: 500 })
  }
}
