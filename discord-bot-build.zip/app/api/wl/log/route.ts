// WL Ledger logging endpoint - upgraded to use Neon DB
import { type NextRequest, NextResponse } from "next/server"
import { logWLPoints, getWLScore, logAgentActivity } from "@/lib/neuro/db-store"
import { getReply } from "@/lib/neuro/router"

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { discordId, project, source, points, reason, awardedBy } = body as {
      discordId: string
      project: "VRG33589" | "VAULT33"
      source: string
      points: number
      reason?: string
      awardedBy?: string
    }

    if (!discordId || !project || !source || points === undefined) {
      return NextResponse.json(
        {
          error: "Missing required fields: discordId, project, source, points",
        },
        { status: 400 },
      )
    }

    // Log WL points
    const entry = await logWLPoints(discordId, project, points, source, reason, awardedBy || "GRYMM")

    // Get updated scores
    const scores = await getWLScore(discordId)

    // Log agent activity
    await logAgentActivity("GRYMM", "WL_AWARD", discordId, undefined, undefined, "wlEvent", {
      project,
      source,
      points,
    })

    // Get GRYMM's ledger message
    const message = getReply("GRYMM", "wlEvent", {
      project,
      source_label: source.replace(/_/g, " "),
      delta: points,
    })

    return NextResponse.json({
      ok: true,
      entry,
      scores,
      message,
    })
  } catch (error) {
    console.error("[WL_LOG] Error:", error)
    return NextResponse.json({ error: "Internal error" }, { status: 500 })
  }
}
