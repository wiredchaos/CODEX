// Get WL scores for a user - upgraded to use Neon DB
import { type NextRequest, NextResponse } from "next/server"
import { getWLScore, getWLLedger } from "@/lib/neuro/db-store"

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const discordId = searchParams.get("discordId")
    const includeLedger = searchParams.get("ledger") === "true"

    if (!discordId) {
      return NextResponse.json({ error: "discordId required" }, { status: 400 })
    }

    const scores = await getWLScore(discordId)

    if (!scores) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    const response: Record<string, unknown> = {
      ok: true,
      discordId,
      scores: {
        vrg33589: scores.vrg33589_score,
        vault33: scores.vault33_score,
        total: scores.total_score,
        gamesWon: scores.games_won,
      },
    }

    if (includeLedger) {
      response.ledger = await getWLLedger(discordId)
    }

    return NextResponse.json(response)
  } catch (error) {
    console.error("[WL_SCORE] Error:", error)
    return NextResponse.json({ error: "Internal error" }, { status: 500 })
  }
}
