// Start a new NPC game session - upgraded to use Neon DB
import { type NextRequest, NextResponse } from "next/server"
import { getOrCreateUser, createNPCGame, getActiveGame, logAgentActivity } from "@/lib/neuro/db-store"
import { getReply } from "@/lib/neuro/router"

type GameType = "LABYRINTH" | "ALCHEMIST" | "FORGE" | "TRIAGE" | "MULTIVERSE" | "SEQUENCE"

const GAME_CONFIG: Record<GameType, { maxMoves: number; agent: string; initTemplate: string }> = {
  LABYRINTH: { maxMoves: 20, agent: "META_X", initTemplate: "labyrinthInit" },
  ALCHEMIST: { maxMoves: 15, agent: "SHADOWLUX", initTemplate: "alchemistInit" },
  FORGE: { maxMoves: 10, agent: "GRYMM", initTemplate: "forgeInit" },
  TRIAGE: { maxMoves: 12, agent: "OYALAN", initTemplate: "triageInit" },
  MULTIVERSE: { maxMoves: 25, agent: "NEUROLUX", initTemplate: "multiverseInit" },
  SEQUENCE: { maxMoves: 8, agent: "KIBA", initTemplate: "sequenceInit" },
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { discordId, game = "LABYRINTH" } = body as {
      discordId: string
      game?: string
    }

    if (!discordId) {
      return NextResponse.json({ error: "discordId required" }, { status: 400 })
    }

    const gameType = game.toUpperCase() as GameType
    if (!GAME_CONFIG[gameType]) {
      return NextResponse.json(
        {
          error: "Invalid game type",
          valid: Object.keys(GAME_CONFIG),
        },
        { status: 400 },
      )
    }

    // Ensure user exists
    await getOrCreateUser(discordId)

    // Check for existing active game
    const existingGame = await getActiveGame(discordId)
    if (existingGame) {
      return NextResponse.json(
        {
          error: "You already have an active game",
          activeGame: {
            id: existingGame.id,
            type: existingGame.game_type,
            moves: existingGame.moves_made,
          },
        },
        { status: 409 },
      )
    }

    const config = GAME_CONFIG[gameType]

    // Create new game session
    const session = await createNPCGame(
      discordId,
      gameType,
      { history: [], currentRoom: "ENTRANCE", inventory: [] },
      config.maxMoves,
      config.agent,
    )

    // Log agent activity
    await logAgentActivity(config.agent, "GAME_START", discordId, undefined, undefined, config.initTemplate, {
      gameType,
      gameId: session.id,
    })

    // Get initialization message
    const message = getReply(config.agent as "META_X", config.initTemplate, {})

    return NextResponse.json({
      ok: true,
      message,
      session: {
        id: session.id,
        game: session.game_type,
        maxMoves: config.maxMoves,
        agent: config.agent,
      },
    })
  } catch (error) {
    console.error("[NPC_START] Error:", error)
    return NextResponse.json({ error: "Internal error" }, { status: 500 })
  }
}
