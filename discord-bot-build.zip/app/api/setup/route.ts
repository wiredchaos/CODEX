import { NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

export async function POST() {
  try {
    // Create tables in order (respecting foreign key constraints)

    // 1. Discord Users table
    await sql`
      CREATE TABLE IF NOT EXISTS discord_users (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        discord_id TEXT UNIQUE NOT NULL,
        discord_username TEXT,
        discord_discriminator TEXT,
        avatar_url TEXT,
        generation TEXT CHECK (generation IN ('GEN1', 'GEN2', 'GEN3')),
        neuro_mode TEXT CHECK (neuro_mode IN ('STANDARD', 'CHAOS', 'ASCEND')),
        wallet_address TEXT,
        is_789_crew BOOLEAN DEFAULT FALSE,
        crew_role TEXT,
        onboarding_started_at TIMESTAMPTZ,
        onboarding_completed_at TIMESTAMPTZ,
        created_at TIMESTAMPTZ DEFAULT NOW(),
        updated_at TIMESTAMPTZ DEFAULT NOW()
      )
    `

    // 2. WL Ledger table
    await sql`
      CREATE TABLE IF NOT EXISTS wl_ledger (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        discord_id TEXT NOT NULL REFERENCES discord_users(discord_id) ON DELETE CASCADE,
        project TEXT NOT NULL CHECK (project IN ('VRG33589', 'VAULT33')),
        points INTEGER NOT NULL DEFAULT 0,
        source TEXT NOT NULL,
        reason TEXT,
        awarded_by TEXT,
        game_id UUID,
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `

    // 3. NPC Games table
    await sql`
      CREATE TABLE IF NOT EXISTS npc_games (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        discord_id TEXT NOT NULL REFERENCES discord_users(discord_id) ON DELETE CASCADE,
        game_type TEXT NOT NULL CHECK (game_type IN ('LABYRINTH', 'ALCHEMIST', 'FORGE', 'TRIAGE', 'MULTIVERSE', 'SEQUENCE')),
        status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'WON', 'LOST', 'ABANDONED')),
        state JSONB NOT NULL DEFAULT '{}',
        moves_made INTEGER DEFAULT 0,
        max_moves INTEGER,
        wl_reward INTEGER DEFAULT 0,
        reward_project TEXT CHECK (reward_project IN ('VRG33589', 'VAULT33')),
        primary_agent TEXT,
        started_at TIMESTAMPTZ DEFAULT NOW(),
        completed_at TIMESTAMPTZ,
        updated_at TIMESTAMPTZ DEFAULT NOW()
      )
    `

    // 4. Agent Activity table
    await sql`
      CREATE TABLE IF NOT EXISTS agent_activity (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        agent_id TEXT NOT NULL,
        action_type TEXT NOT NULL,
        discord_id TEXT,
        channel_id TEXT,
        guild_id TEXT,
        template_key TEXT,
        input_data JSONB,
        output_data JSONB,
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `

    // 5. Swarm State table
    await sql`
      CREATE TABLE IF NOT EXISTS swarm_state (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        discord_id TEXT UNIQUE NOT NULL REFERENCES discord_users(discord_id) ON DELETE CASCADE,
        skill_tree JSONB DEFAULT '{}',
        completed_paths JSONB DEFAULT '[]',
        current_quest TEXT,
        interaction_count INTEGER DEFAULT 0,
        last_agent TEXT,
        memory_snapshot JSONB DEFAULT '{}',
        chaos_score INTEGER DEFAULT 0,
        ascension_level INTEGER DEFAULT 0,
        updated_at TIMESTAMPTZ DEFAULT NOW()
      )
    `

    // Create indexes
    await sql`CREATE INDEX IF NOT EXISTS idx_wl_ledger_discord ON wl_ledger(discord_id)`
    await sql`CREATE INDEX IF NOT EXISTS idx_wl_ledger_project ON wl_ledger(project)`
    await sql`CREATE INDEX IF NOT EXISTS idx_npc_games_discord ON npc_games(discord_id)`
    await sql`CREATE INDEX IF NOT EXISTS idx_npc_games_status ON npc_games(status)`
    await sql`CREATE INDEX IF NOT EXISTS idx_agent_activity_agent ON agent_activity(agent_id)`
    await sql`CREATE INDEX IF NOT EXISTS idx_agent_activity_type ON agent_activity(action_type)`
    await sql`CREATE INDEX IF NOT EXISTS idx_agent_activity_created ON agent_activity(created_at DESC)`

    return NextResponse.json({
      success: true,
      message: "All NEURO SWARM tables created successfully",
      tables: ["discord_users", "wl_ledger", "npc_games", "agent_activity", "swarm_state"],
    })
  } catch (error) {
    console.error("[Setup] Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function GET() {
  try {
    // Check which tables exist
    const result = await sql`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_type = 'BASE TABLE'
    `

    const tables = result.map((r: { table_name: string }) => r.table_name)
    const required = ["discord_users", "wl_ledger", "npc_games", "agent_activity", "swarm_state"]
    const missing = required.filter((t) => !tables.includes(t))

    return NextResponse.json({
      status: missing.length === 0 ? "ready" : "needs_setup",
      existingTables: tables,
      missingTables: missing,
      setupUrl: "/api/setup (POST)",
    })
  } catch (error) {
    console.error("[Setup Check] Error:", error)
    return NextResponse.json(
      {
        status: "error",
        error: error instanceof Error ? error.message : "Database connection failed",
      },
      { status: 500 },
    )
  }
}
