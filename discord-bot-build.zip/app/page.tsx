import { Suspense } from "react"
import { Ticker } from "@/components/control-plane/ticker"
import { ProjectTabs } from "@/components/control-plane/project-tabs"
import { NpcStatus } from "@/components/control-plane/npc-status"
import { SwarmAgents } from "@/components/control-plane/swarm-agents"

export default function ControlPlanePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-primary/20 bg-black/40">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col gap-2">
            <h1 className="text-2xl md:text-3xl font-bold tracking-tight">
              <span className="text-primary">WIRED CHAOS META</span>
              <span className="text-muted-foreground"> — </span>
              <span className="text-foreground">NEURO SWARM CONTROL PLANE</span>
            </h1>
            <p className="text-muted-foreground font-mono text-sm">VRG33589 × VAULT33 • WL, NPC, and Agent State</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="flex flex-col gap-8">
          {/* Row 1: Ticker */}
          <section>
            <Suspense fallback={<div className="h-64 animate-pulse bg-muted rounded-lg" />}>
              <Ticker />
            </Suspense>
          </section>

          {/* Row 2: Project Tabs + NPC Status */}
          <div className="grid gap-8 lg:grid-cols-2">
            <section>
              <Suspense fallback={<div className="h-64 animate-pulse bg-muted rounded-lg" />}>
                <ProjectTabs />
              </Suspense>
            </section>

            <section>
              <Suspense fallback={<div className="h-64 animate-pulse bg-muted rounded-lg" />}>
                <NpcStatus />
              </Suspense>
            </section>
          </div>

          {/* Row 3: Swarm Agents */}
          <section>
            <Suspense fallback={<div className="h-64 animate-pulse bg-muted rounded-lg" />}>
              <SwarmAgents />
            </Suspense>
          </section>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-primary/20 bg-black/40 mt-auto">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between text-xs text-muted-foreground font-mono">
            <span>NEURO SWARM v1.0</span>
            <span>789 CREW • WIRED CHAOS</span>
          </div>
        </div>
      </footer>
    </div>
  )
}
