"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle2, XCircle, Loader2, Database, ArrowRight } from "lucide-react"

interface SetupStatus {
  status: "ready" | "needs_setup" | "error"
  existingTables?: string[]
  missingTables?: string[]
  error?: string
}

interface SetupResult {
  success: boolean
  message?: string
  tables?: string[]
  error?: string
}

export default function SetupPage() {
  const [status, setStatus] = useState<SetupStatus | null>(null)
  const [loading, setLoading] = useState(false)
  const [setupResult, setSetupResult] = useState<SetupResult | null>(null)

  const checkStatus = async () => {
    setLoading(true)
    try {
      const res = await fetch("/api/setup")
      const data = await res.json()
      setStatus(data)
    } catch {
      setStatus({ status: "error", error: "Failed to connect" })
    }
    setLoading(false)
  }

  const runSetup = async () => {
    setLoading(true)
    try {
      const res = await fetch("/api/setup", { method: "POST" })
      const data = await res.json()
      setSetupResult(data)
      if (data.success) {
        await checkStatus()
      }
    } catch {
      setSetupResult({ success: false, error: "Setup failed" })
    }
    setLoading(false)
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-lg">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
            <Database className="h-6 w-6 text-primary" />
          </div>
          <CardTitle className="text-2xl">NEURO SWARM Setup</CardTitle>
          <CardDescription>Initialize your database tables for the WIRED CHAOS bot</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!status && (
            <Button onClick={checkStatus} disabled={loading} className="w-full">
              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Check Database Status
            </Button>
          )}

          {status && (
            <div className="space-y-4">
              <div
                className={`flex items-center gap-2 p-3 rounded-lg ${
                  status.status === "ready"
                    ? "bg-green-500/10 text-green-500"
                    : status.status === "needs_setup"
                      ? "bg-yellow-500/10 text-yellow-500"
                      : "bg-red-500/10 text-red-500"
                }`}
              >
                {status.status === "ready" ? (
                  <CheckCircle2 className="h-5 w-5" />
                ) : status.status === "needs_setup" ? (
                  <Database className="h-5 w-5" />
                ) : (
                  <XCircle className="h-5 w-5" />
                )}
                <span className="font-medium">
                  {status.status === "ready"
                    ? "Database Ready"
                    : status.status === "needs_setup"
                      ? "Setup Required"
                      : "Connection Error"}
                </span>
              </div>

              {status.existingTables && status.existingTables.length > 0 && (
                <div className="text-sm">
                  <p className="font-medium mb-1">Existing Tables:</p>
                  <div className="flex flex-wrap gap-1">
                    {status.existingTables.map((t) => (
                      <span key={t} className="px-2 py-0.5 bg-green-500/10 text-green-500 rounded text-xs">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {status.missingTables && status.missingTables.length > 0 && (
                <div className="text-sm">
                  <p className="font-medium mb-1">Missing Tables:</p>
                  <div className="flex flex-wrap gap-1">
                    {status.missingTables.map((t) => (
                      <span key={t} className="px-2 py-0.5 bg-yellow-500/10 text-yellow-500 rounded text-xs">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {status.status === "needs_setup" && (
                <Button onClick={runSetup} disabled={loading} className="w-full">
                  {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  Create Tables
                </Button>
              )}

              {status.status === "ready" && (
                <Button asChild className="w-full">
                  <a href="/">
                    Go to Dashboard <ArrowRight className="ml-2 h-4 w-4" />
                  </a>
                </Button>
              )}

              {setupResult && (
                <div
                  className={`p-3 rounded-lg text-sm ${
                    setupResult.success ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500"
                  }`}
                >
                  {setupResult.success ? setupResult.message : setupResult.error}
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
