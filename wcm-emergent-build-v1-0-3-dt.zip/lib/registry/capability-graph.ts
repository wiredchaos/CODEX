import { agentRegistry } from "./agents"
import { mcpRegistry } from "./mcp-servers"
import type { Agent, McpTool } from "../patches/types"

interface CapabilityMatch {
  capability: string
  agents: Agent[]
  tools: McpTool[]
}

class CapabilityGraph {
  buildCapabilityGraph(): Map<string, CapabilityMatch> {
    const graph = new Map<string, CapabilityMatch>()
    const agents = agentRegistry.listAgents()
    const tools = mcpRegistry.listMcpTools()

    // Collect all unique capabilities from agents
    const allCapabilities = new Set<string>()
    agents.forEach((a) => a.capabilities.forEach((c) => allCapabilities.add(c)))

    // Build the graph
    allCapabilities.forEach((capability) => {
      const matchingAgents = agents.filter((a) => a.capabilities.includes(capability))
      const matchingTools = tools.filter((t) => {
        // Match tools based on agent preferences
        return matchingAgents.some((a) => a.mcpToolPrefs.includes(t.category))
      })

      graph.set(capability, {
        capability,
        agents: matchingAgents,
        tools: matchingTools,
      })
    })

    return graph
  }

  getMatchesForGoal(goal: string): CapabilityMatch[] {
    const graph = this.buildCapabilityGraph()
    const matches: CapabilityMatch[] = []
    const goalLower = goal.toLowerCase()

    // Simple keyword matching for now
    const keywords = goalLower.split(/\s+/)

    graph.forEach((match, capability) => {
      const capLower = capability.toLowerCase()
      if (keywords.some((k) => capLower.includes(k) || k.includes(capLower))) {
        matches.push(match)
      }
    })

    // Also check agent descriptions
    const agents = agentRegistry.listAgents()
    agents.forEach((agent) => {
      if (keywords.some((k) => agent.description.toLowerCase().includes(k) || agent.role.toLowerCase().includes(k))) {
        agent.capabilities.forEach((cap) => {
          const existing = graph.get(cap)
          if (existing && !matches.includes(existing)) {
            matches.push(existing)
          }
        })
      }
    })

    return matches
  }

  suggestAgentToolPairs(goal: string): Array<{ agent: Agent; tools: McpTool[]; score: number }> {
    const matches = this.getMatchesForGoal(goal)
    const agentScores = new Map<string, { agent: Agent; tools: Set<McpTool>; score: number }>()

    matches.forEach((match) => {
      match.agents.forEach((agent) => {
        const existing = agentScores.get(agent.id)
        if (existing) {
          existing.score += 1
          match.tools.forEach((t) => existing.tools.add(t))
        } else {
          agentScores.set(agent.id, {
            agent,
            tools: new Set(match.tools),
            score: 1,
          })
        }
      })
    })

    return Array.from(agentScores.values())
      .map((v) => ({ agent: v.agent, tools: Array.from(v.tools), score: v.score }))
      .sort((a, b) => b.score - a.score)
  }
}

export const capabilityGraph = new CapabilityGraph()
