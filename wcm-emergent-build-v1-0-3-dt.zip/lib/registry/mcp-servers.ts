import type { McpServer, McpTool } from "../patches/types"

export const STATIC_MCP_SERVERS: McpServer[] = [
  {
    id: "mcp_github",
    name: "GitHub MCP",
    baseUrl: process.env.MCP_GITHUB_URL || "https://mcp.wiredchaos.io/github",
    manifestUrl: "/manifest.json",
    status: "online",
    categories: ["github", "version_control"],
    lastCheckedAt: new Date(),
  },
  {
    id: "mcp_filesystem",
    name: "Filesystem MCP",
    baseUrl: process.env.MCP_FILESYSTEM_URL || "https://mcp.wiredchaos.io/filesystem",
    manifestUrl: "/manifest.json",
    status: "online",
    categories: ["filesystem", "storage"],
    lastCheckedAt: new Date(),
  },
  {
    id: "mcp_tax",
    name: "Tax Engine MCP",
    baseUrl: process.env.MCP_TAX_URL || "https://mcp.wiredchaos.io/tax",
    manifestUrl: "/manifest.json",
    status: "unknown",
    categories: ["tax_engine", "compliance"],
    lastCheckedAt: new Date(),
  },
  {
    id: "mcp_xrpl",
    name: "XRPL MCP",
    baseUrl: process.env.MCP_XRPL_URL || "https://mcp.wiredchaos.io/xrpl",
    manifestUrl: "/manifest.json",
    status: "online",
    categories: ["xrpl", "blockchain", "nfts"],
    lastCheckedAt: new Date(),
  },
  {
    id: "mcp_docs",
    name: "Document Engine MCP",
    baseUrl: process.env.MCP_DOCS_URL || "https://mcp.wiredchaos.io/docs",
    manifestUrl: "/manifest.json",
    status: "online",
    categories: ["doc_engine", "pdf_builder"],
    lastCheckedAt: new Date(),
  },
]

export const STATIC_MCP_TOOLS: McpTool[] = [
  {
    id: "tool_github_read",
    serverId: "mcp_github",
    name: "github.read_repo",
    description: "Read repository contents and structure",
    category: "github",
    inputSchema: { repoUrl: "string", branch: "string?" },
    outputSchema: { files: "array", structure: "object" },
    isDangerous: false,
    requiresApproval: false,
  },
  {
    id: "tool_github_write",
    serverId: "mcp_github",
    name: "github.write_file",
    description: "Write or update files in a repository",
    category: "github",
    inputSchema: { repoUrl: "string", path: "string", content: "string" },
    outputSchema: { success: "boolean", commitSha: "string" },
    isDangerous: true,
    requiresApproval: true,
  },
  {
    id: "tool_fs_read",
    serverId: "mcp_filesystem",
    name: "filesystem.read",
    description: "Read file contents from the filesystem",
    category: "filesystem",
    inputSchema: { path: "string" },
    outputSchema: { content: "string" },
    isDangerous: false,
    requiresApproval: false,
  },
  {
    id: "tool_fs_edit",
    serverId: "mcp_filesystem",
    name: "filesystem.edit",
    description: "Edit file contents on the filesystem",
    category: "filesystem",
    inputSchema: { path: "string", content: "string" },
    outputSchema: { success: "boolean" },
    isDangerous: true,
    requiresApproval: true,
  },
  {
    id: "tool_doc_gen",
    serverId: "mcp_docs",
    name: "doc_engine.generate",
    description: "Generate documentation from code or templates",
    category: "doc_engine",
    inputSchema: { template: "string", context: "object" },
    outputSchema: { document: "string", format: "string" },
    isDangerous: false,
    requiresApproval: false,
  },
  {
    id: "tool_xrpl_mint",
    serverId: "mcp_xrpl",
    name: "xrpl.mint_nft",
    description: "Mint an NFT on the XRP Ledger",
    category: "xrpl",
    inputSchema: { metadata: "object", wallet: "string" },
    outputSchema: { tokenId: "string", txHash: "string" },
    isDangerous: true,
    requiresApproval: true,
  },
]

class McpRegistry {
  private servers: McpServer[] = STATIC_MCP_SERVERS
  private tools: McpTool[] = STATIC_MCP_TOOLS

  listMcpServers(): McpServer[] {
    return this.servers
  }

  getMcpServer(id: string): McpServer | undefined {
    return this.servers.find((s) => s.id === id)
  }

  listMcpTools(): McpTool[] {
    return this.tools
  }

  listMcpToolsByCategory(category: string): McpTool[] {
    return this.tools.filter((t) => t.category === category)
  }

  getToolsForServer(serverId: string): McpTool[] {
    return this.tools.filter((t) => t.serverId === serverId)
  }

  getTool(toolId: string): McpTool | undefined {
    return this.tools.find((t) => t.id === toolId || t.name === toolId)
  }
}

export const mcpRegistry = new McpRegistry()
