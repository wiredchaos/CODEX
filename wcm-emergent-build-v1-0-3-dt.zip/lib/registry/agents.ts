import type { Agent } from "../patches/types"

export const STATIC_AGENTS: Agent[] = [
  {
    id: "agent_architect",
    name: "NEURO_ARCHITECT",
    role: "Architect",
    description: "Repository refactoring, architecture diagrams, and code structure optimization.",
    capabilities: ["repo_refactor", "architecture_diagram", "code_review"],
    swarmKey: "neuro_architect_v1",
    mcpToolPrefs: ["github", "filesystem", "doc_engine"],
    isActive: true,
  },
  {
    id: "agent_tax",
    name: "NEURA_TAX_AI",
    role: "Tax Strategist",
    description: "AI-powered tax preparation, entity strategy, and compliance automation.",
    capabilities: ["tax_prep", "efile_planning", "entity_strategy"],
    swarmKey: "neura_tax_v1",
    mcpToolPrefs: ["tax_engine", "spreadsheet", "pdf_builder"],
    isActive: true,
  },
  {
    id: "agent_scribe",
    name: "DOC_SCRIBE",
    role: "Documentation Specialist",
    description: "Technical documentation, README generation, and knowledge base creation.",
    capabilities: ["documentation", "readme_gen", "knowledge_base"],
    swarmKey: "doc_scribe_v1",
    mcpToolPrefs: ["doc_engine", "filesystem", "github"],
    isActive: true,
  },
  {
    id: "agent_trust",
    name: "TRUST_ORACLE",
    role: "Estate Planner",
    description: "Trust blueprints, estate planning flows, and asset protection strategies.",
    capabilities: ["trusts", "estate_planning", "asset_protection"],
    swarmKey: "trust_oracle_v1",
    mcpToolPrefs: ["trust_docs", "pdf_builder", "spreadsheet"],
    isActive: false,
  },
  {
    id: "agent_coach",
    name: "NPC_COACH",
    role: "Prompt Coach",
    description: "Gamified prompt training, workflow optimization, and NPC-style guidance.",
    capabilities: ["prompt_training", "workflow_opt", "gamification"],
    swarmKey: "npc_coach_v1",
    mcpToolPrefs: ["prompt_library", "gamification_engine"],
    isActive: true,
  },
]

class AgentRegistry {
  private agents: Agent[] = STATIC_AGENTS

  listAgents(): Agent[] {
    return this.agents
  }

  getAgent(id: string): Agent | undefined {
    return this.agents.find((a) => a.id === id || a.name === id)
  }

  listActiveAgents(): Agent[] {
    return this.agents.filter((a) => a.isActive)
  }

  getAgentsByCapability(capability: string): Agent[] {
    return this.agents.filter((a) => a.capabilities.includes(capability))
  }
}

export const agentRegistry = new AgentRegistry()
