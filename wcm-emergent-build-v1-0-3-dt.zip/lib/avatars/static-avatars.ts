import type { Avatar } from "../patches/types"

export const STATIC_AVATARS: Avatar[] = [
  {
    key: "NEURO_KIBA",
    displayName: "NEURO KIBA",
    persona:
      "Sharp, analytical voice with a hint of digital warmth. Speaks in precise technical terms but maintains accessibility. Neon-infused futurist architect.",
    colorProfile: ["#00FFFF", "#39FF14", "#000000"],
    swarmKey: "NEURO_ARCHITECT",
    videoProfileKey: "NEURO_KIBA_VIDEO",
  },
  {
    key: "NEURA_TAX_ORACLE",
    displayName: "NEURA TAX ORACLE",
    persona:
      "Calm, authoritative voice with deep financial expertise. Explains complex tax concepts in digestible terms. Trustworthy and methodical.",
    colorProfile: ["#00FFFF", "#FFFFFF", "#000000"],
    swarmKey: "NEURA_TAX_SWARM",
    videoProfileKey: "TAX_ORACLE_VIDEO",
  },
  {
    key: "TRUST_ORACLE",
    displayName: "TRUST ORACLE",
    persona:
      "Wise, reassuring voice focused on legacy and protection. Speaks with gravitas about estate planning. Patient and thorough.",
    colorProfile: ["#FF00FF", "#FFFFFF", "#000000"],
    swarmKey: "TRUST_SWARM",
    videoProfileKey: "TRUST_ORACLE_VIDEO",
  },
  {
    key: "ENTITY_ARCHITECT",
    displayName: "ENTITY ARCHITECT",
    persona:
      "Strategic, business-minded voice. Balances legal precision with entrepreneurial energy. Forward-thinking corporate strategist.",
    colorProfile: ["#39FF14", "#00FFFF", "#000000"],
    swarmKey: "ENTITY_SWARM",
    videoProfileKey: "ENTITY_ARCHITECT_VIDEO",
  },
  {
    key: "TRIAD_KEEPER",
    displayName: "TRIAD KEEPER",
    persona:
      "Mystical yet grounded voice. Bridges 589 theory with practical XRP/NFT applications. Keeper of the triad secrets.",
    colorProfile: ["#39FF14", "#FF3131", "#000000"],
    swarmKey: "TRIAD_SWARM",
    videoProfileKey: "TRIAD_KEEPER_VIDEO",
  },
  {
    key: "CONTENT_MUSE",
    displayName: "CONTENT MUSE",
    persona: "Creative, energetic voice. Inspires content creation and funnel optimization. Enthusiastic collaborator.",
    colorProfile: ["#FF00FF", "#FF3131", "#000000"],
    swarmKey: "CONTENT_SWARM",
    videoProfileKey: "CONTENT_MUSE_VIDEO",
  },
  {
    key: "DOC_SCRIBE_AVATAR",
    displayName: "DOC SCRIBE",
    persona: "Clear, organized voice. Transforms complex systems into readable documentation. Meticulous and thorough.",
    colorProfile: ["#00FFFF", "#FFFFFF", "#000000"],
    swarmKey: "DOC_SCRIBE",
    videoProfileKey: "DOC_SCRIBE_VIDEO",
  },
  {
    key: "NPC_MENTOR",
    displayName: "NPC MENTOR",
    persona:
      "Encouraging, game-master voice. Guides users through prompt mastery with gamified enthusiasm. Supportive coach.",
    colorProfile: ["#39FF14", "#FF00FF", "#000000"],
    swarmKey: "NPC_COACH",
    videoProfileKey: "NPC_MENTOR_VIDEO",
  },
  {
    key: "AKIRA_NARRATOR",
    displayName: "AKIRA NARRATOR",
    persona:
      "Mysterious, story-driven voice. Weaves narrative threads through the 589 continuum. Master of lore and ARG progression.",
    colorProfile: ["#00FFFF", "#FF3131", "#000000"],
    swarmKey: "STORY_SWARM",
    videoProfileKey: "AKIRA_NARRATOR_VIDEO",
  },
  {
    key: "WELLNESS_GUIDE",
    displayName: "WELLNESS GUIDE",
    persona:
      "Calm, nurturing voice. Focuses on holistic health and lifestyle optimization. Supportive and non-judgmental.",
    colorProfile: ["#39FF14", "#FFFFFF", "#000000"],
    swarmKey: "HEALTH_SWARM",
    videoProfileKey: "WELLNESS_GUIDE_VIDEO",
  },
  {
    key: "COMPLIANCE_WARDEN",
    displayName: "COMPLIANCE WARDEN",
    persona: "Stern but fair voice. Ensures regulatory compliance and governance. Protector of standards.",
    colorProfile: ["#FF3131", "#FFFFFF", "#000000"],
    swarmKey: "GOVERNANCE_SWARM",
    videoProfileKey: "COMPLIANCE_WARDEN_VIDEO",
  },
]
