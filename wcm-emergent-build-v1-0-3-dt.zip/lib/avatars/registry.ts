import type { Avatar } from "../patches/types"
import { STATIC_AVATARS } from "./static-avatars"

class AvatarRegistry {
  private avatars: Avatar[] = STATIC_AVATARS

  get(key: string): Avatar | undefined {
    return this.avatars.find((a) => a.key === key)
  }

  getByKey(key: string): Avatar | undefined {
    return this.get(key)
  }

  getAvatar(key: string): Avatar | undefined {
    return this.get(key)
  }

  getAvatarByKey(key: string): Avatar | undefined {
    return this.get(key)
  }

  list(): Avatar[] {
    return this.avatars
  }

  listAvatars(): Avatar[] {
    return this.list()
  }

  getAvatarBySwarm(swarmKey: string): Avatar | undefined {
    return this.avatars.find((a) => a.swarmKey === swarmKey)
  }

  listBySwarm(swarmKey: string): Avatar[] {
    return this.avatars.filter((a) => a.swarmKey === swarmKey)
  }
}

export const avatarRegistry = new AvatarRegistry()
