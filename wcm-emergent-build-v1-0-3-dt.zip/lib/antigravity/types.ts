// CHAOS Antigravity Engine - Core Types

export type ExecutionStatus = "pending" | "planning" | "executing" | "paused" | "completed" | "failed" | "cancelled"
export type StepStatus = "queued" | "running" | "success" | "failed" | "skipped"

export interface AntigravityTask {
  id: string
  goal: string
  context?: string
  domain: string
  createdAt: string
  updatedAt: string
  status: ExecutionStatus
  plan: AntigravityPlan | null
  results: StepResult[]
  metadata: TaskMetadata
}

export interface AntigravityPlan {
  planId: string
  steps: PlanStep[]
  estimatedDuration: number // ms
  riskLevel: "low" | "medium" | "high"
  requiredApprovals: string[]
}

export interface PlanStep {
  stepNumber: number
  agentKey: string
  agentName: string
  toolId: string
  toolName: string
  action: string
  params: Record<string, unknown>
  dependsOn: number[] // step numbers this depends on
  estimatedMs: number
  requiresApproval: boolean
  riskLevel: "low" | "medium" | "high"
}

export interface StepResult {
  stepNumber: number
  status: StepStatus
  startedAt: string | null
  completedAt: string | null
  latencyMs: number
  output: unknown
  error: string | null
  retryCount: number
}

export interface TaskMetadata {
  maxSteps: number
  safeMode: boolean
  autoExecute: boolean
  retryOnFail: boolean
  maxRetries: number
  timeoutMs: number
  swarmCount: number
  toolCount: number
  domainSwarms: string[]
}

export interface ExecutionContext {
  taskId: string
  currentStep: number
  totalSteps: number
  previousResults: StepResult[]
  globalParams: Record<string, unknown>
}

export interface SwarmCapabilityMatch {
  swarmKey: string
  swarmName: string
  matchScore: number
  matchedCapabilities: string[]
  suggestedTools: ToolSuggestion[]
}

export interface ToolSuggestion {
  toolId: string
  toolName: string
  relevanceScore: number
  action: string
  estimatedMs: number
}

export interface AntigravityConfig {
  maxSteps: number
  safeMode: boolean
  autoExecute: boolean
  retryOnFail: boolean
  maxRetries: number
  timeoutMs: number
  domain?: string
}

export const DEFAULT_CONFIG: AntigravityConfig = {
  maxSteps: 10,
  safeMode: true,
  autoExecute: false,
  retryOnFail: true,
  maxRetries: 3,
  timeoutMs: 30000,
}
