// CHAOS Antigravity Engine - Main Orchestrator

import type { AntigravityTask, AntigravityConfig, ExecutionStatus } from "./types"
import { antigravityPlanner } from "./planner"
import { antigravityExecutor } from "./executor"
import { swarmRegistry } from "@/lib/swarms/registry"
import { mcpRegistry } from "@/lib/registry/mcp-servers"
import type { SwarmType } from "@/lib/patches/types"

// In-memory task store (would be database in production)
const taskStore = new Map<string, AntigravityTask>()

export class AntigravityEngine {
  /**
   * Create a new task
   */
  createTask(goal: string, context = "", config: Partial<AntigravityConfig> = {}): AntigravityTask {
    const fullConfig: AntigravityConfig = {
      maxSteps: config.maxSteps ?? 10,
      safeMode: config.safeMode ?? true,
      autoExecute: config.autoExecute ?? false,
      retryOnFail: config.retryOnFail ?? true,
      maxRetries: config.maxRetries ?? 3,
      timeoutMs: config.timeoutMs ?? 30000,
      domain: config.domain,
    }

    const domain = fullConfig.domain || antigravityPlanner.detectDomain(goal)
    const domainSwarms = swarmRegistry.getSwarmsByType(domain as SwarmType).map((s) => s.name)

    const task: AntigravityTask = {
      id: `task_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      goal,
      context,
      domain,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      status: "pending",
      plan: null,
      results: [],
      metadata: {
        maxSteps: fullConfig.maxSteps,
        safeMode: fullConfig.safeMode,
        autoExecute: fullConfig.autoExecute,
        retryOnFail: fullConfig.retryOnFail,
        maxRetries: fullConfig.maxRetries,
        timeoutMs: fullConfig.timeoutMs,
        swarmCount: swarmRegistry.listActiveSwarms().length,
        toolCount: mcpRegistry.listMcpTools().length,
        domainSwarms,
      },
    }

    taskStore.set(task.id, task)
    return task
  }

  /**
   * Generate plan for a task
   */
  planTask(taskId: string): AntigravityTask {
    const task = taskStore.get(taskId)
    if (!task) throw new Error(`Task ${taskId} not found`)

    task.status = "planning"
    task.updatedAt = new Date().toISOString()

    const plan = antigravityPlanner.generatePlan(task.goal, task.context || "", {
      maxSteps: task.metadata.maxSteps,
      safeMode: task.metadata.safeMode,
      autoExecute: task.metadata.autoExecute,
      retryOnFail: task.metadata.retryOnFail,
      maxRetries: task.metadata.maxRetries,
      timeoutMs: task.metadata.timeoutMs,
      domain: task.domain,
    })

    task.plan = plan
    task.status = "pending" // Ready for execution
    task.updatedAt = new Date().toISOString()

    taskStore.set(taskId, task)
    return task
  }

  /**
   * Execute a task's plan
   */
  async executeTask(taskId: string, onProgress?: (task: AntigravityTask) => void): Promise<AntigravityTask> {
    const task = taskStore.get(taskId)
    if (!task) throw new Error(`Task ${taskId} not found`)
    if (!task.plan) throw new Error(`Task ${taskId} has no plan`)

    task.status = "executing"
    task.updatedAt = new Date().toISOString()

    const results = await antigravityExecutor.executePlan(
      task,
      {
        maxSteps: task.metadata.maxSteps,
        safeMode: task.metadata.safeMode,
        autoExecute: task.metadata.autoExecute,
        retryOnFail: task.metadata.retryOnFail,
        maxRetries: task.metadata.maxRetries,
        timeoutMs: task.metadata.timeoutMs,
        domain: task.domain,
      },
      (result) => {
        task.results.push(result)
        task.updatedAt = new Date().toISOString()
        if (onProgress) onProgress(task)
      },
    )

    // Determine final status
    const failedCount = results.filter((r) => r.status === "failed").length
    const successCount = results.filter((r) => r.status === "success").length

    if (failedCount === 0) {
      task.status = "completed"
    } else if (successCount > 0) {
      task.status = "completed" // Partial success
    } else {
      task.status = "failed"
    }

    task.results = results
    task.updatedAt = new Date().toISOString()
    taskStore.set(taskId, task)

    return task
  }

  /**
   * Get task by ID
   */
  getTask(taskId: string): AntigravityTask | undefined {
    return taskStore.get(taskId)
  }

  /**
   * List all tasks
   */
  listTasks(): AntigravityTask[] {
    return Array.from(taskStore.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
    )
  }

  /**
   * Cancel a task
   */
  cancelTask(taskId: string): AntigravityTask {
    const task = taskStore.get(taskId)
    if (!task) throw new Error(`Task ${taskId} not found`)

    task.status = "cancelled"
    task.updatedAt = new Date().toISOString()
    taskStore.set(taskId, task)

    return task
  }

  /**
   * Get engine statistics
   */
  getStats(): {
    totalTasks: number
    byStatus: Record<ExecutionStatus, number>
    activeSwarms: number
    availableTools: number
  } {
    const tasks = Array.from(taskStore.values())
    const byStatus: Record<ExecutionStatus, number> = {
      pending: 0,
      planning: 0,
      executing: 0,
      paused: 0,
      completed: 0,
      failed: 0,
      cancelled: 0,
    }

    for (const task of tasks) {
      byStatus[task.status]++
    }

    return {
      totalTasks: tasks.length,
      byStatus,
      activeSwarms: swarmRegistry.listActiveSwarms().length,
      availableTools: mcpRegistry.listMcpTools().length,
    }
  }
}

export const antigravityEngine = new AntigravityEngine()
