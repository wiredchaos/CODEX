// CHAOS Antigravity Engine - AI Planner

import type { AntigravityPlan, PlanStep, SwarmCapabilityMatch, ToolSuggestion, AntigravityConfig } from "./types"
import { swarmRegistry } from "@/lib/swarms/registry"
import { mcpRegistry } from "@/lib/registry/mcp-servers"
import { capabilityGraph } from "@/lib/registry/capability-graph"
import type { SwarmType } from "@/lib/patches/types"

// Domain keyword mappings for intelligent routing
const DOMAIN_KEYWORDS: Record<string, string[]> = {
  tax: ["tax", "irs", "filing", "deduction", "crypto", "expat", "efile", "1099", "w2", "schedule", "return"],
  trust: ["trust", "estate", "beneficiary", "asset protection", "revocable", "irrevocable", "grantor"],
  entity: ["llc", "corporation", "s-corp", "c-corp", "holding", "offshore", "formation", "business entity"],
  triad: ["589", "fen", "vrg", "vault33", "xrpl", "nft", "artifact", "triad", "magazine"],
  content: ["content", "video", "funnel", "workflow", "creative", "studio", "avatar", "marketing"],
  system: ["architecture", "refactor", "code", "documentation", "api", "deploy", "build"],
  health: ["health", "wellness", "biometric", "fitness", "nutrition", "lifestyle"],
}

// Capability to action mappings
const CAPABILITY_ACTIONS: Record<string, string> = {
  tax_prep_domestic: "Prepare domestic tax return",
  tax_prep_expat: "Prepare expatriate tax return",
  efile_us_only: "Submit electronic filing",
  crypto_tax: "Calculate cryptocurrency gains/losses",
  entity_strategy: "Develop entity structure strategy",
  revocable_trusts: "Draft revocable trust blueprint",
  irrevocable_trusts: "Draft irrevocable trust blueprint",
  asset_protection: "Design asset protection strategy",
  us_llc_corp: "Form US LLC or Corporation",
  multi_state_nexus: "Analyze multi-state nexus",
  intl_holding_cos: "Structure international holding company",
  xrpl_nft_layers: "Mint XRPL NFT layers",
  triad_progression: "Process triad progression",
  content_systems: "Build content system",
  avatar_video: "Generate avatar video",
  repo_refactor: "Refactor repository structure",
  documentation: "Generate documentation",
}

export class AntigravityPlanner {
  /**
   * Detect domain from goal text using keyword matching
   */
  detectDomain(goal: string): string {
    const lowerGoal = goal.toLowerCase()
    let bestMatch = { domain: "system", score: 0 }

    for (const [domain, keywords] of Object.entries(DOMAIN_KEYWORDS)) {
      const matchCount = keywords.filter((kw) => lowerGoal.includes(kw)).length
      if (matchCount > bestMatch.score) {
        bestMatch = { domain, score: matchCount }
      }
    }

    return bestMatch.domain
  }

  /**
   * Find best matching swarms for a goal
   */
  findMatchingSwarms(goal: string, domain?: string): SwarmCapabilityMatch[] {
    const detectedDomain = domain || this.detectDomain(goal)
    const lowerGoal = goal.toLowerCase()

    // Get swarms by domain first
    let candidates = swarmRegistry.getSwarmsByType(detectedDomain as SwarmType)

    // If no domain-specific swarms, fall back to all active swarms
    if (candidates.length === 0) {
      candidates = swarmRegistry.listActiveSwarms()
    }

    const matches: SwarmCapabilityMatch[] = []

    for (const swarm of candidates) {
      const matchedCapabilities: string[] = []
      let matchScore = 0

      // Score based on capability relevance
      for (const cap of swarm.capabilities) {
        const capWords = cap.toLowerCase().split("_")
        const capMatches = capWords.filter((w) => lowerGoal.includes(w)).length
        if (capMatches > 0) {
          matchedCapabilities.push(cap)
          matchScore += capMatches * 10
        }
      }

      // Bonus for domain match
      if (swarm.swarmType === detectedDomain) {
        matchScore += 20
      }

      // Bonus for active status
      if (swarm.isActive) {
        matchScore += 10
      }

      // Get suggested tools for this swarm
      const suggestedTools = this.suggestToolsForSwarm(swarm.key, matchedCapabilities)

      matches.push({
        swarmKey: swarm.key,
        swarmName: swarm.name,
        matchScore,
        matchedCapabilities,
        suggestedTools,
      })
    }

    // Sort by match score descending
    return matches.sort((a, b) => b.matchScore - a.matchScore)
  }

  /**
   * Suggest tools for a swarm based on matched capabilities
   */
  suggestToolsForSwarm(swarmKey: string, capabilities: string[]): ToolSuggestion[] {
    const allTools = mcpRegistry.listMcpTools()
    const suggestions: ToolSuggestion[] = []

    for (const tool of allTools) {
      let relevanceScore = 0
      const toolCategory = tool.category.toLowerCase()
      const toolName = tool.name.toLowerCase()

      // Match against capabilities
      for (const cap of capabilities) {
        const capParts = cap.toLowerCase().split("_")
        if (capParts.some((p) => toolCategory.includes(p) || toolName.includes(p))) {
          relevanceScore += 15
        }
      }

      // Additional relevance for non-dangerous tools
      if (!tool.isDangerous) {
        relevanceScore += 5
      }

      if (relevanceScore > 0) {
        suggestions.push({
          toolId: tool.id,
          toolName: tool.name,
          relevanceScore,
          action: CAPABILITY_ACTIONS[capabilities[0]] || `Execute ${tool.name}`,
          estimatedMs: tool.isDangerous ? 3000 : 1500,
        })
      }
    }

    return suggestions.sort((a, b) => b.relevanceScore - a.relevanceScore).slice(0, 5)
  }

  /**
   * Generate execution plan from goal
   */
  generatePlan(goal: string, context = "", config: AntigravityConfig): AntigravityPlan {
    const domain = config.domain || this.detectDomain(goal)
    const swarmMatches = this.findMatchingSwarms(goal, domain)

    // Also get suggestions from capability graph
    const graphSuggestions = capabilityGraph.suggestAgentToolPairs(goal)

    const steps: PlanStep[] = []
    let stepNumber = 1
    let totalEstimatedMs = 0
    const requiredApprovals: string[] = []
    let highestRisk: "low" | "medium" | "high" = "low"

    // Build steps from swarm matches
    for (const match of swarmMatches) {
      if (stepNumber > config.maxSteps) break
      if (match.suggestedTools.length === 0) continue

      for (const tool of match.suggestedTools) {
        if (stepNumber > config.maxSteps) break

        const mcpTool = mcpRegistry.getTool(tool.toolId)
        const requiresApproval = config.safeMode && mcpTool?.isDangerous
        const riskLevel = mcpTool?.isDangerous ? "high" : "low"

        if (riskLevel === "high") highestRisk = "high"
        else if (riskLevel === "medium" && highestRisk === "low") highestRisk = "medium"

        if (requiresApproval) {
          requiredApprovals.push(`Step ${stepNumber}: ${tool.action}`)
        }

        steps.push({
          stepNumber,
          agentKey: match.swarmKey,
          agentName: match.swarmName,
          toolId: tool.toolId,
          toolName: tool.toolName,
          action: tool.action,
          params: {
            goal,
            context,
            domain,
            capabilities: match.matchedCapabilities,
          },
          dependsOn: stepNumber > 1 ? [stepNumber - 1] : [],
          estimatedMs: tool.estimatedMs,
          requiresApproval: requiresApproval || false,
          riskLevel,
        })

        totalEstimatedMs += tool.estimatedMs
        stepNumber++
      }
    }

    // Fallback: add steps from capability graph if we have none
    if (steps.length === 0 && graphSuggestions.length > 0) {
      for (const suggestion of graphSuggestions) {
        if (stepNumber > config.maxSteps) break

        for (const tool of suggestion.tools) {
          if (stepNumber > config.maxSteps) break

          steps.push({
            stepNumber,
            agentKey: suggestion.agent.id,
            agentName: suggestion.agent.name,
            toolId: tool.id,
            toolName: tool.name,
            action: `Execute ${tool.name}`,
            params: { goal, context },
            dependsOn: stepNumber > 1 ? [stepNumber - 1] : [],
            estimatedMs: 1500,
            requiresApproval: config.safeMode && tool.isDangerous,
            riskLevel: tool.isDangerous ? "high" : "low",
          })

          totalEstimatedMs += 1500
          stepNumber++
        }
      }
    }

    // Final fallback: create analysis step
    if (steps.length === 0) {
      const primarySwarm = swarmRegistry.listActiveSwarms()[0]
      if (primarySwarm) {
        steps.push({
          stepNumber: 1,
          agentKey: primarySwarm.key,
          agentName: primarySwarm.name,
          toolId: "analyze_and_plan",
          toolName: "Analyze & Plan",
          action: "Analyze goal and create execution strategy",
          params: { goal, context, domain },
          dependsOn: [],
          estimatedMs: 2000,
          requiresApproval: false,
          riskLevel: "low",
        })
        totalEstimatedMs = 2000
      }
    }

    return {
      planId: `plan_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      steps,
      estimatedDuration: totalEstimatedMs,
      riskLevel: highestRisk,
      requiredApprovals,
    }
  }
}

export const antigravityPlanner = new AntigravityPlanner()
