import type { SwarmAgent, SwarmType } from "../patches/types"
import { STATIC_SWARMS } from "./static-swarms"

class SwarmRegistry {
  private swarms: SwarmAgent[] = STATIC_SWARMS

  get(key: string): SwarmAgent | undefined {
    return this.swarms.find((s) => s.key === key || s.id === key)
  }

  getByKey(key: string): SwarmAgent | undefined {
    return this.get(key)
  }

  getSwarm(key: string): SwarmAgent | undefined {
    return this.get(key)
  }

  getSwarmByKey(key: string): SwarmAgent | undefined {
    return this.get(key)
  }

  getSwarmAgent(key: string): SwarmAgent | undefined {
    return this.get(key)
  }

  list(): SwarmAgent[] {
    return this.swarms
  }

  listSwarms(): SwarmAgent[] {
    return this.list()
  }

  listSwarmAgents(): SwarmAgent[] {
    return this.list()
  }

  listSwarmsByType(type: SwarmType): SwarmAgent[] {
    return this.getSwarmsByType(type)
  }

  listActiveSwarms(): SwarmAgent[] {
    return this.swarms.filter((s) => s.isActive)
  }

  getSwarmsByType(type: SwarmType): SwarmAgent[] {
    return this.swarms.filter((s) => s.swarmType === type)
  }

  getSwarmsByPatchAffinity(patchKey: string): SwarmAgent[] {
    return this.swarms.filter((s) => s.patchAffinity?.includes(patchKey))
  }

  getSwarmsByCapability(capability: string): SwarmAgent[] {
    return this.swarms.filter((s) => s.capabilities.includes(capability))
  }

  getSwarmsByDomain(domain: string): SwarmAgent[] {
    return this.swarms.filter((s) => s.domain === domain)
  }
}

export const swarmRegistry = new SwarmRegistry()
