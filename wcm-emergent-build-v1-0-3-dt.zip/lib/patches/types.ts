export type PatchStatus = "online" | "degraded" | "offline" | "coming_soon"

export type SwarmType = "content" | "tax" | "trust" | "entity" | "triad" | "system" | "health" | "other"

export interface PatchModule {
  id: string
  key: string
  slug: string
  displayName: string
  description: string
  status: PatchStatus
  category: string
  appBaseUrl: string
  docsUrl?: string
  requiresAuth: boolean
  capabilities: string[]
  icon?: string
  primaryColor?: string
  createdAt: Date
  updatedAt: Date
  embedded?: EmbeddedPatch
}

export interface EmbeddedPatch {
  moduleKey: string
  hasRoutes: boolean
  hasDatabase: boolean
  hasAPI: boolean
  basePath: string // e.g. "/chaos-os", "/neura-tax"
}

export interface SwarmAgent {
  id: string
  key: string
  name: string
  role: string
  description: string
  capabilities: string[]
  patchAffinity?: string[]
  avatarKey?: string
  swarmType: SwarmType
  isActive: boolean
}

export interface Avatar {
  key: string
  displayName: string
  persona: string
  colorProfile: string[]
  swarmKey?: string
  videoProfileKey?: string
}

export interface VideoProfile {
  key: string
  provider: "sora" | "kling" | "custom" | "other"
  modelHint?: string
  aspectRatio: string
  defaultDurationSec: number
  voicePreset?: string
  notes?: string
}

// Legacy Agent type for backwards compatibility
export interface Agent {
  id: string
  name: string
  role: string
  description: string
  capabilities: string[]
  swarmKey: string
  mcpToolPrefs: string[]
  isActive: boolean
}

export interface McpServer {
  id: string
  name: string
  baseUrl: string
  manifestUrl: string
  status: "online" | "offline" | "unknown"
  categories: string[]
  lastCheckedAt?: Date
}

export interface McpTool {
  id: string
  serverId: string
  name: string
  description: string
  category: string
  inputSchema: Record<string, unknown>
  outputSchema: Record<string, unknown>
  isDangerous: boolean
  requiresApproval: boolean
}

export interface PlanStep {
  stepNumber: number
  agentId: string
  toolId: string
  params: Record<string, unknown>
}

export interface ExecutionResult {
  stepNumber: number
  success: boolean
  output: Record<string, unknown> | null
  error: string | null
  latencyMs: number
}
