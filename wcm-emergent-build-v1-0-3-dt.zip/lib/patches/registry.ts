import { STATIC_PATCHES } from "./static-patches"
import type { PatchModule } from "./types"

class PatchRegistry {
  private patches: PatchModule[] = STATIC_PATCHES

  get(key: string): PatchModule | undefined {
    return this.patches.find((p) => p.key === key)
  }

  getByKey(key: string): PatchModule | undefined {
    return this.get(key)
  }

  getPatch(key: string): PatchModule | undefined {
    return this.get(key)
  }

  getPatchByKey(key: string): PatchModule | undefined {
    return this.get(key)
  }

  list(): PatchModule[] {
    return this.patches
  }

  listPatches(): PatchModule[] {
    return this.list()
  }

  listPatchesByCategory(category: string): PatchModule[] {
    return this.listByCategory(category)
  }

  getPatchBySlug(slug: string): PatchModule | undefined {
    return this.patches.find((p) => p.slug === slug)
  }

  listByCategory(category: string): PatchModule[] {
    return this.patches.filter((p) => p.category === category)
  }

  listByStatus(status: PatchModule["status"]): PatchModule[] {
    return this.patches.filter((p) => p.status === status)
  }

  getCategories(): string[] {
    return [...new Set(this.patches.map((p) => p.category))]
  }

  getAllCapabilities(): string[] {
    const caps = this.patches.flatMap((p) => p.capabilities)
    return [...new Set(caps)]
  }
}

export const patchRegistry = new PatchRegistry()
