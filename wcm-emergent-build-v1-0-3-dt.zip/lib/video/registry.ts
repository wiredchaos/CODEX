import type { VideoProfile } from "../patches/types"
import { STATIC_VIDEO_PROFILES } from "./static-video-profiles"

class VideoRegistry {
  private profiles: VideoProfile[] = STATIC_VIDEO_PROFILES

  get(key: string): VideoProfile | undefined {
    return this.profiles.find((p) => p.key === key)
  }

  getByKey(key: string): VideoProfile | undefined {
    return this.get(key)
  }

  getVideoProfile(key: string): VideoProfile | undefined {
    return this.get(key)
  }

  getVideoProfileByKey(key: string): VideoProfile | undefined {
    return this.get(key)
  }

  list(): VideoProfile[] {
    return this.profiles
  }

  listVideoProfiles(): VideoProfile[] {
    return this.list()
  }

  getProfilesByProvider(provider: VideoProfile["provider"]): VideoProfile[] {
    return this.profiles.filter((p) => p.provider === provider)
  }

  listByProvider(provider: VideoProfile["provider"]): VideoProfile[] {
    return this.getProfilesByProvider(provider)
  }

  getByAvatar(avatarKey: string): VideoProfile | undefined {
    return this.profiles.find((p) => p.avatarKey === avatarKey)
  }
}

export const videoRegistry = new VideoRegistry()
