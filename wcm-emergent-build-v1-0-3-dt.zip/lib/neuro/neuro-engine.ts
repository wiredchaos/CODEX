import type { NeuroState, InteractionEvent } from "./types"
import { DetectionEngine } from "./detection-engine"
import { AvatarSelector } from "./avatar-selector"

export class NeuroEngine {
  private static state: NeuroState | null = null

  // Initialize NEURO on first interaction
  static initialize(): NeuroState {
    const context = DetectionEngine.detectContext()
    const signals = DetectionEngine.initBehavioralTracking()
    const profile = AvatarSelector.selectAvatarForm(context, signals)

    this.state = {
      currentForm: profile.avatarForm,
      currentMode: profile.personalityMode,
      profile,
      context,
      behavioralSignals: signals,
      lastUpdate: new Date(),
    }

    // Mark user as visited
    if (typeof window !== "undefined") {
      localStorage.setItem("neuro_visited", "true")
    }

    return this.state
  }

  static update(event: "click" | "keypress" | "scroll" | "error" | "help" | "complete" | "erase"): NeuroState | null {
    if (!this.state) return null

    const signals = DetectionEngine.updateBehavioralSignals(this.state.behavioralSignals, event)
    const profile = AvatarSelector.selectAvatarForm(this.state.context, signals)

    // Adapt personality mode based on frustration level
    let adaptedMode = profile.personalityMode
    if (signals.frustrationLevel > 60) {
      adaptedMode = "comfort"
    } else if (signals.frustrationLevel < 20 && signals.taskCompletionRate > 3) {
      adaptedMode = "architect"
    }

    this.state = {
      ...this.state,
      currentForm: profile.avatarForm,
      currentMode: adaptedMode,
      profile: { ...profile, personalityMode: adaptedMode },
      behavioralSignals: signals,
      lastUpdate: new Date(),
    }

    return this.state
  }

  static registerEvent(event: InteractionEvent): NeuroState | null {
    if (!this.state) return null

    const signals = DetectionEngine.processInteractionEvent(this.state.behavioralSignals, event)
    const profile = AvatarSelector.selectAvatarForm(this.state.context, signals)

    // Adapt personality mode based on event type
    let adaptedMode = profile.personalityMode
    if (event.type === "OVERWHELMED" || event.type === "HELP_REQUEST") {
      adaptedMode = "comfort"
    } else if (event.type === "ADVANCED_SELF_IDENTIFY") {
      adaptedMode = "architect"
    } else if (signals.frustrationLevel > 60) {
      adaptedMode = "comfort"
    }

    this.state = {
      ...this.state,
      currentForm: profile.avatarForm,
      currentMode: adaptedMode,
      profile: { ...profile, personalityMode: adaptedMode },
      behavioralSignals: signals,
      lastUpdate: new Date(),
    }

    return this.state
  }

  // Get current NEURO state
  static getState(): NeuroState | null {
    return this.state
  }

  // Reset NEURO (for testing or new session)
  static reset(): void {
    this.state = null
    if (typeof window !== "undefined") {
      localStorage.removeItem("neuro_visited")
    }
  }
}
