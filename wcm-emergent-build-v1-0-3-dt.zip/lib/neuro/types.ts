export type AvatarForm = "human" | "digital" | "guardian" | "sovereign" | "hybrid"
export type PersonalityMode = "comfort" | "instructor" | "architect" | "guide"
export type GenerationalProfile = "boomer" | "genx" | "millennial" | "genz" | "genalpha"
export type NeurodivergentProfile = "neurotypical" | "adhd" | "asd" | "dyslexic" | "processing" | "unknown"

export type InteractionEventType =
  | "KEY_HESITATION"
  | "KEY_ERASE_LOOP"
  | "FAST_TYPING"
  | "RAPID_CLICKING"
  | "NO_CLICK"
  | "HELP_REQUEST"
  | "COMPLETED_STEP"
  | "OVERWHELMED"
  | "ADVANCED_SELF_IDENTIFY"

export interface InteractionEvent {
  type: InteractionEventType
  timestamp: number
}

export interface ContextDetection {
  entryPoint: string
  device: "mobile" | "tablet" | "desktop"
  timeOfDay: "morning" | "afternoon" | "evening" | "night"
  section: string
  isReturningUser: boolean
  sessionDuration: number
  interactionSpeed: "slow" | "moderate" | "fast"
  confidenceLevel: "novice" | "intermediate" | "expert"
  explorationStyle: "methodical" | "exploratory" | "goal-oriented"
}

export interface BehavioralSignals {
  clickPatterns: number[]
  keyboardSpeed: number
  scrollBehavior: "skimmer" | "reader" | "scanner"
  errorRecovery: "immediate" | "delayed" | "frustrated"
  helpSeekingBehavior: boolean
  taskCompletionRate: number
  frustrationLevel: number
  eraseCount: number
  lastKeyTime: number
}

export interface NeuroProfile {
  avatarForm: AvatarForm
  personalityMode: PersonalityMode
  generationalProfile: GenerationalProfile
  neurodivergentProfile: NeurodivergentProfile
  adaptationReason: string
  confidence: number
  frustrationLevel: number // Add frustrationLevel for Swarm routing
  currentAvatar?: AvatarForm // Add currentAvatar for Sora requests
  prefers: {
    video: boolean
    text: boolean
    audio: boolean
    simpleUi: boolean
  }
}

export interface NeuroState {
  currentForm: AvatarForm
  currentMode: PersonalityMode
  profile: NeuroProfile
  context: ContextDetection
  behavioralSignals: BehavioralSignals
  lastUpdate: Date
}

export type VideoIntent = "overview" | "explain_step" | "encourage" | "deep_dive" | "troubleshoot"

export interface NeuroVideoRequest {
  question: string
  profile: NeuroProfile
  intent: VideoIntent
  section?: string
}

export interface NeuroVideoResponse {
  text: string
  videoUrl?: string
  suggestedNextSteps?: string[]
  social?: {
    tweet?: string
    thread?: string[]
    caption?: string
  }
  agentsUsed?: string[]
  processingTime?: number
}
