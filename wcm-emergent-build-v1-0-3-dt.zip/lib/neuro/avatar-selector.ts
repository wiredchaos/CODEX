import type { AvatarForm, PersonalityMode, NeuroProfile, ContextDetection, BehavioralSignals } from "./types"
import { DetectionEngine } from "./detection-engine"

export class AvatarSelector {
  // Main intelligence: select optimal avatar form based on all inputs
  static selectAvatarForm(context: ContextDetection, signals: BehavioralSignals): NeuroProfile {
    const { section, device, timeOfDay, confidenceLevel } = context
    const generationalProfile = DetectionEngine.detectGenerationalProfile(signals)
    const neurodivergentProfile = DetectionEngine.detectNeurodivergentProfile(signals)

    // Section-based avatar selection
    let avatarForm: AvatarForm = "human"
    let personalityMode: PersonalityMode = "guide"
    let reason = ""

    // CHAOS OS, Antigravity, Vision → Digital hologram
    if (["chaos-os", "technical", "vision"].includes(section)) {
      avatarForm = "digital"
      personalityMode = "architect"
      reason = "Technical environment detected → Digital NEURO hologram"
    }

    // Trust, Entity, FEN → Guardian (Cane Corso)
    else if (["trust", "entity", "vault"].includes(section)) {
      avatarForm = "guardian"
      personalityMode = "comfort"
      reason = "Security/trust context → Guardian NEURO (Cane Corso)"
    }

    // Creative sections → Sovereign (Oyalán Shàkó)
    else if (["creative", "akira"].includes(section)) {
      avatarForm = "sovereign"
      personalityMode = "instructor"
      reason = "Creative environment → Sovereign NEURO (Oyalán Shàkó)"
    }

    // Hub, learning, general → Human NEURO
    else {
      avatarForm = "human"
      personalityMode = "guide"
      reason = "Learning environment → Human NEURO mentor"
    }

    // Override based on confidence level
    if (confidenceLevel === "novice") {
      personalityMode = "comfort"
      reason += " | Novice detected → Comfort mode"
    } else if (confidenceLevel === "expert") {
      personalityMode = "architect"
      reason += " | Expert detected → Architect mode"
    }

    // Mobile device → Prefer simpler forms
    if (device === "mobile") {
      if (avatarForm === "hybrid") {
        avatarForm = "human"
        reason += " | Mobile → Simplified to Human"
      }
    }

    // Night time → More calming presence
    if (timeOfDay === "night") {
      if (personalityMode === "architect") {
        personalityMode = "instructor"
        reason += " | Night → Calmer instructor mode"
      }
    }

    // Neurodivergent adaptations
    if (neurodivergentProfile === "adhd") {
      personalityMode = "instructor"
      reason += " | ADHD patterns → Clear, structured instructor"
    } else if (neurodivergentProfile === "asd") {
      personalityMode = "guide"
      reason += " | ASD patterns → Consistent, pattern-based guide"
    }

    const prefers = this.determinePreferences(personalityMode, neurodivergentProfile, generationalProfile, signals)

    return {
      avatarForm,
      personalityMode,
      generationalProfile,
      neurodivergentProfile,
      adaptationReason: reason,
      confidence: this.calculateConfidence(context, signals),
      prefers,
    }
  }

  private static determinePreferences(
    mode: PersonalityMode,
    nd: string,
    gen: string,
    signals: BehavioralSignals,
  ): NeuroProfile["prefers"] {
    const prefers = {
      video: true,
      text: true,
      audio: false,
      simpleUi: false,
    }

    // Comfort mode or high frustration → simple UI
    if (mode === "comfort" || signals.frustrationLevel > 50) {
      prefers.simpleUi = true
    }

    // Dyslexic or processing → prefer video/audio
    if (nd === "dyslexic" || nd === "processing") {
      prefers.video = true
      prefers.audio = true
      prefers.simpleUi = true
    }

    // Gen Alpha/Z → video preferred
    if (gen === "genalpha" || gen === "genz") {
      prefers.video = true
    }

    // Boomer → text preferred, simpler UI
    if (gen === "boomer") {
      prefers.text = true
      prefers.simpleUi = true
    }

    return prefers
  }

  private static calculateConfidence(context: ContextDetection, signals: BehavioralSignals): number {
    let confidence = 50

    // More interactions = higher confidence
    confidence += Math.min(signals.clickPatterns.length * 2, 30)

    // Returning user = higher confidence
    if (context.isReturningUser) confidence += 20

    return Math.min(confidence, 100)
  }

  // Get personality tone adjustments
  static getPersonalityAdjustments(mode: PersonalityMode, generational: string, nd: string) {
    const base = {
      comfort: { tone: "warm", pace: "slow", detail: "high" },
      instructor: { tone: "clear", pace: "moderate", detail: "structured" },
      architect: { tone: "technical", pace: "fast", detail: "precise" },
      guide: { tone: "friendly", pace: "adaptive", detail: "balanced" },
    }

    const adjustments = base[mode]

    // Generational tweaks
    if (generational === "genalpha" || generational === "genz") {
      adjustments.pace = "fast"
      adjustments.detail = "concise"
    } else if (generational === "boomer") {
      adjustments.pace = "slow"
      adjustments.detail = "thorough"
    }

    // Neurodivergent tweaks
    if (nd === "adhd") {
      adjustments.detail = "chunked"
    } else if (nd === "asd") {
      adjustments.tone = "literal"
    } else if (nd === "dyslexic") {
      adjustments.detail = "visual"
    }

    return adjustments
  }
}
