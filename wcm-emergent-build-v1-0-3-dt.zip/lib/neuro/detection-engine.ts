import type {
  ContextDetection,
  BehavioralSignals,
  GenerationalProfile,
  NeurodivergentProfile,
  InteractionEvent,
} from "./types"

export class DetectionEngine {
  // Detect context from user's entry and environment
  static detectContext(): ContextDetection {
    const path = typeof window !== "undefined" ? window.location.pathname : "/"
    const userAgent = typeof navigator !== "undefined" ? navigator.userAgent : ""

    return {
      entryPoint: path,
      device: this.detectDevice(userAgent),
      timeOfDay: this.detectTimeOfDay(),
      section: this.detectSection(path),
      isReturningUser: this.checkReturningUser(),
      sessionDuration: 0,
      interactionSpeed: "moderate",
      confidenceLevel: "novice",
      explorationStyle: "exploratory",
    }
  }

  private static detectDevice(userAgent: string): "mobile" | "tablet" | "desktop" {
    if (/mobile|android|iphone/i.test(userAgent)) return "mobile"
    if (/tablet|ipad/i.test(userAgent)) return "tablet"
    return "desktop"
  }

  private static detectTimeOfDay(): "morning" | "afternoon" | "evening" | "night" {
    const hour = new Date().getHours()
    if (hour < 6) return "night"
    if (hour < 12) return "morning"
    if (hour < 18) return "afternoon"
    if (hour < 22) return "evening"
    return "night"
  }

  private static detectSection(path: string): string {
    if (path.includes("chaos-os")) return "chaos-os"
    if (path.includes("trust")) return "trust"
    if (path.includes("tax")) return "tax"
    if (path.includes("akira")) return "creative"
    if (path.includes("antigravity")) return "technical"
    if (path.includes("vision")) return "vision"
    if (path.includes("neuro")) return "neuro"
    return "hub"
  }

  private static checkReturningUser(): boolean {
    if (typeof window === "undefined") return false
    return localStorage.getItem("neuro_visited") === "true"
  }

  // Analyze behavioral patterns to detect generational profile
  static detectGenerationalProfile(signals: BehavioralSignals): GenerationalProfile {
    const { clickPatterns, scrollBehavior, keyboardSpeed } = signals
    const interactionSpeed = keyboardSpeed > 80 ? "fast" : keyboardSpeed < 40 ? "slow" : "moderate"

    // Fast, exploratory, multi-tab → Gen Z/Alpha
    if (scrollBehavior === "skimmer" && interactionSpeed === "fast") {
      return clickPatterns.length > 20 ? "genalpha" : "genz"
    }

    // Methodical, slower, reads carefully → Boomer/Gen X
    if (scrollBehavior === "reader" && interactionSpeed === "slow") {
      return clickPatterns.length < 10 ? "boomer" : "genx"
    }

    // Balanced scanner → Millennial
    return "millennial"
  }

  // Detect neurodivergent patterns from behavior
  static detectNeurodivergentProfile(signals: BehavioralSignals): NeurodivergentProfile {
    const { clickPatterns, errorRecovery, helpSeekingBehavior, keyboardSpeed } = signals

    // Rapid clicking, quick task switching, impulsive → ADHD
    if (clickPatterns.length > 30 && errorRecovery === "immediate" && keyboardSpeed > 100) {
      return "adhd"
    }

    // Methodical, pattern-seeking, detail-oriented → ASD
    if (errorRecovery === "delayed" && !helpSeekingBehavior && keyboardSpeed < 50) {
      return "asd"
    }

    // Struggles with text, rereads, uses visual aids → Dyslexic
    if (helpSeekingBehavior && errorRecovery === "frustrated") {
      return "dyslexic"
    }

    // Slow, careful, needs processing time → Processing
    if (keyboardSpeed < 30 && errorRecovery === "delayed") {
      return "processing"
    }

    return "unknown"
  }

  static initBehavioralTracking(): BehavioralSignals {
    return {
      clickPatterns: [],
      keyboardSpeed: 0,
      scrollBehavior: "scanner",
      errorRecovery: "immediate",
      helpSeekingBehavior: false,
      taskCompletionRate: 0,
      frustrationLevel: 0,
      eraseCount: 0,
      lastKeyTime: Date.now(),
    }
  }

  static updateBehavioralSignals(
    signals: BehavioralSignals,
    event: "click" | "keypress" | "scroll" | "error" | "help" | "complete" | "erase",
  ): BehavioralSignals {
    const updated = { ...signals }
    const now = Date.now()

    switch (event) {
      case "click":
        updated.clickPatterns.push(now)
        // Trim old clicks (keep last 60 seconds)
        updated.clickPatterns = updated.clickPatterns.filter((t) => now - t < 60000)
        break
      case "keypress":
        // Calculate typing speed
        if (updated.lastKeyTime) {
          const gap = now - updated.lastKeyTime
          if (gap < 5000) {
            updated.keyboardSpeed = Math.round(60000 / gap) // WPM approximation
          }
        }
        updated.lastKeyTime = now
        updated.eraseCount = 0 // Reset erase count on normal typing
        break
      case "erase":
        updated.eraseCount += 1
        if (updated.eraseCount > 8) {
          updated.frustrationLevel = Math.min(100, updated.frustrationLevel + 20)
          updated.errorRecovery = "frustrated"
        }
        break
      case "help":
        updated.helpSeekingBehavior = true
        updated.frustrationLevel = Math.min(100, updated.frustrationLevel + 5)
        break
      case "complete":
        updated.taskCompletionRate += 1
        updated.frustrationLevel = Math.max(0, updated.frustrationLevel - 15)
        break
      case "error":
        updated.frustrationLevel = Math.min(100, updated.frustrationLevel + 10)
        break
    }

    return updated
  }

  static processInteractionEvent(signals: BehavioralSignals, event: InteractionEvent): BehavioralSignals {
    const updated = { ...signals }

    switch (event.type) {
      case "KEY_HESITATION":
      case "NO_CLICK":
        updated.frustrationLevel = Math.min(100, updated.frustrationLevel + 10)
        break
      case "KEY_ERASE_LOOP":
        updated.frustrationLevel = Math.min(100, updated.frustrationLevel + 20)
        updated.errorRecovery = "frustrated"
        break
      case "FAST_TYPING":
      case "RAPID_CLICKING":
        updated.frustrationLevel = Math.max(0, updated.frustrationLevel - 10)
        break
      case "HELP_REQUEST":
      case "OVERWHELMED":
        updated.frustrationLevel = Math.min(100, updated.frustrationLevel + 5)
        updated.helpSeekingBehavior = true
        break
      case "COMPLETED_STEP":
        updated.frustrationLevel = Math.max(0, updated.frustrationLevel - 15)
        updated.taskCompletionRate += 1
        break
      case "ADVANCED_SELF_IDENTIFY":
        updated.frustrationLevel = 0
        break
    }

    return updated
  }
}
