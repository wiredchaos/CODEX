import type { VisionRequest, VisionResult, BlueprintOutput, VisionMode } from "./types"

// In-memory store for vision requests (would be DB in production)
const visionStore = new Map<string, VisionRequest>()

export function generateRequestId(): string {
  return `vis_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`
}

export function createVisionRequest(
  prompt: string,
  mode: VisionMode = "blueprint",
  persona?: string,
  imageUrl?: string,
): VisionRequest {
  const request: VisionRequest = {
    id: generateRequestId(),
    prompt,
    mode,
    persona,
    imageUrl,
    createdAt: new Date(),
    status: "pending",
  }
  visionStore.set(request.id, request)
  return request
}

export function getVisionRequest(id: string): VisionRequest | undefined {
  return visionStore.get(id)
}

export function updateVisionRequest(id: string, updates: Partial<VisionRequest>): VisionRequest | undefined {
  const request = visionStore.get(id)
  if (!request) return undefined
  const updated = { ...request, ...updates }
  visionStore.set(id, updated)
  return updated
}

export async function processVisionRequest(request: VisionRequest): Promise<VisionResult> {
  // Update status to processing
  updateVisionRequest(request.id, { status: "processing" })

  try {
    let result: VisionResult

    switch (request.mode) {
      case "blueprint":
        result = { blueprint: await generateBlueprint(request.prompt) }
        break
      case "ttv_prep":
        result = {
          blueprint: await generateBlueprint(request.prompt),
          analysis: {
            description: `TTV preparation for: ${request.prompt}`,
            objects: [],
            colors: ["#00FFFF", "#FF3131", "#39FF14"],
            style: "cinematic",
            mood: "dramatic",
          },
        }
        break
      case "full":
      default:
        result = {
          analysis: {
            description: `Full analysis of: ${request.prompt}`,
            objects: [],
            colors: ["#00FFFF", "#FF00FF", "#39FF14"],
            style: "modern",
            mood: "energetic",
          },
        }
    }

    updateVisionRequest(request.id, { status: "completed", result })
    return result
  } catch (error) {
    const errorResult: VisionResult = {
      error: error instanceof Error ? error.message : "Unknown error",
    }
    updateVisionRequest(request.id, { status: "failed", result: errorResult })
    return errorResult
  }
}

async function generateBlueprint(prompt: string): Promise<BlueprintOutput> {
  // Blueprint Mode: Generate structured layout without TTV
  return {
    layout: "flex-column",
    components: ["Header", "Hero", "Features", "CTA", "Footer"],
    colorScheme: ["#00FFFF", "#0A0A0A", "#1A1A2E", "#FF3131"],
    typography: {
      heading: "Space Grotesk",
      body: "Inter",
    },
    structure: [
      {
        id: "root",
        type: "container",
        name: "Page",
        children: [
          { id: "header", type: "section", name: "Header" },
          { id: "hero", type: "section", name: "Hero" },
          {
            id: "features",
            type: "section",
            name: "Features",
            children: [
              { id: "feat-1", type: "component", name: "FeatureCard" },
              { id: "feat-2", type: "component", name: "FeatureCard" },
              { id: "feat-3", type: "component", name: "FeatureCard" },
            ],
          },
          { id: "cta", type: "section", name: "CTA" },
          { id: "footer", type: "section", name: "Footer" },
        ],
      },
    ],
  }
}

export function listVisionRequests(): VisionRequest[] {
  return Array.from(visionStore.values()).sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
}
