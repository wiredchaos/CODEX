export type VisionMode = "blueprint" | "full" | "ttv_prep"
export type VisionStatus = "pending" | "processing" | "completed" | "failed"

export interface VisionRequest {
  id: string
  prompt: string
  mode: VisionMode
  persona?: string
  imageUrl?: string
  createdAt: Date
  status: VisionStatus
  result?: VisionResult
}

export interface VisionResult {
  blueprint?: BlueprintOutput
  analysis?: ImageAnalysis
  generation?: GeneratedScene
  error?: string
}

export interface BlueprintOutput {
  layout: string
  components: string[]
  colorScheme: string[]
  typography: {
    heading: string
    body: string
  }
  structure: LayoutNode[]
}

export interface LayoutNode {
  id: string
  type: "section" | "container" | "component" | "text" | "image"
  name: string
  children?: LayoutNode[]
  props?: Record<string, unknown>
}

export interface ImageAnalysis {
  description: string
  objects: DetectedObject[]
  colors: string[]
  style: string
  mood: string
}

export interface DetectedObject {
  label: string
  confidence: number
  boundingBox?: {
    x: number
    y: number
    width: number
    height: number
  }
}

export interface GeneratedScene {
  imageUrl: string
  prompt: string
  seed: number
  model: string
}

export interface VisionPersona {
  key: string
  name: string
  systemPrompt: string
  capabilities: string[]
  defaultMode: VisionMode
}

export const VISION_PERSONAS: VisionPersona[] = [
  {
    key: "architect",
    name: "Architect",
    systemPrompt: "You are a UI/UX architect. Analyze designs and generate structured blueprints for implementation.",
    capabilities: ["blueprint_generation", "layout_analysis", "component_mapping"],
    defaultMode: "blueprint",
  },
  {
    key: "artist",
    name: "Artist",
    systemPrompt: "You are a creative artist. Generate vivid scene descriptions and visual concepts.",
    capabilities: ["scene_generation", "style_transfer", "mood_analysis"],
    defaultMode: "full",
  },
  {
    key: "analyst",
    name: "Analyst",
    systemPrompt: "You are a visual analyst. Extract detailed information from images and documents.",
    capabilities: ["object_detection", "text_extraction", "data_analysis"],
    defaultMode: "full",
  },
  {
    key: "director",
    name: "Director",
    systemPrompt: "You are a video director. Plan shots, scenes, and storyboards for TTV production.",
    capabilities: ["storyboard_generation", "shot_planning", "ttv_prep"],
    defaultMode: "ttv_prep",
  },
]
