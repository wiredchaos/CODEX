import type { TrinityMount, Timeline } from "./types"
import { TRINITY_FLOORS, TIMELINES } from "./static-floors"

export class TrinityMountRegistry {
  private mounts: Map<string, TrinityMount> = new Map()

  // Mount a patch to Trinity infrastructure (declarative, read-only)
  mountPatch(patchKey: string, floorId: string, timelineKeys: string[]): TrinityMount {
    const floor = TRINITY_FLOORS.find((f) => f.id === floorId)
    if (!floor) {
      throw new Error(`Trinity Floor not found: ${floorId}`)
    }

    // Verify all timeline keys belong to the floor
    const invalidTimelines = timelineKeys.filter((tk) => !floor.timelineKeys.includes(tk))
    if (invalidTimelines.length > 0) {
      throw new Error(`Invalid timelines for floor ${floorId}: ${invalidTimelines.join(", ")}`)
    }

    const mount: TrinityMount = {
      patchKey,
      assignedFloor: floorId,
      assignedTimelines: timelineKeys,
      mountedAt: new Date(),
      accessGrantedBy: "AKIRA_CODEX",
    }

    this.mounts.set(patchKey, mount)
    return mount
  }

  getMountByPatch(patchKey: string): TrinityMount | null {
    return this.mounts.get(patchKey) || null
  }

  listAllMounts(): TrinityMount[] {
    return Array.from(this.mounts.values())
  }

  // Get accessible timelines for a mounted patch
  getAccessibleTimelines(patchKey: string): Timeline[] {
    const mount = this.getMountByPatch(patchKey)
    if (!mount) return []

    return TIMELINES.filter((t) => mount.assignedTimelines.includes(t.key))
  }

  // Check if patch has access to specific timeline
  hasTimelineAccess(patchKey: string, timelineKey: string): boolean {
    const mount = this.getMountByPatch(patchKey)
    if (!mount) return false

    return mount.assignedTimelines.includes(timelineKey)
  }
}

export const trinityMountRegistry = new TrinityMountRegistry()

// Example: Mount patches to Trinity floors
trinityMountRegistry.mountPatch("AKIRA_CODEX", "floor_genesis", ["timeline_origin", "timeline_foundation"])
trinityMountRegistry.mountPatch("FEN_TRIAD", "floor_sovereign", ["timeline_triad", "timeline_589"])
trinityMountRegistry.mountPatch("CHAOS_BUILD", "floor_architect", ["timeline_build", "timeline_structure"])
