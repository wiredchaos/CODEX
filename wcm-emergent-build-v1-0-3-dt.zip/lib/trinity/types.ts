export type TrinityAccessLevel = "read_only" | "timeline_viewer" | "floor_observer"

export interface TrinityFloor {
  id: string
  name: string
  level: number
  timelineKeys: string[]
  description: string
  governedBy: "AKIRA_CODEX"
  accessLevel: TrinityAccessLevel
}

export interface Timeline {
  key: string
  displayName: string
  floorId: string
  akiraCodexAuthorization: boolean
  sceneUrl: string // Read-only 3D scene endpoint
  metadata: {
    era?: string
    theme?: string
    nodes?: number
    readonly: true
  }
}

export interface TrinityMount {
  patchKey: string
  assignedFloor: string
  assignedTimelines: string[]
  mountedAt: Date
  accessGrantedBy: "AKIRA_CODEX"
}

export interface TrinityConsumerSession {
  sessionId: string
  patchKey: string
  floorId: string
  timelineKey: string
  viewMode: "observer" | "navigator"
  connectedAt: Date
  readonly: true
  sceneUrl?: string // Added sceneUrl for video/3D fallback
}
