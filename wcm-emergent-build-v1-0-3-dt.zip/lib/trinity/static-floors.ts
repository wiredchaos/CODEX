import type { TrinityFloor, Timeline } from "./types"

export const TRINITY_FLOORS: TrinityFloor[] = [
  {
    id: "floor_genesis",
    name: "Genesis Floor",
    level: 0,
    timelineKeys: ["timeline_origin", "timeline_foundation"],
    description: "Foundation layer of WIRED CHAOS Trinity infrastructure. Origin timelines and core narratives.",
    governedBy: "AKIRA_CODEX",
    accessLevel: "read_only",
  },
  {
    id: "floor_architect",
    name: "Architect Floor",
    level: 1,
    timelineKeys: ["timeline_build", "timeline_structure"],
    description: "Structural timelines for system architecture and build progression.",
    governedBy: "AKIRA_CODEX",
    accessLevel: "timeline_viewer",
  },
  {
    id: "floor_sovereign",
    name: "Sovereign Floor",
    level: 2,
    timelineKeys: ["timeline_triad", "timeline_589"],
    description: "Advanced triad and 589 theory timelines. Elite access layer.",
    governedBy: "AKIRA_CODEX",
    accessLevel: "floor_observer",
  },
]

export const TIMELINES: Timeline[] = [
  {
    key: "timeline_origin",
    displayName: "Origin Timeline",
    floorId: "floor_genesis",
    akiraCodexAuthorization: true,
    sceneUrl: "/trinity-core/scenes/origin.glb",
    metadata: {
      era: "Foundation",
      theme: "Genesis narrative and first principles",
      nodes: 12,
      readonly: true,
    },
  },
  {
    key: "timeline_foundation",
    displayName: "Foundation Timeline",
    floorId: "floor_genesis",
    akiraCodexAuthorization: true,
    sceneUrl: "/trinity-core/scenes/foundation.glb",
    metadata: {
      era: "Foundation",
      theme: "Core infrastructure establishment",
      nodes: 8,
      readonly: true,
    },
  },
  {
    key: "timeline_build",
    displayName: "Build Timeline",
    floorId: "floor_architect",
    akiraCodexAuthorization: true,
    sceneUrl: "/trinity-core/scenes/build.glb",
    metadata: {
      era: "Construction",
      theme: "System architecture and development progression",
      nodes: 24,
      readonly: true,
    },
  },
  {
    key: "timeline_structure",
    displayName: "Structure Timeline",
    floorId: "floor_architect",
    akiraCodexAuthorization: true,
    sceneUrl: "/trinity-core/scenes/structure.glb",
    metadata: {
      era: "Construction",
      theme: "Organizational and system structure evolution",
      nodes: 16,
      readonly: true,
    },
  },
  {
    key: "timeline_triad",
    displayName: "Triad Timeline",
    floorId: "floor_sovereign",
    akiraCodexAuthorization: true,
    sceneUrl: "/trinity-core/scenes/triad.glb",
    metadata: {
      era: "Sovereign",
      theme: "Triad engine progression and artifact unlocks",
      nodes: 33,
      readonly: true,
    },
  },
  {
    key: "timeline_589",
    displayName: "589 Theory Timeline",
    floorId: "floor_sovereign",
    akiraCodexAuthorization: true,
    sceneUrl: "/trinity-core/scenes/589.glb",
    metadata: {
      era: "Sovereign",
      theme: "589 magazine theory and encoding system",
      nodes: 27,
      readonly: true,
    },
  },
]
