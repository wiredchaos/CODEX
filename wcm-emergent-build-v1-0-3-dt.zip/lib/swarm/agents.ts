// SWARM AGENT REGISTRY

import type { SwarmAgentConfig } from "./types"

export const SWARM_AGENTS: Record<string, SwarmAgentConfig> = {
  gemini: {
    id: "gemini",
    name: "Gemini Agent",
    description: "Research & Structure - Step-by-step breakdowns, comparisons, flowcharts, explanations for all levels",
    capabilities: [
      "step_by_step",
      "comparisons",
      "analogies",
      "checklists",
      "flowcharts",
      "web2_onboarding",
      "long_form",
      "explain_like_im",
    ],
    apiEndpoint: "/api/swarm/gemini",
    envKey: "GEMINI_API_KEY",
    isActive: true,
  },
  sora: {
    id: "sora",
    name: "Sora Agent",
    description: "Video Synthesis - Generates branded NEURO avatar videos, module intros, tutorials, emotional clips",
    capabilities: [
      "video_generation",
      "avatar_animation",
      "module_intros",
      "tutorial_clips",
      "emotional_reassurance",
      "storyboard_to_video",
    ],
    apiEndpoint: "/api/swarm/sora",
    envKey: "SORA_API_KEY",
    isActive: true,
  },
  grok: {
    id: "grok",
    name: "Grok Agent",
    description: "X Native / Social Layer - Tweets, threads, memes, hooks, CTAs optimized for social sharing",
    capabilities: [
      "tweet_generation",
      "thread_creation",
      "meme_variants",
      "hook_writing",
      "cta_optimization",
      "x_space_teasers",
    ],
    apiEndpoint: "/api/swarm/grok",
    envKey: "XAI_API_KEY",
    isActive: true,
  },
  codex: {
    id: "codex",
    name: "Codex Brain",
    description: "Core Domain Logic - WIRED CHAOS specific knowledge, lore, code, and system guidance",
    capabilities: [
      "domain_logic",
      "lore_knowledge",
      "code_generation",
      "system_guidance",
      "patch_specific",
      "technical_deep_dive",
    ],
    apiEndpoint: "/api/swarm/codex",
    envKey: "OPENAI_API_KEY",
    isActive: true,
  },
}

export function getActiveAgents(): SwarmAgentConfig[] {
  return Object.values(SWARM_AGENTS).filter((a) => a.isActive)
}

export function getAgentByCapability(capability: string): SwarmAgentConfig | undefined {
  return Object.values(SWARM_AGENTS).find((a) => a.capabilities.includes(capability) && a.isActive)
}
