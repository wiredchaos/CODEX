// SWARM ROUTER - Intelligent routing to Sora/Grok/Gemini/Codex

import type {
  SwarmRouteRequest,
  SwarmRouteDecision,
  SwarmAgentType,
  GeminiRequest,
  SoraRequest,
  GrokRequest,
  CodexRequest,
} from "./types"
import type { NeuroProfile } from "@/lib/neuro/types"

// Keywords that trigger specific agents
const INTENT_KEYWORDS = {
  video: ["show", "demo", "watch", "see", "visual", "video", "animate", "display"],
  social: ["tweet", "post", "share", "x", "twitter", "thread", "viral", "meme"],
  explain: ["explain", "what", "how", "why", "help", "understand", "confused", "learn", "teach"],
  code: ["code", "api", "build", "implement", "technical", "developer", "function", "endpoint"],
}

// Section to agent affinity
const SECTION_AFFINITY: Record<string, SwarmAgentType[]> = {
  hub: ["gemini", "codex"],
  "chaos-os": ["codex", "gemini"],
  "creator-codex": ["sora", "gemini", "grok"],
  "akira-codex": ["sora", "codex", "gemini"],
  "neura-tax": ["gemini", "codex"],
  "trust-launcher": ["gemini", "codex"],
  "entity-formation": ["gemini", "codex"],
  antigravity: ["codex", "gemini"],
  vision: ["sora", "codex"],
  swarms: ["codex", "gemini"],
  avatars: ["sora", "codex"],
  referral: ["grok", "gemini"],
}

export class SwarmRouter {
  // Analyze request and determine which agents to use
  static route(request: SwarmRouteRequest): SwarmRouteDecision {
    const { question, profile, section, intent } = request
    const questionLower = question.toLowerCase()

    // Start with empty decision
    let useGemini = false
    let useSora = false
    let useGrok = false
    let useCodex = false
    const reasoning: string[] = []
    const priority: SwarmAgentType[] = []

    // 1. Check explicit intent
    if (intent === "show") {
      useSora = true
      useGemini = true // Need script first
      reasoning.push("Explicit show intent -> Gemini for script, Sora for video")
    } else if (intent === "social") {
      useGrok = true
      useGemini = true // Need content first
      reasoning.push("Explicit social intent -> Gemini for content, Grok for social")
    } else if (intent === "explain") {
      useGemini = true
      reasoning.push("Explicit explain intent -> Gemini")
    }

    // 2. Keyword detection
    for (const [type, keywords] of Object.entries(INTENT_KEYWORDS)) {
      if (keywords.some((k) => questionLower.includes(k))) {
        switch (type) {
          case "video":
            useSora = true
            useGemini = true
            reasoning.push(`Video keywords detected -> Sora + Gemini`)
            break
          case "social":
            useGrok = true
            reasoning.push(`Social keywords detected -> Grok`)
            break
          case "explain":
            useGemini = true
            reasoning.push(`Explain keywords detected -> Gemini`)
            break
          case "code":
            useCodex = true
            reasoning.push(`Code keywords detected -> Codex`)
            break
        }
      }
    }

    // 3. Profile-based adjustments
    if (profile.personalityMode === "comfort" || profile.frustrationLevel > 50) {
      useGemini = true
      if (profile.frustrationLevel > 70) {
        useSora = true // Calming video for high frustration
        reasoning.push(`High frustration (${profile.frustrationLevel}) -> Add Sora for calming video`)
      }
      reasoning.push(`Comfort mode or elevated frustration -> Gemini for gentle explanation`)
    }

    if (profile.personalityMode === "architect") {
      useCodex = true
      reasoning.push(`Architect mode -> Codex for technical depth`)
    }

    // 4. Section affinity
    const sectionAgents = SECTION_AFFINITY[section] || SECTION_AFFINITY.hub
    if (!useGemini && !useSora && !useGrok && !useCodex) {
      // No agents selected yet, use section default
      const defaultAgent = sectionAgents[0]
      switch (defaultAgent) {
        case "gemini":
          useGemini = true
          break
        case "sora":
          useSora = true
          break
        case "grok":
          useGrok = true
          break
        case "codex":
          useCodex = true
          break
      }
      reasoning.push(`Section default for "${section}" -> ${defaultAgent}`)
    }

    // 5. Always have at least Gemini for base explanation
    if (!useGemini && !useCodex) {
      useGemini = true
      reasoning.push(`Fallback -> Gemini for base explanation`)
    }

    // Build priority order
    if (useGemini) priority.push("gemini")
    if (useSora) priority.push("sora")
    if (useGrok) priority.push("grok")
    if (useCodex) priority.push("codex")

    return {
      useGemini,
      useSora,
      useGrok,
      useCodex,
      reasoning: reasoning.join(" | "),
      priority,
    }
  }

  // Build Gemini request based on profile
  static buildGeminiRequest(request: SwarmRouteRequest, forVideo = false): GeminiRequest {
    const { question, profile, section } = request

    let outputFormat: GeminiRequest["outputFormat"] = "explanation"
    let complexity: GeminiRequest["complexity"] = "moderate"

    // Adjust based on profile
    if (profile.personalityMode === "comfort") {
      complexity = "simple"
      outputFormat = "explanation"
    } else if (profile.personalityMode === "architect") {
      complexity = "detailed"
      outputFormat = "flowchart"
    }

    // If generating for video, output script
    if (forVideo) {
      outputFormat = "script"
    }

    // Check for specific output requests
    const qLower = question.toLowerCase()
    if (qLower.includes("step") || qLower.includes("how to")) {
      outputFormat = "checklist"
    } else if (qLower.includes("compare") || qLower.includes("vs") || qLower.includes("difference")) {
      outputFormat = "comparison"
    }

    return {
      question,
      profile,
      section,
      outputFormat,
      complexity,
    }
  }

  // Build Sora request
  static buildSoraRequest(
    script: string,
    profile: NeuroProfile,
    section: string,
    avatarForm: SoraRequest["avatarForm"],
  ): SoraRequest {
    let style: SoraRequest["style"] = "instructor"
    let mood: SoraRequest["mood"] = "calm"
    let duration: SoraRequest["duration"] = 20

    // Adjust based on profile
    switch (profile.personalityMode) {
      case "comfort":
        style = "comfort"
        mood = "calm"
        duration = 30 // Longer, slower for comfort
        break
      case "instructor":
        style = "instructor"
        mood = "energetic"
        duration = 20
        break
      case "architect":
        style = "architect"
        mood = "serious"
        duration = 10 // Quick, dense
        break
      case "guide":
        style = "cinematic"
        mood = "playful"
        duration = 20
        break
    }

    // High frustration = calmer, longer
    if (profile.frustrationLevel > 60) {
      mood = "calm"
      duration = 30
    }

    return {
      script,
      style,
      avatarForm,
      duration,
      mood,
      section,
    }
  }

  // Build Grok request
  static buildGrokRequest(content: string, profile: NeuroProfile): GrokRequest {
    let format: GrokRequest["format"] = "tweet"
    let tone: GrokRequest["tone"] = "professional"
    let targetAudience: GrokRequest["targetAudience"] = "general"

    // Adjust based on profile
    if (profile.personalityMode === "architect") {
      tone = "binary"
      targetAudience = "developer"
      format = "thread"
    } else if (profile.personalityMode === "comfort") {
      tone = "educational"
      targetAudience = "web2"
    }

    // Gen Z/Alpha get meme tone
    if (profile.generationalProfile === "gen_z" || profile.generationalProfile === "gen_alpha") {
      tone = "meme"
    }

    return {
      content,
      format,
      tone,
      targetAudience,
      maxLength: format === "tweet" ? 280 : undefined,
    }
  }

  // Build Codex request
  static buildCodexRequest(request: SwarmRouteRequest): CodexRequest {
    const { question, profile, section } = request

    // Map section to domain
    const domainMap: Record<string, string> = {
      "chaos-os": "system",
      "creator-codex": "creative",
      "akira-codex": "creative",
      "neura-tax": "tax",
      "trust-launcher": "trust",
      "entity-formation": "entity",
      antigravity: "orchestration",
      vision: "ai",
      swarms: "agents",
    }

    const domain = domainMap[section] || "general"
    const includeCode = profile.personalityMode === "architect"
    const includeLore = section.includes("akira") || section.includes("fen") || section.includes("triad")

    return {
      question,
      domain,
      profile,
      includeCode,
      includeLore,
    }
  }
}
