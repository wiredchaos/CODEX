// SWARM ROUTER TYPES - Sora, Grok, Gemini integration

import type { NeuroProfile } from "@/lib/neuro/types"

// Agent Types
export type SwarmAgentType = "gemini" | "sora" | "grok" | "codex"

export interface SwarmAgentConfig {
  id: SwarmAgentType
  name: string
  description: string
  capabilities: string[]
  apiEndpoint: string
  envKey: string
  isActive: boolean
}

// Routing
export interface SwarmRouteRequest {
  question: string
  profile: NeuroProfile
  section: string
  intent?: "explain" | "show" | "social" | "auto"
  context?: Record<string, unknown>
}

export interface SwarmRouteDecision {
  useGemini: boolean
  useSora: boolean
  useGrok: boolean
  useCodex: boolean
  reasoning: string
  priority: SwarmAgentType[]
}

// Gemini Agent
export interface GeminiRequest {
  question: string
  profile: NeuroProfile
  section: string
  outputFormat: "explanation" | "script" | "checklist" | "comparison" | "flowchart"
  complexity: "simple" | "moderate" | "detailed"
}

export interface GeminiResponse {
  explanation: string
  script?: string
  steps?: string[]
  diagrams?: string[]
  analogies?: string[]
  nextQuestions?: string[]
}

// Sora Agent
export interface SoraRequest {
  script: string
  style: "comfort" | "instructor" | "architect" | "cinematic"
  avatarForm: "human" | "digital" | "guardian" | "sovereign"
  duration: 10 | 20 | 30 | 60
  mood: "calm" | "energetic" | "serious" | "playful"
  section: string
}

export interface SoraResponse {
  videoUrl: string
  thumbnailUrl?: string
  duration: number
  status: "pending" | "processing" | "complete" | "error"
  jobId?: string
}

// Grok Agent
export interface GrokRequest {
  content: string
  format: "tweet" | "thread" | "caption" | "hook" | "cta"
  tone: "meme" | "professional" | "binary" | "hype" | "educational"
  targetAudience: "web2" | "web3" | "general" | "developer"
  maxLength?: number
}

export interface GrokResponse {
  primary: string
  variants: string[]
  hashtags: string[]
  hooks: string[]
  threadParts?: string[]
}

// Codex Brain (main LLM)
export interface CodexRequest {
  question: string
  domain: string
  profile: NeuroProfile
  includeCode?: boolean
  includeLore?: boolean
}

export interface CodexResponse {
  answer: string
  codeSnippets?: { language: string; code: string }[]
  loreReferences?: string[]
  relatedTopics?: string[]
}

// Combined Swarm Response
export interface SwarmResponse {
  text: string
  videoUrl?: string
  social?: {
    tweet?: string
    thread?: string[]
    caption?: string
  }
  suggestedNextSteps: string[]
  agentsUsed: SwarmAgentType[]
  processingTime: number
}
