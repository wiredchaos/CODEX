import type { GameSession, DifficultyLevel } from "./types"

export const GAME_TEMPLATES = {
  // Tax Game
  tax_deduction_hunter: {
    type: "scenario" as const,
    title: "Deduction Hunter: Find All Write-Offs",
    generateSession: (difficulty: DifficultyLevel): Partial<GameSession> => ({
      type: "scenario",
      title: "Deduction Hunter: Find All Write-Offs",
      difficulty,
      timeLimit: difficulty === "beginner" ? 300 : difficulty === "intermediate" ? 180 : 120,
      maxScore: difficulty === "beginner" ? 100 : difficulty === "intermediate" ? 200 : 300,
      score: 0,
      completed: false,
      xpEarned: 0,
    }),
  },

  // Trust Game
  trust_architect: {
    type: "simulation" as const,
    title: "Trust Architect: Design the Perfect Structure",
    generateSession: (difficulty: DifficultyLevel): Partial<GameSession> => ({
      type: "simulation",
      title: "Trust Architect: Design the Perfect Structure",
      difficulty,
      timeLimit: difficulty === "beginner" ? 600 : difficulty === "intermediate" ? 480 : 360,
      maxScore: difficulty === "beginner" ? 150 : difficulty === "intermediate" ? 300 : 500,
      score: 0,
      completed: false,
      xpEarned: 0,
    }),
  },

  // Entity Game
  entity_builder: {
    type: "puzzle" as const,
    title: "Entity Builder: Stack Your Holdings",
    generateSession: (difficulty: DifficultyLevel): Partial<GameSession> => ({
      type: "puzzle",
      title: "Entity Builder: Stack Your Holdings",
      difficulty,
      timeLimit: difficulty === "beginner" ? 420 : difficulty === "intermediate" ? 300 : 240,
      maxScore: difficulty === "beginner" ? 120 : difficulty === "intermediate" ? 250 : 400,
      score: 0,
      completed: false,
      xpEarned: 0,
    }),
  },

  // Quiz Game
  rapid_fire_quiz: {
    type: "quiz" as const,
    title: "Rapid Fire: Test Your Knowledge",
    generateSession: (difficulty: DifficultyLevel): Partial<GameSession> => ({
      type: "quiz",
      title: "Rapid Fire: Test Your Knowledge",
      difficulty,
      timeLimit: 120,
      maxScore: difficulty === "beginner" ? 50 : difficulty === "intermediate" ? 100 : 200,
      score: 0,
      completed: false,
      xpEarned: 0,
    }),
  },

  // Challenge Game
  chaos_challenge: {
    type: "challenge" as const,
    title: "CHAOS Challenge: Navigate the System",
    generateSession: (difficulty: DifficultyLevel): Partial<GameSession> => ({
      type: "challenge",
      title: "CHAOS Challenge: Navigate the System",
      difficulty,
      maxScore: difficulty === "beginner" ? 100 : difficulty === "intermediate" ? 200 : 400,
      score: 0,
      completed: false,
      xpEarned: 0,
    }),
  },
}

export function createGameSession(gameKey: string, difficulty: DifficultyLevel): GameSession {
  const template = GAME_TEMPLATES[gameKey as keyof typeof GAME_TEMPLATES]
  if (!template) {
    throw new Error(`Game template not found: ${gameKey}`)
  }

  return {
    id: `game_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    ...template.generateSession(difficulty),
  } as GameSession
}
