import type { NPCSession, GeneralCommand, NPCRole, NPCMode, DifficultyLevel } from "./types"

export class GeneralCoordinator {
  private sessions: Map<string, NPCSession> = new Map()

  // Assess user profile and assign appropriate NPC role
  assessAndAssign(userId: string, userProfile: any): GeneralCommand {
    const expertise = userProfile.detectedExpertise || "beginner"
    const section = userProfile.currentSection || "dashboard"
    const preferredMode = userProfile.preferredLearningStyle || "balanced"

    // Determine best starting mode
    let mode: NPCMode = "education"
    let role: NPCRole = "educator"

    if (section.includes("chaos-os") || section.includes("antigravity")) {
      mode = "exploration"
      role = "guide"
    } else if (expertise === "advanced" || expertise === "expert") {
      mode = "game"
      role = "challenger"
    } else if (userProfile.ndOptimized) {
      mode = "labyrinth"
      role = "companion"
    }

    return {
      type: "assign_module",
      target: userId,
      payload: { mode, role, difficulty: expertise as DifficultyLevel },
      reason: `Assigned ${role} in ${mode} mode based on ${expertise} expertise level`,
    }
  }

  // Monitor progress and adapt difficulty
  evaluateProgress(session: NPCSession): GeneralCommand | null {
    const { progress, mode } = session
    const winRate = progress.gamesWon / Math.max(progress.modulesCompleted, 1)
    const xpRate = progress.totalXP / Math.max(progress.modulesCompleted, 1)

    // Too easy - level up
    if (winRate > 0.9 && xpRate > 500) {
      return {
        type: "adjust_difficulty",
        target: session.userId,
        payload: { increase: true, reason: "high_performance" },
        reason: "User excelling - increasing challenge",
      }
    }

    // Struggling - reduce difficulty
    if (winRate < 0.3 && session.history.length > 5) {
      return {
        type: "adjust_difficulty",
        target: session.userId,
        payload: { increase: false, reason: "struggling" },
        reason: "User needs support - reducing difficulty",
      }
    }

    // Milestone achieved - award badge
    if (progress.modulesCompleted % 5 === 0 && progress.modulesCompleted > 0) {
      return {
        type: "award_badge",
        target: session.userId,
        payload: { badge: `${mode}_mastery_${progress.modulesCompleted}` },
        reason: `Completed ${progress.modulesCompleted} modules`,
      }
    }

    return null
  }

  // Route user query to appropriate swarm
  routeToSwarm(query: string, session: NPCSession): { agent: string; context: any } {
    const queryLower = query.toLowerCase()

    // Education mode - use Gemini for structured learning
    if (session.mode === "education" || queryLower.includes("learn") || queryLower.includes("explain")) {
      return {
        agent: "gemini",
        context: {
          mode: "education",
          difficulty: session.personality.verbosity,
          currentModule: session.currentModule,
        },
      }
    }

    // Game mode - use Codex for creative challenges
    if (session.mode === "game" || queryLower.includes("play") || queryLower.includes("challenge")) {
      return {
        agent: "codex",
        context: {
          mode: "game",
          gameType: "challenge",
          difficulty: session.progress.level,
        },
      }
    }

    // Labyrinth - use combined swarm for complex navigation
    if (session.mode === "labyrinth" || queryLower.includes("explore") || queryLower.includes("path")) {
      return {
        agent: "executor", // Use full swarm orchestration
        context: {
          mode: "labyrinth",
          currentNode: session.currentLabyrinthNode,
          riskTolerance: session.personality.challenge,
        },
      }
    }

    // Default - use Grok for general interaction
    return {
      agent: "grok",
      context: { mode: "exploration", casual: true },
    }
  }
}

export const generalCoordinator = new GeneralCoordinator()
