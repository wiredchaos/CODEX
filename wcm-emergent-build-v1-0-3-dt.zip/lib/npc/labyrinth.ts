import type { LabyrinthNode } from "./types"

export const LABYRINTH_NODES: Record<string, LabyrinthNode> = {
  entrance: {
    id: "entrance",
    type: "decision",
    title: "The Gateway",
    description:
      "You stand before three glowing portals in the CHAOS motherboard. Each leads to a different domain of knowledge and challenge.",
    options: [
      {
        id: "path_tax",
        text: "Enter the Tax Citadel (Green Portal)",
        nextNodeId: "tax_citadel",
        risk: "safe",
      },
      {
        id: "path_trust",
        text: "Descend into the Trust Vault (Red Portal)",
        nextNodeId: "trust_vault",
        risk: "moderate",
      },
      {
        id: "path_chaos",
        text: "Ascend to the CHAOS Nexus (Cyan Portal)",
        nextNodeId: "chaos_nexus",
        risk: "dangerous",
      },
    ],
    visited: false,
    completed: false,
  },

  tax_citadel: {
    id: "tax_citadel",
    type: "challenge",
    title: "The Tax Citadel",
    description:
      "A fortress of forms and calculations. The Tax Guardian blocks your path, demanding you prove your understanding of deductions.",
    options: [
      {
        id: "challenge_guardian",
        text: "Challenge the Tax Guardian (Requires 200 XP)",
        nextNodeId: "tax_boss",
        requirement: { type: "xp", value: 200 },
        risk: "dangerous",
      },
      {
        id: "study_scrolls",
        text: "Study the Ancient Scrolls",
        nextNodeId: "tax_library",
        risk: "safe",
      },
      {
        id: "return_entrance",
        text: "Return to Gateway",
        nextNodeId: "entrance",
        risk: "safe",
      },
    ],
    visited: false,
    completed: false,
  },

  trust_vault: {
    id: "trust_vault",
    type: "challenge",
    title: "The Trust Vault",
    description:
      "A labyrinth of locked chambers, each containing secrets of asset protection. The Vault Keeper watches from the shadows.",
    options: [
      {
        id: "unlock_chambers",
        text: "Unlock the Secret Chambers",
        nextNodeId: "trust_chambers",
        requirement: { type: "badge", value: "trust_basics" },
        risk: "moderate",
      },
      {
        id: "speak_keeper",
        text: "Speak with the Vault Keeper",
        nextNodeId: "trust_keeper",
        risk: "safe",
      },
      {
        id: "return_entrance",
        text: "Return to Gateway",
        nextNodeId: "entrance",
        risk: "safe",
      },
    ],
    visited: false,
    completed: false,
  },

  chaos_nexus: {
    id: "chaos_nexus",
    type: "portal",
    title: "The CHAOS Nexus",
    description:
      "The heart of the motherboard pulses with raw data. Reality bends here. Only the most skilled navigators survive.",
    options: [
      {
        id: "activate_antigravity",
        text: "Activate Antigravity Engine",
        nextNodeId: "antigravity_zone",
        requirement: { type: "xp", value: 500 },
        risk: "dangerous",
      },
      {
        id: "consult_neuro",
        text: "Consult NEURO Avatar",
        nextNodeId: "neuro_guidance",
        risk: "safe",
      },
      {
        id: "return_entrance",
        text: "Return to Gateway",
        nextNodeId: "entrance",
        risk: "safe",
      },
    ],
    visited: false,
    completed: false,
  },

  tax_boss: {
    id: "tax_boss",
    type: "boss",
    title: "Tax Guardian Battle",
    description:
      'The Tax Guardian materializes: "Prove your mastery of deductions, or be lost in audit loops forever!"',
    options: [
      {
        id: "complete_challenge",
        text: "Complete the Challenge",
        nextNodeId: "tax_victory",
        risk: "dangerous",
      },
    ],
    visited: false,
    completed: false,
  },

  tax_victory: {
    id: "tax_victory",
    type: "reward",
    title: "Victory!",
    description: 'The Tax Guardian bows. "You have mastered the forms. Take this badge and continue your journey."',
    options: [
      {
        id: "return_entrance",
        text: "Return to Gateway with Badge",
        nextNodeId: "entrance",
        risk: "safe",
      },
    ],
    visited: false,
    completed: false,
  },

  // Add more nodes for complete labyrinth...
}

export function getLabyrinthNode(nodeId: string): LabyrinthNode | undefined {
  return LABYRINTH_NODES[nodeId]
}

export function canAccessNode(node: LabyrinthNode, option: any, userProgress: any): boolean {
  if (!option.requirement) return true

  const { type, value } = option.requirement

  switch (type) {
    case "xp":
      return userProgress.totalXP >= value
    case "badge":
      return userProgress.badges.includes(value)
    case "skill":
      return userProgress.skills?.[value] >= 1
    default:
      return true
  }
}
