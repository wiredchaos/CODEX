import type { EducationModule } from "./types"

export const EDUCATION_MODULES: EducationModule[] = [
  // TAX MODULES
  {
    id: "tax_basics_101",
    title: "Tax Fundamentals: Your First Return",
    category: "tax",
    difficulty: "beginner",
    duration: 15,
    prerequisites: [],
    outcomes: ["Understand W-2 forms", "File basic 1040", "Calculate standard deduction"],
    xpReward: 100,
  },
  {
    id: "tax_deductions_201",
    title: "Advanced Deductions & Credits",
    category: "tax",
    difficulty: "intermediate",
    duration: 30,
    prerequisites: ["tax_basics_101"],
    outcomes: ["Identify business deductions", "Claim tax credits", "Optimize refunds"],
    xpReward: 250,
  },

  // TRUST MODULES
  {
    id: "trust_intro_101",
    title: "Trust Basics: Asset Protection 101",
    category: "trust",
    difficulty: "beginner",
    duration: 20,
    prerequisites: [],
    outcomes: ["Understand trust types", "Know when to use trusts", "Identify beneficiaries"],
    xpReward: 150,
  },
  {
    id: "trust_advanced_301",
    title: "Dynasty Trusts & Generational Wealth",
    category: "trust",
    difficulty: "advanced",
    duration: 45,
    prerequisites: ["trust_intro_101", "entity_structures_201"],
    outcomes: ["Structure dynasty trusts", "Minimize estate taxes", "Plan multi-generational transfers"],
    xpReward: 500,
  },

  // ENTITY MODULES
  {
    id: "entity_llc_101",
    title: "LLC Formation: Your First Business Entity",
    category: "entity",
    difficulty: "beginner",
    duration: 25,
    prerequisites: [],
    outcomes: ["Form an LLC", "Understand liability protection", "Setup operating agreement"],
    xpReward: 200,
  },
  {
    id: "entity_structures_201",
    title: "Complex Entity Structures: Holdings & Subsidiaries",
    category: "entity",
    difficulty: "intermediate",
    duration: 40,
    prerequisites: ["entity_llc_101"],
    outcomes: ["Design holding companies", "Create subsidiary networks", "Optimize tax structure"],
    xpReward: 350,
  },

  // BUSINESS MODULES
  {
    id: "business_plan_101",
    title: "Business Planning: From Idea to Launch",
    category: "business",
    difficulty: "beginner",
    duration: 30,
    prerequisites: [],
    outcomes: ["Create business plan", "Define value proposition", "Build financial projections"],
    xpReward: 150,
  },

  // CREATIVE MODULES
  {
    id: "creative_branding_101",
    title: "Brand Identity: Building Your Visual Language",
    category: "creative",
    difficulty: "beginner",
    duration: 20,
    prerequisites: [],
    outcomes: ["Define brand voice", "Create visual identity", "Design brand guidelines"],
    xpReward: 100,
  },

  // TECHNICAL MODULES
  {
    id: "tech_chaos_os_101",
    title: "CHAOS OS: Navigating the Motherboard",
    category: "technical",
    difficulty: "beginner",
    duration: 15,
    prerequisites: [],
    outcomes: ["Navigate CHAOS OS", "Understand patch system", "Use Antigravity Engine"],
    xpReward: 100,
  },
]

export function getModuleById(id: string): EducationModule | undefined {
  return EDUCATION_MODULES.find((m) => m.id === id)
}

export function getModulesByCategory(category: string): EducationModule[] {
  return EDUCATION_MODULES.filter((m) => m.category === category)
}

export function getModulesByDifficulty(difficulty: string): EducationModule[] {
  return EDUCATION_MODULES.filter((m) => m.difficulty === difficulty)
}

export function getAvailableModules(completedModules: string[]): EducationModule[] {
  return EDUCATION_MODULES.filter((module) => {
    // Module not yet completed
    if (completedModules.includes(module.id)) return false

    // Check if prerequisites are met
    return module.prerequisites.every((prereq) => completedModules.includes(prereq))
  })
}
