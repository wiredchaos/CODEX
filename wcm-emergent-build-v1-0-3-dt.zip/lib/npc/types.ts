export type NPCRole = "general" | "educator" | "guide" | "challenger" | "companion"
export type NPCMode = "education" | "game" | "labyrinth" | "exploration"
export type DifficultyLevel = "beginner" | "intermediate" | "advanced" | "expert"

export interface NPCPersonality {
  role: NPCRole
  mode: NPCMode
  tone: "friendly" | "professional" | "playful" | "mysterious" | "authoritative"
  verbosity: "concise" | "balanced" | "detailed"
  encouragement: number // 0-100
  challenge: number // 0-100
}

export interface EducationModule {
  id: string
  title: string
  category: "tax" | "trust" | "entity" | "business" | "creative" | "technical"
  difficulty: DifficultyLevel
  duration: number // minutes
  prerequisites: string[]
  outcomes: string[]
  xpReward: number
}

export interface GameSession {
  id: string
  type: "quiz" | "puzzle" | "simulation" | "challenge" | "scenario"
  title: string
  difficulty: DifficultyLevel
  timeLimit?: number
  score: number
  maxScore: number
  completed: boolean
  xpEarned: number
}

export interface LabyrinthNode {
  id: string
  type: "decision" | "challenge" | "reward" | "trap" | "portal" | "boss"
  title: string
  description: string
  options: LabyrinthOption[]
  visited: boolean
  completed: boolean
}

export interface LabyrinthOption {
  id: string
  text: string
  nextNodeId: string
  requirement?: {
    type: "xp" | "skill" | "item" | "badge"
    value: string | number
  }
  risk: "safe" | "moderate" | "dangerous"
}

export interface NPCSession {
  id: string
  userId: string
  npcRole: NPCRole
  mode: NPCMode
  personality: NPCPersonality
  currentModule?: string
  currentGame?: string
  currentLabyrinthNode?: string
  progress: {
    modulesCompleted: number
    gamesWon: number
    labyrinthsExplored: number
    totalXP: number
    level: number
    badges: string[]
  }
  history: NPCInteraction[]
  createdAt: Date
  lastActive: Date
}

export interface NPCInteraction {
  id: string
  timestamp: Date
  userInput: string
  npcResponse: string
  action?: "educate" | "challenge" | "guide" | "reward" | "redirect"
  xpAwarded?: number
  videoUrl?: string
}

export interface GeneralCommand {
  type: "assign_module" | "start_game" | "enter_labyrinth" | "level_up" | "award_badge" | "adjust_difficulty"
  target: string
  payload: Record<string, any>
  reason: string
}
