import { notFound } from "next/navigation"
import { ShellLayout } from "@/components/shell-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { StatusPill } from "@/components/status-pill"
import { swarmRegistry } from "@/lib/swarms/registry"
import { avatarRegistry } from "@/lib/avatars/registry"
import { videoRegistry } from "@/lib/video/registry"
import { patchRegistry } from "@/lib/patches/registry"
import { Bot, User, Video, Boxes, ArrowLeft, Play } from "lucide-react"
import Link from "next/link"

interface SwarmDetailPageProps {
  params: Promise<{ key: string }>
}

export default async function SwarmDetailPage({ params }: SwarmDetailPageProps) {
  const { key } = await params
  const swarm = swarmRegistry.getSwarmAgent(key)

  if (!swarm) {
    notFound()
  }

  const avatar = swarm.avatarKey ? avatarRegistry.getAvatar(swarm.avatarKey) : null
  const videoProfile = avatar?.videoProfileKey ? videoRegistry.getVideoProfile(avatar.videoProfileKey) : null
  const linkedPatches = swarm.patchAffinity?.map((pk) => patchRegistry.getPatch(pk)).filter(Boolean) || []

  return (
    <ShellLayout>
      <div className="space-y-6">
        <Link
          href="/swarms"
          className="inline-flex items-center text-sm text-muted-foreground hover:text-[#00FFFF] transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-1" /> Back to Swarms
        </Link>

        <div className="flex items-start gap-4">
          <div className="w-16 h-16 rounded-xl bg-[#00FFFF]/10 border border-[#00FFFF]/30 flex items-center justify-center">
            <Bot className="w-8 h-8 text-[#00FFFF]" />
          </div>
          <div className="space-y-1 flex-1">
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold text-[#00FFFF] text-glow-cyan">{swarm.name}</h1>
              <StatusPill status={swarm.isActive ? "online" : "offline"} />
            </div>
            <p className="text-muted-foreground">{swarm.role}</p>
            <Badge variant="outline" className="text-xs capitalize">
              {swarm.swarmType}
            </Badge>
          </div>
        </div>

        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-lg">Description</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">{swarm.description}</p>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-lg">Capabilities</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {swarm.capabilities.map((cap) => (
                <Badge
                  key={cap}
                  variant="secondary"
                  className="bg-[#00FFFF]/10 text-[#00FFFF] border border-[#00FFFF]/30"
                >
                  {cap.replace(/_/g, " ")}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {linkedPatches.length > 0 && (
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Boxes className="w-5 h-5" /> Linked Patch Modules
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {linkedPatches.map(
                  (patch) =>
                    patch && (
                      <Link key={patch.id} href={`/patches/${patch.slug}`}>
                        <div className="p-3 rounded-lg bg-background/50 border border-border hover:border-[#00FFFF]/50 transition-colors">
                          <div className="flex items-center justify-between">
                            <span className="font-medium">{patch.displayName}</span>
                            <StatusPill status={patch.status} />
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">{patch.category}</p>
                        </div>
                      </Link>
                    ),
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {avatar && (
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <User className="w-5 h-5" /> Linked Avatar
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-4">
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center"
                  style={{
                    background: `linear-gradient(135deg, ${avatar.colorProfile[0]}40, ${avatar.colorProfile[1] || avatar.colorProfile[0]}40)`,
                    border: `2px solid ${avatar.colorProfile[0]}`,
                  }}
                >
                  <User className="w-6 h-6" style={{ color: avatar.colorProfile[0] }} />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold" style={{ color: avatar.colorProfile[0] }}>
                    {avatar.displayName}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">{avatar.persona}</p>
                  <div className="flex gap-2 mt-2">
                    {avatar.colorProfile.map((color, i) => (
                      <div
                        key={i}
                        className="w-6 h-6 rounded-full border border-white/20"
                        style={{ backgroundColor: color }}
                        title={color}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {videoProfile && (
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Video className="w-5 h-5" /> Video Profile
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Provider</p>
                  <p className="font-medium capitalize">{videoProfile.provider}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Aspect Ratio</p>
                  <p className="font-medium">{videoProfile.aspectRatio}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Duration</p>
                  <p className="font-medium">{videoProfile.defaultDurationSec}s</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Voice Preset</p>
                  <p className="font-medium">{videoProfile.voicePreset?.replace(/_/g, " ") || "—"}</p>
                </div>
              </div>
              {videoProfile.notes && <p className="text-sm text-muted-foreground italic">{videoProfile.notes}</p>}
              <Button className="w-full md:w-auto bg-[#FF00FF] hover:bg-[#FF00FF]/80 text-white">
                <Play className="w-4 h-4 mr-2" /> Generate Video (Coming Soon)
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </ShellLayout>
  )
}
