import { ShellLayout } from "@/components/shell-layout"
import { SwarmCard } from "@/components/swarm-card"
import { swarmRegistry } from "@/lib/swarms/registry"
import type { SwarmType } from "@/lib/patches/types"

const SWARM_TYPE_LABELS: Record<SwarmType, string> = {
  system: "System & Architecture",
  tax: "Tax & Compliance",
  trust: "Estate & Trusts",
  entity: "Business Entities",
  triad: "Triad Engine",
  content: "Content & Media",
  health: "Health & Wellness",
  other: "Other",
}

const SWARM_TYPE_ORDER: SwarmType[] = ["system", "tax", "trust", "entity", "triad", "content", "health", "other"]

export default function SwarmsPage() {
  const swarms = swarmRegistry.listSwarmAgents()
  const activeCount = swarms.filter((s) => s.isActive).length

  const swarmsByType = SWARM_TYPE_ORDER.map((type) => ({
    type,
    label: SWARM_TYPE_LABELS[type],
    swarms: swarms.filter((s) => s.swarmType === type),
  })).filter((group) => group.swarms.length > 0)

  return (
    <ShellLayout>
      <div className="space-y-8">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-[#00FFFF] text-glow-cyan">SWARM Registry</h1>
          <p className="text-muted-foreground">
            {swarms.length} agents registered • {activeCount} active
          </p>
        </div>

        {swarmsByType.map((group) => (
          <div key={group.type} className="space-y-4">
            <h2 className="text-xl font-semibold text-foreground border-b border-[#00FFFF]/20 pb-2">{group.label}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {group.swarms.map((swarm) => (
                <SwarmCard key={swarm.id} swarm={swarm} />
              ))}
            </div>
          </div>
        ))}
      </div>
    </ShellLayout>
  )
}
