import { ShellLayout } from "@/components/shell-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { avatarRegistry } from "@/lib/avatars/registry"
import { videoRegistry } from "@/lib/video/registry"
import { swarmRegistry } from "@/lib/swarms/registry"
import { User, Video, Bot } from "lucide-react"
import Link from "next/link"

export default function AvatarsPage() {
  const avatars = avatarRegistry.listAvatars()

  return (
    <ShellLayout>
      <div className="space-y-8">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-[#FF00FF] text-glow-pink">Avatar Gallery</h1>
          <p className="text-muted-foreground">{avatars.length} avatar personas • Video-enabled agents</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {avatars.map((avatar) => {
            const swarm = avatar.swarmKey ? swarmRegistry.getSwarmAgent(avatar.swarmKey) : null
            const video = avatar.videoProfileKey ? videoRegistry.getVideoProfile(avatar.videoProfileKey) : null

            return (
              <Card key={avatar.key} className="glass-card hover:border-[#FF00FF]/50 transition-all">
                <CardHeader className="pb-3">
                  <div className="flex items-start gap-3">
                    <div
                      className="w-14 h-14 rounded-full flex items-center justify-center shrink-0"
                      style={{
                        background: `linear-gradient(135deg, ${avatar.colorProfile[0]}40, ${avatar.colorProfile[1] || avatar.colorProfile[0]}40)`,
                        border: `2px solid ${avatar.colorProfile[0]}`,
                      }}
                    >
                      <User className="w-7 h-7" style={{ color: avatar.colorProfile[0] }} />
                    </div>
                    <div className="min-w-0">
                      <CardTitle className="text-base" style={{ color: avatar.colorProfile[0] }}>
                        {avatar.displayName}
                      </CardTitle>
                      {swarm && (
                        <Link
                          href={`/swarms/${swarm.key}`}
                          className="text-xs text-muted-foreground hover:text-[#00FFFF] flex items-center gap-1 mt-1"
                        >
                          <Bot className="w-3 h-3" /> {swarm.name}
                        </Link>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-muted-foreground line-clamp-3">{avatar.persona}</p>

                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">Colors:</span>
                    <div className="flex gap-1">
                      {avatar.colorProfile.map((color, i) => (
                        <div
                          key={i}
                          className="w-5 h-5 rounded-full border border-white/20"
                          style={{ backgroundColor: color }}
                          title={color}
                        />
                      ))}
                    </div>
                  </div>

                  {video && (
                    <div className="flex items-center gap-2 text-xs">
                      <Video className="w-3 h-3 text-[#FF00FF]" />
                      <span className="text-muted-foreground">
                        {video.provider} • {video.aspectRatio} • {video.defaultDurationSec}s
                      </span>
                    </div>
                  )}

                  {swarm && (
                    <Badge variant="outline" className="text-xs capitalize">
                      {swarm.swarmType}
                    </Badge>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </ShellLayout>
  )
}
