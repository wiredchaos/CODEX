"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { ShellLayout } from "@/components/shell-layout"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Zap,
  Play,
  Loader2,
  CheckCircle2,
  XCircle,
  Clock,
  AlertTriangle,
  Rocket,
  BarChart3,
  History,
  Settings2,
} from "lucide-react"

interface PlanStep {
  stepNumber: number
  agentKey: string
  agentName: string
  toolId: string
  toolName: string
  action: string
  params: Record<string, unknown>
  dependsOn: number[]
  estimatedMs: number
  requiresApproval: boolean
  riskLevel: "low" | "medium" | "high"
}

interface StepResult {
  stepNumber: number
  status: "queued" | "running" | "success" | "failed" | "skipped"
  startedAt: string | null
  completedAt: string | null
  latencyMs: number
  output: unknown
  error: string | null
  retryCount: number
}

interface Task {
  id: string
  goal: string
  context?: string
  domain: string
  createdAt: string
  updatedAt: string
  status: "pending" | "planning" | "executing" | "paused" | "completed" | "failed" | "cancelled"
  plan: {
    planId: string
    steps: PlanStep[]
    estimatedDuration: number
    riskLevel: "low" | "medium" | "high"
    requiredApprovals: string[]
  } | null
  results: StepResult[]
  metadata: {
    maxSteps: number
    safeMode: boolean
    autoExecute: boolean
    domainSwarms: string[]
  }
}

interface Stats {
  totalTasks: number
  byStatus: Record<string, number>
  activeSwarms: number
  availableTools: number
}

const DOMAINS = [
  { value: "auto", label: "Auto-detect" },
  { value: "system", label: "System & Architecture" },
  { value: "tax", label: "Tax & Compliance" },
  { value: "trust", label: "Estate & Trusts" },
  { value: "entity", label: "Business Entities" },
  { value: "triad", label: "Triad Engine (FEN/VRG/589)" },
  { value: "content", label: "Content & Media" },
  { value: "health", label: "Health & Wellness" },
] as const

const STATUS_CONFIG: Record<string, { color: string; icon: React.ElementType }> = {
  pending: { color: "text-yellow-400", icon: Clock },
  planning: { color: "text-blue-400", icon: Loader2 },
  executing: { color: "text-cyan-400", icon: Rocket },
  paused: { color: "text-orange-400", icon: AlertTriangle },
  completed: { color: "text-green-400", icon: CheckCircle2 },
  failed: { color: "text-red-400", icon: XCircle },
  cancelled: { color: "text-gray-400", icon: XCircle },
}

export default function AntigravityPage() {
  const [goal, setGoal] = useState("")
  const [context, setContext] = useState("")
  const [maxSteps, setMaxSteps] = useState(10)
  const [safeMode, setSafeMode] = useState(true)
  const [autoExecute, setAutoExecute] = useState(false)
  const [domain, setDomain] = useState("auto")

  const [currentTask, setCurrentTask] = useState<Task | null>(null)
  const [tasks, setTasks] = useState<Task[]>([])
  const [stats, setStats] = useState<Stats | null>(null)

  const [isCreating, setIsCreating] = useState(false)
  const [isPlanning, setIsPlanning] = useState(false)
  const [isExecuting, setIsExecuting] = useState(false)

  // Load tasks and stats on mount
  useEffect(() => {
    fetchTasks()
  }, [])

  const fetchTasks = async () => {
    try {
      const res = await fetch("/api/antigravity/task")
      const data = await res.json()
      setTasks(data.tasks || [])
      setStats(data.stats || null)
    } catch (error) {
      console.error("Failed to fetch tasks:", error)
    }
  }

  const handleCreateTask = async () => {
    if (!goal.trim()) return
    setIsCreating(true)

    try {
      const res = await fetch("/api/antigravity/task", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          goal,
          context,
          config: {
            maxSteps,
            safeMode,
            autoExecute,
            domain: domain === "auto" ? undefined : domain,
          },
        }),
      })

      const task = await res.json()
      setCurrentTask(task)
      await fetchTasks()

      // Auto-plan
      await handlePlanTask(task.id)
    } catch (error) {
      console.error("Failed to create task:", error)
    } finally {
      setIsCreating(false)
    }
  }

  const handlePlanTask = async (taskId: string) => {
    setIsPlanning(true)

    try {
      const res = await fetch("/api/antigravity/plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ taskId }),
      })

      const task = await res.json()
      setCurrentTask(task)
      await fetchTasks()
    } catch (error) {
      console.error("Failed to plan task:", error)
    } finally {
      setIsPlanning(false)
    }
  }

  const handleExecuteTask = async () => {
    if (!currentTask?.id) return
    setIsExecuting(true)

    try {
      const res = await fetch("/api/antigravity/execute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ taskId: currentTask.id }),
      })

      const task = await res.json()
      setCurrentTask(task)
      await fetchTasks()
    } catch (error) {
      console.error("Failed to execute task:", error)
    } finally {
      setIsExecuting(false)
    }
  }

  const loadTask = (task: Task) => {
    setCurrentTask(task)
    setGoal(task.goal)
    setContext(task.context || "")
    setDomain(task.domain)
  }

  const StatusBadge = ({ status }: { status: string }) => {
    const config = STATUS_CONFIG[status] || STATUS_CONFIG.pending
    const Icon = config.icon

    return (
      <Badge variant="outline" className={`${config.color} border-current`}>
        <Icon className={`w-3 h-3 mr-1 ${status === "planning" || status === "executing" ? "animate-spin" : ""}`} />
        {status.toUpperCase()}
      </Badge>
    )
  }

  const RiskBadge = ({ level }: { level: "low" | "medium" | "high" }) => {
    const colors = {
      low: "bg-green-500/20 text-green-400 border-green-500/30",
      medium: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
      high: "bg-red-500/20 text-red-400 border-red-500/30",
    }

    return (
      <Badge variant="outline" className={colors[level]}>
        {level.toUpperCase()} RISK
      </Badge>
    )
  }

  return (
    <ShellLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <h1 className="text-2xl font-bold text-[#00FFFF] text-glow-cyan flex items-center gap-2">
              <Rocket className="w-6 h-6" />
              CHAOS Antigravity Engine
            </h1>
            <p className="text-muted-foreground">AI-powered task orchestration via SWARM agents and MCP tools</p>
          </div>

          {stats && (
            <div className="flex items-center gap-4 text-sm">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-[#00FFFF]" />
                <span className="text-muted-foreground">
                  {stats.activeSwarms} Swarms / {stats.availableTools} Tools
                </span>
              </div>
            </div>
          )}
        </div>

        <Tabs defaultValue="engine" className="space-y-4">
          <TabsList className="bg-secondary/50">
            <TabsTrigger value="engine" className="data-[state=active]:bg-[#00FFFF]/20">
              <Zap className="w-4 h-4 mr-2" />
              Engine
            </TabsTrigger>
            <TabsTrigger value="history" className="data-[state=active]:bg-[#00FFFF]/20">
              <History className="w-4 h-4 mr-2" />
              History
            </TabsTrigger>
          </TabsList>

          <TabsContent value="engine" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Input Panel */}
              <Card className="glass-card border-[#00FFFF]/20">
                <CardHeader>
                  <CardTitle className="text-lg text-foreground flex items-center gap-2">
                    <Zap className="w-5 h-5 text-[#00FFFF]" />
                    Task Definition
                  </CardTitle>
                  <CardDescription>Define your goal and let SWARM orchestrate</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="goal">Goal</Label>
                    <Textarea
                      id="goal"
                      placeholder="What do you want to accomplish? e.g., 'Prepare crypto tax documents for 2024' or 'Generate trust blueprint for asset protection'"
                      value={goal}
                      onChange={(e) => setGoal(e.target.value)}
                      className="bg-secondary/50 border-border min-h-[100px]"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="context">Context (optional)</Label>
                    <Textarea
                      id="context"
                      placeholder="Additional context, constraints, or relevant information..."
                      value={context}
                      onChange={(e) => setContext(e.target.value)}
                      className="bg-secondary/50 border-border"
                      rows={2}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="domain">Domain</Label>
                      <Select value={domain} onValueChange={setDomain}>
                        <SelectTrigger className="bg-secondary/50 border-border">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {DOMAINS.map((d) => (
                            <SelectItem key={d.value} value={d.value}>
                              {d.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="maxSteps">Max Steps</Label>
                      <Input
                        id="maxSteps"
                        type="number"
                        min={1}
                        max={20}
                        value={maxSteps}
                        onChange={(e) => setMaxSteps(Number(e.target.value))}
                        className="bg-secondary/50 border-border"
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-6">
                    <div className="flex items-center gap-2">
                      <Switch id="safeMode" checked={safeMode} onCheckedChange={setSafeMode} />
                      <Label htmlFor="safeMode" className="text-sm">
                        Safe Mode
                      </Label>
                    </div>

                    <div className="flex items-center gap-2">
                      <Switch id="autoExecute" checked={autoExecute} onCheckedChange={setAutoExecute} />
                      <Label htmlFor="autoExecute" className="text-sm">
                        Auto-Execute
                      </Label>
                    </div>
                  </div>

                  <Button
                    onClick={handleCreateTask}
                    disabled={!goal.trim() || isCreating || isPlanning}
                    className="w-full bg-[#00FFFF]/20 text-[#00FFFF] hover:bg-[#00FFFF]/30 border border-[#00FFFF]/30"
                  >
                    {isCreating || isPlanning ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        {isCreating ? "Creating..." : "Planning..."}
                      </>
                    ) : (
                      <>
                        <Zap className="w-4 h-4 mr-2" />
                        Create & Plan Task
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {/* Plan Panel */}
              <Card className="glass-card border-[#39FF14]/20">
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle className="text-lg text-foreground">Execution Plan</CardTitle>
                    {currentTask && (
                      <CardDescription className="flex items-center gap-2 mt-1">
                        <StatusBadge status={currentTask.status} />
                        {currentTask.plan && <RiskBadge level={currentTask.plan.riskLevel} />}
                      </CardDescription>
                    )}
                  </div>
                  {currentTask?.plan && currentTask.status === "pending" && (
                    <Button
                      onClick={handleExecuteTask}
                      disabled={isExecuting}
                      className="bg-[#39FF14]/20 text-[#39FF14] hover:bg-[#39FF14]/30 border border-[#39FF14]/30"
                    >
                      {isExecuting ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Executing...
                        </>
                      ) : (
                        <>
                          <Play className="w-4 h-4 mr-2" />
                          Execute Plan
                        </>
                      )}
                    </Button>
                  )}
                </CardHeader>
                <CardContent>
                  {!currentTask?.plan ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Settings2 className="w-12 h-12 mx-auto mb-3 opacity-30" />
                      <p>No plan generated yet</p>
                      <p className="text-sm">Create a task to generate an execution plan</p>
                    </div>
                  ) : (
                    <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                      {currentTask.plan.steps.map((step, index) => {
                        const result = currentTask.results.find((r) => r.stepNumber === step.stepNumber)
                        const resultStatus = result?.status || "queued"

                        return (
                          <div
                            key={index}
                            className={`p-3 rounded-lg border transition-colors ${
                              resultStatus === "success"
                                ? "bg-green-500/10 border-green-500/30"
                                : resultStatus === "failed"
                                  ? "bg-red-500/10 border-red-500/30"
                                  : resultStatus === "running"
                                    ? "bg-cyan-500/10 border-cyan-500/30"
                                    : "bg-secondary/30 border-border"
                            }`}
                          >
                            <div className="flex items-start gap-3">
                              <div
                                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-mono shrink-0 ${
                                  resultStatus === "success"
                                    ? "bg-green-500/20 text-green-400"
                                    : resultStatus === "failed"
                                      ? "bg-red-500/20 text-red-400"
                                      : resultStatus === "running"
                                        ? "bg-cyan-500/20 text-cyan-400"
                                        : "bg-[#39FF14]/10 text-[#39FF14]"
                                }`}
                              >
                                {resultStatus === "success" ? (
                                  <CheckCircle2 className="w-4 h-4" />
                                ) : resultStatus === "failed" ? (
                                  <XCircle className="w-4 h-4" />
                                ) : resultStatus === "running" ? (
                                  <Loader2 className="w-4 h-4 animate-spin" />
                                ) : (
                                  step.stepNumber
                                )}
                              </div>

                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <code className="text-[#00FFFF] font-mono text-sm">{step.agentName}</code>
                                  <span className="text-muted-foreground">→</span>
                                  <code className="text-[#FF00FF] font-mono text-sm">{step.toolName}</code>
                                  {step.requiresApproval && (
                                    <Badge variant="outline" className="text-orange-400 border-orange-400/30 text-xs">
                                      APPROVAL
                                    </Badge>
                                  )}
                                </div>
                                <p className="text-sm text-muted-foreground mt-1">{step.action}</p>

                                {result?.latencyMs && (
                                  <p className="text-xs text-muted-foreground mt-1">
                                    Completed in {result.latencyMs}ms
                                    {result.retryCount > 0 && ` (${result.retryCount} retries)`}
                                  </p>
                                )}

                                {result?.error && <p className="text-xs text-red-400 mt-1">{result.error}</p>}
                              </div>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  )}

                  {currentTask?.plan && (
                    <div className="mt-4 pt-4 border-t border-border flex items-center justify-between text-sm text-muted-foreground">
                      <span>
                        {currentTask.plan.steps.length} steps / ~{Math.round(currentTask.plan.estimatedDuration / 1000)}
                        s estimated
                      </span>
                      <span>Domain: {currentTask.domain}</span>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Results Panel */}
            {currentTask?.results && currentTask.results.length > 0 && (
              <Card className="glass-card border-[#FF00FF]/20">
                <CardHeader>
                  <CardTitle className="text-lg text-foreground">Execution Results</CardTitle>
                  <CardDescription>
                    {currentTask.results.filter((r) => r.status === "success").length} of {currentTask.results.length}{" "}
                    steps completed successfully
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <pre className="text-sm text-muted-foreground bg-secondary/30 p-4 rounded-lg overflow-auto max-h-[300px]">
                    {JSON.stringify(
                      currentTask.results.map((r) => ({
                        step: r.stepNumber,
                        status: r.status,
                        latencyMs: r.latencyMs,
                        output: r.output,
                        error: r.error,
                      })),
                      null,
                      2,
                    )}
                  </pre>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="history" className="space-y-4">
            <Card className="glass-card border-border">
              <CardHeader>
                <CardTitle className="text-lg text-foreground flex items-center gap-2">
                  <History className="w-5 h-5" />
                  Task History
                </CardTitle>
                <CardDescription>{tasks.length} total tasks</CardDescription>
              </CardHeader>
              <CardContent>
                {tasks.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <History className="w-12 h-12 mx-auto mb-3 opacity-30" />
                    <p>No tasks yet</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {tasks.map((task) => (
                      <button
                        key={task.id}
                        onClick={() => loadTask(task)}
                        className={`w-full p-3 rounded-lg border text-left transition-colors hover:bg-secondary/50 ${
                          currentTask?.id === task.id ? "border-[#00FFFF]/50 bg-[#00FFFF]/5" : "border-border"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex-1 min-w-0">
                            <p className="font-medium truncate">{task.goal}</p>
                            <p className="text-xs text-muted-foreground">
                              {new Date(task.createdAt).toLocaleString()} • {task.domain}
                            </p>
                          </div>
                          <StatusBadge status={task.status} />
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </ShellLayout>
  )
}
