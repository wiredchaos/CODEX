"use client"

import { ShellLayout } from "@/components/shell-layout"
import { useEffect, useState } from "react"
import { NeuroEngine } from "@/lib/neuro/neuro-engine"
import type { NeuroState } from "@/lib/neuro/types"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Brain, Zap, User, Shield, Crown, Activity, RefreshCw } from "lucide-react"

export default function NeuroControlPage() {
  const [neuroState, setNeuroState] = useState<NeuroState | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const state = NeuroEngine.getState()
    setNeuroState(state)
    setIsLoading(false)
  }, [])

  const handleReset = () => {
    NeuroEngine.reset()
    window.location.reload()
  }

  const handleSimulateEvent = (event: "click" | "keypress" | "scroll" | "error" | "help") => {
    const updated = NeuroEngine.update(event)
    if (updated) setNeuroState(updated)
  }

  if (isLoading) {
    return (
      <ShellLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center space-y-4">
            <Brain className="w-12 h-12 text-[#00FFFF] animate-pulse mx-auto" />
            <p className="text-muted-foreground">Initializing NEURO...</p>
          </div>
        </div>
      </ShellLayout>
    )
  }

  if (!neuroState) {
    return (
      <ShellLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Card className="glass-panel border-[#FF3131]/50 p-8 text-center space-y-4">
            <p className="text-[#FF3131]">NEURO not initialized</p>
            <Button onClick={() => window.location.reload()}>Initialize NEURO</Button>
          </Card>
        </div>
      </ShellLayout>
    )
  }

  const { currentForm, currentMode, profile, context, behavioralSignals } = neuroState

  const avatarIcons = {
    human: User,
    digital: Zap,
    guardian: Shield,
    sovereign: Crown,
    hybrid: Activity,
  }

  const AvatarIcon = avatarIcons[currentForm]

  return (
    <ShellLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-[#00FFFF] text-glow-cyan">NEURO Navigator Control</h1>
          <p className="text-muted-foreground">Adaptive Intelligence System • Context-Aware Avatar Selection</p>
        </div>

        {/* Current State */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="glass-panel border-[#00FFFF]/50 p-6">
            <div className="flex items-center gap-3 mb-2">
              <AvatarIcon className="w-8 h-8 text-[#00FFFF]" />
              <h3 className="font-semibold text-foreground">Avatar Form</h3>
            </div>
            <p className="text-2xl font-bold text-[#00FFFF] capitalize">{currentForm}</p>
            <Badge variant="outline" className="mt-2 border-[#00FFFF]/50 text-[#00FFFF]">
              Active
            </Badge>
          </Card>

          <Card className="glass-panel border-[#39FF14]/50 p-6">
            <div className="flex items-center gap-3 mb-2">
              <Brain className="w-8 h-8 text-[#39FF14]" />
              <h3 className="font-semibold text-foreground">Personality Mode</h3>
            </div>
            <p className="text-2xl font-bold text-[#39FF14] capitalize">{currentMode}</p>
          </Card>

          <Card className="glass-panel border-[#FF00FF]/50 p-6">
            <div className="flex items-center gap-3 mb-2">
              <User className="w-8 h-8 text-[#FF00FF]" />
              <h3 className="font-semibold text-foreground">Generation</h3>
            </div>
            <p className="text-2xl font-bold text-[#FF00FF] capitalize">{profile.generationalProfile}</p>
          </Card>

          <Card className="glass-panel border-[#FF3131]/50 p-6">
            <div className="flex items-center gap-3 mb-2">
              <Activity className="w-8 h-8 text-[#FF3131]" />
              <h3 className="font-semibold text-foreground">Confidence</h3>
            </div>
            <p className="text-2xl font-bold text-[#FF3131]">{profile.confidence}%</p>
          </Card>
        </div>

        {/* Adaptation Reason */}
        <Card className="glass-panel border-[#00FFFF]/30 p-6">
          <h3 className="font-semibold text-foreground mb-3">Adaptation Logic</h3>
          <p className="text-[#00FFFF] text-sm leading-relaxed">{profile.adaptationReason}</p>
        </Card>

        {/* Context Detection */}
        <Card className="glass-panel border-[#39FF14]/30 p-6">
          <h3 className="font-semibold text-foreground mb-4">Context Detection</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            <div>
              <p className="text-xs text-muted-foreground mb-1">Entry Point</p>
              <p className="text-sm text-foreground font-mono">{context.entryPoint}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Device</p>
              <p className="text-sm text-foreground capitalize">{context.device}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Time of Day</p>
              <p className="text-sm text-foreground capitalize">{context.timeOfDay}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Section</p>
              <p className="text-sm text-foreground capitalize">{context.section}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">User Type</p>
              <p className="text-sm text-foreground">{context.isReturningUser ? "Returning" : "New"}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Confidence Level</p>
              <p className="text-sm text-foreground capitalize">{context.confidenceLevel}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Interaction Speed</p>
              <p className="text-sm text-foreground capitalize">{context.interactionSpeed}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Exploration Style</p>
              <p className="text-sm text-foreground capitalize">{context.explorationStyle}</p>
            </div>
          </div>
        </Card>

        {/* Behavioral Signals */}
        <Card className="glass-panel border-[#FF00FF]/30 p-6">
          <h3 className="font-semibold text-foreground mb-4">Behavioral Analysis</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div>
              <p className="text-xs text-muted-foreground mb-1">Click Events</p>
              <p className="text-sm text-foreground">{behavioralSignals.clickPatterns.length}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Keyboard Speed</p>
              <p className="text-sm text-foreground">{behavioralSignals.keyboardSpeed} WPM</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Scroll Behavior</p>
              <p className="text-sm text-foreground capitalize">{behavioralSignals.scrollBehavior}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Error Recovery</p>
              <p className="text-sm text-foreground capitalize">{behavioralSignals.errorRecovery}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Help Seeking</p>
              <p className="text-sm text-foreground">{behavioralSignals.helpSeekingBehavior ? "Yes" : "No"}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Neurodivergent Profile</p>
              <p className="text-sm text-foreground capitalize">{profile.neurodivergentProfile}</p>
            </div>
          </div>
        </Card>

        {/* Controls */}
        <Card className="glass-panel border-[#FF3131]/30 p-6">
          <h3 className="font-semibold text-foreground mb-4">Test Controls</h3>
          <div className="flex flex-wrap gap-3">
            <Button onClick={() => handleSimulateEvent("click")} variant="outline" size="sm">
              Simulate Click
            </Button>
            <Button onClick={() => handleSimulateEvent("keypress")} variant="outline" size="sm">
              Simulate Keypress
            </Button>
            <Button onClick={() => handleSimulateEvent("scroll")} variant="outline" size="sm">
              Simulate Scroll
            </Button>
            <Button onClick={() => handleSimulateEvent("error")} variant="outline" size="sm">
              Simulate Error
            </Button>
            <Button onClick={() => handleSimulateEvent("help")} variant="outline" size="sm">
              Simulate Help Request
            </Button>
            <Button onClick={handleReset} variant="destructive" size="sm" className="ml-auto">
              <RefreshCw className="w-4 h-4 mr-2" />
              Reset NEURO
            </Button>
          </div>
        </Card>

        {/* How It Works */}
        <Card className="glass-panel border-border p-6">
          <h3 className="font-semibold text-foreground mb-4">How NEURO Adapts</h3>
          <div className="space-y-3 text-sm text-muted-foreground">
            <p>
              <span className="text-[#00FFFF] font-semibold">Human NEURO:</span> Learning environments, hub navigation,
              general support
            </p>
            <p>
              <span className="text-[#00FFFF] font-semibold">Digital NEURO:</span> Technical sections (CHAOS OS,
              Antigravity, Vision)
            </p>
            <p>
              <span className="text-[#00FFFF] font-semibold">Guardian NEURO:</span> Security contexts (Trust, Entity,
              FEN, Vault)
            </p>
            <p>
              <span className="text-[#00FFFF] font-semibold">Sovereign NEURO:</span> Creative environments (Akira,
              Creator systems)
            </p>
            <p className="pt-3 border-t border-border">
              NEURO continuously monitors your interactions to detect generational profile, neurodivergent patterns, and
              expertise level, adapting personality mode (Comfort, Instructor, Architect, Guide) to match your needs.
            </p>
          </div>
        </Card>
      </div>
    </ShellLayout>
  )
}
