"use client"

import { useState } from "react"
import { ShellLayout } from "@/components/shell-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Brain, Video, Twitter, Code, Loader2, Play, Sparkles } from "lucide-react"
import type { NeuroProfile, PersonalityMode } from "@/lib/neuro/types"

const AGENT_INFO = {
  gemini: {
    name: "Gemini",
    icon: Brain,
    color: "#4285F4",
    description: "Research & Structure - Step-by-step, comparisons, flowcharts",
  },
  sora: {
    name: "Sora",
    icon: Video,
    color: "#FF00FF",
    description: "Video Synthesis - Avatar videos, tutorials, intros",
  },
  grok: {
    name: "Grok",
    icon: Twitter,
    color: "#1DA1F2",
    description: "X Native / Social - Tweets, threads, memes, hooks",
  },
  codex: {
    name: "Codex",
    icon: Code,
    color: "#39FF14",
    description: "Core Brain - Domain logic, code, lore, technical depth",
  },
}

const SECTIONS = [
  { value: "hub", label: "Dashboard Hub" },
  { value: "chaos-os", label: "CHAOS OS" },
  { value: "creator-codex", label: "Creator Codex" },
  { value: "akira-codex", label: "Akira Codex" },
  { value: "neura-tax", label: "NEURA TAX" },
  { value: "trust-launcher", label: "Trust Launcher" },
  { value: "entity-formation", label: "Entity Formation" },
  { value: "antigravity", label: "Antigravity Engine" },
  { value: "vision", label: "Vision API" },
  { value: "swarms", label: "Swarms" },
  { value: "avatars", label: "Avatars" },
]

const MODES: { value: PersonalityMode; label: string }[] = [
  { value: "comfort", label: "Comfort (Beginner)" },
  { value: "instructor", label: "Instructor (Intermediate)" },
  { value: "architect", label: "Architect (Expert)" },
  { value: "guide", label: "Guide (Friendly)" },
]

export default function SwarmRouterPage() {
  const [question, setQuestion] = useState("")
  const [section, setSection] = useState("hub")
  const [mode, setMode] = useState<PersonalityMode>("guide")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<{
    decision: {
      useGemini: boolean
      useSora: boolean
      useGrok: boolean
      useCodex: boolean
      reasoning: string
      priority: string[]
    }
    response: {
      text: string
      videoUrl?: string
      social?: {
        tweet?: string
        thread?: string[]
        caption?: string
      }
      suggestedNextSteps: string[]
      agentsUsed: string[]
      processingTime: number
    }
  } | null>(null)

  const handleSubmit = async () => {
    if (!question.trim()) return

    setLoading(true)
    setResult(null)

    const profile: NeuroProfile = {
      avatarForm: "digital",
      personalityMode: mode,
      generationalProfile: "millennial",
      neurodivergentProfile: "unknown",
      adaptationReason: "manual selection",
      confidence: 80,
      frustrationLevel: 0,
      currentAvatar: "digital",
      prefers: {
        video: true,
        text: true,
        audio: false,
        simpleUi: mode === "comfort",
      },
    }

    try {
      const res = await fetch("/api/swarm/route", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question,
          profile,
          section,
          intent: "auto",
        }),
      })

      const data = await res.json()
      setResult(data)
    } catch (err) {
      console.error("Swarm router error:", err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <ShellLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-[#00FFFF] text-glow-cyan">SWARM ROUTER</h1>
          <p className="text-muted-foreground mt-1">
            Intelligent orchestration of Gemini, Sora, Grok, and Codex agents
          </p>
        </div>

        {/* Agent Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {Object.entries(AGENT_INFO).map(([key, agent]) => (
            <Card key={key} className="glass-panel border-[#00FFFF]/20">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center"
                    style={{ backgroundColor: `${agent.color}20` }}
                  >
                    <agent.icon className="w-5 h-5" style={{ color: agent.color }} />
                  </div>
                  <div>
                    <h3 className="font-semibold" style={{ color: agent.color }}>
                      {agent.name}
                    </h3>
                    <p className="text-xs text-muted-foreground">{agent.description}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Test Interface */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Input */}
          <Card className="glass-panel border-[#00FFFF]/20">
            <CardHeader>
              <CardTitle className="text-[#00FFFF]">Test Swarm Router</CardTitle>
              <CardDescription>Enter a question and see how the router decides which agents to use</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-muted-foreground mb-2 block">Section Context</label>
                  <Select value={section} onValueChange={setSection}>
                    <SelectTrigger className="bg-background/50 border-[#00FFFF]/30">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {SECTIONS.map((s) => (
                        <SelectItem key={s.value} value={s.value}>
                          {s.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground mb-2 block">Personality Mode</label>
                  <Select value={mode} onValueChange={(v) => setMode(v as PersonalityMode)}>
                    <SelectTrigger className="bg-background/50 border-[#00FFFF]/30">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {MODES.map((m) => (
                        <SelectItem key={m.value} value={m.value}>
                          {m.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="text-sm text-muted-foreground mb-2 block">Your Question</label>
                <Textarea
                  placeholder="e.g., 'Show me how to set up a trust' or 'What is the Antigravity Engine?'"
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  className="bg-background/50 border-[#00FFFF]/30 min-h-[120px]"
                />
              </div>

              <Button
                onClick={handleSubmit}
                disabled={loading || !question.trim()}
                className="w-full bg-[#00FFFF]/20 hover:bg-[#00FFFF]/30 text-[#00FFFF] border border-[#00FFFF]/50"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Routing to Swarm...
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Execute Swarm Route
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Results */}
          <Card className="glass-panel border-[#00FFFF]/20">
            <CardHeader>
              <CardTitle className="text-[#00FFFF]">Routing Decision</CardTitle>
              <CardDescription>See which agents were selected and why</CardDescription>
            </CardHeader>
            <CardContent>
              {!result ? (
                <div className="flex items-center justify-center h-[300px] text-muted-foreground">
                  <div className="text-center">
                    <Sparkles className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Enter a question to see the routing decision</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Agents Used */}
                  <div>
                    <h4 className="text-sm font-medium mb-2">Agents Selected</h4>
                    <div className="flex flex-wrap gap-2">
                      {Object.entries(AGENT_INFO).map(([key, agent]) => {
                        const isUsed =
                          result.decision[
                            `use${key.charAt(0).toUpperCase() + key.slice(1)}` as keyof typeof result.decision
                          ]
                        return (
                          <Badge
                            key={key}
                            variant={isUsed ? "default" : "outline"}
                            style={{
                              backgroundColor: isUsed ? `${agent.color}30` : "transparent",
                              borderColor: agent.color,
                              color: isUsed ? agent.color : "#666",
                            }}
                          >
                            <agent.icon className="w-3 h-3 mr-1" />
                            {agent.name}
                          </Badge>
                        )
                      })}
                    </div>
                  </div>

                  {/* Reasoning */}
                  <div>
                    <h4 className="text-sm font-medium mb-2">Routing Reasoning</h4>
                    <p className="text-sm text-muted-foreground bg-background/50 p-3 rounded-lg">
                      {result.decision.reasoning}
                    </p>
                  </div>

                  {/* Processing Time */}
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Badge variant="outline" className="border-[#39FF14]/50 text-[#39FF14]">
                      {result.response.processingTime}ms
                    </Badge>
                    <span>processing time</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Response Output */}
        {result && (
          <Card className="glass-panel border-[#00FFFF]/20">
            <CardHeader>
              <CardTitle className="text-[#00FFFF]">Swarm Response</CardTitle>
              <CardDescription>Combined output from {result.response.agentsUsed.join(", ")}</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="text">
                <TabsList className="bg-background/50">
                  <TabsTrigger value="text">Text Response</TabsTrigger>
                  {result.response.videoUrl && <TabsTrigger value="video">Video</TabsTrigger>}
                  {result.response.social && <TabsTrigger value="social">Social</TabsTrigger>}
                  <TabsTrigger value="next">Next Steps</TabsTrigger>
                </TabsList>

                <TabsContent value="text" className="mt-4">
                  <div className="bg-background/50 p-4 rounded-lg whitespace-pre-wrap text-sm">
                    {result.response.text}
                  </div>
                </TabsContent>

                {result.response.videoUrl && (
                  <TabsContent value="video" className="mt-4">
                    <div className="bg-background/50 p-4 rounded-lg">
                      <p className="text-sm text-muted-foreground mb-2">Video URL:</p>
                      <code className="text-xs text-[#00FFFF]">{result.response.videoUrl}</code>
                    </div>
                  </TabsContent>
                )}

                {result.response.social && (
                  <TabsContent value="social" className="mt-4 space-y-4">
                    {result.response.social.tweet && (
                      <div className="bg-background/50 p-4 rounded-lg">
                        <h4 className="text-sm font-medium text-[#1DA1F2] mb-2">Tweet</h4>
                        <p className="text-sm">{result.response.social.tweet}</p>
                      </div>
                    )}
                    {result.response.social.thread && (
                      <div className="bg-background/50 p-4 rounded-lg">
                        <h4 className="text-sm font-medium text-[#1DA1F2] mb-2">Thread</h4>
                        <div className="space-y-2">
                          {result.response.social.thread.map((tweet, i) => (
                            <p key={i} className="text-sm border-l-2 border-[#1DA1F2]/30 pl-3">
                              {tweet}
                            </p>
                          ))}
                        </div>
                      </div>
                    )}
                  </TabsContent>
                )}

                <TabsContent value="next" className="mt-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {result.response.suggestedNextSteps.map((step, i) => (
                      <Button
                        key={i}
                        variant="outline"
                        className="justify-start border-[#00FFFF]/30 hover:bg-[#00FFFF]/10 bg-transparent"
                        onClick={() => setQuestion(step)}
                      >
                        {step}
                      </Button>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        )}
      </div>
    </ShellLayout>
  )
}
