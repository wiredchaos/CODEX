import { ShellLayout } from "@/components/shell-layout"
import { patchRegistry } from "@/lib/patches/registry"
import { agentRegistry } from "@/lib/registry/agents"
import { mcpRegistry } from "@/lib/registry/mcp-servers"
import { StatusPill } from "@/components/status-pill"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Boxes, Brain, Server, Clock } from "lucide-react"

export default function StatusPage() {
  const patches = patchRegistry.listPatches()
  const agents = agentRegistry.listAgents()
  const mcpServers = mcpRegistry.listMcpServers()

  return (
    <ShellLayout>
      <div className="space-y-6">
        <div className="space-y-2">
          <h1 className="text-2xl font-bold text-foreground">System Status</h1>
          <p className="text-muted-foreground">Overview of all systems and their current operational status</p>
        </div>

        {/* Patch Status */}
        <Card className="glass-panel border-[#00FFFF]/20">
          <CardHeader>
            <CardTitle className="text-lg text-foreground flex items-center gap-2">
              <Boxes className="w-5 h-5 text-[#00FFFF]" />
              Patch Modules
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {patches.map((patch) => (
                <div key={patch.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary/30">
                  <div className="flex items-center gap-3">
                    <span className="text-foreground">{patch.displayName}</span>
                    <span className="text-muted-foreground text-sm">({patch.category})</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <StatusPill status={patch.status} size="sm" />
                    <div className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      Just now
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Agent Status */}
        <Card className="glass-panel border-[#39FF14]/20">
          <CardHeader>
            <CardTitle className="text-lg text-foreground flex items-center gap-2">
              <Brain className="w-5 h-5 text-[#39FF14]" />
              SWARM Agents
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {agents.map((agent) => (
                <div key={agent.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary/30">
                  <div className="flex items-center gap-3">
                    <span className="text-foreground">{agent.name}</span>
                    <span className="text-muted-foreground text-sm">({agent.role})</span>
                  </div>
                  <StatusPill status={agent.isActive ? "online" : "offline"} size="sm" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* MCP Status */}
        <Card className="glass-panel border-[#FF00FF]/20">
          <CardHeader>
            <CardTitle className="text-lg text-foreground flex items-center gap-2">
              <Server className="w-5 h-5 text-[#FF00FF]" />
              MCP Servers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {mcpServers.map((server) => (
                <div key={server.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary/30">
                  <div className="flex items-center gap-3">
                    <span className="text-foreground">{server.name}</span>
                    <code className="text-muted-foreground text-xs font-mono">{server.baseUrl}</code>
                  </div>
                  <div className="flex items-center gap-3">
                    <StatusPill status={server.status} size="sm" />
                    {server.lastCheckedAt && (
                      <div className="text-xs text-muted-foreground flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(server.lastCheckedAt).toLocaleTimeString()}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </ShellLayout>
  )
}
