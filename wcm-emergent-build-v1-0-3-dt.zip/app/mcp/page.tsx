"use client"

import { useState } from "react"
import { ShellLayout } from "@/components/shell-layout"
import { mcpRegistry } from "@/lib/registry/mcp-servers"
import { StatusPill } from "@/components/status-pill"
import { TagChip } from "@/components/tag-chip"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Server, ChevronDown, ChevronUp, AlertTriangle } from "lucide-react"

export default function McpServersPage() {
  const servers = mcpRegistry.listMcpServers()
  const [expandedServer, setExpandedServer] = useState<string | null>(null)

  return (
    <ShellLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="space-y-2">
            <h1 className="text-2xl font-bold text-foreground">MCP Servers</h1>
            <p className="text-muted-foreground">Model Context Protocol servers and available tools</p>
          </div>
          <Button variant="outline" className="border-[#00FFFF]/30 text-[#00FFFF] hover:bg-[#00FFFF]/10 bg-transparent">
            Refresh Status
          </Button>
        </div>

        <div className="space-y-4">
          {servers.map((server) => {
            const tools = mcpRegistry.getToolsForServer(server.id)
            const isExpanded = expandedServer === server.id

            return (
              <Card key={server.id} className="glass-panel border-[#00FFFF]/20">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-lg bg-[#FF00FF]/10 flex items-center justify-center">
                        <Server className="w-6 h-6 text-[#FF00FF]" />
                      </div>
                      <div>
                        <CardTitle className="text-lg text-foreground">{server.name}</CardTitle>
                        <CardDescription className="font-mono text-xs">{server.baseUrl}</CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <StatusPill status={server.status} size="sm" />
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setExpandedServer(isExpanded ? null : server.id)}
                      >
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </Button>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-1.5 mt-3">
                    {server.categories.map((cat) => (
                      <TagChip key={cat} label={cat} variant="pink" />
                    ))}
                  </div>
                </CardHeader>

                {isExpanded && (
                  <CardContent className="border-t border-[#00FFFF]/10 pt-4">
                    <p className="text-sm text-muted-foreground mb-4">Available Tools ({tools.length})</p>
                    <div className="space-y-3">
                      {tools.map((tool) => (
                        <div key={tool.id} className="p-3 rounded-lg bg-secondary/30 border border-border">
                          <div className="flex items-start justify-between">
                            <div>
                              <code className="text-[#00FFFF] font-mono text-sm">{tool.name}</code>
                              <p className="text-sm text-muted-foreground mt-1">{tool.description}</p>
                            </div>
                            {tool.isDangerous && (
                              <div className="flex items-center gap-1 text-[#FF3131] text-xs">
                                <AlertTriangle className="w-3 h-3" />
                                Dangerous
                              </div>
                            )}
                          </div>
                          <div className="flex gap-2 mt-2">
                            <TagChip label={tool.category} variant="cyan" />
                            {tool.requiresApproval && <TagChip label="Requires Approval" variant="red" />}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                )}
              </Card>
            )
          })}
        </div>
      </div>
    </ShellLayout>
  )
}
