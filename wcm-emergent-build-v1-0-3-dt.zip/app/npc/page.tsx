"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, Gamepad2, Compass, Zap, MessageSquare } from "lucide-react"

export default function NPCPage() {
  const [session, setSession] = useState<any>(null)
  const [input, setInput] = useState("")
  const [interactions, setInteractions] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [modules, setModules] = useState<any[]>([])
  const [games, setGames] = useState<any[]>([])
  const [currentNode, setCurrentNode] = useState<any>(null)

  useEffect(() => {
    // Initialize NPC session
    initSession()
    loadModules()
    loadGames()
    loadLabyrinthNode("entrance")
  }, [])

  const initSession = async () => {
    try {
      const res = await fetch("/api/npc/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: "demo_user",
          userProfile: {
            detectedExpertise: "intermediate",
            currentSection: "npc",
            preferredLearningStyle: "balanced",
          },
        }),
      })
      const data = await res.json()
      setSession(data.session)
    } catch (error) {
      console.error("Failed to initialize session:", error)
    }
  }

  const loadModules = async () => {
    try {
      const res = await fetch("/api/npc/modules")
      const data = await res.json()
      setModules(data.modules || [])
    } catch (error) {
      console.error("Failed to load modules:", error)
    }
  }

  const loadGames = async () => {
    try {
      const res = await fetch("/api/npc/games")
      const data = await res.json()
      setGames(data.games || [])
    } catch (error) {
      console.error("Failed to load games:", error)
    }
  }

  const loadLabyrinthNode = async (nodeId: string) => {
    try {
      const res = await fetch(`/api/npc/labyrinth?nodeId=${nodeId}`)
      const data = await res.json()
      setCurrentNode(data.node)
    } catch (error) {
      console.error("Failed to load labyrinth node:", error)
    }
  }

  const handleInteract = async () => {
    if (!input.trim() || !session) return

    setLoading(true)
    try {
      const res = await fetch("/api/npc/interact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionId: session.id,
          userInput: input,
          session,
        }),
      })
      const data = await res.json()

      if (data.success) {
        setInteractions([data.interaction, ...interactions])
        setInput("")

        // Update session progress
        if (data.interaction.xpAwarded) {
          setSession({
            ...session,
            progress: {
              ...session.progress,
              totalXP: session.progress.totalXP + data.interaction.xpAwarded,
            },
          })
        }
      }
    } catch (error) {
      console.error("Interaction failed:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleLabyrinthChoice = async (optionId: string, nextNodeId: string) => {
    try {
      const res = await fetch("/api/npc/labyrinth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nodeId: currentNode.id,
          optionId,
          userProgress: session?.progress || {},
        }),
      })
      const data = await res.json()

      if (data.success && data.nextNode) {
        setCurrentNode(data.nextNode)
      }
    } catch (error) {
      console.error("Failed to navigate labyrinth:", error)
    }
  }

  if (!session) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-cyan-400">Initializing NPC General...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-pink-500 bg-clip-text text-transparent">
              NPC GENERAL SYSTEM
            </h1>
            <p className="text-muted-foreground mt-2">Education • Games • Labyrinth Navigation</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-sm text-muted-foreground">XP</div>
              <div className="text-2xl font-bold text-cyan-400">{session.progress.totalXP}</div>
            </div>
            <div className="text-right">
              <div className="text-sm text-muted-foreground">Level</div>
              <div className="text-2xl font-bold text-pink-500">{session.progress.level}</div>
            </div>
          </div>
        </div>

        {/* Session Info */}
        <Card className="p-4 bg-black/40 border-cyan-500/20">
          <div className="flex items-center gap-6">
            <div>
              <span className="text-sm text-muted-foreground">Role:</span>
              <Badge className="ml-2 bg-cyan-500/20 text-cyan-400 border-cyan-500/30">{session.npcRole}</Badge>
            </div>
            <div>
              <span className="text-sm text-muted-foreground">Mode:</span>
              <Badge className="ml-2 bg-pink-500/20 text-pink-400 border-pink-500/30">{session.mode}</Badge>
            </div>
            <div>
              <span className="text-sm text-muted-foreground">Progress:</span>
              <span className="ml-2 text-sm">
                {session.progress.modulesCompleted} modules • {session.progress.gamesWon} games •{" "}
                {session.progress.badges.length} badges
              </span>
            </div>
          </div>
        </Card>
      </div>

      <Tabs defaultValue="interact" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 bg-black/40 border border-cyan-500/20">
          <TabsTrigger
            value="interact"
            className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
          >
            <MessageSquare className="w-4 h-4 mr-2" />
            Interact
          </TabsTrigger>
          <TabsTrigger
            value="education"
            className="data-[state=active]:bg-green-500/20 data-[state=active]:text-green-400"
          >
            <BookOpen className="w-4 h-4 mr-2" />
            Education
          </TabsTrigger>
          <TabsTrigger value="games" className="data-[state=active]:bg-pink-500/20 data-[state=active]:text-pink-400">
            <Gamepad2 className="w-4 h-4 mr-2" />
            Games
          </TabsTrigger>
          <TabsTrigger
            value="labyrinth"
            className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400"
          >
            <Compass className="w-4 h-4 mr-2" />
            Labyrinth
          </TabsTrigger>
        </TabsList>

        {/* Interact Tab */}
        <TabsContent value="interact" className="space-y-4">
          <Card className="p-6 bg-black/40 border-cyan-500/20">
            <div className="space-y-4">
              <div className="flex gap-2">
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleInteract()}
                  placeholder="Ask NEURO General anything..."
                  className="flex-1 bg-black/60 border-cyan-500/30"
                />
                <Button
                  onClick={handleInteract}
                  disabled={loading || !input.trim()}
                  className="bg-cyan-500 hover:bg-cyan-600"
                >
                  {loading ? "Processing..." : "Send"}
                </Button>
              </div>

              {/* Interaction History */}
              <div className="space-y-3 max-h-[500px] overflow-y-auto">
                {interactions.map((interaction) => (
                  <div key={interaction.id} className="space-y-2">
                    <div className="flex justify-end">
                      <div className="bg-cyan-500/20 border border-cyan-500/30 rounded-lg px-4 py-2 max-w-[70%]">
                        <p className="text-sm">{interaction.userInput}</p>
                      </div>
                    </div>
                    <div className="flex justify-start">
                      <div className="bg-pink-500/20 border border-pink-500/30 rounded-lg px-4 py-2 max-w-[70%]">
                        <p className="text-sm">{interaction.npcResponse}</p>
                        {interaction.xpAwarded && (
                          <div className="flex items-center gap-2 mt-2 text-xs text-green-400">
                            <Zap className="w-3 h-3" />+{interaction.xpAwarded} XP
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Education Tab */}
        <TabsContent value="education" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {modules.map((module) => (
              <Card
                key={module.id}
                className="p-4 bg-black/40 border-green-500/20 hover:border-green-500/50 transition-colors"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between">
                    <BookOpen className="w-5 h-5 text-green-400" />
                    <Badge className="bg-green-500/20 text-green-400 border-green-500/30">{module.difficulty}</Badge>
                  </div>
                  <div>
                    <h3 className="font-semibold text-green-400">{module.title}</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      {module.category} • {module.duration} min
                    </p>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-green-400">+{module.xpReward} XP</span>
                    <Button size="sm" className="bg-green-500 hover:bg-green-600">
                      Start
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Games Tab */}
        <TabsContent value="games" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {games.map((game) => (
              <Card
                key={game.key}
                className="p-6 bg-black/40 border-pink-500/20 hover:border-pink-500/50 transition-colors"
              >
                <div className="flex items-start justify-between mb-4">
                  <Gamepad2 className="w-6 h-6 text-pink-400" />
                  <Badge className="bg-pink-500/20 text-pink-400 border-pink-500/30">{game.type}</Badge>
                </div>
                <h3 className="font-semibold text-pink-400 text-lg mb-2">{game.title}</h3>
                <Button className="w-full bg-pink-500 hover:bg-pink-600">Play Now</Button>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Labyrinth Tab */}
        <TabsContent value="labyrinth" className="space-y-4">
          {currentNode && (
            <Card className="p-6 bg-black/40 border-purple-500/20">
              <div className="space-y-6">
                <div>
                  <Badge className="mb-2 bg-purple-500/20 text-purple-400 border-purple-500/30">
                    {currentNode.type}
                  </Badge>
                  <h2 className="text-2xl font-bold text-purple-400 mb-2">{currentNode.title}</h2>
                  <p className="text-muted-foreground">{currentNode.description}</p>
                </div>

                <div className="space-y-3">
                  {currentNode.options.map((option: any) => (
                    <Button
                      key={option.id}
                      onClick={() => handleLabyrinthChoice(option.id, option.nextNodeId)}
                      className="w-full justify-start text-left h-auto py-4 bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span>{option.text}</span>
                          <Badge
                            className={`ml-auto ${
                              option.risk === "safe"
                                ? "bg-green-500/20 text-green-400 border-green-500/30"
                                : option.risk === "moderate"
                                  ? "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
                                  : "bg-red-500/20 text-red-400 border-red-500/30"
                            }`}
                          >
                            {option.risk}
                          </Badge>
                        </div>
                        {option.requirement && (
                          <div className="text-xs text-muted-foreground">
                            Requires: {option.requirement.type} {option.requirement.value}
                          </div>
                        )}
                      </div>
                    </Button>
                  ))}
                </div>
              </div>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
