"use client"

import { useState } from "react"
import { ShellLayout } from "@/components/shell-layout"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { User, Eye, Bell, Save } from "lucide-react"

export default function SettingsPage() {
  const [showExperimental, setShowExperimental] = useState(false)
  const [notifications, setNotifications] = useState(true)

  return (
    <ShellLayout>
      <div className="space-y-6 max-w-2xl">
        <div className="space-y-2">
          <h1 className="text-2xl font-bold text-foreground">Settings</h1>
          <p className="text-muted-foreground">Manage your profile and environment preferences</p>
        </div>

        {/* Profile */}
        <Card className="glass-panel border-[#00FFFF]/20">
          <CardHeader>
            <CardTitle className="text-lg text-foreground flex items-center gap-2">
              <User className="w-5 h-5 text-[#00FFFF]" />
              Profile
            </CardTitle>
            <CardDescription>Your account information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Display Name</Label>
              <Input
                id="name"
                placeholder="Your name"
                defaultValue="CHAOS Operator"
                className="bg-secondary/50 border-border"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" placeholder="you@example.com" className="bg-secondary/50 border-border" />
            </div>
          </CardContent>
        </Card>

        {/* Visibility */}
        <Card className="glass-panel border-[#00FFFF]/20">
          <CardHeader>
            <CardTitle className="text-lg text-foreground flex items-center gap-2">
              <Eye className="w-5 h-5 text-[#00FFFF]" />
              Visibility
            </CardTitle>
            <CardDescription>Control what patches and features you see</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Show Experimental Patches</Label>
                <p className="text-sm text-muted-foreground">Display patches that are still in development</p>
              </div>
              <Switch checked={showExperimental} onCheckedChange={setShowExperimental} />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Show Coming Soon</Label>
                <p className="text-sm text-muted-foreground">Display patches that are planned but not yet available</p>
              </div>
              <Switch defaultChecked />
            </div>
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card className="glass-panel border-[#00FFFF]/20">
          <CardHeader>
            <CardTitle className="text-lg text-foreground flex items-center gap-2">
              <Bell className="w-5 h-5 text-[#00FFFF]" />
              Notifications
            </CardTitle>
            <CardDescription>Configure how you receive updates</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>System Notifications</Label>
                <p className="text-sm text-muted-foreground">Receive alerts about system status changes</p>
              </div>
              <Switch checked={notifications} onCheckedChange={setNotifications} />
            </div>
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Task Completion</Label>
                <p className="text-sm text-muted-foreground">Get notified when tasks finish executing</p>
              </div>
              <Switch defaultChecked />
            </div>
          </CardContent>
        </Card>

        <Button className="bg-[#39FF14]/20 text-[#39FF14] hover:bg-[#39FF14]/30 border border-[#39FF14]/30">
          <Save className="w-4 h-4 mr-2" />
          Save Settings
        </Button>
      </div>
    </ShellLayout>
  )
}
