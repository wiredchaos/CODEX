export default function TrinityLobbyLoading() {
  return (
    <div className="flex h-screen items-center justify-center bg-black">
      <div className="space-y-4 text-center">
        <div className="h-16 w-16 animate-spin rounded-full border-4 border-cyan-500 border-t-transparent mx-auto trinity-loading" />
        <p className="text-cyan-400 text-sm font-mono">INITIALIZING TRINITY CORE...</p>
        <p className="text-muted-foreground text-xs font-mono">Read-Only Environment Mount</p>
      </div>
    </div>
  )
}
