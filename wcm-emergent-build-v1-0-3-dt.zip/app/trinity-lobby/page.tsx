"use client"

import { EnvironmentRenderer } from "@/components/trinity-environment-renderer"
import { useRouter } from "next/navigation"

export default function TrinityLobbyPage() {
  const router = useRouter()

  function handleHotspotClick(hotspotId: string) {
    console.log("[v0] Trinity hotspot clicked:", hotspotId)

    if (hotspotId === "exit") {
      router.push("/trinity-mount")
    }
  }

  return (
    <div className="h-screen w-screen">
      <EnvironmentRenderer patchId="CLEAR" kind="lobby" onHotspotClick={handleHotspotClick} />
    </div>
  )
}
