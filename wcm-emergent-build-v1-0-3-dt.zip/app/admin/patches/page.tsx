"use client"

import type React from "react"

import { useState } from "react"
import { ShellLayout } from "@/components/shell-layout"
import { patchRegistry } from "@/lib/patches/registry"
import { StatusPill } from "@/components/status-pill"
import { TagChip } from "@/components/tag-chip"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Plus, Pencil, Trash2, Shield } from "lucide-react"
import type { PatchModule, PatchStatus } from "@/lib/patches/types"

export default function AdminPatchesPage() {
  const patches = patchRegistry.listPatches()
  const [editingPatch, setEditingPatch] = useState<PatchModule | null>(null)
  const [isCreateOpen, setIsCreateOpen] = useState(false)

  return (
    <ShellLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="space-y-2">
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <Shield className="w-6 h-6 text-[#FF3131]" />
              Admin: Patch Manager
            </h1>
            <p className="text-muted-foreground">Create, edit, and manage patch module configurations</p>
          </div>
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="bg-[#39FF14]/20 text-[#39FF14] hover:bg-[#39FF14]/30 border border-[#39FF14]/30">
                <Plus className="w-4 h-4 mr-2" />
                New Patch
              </Button>
            </DialogTrigger>
            <DialogContent className="glass-panel border-[#00FFFF]/20 bg-background">
              <DialogHeader>
                <DialogTitle>Create New Patch</DialogTitle>
              </DialogHeader>
              <PatchForm onClose={() => setIsCreateOpen(false)} />
            </DialogContent>
          </Dialog>
        </div>

        {/* Patch List */}
        <Card className="glass-panel border-[#00FFFF]/20">
          <CardHeader>
            <CardTitle className="text-lg text-foreground">All Patches ({patches.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {patches.map((patch) => (
                <div
                  key={patch.id}
                  className="flex items-center justify-between p-4 rounded-lg bg-secondary/30 border border-border"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-3">
                      <span className="font-medium text-foreground">{patch.displayName}</span>
                      <code className="text-xs text-muted-foreground font-mono">{patch.key}</code>
                      <StatusPill status={patch.status} size="sm" />
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">{patch.description}</p>
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {patch.capabilities.slice(0, 4).map((cap) => (
                        <TagChip key={cap} label={cap} variant="cyan" />
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setEditingPatch(patch)}
                          className="text-muted-foreground hover:text-foreground"
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="glass-panel border-[#00FFFF]/20 bg-background">
                        <DialogHeader>
                          <DialogTitle>Edit Patch: {patch.displayName}</DialogTitle>
                        </DialogHeader>
                        <PatchForm patch={patch} onClose={() => setEditingPatch(null)} />
                      </DialogContent>
                    </Dialog>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-[#FF3131] hover:text-[#FF3131] hover:bg-[#FF3131]/10"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </ShellLayout>
  )
}

function PatchForm({ patch, onClose }: { patch?: PatchModule; onClose: () => void }) {
  const [formData, setFormData] = useState({
    key: patch?.key || "",
    displayName: patch?.displayName || "",
    slug: patch?.slug || "",
    description: patch?.description || "",
    category: patch?.category || "",
    status: patch?.status || ("coming_soon" as PatchStatus),
    appBaseUrl: patch?.appBaseUrl || "",
    docsUrl: patch?.docsUrl || "",
    capabilities: patch?.capabilities.join(", ") || "",
    requiresAuth: patch?.requiresAuth ?? true,
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real app, this would save to the database
    console.log("Saving patch:", formData)
    onClose()
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="key">Key</Label>
          <Input
            id="key"
            value={formData.key}
            onChange={(e) => setFormData({ ...formData, key: e.target.value })}
            placeholder="PATCH_KEY"
            className="bg-secondary/50 border-border font-mono"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="slug">Slug</Label>
          <Input
            id="slug"
            value={formData.slug}
            onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
            placeholder="patch-slug"
            className="bg-secondary/50 border-border"
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="displayName">Display Name</Label>
        <Input
          id="displayName"
          value={formData.displayName}
          onChange={(e) => setFormData({ ...formData, displayName: e.target.value })}
          placeholder="Patch Name"
          className="bg-secondary/50 border-border"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          placeholder="What does this patch do?"
          className="bg-secondary/50 border-border"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="category">Category</Label>
          <Input
            id="category"
            value={formData.category}
            onChange={(e) => setFormData({ ...formData, category: e.target.value })}
            placeholder="Story Engine"
            className="bg-secondary/50 border-border"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="status">Status</Label>
          <select
            id="status"
            value={formData.status}
            onChange={(e) => setFormData({ ...formData, status: e.target.value as PatchStatus })}
            className="w-full px-3 py-2 rounded-md bg-secondary/50 border border-border text-sm"
          >
            <option value="online">Online</option>
            <option value="degraded">Degraded</option>
            <option value="offline">Offline</option>
            <option value="coming_soon">Coming Soon</option>
          </select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="appBaseUrl">App Base URL</Label>
        <Input
          id="appBaseUrl"
          value={formData.appBaseUrl}
          onChange={(e) => setFormData({ ...formData, appBaseUrl: e.target.value })}
          placeholder="https://app.example.com"
          className="bg-secondary/50 border-border"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="capabilities">Capabilities (comma-separated)</Label>
        <Input
          id="capabilities"
          value={formData.capabilities}
          onChange={(e) => setFormData({ ...formData, capabilities: e.target.value })}
          placeholder="story_graph, missions, arg"
          className="bg-secondary/50 border-border"
        />
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button type="button" variant="outline" onClick={onClose}>
          Cancel
        </Button>
        <Button
          type="submit"
          className="bg-[#39FF14]/20 text-[#39FF14] hover:bg-[#39FF14]/30 border border-[#39FF14]/30"
        >
          {patch ? "Save Changes" : "Create Patch"}
        </Button>
      </div>
    </form>
  )
}
