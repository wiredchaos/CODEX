"use client"

import { useState } from "react"
import { Eye, Loader2, Sparkles, Layout, Film, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { HologramOverlay } from "@/components/hologram-overlay"
import type { VisionResult, VisionMode } from "@/lib/vision/types"

const MODES: { key: VisionMode; label: string; icon: typeof Eye; description: string }[] = [
  { key: "blueprint", label: "Blueprint", icon: Layout, description: "Generate structured UI layouts" },
  { key: "full", label: "Full Analysis", icon: Search, description: "Analyze images and content" },
  { key: "ttv_prep", label: "TTV Prep", icon: Film, description: "Prepare for text-to-video" },
]

const PERSONAS = [
  { key: "architect", label: "Architect", description: "UI/UX structure expert" },
  { key: "artist", label: "Artist", description: "Creative visionary" },
  { key: "analyst", label: "Analyst", description: "Data extraction specialist" },
  { key: "director", label: "Director", description: "Video production lead" },
]

export default function VisionPage() {
  const [prompt, setPrompt] = useState("")
  const [mode, setMode] = useState<VisionMode>("blueprint")
  const [persona, setPersona] = useState("architect")
  const [isLoading, setIsLoading] = useState(false)
  const [result, setResult] = useState<VisionResult | null>(null)
  const [showOverlay, setShowOverlay] = useState(false)

  async function handleSubmit() {
    if (!prompt.trim()) return

    setIsLoading(true)
    setShowOverlay(true)

    try {
      const response = await fetch("/api/vision/ask", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, mode, persona }),
      })

      const data = await response.json()
      setResult(data.result)
    } catch (error) {
      setResult({ error: "Failed to process vision request" })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="p-3 rounded-lg bg-cyan-500/20 border border-cyan-500/30">
          <Eye className="w-6 h-6 text-cyan-400" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">GIGA MAX Vision</h1>
          <p className="text-gray-400">Multi-modal vision engine with Blueprint Mode</p>
        </div>
      </div>

      {/* Mode Selection */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {MODES.map((m) => {
          const Icon = m.icon
          const isActive = mode === m.key
          return (
            <button
              key={m.key}
              onClick={() => setMode(m.key)}
              className={`p-4 rounded-lg border text-left transition-all ${
                isActive ? "bg-cyan-500/20 border-cyan-500/50" : "bg-gray-900/50 border-gray-700 hover:border-gray-600"
              }`}
            >
              <div className="flex items-center gap-2 mb-2">
                <Icon className={`w-5 h-5 ${isActive ? "text-cyan-400" : "text-gray-400"}`} />
                <span className={`font-medium ${isActive ? "text-cyan-400" : "text-white"}`}>{m.label}</span>
              </div>
              <p className="text-sm text-gray-400">{m.description}</p>
            </button>
          )
        })}
      </div>

      {/* Persona Selection */}
      <div>
        <h3 className="text-sm font-medium text-gray-400 mb-3">SELECT PERSONA</h3>
        <div className="flex flex-wrap gap-2">
          {PERSONAS.map((p) => (
            <button
              key={p.key}
              onClick={() => setPersona(p.key)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                persona === p.key
                  ? "bg-purple-500/20 border border-purple-500/50 text-purple-400"
                  : "bg-gray-800 border border-gray-700 text-gray-300 hover:border-gray-600"
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* Prompt Input */}
      <div className="space-y-4">
        <div className="relative">
          <Textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe what you want to visualize or analyze..."
            className="min-h-[120px] bg-gray-900/50 border-gray-700 text-white placeholder:text-gray-500 resize-none"
          />
          <div className="absolute bottom-3 right-3 flex items-center gap-2">
            <span className="text-xs text-gray-500">{prompt.length} chars</span>
          </div>
        </div>

        <Button
          onClick={handleSubmit}
          disabled={!prompt.trim() || isLoading}
          className="w-full bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Processing...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 mr-2" />
              Generate Vision
            </>
          )}
        </Button>
      </div>

      {/* Status Card */}
      <div className="bg-gray-900/50 border border-gray-700 rounded-lg p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-sm text-gray-400">GIGA MAX Engine Status</span>
          </div>
          <span className="text-green-400 text-sm font-mono">ONLINE</span>
        </div>
        <div className="mt-3 grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-2xl font-bold text-white">3</p>
            <p className="text-xs text-gray-500">Modes</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-white">4</p>
            <p className="text-xs text-gray-500">Personas</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-cyan-400">v1.0</p>
            <p className="text-xs text-gray-500">Version</p>
          </div>
        </div>
      </div>

      {/* Hologram Overlay */}
      <HologramOverlay
        isOpen={showOverlay}
        onClose={() => setShowOverlay(false)}
        result={result || undefined}
        isLoading={isLoading}
      />
    </div>
  )
}
