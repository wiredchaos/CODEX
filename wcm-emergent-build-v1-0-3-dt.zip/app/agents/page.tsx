import type React from "react"
import { ShellLayout } from "@/components/shell-layout"
import { agentRegistry } from "@/lib/registry/agents"
import { StatusPill } from "@/components/status-pill"
import { TagChip } from "@/components/tag-chip"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Brain, Cpu, FileText, Calculator, Shield, Gamepad2 } from "lucide-react"

const iconMap: Record<string, React.ElementType> = {
  Architect: Cpu,
  "Tax Strategist": Calculator,
  "Documentation Specialist": FileText,
  "Estate Planner": Shield,
  "Prompt Coach": Gamepad2,
}

export default function AgentsPage() {
  const agents = agentRegistry.listAgents()

  return (
    <ShellLayout>
      <div className="space-y-6">
        <div className="space-y-2">
          <h1 className="text-2xl font-bold text-foreground">SWARM Agents</h1>
          <p className="text-muted-foreground">AI agents available for task orchestration and automation</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {agents.map((agent) => {
            const Icon = iconMap[agent.role] || Brain
            return (
              <Card key={agent.id} className="glass-panel border-[#00FFFF]/20">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="w-12 h-12 rounded-lg bg-[#39FF14]/10 flex items-center justify-center">
                      <Icon className="w-6 h-6 text-[#39FF14]" />
                    </div>
                    <StatusPill status={agent.isActive ? "online" : "offline"} size="sm" />
                  </div>
                  <CardTitle className="text-lg text-foreground mt-3">{agent.name}</CardTitle>
                  <CardDescription>{agent.role}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">{agent.description}</p>
                  <div>
                    <p className="text-xs text-muted-foreground mb-2">Capabilities</p>
                    <div className="flex flex-wrap gap-1.5">
                      {agent.capabilities.map((cap) => (
                        <TagChip key={cap} label={cap} variant="green" />
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-2">Preferred MCP Tools</p>
                    <div className="flex flex-wrap gap-1.5">
                      {agent.mcpToolPrefs.map((pref) => (
                        <TagChip key={pref} label={pref} variant="cyan" />
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </ShellLayout>
  )
}
