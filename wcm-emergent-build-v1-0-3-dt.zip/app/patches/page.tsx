"use client"

import { useState } from "react"
import { ShellLayout } from "@/components/shell-layout"
import { PatchCard } from "@/components/patch-card"
import { patchRegistry } from "@/lib/patches/registry"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search } from "lucide-react"
import type { PatchStatus } from "@/lib/patches/types"

export default function PatchesPage() {
  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState<PatchStatus | "all">("all")
  const [categoryFilter, setCategoryFilter] = useState<string | "all">("all")

  const patches = patchRegistry.listPatches()
  const categories = patchRegistry.getCategories()

  const filteredPatches = patches.filter((patch) => {
    const matchesSearch =
      search === "" ||
      patch.displayName.toLowerCase().includes(search.toLowerCase()) ||
      patch.capabilities.some((c) => c.toLowerCase().includes(search.toLowerCase()))

    const matchesStatus = statusFilter === "all" || patch.status === statusFilter
    const matchesCategory = categoryFilter === "all" || patch.category === categoryFilter

    return matchesSearch && matchesStatus && matchesCategory
  })

  return (
    <ShellLayout>
      <div className="space-y-6">
        <div className="space-y-2">
          <h1 className="text-2xl font-bold text-foreground">All Patches</h1>
          <p className="text-muted-foreground">Browse and manage all patch modules in the system</p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4">
          <div className="relative flex-1 min-w-[200px] max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search patches..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 bg-secondary/50 border-border"
            />
          </div>

          <div className="flex gap-2">
            {(["all", "online", "degraded", "offline", "coming_soon"] as const).map((status) => (
              <Button
                key={status}
                variant={statusFilter === status ? "default" : "outline"}
                size="sm"
                onClick={() => setStatusFilter(status)}
                className={
                  statusFilter === status ? "bg-[#00FFFF]/20 text-[#00FFFF] border-[#00FFFF]/30" : "border-border"
                }
              >
                {status === "all" ? "All" : status.replace("_", " ")}
              </Button>
            ))}
          </div>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-2 rounded-md bg-secondary/50 border border-border text-sm"
          >
            <option value="all">All Categories</option>
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>

        {/* Results */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredPatches.map((patch) => (
            <PatchCard key={patch.id} patch={patch} />
          ))}
        </div>

        {filteredPatches.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">No patches found matching your criteria</div>
        )}
      </div>
    </ShellLayout>
  )
}
