import type React from "react"
import { notFound } from "next/navigation"
import Link from "next/link"
import { ShellLayout } from "@/components/shell-layout"
import { StatusPill } from "@/components/status-pill"
import { TagChip } from "@/components/tag-chip"
import { patchRegistry } from "@/lib/patches/registry"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, ExternalLink, FileText, Scroll, PenTool, Brain, Calculator, Shield, Gem } from "lucide-react"

const iconMap: Record<string, React.ElementType> = {
  scroll: Scroll,
  "pen-tool": PenTool,
  brain: Brain,
  calculator: Calculator,
  shield: Shield,
  gem: Gem,
}

interface PageProps {
  params: Promise<{ slug: string }>
}

export default async function PatchDetailPage({ params }: PageProps) {
  const { slug } = await params
  const patch = patchRegistry.getPatchBySlug(slug)

  if (!patch) {
    notFound()
  }

  const Icon = patch.icon ? iconMap[patch.icon] || FileText : FileText

  return (
    <ShellLayout>
      <div className="space-y-6 max-w-4xl">
        {/* Back link */}
        <Link
          href="/patches"
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Patches
        </Link>

        {/* Header */}
        <div className="flex items-start gap-6">
          <div
            className="w-20 h-20 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ backgroundColor: `${patch.primaryColor}15` }}
          >
            <Icon className="w-10 h-10" style={{ color: patch.primaryColor }} />
          </div>
          <div className="space-y-2 flex-1">
            <div className="flex items-center gap-3">
              <h1 className="text-3xl font-bold text-foreground">{patch.displayName}</h1>
              <StatusPill status={patch.status} />
            </div>
            <p className="text-muted-foreground">{patch.category}</p>
            <p className="text-foreground">{patch.description}</p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3">
          {patch.status === "online" ? (
            <>
              <Button
                asChild
                className="bg-[#39FF14]/20 text-[#39FF14] hover:bg-[#39FF14]/30 border border-[#39FF14]/30"
              >
                <a href={patch.appBaseUrl} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Launch Module
                </a>
              </Button>
              <Button
                asChild
                variant="outline"
                className="border-[#00FFFF]/30 text-[#00FFFF] hover:bg-[#00FFFF]/10 bg-transparent"
              >
                <a href={`/api/patches/${patch.key}/handshake`}>Open in Shell</a>
              </Button>
            </>
          ) : (
            <Button disabled variant="outline">
              {patch.status === "coming_soon" ? "Coming Soon" : "Currently Unavailable"}
            </Button>
          )}
          {patch.docsUrl && (
            <Button asChild variant="outline" className="border-border bg-transparent">
              <a href={patch.docsUrl} target="_blank" rel="noopener noreferrer">
                <FileText className="w-4 h-4 mr-2" />
                Documentation
              </a>
            </Button>
          )}
        </div>

        {/* Details Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="glass-panel border-[#00FFFF]/20">
            <CardHeader>
              <CardTitle className="text-lg text-foreground">Capabilities</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {patch.capabilities.map((cap) => (
                  <TagChip key={cap} label={cap} variant="cyan" />
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="glass-panel border-[#00FFFF]/20">
            <CardHeader>
              <CardTitle className="text-lg text-foreground">Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Requires Auth</span>
                <span className="text-foreground">{patch.requiresAuth ? "Yes" : "No"}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Module Key</span>
                <code className="text-[#00FFFF] font-mono text-xs">{patch.key}</code>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Base URL</span>
                <code className="text-muted-foreground font-mono text-xs truncate max-w-[200px]">
                  {patch.appBaseUrl}
                </code>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Telemetry Placeholder */}
        <Card className="glass-panel border-[#00FFFF]/20">
          <CardHeader>
            <CardTitle className="text-lg text-foreground">Telemetry</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-8 text-muted-foreground">
              Telemetry dashboard coming soon. This will display usage metrics, error rates, and performance data.
            </div>
          </CardContent>
        </Card>
      </div>
    </ShellLayout>
  )
}
