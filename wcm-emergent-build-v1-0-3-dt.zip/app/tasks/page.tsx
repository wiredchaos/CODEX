"use client"

import { useState } from "react"
import { ShellLayout } from "@/components/shell-layout"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Zap, Play, Loader2 } from "lucide-react"

interface PlanStep {
  stepNumber: number
  agentId: string
  toolId: string
  params: Record<string, unknown>
}

interface Plan {
  planId: string
  steps: PlanStep[]
}

const DOMAINS = [
  { value: "system", label: "System & Architecture" },
  { value: "tax", label: "Tax & Compliance" },
  { value: "trust", label: "Estate & Trusts" },
  { value: "entity", label: "Business Entities" },
  { value: "triad", label: "Triad Engine (FEN/VRG/589)" },
  { value: "content", label: "Content & Media" },
  { value: "health", label: "Health & Wellness" },
] as const

export default function TasksPage() {
  const [goal, setGoal] = useState("")
  const [context, setContext] = useState("")
  const [maxSteps, setMaxSteps] = useState(5)
  const [safeMode, setSafeMode] = useState(true)
  const [domain, setDomain] = useState<string>("")
  const [isPlanning, setIsPlanning] = useState(false)
  const [isExecuting, setIsExecuting] = useState(false)
  const [plan, setPlan] = useState<Plan | null>(null)
  const [results, setResults] = useState<Array<{
    stepNumber: number
    success: boolean
    output: Record<string, unknown> | null
    error: string | null
  }> | null>(null)

  const handleGeneratePlan = async () => {
    setIsPlanning(true)
    setPlan(null)
    setResults(null)

    try {
      const res = await fetch("/api/swarm/plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ goal, context, constraints: { maxSteps, safeMode, domain: domain || undefined } }),
      })
      const data = await res.json()
      setPlan(data)
    } catch (error) {
      console.error("Planning failed:", error)
    } finally {
      setIsPlanning(false)
    }
  }

  const handleExecutePlan = async () => {
    if (!plan) return
    setIsExecuting(true)
    setResults(null)

    try {
      const res = await fetch("/api/swarm/execute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ planId: plan.planId, steps: plan.steps }),
      })
      const data = await res.json()
      setResults(data.results)
    } catch (error) {
      console.error("Execution failed:", error)
    } finally {
      setIsExecuting(false)
    }
  }

  return (
    <ShellLayout>
      <div className="space-y-6 max-w-4xl">
        <div className="space-y-2">
          <h1 className="text-2xl font-bold text-[#00FFFF] text-glow-cyan">CHAOS Antigravity Engine</h1>
          <p className="text-muted-foreground">
            Define a goal and let SWARM agents orchestrate MCP tools to complete it
          </p>
        </div>

        {/* Input Form */}
        <Card className="glass-card border-[#00FFFF]/20">
          <CardHeader>
            <CardTitle className="text-lg text-foreground flex items-center gap-2">
              <Zap className="w-5 h-5 text-[#00FFFF]" />
              Task Definition
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="goal">Goal</Label>
              <Textarea
                id="goal"
                placeholder="What do you want to accomplish? e.g., 'Prepare crypto tax documents' or 'Generate trust blueprint'"
                value={goal}
                onChange={(e) => setGoal(e.target.value)}
                className="bg-secondary/50 border-border min-h-[100px]"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="context">Context (optional)</Label>
              <Textarea
                id="context"
                placeholder="Additional context, constraints, or relevant information..."
                value={context}
                onChange={(e) => setContext(e.target.value)}
                className="bg-secondary/50 border-border"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="domain">Domain</Label>
                <Select value={domain} onValueChange={setDomain}>
                  <SelectTrigger className="bg-secondary/50 border-border">
                    <SelectValue placeholder="Auto-detect" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="auto">Auto-detect</SelectItem>
                    {DOMAINS.map((d) => (
                      <SelectItem key={d.value} value={d.value}>
                        {d.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="maxSteps">Max Steps</Label>
                <Input
                  id="maxSteps"
                  type="number"
                  min={1}
                  max={20}
                  value={maxSteps}
                  onChange={(e) => setMaxSteps(Number(e.target.value))}
                  className="bg-secondary/50 border-border"
                />
              </div>

              <div className="space-y-2">
                <Label>Safe Mode</Label>
                <div className="flex items-center gap-2 h-10">
                  <Switch id="safeMode" checked={safeMode} onCheckedChange={setSafeMode} />
                  <span className="text-xs text-muted-foreground">Require approval</span>
                </div>
              </div>
            </div>

            <Button
              onClick={handleGeneratePlan}
              disabled={!goal || isPlanning}
              className="bg-[#00FFFF]/20 text-[#00FFFF] hover:bg-[#00FFFF]/30 border border-[#00FFFF]/30"
            >
              {isPlanning ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Planning...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 mr-2" />
                  Generate Plan
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Plan Display */}
        {plan && (
          <Card className="glass-card border-[#39FF14]/20">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg text-foreground">Execution Plan</CardTitle>
              <Button
                onClick={handleExecutePlan}
                disabled={isExecuting}
                className="bg-[#39FF14]/20 text-[#39FF14] hover:bg-[#39FF14]/30 border border-[#39FF14]/30"
              >
                {isExecuting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Executing...
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Execute Plan
                  </>
                )}
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {plan.steps.map((step, index) => (
                  <div
                    key={index}
                    className="p-3 rounded-lg bg-secondary/30 border border-border flex items-center gap-4"
                  >
                    <div className="w-8 h-8 rounded-full bg-[#39FF14]/10 flex items-center justify-center text-[#39FF14] font-mono text-sm">
                      {step.stepNumber}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <code className="text-[#00FFFF] font-mono text-sm">{step.agentId}</code>
                        <span className="text-muted-foreground">→</span>
                        <code className="text-[#FF00FF] font-mono text-sm">{step.toolId}</code>
                      </div>
                      {Object.keys(step.params).length > 0 && (
                        <pre className="text-xs text-muted-foreground mt-1 overflow-auto">
                          {JSON.stringify(step.params, null, 2)}
                        </pre>
                      )}
                    </div>
                    {results && results[index] && (
                      <div
                        className={`px-2 py-1 rounded text-xs ${
                          results[index].success ? "bg-[#39FF14]/20 text-[#39FF14]" : "bg-[#FF3131]/20 text-[#FF3131]"
                        }`}
                      >
                        {results[index].success ? "Success" : "Failed"}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Results */}
        {results && (
          <Card className="glass-card border-[#FF00FF]/20">
            <CardHeader>
              <CardTitle className="text-lg text-foreground">Execution Results</CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="text-sm text-muted-foreground bg-secondary/30 p-4 rounded-lg overflow-auto">
                {JSON.stringify(results, null, 2)}
              </pre>
            </CardContent>
          </Card>
        )}
      </div>
    </ShellLayout>
  )
}
