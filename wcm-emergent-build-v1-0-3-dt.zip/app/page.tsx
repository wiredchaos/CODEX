import { ShellLayout } from "@/components/shell-layout"
import { PatchCard } from "@/components/patch-card"
import { StatsCard } from "@/components/stats-card"
import { patchRegistry } from "@/lib/patches/registry"
import { swarmRegistry } from "@/lib/swarms/registry"
import { avatarRegistry } from "@/lib/avatars/registry"
import { mcpRegistry } from "@/lib/registry/mcp-servers"
import { Boxes, Brain, Server, Zap, User, Video } from "lucide-react"
import Link from "next/link"

export default function DashboardPage() {
  const patches = patchRegistry.listPatches()
  const swarms = swarmRegistry.listSwarmAgents()
  const avatars = avatarRegistry.listAvatars()
  const mcpServers = mcpRegistry.listMcpServers()
  const mcpTools = mcpRegistry.listMcpTools()

  const onlinePatches = patches.filter((p) => p.status === "online").length
  const activeSwarms = swarms.filter((s) => s.isActive).length
  const onlineServers = mcpServers.filter((s) => s.status === "online").length

  const coreShell = patches.filter((p) => p.category === "Core Shell / Device Layer")
  const engines = patches.filter((p) =>
    [
      "Triad Engine",
      "Tax & Compliance",
      "Estate & Trusts",
      "Business Entities",
      "Story & ARG Engine",
      "Creator Systems",
      "Prompt & Agent Hub",
    ].includes(p.category),
  )
  const media = patches.filter((p) => p.category === "Media & Broadcast")

  return (
    <ShellLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-[#00FFFF] text-glow-cyan">WIRED CHAOS META</h1>
          <p className="text-muted-foreground">Control Motherboard • Antigravity Engine • Patch Orchestration</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <StatsCard
            title="Patches"
            value={patches.length}
            description={`${onlinePatches} online`}
            icon={Boxes}
            color="cyan"
          />
          <StatsCard
            title="SWARM Agents"
            value={swarms.length}
            description={`${activeSwarms} active`}
            icon={Brain}
            color="green"
          />
          <StatsCard title="Avatars" value={avatars.length} description="Video-enabled" icon={User} color="pink" />
          <StatsCard
            title="MCP Servers"
            value={mcpServers.length}
            description={`${onlineServers} online`}
            icon={Server}
            color="cyan"
          />
          <StatsCard title="MCP Tools" value={mcpTools.length} description="Available" icon={Zap} color="green" />
          <Link href="/tasks" className="block">
            <StatsCard title="Antigravity" value="GO" description="Task Engine" icon={Video} color="pink" />
          </Link>
        </div>

        {/* Core Shell */}
        {coreShell.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-foreground border-b border-[#00FFFF]/20 pb-2">Core Shell</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {coreShell.map((patch) => (
                <PatchCard key={patch.id} patch={patch} />
              ))}
            </div>
          </div>
        )}

        {/* Engines & Systems */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-foreground border-b border-[#39FF14]/20 pb-2">Engines & Systems</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {engines.map((patch) => (
              <PatchCard key={patch.id} patch={patch} />
            ))}
          </div>
        </div>

        {/* Media & Broadcast */}
        {media.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-foreground border-b border-[#FF3131]/20 pb-2">
              Media & Broadcast
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {media.map((patch) => (
                <PatchCard key={patch.id} patch={patch} />
              ))}
            </div>
          </div>
        )}
      </div>
    </ShellLayout>
  )
}
