import { ShellLayout } from "@/components/shell-layout"
import { ReferralCard } from "@/components/referral-card"
import { ReferralStats } from "@/components/referral-stats"
import { Gift, Users, Zap } from "lucide-react"

export default function ReferralPage() {
  const referralCode = "RIYB8H"
  const referralLink = `https://v0.app/ref/${referralCode}`

  return (
    <ShellLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-[#00FFFF] text-glow-cyan">Referral Program</h1>
          <p className="text-muted-foreground">Share WIRED CHAOS META and earn rewards for every new user who joins</p>
        </div>

        {/* Main Referral Card */}
        <ReferralCard referralCode={referralCode} referralLink={referralLink} />

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <ReferralStats
            title="Total Referrals"
            value="0"
            description="Users joined via your link"
            icon={Users}
            color="cyan"
          />
          <ReferralStats
            title="Pending Rewards"
            value="0"
            description="Awaiting verification"
            icon={Gift}
            color="pink"
          />
          <ReferralStats title="Total Earned" value="$0" description="Lifetime earnings" icon={Zap} color="green" />
        </div>

        {/* How It Works */}
        <div className="glass-panel rounded-lg p-6 space-y-6">
          <h2 className="text-xl font-semibold text-[#39FF14] text-glow-green">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-full bg-[#00FFFF]/10 border border-[#00FFFF]/30 flex items-center justify-center">
                <span className="text-[#00FFFF] font-bold text-lg">1</span>
              </div>
              <h3 className="font-medium text-foreground">Share Your Link</h3>
              <p className="text-sm text-muted-foreground">
                Copy your unique referral link and share it with friends, colleagues, or on social media.
              </p>
            </div>
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-full bg-[#FF00FF]/10 border border-[#FF00FF]/30 flex items-center justify-center">
                <span className="text-[#FF00FF] font-bold text-lg">2</span>
              </div>
              <h3 className="font-medium text-foreground">They Sign Up</h3>
              <p className="text-sm text-muted-foreground">
                When someone clicks your link and creates an account, they become your referral.
              </p>
            </div>
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-full bg-[#39FF14]/10 border border-[#39FF14]/30 flex items-center justify-center">
                <span className="text-[#39FF14] font-bold text-lg">3</span>
              </div>
              <h3 className="font-medium text-foreground">Earn Rewards</h3>
              <p className="text-sm text-muted-foreground">
                Get credits and perks when your referrals subscribe or make qualifying purchases.
              </p>
            </div>
          </div>
        </div>

        {/* Referral History */}
        <div className="glass-panel rounded-lg p-6 space-y-4">
          <h2 className="text-xl font-semibold text-foreground">Recent Referrals</h2>
          <div className="border border-border/50 rounded-lg overflow-hidden">
            <div className="p-8 text-center text-muted-foreground">
              <Users className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p>No referrals yet</p>
              <p className="text-sm mt-1">Share your link to start earning rewards</p>
            </div>
          </div>
        </div>
      </div>
    </ShellLayout>
  )
}
