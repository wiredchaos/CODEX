"use client"

import { ShellLayout } from "@/components/shell-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, User, Shield, Key, Activity } from "lucide-react"
import Link from "next/link"

export default function IdentityPage() {
  return (
    <ShellLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Link href="/chaos-os">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div className="space-y-1 flex-1">
            <h1 className="text-2xl font-bold text-foreground">User Identity</h1>
            <p className="text-muted-foreground">Manage your profile and sessions</p>
          </div>
        </div>

        {/* Profile Card */}
        <Card className="bg-secondary/50 border-border">
          <CardHeader>
            <CardTitle className="text-foreground">Profile</CardTitle>
            <CardDescription>Your WIRED CHAOS META identity</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-[#00FFFF]/20 border-2 border-[#00FFFF]/30 flex items-center justify-center">
                <User className="w-8 h-8 text-[#00FFFF]" />
              </div>
              <div>
                <div className="text-lg font-semibold text-foreground">CHAOS User</div>
                <div className="text-sm text-muted-foreground">chaos.user@wiredchaos.io</div>
                <Badge className="mt-2 bg-[#39FF14]/20 text-[#39FF14] border-[#39FF14]/30">VERIFIED</Badge>
              </div>
            </div>

            <div className="pt-4 space-y-2 border-t border-border">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">User ID</span>
                <span className="text-foreground font-mono">user_chaos_001</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Account Created</span>
                <span className="text-foreground">Jan 1, 2024</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Access Level</span>
                <span className="text-foreground">Admin</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Active Sessions */}
        <Card className="bg-secondary/50 border-border">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-[#00FFFF]" />
              <CardTitle className="text-foreground">Active Sessions</CardTitle>
            </div>
            <CardDescription>Currently logged in devices</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between p-3 rounded-lg bg-background/50 border border-border">
              <div>
                <div className="text-sm font-medium text-foreground">Current Session</div>
                <div className="text-xs text-muted-foreground">Chrome on macOS • San Francisco, CA</div>
              </div>
              <Badge className="bg-[#39FF14]/20 text-[#39FF14] border-[#39FF14]/30">ACTIVE</Badge>
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg bg-background/50 border border-border">
              <div>
                <div className="text-sm font-medium text-foreground">Mobile App</div>
                <div className="text-xs text-muted-foreground">iOS App • Last active 2 hours ago</div>
              </div>
              <Button variant="ghost" size="sm" className="text-[#FF3131]">
                Revoke
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Security */}
        <Card className="bg-secondary/50 border-border">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-[#FF00FF]" />
              <CardTitle className="text-foreground">Security</CardTitle>
            </div>
            <CardDescription>Manage authentication and access</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button variant="outline" className="w-full justify-start border-border bg-transparent">
              <Key className="w-4 h-4 mr-2" />
              Change Password
            </Button>
            <Button variant="outline" className="w-full justify-start border-border bg-transparent">
              <Shield className="w-4 h-4 mr-2" />
              Two-Factor Authentication
            </Button>
          </CardContent>
        </Card>
      </div>
    </ShellLayout>
  )
}
