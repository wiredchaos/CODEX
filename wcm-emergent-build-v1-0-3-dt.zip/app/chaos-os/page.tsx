"use client"

import { ShellLayout } from "@/components/shell-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Cpu, Bell, User, Grid, ArrowRight } from "lucide-react"
import Link from "next/link"

export default function ChaosOSPage() {
  return (
    <ShellLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-lg bg-[#00FFFF]/20 flex items-center justify-center border border-[#00FFFF]/30">
              <Cpu className="w-6 h-6 text-[#00FFFF]" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">CHAOS OS</h1>
              <p className="text-muted-foreground">Core Shell & Device Layer</p>
            </div>
            <Badge className="ml-auto bg-[#39FF14]/20 text-[#39FF14] border-[#39FF14]/30">ONLINE</Badge>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-secondary/50 border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Active Patches</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-[#00FFFF]">13</div>
            </CardContent>
          </Card>
          <Card className="bg-secondary/50 border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Notifications</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-[#FF00FF]">7</div>
            </CardContent>
          </Card>
          <Card className="bg-secondary/50 border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Active Sessions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-[#39FF14]">3</div>
            </CardContent>
          </Card>
          <Card className="bg-secondary/50 border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">System Health</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-[#39FF14]">98%</div>
            </CardContent>
          </Card>
        </div>

        {/* Main Modules */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="bg-secondary/50 border-border hover:border-[#00FFFF]/50 transition-colors">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#00FFFF]/20 flex items-center justify-center border border-[#00FFFF]/30">
                    <Grid className="w-5 h-5 text-[#00FFFF]" />
                  </div>
                  <div>
                    <CardTitle className="text-foreground">App Launcher</CardTitle>
                    <CardDescription>Launch and manage patch modules</CardDescription>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Link href="/chaos-os/launcher">
                <Button variant="outline" className="w-full border-[#00FFFF]/30 hover:bg-[#00FFFF]/10 bg-transparent">
                  Open Launcher <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="bg-secondary/50 border-border hover:border-[#FF00FF]/50 transition-colors">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#FF00FF]/20 flex items-center justify-center border border-[#FF00FF]/30">
                    <Bell className="w-5 h-5 text-[#FF00FF]" />
                  </div>
                  <div>
                    <CardTitle className="text-foreground">Notifications</CardTitle>
                    <CardDescription>System and patch notifications</CardDescription>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Link href="/chaos-os/notifications">
                <Button variant="outline" className="w-full border-[#FF00FF]/30 hover:bg-[#FF00FF]/10 bg-transparent">
                  View Notifications <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="bg-secondary/50 border-border hover:border-[#39FF14]/50 transition-colors">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#39FF14]/20 flex items-center justify-center border border-[#39FF14]/30">
                    <User className="w-5 h-5 text-[#39FF14]" />
                  </div>
                  <div>
                    <CardTitle className="text-foreground">User Identity</CardTitle>
                    <CardDescription>Manage profile and sessions</CardDescription>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Link href="/chaos-os/identity">
                <Button variant="outline" className="w-full border-[#39FF14]/30 hover:bg-[#39FF14]/10 bg-transparent">
                  View Profile <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="bg-secondary/50 border-border hover:border-[#FF3131]/50 transition-colors">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#FF3131]/20 flex items-center justify-center border border-[#FF3131]/30">
                    <Cpu className="w-5 h-5 text-[#FF3131]" />
                  </div>
                  <div>
                    <CardTitle className="text-foreground">Patch Hub</CardTitle>
                    <CardDescription>Browse and connect patches</CardDescription>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Link href="/patches">
                <Button variant="outline" className="w-full border-[#FF3131]/30 hover:bg-[#FF3131]/10 bg-transparent">
                  Open Hub <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        {/* System Info */}
        <Card className="bg-secondary/50 border-border">
          <CardHeader>
            <CardTitle className="text-foreground">System Information</CardTitle>
            <CardDescription>Current CHAOS OS configuration</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Version</span>
              <span className="text-foreground font-mono">v1.0.0-alpha</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Uptime</span>
              <span className="text-foreground font-mono">7d 14h 32m</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Connected Patches</span>
              <span className="text-foreground font-mono">13 / 13</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Environment</span>
              <span className="text-foreground font-mono">Production</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </ShellLayout>
  )
}
