"use client"

import { ShellLayout } from "@/components/shell-layout"
import { PatchCard } from "@/components/patch-card"
import { patchRegistry } from "@/lib/patches/registry"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ArrowLeft, Search } from "lucide-react"
import Link from "next/link"
import { useState } from "react"

export default function LauncherPage() {
  const [search, setSearch] = useState("")
  const patches = patchRegistry.listByStatus("online")

  const filteredPatches = patches.filter((patch) => patch.displayName.toLowerCase().includes(search.toLowerCase()))

  return (
    <ShellLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Link href="/chaos-os">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div className="space-y-1 flex-1">
            <h1 className="text-2xl font-bold text-foreground">App Launcher</h1>
            <p className="text-muted-foreground">Launch any online patch module</p>
          </div>
        </div>

        {/* Search */}
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search patches..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-secondary/50 border-border"
          />
        </div>

        {/* Patch Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredPatches.map((patch) => (
            <PatchCard key={patch.id} patch={patch} />
          ))}
        </div>
      </div>
    </ShellLayout>
  )
}
