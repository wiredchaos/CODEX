"use client"

import { ShellLayout } from "@/components/shell-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ArrowLeft, CheckCircle, AlertTriangle, Info } from "lucide-react"
import Link from "next/link"

const mockNotifications = [
  {
    id: "1",
    type: "success",
    title: "NEURA TAX Updated",
    message: "Tax suite has been updated with new crypto tax workflows",
    timestamp: "2 hours ago",
    read: false,
  },
  {
    id: "2",
    type: "warning",
    title: "Session Expiring Soon",
    message: "Your current session will expire in 1 hour",
    timestamp: "3 hours ago",
    read: false,
  },
  {
    id: "3",
    type: "info",
    title: "New Patch Available",
    message: "GIGA MAX vision engine is now available in the patch hub",
    timestamp: "5 hours ago",
    read: true,
  },
]

export default function NotificationsPage() {
  return (
    <ShellLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Link href="/chaos-os">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div className="space-y-1 flex-1">
            <h1 className="text-2xl font-bold text-foreground">Notifications</h1>
            <p className="text-muted-foreground">System and patch notifications</p>
          </div>
          <Button variant="outline" size="sm" className="border-border bg-transparent">
            Mark All Read
          </Button>
        </div>

        {/* Notifications List */}
        <div className="space-y-3">
          {mockNotifications.map((notif) => (
            <Card
              key={notif.id}
              className={`bg-secondary/50 border-border ${!notif.read ? "border-l-4 border-l-[#00FFFF]" : ""}`}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    <div
                      className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                        notif.type === "success"
                          ? "bg-[#39FF14]/20 border border-[#39FF14]/30"
                          : notif.type === "warning"
                            ? "bg-[#FF3131]/20 border border-[#FF3131]/30"
                            : "bg-[#00FFFF]/20 border border-[#00FFFF]/30"
                      }`}
                    >
                      {notif.type === "success" && <CheckCircle className="w-4 h-4 text-[#39FF14]" />}
                      {notif.type === "warning" && <AlertTriangle className="w-4 h-4 text-[#FF3131]" />}
                      {notif.type === "info" && <Info className="w-4 h-4 text-[#00FFFF]" />}
                    </div>
                    <div>
                      <CardTitle className="text-sm text-foreground">{notif.title}</CardTitle>
                      <CardDescription className="text-xs mt-1">{notif.message}</CardDescription>
                    </div>
                  </div>
                  {!notif.read && (
                    <Badge className="bg-[#00FFFF]/20 text-[#00FFFF] border-[#00FFFF]/30 text-xs">NEW</Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-xs text-muted-foreground">{notif.timestamp}</div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </ShellLayout>
  )
}
