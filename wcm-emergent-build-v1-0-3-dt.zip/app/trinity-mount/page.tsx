import { TRINITY_FLOORS, TIMELINES } from "@/lib/trinity/static-floors"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Layers, Lock, Eye } from "lucide-react"

export default function TrinityMountPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Layers className="h-8 w-8 text-cyan-400" />
        <div>
          <h1 className="text-3xl font-bold text-cyan-400">TRINITY MOUNT</h1>
          <p className="text-sm text-muted-foreground">Read-Only Timeline Consumer</p>
        </div>
      </div>

      <Card className="border-cyan-500/20 bg-background/40 backdrop-blur-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-cyan-400">
            <Lock className="h-5 w-5" />
            Declarative Mount System
          </CardTitle>
          <CardDescription>
            This patch consumes the existing WIRED CHAOS Trinity 3D Core. It does not generate new 3D content or
            galaxies. All timeline access is governed by Akira Codex.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-2 text-sm">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="border-red-500/50 text-red-400">
                No Generation
              </Badge>
              <span className="text-muted-foreground">Read-only infrastructure consumer</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="border-green-500/50 text-green-400">
                Timeline Mount
              </Badge>
              <span className="text-muted-foreground">Assigned to Trinity Floor by Akira Codex</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="border-pink-500/50 text-pink-400">
                Infrastructure Only
              </Badge>
              <span className="text-muted-foreground">Consumer, not owner</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-foreground">Trinity Floors</h2>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {TRINITY_FLOORS.map((floor) => (
            <Card key={floor.id} className="border-cyan-500/20 bg-background/40 backdrop-blur-md">
              <CardHeader>
                <CardTitle className="text-cyan-400">
                  Level {floor.level} · {floor.name}
                </CardTitle>
                <CardDescription>{floor.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <Eye className="h-4 w-4 text-pink-400" />
                    <span className="text-muted-foreground">{floor.accessLevel.replace("_", " ")}</span>
                  </div>
                  <div className="text-xs text-muted-foreground">{floor.timelineKeys.length} timeline(s) available</div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-foreground">Available Timelines</h2>
        <div className="grid gap-4">
          {TIMELINES.map((timeline) => {
            const floor = TRINITY_FLOORS.find((f) => f.id === timeline.floorId)
            return (
              <Card key={timeline.key} className="border-cyan-500/20 bg-background/40 backdrop-blur-md">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-cyan-400">{timeline.displayName}</CardTitle>
                      <CardDescription>{timeline.metadata.theme}</CardDescription>
                    </div>
                    <Badge variant="outline" className="border-green-500/50 text-green-400">
                      {floor?.name}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Era:</span>
                      <span className="text-foreground">{timeline.metadata.era}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Nodes:</span>
                      <span className="text-foreground">{timeline.metadata.nodes}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Access:</span>
                      <Badge variant="outline" className="border-red-500/50 text-red-400">
                        Read-Only
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>

      <Card className="border-pink-500/20 bg-background/40 backdrop-blur-md">
        <CardHeader>
          <CardTitle className="text-pink-400">API Endpoints</CardTitle>
          <CardDescription>Read-only endpoints for Trinity timeline consumption</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 font-mono text-sm">
            <div className="flex items-center gap-2">
              <Badge variant="outline">GET</Badge>
              <code className="text-cyan-400">/api/trinity/mount?patchKey=YOUR_PATCH</code>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline">GET</Badge>
              <code className="text-cyan-400">/api/trinity/timeline/[key]?patchKey=YOUR_PATCH</code>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline">POST</Badge>
              <code className="text-cyan-400">/api/trinity/mount</code>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
