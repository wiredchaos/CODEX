import { type NextRequest, NextResponse } from "next/server"
import { createGameSession, GAME_TEMPLATES } from "@/lib/npc/games"
import type { DifficultyLevel } from "@/lib/npc/types"

export async function GET(req: NextRequest) {
  try {
    const games = Object.entries(GAME_TEMPLATES).map(([key, template]) => ({
      key,
      type: template.type,
      title: template.title,
    }))

    return NextResponse.json({
      success: true,
      games,
      total: games.length,
    })
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { gameKey, difficulty } = body

    if (!gameKey || !difficulty) {
      return NextResponse.json({ error: "gameKey and difficulty required" }, { status: 400 })
    }

    const session = createGameSession(gameKey, difficulty as DifficultyLevel)

    return NextResponse.json({
      success: true,
      session,
      message: `Game session created: ${session.title}`,
    })
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
