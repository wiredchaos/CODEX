import { type NextRequest, NextResponse } from "next/server"
import { getLabyrinthNode, canAccessNode } from "@/lib/npc/labyrinth"

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const nodeId = searchParams.get("nodeId") || "entrance"

    const node = getLabyrinthNode(nodeId)

    if (!node) {
      return NextResponse.json({ error: "Node not found" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      node,
    })
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { nodeId, optionId, userProgress } = body

    if (!nodeId || !optionId) {
      return NextResponse.json({ error: "nodeId and optionId required" }, { status: 400 })
    }

    const node = getLabyrinthNode(nodeId)
    if (!node) {
      return NextResponse.json({ error: "Node not found" }, { status: 404 })
    }

    const option = node.options.find((opt) => opt.id === optionId)
    if (!option) {
      return NextResponse.json({ error: "Option not found" }, { status: 404 })
    }

    // Check access
    const hasAccess = canAccessNode(node, option, userProgress || { totalXP: 0, badges: [] })
    if (!hasAccess) {
      return NextResponse.json(
        {
          success: false,
          error: "Requirements not met",
          requirement: option.requirement,
        },
        { status: 403 },
      )
    }

    // Get next node
    const nextNode = getLabyrinthNode(option.nextNodeId)

    return NextResponse.json({
      success: true,
      nextNode,
      risk: option.risk,
      message: `Moving to ${nextNode?.title}`,
    })
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
