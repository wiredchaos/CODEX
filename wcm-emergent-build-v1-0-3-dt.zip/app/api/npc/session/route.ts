import { type NextRequest, NextResponse } from "next/server"
import { generalCoordinator } from "@/lib/npc/general"
import type { NPCSession } from "@/lib/npc/types"

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { userId, userProfile } = body

    if (!userId) {
      return NextResponse.json({ error: "userId required" }, { status: 400 })
    }

    // Get assignment from General
    const command = generalCoordinator.assessAndAssign(userId, userProfile || {})

    // Create new session
    const session: NPCSession = {
      id: `npc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      userId,
      npcRole: command.payload.role,
      mode: command.payload.mode,
      personality: {
        role: command.payload.role,
        mode: command.payload.mode,
        tone: "friendly",
        verbosity: "balanced",
        encouragement: 70,
        challenge: 50,
      },
      progress: {
        modulesCompleted: 0,
        gamesWon: 0,
        labyrinthsExplored: 0,
        totalXP: 0,
        level: 1,
        badges: [],
      },
      history: [],
      createdAt: new Date(),
      lastActive: new Date(),
    }

    return NextResponse.json({
      success: true,
      session,
      command,
      message: `NPC ${command.payload.role} activated in ${command.payload.mode} mode`,
    })
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const userId = searchParams.get("userId")

    if (!userId) {
      return NextResponse.json({ error: "userId required" }, { status: 400 })
    }

    // Mock: In production, fetch from database
    return NextResponse.json({
      success: true,
      session: null,
      message: "No active session found",
    })
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
