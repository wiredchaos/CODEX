import { type NextRequest, NextResponse } from "next/server"
import { generalCoordinator } from "@/lib/npc/general"
import type { NPCSession, NPCInteraction } from "@/lib/npc/types"

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { sessionId, userInput, session } = body

    if (!sessionId || !userInput || !session) {
      return NextResponse.json({ error: "sessionId, userInput, and session required" }, { status: 400 })
    }

    const npcSession = session as NPCSession

    // Get swarm routing from General
    const routing = generalCoordinator.routeToSwarm(userInput, npcSession)

    // Call appropriate swarm agent
    const swarmResponse = await fetch(
      `${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/api/swarm/${routing.agent}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: userInput,
          context: routing.context,
          profile: {
            role: npcSession.npcRole,
            mode: npcSession.mode,
            personality: npcSession.personality,
            progress: npcSession.progress,
          },
        }),
      },
    )

    const swarmData = await swarmResponse.json()

    // Create interaction record
    const interaction: NPCInteraction = {
      id: `interaction_${Date.now()}`,
      timestamp: new Date(),
      userInput,
      npcResponse: swarmData.response || swarmData.result || "I can help with that.",
      action: determineAction(userInput, npcSession.mode),
      xpAwarded: calculateXP(userInput, npcSession),
      videoUrl: swarmData.videoUrl,
    }

    // Evaluate progress and get command from General
    const progressCommand = generalCoordinator.evaluateProgress(npcSession)

    return NextResponse.json({
      success: true,
      interaction,
      routing,
      command: progressCommand,
      swarmAgent: routing.agent,
    })
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

function determineAction(input: string, mode: string): "educate" | "challenge" | "guide" | "reward" | "redirect" {
  const inputLower = input.toLowerCase()

  if (inputLower.includes("learn") || inputLower.includes("explain") || inputLower.includes("teach")) {
    return "educate"
  }
  if (inputLower.includes("play") || inputLower.includes("game") || inputLower.includes("challenge")) {
    return "challenge"
  }
  if (inputLower.includes("help") || inputLower.includes("guide") || inputLower.includes("where")) {
    return "guide"
  }
  if (inputLower.includes("complete") || inputLower.includes("finish") || inputLower.includes("done")) {
    return "reward"
  }

  return mode === "education" ? "educate" : "guide"
}

function calculateXP(input: string, session: NPCSession): number {
  const baseXP = 10
  const modeMultiplier = session.mode === "game" ? 2 : session.mode === "labyrinth" ? 1.5 : 1
  const difficultyBonus = session.progress.level * 5

  return Math.floor(baseXP * modeMultiplier + difficultyBonus)
}
