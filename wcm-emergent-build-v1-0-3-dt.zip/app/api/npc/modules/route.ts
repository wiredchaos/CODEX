import { type NextRequest, NextResponse } from "next/server"
import { EDUCATION_MODULES, getAvailableModules, getModulesByCategory } from "@/lib/npc/education-modules"

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const category = searchParams.get("category")
    const completedStr = searchParams.get("completed")

    let modules = EDUCATION_MODULES

    if (category) {
      modules = getModulesByCategory(category)
    }

    if (completedStr) {
      const completed = completedStr.split(",").filter(Boolean)
      modules = getAvailableModules(completed)
    }

    return NextResponse.json({
      success: true,
      modules,
      total: modules.length,
    })
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
