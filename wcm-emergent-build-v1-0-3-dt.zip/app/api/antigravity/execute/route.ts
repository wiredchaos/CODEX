// POST /api/antigravity/execute - Execute task plan

import { NextResponse } from "next/server"
import { antigravityEngine } from "@/lib/antigravity/engine"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { taskId } = body

    if (!taskId) {
      return NextResponse.json({ error: "taskId is required" }, { status: 400 })
    }

    const task = await antigravityEngine.executeTask(taskId)

    return NextResponse.json(task)
  } catch (error) {
    console.error("Execute task error:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to execute task" },
      { status: 500 },
    )
  }
}
