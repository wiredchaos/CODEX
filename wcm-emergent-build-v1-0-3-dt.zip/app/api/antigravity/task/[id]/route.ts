// GET /api/antigravity/task/[id] - Get task by ID

import { NextResponse } from "next/server"
import { antigravityEngine } from "@/lib/antigravity/engine"

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const task = antigravityEngine.getTask(id)

    if (!task) {
      return NextResponse.json({ error: "Task not found" }, { status: 404 })
    }

    return NextResponse.json(task)
  } catch (error) {
    console.error("Get task error:", error)
    return NextResponse.json({ error: "Failed to get task" }, { status: 500 })
  }
}
