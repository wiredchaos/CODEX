// POST /api/antigravity/task - Create new task
// GET /api/antigravity/task - List all tasks

import { NextResponse } from "next/server"
import { antigravityEngine } from "@/lib/antigravity/engine"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { goal, context, config } = body

    if (!goal || typeof goal !== "string") {
      return NextResponse.json({ error: "Goal is required" }, { status: 400 })
    }

    const task = antigravityEngine.createTask(goal, context, config)

    return NextResponse.json(task)
  } catch (error) {
    console.error("Create task error:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to create task" },
      { status: 500 },
    )
  }
}

export async function GET() {
  try {
    const tasks = antigravityEngine.listTasks()
    const stats = antigravityEngine.getStats()

    return NextResponse.json({ tasks, stats })
  } catch (error) {
    console.error("List tasks error:", error)
    return NextResponse.json({ error: "Failed to list tasks" }, { status: 500 })
  }
}
