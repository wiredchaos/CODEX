// POST /api/antigravity/plan - Generate plan for task

import { NextResponse } from "next/server"
import { antigravityEngine } from "@/lib/antigravity/engine"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { taskId } = body

    if (!taskId) {
      return NextResponse.json({ error: "taskId is required" }, { status: 400 })
    }

    const task = antigravityEngine.planTask(taskId)

    return NextResponse.json(task)
  } catch (error) {
    console.error("Plan task error:", error)
    return NextResponse.json({ error: error instanceof Error ? error.message : "Failed to plan task" }, { status: 500 })
  }
}
