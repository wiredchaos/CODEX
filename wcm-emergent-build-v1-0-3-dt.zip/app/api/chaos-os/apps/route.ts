import { NextResponse } from "next/server"
import { patchRegistry } from "@/lib/patches/registry"

export async function GET() {
  const patches = patchRegistry.listByStatus("online")

  return NextResponse.json({
    success: true,
    apps: patches.map((patch) => ({
      id: patch.id,
      key: patch.key,
      name: patch.displayName,
      slug: patch.slug,
      icon: patch.icon,
      color: patch.primaryColor,
      capabilities: patch.capabilities,
    })),
  })
}
