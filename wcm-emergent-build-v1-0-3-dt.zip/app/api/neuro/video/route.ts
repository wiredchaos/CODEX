import { type NextRequest, NextResponse } from "next/server"
import type { NeuroVideoRequest, NeuroVideoResponse } from "@/lib/neuro/types"
import { SwarmExecutor } from "@/lib/swarm/executor"

// Section-specific response templates
const SECTION_RESPONSES: Record<string, Record<string, string>> = {
  hub: {
    comfort:
      "Welcome to WIRED CHAOS META. I'm NEURO, your guide. Let's take this one step at a time. What would you like to explore first?",
    instructor:
      "This is your WIRED CHAOS META dashboard. You have access to multiple modules - patches for tax, trust, creative work, and more. Where shall we begin?",
    architect:
      "WIRED CHAOS META shell initialized. You have 13 active patches, SWARM orchestration, and the Antigravity Engine available. What system are you targeting?",
    guide:
      "Hey there! I'm NEURO, and I'll help you navigate WIRED CHAOS META. Think of this as your mission control for all your business systems. Ask me anything!",
  },
  "chaos-os": {
    comfort:
      "CHAOS OS is like your personal operating system within WIRED CHAOS. It manages your apps and notifications. Let me walk you through it slowly.",
    instructor:
      "CHAOS OS provides app launching, notification management, and user identity services. Here's how each component works...",
    architect:
      "CHAOS OS layer: App registry API at /api/chaos-os/apps, notifications at /api/chaos-os/notifications. Full CRUD operations available.",
    guide:
      "CHAOS OS is your command center! It keeps track of your apps, alerts you to important updates, and manages your identity across all patches.",
  },
  technical: {
    comfort:
      "The Antigravity Engine helps automate tasks across your systems. Don't worry about the technical stuff - just tell me what you want to accomplish.",
    instructor:
      "The Antigravity Engine orchestrates SWARM agents and MCP tools to execute multi-step tasks. It plans, then executes, then reports.",
    architect:
      "Antigravity API: POST /api/antigravity/task to create, /plan to generate execution plan, /execute to run. Full domain detection and capability matching.",
    guide:
      "Think of the Antigravity Engine as your automation assistant. Tell it a goal, and it figures out which tools and agents to use to make it happen!",
  },
  trust: {
    comfort:
      "Trust and entity services help protect your business structure. I'm here to make this less intimidating - we'll go through each step together.",
    instructor:
      "This section covers trust formation, entity structuring, and asset protection. Each has specific requirements and workflows.",
    architect: "Trust Launcher and Entity Formation modules: Firewall-isolated, separate data stores, RLS-protected.",
    guide:
      "Setting up trusts and entities can feel complex, but I've got your back. These tools help protect your assets and structure your business properly.",
  },
  creative: {
    comfort:
      "Welcome to the creative suite! Akira Codex helps with content creation. Let's explore what you can make here.",
    instructor:
      "Akira Codex provides AI-assisted creative generation - images, copy, video concepts. Here's how to use each tool effectively.",
    architect:
      "Akira Codex API endpoints ready. Style profiles, generation parameters, and output formats configurable.",
    guide:
      "This is where the magic happens! Akira Codex is your creative AI partner. Tell it what you want to create and watch it come to life.",
  },
}

function getSuggestedNextSteps(section: string, mode: string): string[] {
  const steps: Record<string, string[]> = {
    hub: ["Explore the Patches page", "Check the Antigravity Engine", "Visit CHAOS OS"],
    "chaos-os": ["Launch an app", "Check notifications", "Update your identity"],
    technical: ["Create a new task", "View execution history", "Check SWARM agents"],
    trust: ["Start a trust consultation", "Review entity options", "Check compliance status"],
    creative: ["Generate new content", "Browse style profiles", "Start a project"],
  }

  return steps[section] || steps.hub
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as NeuroVideoRequest

    if (!body.question || !body.profile) {
      return NextResponse.json({ error: "Missing question or profile." }, { status: 400 })
    }

    const { question, profile, section = "hub" } = body

    const swarmResponse = await SwarmExecutor.execute({
      question,
      profile,
      section,
      intent: "auto",
    })

    const response: NeuroVideoResponse = {
      text: swarmResponse.text,
      videoUrl: swarmResponse.videoUrl,
      suggestedNextSteps: swarmResponse.suggestedNextSteps,
      social: swarmResponse.social,
      agentsUsed: swarmResponse.agentsUsed,
      processingTime: swarmResponse.processingTime,
    }

    return NextResponse.json(response, { status: 200 })
  } catch (err) {
    console.error("NEURO video error:", err)
    return NextResponse.json({ error: "NEURO Navigator encountered an error." }, { status: 500 })
  }
}
