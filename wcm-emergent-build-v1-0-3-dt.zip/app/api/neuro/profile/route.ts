import { type NextRequest, NextResponse } from "next/server"
import { NeuroEngine } from "@/lib/neuro/neuro-engine"

export async function GET(request: NextRequest) {
  const state = NeuroEngine.getState()

  if (!state) {
    return NextResponse.json({ error: "NEURO not initialized" }, { status: 400 })
  }

  return NextResponse.json({
    success: true,
    profile: state.profile,
    context: state.context,
  })
}

export async function POST(request: NextRequest) {
  const body = await request.json()
  const { event } = body

  if (!event) {
    return NextResponse.json({ error: "Event type required" }, { status: 400 })
  }

  const updated = NeuroEngine.update(event)

  if (!updated) {
    return NextResponse.json({ error: "NEURO not initialized" }, { status: 400 })
  }

  return NextResponse.json({
    success: true,
    profile: updated.profile,
    adapted: updated.currentForm,
  })
}
