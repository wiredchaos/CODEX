// GEMINI AGENT API - Research & Structure

import { type NextRequest, NextResponse } from "next/server"
import type { GeminiRequest, GeminiResponse } from "@/lib/swarm/types"

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as GeminiRequest

    // Check for API key
    const apiKey = process.env.GEMINI_API_KEY

    if (apiKey) {
      // Production: Call real Gemini API
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${apiKey}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [
              {
                parts: [
                  {
                    text: buildGeminiPrompt(body),
                  },
                ],
              },
            ],
            generationConfig: {
              temperature: body.complexity === "simple" ? 0.3 : 0.7,
              maxOutputTokens: body.complexity === "detailed" ? 2048 : 1024,
            },
          }),
        },
      )

      if (response.ok) {
        const data = await response.json()
        const text = data.candidates?.[0]?.content?.parts?.[0]?.text || ""

        return NextResponse.json(parseGeminiOutput(text, body))
      }
    }

    // Fallback: Mock response
    return NextResponse.json(generateMockGeminiResponse(body))
  } catch (err) {
    console.error("Gemini agent error:", err)
    return NextResponse.json({ error: "Gemini processing failed" }, { status: 500 })
  }
}

function buildGeminiPrompt(request: GeminiRequest): string {
  const modeInstructions = {
    simple:
      "Explain in very simple terms, use everyday analogies, short sentences. Target audience: complete beginners who may be overwhelmed.",
    moderate: "Provide clear explanation with moderate detail. Balance accessibility with accuracy.",
    detailed:
      "Provide comprehensive technical breakdown with architecture details, code patterns, and system relationships.",
  }

  const formatInstructions = {
    explanation: "Provide a clear explanation.",
    script: "Write a video script for a 20-30 second clip. Include [SCENE] markers and avatar dialogue.",
    checklist: "Provide a numbered step-by-step checklist.",
    comparison: "Create a comparison with pros/cons for each option.",
    flowchart: "Describe a flowchart with decision points and outcomes.",
  }

  return `You are NEURO, an adaptive AI guide for WIRED CHAOS META platform.

User Question: ${request.question}
Current Section: ${request.section}
User Mode: ${request.profile.personalityMode}
Complexity Level: ${request.complexity}

Instructions:
${modeInstructions[request.complexity]}
${formatInstructions[request.outputFormat]}

Respond in a helpful, ${request.profile.personalityMode === "comfort" ? "warm and reassuring" : "clear and professional"} tone.`
}

function parseGeminiOutput(text: string, request: GeminiRequest): GeminiResponse {
  return {
    explanation: text,
    steps: request.outputFormat === "checklist" ? text.split(/\d+\.\s+/).filter(Boolean) : undefined,
    script: request.outputFormat === "script" ? text : undefined,
    analogies: [],
    nextQuestions: [],
  }
}

function generateMockGeminiResponse(request: GeminiRequest): GeminiResponse {
  const complexityText = {
    simple: "Let me explain this simply",
    moderate: "Here's what you need to know",
    detailed: "Technical breakdown",
  }

  return {
    explanation: `${complexityText[request.complexity]}: ${request.question}\n\nThis is in the ${request.section} section. [Gemini API key not configured - showing mock response]`,
    steps:
      request.outputFormat === "checklist"
        ? ["Understand the concept", "Review requirements", "Execute workflow", "Verify results"]
        : undefined,
    script:
      request.outputFormat === "script"
        ? `[SCENE: NEURO appears]\n\nNEURO: "Let me explain ${request.question}..."\n\n[TRANSITION]`
        : undefined,
    analogies: ["Think of it like a GPS for your business"],
    nextQuestions: ["What would you like to explore next?"],
  }
}
