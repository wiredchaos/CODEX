// GROK AGENT API - X Native / Social Layer

import { type NextRequest, NextResponse } from "next/server"
import type { GrokRequest, GrokResponse } from "@/lib/swarm/types"

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as GrokRequest

    // Check for xAI API key
    const apiKey = process.env.XAI_API_KEY

    if (apiKey) {
      // Production: Call xAI Grok API
      const response = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "grok-beta",
          messages: [
            {
              role: "system",
              content: buildGrokSystemPrompt(body),
            },
            {
              role: "user",
              content: body.content,
            },
          ],
          temperature: body.tone === "meme" ? 0.9 : 0.7,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        const text = data.choices?.[0]?.message?.content || ""

        return NextResponse.json(parseGrokOutput(text, body))
      }
    }

    // Fallback: Mock response
    return NextResponse.json(generateMockGrokResponse(body))
  } catch (err) {
    console.error("Grok agent error:", err)
    return NextResponse.json({ error: "Grok processing failed" }, { status: 500 })
  }
}

function buildGrokSystemPrompt(request: GrokRequest): string {
  const toneInstructions = {
    meme: "Write in viral meme style. Punchy, bold, uses crypto/tech culture references. Include emojis.",
    professional: "Write in clean, professional style. Authoritative but accessible.",
    binary: "Write in coded, cryptic style. Short lines, if/then frames, binary thinking.",
    hype: "Write with maximum energy. Exciting, urgent, FOMO-inducing.",
    educational: "Write to educate. Clear, informative, breaks down complexity.",
  }

  const formatInstructions = {
    tweet: "Create a single tweet (max 280 chars).",
    thread: "Create a Twitter thread (5-7 tweets, numbered).",
    caption: "Create a short caption for social media.",
    hook: "Create an attention-grabbing hook line.",
    cta: "Create a call-to-action that drives engagement.",
  }

  return `You are a social media optimization AI for WIRED CHAOS META.

Tone: ${request.tone}
${toneInstructions[request.tone]}

Format: ${request.format}
${formatInstructions[request.format]}

Target Audience: ${request.targetAudience}
${request.maxLength ? `Max Length: ${request.maxLength} characters` : ""}

Generate X-optimized content that drives engagement.`
}

function parseGrokOutput(text: string, request: GrokRequest): GrokResponse {
  const lines = text.split("\n").filter(Boolean)

  return {
    primary: lines[0] || text.slice(0, 280),
    variants: lines.slice(1, 4),
    hashtags: text.match(/#\w+/g) || ["#WIREDCHAOS", "#NEURO"],
    hooks: lines.filter((l) => l.includes("...") || l.includes("?")),
    threadParts: request.format === "thread" ? lines.filter((l) => /^\d+[./]/.test(l)) : undefined,
  }
}

function generateMockGrokResponse(request: GrokRequest): GrokResponse {
  const toneEmoji = {
    meme: "🔥",
    professional: "📊",
    binary: "01",
    hype: "🚀",
    educational: "📚",
  }

  const emoji = toneEmoji[request.tone]
  const preview = request.content.slice(0, 100)

  return {
    primary: `${emoji} ${preview}... [Grok API key not configured]`,
    variants: [
      `Thread incoming: ${preview.slice(0, 50)}...`,
      `GM to everyone learning about this`,
      `If you're not paying attention, ngmi`,
    ],
    hashtags: ["#WIREDCHAOS", "#NEURO", "#Web3"],
    hooks: ["Most people don't realize this, but...", "Here's what changed everything:"],
    threadParts:
      request.format === "thread"
        ? [
            `1/ ${preview}`,
            "2/ Here's why this matters...",
            "3/ The key insight is...",
            "4/ Action steps:",
            "5/ RT + follow for more",
          ]
        : undefined,
  }
}

export async function GET() {
  return NextResponse.json({
    status: "online",
    agent: "grok",
    capabilities: ["tweet", "thread", "caption", "hook", "cta"],
    tones: ["meme", "professional", "binary", "hype", "educational"],
  })
}
