// CODEX BRAIN API - Core Domain Logic

import { type NextRequest, NextResponse } from "next/server"
import type { CodexRequest, CodexResponse } from "@/lib/swarm/types"

// Domain knowledge bases
const DOMAIN_KNOWLEDGE: Record<string, { overview: string; keywords: string[] }> = {
  system: {
    overview: "CHAOS OS and system-level operations within WIRED CHAOS META",
    keywords: ["launcher", "notifications", "identity", "patch", "registry"],
  },
  creative: {
    overview: "Akira Codex and Creator Codex for AI-assisted content generation",
    keywords: ["generate", "style", "content", "video", "image", "creative"],
  },
  tax: {
    overview: "NEURA TAX for AI-powered tax preparation and strategy",
    keywords: ["tax", "efile", "crypto", "expat", "deduction", "entity"],
  },
  trust: {
    overview: "Trust Launcher for estate planning and asset protection",
    keywords: ["trust", "estate", "beneficiary", "revocable", "irrevocable"],
  },
  entity: {
    overview: "Entity Formation for business structure optimization",
    keywords: ["llc", "corp", "holding", "offshore", "nexus", "formation"],
  },
  orchestration: {
    overview: "Antigravity Engine for SWARM and MCP orchestration",
    keywords: ["task", "agent", "swarm", "mcp", "execute", "plan"],
  },
  ai: {
    overview: "Vision API and GIGA MAX for AI-powered analysis",
    keywords: ["vision", "analyze", "blueprint", "ai", "model"],
  },
  agents: {
    overview: "SWARM agents and their coordination",
    keywords: ["swarm", "agent", "capability", "routing", "coordinator"],
  },
  general: {
    overview: "General WIRED CHAOS META platform guidance",
    keywords: ["help", "start", "learn", "navigate", "explore"],
  },
}

// Lore fragments for creative domains
const LORE_FRAGMENTS: Record<string, string[]> = {
  creative: [
    "The Akira Scrolls speak of patterns within patterns...",
    "As the Codex reveals: creation flows from chaos into form.",
  ],
  triad: [
    "The 589 Continuum encodes the path forward.",
    "VRG33589 - Where vision becomes reality.",
    "The Triad Engine awaits activation.",
  ],
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as CodexRequest

    const domainInfo = DOMAIN_KNOWLEDGE[body.domain] || DOMAIN_KNOWLEDGE.general

    // Check for OpenAI API key for enhanced responses
    const apiKey = process.env.OPENAI_API_KEY

    if (apiKey) {
      // Production: Call OpenAI with domain context
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            {
              role: "system",
              content: buildCodexSystemPrompt(body, domainInfo),
            },
            {
              role: "user",
              content: body.question,
            },
          ],
          temperature: 0.7,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        const text = data.choices?.[0]?.message?.content || ""

        return NextResponse.json(parseCodexOutput(text, body))
      }
    }

    // Fallback: Generate domain-aware mock response
    return NextResponse.json(generateMockCodexResponse(body, domainInfo))
  } catch (err) {
    console.error("Codex brain error:", err)
    return NextResponse.json({ error: "Codex processing failed" }, { status: 500 })
  }
}

function buildCodexSystemPrompt(request: CodexRequest, domainInfo: { overview: string; keywords: string[] }): string {
  return `You are the CODEX BRAIN - the core intelligence of WIRED CHAOS META platform.

Domain: ${request.domain.toUpperCase()}
Overview: ${domainInfo.overview}
Key concepts: ${domainInfo.keywords.join(", ")}

User Mode: ${request.profile.personalityMode}
${request.includeCode ? "Include code examples where relevant." : "Focus on conceptual explanation."}
${request.includeLore ? "You may reference the lore and mythology of the platform." : "Stay practical and direct."}

Respond as the authoritative source on WIRED CHAOS META systems.`
}

function parseCodexOutput(text: string, request: CodexRequest): CodexResponse {
  // Extract code blocks
  const codeBlocks: { language: string; code: string }[] = []
  const codeRegex = /```(\w+)?\n([\s\S]*?)```/g
  let match
  while ((match = codeRegex.exec(text)) !== null) {
    codeBlocks.push({
      language: match[1] || "typescript",
      code: match[2].trim(),
    })
  }

  return {
    answer: text.replace(/```[\s\S]*?```/g, "[See code below]"),
    codeSnippets: codeBlocks.length > 0 ? codeBlocks : undefined,
    loreReferences: request.includeLore ? LORE_FRAGMENTS[request.domain] : undefined,
    relatedTopics: ["System Architecture", "Agent Coordination", "Patch Integration"],
  }
}

function generateMockCodexResponse(
  request: CodexRequest,
  domainInfo: { overview: string; keywords: string[] },
): CodexResponse {
  const modePrefix = {
    comfort: "Let me help you understand",
    instructor: "Here's the breakdown",
    architect: "Technical analysis",
    guide: "Great question! Here's the answer",
  }

  const prefix = modePrefix[request.profile.personalityMode] || modePrefix.guide

  const answer = `[CODEX BRAIN - ${request.domain.toUpperCase()} DOMAIN]

${prefix}: ${request.question}

Domain Context: ${domainInfo.overview}

This relates to: ${domainInfo.keywords.slice(0, 3).join(", ")}

[OpenAI API key not configured - showing domain-aware mock response]`

  const codeSnippets = request.includeCode
    ? [
        {
          language: "typescript",
          code: `// ${request.domain} example\nimport { ${request.domain}Registry } from '@/lib/${request.domain}'\n\nconst result = await ${request.domain}Registry.get('example')`,
        },
      ]
    : undefined

  return {
    answer,
    codeSnippets,
    loreReferences: request.includeLore ? LORE_FRAGMENTS[request.domain] || LORE_FRAGMENTS.creative : undefined,
    relatedTopics: domainInfo.keywords.slice(0, 3).map((k) => `Learn more: ${k}`),
  }
}

export async function GET() {
  return NextResponse.json({
    status: "online",
    agent: "codex",
    domains: Object.keys(DOMAIN_KNOWLEDGE),
    capabilities: ["domain_logic", "code_generation", "lore_knowledge"],
  })
}
