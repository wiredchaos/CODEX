import { NextResponse } from "next/server"
import { capabilityGraph } from "@/lib/registry/capability-graph"
import { swarmRegistry } from "@/lib/swarms/registry"
import { mcpRegistry } from "@/lib/registry/mcp-servers"
import type { PlanStep, SwarmType } from "@/lib/patches/types"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { goal, context, constraints } = body
    const { maxSteps = 5, safeMode = true, domain } = constraints || {}

    // Get capability matches for the goal
    const suggestions = capabilityGraph.suggestAgentToolPairs(goal)

    // Build a simple plan based on suggestions
    const steps: PlanStep[] = []
    let stepNumber = 1

    for (const suggestion of suggestions) {
      if (stepNumber > maxSteps) break

      for (const tool of suggestion.tools) {
        if (stepNumber > maxSteps) break

        // Skip dangerous tools in safe mode if they require approval
        if (safeMode && tool.isDangerous && tool.requiresApproval) {
          continue
        }

        steps.push({
          stepNumber,
          agentId: suggestion.agent.name,
          toolId: tool.name,
          params: {
            goal,
            context: context || "",
          },
        })
        stepNumber++
      }
    }

    if (steps.length === 0) {
      let swarms = swarmRegistry.listActiveSwarms()

      // Filter by domain if specified
      if (domain && domain !== "auto") {
        swarms = swarmRegistry.getSwarmsByType(domain as SwarmType)
      }

      const firstSwarm = swarms[0]

      if (firstSwarm) {
        // Get tools that match swarm capabilities
        const allTools = mcpRegistry.listMcpTools()
        const matchingTools = allTools
          .filter((t) => firstSwarm.capabilities.some((cap) => t.category.toLowerCase().includes(cap.split("_")[0])))
          .slice(0, maxSteps)

        if (matchingTools.length > 0) {
          for (const tool of matchingTools) {
            steps.push({
              stepNumber: steps.length + 1,
              agentId: firstSwarm.name,
              toolId: tool.name,
              params: { goal, context: context || "", domain: domain || "auto" },
            })
          }
        } else {
          // Fallback: create a single step with the swarm
          steps.push({
            stepNumber: 1,
            agentId: firstSwarm.name,
            toolId: "analyze_and_plan",
            params: { goal, context: context || "", domain: domain || "auto" },
          })
        }
      }
    }

    return NextResponse.json({
      planId: `plan_${Date.now()}`,
      steps,
      metadata: {
        domain: domain || "auto",
        swarmCount: swarmRegistry.listActiveSwarms().length,
      },
    })
  } catch (error) {
    console.error("Planning error:", error)
    return NextResponse.json({ error: "Failed to generate plan" }, { status: 500 })
  }
}
