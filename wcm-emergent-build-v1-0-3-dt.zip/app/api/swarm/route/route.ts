// SWARM ROUTER API - Main entry point for swarm orchestration

import { type NextRequest, NextResponse } from "next/server"
import type { SwarmRouteRequest } from "@/lib/swarm/types"
import { SwarmRouter } from "@/lib/swarm/router"
import { SwarmExecutor } from "@/lib/swarm/executor"

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as SwarmRouteRequest

    if (!body.question || !body.profile) {
      return NextResponse.json({ error: "Missing question or profile" }, { status: 400 })
    }

    // Get routing decision
    const decision = SwarmRouter.route(body)

    // Execute swarm
    const response = await SwarmExecutor.execute(body)

    return NextResponse.json({
      success: true,
      decision,
      response,
    })
  } catch (err) {
    console.error("Swarm router error:", err)
    return NextResponse.json({ error: "Swarm routing failed" }, { status: 500 })
  }
}

// GET for testing/status
export async function GET() {
  return NextResponse.json({
    status: "online",
    agents: ["gemini", "sora", "grok", "codex"],
    version: "1.0.0",
  })
}
