import { NextResponse } from "next/server"
import { mcpRegistry } from "@/lib/registry/mcp-servers"
import type { ExecutionResult } from "@/lib/patches/types"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { planId, steps } = body

    const results: ExecutionResult[] = []

    for (const step of steps) {
      const startTime = Date.now()

      // Get the tool
      const tool = mcpRegistry.getTool(step.toolId)

      if (!tool) {
        results.push({
          stepNumber: step.stepNumber,
          success: false,
          output: null,
          error: `Tool ${step.toolId} not found`,
          latencyMs: Date.now() - startTime,
        })
        continue
      }

      // In a real implementation, this would call the actual MCP server
      // For now, we simulate the execution
      try {
        // Simulate API call delay
        await new Promise((resolve) => setTimeout(resolve, 500 + Math.random() * 500))

        // Mock successful execution
        results.push({
          stepNumber: step.stepNumber,
          success: true,
          output: {
            message: `Successfully executed ${tool.name}`,
            agentId: step.agentId,
            params: step.params,
          },
          error: null,
          latencyMs: Date.now() - startTime,
        })
      } catch (err) {
        results.push({
          stepNumber: step.stepNumber,
          success: false,
          output: null,
          error: err instanceof Error ? err.message : "Unknown error",
          latencyMs: Date.now() - startTime,
        })
      }
    }

    return NextResponse.json({
      planId,
      results,
      finalSummary: `Executed ${results.filter((r) => r.success).length}/${steps.length} steps successfully`,
    })
  } catch (error) {
    console.error("Execution error:", error)
    return NextResponse.json({ error: "Failed to execute plan" }, { status: 500 })
  }
}
