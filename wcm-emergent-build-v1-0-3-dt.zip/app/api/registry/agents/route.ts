import { NextResponse } from "next/server"
import { agentRegistry } from "@/lib/registry/agents"

export async function GET() {
  const agents = agentRegistry.listAgents()
  return NextResponse.json(agents)
}
