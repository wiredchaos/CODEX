import { NextResponse } from "next/server"
import { mcpRegistry } from "@/lib/registry/mcp-servers"

export async function GET() {
  const servers = mcpRegistry.listMcpServers()
  const tools = mcpRegistry.listMcpTools()

  return NextResponse.json({
    servers,
    tools,
  })
}
