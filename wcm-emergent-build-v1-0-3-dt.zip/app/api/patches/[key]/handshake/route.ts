import { NextResponse } from "next/server"
import { patchRegistry } from "@/lib/patches/registry"

interface RouteParams {
  params: Promise<{ key: string }>
}

export async function POST(request: Request, { params }: RouteParams) {
  try {
    const { key } = await params
    const body = await request.json().catch(() => ({}))
    const { returnUrl } = body

    // Get the patch
    const patch = patchRegistry.getPatchByKey(key)

    if (!patch) {
      return NextResponse.json({ error: "Patch not found" }, { status: 404 })
    }

    // In a real implementation, this would:
    // 1. Validate the user is authenticated
    // 2. Generate a signed JWT token
    // 3. Return the handshake response

    // For now, we create a mock token
    const mockToken = Buffer.from(
      JSON.stringify({
        userId: "user_mock",
        patchKey: key,
        issuedAt: Date.now(),
        expiresAt: Date.now() + 300000, // 5 minutes
      }),
    ).toString("base64")

    const redirectUrl = `${patch.appBaseUrl}/chaos-handshake?token=${mockToken}`

    return NextResponse.json({
      patchKey: key,
      appBaseUrl: patch.appBaseUrl,
      token: mockToken,
      redirectUrl,
    })
  } catch (error) {
    console.error("Handshake error:", error)
    return NextResponse.json({ error: "Handshake failed" }, { status: 500 })
  }
}
