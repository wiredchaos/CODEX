import { NextResponse } from "next/server"
import { trinityMountRegistry } from "@/lib/trinity/mount-registry"
import { TIMELINES } from "@/lib/trinity/static-floors"
import type { TrinityConsumerSession } from "@/lib/trinity/types"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const patchKey = searchParams.get("patchKey")

  if (patchKey) {
    const mount = trinityMountRegistry.getMountByPatch(patchKey)
    if (!mount) {
      return NextResponse.json({ error: "Patch not mounted to Trinity" }, { status: 404 })
    }

    const timelines = trinityMountRegistry.getAccessibleTimelines(patchKey)
    return NextResponse.json({ mount, timelines })
  }

  const mounts = trinityMountRegistry.listAllMounts()
  return NextResponse.json({ mounts })
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { patchKey, floorId, timelineKeys, kind, timelineKey } = body

    // Session initialization (for EnvironmentRenderer)
    if (kind) {
      const mount = trinityMountRegistry.getMountByPatch(patchKey)
      if (!mount) {
        return NextResponse.json({ error: "Patch not mounted to Trinity" }, { status: 403 })
      }

      // Verify timeline access if specified
      if (timelineKey && !trinityMountRegistry.hasTimelineAccess(patchKey, timelineKey)) {
        return NextResponse.json({ error: "Timeline access denied" }, { status: 403 })
      }

      // Find timeline scene URL
      const timeline = TIMELINES.find((t) => t.key === timelineKey || mount.assignedTimelines.includes(t.key))

      const session: TrinityConsumerSession = {
        sessionId: `trinity_${Date.now()}_${Math.random().toString(36).slice(2)}`,
        patchKey,
        floorId: mount.assignedFloor,
        timelineKey: timelineKey || mount.assignedTimelines[0],
        viewMode: kind === "lobby" ? "observer" : "navigator",
        connectedAt: new Date(),
        readonly: true,
        sceneUrl: timeline?.sceneUrl || "/trinity-lobby-fallback.mp4",
      }

      return NextResponse.json({ success: true, session })
    }

    // Mount creation (admin operation)
    if (!patchKey || !floorId || !timelineKeys) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const mount = trinityMountRegistry.mountPatch(patchKey, floorId, timelineKeys)
    return NextResponse.json({ success: true, mount })
  } catch (error) {
    return NextResponse.json({ error: (error as Error).message }, { status: 400 })
  }
}
