import { NextResponse } from "next/server"
import { TIMELINES } from "@/lib/trinity/static-floors"
import { trinityMountRegistry } from "@/lib/trinity/mount-registry"

export async function GET(request: Request, { params }: { params: Promise<{ key: string }> }) {
  const { key } = await params
  const { searchParams } = new URL(request.url)
  const patchKey = searchParams.get("patchKey")

  const timeline = TIMELINES.find((t) => t.key === key)
  if (!timeline) {
    return NextResponse.json({ error: "Timeline not found" }, { status: 404 })
  }

  // Verify access if patchKey provided
  if (patchKey) {
    const hasAccess = trinityMountRegistry.hasTimelineAccess(patchKey, key)
    if (!hasAccess) {
      return NextResponse.json({ error: "Access denied. Timeline not authorized for this patch." }, { status: 403 })
    }
  }

  return NextResponse.json({
    timeline,
    readonly: true,
    note: "This is read-only infrastructure. Timeline access governed by Akira Codex.",
  })
}
