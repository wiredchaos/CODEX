import { type NextRequest, NextResponse } from "next/server"
import { createVisionRequest, processVisionRequest } from "@/lib/vision/engine"
import type { VisionMode } from "@/lib/vision/types"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { prompt, mode = "blueprint", persona, imageUrl } = body

    if (!prompt) {
      return NextResponse.json({ error: "Prompt is required" }, { status: 400 })
    }

    // Create the vision request
    const visionRequest = createVisionRequest(prompt, mode as VisionMode, persona, imageUrl)

    // Process immediately (could be async/queued in production)
    const result = await processVisionRequest(visionRequest)

    return NextResponse.json({
      id: visionRequest.id,
      status: visionRequest.status,
      mode: visionRequest.mode,
      result,
    })
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Internal server error" },
      { status: 500 },
    )
  }
}
