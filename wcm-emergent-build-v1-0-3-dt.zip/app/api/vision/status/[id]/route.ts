import { type NextRequest, NextResponse } from "next/server"
import { getVisionRequest } from "@/lib/vision/engine"

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params

  const visionRequest = getVisionRequest(id)

  if (!visionRequest) {
    return NextResponse.json({ error: "Vision request not found" }, { status: 404 })
  }

  return NextResponse.json({
    id: visionRequest.id,
    status: visionRequest.status,
    mode: visionRequest.mode,
    persona: visionRequest.persona,
    createdAt: visionRequest.createdAt,
    result: visionRequest.result,
  })
}
