"use client"

import type React from "react"
import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  Boxes,
  Settings,
  Activity,
  Shield,
  Brain,
  Server,
  ChevronLeft,
  ChevronRight,
  Zap,
  User,
  Gift,
  Eye,
  Rocket,
  Bot,
  Network,
  Layers,
} from "lucide-react"
import { Button } from "@/components/ui/button"

interface ShellLayoutProps {
  children: React.ReactNode
}

const navigation = [
  { name: "Dashboard", href: "/", icon: LayoutDashboard },
  { name: "Patches", href: "/patches", icon: Boxes },
  { name: "Swarms", href: "/swarms", icon: Brain },
  { name: "Swarm Router", href: "/swarm-router", icon: Network },
  { name: "Avatars", href: "/avatars", icon: User },
  { name: "NEURO", href: "/neuro", icon: Bot },
  { name: "Vision", href: "/vision", icon: Eye },
  { name: "MCP Servers", href: "/mcp", icon: Server },
  { name: "Antigravity", href: "/antigravity", icon: Rocket },
  { name: "Tasks", href: "/tasks", icon: Zap },
  { name: "Trinity Mount", href: "/trinity-mount", icon: Layers },
  { name: "Trinity Lobby", href: "/trinity-lobby", icon: Layers },
  { name: "Referral", href: "/referral", icon: Gift },
  { name: "Status", href: "/status", icon: Activity },
  { name: "Settings", href: "/settings", icon: Settings },
  { name: "Admin", href: "/admin/patches", icon: Shield },
]

export function ShellLayout({ children }: ShellLayoutProps) {
  const [collapsed, setCollapsed] = useState(false)
  const pathname = usePathname()

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside
        className={cn(
          "glass-panel border-r border-[#00FFFF]/20 flex flex-col transition-all duration-300",
          collapsed ? "w-16" : "w-64",
        )}
      >
        {/* Logo */}
        <div className="p-4 border-b border-[#00FFFF]/20">
          <Link href="/" className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#00FFFF]/10 flex items-center justify-center glow-cyan">
              <Zap className="w-6 h-6 text-[#00FFFF]" />
            </div>
            {!collapsed && (
              <div>
                <h1 className="font-bold text-[#00FFFF] text-glow-cyan text-sm">WIRED CHAOS</h1>
                <p className="text-xs text-muted-foreground">META</p>
              </div>
            )}
          </Link>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-2 space-y-1">
          {navigation.map((item) => {
            const isActive = pathname === item.href || pathname.startsWith(item.href + "/")
            return (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 px-3 py-2 rounded-lg transition-all",
                  isActive
                    ? "bg-[#00FFFF]/10 text-[#00FFFF] glow-cyan"
                    : "text-muted-foreground hover:bg-[#00FFFF]/5 hover:text-foreground",
                )}
              >
                <item.icon className="w-5 h-5 flex-shrink-0" />
                {!collapsed && <span className="text-sm">{item.name}</span>}
              </Link>
            )
          })}
        </nav>

        {/* Collapse toggle */}
        <div className="p-2 border-t border-[#00FFFF]/20">
          <Button variant="ghost" size="sm" onClick={() => setCollapsed(!collapsed)} className="w-full justify-center">
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </Button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-auto">
        <div className="p-6">{children}</div>
      </main>
    </div>
  )
}
