import type { LucideIcon } from "lucide-react"

interface ReferralStatsProps {
  title: string
  value: string
  description: string
  icon: LucideIcon
  color: "cyan" | "green" | "red" | "pink"
}

const colorMap = {
  cyan: {
    border: "border-[#00FFFF]/30",
    text: "text-[#00FFFF]",
    bg: "bg-[#00FFFF]/10",
    glow: "glow-cyan",
  },
  green: {
    border: "border-[#39FF14]/30",
    text: "text-[#39FF14]",
    bg: "bg-[#39FF14]/10",
    glow: "glow-green",
  },
  red: {
    border: "border-[#FF3131]/30",
    text: "text-[#FF3131]",
    bg: "bg-[#FF3131]/10",
    glow: "glow-red",
  },
  pink: {
    border: "border-[#FF00FF]/30",
    text: "text-[#FF00FF]",
    bg: "bg-[#FF00FF]/10",
    glow: "glow-pink",
  },
}

export function ReferralStats({ title, value, description, icon: Icon, color }: ReferralStatsProps) {
  const colors = colorMap[color]

  return (
    <div className={`glass-panel rounded-lg p-5 ${colors.border} border ${colors.glow}`}>
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <p className="text-sm text-muted-foreground">{title}</p>
          <p className={`text-3xl font-bold ${colors.text}`}>{value}</p>
          <p className="text-xs text-muted-foreground">{description}</p>
        </div>
        <div className={`p-2 rounded-lg ${colors.bg}`}>
          <Icon className={`w-5 h-5 ${colors.text}`} />
        </div>
      </div>
    </div>
  )
}
