import { cn } from "@/lib/utils"

interface TagChipProps {
  label: string
  variant?: "cyan" | "green" | "pink" | "red" | "default"
}

export function TagChip({ label, variant = "default" }: TagChipProps) {
  const variants = {
    cyan: "bg-[#00FFFF]/10 text-[#00FFFF] border-[#00FFFF]/30",
    green: "bg-[#39FF14]/10 text-[#39FF14] border-[#39FF14]/30",
    pink: "bg-[#FF00FF]/10 text-[#FF00FF] border-[#FF00FF]/30",
    red: "bg-[#FF3131]/10 text-[#FF3131] border-[#FF3131]/30",
    default: "bg-muted text-muted-foreground border-border",
  }

  return (
    <span className={cn("inline-flex items-center px-2 py-0.5 rounded-md text-xs border", variants[variant])}>
      {label}
    </span>
  )
}
