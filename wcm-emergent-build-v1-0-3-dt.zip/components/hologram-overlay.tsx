"use client"

import { useState, useEffect } from "react"
import { X, Loader2, Eye, Cpu, Palette, Layout } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { BlueprintOutput, VisionResult } from "@/lib/vision/types"

interface HologramOverlayProps {
  isOpen: boolean
  onClose: () => void
  result?: VisionResult
  isLoading?: boolean
}

export function HologramOverlay({ isOpen, onClose, result, isLoading }: HologramOverlayProps) {
  const [scanLine, setScanLine] = useState(0)

  useEffect(() => {
    if (!isOpen) return
    const interval = setInterval(() => {
      setScanLine((prev) => (prev + 1) % 100)
    }, 50)
    return () => clearInterval(interval)
  }, [isOpen])

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />

      {/* Hologram Container */}
      <div className="relative w-full max-w-4xl mx-4 bg-black/90 border border-cyan-500/50 rounded-lg overflow-hidden">
        {/* Scan line effect */}
        <div
          className="absolute inset-x-0 h-px bg-gradient-to-r from-transparent via-cyan-400 to-transparent opacity-50 pointer-events-none"
          style={{ top: `${scanLine}%` }}
        />

        {/* Grid overlay */}
        <div
          className="absolute inset-0 opacity-10 pointer-events-none"
          style={{
            backgroundImage: `
              linear-gradient(rgba(0, 255, 255, 0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(0, 255, 255, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: "20px 20px",
          }}
        />

        {/* Header */}
        <div className="relative flex items-center justify-between p-4 border-b border-cyan-500/30">
          <div className="flex items-center gap-2">
            <Eye className="w-5 h-5 text-cyan-400" />
            <span className="text-cyan-400 font-mono text-sm">GIGA MAX VISION OUTPUT</span>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-gray-400 hover:text-white">
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Content */}
        <div className="relative p-6 min-h-[400px]">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center h-full gap-4">
              <Loader2 className="w-12 h-12 text-cyan-400 animate-spin" />
              <p className="text-cyan-400 font-mono">Processing vision request...</p>
            </div>
          ) : result?.blueprint ? (
            <BlueprintView blueprint={result.blueprint} />
          ) : result?.analysis ? (
            <AnalysisView analysis={result.analysis} />
          ) : result?.error ? (
            <div className="text-red-400 font-mono text-center">Error: {result.error}</div>
          ) : (
            <div className="text-gray-500 font-mono text-center">No results to display</div>
          )}
        </div>

        {/* Footer */}
        <div className="relative p-4 border-t border-cyan-500/30 flex items-center justify-between">
          <span className="text-xs text-gray-500 font-mono">BLUEPRINT MODE ACTIVE</span>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-xs text-green-400 font-mono">ONLINE</span>
          </div>
        </div>
      </div>
    </div>
  )
}

function BlueprintView({ blueprint }: { blueprint: BlueprintOutput }) {
  return (
    <div className="space-y-6">
      {/* Layout Info */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Layout className="w-4 h-4 text-cyan-400" />
            <span className="text-cyan-400 font-mono text-sm">LAYOUT</span>
          </div>
          <p className="text-white font-mono">{blueprint.layout}</p>
        </div>

        <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Cpu className="w-4 h-4 text-purple-400" />
            <span className="text-purple-400 font-mono text-sm">COMPONENTS</span>
          </div>
          <p className="text-white font-mono text-sm">{blueprint.components.join(", ")}</p>
        </div>

        <div className="bg-pink-500/10 border border-pink-500/30 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Palette className="w-4 h-4 text-pink-400" />
            <span className="text-pink-400 font-mono text-sm">COLORS</span>
          </div>
          <div className="flex gap-2">
            {blueprint.colorScheme.map((color, i) => (
              <div
                key={i}
                className="w-6 h-6 rounded border border-white/20"
                style={{ backgroundColor: color }}
                title={color}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Structure Tree */}
      <div className="bg-gray-900/50 border border-gray-700 rounded-lg p-4">
        <h3 className="text-cyan-400 font-mono text-sm mb-3">STRUCTURE</h3>
        <div className="font-mono text-sm">
          {blueprint.structure.map((node) => (
            <StructureNode key={node.id} node={node} depth={0} />
          ))}
        </div>
      </div>

      {/* Typography */}
      <div className="bg-gray-900/50 border border-gray-700 rounded-lg p-4">
        <h3 className="text-cyan-400 font-mono text-sm mb-3">TYPOGRAPHY</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <span className="text-gray-400 text-xs">Heading</span>
            <p className="text-white">{blueprint.typography.heading}</p>
          </div>
          <div>
            <span className="text-gray-400 text-xs">Body</span>
            <p className="text-white">{blueprint.typography.body}</p>
          </div>
        </div>
      </div>
    </div>
  )
}

function StructureNode({ node, depth }: { node: any; depth: number }) {
  const indent = depth * 16
  const typeColors: Record<string, string> = {
    container: "text-cyan-400",
    section: "text-green-400",
    component: "text-purple-400",
    text: "text-yellow-400",
    image: "text-pink-400",
  }

  return (
    <div>
      <div style={{ paddingLeft: indent }} className="py-1">
        <span className={typeColors[node.type] || "text-gray-400"}>[{node.type}]</span>{" "}
        <span className="text-white">{node.name}</span>
      </div>
      {node.children?.map((child: any) => (
        <StructureNode key={child.id} node={child} depth={depth + 1} />
      ))}
    </div>
  )
}

function AnalysisView({ analysis }: { analysis: any }) {
  return (
    <div className="space-y-4">
      <div className="bg-gray-900/50 border border-gray-700 rounded-lg p-4">
        <h3 className="text-cyan-400 font-mono text-sm mb-2">DESCRIPTION</h3>
        <p className="text-white">{analysis.description}</p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-gray-900/50 border border-gray-700 rounded-lg p-4">
          <h3 className="text-cyan-400 font-mono text-sm mb-2">STYLE</h3>
          <p className="text-white">{analysis.style}</p>
        </div>
        <div className="bg-gray-900/50 border border-gray-700 rounded-lg p-4">
          <h3 className="text-cyan-400 font-mono text-sm mb-2">MOOD</h3>
          <p className="text-white">{analysis.mood}</p>
        </div>
      </div>

      <div className="bg-gray-900/50 border border-gray-700 rounded-lg p-4">
        <h3 className="text-cyan-400 font-mono text-sm mb-2">COLORS</h3>
        <div className="flex gap-2">
          {analysis.colors.map((color: string, i: number) => (
            <div
              key={i}
              className="w-8 h-8 rounded border border-white/20"
              style={{ backgroundColor: color }}
              title={color}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
