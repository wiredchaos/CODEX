"use client"

import { useState } from "react"
import { Copy, Check, Twitter, Linkedin, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"

interface ReferralCardProps {
  referralCode: string
  referralLink: string
}

export function ReferralCard({ referralCode, referralLink }: ReferralCardProps) {
  const [copied, setCopied] = useState(false)

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(referralLink)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error("Failed to copy:", err)
    }
  }

  const shareOnTwitter = () => {
    const text = encodeURIComponent("Join me on v0 - Build with AI. Use my referral link:")
    window.open(`https://twitter.com/intent/tweet?text=${text}&url=${encodeURIComponent(referralLink)}`, "_blank")
  }

  const shareOnLinkedIn = () => {
    window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(referralLink)}`, "_blank")
  }

  const shareViaEmail = () => {
    const subject = encodeURIComponent("Join v0 - Build with AI")
    const body = encodeURIComponent(
      `Hey!\n\nI wanted to share v0 with you. Use my referral link to sign up:\n\n${referralLink}\n\nLet me know what you think!`,
    )
    window.open(`mailto:?subject=${subject}&body=${body}`, "_blank")
  }

  return (
    <div className="glass-panel rounded-lg p-6 space-y-6 glow-cyan">
      {/* Referral Code Display */}
      <div className="text-center space-y-2">
        <p className="text-sm text-muted-foreground uppercase tracking-wider">Your Referral Code</p>
        <div className="inline-block px-6 py-3 bg-[#00FFFF]/10 border-2 border-[#00FFFF]/50 rounded-lg">
          <span className="text-3xl font-mono font-bold text-[#00FFFF] tracking-widest">{referralCode}</span>
        </div>
      </div>

      {/* Referral Link */}
      <div className="space-y-3">
        <p className="text-sm text-muted-foreground">Your Referral Link</p>
        <div className="flex gap-2">
          <div className="flex-1 bg-secondary/50 border border-border rounded-lg px-4 py-3 font-mono text-sm text-foreground truncate">
            {referralLink}
          </div>
          <Button
            onClick={copyToClipboard}
            variant="outline"
            className={`shrink-0 border-[#00FFFF]/50 hover:bg-[#00FFFF]/10 ${copied ? "text-[#39FF14] border-[#39FF14]/50" : "text-[#00FFFF]"}`}
          >
            {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
            {copied ? "Copied!" : "Copy"}
          </Button>
        </div>
      </div>

      {/* Share Buttons */}
      <div className="space-y-3">
        <p className="text-sm text-muted-foreground">Share via</p>
        <div className="flex flex-wrap gap-3">
          <Button
            onClick={shareOnTwitter}
            variant="outline"
            className="border-[#1DA1F2]/50 text-[#1DA1F2] hover:bg-[#1DA1F2]/10 bg-transparent"
          >
            <Twitter className="w-4 h-4 mr-2" />
            Twitter
          </Button>
          <Button
            onClick={shareOnLinkedIn}
            variant="outline"
            className="border-[#0A66C2]/50 text-[#0A66C2] hover:bg-[#0A66C2]/10 bg-transparent"
          >
            <Linkedin className="w-4 h-4 mr-2" />
            LinkedIn
          </Button>
          <Button
            onClick={shareViaEmail}
            variant="outline"
            className="border-[#FF00FF]/50 text-[#FF00FF] hover:bg-[#FF00FF]/10 bg-transparent"
          >
            <Mail className="w-4 h-4 mr-2" />
            Email
          </Button>
        </div>
      </div>
    </div>
  )
}
