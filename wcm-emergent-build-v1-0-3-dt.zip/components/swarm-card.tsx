import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { StatusPill } from "@/components/status-pill"
import type { SwarmAgent } from "@/lib/patches/types"
import { Bot, ArrowRight } from "lucide-react"

interface SwarmCardProps {
  swarm: SwarmAgent
}

const SWARM_TYPE_COLORS: Record<string, string> = {
  system: "#00FFFF",
  tax: "#00FFFF",
  trust: "#FF00FF",
  entity: "#39FF14",
  triad: "#39FF14",
  content: "#FF00FF",
  health: "#39FF14",
  other: "#FFFFFF",
}

export function SwarmCard({ swarm }: SwarmCardProps) {
  const color = SWARM_TYPE_COLORS[swarm.swarmType] || "#FFFFFF"

  return (
    <Link href={`/swarms/${swarm.key}`}>
      <Card className="glass-card hover:border-[#00FFFF]/50 transition-all group cursor-pointer h-full">
        <CardHeader className="pb-2">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2">
              <div
                className="w-10 h-10 rounded-lg flex items-center justify-center"
                style={{ backgroundColor: `${color}20`, border: `1px solid ${color}40` }}
              >
                <Bot className="w-5 h-5" style={{ color }} />
              </div>
              <div>
                <CardTitle className="text-base" style={{ color }}>
                  {swarm.name}
                </CardTitle>
                <p className="text-xs text-muted-foreground">{swarm.role}</p>
              </div>
            </div>
            <StatusPill status={swarm.isActive ? "online" : "offline"} />
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-muted-foreground line-clamp-2">{swarm.description}</p>
          <div className="flex flex-wrap gap-1">
            {swarm.capabilities.slice(0, 3).map((cap) => (
              <Badge key={cap} variant="outline" className="text-xs">
                {cap.replace(/_/g, " ")}
              </Badge>
            ))}
            {swarm.capabilities.length > 3 && (
              <Badge variant="outline" className="text-xs">
                +{swarm.capabilities.length - 3}
              </Badge>
            )}
          </div>
          <div className="flex items-center justify-end text-xs text-muted-foreground group-hover:text-[#00FFFF] transition-colors">
            View Details <ArrowRight className="w-3 h-3 ml-1" />
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}
