"use client"

import { useEffect, useState, useRef } from "react"
import { NeuroEngine } from "@/lib/neuro/neuro-engine"
import type { NeuroState, VideoIntent } from "@/lib/neuro/types"
import { X, Send, Loader2, HelpCircle, Zap, Volume2, VolumeX } from "lucide-react"

export function NeuroAvatar() {
  const [neuroState, setNeuroState] = useState<NeuroState | null>(null)
  const [isVisible, setIsVisible] = useState(false)
  const [isExpanded, setIsExpanded] = useState(false)
  const [userInput, setUserInput] = useState("")
  const [neuroReply, setNeuroReply] = useState<string | null>(null)
  const [videoUrl, setVideoUrl] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const inputRef = useRef<HTMLTextAreaElement>(null)

  const lastKeyTimeRef = useRef<number>(Date.now())
  const eraseCountRef = useRef<number>(0)

  useEffect(() => {
    const state = NeuroEngine.initialize()
    setNeuroState(state)
    setTimeout(() => setIsVisible(true), 500)

    const handleClick = () => {
      const updated = NeuroEngine.update("click")
      if (updated) setNeuroState(updated)
    }

    const handleKeyDown = (e: KeyboardEvent) => {
      const now = Date.now()

      // Track hesitation (no keypress for > 6 seconds)
      if (lastKeyTimeRef.current && now - lastKeyTimeRef.current > 6000) {
        NeuroEngine.registerEvent({ type: "KEY_HESITATION", timestamp: now })
      }
      lastKeyTimeRef.current = now

      // Track erase loops
      if (e.key === "Backspace" || e.key === "Delete") {
        eraseCountRef.current += 1
        if (eraseCountRef.current > 8) {
          NeuroEngine.registerEvent({ type: "KEY_ERASE_LOOP", timestamp: now })
          eraseCountRef.current = 0
        }
        const updated = NeuroEngine.update("erase")
        if (updated) setNeuroState(updated)
      } else {
        eraseCountRef.current = 0
        const updated = NeuroEngine.update("keypress")
        if (updated) setNeuroState(updated)
      }
    }

    const handleScroll = () => {
      const updated = NeuroEngine.update("scroll")
      if (updated) setNeuroState(updated)
    }

    window.addEventListener("click", handleClick)
    window.addEventListener("keydown", handleKeyDown)
    window.addEventListener("scroll", handleScroll)

    return () => {
      window.removeEventListener("click", handleClick)
      window.removeEventListener("keydown", handleKeyDown)
      window.removeEventListener("scroll", handleScroll)
    }
  }, [])

  const handleAsk = async (intent: VideoIntent = "overview") => {
    if (!userInput.trim() || !neuroState) {
      NeuroEngine.registerEvent({ type: "HELP_REQUEST", timestamp: Date.now() })
      setNeuroReply("Tell me what you're trying to do, and I'll walk you through it.")
      return
    }

    setLoading(true)
    setNeuroReply(null)
    setVideoUrl(null)

    try {
      const res = await fetch("/api/neuro/video", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: userInput,
          profile: neuroState.profile,
          intent,
          section: neuroState.context.section,
        }),
      })

      const json = await res.json()

      if (!res.ok) {
        setNeuroReply(json.error || "I hit a glitch in the signal. Let's try again.")
      } else {
        if (json.text) setNeuroReply(json.text)
        if (json.videoUrl) setVideoUrl(json.videoUrl)
      }
      NeuroEngine.registerEvent({ type: "COMPLETED_STEP", timestamp: Date.now() })
      const updated = NeuroEngine.update("complete")
      if (updated) setNeuroState(updated)
    } catch {
      setNeuroReply("Something went sideways. I'll recalibrate.")
    } finally {
      setLoading(false)
    }
  }

  const handleOverwhelmed = () => {
    NeuroEngine.registerEvent({ type: "OVERWHELMED", timestamp: Date.now() })
    const updated = NeuroEngine.update("help")
    if (updated) setNeuroState(updated)
    setNeuroReply(
      "Okay, I'll simplify everything. Let's take it one step at a time. What's the ONE thing you're trying to do right now?",
    )
  }

  const handleAdvanced = () => {
    NeuroEngine.registerEvent({ type: "ADVANCED_SELF_IDENTIFY", timestamp: Date.now() })
    setNeuroReply("Got it - switching to Architect Mode. I'll skip the basics and give you direct technical answers.")
  }

  if (!neuroState || !isVisible) return null

  const { currentForm, currentMode, profile, behavioralSignals } = neuroState

  const modeLabels: Record<typeof currentMode, string> = {
    comfort: "Comfort Mode",
    instructor: "Instructor Mode",
    architect: "Architect Mode",
    guide: "Guide Mode",
  }

  const formIcons: Record<typeof currentForm, string> = {
    human: "👤",
    digital: "⚡",
    guardian: "🐕",
    sovereign: "👑",
    hybrid: "🔮",
  }

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Collapsed Avatar Button */}
      {!isExpanded && (
        <button
          onClick={() => setIsExpanded(true)}
          className="group relative w-16 h-16 rounded-full bg-gradient-to-br from-primary/30 to-accent/30 border-2 border-primary/60 backdrop-blur-md flex items-center justify-center shadow-lg shadow-primary/30 transition-all duration-300 hover:scale-110 hover:shadow-primary/50"
        >
          <span className="text-3xl">{formIcons[currentForm]}</span>
          <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-background animate-pulse" />

          {/* Tooltip on hover */}
          <div className="absolute bottom-full right-0 mb-2 w-48 bg-card/95 backdrop-blur-md border border-border rounded-lg p-2 shadow-xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
            <div className="text-xs">
              <div className="font-bold text-primary">NEURO Navigator</div>
              <div className="text-muted-foreground">{modeLabels[currentMode]}</div>
            </div>
          </div>
        </button>
      )}

      {/* Expanded Panel */}
      {isExpanded && (
        <div className="w-80 bg-card/95 backdrop-blur-xl border border-primary/30 rounded-2xl shadow-2xl shadow-primary/20 overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between p-3 border-b border-border bg-gradient-to-r from-primary/10 to-accent/10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary/40 to-accent/40 border border-primary/60 flex items-center justify-center shadow-lg shadow-primary/30">
                <span className="text-xl">{formIcons[currentForm]}</span>
              </div>
              <div>
                <div className="text-sm font-bold text-primary">NEURO Navigator</div>
                <div className="text-[10px] text-muted-foreground">{modeLabels[currentMode]}</div>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setIsMuted(!isMuted)}
                className="p-1.5 rounded-full hover:bg-muted/50 transition-colors"
              >
                {isMuted ? (
                  <VolumeX className="w-4 h-4 text-muted-foreground" />
                ) : (
                  <Volume2 className="w-4 h-4 text-primary" />
                )}
              </button>
              <button
                onClick={() => setIsExpanded(false)}
                className="p-1.5 rounded-full hover:bg-muted/50 transition-colors"
              >
                <X className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="p-3 space-y-3 max-h-96 overflow-y-auto">
            {/* Intro text */}
            <div className="text-[11px] text-muted-foreground leading-relaxed">
              I adapt to your pace and comfort level. Ask me anything about WIRED CHAOS META - I can answer in text and
              video.
            </div>

            {/* Input */}
            <textarea
              ref={inputRef}
              className="w-full min-h-[60px] rounded-xl bg-background/60 border border-primary/20 px-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
              placeholder="What are you trying to do?"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault()
                  handleAsk()
                }
              }}
            />

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => handleAsk("overview")}
                disabled={loading}
                className="flex-1 flex items-center justify-center gap-1.5 rounded-full px-3 py-2 text-[11px] font-semibold bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 transition-colors"
              >
                {loading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Send className="w-3 h-3" />}
                {loading ? "Thinking..." : "Answer"}
              </button>
              <button
                onClick={handleOverwhelmed}
                disabled={loading}
                className="flex items-center gap-1 rounded-full px-3 py-2 text-[11px] border border-primary/40 text-primary hover:bg-primary/10 disabled:opacity-50 transition-colors"
              >
                <HelpCircle className="w-3 h-3" />
                Overwhelmed
              </button>
            </div>

            {/* Response */}
            {neuroReply && (
              <div className="text-[11px] text-foreground bg-muted/50 border border-border rounded-xl p-3 leading-relaxed">
                {neuroReply}
              </div>
            )}

            {/* Video */}
            {videoUrl && (
              <div className="rounded-xl overflow-hidden border border-primary/30">
                <video className="w-full" src={videoUrl} controls muted={isMuted} />
              </div>
            )}

            {/* Footer Controls */}
            <div className="flex items-center justify-between pt-2 border-t border-border">
              <button
                onClick={handleAdvanced}
                className="text-[10px] text-muted-foreground hover:text-primary underline underline-offset-2 transition-colors"
              >
                I'm an advanced user
              </button>
              <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                <Zap className="w-3 h-3" />
                Frustration: {behavioralSignals.frustrationLevel}%
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
