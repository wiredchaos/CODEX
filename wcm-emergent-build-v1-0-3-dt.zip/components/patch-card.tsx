import type React from "react"
import Link from "next/link"
import type { PatchModule } from "@/lib/patches/types"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { StatusPill } from "@/components/status-pill"
import { TagChip } from "@/components/tag-chip"
import { ExternalLink, FileText, Scroll, PenTool, Brain, Calculator, Shield, Gem } from "lucide-react"

const iconMap: Record<string, React.ElementType> = {
  scroll: Scroll,
  "pen-tool": PenTool,
  brain: Brain,
  calculator: Calculator,
  shield: Shield,
  gem: Gem,
}

interface PatchCardProps {
  patch: PatchModule
}

export function PatchCard({ patch }: PatchCardProps) {
  const Icon = patch.icon ? iconMap[patch.icon] || FileText : FileText

  return (
    <Card className="glass-panel border-[#00FFFF]/20 hover:border-[#00FFFF]/40 transition-all group">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div
            className="w-12 h-12 rounded-lg flex items-center justify-center"
            style={{ backgroundColor: `${patch.primaryColor}15` }}
          >
            <Icon className="w-6 h-6" style={{ color: patch.primaryColor }} />
          </div>
          <StatusPill status={patch.status} size="sm" />
        </div>
        <CardTitle className="text-lg mt-3 text-foreground group-hover:text-[#00FFFF] transition-colors">
          {patch.displayName}
        </CardTitle>
        <CardDescription className="text-muted-foreground text-sm">{patch.category}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground line-clamp-2">{patch.description}</p>
        <div className="flex flex-wrap gap-1.5">
          {patch.capabilities.slice(0, 3).map((cap) => (
            <TagChip key={cap} label={cap} variant="cyan" />
          ))}
          {patch.capabilities.length > 3 && <TagChip label={`+${patch.capabilities.length - 3}`} variant="default" />}
        </div>
        <div className="flex gap-2 pt-2">
          <Button
            asChild
            size="sm"
            className="flex-1 bg-[#00FFFF]/10 text-[#00FFFF] hover:bg-[#00FFFF]/20 border border-[#00FFFF]/30"
          >
            <Link href={`/patches/${patch.slug}`}>View Details</Link>
          </Button>
          {patch.status === "online" && (
            <Button
              asChild
              size="sm"
              variant="outline"
              className="border-[#39FF14]/30 text-[#39FF14] hover:bg-[#39FF14]/10 bg-transparent"
            >
              <a href={patch.appBaseUrl} target="_blank" rel="noopener noreferrer">
                <ExternalLink className="w-4 h-4" />
              </a>
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
