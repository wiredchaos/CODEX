"use client"

import { useEffect, useState } from "react"
import type { TrinityConsumerSession } from "@/lib/trinity/types"

interface EnvironmentRendererProps {
  patchId: string
  kind: "lobby" | "timeline" | "floor"
  timelineKey?: string
  onHotspotClick?: (hotspotId: string) => void
}

/**
 * EnvironmentRenderer - Mounts the existing Trinity 3D Core (read-only)
 *
 * This component is a CONSUMER of the WIRED CHAOS Trinity 3D Core.
 * It does NOT implement 3D engines or create timelines.
 * All rendering is delegated to the shared Trinity system.
 */
export function EnvironmentRenderer({ patchId, kind, timelineKey, onHotspotClick }: EnvironmentRendererProps) {
  const [session, setSession] = useState<TrinityConsumerSession | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function mountEnvironment() {
      try {
        setLoading(true)
        setError(null)

        // Request mount session from Trinity Core
        const response = await fetch("/api/trinity/mount", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            patchKey: patchId,
            kind,
            timelineKey,
          }),
        })

        if (!response.ok) {
          throw new Error("Failed to mount Trinity environment")
        }

        const data = await response.json()
        setSession(data.session)
      } catch (err) {
        setError(err instanceof Error ? err.message : "Unknown error")
      } finally {
        setLoading(false)
      }
    }

    mountEnvironment()
  }, [patchId, kind, timelineKey])

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center bg-black">
        <div className="space-y-4 text-center">
          <div className="h-12 w-12 animate-spin rounded-full border-4 border-cyan-500 border-t-transparent mx-auto" />
          <p className="text-cyan-400 text-sm">Mounting Trinity Core...</p>
        </div>
      </div>
    )
  }

  if (error || !session) {
    return (
      <div className="flex h-full items-center justify-center bg-black">
        <div className="space-y-2 text-center">
          <p className="text-red-400 text-sm">Mount Failed</p>
          <p className="text-muted-foreground text-xs">{error || "No session established"}</p>
        </div>
      </div>
    )
  }

  // Video fallback if 3D not available
  return (
    <div className="relative h-full w-full bg-black">
      {/* Trinity 3D Scene Container (delegated to external Trinity Core) */}
      <div id="trinity-3d-scene" className="absolute inset-0">
        {/* Placeholder: Real Trinity Core would inject 3D scene here */}
        <video
          autoPlay
          loop
          muted
          playsInline
          className="h-full w-full object-cover"
          poster="/cyberpunk-lobby-neon.jpg"
        >
          <source src={session.sceneUrl || "/trinity-lobby-fallback.mp4"} type="video/mp4" />
        </video>
      </div>

      {/* HUD Overlay (supplied by Trinity Core) */}
      <TrinityHUD session={session} onHotspotClick={onHotspotClick} />
    </div>
  )
}

/**
 * TrinityHUD - Heads-Up Display for Trinity environment interactions
 * Uses hotspots and navigation supplied by Trinity Core
 */
function TrinityHUD({
  session,
  onHotspotClick,
}: {
  session: TrinityConsumerSession
  onHotspotClick?: (hotspotId: string) => void
}) {
  return (
    <div className="pointer-events-none absolute inset-0">
      {/* Top Bar - Session Info */}
      <div className="pointer-events-auto absolute top-4 left-4 right-4 flex items-center justify-between">
        <div className="rounded-lg border border-cyan-500/30 bg-black/60 backdrop-blur-md px-4 py-2">
          <p className="text-xs text-cyan-400 font-mono">
            TRINITY CORE · {session.viewMode.toUpperCase()} · {session.timelineKey}
          </p>
        </div>
        <div className="rounded-lg border border-pink-500/30 bg-black/60 backdrop-blur-md px-4 py-2">
          <p className="text-xs text-pink-400 font-mono">READ-ONLY</p>
        </div>
      </div>

      {/* Bottom Bar - Hotspot Navigation */}
      <div className="pointer-events-auto absolute bottom-4 left-1/2 -translate-x-1/2">
        <div className="rounded-lg border border-cyan-500/30 bg-black/60 backdrop-blur-md px-6 py-3">
          <div className="flex items-center gap-4">
            <button
              onClick={() => onHotspotClick?.("exit")}
              className="text-xs text-cyan-400 hover:text-cyan-300 transition-colors font-mono"
            >
              EXIT
            </button>
            <div className="w-px h-4 bg-cyan-500/30" />
            <p className="text-xs text-muted-foreground font-mono">Hotspots supplied by Trinity Core</p>
          </div>
        </div>
      </div>

      {/* Scanline Effect */}
      <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(transparent_50%,rgba(0,255,255,0.03)_50%)] bg-[length:100%_4px] animate-scan" />
    </div>
  )
}
