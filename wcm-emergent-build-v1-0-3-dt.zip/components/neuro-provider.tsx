"use client"

import { createContext, useContext, type ReactNode } from "react"
import type { NeuroState } from "@/lib/neuro/types"

const NeuroContext = createContext<NeuroState | null>(null)

export function useNeuro() {
  return useContext(NeuroContext)
}

export function NeuroProvider({ children, initialState }: { children: ReactNode; initialState?: NeuroState | null }) {
  return <NeuroContext.Provider value={initialState || null}>{children}</NeuroContext.Provider>
}
