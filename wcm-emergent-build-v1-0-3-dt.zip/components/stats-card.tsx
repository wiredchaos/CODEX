import { Card, CardContent } from "@/components/ui/card"
import type { LucideIcon } from "lucide-react"

interface StatsCardProps {
  title: string
  value: string | number
  description?: string
  icon: LucideIcon
  color?: "cyan" | "green" | "pink" | "red"
}

export function StatsCard({ title, value, description, icon: Icon, color = "cyan" }: StatsCardProps) {
  const colors = {
    cyan: { bg: "bg-[#00FFFF]/10", text: "text-[#00FFFF]", glow: "glow-cyan" },
    green: { bg: "bg-[#39FF14]/10", text: "text-[#39FF14]", glow: "glow-green" },
    pink: { bg: "bg-[#FF00FF]/10", text: "text-[#FF00FF]", glow: "glow-pink" },
    red: { bg: "bg-[#FF3131]/10", text: "text-[#FF3131]", glow: "glow-red" },
  }

  const { bg, text, glow } = colors[color]

  return (
    <Card className="glass-panel border-[#00FFFF]/20">
      <CardContent className="p-6">
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 rounded-lg ${bg} ${glow} flex items-center justify-center`}>
            <Icon className={`w-6 h-6 ${text}`} />
          </div>
          <div>
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className={`text-2xl font-bold ${text}`}>{value}</p>
            {description && <p className="text-xs text-muted-foreground">{description}</p>}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
