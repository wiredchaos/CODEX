import { cn } from "@/lib/utils"
import type { PatchStatus } from "@/lib/patches/types"

interface StatusPillProps {
  status: PatchStatus | "online" | "offline" | "unknown"
  size?: "sm" | "md"
}

export function StatusPill({ status, size = "md" }: StatusPillProps) {
  const config = {
    online: {
      bg: "bg-[#39FF14]/20",
      text: "text-[#39FF14]",
      border: "border-[#39FF14]/50",
      glow: "glow-green",
      label: "Online",
    },
    degraded: {
      bg: "bg-[#FF3131]/20",
      text: "text-[#FF3131]",
      border: "border-[#FF3131]/50",
      glow: "glow-red",
      label: "Degraded",
    },
    offline: {
      bg: "bg-gray-500/20",
      text: "text-gray-400",
      border: "border-gray-500/50",
      glow: "",
      label: "Offline",
    },
    coming_soon: {
      bg: "bg-[#FF00FF]/20",
      text: "text-[#FF00FF]",
      border: "border-[#FF00FF]/50",
      glow: "glow-pink",
      label: "Coming Soon",
    },
    unknown: {
      bg: "bg-yellow-500/20",
      text: "text-yellow-400",
      border: "border-yellow-500/50",
      glow: "",
      label: "Unknown",
    },
  }

  const { bg, text, border, glow, label } = config[status] || config.unknown

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border",
        bg,
        text,
        border,
        glow,
        size === "sm" ? "px-2 py-0.5 text-xs" : "px-3 py-1 text-sm",
      )}
    >
      <span className={cn("w-1.5 h-1.5 rounded-full", text.replace("text-", "bg-"))} />
      {label}
    </span>
  )
}
