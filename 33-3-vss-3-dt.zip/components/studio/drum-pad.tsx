"use client"

import { useState, useCallback, useRef, useEffect } from "react"
import { cn } from "@/lib/utils"

interface DrumPadProps {
  label: string
  sound: string
  color?: "red" | "cyan" | "green" | "default"
  keyBinding?: string
}

export function DrumPad({ label, sound, color = "default", keyBinding }: DrumPadProps) {
  const [isActive, setIsActive] = useState(false)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  const colorClasses = {
    red: "bg-primary/20 hover:bg-primary/30 border-primary/50 active:neon-glow-red",
    cyan: "bg-accent/20 hover:bg-accent/30 border-accent/50 active:neon-glow-cyan",
    green: "bg-neon-green/20 hover:bg-neon-green/30 border-neon-green/50",
    default: "bg-secondary/50 hover:bg-secondary/70 border-border",
  }

  const textColors = {
    red: "text-primary",
    cyan: "text-accent",
    green: "text-neon-green",
    default: "text-foreground",
  }

  const playSound = useCallback(() => {
    setIsActive(true)
    // In a real app, this would play the actual sound file
    // For now, we simulate the visual feedback
    setTimeout(() => setIsActive(false), 150)
  }, [])

  // Handle keyboard shortcuts
  useEffect(() => {
    if (!keyBinding) return

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key.toLowerCase() === keyBinding.toLowerCase()) {
        playSound()
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [keyBinding, playSound])

  return (
    <button
      onClick={playSound}
      className={cn(
        "aspect-square rounded-lg border-2 flex flex-col items-center justify-center gap-1 transition-all",
        colorClasses[color],
        isActive && "scale-95 brightness-125",
      )}
    >
      <span className={cn("text-sm font-bold", textColors[color])}>{label}</span>
      {keyBinding && <span className="text-xs text-muted-foreground font-mono">{keyBinding}</span>}
    </button>
  )
}
