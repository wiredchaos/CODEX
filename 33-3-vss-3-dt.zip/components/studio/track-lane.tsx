"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Volume2, VolumeX, Headphones } from "lucide-react"

interface TrackLaneProps {
  name: string
  color: "red" | "cyan" | "green" | "yellow"
  waveformData?: number[]
  onMute?: () => void
  onSolo?: () => void
}

export function TrackLane({ name, color, waveformData = [], onMute, onSolo }: TrackLaneProps) {
  const [isMuted, setIsMuted] = useState(false)
  const [isSolo, setIsSolo] = useState(false)
  const [volume, setVolume] = useState([75])
  const [pan, setPan] = useState([50])

  const colorClasses = {
    red: "bg-primary/30 border-primary/50",
    cyan: "bg-accent/30 border-accent/50",
    green: "bg-neon-green/30 border-neon-green/50",
    yellow: "bg-yellow-500/30 border-yellow-500/50",
  }

  const waveColors = {
    red: "bg-primary",
    cyan: "bg-accent",
    green: "bg-neon-green",
    yellow: "bg-yellow-500",
  }

  // Generate random waveform if none provided
  const displayWaveform = waveformData.length > 0 ? waveformData : Array.from({ length: 100 }, () => Math.random())

  return (
    <div className={cn("rounded-lg border p-3", colorClasses[color])}>
      <div className="flex items-center gap-4">
        {/* Track Controls */}
        <div className="w-32 flex-shrink-0 space-y-2">
          <p className="text-sm font-medium truncate">{name}</p>
          <div className="flex items-center gap-1">
            <Button
              size="icon"
              variant="ghost"
              className={cn("h-7 w-7", isMuted && "bg-destructive/20 text-destructive")}
              onClick={() => {
                setIsMuted(!isMuted)
                onMute?.()
              }}
            >
              {isMuted ? <VolumeX className="h-3 w-3" /> : <Volume2 className="h-3 w-3" />}
            </Button>
            <Button
              size="icon"
              variant="ghost"
              className={cn("h-7 w-7", isSolo && "bg-accent/20 text-accent")}
              onClick={() => {
                setIsSolo(!isSolo)
                onSolo?.()
              }}
            >
              <Headphones className="h-3 w-3" />
            </Button>
          </div>
          <div className="space-y-1">
            <Slider value={volume} onValueChange={setVolume} max={100} className="h-1" />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Vol</span>
              <span>{volume[0]}%</span>
            </div>
          </div>
        </div>

        {/* Waveform Display */}
        <div className="flex-1 h-16 flex items-end gap-px rounded overflow-hidden bg-background/50">
          {displayWaveform.map((value, index) => (
            <div
              key={index}
              className={cn("flex-1 rounded-t", waveColors[color], isMuted && "opacity-30")}
              style={{ height: `${value * 100}%` }}
            />
          ))}
        </div>

        {/* Pan Control */}
        <div className="w-20 flex-shrink-0 space-y-1">
          <Slider value={pan} onValueChange={setPan} max={100} className="h-1" />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>L</span>
            <span>R</span>
          </div>
        </div>
      </div>
    </div>
  )
}
