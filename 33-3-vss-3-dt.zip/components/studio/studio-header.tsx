"use client"

import { cn } from "@/lib/utils"
import { getTierInfo, type UserTier } from "@/lib/auth"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Radio, User, Wallet } from "lucide-react"

interface StudioHeaderProps {
  user?: {
    id: string
    display_name: string | null
    tier: UserTier
    wallet: string | null
  }
  currentRoom?: string
}

export function StudioHeader({ user, currentRoom }: StudioHeaderProps) {
  const tierInfo = user ? getTierInfo(user.tier) : null

  return (
    <header className="glass-panel border-b border-border/50 px-6 py-4">
      <div className="flex items-center justify-between">
        {/* Logo and Brand */}
        <div className="flex items-center gap-4">
          <div className="relative">
            <Radio className="h-8 w-8 text-primary animate-pulse-glow" />
            <div className="absolute inset-0 blur-lg bg-primary/30" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">
              <span className="text-glow-red">33.3</span>
              <span className="text-foreground/80 ml-2">Virtual Signal Studio</span>
            </h1>
            <p className="text-xs text-muted-foreground font-mono">VSS-33.3 | FM DOGECHAIN</p>
          </div>
        </div>

        {/* Current Room Indicator */}
        {currentRoom && (
          <div className="hidden md:flex items-center gap-2 px-4 py-2 rounded-lg bg-secondary/50 border border-border/50">
            <div className="w-2 h-2 rounded-full bg-neon-cyan animate-pulse" />
            <span className="text-sm font-mono text-accent capitalize">{currentRoom.replace("-", " ")}</span>
          </div>
        )}

        {/* User Info */}
        <div className="flex items-center gap-4">
          {user ? (
            <>
              <div className="text-right hidden sm:block">
                <p className="text-sm font-medium">{user.display_name || "Anonymous Signal"}</p>
                <div className="flex items-center gap-2 justify-end">
                  <Badge variant="outline" className={cn("text-xs", tierInfo?.color)}>
                    {tierInfo?.name}
                  </Badge>
                  {user.wallet && (
                    <span className="text-xs text-muted-foreground font-mono">
                      {user.wallet.slice(0, 6)}...{user.wallet.slice(-4)}
                    </span>
                  )}
                </div>
              </div>
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
                <User className="h-5 w-5" />
              </Button>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                <Wallet className="h-4 w-4" />
                Connect
              </Button>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}
