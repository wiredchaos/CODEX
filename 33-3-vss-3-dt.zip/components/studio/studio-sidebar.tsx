"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { canAccessRoom, type UserTier } from "@/lib/auth"
import { Mic, Music, Sliders, Settings, Coins, Lock, ListMusic, Radio, ChevronRight } from "lucide-react"

interface StudioSidebarProps {
  userTier: UserTier
}

const rooms = [
  {
    id: "dashboard",
    name: "Dashboard",
    path: "/studio",
    icon: Radio,
    description: "Studio overview",
  },
  {
    id: "signal-booth",
    name: "Signal Booth",
    path: "/studio/signal-booth",
    icon: Mic,
    description: "Recording room",
  },
  {
    id: "producer-room",
    name: "Producer Room",
    path: "/studio/producer-room",
    icon: Music,
    description: "Beat creation",
  },
  {
    id: "mix-room",
    name: "Mix Room",
    path: "/studio/mix-room",
    icon: Sliders,
    description: "Mixing & mastering",
  },
  {
    id: "control-room",
    name: "Control Room",
    path: "/studio/control-room",
    icon: Settings,
    description: "Project management",
  },
  {
    id: "mint",
    name: "Mint",
    path: "/studio/mint",
    icon: Coins,
    description: "NFT minting",
  },
  {
    id: "playlists",
    name: "Playlists",
    path: "/studio/playlists",
    icon: ListMusic,
    description: "Browse playlists",
  },
]

export function StudioSidebar({ userTier }: StudioSidebarProps) {
  const pathname = usePathname()

  return (
    <aside className="w-64 glass-panel border-r border-border/50 flex flex-col">
      <nav className="flex-1 p-4 space-y-2">
        {rooms.map((room) => {
          const isActive = pathname === room.path
          const hasAccess = room.id === "dashboard" || canAccessRoom(userTier, room.id)
          const Icon = room.icon

          return (
            <Link
              key={room.id}
              href={hasAccess ? room.path : "/studio/gate"}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-lg transition-all group",
                isActive
                  ? "bg-primary/20 border border-primary/50 neon-glow-red"
                  : hasAccess
                    ? "hover:bg-secondary/50 border border-transparent"
                    : "opacity-50 cursor-not-allowed border border-transparent",
              )}
            >
              <div className={cn("p-2 rounded-md", isActive ? "bg-primary/30" : "bg-secondary/50")}>
                <Icon
                  className={cn(
                    "h-4 w-4",
                    isActive ? "text-primary" : hasAccess ? "text-accent" : "text-muted-foreground",
                  )}
                />
              </div>
              <div className="flex-1 min-w-0">
                <p className={cn("text-sm font-medium truncate", isActive ? "text-primary" : "text-foreground")}>
                  {room.name}
                </p>
                <p className="text-xs text-muted-foreground truncate">{room.description}</p>
              </div>
              {!hasAccess ? (
                <Lock className="h-4 w-4 text-muted-foreground" />
              ) : (
                <ChevronRight
                  className={cn(
                    "h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity",
                    isActive ? "text-primary" : "text-muted-foreground",
                  )}
                />
              )}
            </Link>
          )
        })}
      </nav>

      {/* Tier Status */}
      <div className="p-4 border-t border-border/50">
        <div className="glass-panel rounded-lg p-4">
          <p className="text-xs text-muted-foreground mb-1">Access Level</p>
          <p
            className={cn(
              "text-sm font-bold capitalize",
              userTier === "producer"
                ? "text-glow-red text-primary"
                : userTier === "syndicate"
                  ? "text-neon-green"
                  : userTier === "creator"
                    ? "text-glow-cyan text-accent"
                    : "text-muted-foreground",
            )}
          >
            {userTier} Tier
          </p>
        </div>
      </div>
    </aside>
  )
}
