"use client"

import Link from "next/link"
import { cn } from "@/lib/utils"
import { canAccessRoom, type UserTier } from "@/lib/auth"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Lock, ArrowRight } from "lucide-react"
import type { LucideIcon } from "lucide-react"

interface RoomCardProps {
  id: string
  name: string
  description: string
  icon: LucideIcon
  path: string
  userTier: UserTier
  variant?: "red" | "cyan" | "green"
}

export function RoomCard({ id, name, description, icon: Icon, path, userTier, variant = "cyan" }: RoomCardProps) {
  const hasAccess = canAccessRoom(userTier, id)

  const variantStyles = {
    red: "hover:neon-glow-red hover:border-primary/50",
    cyan: "hover:neon-glow-cyan hover:border-accent/50",
    green: "hover:border-neon-green/50",
  }

  const iconColors = {
    red: "text-primary",
    cyan: "text-accent",
    green: "text-neon-green",
  }

  return (
    <Link href={hasAccess ? path : "/studio/gate"}>
      <Card
        className={cn(
          "glass-panel transition-all duration-300 group cursor-pointer h-full",
          hasAccess ? variantStyles[variant] : "opacity-60",
        )}
      >
        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className={cn("p-3 rounded-lg bg-secondary/50", hasAccess && "group-hover:bg-secondary")}>
              <Icon className={cn("h-6 w-6", hasAccess ? iconColors[variant] : "text-muted-foreground")} />
            </div>
            {!hasAccess ? (
              <Badge variant="outline" className="text-muted-foreground">
                <Lock className="h-3 w-3 mr-1" />
                Locked
              </Badge>
            ) : (
              <ArrowRight className="h-5 w-5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
            )}
          </div>
          <h3 className="text-lg font-semibold mb-2">{name}</h3>
          <p className="text-sm text-muted-foreground">{description}</p>
        </CardContent>
      </Card>
    </Link>
  )
}
