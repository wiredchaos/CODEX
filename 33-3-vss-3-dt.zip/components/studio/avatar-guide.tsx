"use client"

import { cn } from "@/lib/utils"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface AvatarGuideProps {
  avatar: "neuro" | "redfang" | "kiba"
  message: string
  className?: string
}

const avatarData = {
  neuro: {
    name: "NEURO META X",
    image: "/cyberpunk-female-avatar-neon-red-portrait.jpg",
    fallback: "NX",
    color: "border-primary",
    glow: "neon-glow-red",
  },
  redfang: {
    name: "DJ Red Fang",
    image: "/cyberpunk-dj-avatar-red-mask-portrait.jpg",
    fallback: "RF",
    color: "border-primary",
    glow: "neon-glow-red",
  },
  kiba: {
    name: "KIBA NEURO",
    image: "/cyberpunk-guardian-avatar-cyan-portrait.jpg",
    fallback: "KN",
    color: "border-accent",
    glow: "neon-glow-cyan",
  },
}

export function AvatarGuide({ avatar, message, className }: AvatarGuideProps) {
  const data = avatarData[avatar]

  return (
    <div className={cn("flex items-start gap-4", className)}>
      <Avatar className={cn("h-16 w-16 border-2", data.color, data.glow)}>
        <AvatarImage src={data.image || "/placeholder.svg"} alt={data.name} />
        <AvatarFallback className="bg-secondary text-foreground font-bold">{data.fallback}</AvatarFallback>
      </Avatar>
      <div className="flex-1 glass-panel rounded-lg p-4 relative">
        {/* Speech bubble arrow */}
        <div className="absolute left-0 top-6 -translate-x-2 w-0 h-0 border-t-8 border-b-8 border-r-8 border-transparent border-r-border/50" />
        <p className="text-xs text-accent font-mono mb-1">{data.name}</p>
        <p className="text-sm text-foreground">{message}</p>
      </div>
    </div>
  )
}
