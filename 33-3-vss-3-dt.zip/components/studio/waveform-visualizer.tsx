"use client"

import { useEffect, useRef } from "react"
import { cn } from "@/lib/utils"

interface WaveformVisualizerProps {
  isActive: boolean
  getAudioData?: () => Float32Array | null
  audioUrl?: string | null
  className?: string
  variant?: "live" | "static"
}

export function WaveformVisualizer({
  isActive,
  getAudioData,
  audioUrl,
  className,
  variant = "live",
}: WaveformVisualizerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animationRef = useRef<number>(0)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const draw = () => {
      const width = canvas.width
      const height = canvas.height

      // Clear canvas
      ctx.fillStyle = "rgba(8, 8, 20, 0.3)"
      ctx.fillRect(0, 0, width, height)

      if (variant === "live" && isActive && getAudioData) {
        const audioData = getAudioData()
        if (audioData) {
          // Draw waveform
          ctx.beginPath()
          ctx.strokeStyle = "oklch(0.65 0.25 25)" // Neon red
          ctx.lineWidth = 2

          const sliceWidth = width / audioData.length
          let x = 0

          for (let i = 0; i < audioData.length; i++) {
            const v = audioData[i]
            const y = (v * height) / 2 + height / 2

            if (i === 0) {
              ctx.moveTo(x, y)
            } else {
              ctx.lineTo(x, y)
            }
            x += sliceWidth
          }

          ctx.stroke()

          // Add glow effect
          ctx.shadowColor = "oklch(0.65 0.25 25)"
          ctx.shadowBlur = 10
          ctx.stroke()
          ctx.shadowBlur = 0
        }
      } else if (!isActive) {
        // Draw idle line
        ctx.beginPath()
        ctx.strokeStyle = "oklch(0.25 0.03 260)"
        ctx.lineWidth = 1
        ctx.moveTo(0, height / 2)
        ctx.lineTo(width, height / 2)
        ctx.stroke()

        // Draw center markers
        for (let i = 0; i < width; i += 20) {
          ctx.fillStyle = "oklch(0.3 0.03 260)"
          ctx.fillRect(i, height / 2 - 1, 2, 2)
        }
      }

      animationRef.current = requestAnimationFrame(draw)
    }

    draw()

    return () => {
      cancelAnimationFrame(animationRef.current)
    }
  }, [isActive, getAudioData, variant])

  return (
    <div className={cn("relative rounded-lg overflow-hidden bg-circuit-dark border border-border/50", className)}>
      <canvas ref={canvasRef} width={800} height={150} className="w-full h-full" />
      {/* Scan line overlay */}
      {isActive && (
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute inset-x-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent animate-scan-line" />
        </div>
      )}
    </div>
  )
}
