/**
 * TRINITY 3D CORE CONSUMER
 *
 * This component is a READ-ONLY mount point for the WIRED CHAOS Trinity 3D Core.
 * - Does NOT implement its own 3D engine
 * - Does NOT create timelines or elevators
 * - Uses video fallback when Trinity Core is not available
 * - Respects Akira Codex gating
 * - Business data stays firewalled
 */

"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { PATCH_MANIFEST } from "@/lib/patch-registry"

interface EnvironmentRendererProps {
  patchId: string
  kind: "lobby" | "gallery" | "studio" | "vault"
  hotspots?: Array<{
    id: string
    label: string
    position: { x: number; y: number }
    action: () => void
  }>
  children?: React.ReactNode
}

// Trinity Core connection status
type TrinityStatus = "connecting" | "mounted" | "fallback" | "gated"

export function EnvironmentRenderer({ patchId, kind, hotspots = [], children }: EnvironmentRendererProps) {
  const [status, setStatus] = useState<TrinityStatus>("connecting")
  const [akiraGate, setAkiraGate] = useState<boolean>(false)

  useEffect(() => {
    // Check Akira Codex gating
    const checkAkiraGate = async () => {
      // Consumer mode: check if Trinity Core is available
      // In production, this would ping the actual Trinity 3D Core service
      const trinityAvailable =
        typeof window !== "undefined" && (window as unknown as { TRINITY_3D_CORE?: boolean }).TRINITY_3D_CORE === true

      if (PATCH_MANIFEST.trinityMount.accessLevel !== "READ_ONLY") {
        setStatus("gated")
        setAkiraGate(true)
        return
      }

      if (trinityAvailable) {
        setStatus("mounted")
      } else {
        // Fallback to cinematic video render
        setStatus("fallback")
      }
    }

    const timer = setTimeout(checkAkiraGate, 500)
    return () => clearTimeout(timer)
  }, [])

  // Video fallback backgrounds by kind
  const fallbackVideos: Record<string, string> = {
    lobby: "/cyberpunk-neon-lobby-dark-atmospheric.jpg",
    gallery: "/neon-art-gallery-holographic-displays.jpg",
    studio: "/futuristic-recording-studio-neon-lights.jpg",
    vault: "/digital-vault-cyan-red-neon-motherboard.jpg",
  }

  return (
    <div className="relative w-full h-full min-h-screen overflow-hidden">
      {/* Trinity Status HUD */}
      <div className="absolute top-4 left-4 z-50 glass-panel px-3 py-2 text-xs font-mono">
        <div className="flex items-center gap-2">
          <span
            className={`w-2 h-2 rounded-full ${
              status === "mounted"
                ? "bg-accent animate-pulse"
                : status === "fallback"
                  ? "bg-yellow-500"
                  : status === "gated"
                    ? "bg-destructive"
                    : "bg-muted-foreground animate-pulse"
            }`}
          />
          <span className="text-muted-foreground">TRINITY:</span>
          <span
            className={
              status === "mounted"
                ? "text-accent"
                : status === "fallback"
                  ? "text-yellow-500"
                  : status === "gated"
                    ? "text-destructive"
                    : "text-muted-foreground"
            }
          >
            {status.toUpperCase()}
          </span>
          <span className="text-muted-foreground">|</span>
          <span className="text-muted-foreground">PATCH:</span>
          <span className="text-primary">{patchId}</span>
          <span className="text-muted-foreground">|</span>
          <span className="text-muted-foreground">KIND:</span>
          <span className="text-accent">{kind.toUpperCase()}</span>
        </div>
      </div>

      {/* Akira Codex Gate Warning */}
      {akiraGate && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-background/90">
          <div className="glass-panel p-8 text-center max-w-md">
            <div className="text-destructive text-4xl mb-4">ACCESS DENIED</div>
            <div className="text-muted-foreground mb-4">
              This environment is gated by Akira Codex.
              <br />
              Current access level does not permit Trinity mount.
            </div>
            <div className="text-xs font-mono text-muted-foreground">
              CODEX: {PATCH_MANIFEST.trinityMount.governedBy}
            </div>
          </div>
        </div>
      )}

      {/* Cinematic Background Layer */}
      {status === "fallback" && (
        <div
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: `url('${fallbackVideos[kind]}')`,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        >
          {/* Scanline overlay */}
          <div className="absolute inset-0 bg-scanlines opacity-20" />

          {/* Vignette */}
          <div className="absolute inset-0 bg-gradient-radial from-transparent via-transparent to-background/80" />

          {/* Circuit pattern overlay */}
          <div className="absolute inset-0 bg-circuit opacity-10" />
        </div>
      )}

      {/* Trinity 3D Mount Point (Consumer Interface) */}
      {status === "mounted" && (
        <div
          id="trinity-mount-point"
          data-patch-id={patchId}
          data-kind={kind}
          data-governed-by={PATCH_MANIFEST.trinityMount.governedBy}
          className="absolute inset-0 z-0"
        >
          {/* 
            Trinity 3D Core mounts here via external system.
            This patch does NOT generate 3D content.
            READ-ONLY consumer interface only.
          */}
          <div className="w-full h-full flex items-center justify-center">
            <div className="text-accent animate-pulse font-mono text-sm">TRINITY 3D CORE ACTIVE</div>
          </div>
        </div>
      )}

      {/* Hotspots Layer (supplied by core) */}
      {hotspots.length > 0 && !akiraGate && (
        <div className="absolute inset-0 z-20 pointer-events-none">
          {hotspots.map((hotspot) => (
            <button
              key={hotspot.id}
              onClick={hotspot.action}
              className="absolute pointer-events-auto glass-panel px-3 py-2 text-xs font-mono 
                         hover:border-accent transition-colors cursor-pointer group"
              style={{
                left: `${hotspot.position.x}%`,
                top: `${hotspot.position.y}%`,
                transform: "translate(-50%, -50%)",
              }}
            >
              <span className="text-accent group-hover:text-primary transition-colors">{hotspot.label}</span>
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-accent rounded-full animate-ping" />
            </button>
          ))}
        </div>
      )}

      {/* Content Layer */}
      <div className="relative z-10 w-full h-full">{children}</div>

      {/* Bottom HUD */}
      <div className="absolute bottom-4 left-4 right-4 z-50 flex justify-between items-center">
        <div className="glass-panel px-3 py-2 text-xs font-mono text-muted-foreground">
          TIMELINE: {PATCH_MANIFEST.trinityMount.timeline} | ACCESS: {PATCH_MANIFEST.trinityMount.accessLevel}
        </div>
        <div className="glass-panel px-3 py-2 text-xs font-mono text-muted-foreground">
          FLOOR: {PATCH_MANIFEST.floor} | REALM: {PATCH_MANIFEST.realm}
        </div>
      </div>
    </div>
  )
}
