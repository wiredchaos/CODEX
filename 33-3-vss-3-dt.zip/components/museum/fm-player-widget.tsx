"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Play, Pause, SkipForward, SkipBack, Volume2, Repeat, Shuffle } from "lucide-react"

interface Track {
  id: string
  title: string
  artist: string
  coverArt: string
  audioUrl: string
  duration: number
}

export function FMPlayerWidget() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [volume, setVolume] = useState(0.8)
  const [currentTrack, setCurrentTrack] = useState<Track>({
    id: "1",
    title: "Neon Dreams",
    artist: "33.3 FM Collective",
    coverArt: "/neon-abstract-album-art.jpg",
    audioUrl: "",
    duration: 240,
  })

  const audioRef = useRef<HTMLAudioElement>(null)

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume
    }
  }, [volume])

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause()
      } else {
        audioRef.current.play()
      }
      setIsPlaying(!isPlaying)
    }
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 border-t border-primary/20 bg-black/95 backdrop-blur-xl">
      <div className="glass-panel border-0 rounded-none">
        {/* Waveform Visualizer Background */}
        <div className="absolute inset-0 overflow-hidden opacity-10 pointer-events-none">
          <div className="flex items-end justify-around h-full px-4 gap-0.5">
            {Array.from({ length: 80 }).map((_, i) => (
              <div
                key={i}
                className="w-1 bg-gradient-to-t from-primary to-accent rounded-full animate-pulse"
                style={{
                  height: `${Math.random() * 100}%`,
                  animationDelay: `${i * 50}ms`,
                  animationDuration: "1s",
                }}
              />
            ))}
          </div>
        </div>

        <div className="relative container mx-auto px-4 py-3">
          <div className="flex items-center gap-4">
            {/* Track Info */}
            <div className="flex items-center gap-3 min-w-0 flex-1">
              <div className="relative w-14 h-14 rounded-md overflow-hidden circuit-glow flex-shrink-0">
                <img
                  src={currentTrack.coverArt || "/placeholder.svg"}
                  alt={currentTrack.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="min-w-0 flex-1">
                <h4 className="text-sm font-semibold text-foreground truncate">{currentTrack.title}</h4>
                <p className="text-xs text-muted-foreground truncate">{currentTrack.artist}</p>
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center gap-2">
              <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                <Shuffle className="h-4 w-4" />
              </Button>
              <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                <SkipBack className="h-4 w-4" />
              </Button>
              <Button size="sm" onClick={togglePlay} className="h-10 w-10 p-0 rounded-full neon-glow">
                {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5 ml-0.5" />}
              </Button>
              <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                <SkipForward className="h-4 w-4" />
              </Button>
              <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                <Repeat className="h-4 w-4" />
              </Button>
            </div>

            {/* Progress */}
            <div className="hidden md:flex items-center gap-2 flex-1 max-w-md">
              <span className="text-xs text-muted-foreground tabular-nums">{formatTime(currentTime)}</span>
              <Slider
                value={[currentTime]}
                max={currentTrack.duration}
                step={1}
                className="flex-1"
                onValueChange={(value) => setCurrentTime(value[0])}
              />
              <span className="text-xs text-muted-foreground tabular-nums">{formatTime(currentTrack.duration)}</span>
            </div>

            {/* Volume */}
            <div className="hidden lg:flex items-center gap-2 w-32">
              <Volume2 className="h-4 w-4 text-muted-foreground" />
              <Slider
                value={[volume * 100]}
                max={100}
                step={1}
                className="flex-1"
                onValueChange={(value) => setVolume(value[0] / 100)}
              />
            </div>

            {/* 33.3 FM Badge */}
            <div className="hidden xl:flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20">
              <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
              <span className="text-xs font-bold text-primary">33.3 FM</span>
            </div>
          </div>
        </div>
      </div>

      {currentTrack.audioUrl && <audio ref={audioRef} src={currentTrack.audioUrl} />}
    </div>
  )
}
