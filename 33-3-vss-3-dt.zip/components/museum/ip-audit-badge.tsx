"use client"

import { Badge } from "@/components/ui/badge"
import { Shield, ShieldCheck, ShieldAlert, Clock } from "lucide-react"

interface IPAuditBadgeProps {
  status: string
  score?: number
  size?: "sm" | "md" | "lg"
  showScore?: boolean
}

export function IPAuditBadge({ status, score, size = "md", showScore = true }: IPAuditBadgeProps) {
  const getStatusConfig = () => {
    switch (status) {
      case "verified":
        return {
          icon: ShieldCheck,
          label: "Verified",
          className: "bg-green-500/20 text-green-400 border-green-500/30 neon-glow-cyan",
        }
      case "disputed":
        return {
          icon: ShieldAlert,
          label: "Disputed",
          className: "bg-red-500/20 text-red-400 border-red-500/30",
        }
      case "pending":
        return {
          icon: Clock,
          label: "Pending",
          className: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
        }
      default:
        return {
          icon: Shield,
          label: "Unknown",
          className: "bg-muted/50 text-muted-foreground border-border",
        }
    }
  }

  const config = getStatusConfig()
  const Icon = config.icon

  const sizeClasses = {
    sm: "text-xs py-0.5 px-2 gap-1",
    md: "text-sm py-1 px-3 gap-1.5",
    lg: "text-base py-1.5 px-4 gap-2",
  }

  const iconSizes = {
    sm: "h-3 w-3",
    md: "h-4 w-4",
    lg: "h-5 w-5",
  }

  return (
    <Badge className={`${config.className} ${sizeClasses[size]} font-semibold`}>
      <Icon className={iconSizes[size]} />
      {config.label}
      {showScore && score !== undefined && status === "verified" && <span className="ml-1 opacity-80">{score}%</span>}
    </Badge>
  )
}
