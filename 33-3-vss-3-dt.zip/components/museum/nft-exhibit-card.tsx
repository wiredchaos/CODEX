"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ExternalLink, Play, Shield, Info } from "lucide-react"

interface NFTExhibit {
  id: string
  title: string
  artistName: string
  imageUrl: string
  animationUrl?: string
  contractAddress: string
  tokenId: string
  chain: string
  ipAuditStatus: string
  ipAuditScore: number
  audioGuideTrackId?: string
  openseaUrl?: string
}

export function NFTExhibitCard({ exhibit }: { exhibit: NFTExhibit }) {
  const [isHovered, setIsHovered] = useState(false)
  const [showInfo, setShowInfo] = useState(false)

  const getAuditBadge = () => {
    switch (exhibit.ipAuditStatus) {
      case "verified":
        return <Badge className="neon-glow bg-green-500/20 text-green-400 border-green-500/30">Verified</Badge>
      case "disputed":
        return <Badge variant="destructive">Disputed</Badge>
      default:
        return <Badge variant="secondary">Pending</Badge>
    }
  }

  return (
    <Card
      className="relative overflow-hidden group cursor-pointer transition-all duration-500 hover:scale-105 circuit-glow"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Holographic Effect Overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/0 via-accent/5 to-primary/0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

      {/* Main Image/Animation */}
      <div className="relative aspect-square overflow-hidden bg-muted/20">
        {exhibit.animationUrl ? (
          <video src={exhibit.animationUrl} autoPlay loop muted playsInline className="w-full h-full object-cover" />
        ) : (
          <img
            src={exhibit.imageUrl || "/placeholder.svg"}
            alt={exhibit.title}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
        )}

        {/* Hover Overlay */}
        <div
          className={`absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity duration-300 ${isHovered ? "opacity-100" : "opacity-0"}`}
        >
          <div className="flex flex-col items-center justify-center h-full gap-3 p-4">
            {exhibit.audioGuideTrackId && (
              <Button size="sm" className="neon-glow">
                <Play className="h-4 w-4 mr-2" />
                Audio Guide
              </Button>
            )}
            {exhibit.openseaUrl && (
              <Button size="sm" variant="outline" asChild>
                <a href={exhibit.openseaUrl} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  View on OpenSea
                </a>
              </Button>
            )}
            <Button size="sm" variant="ghost" onClick={() => setShowInfo(!showInfo)}>
              <Info className="h-4 w-4 mr-2" />
              Details
            </Button>
          </div>
        </div>

        {/* IP Audit Badge */}
        <div className="absolute top-3 right-3">{getAuditBadge()}</div>

        {/* Chain Badge */}
        <div className="absolute top-3 left-3">
          <Badge variant="secondary" className="text-xs">
            {exhibit.chain}
          </Badge>
        </div>
      </div>

      {/* Info Section */}
      <div className="p-4 space-y-2">
        <h3 className="font-semibold text-lg text-foreground truncate">{exhibit.title}</h3>
        <p className="text-sm text-muted-foreground truncate">by {exhibit.artistName}</p>

        {/* IP Audit Score */}
        {exhibit.ipAuditStatus === "verified" && (
          <div className="flex items-center gap-2">
            <Shield className="h-4 w-4 text-green-400" />
            <span className="text-xs text-muted-foreground">
              IP Score: <span className="text-green-400 font-semibold">{exhibit.ipAuditScore}%</span>
            </span>
          </div>
        )}

        {/* Token Info */}
        <div className="text-xs text-muted-foreground font-mono">
          {exhibit.contractAddress.slice(0, 6)}...{exhibit.contractAddress.slice(-4)} #{exhibit.tokenId}
        </div>
      </div>
    </Card>
  )
}
