"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { IPAuditBadge } from "@/components/museum/ip-audit-badge"
import { CheckCircle2, AlertCircle, ExternalLink, FileText } from "lucide-react"

interface IPAudit {
  id: string
  auditType: string
  status: string
  confidenceScore: number
  findings: any
  blockchainVerification: any
  openseaVerification: any
  createdAt: string
  completedAt?: string
}

interface IPAuditPanelProps {
  audits: IPAudit[]
  contractAddress: string
  tokenId: string
}

export function IPAuditPanel({ audits, contractAddress, tokenId }: IPAuditPanelProps) {
  const latestAudit = audits[0]

  return (
    <div className="space-y-6">
      {/* Overall Status */}
      <Card className="glass-panel circuit-glow">
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                IP Audit Report
                <IPAuditBadge status={latestAudit?.status || "pending"} score={latestAudit?.confidenceScore} />
              </CardTitle>
              <CardDescription className="mt-2">
                Automated verification of ownership, authenticity, and licensing
              </CardDescription>
            </div>
            <Button size="sm" variant="outline">
              <FileText className="h-4 w-4 mr-2" />
              Full Report
            </Button>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Confidence Score */}
          {latestAudit && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Confidence Score</span>
                <span className="font-bold text-foreground">{latestAudit.confidenceScore}%</span>
              </div>
              <Progress value={latestAudit.confidenceScore} className="h-2" />
            </div>
          )}

          {/* Verification Checks */}
          <div className="space-y-3">
            <h4 className="text-sm font-semibold text-foreground">Verification Checks</h4>

            <div className="grid gap-3">
              {/* Blockchain Verification */}
              <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/30 border border-border/50">
                <CheckCircle2 className="h-5 w-5 text-green-400 flex-shrink-0 mt-0.5" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-foreground">Blockchain Ownership</p>
                    <Badge variant="secondary" className="text-xs">
                      Verified
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1 font-mono truncate">
                    {contractAddress}:{tokenId}
                  </p>
                </div>
              </div>

              {/* OpenSea Verification */}
              <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/30 border border-border/50">
                <CheckCircle2 className="h-5 w-5 text-green-400 flex-shrink-0 mt-0.5" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-foreground">OpenSea Listing</p>
                    <Badge variant="secondary" className="text-xs">
                      Active
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Collection verified on OpenSea marketplace</p>
                </div>
              </div>

              {/* Metadata Verification */}
              <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/30 border border-border/50">
                <CheckCircle2 className="h-5 w-5 text-green-400 flex-shrink-0 mt-0.5" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-foreground">Metadata Integrity</p>
                    <Badge variant="secondary" className="text-xs">
                      Valid
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">IPFS metadata matches on-chain hash</p>
                </div>
              </div>

              {/* Licensing Check */}
              <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/30 border border-border/50">
                <AlertCircle className="h-5 w-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-foreground">Commercial License</p>
                    <Badge variant="secondary" className="text-xs">
                      Review Required
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">CC0 or commercial rights not explicitly stated</p>
                </div>
              </div>
            </div>
          </div>

          {/* Audit History */}
          {audits.length > 1 && (
            <div className="space-y-2">
              <h4 className="text-sm font-semibold text-foreground">Audit History</h4>
              <div className="space-y-2">
                {audits.slice(1, 4).map((audit) => (
                  <div
                    key={audit.id}
                    className="flex items-center justify-between text-xs p-2 rounded bg-muted/20 border border-border/30"
                  >
                    <span className="text-muted-foreground">{audit.auditType}</span>
                    <div className="flex items-center gap-2">
                      <IPAuditBadge status={audit.status} size="sm" showScore={false} />
                      <span className="text-muted-foreground">{new Date(audit.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* External Links */}
          <div className="flex gap-2 pt-2">
            <Button size="sm" variant="outline" className="flex-1 bg-transparent" asChild>
              <a
                href={`https://etherscan.io/token/${contractAddress}?a=${tokenId}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <ExternalLink className="h-3 w-3 mr-2" />
                Etherscan
              </a>
            </Button>
            <Button size="sm" variant="outline" className="flex-1 bg-transparent" asChild>
              <a
                href={`https://opensea.io/assets/ethereum/${contractAddress}/${tokenId}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <ExternalLink className="h-3 w-3 mr-2" />
                OpenSea
              </a>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
