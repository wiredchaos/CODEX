import { neon, type NeonQueryFunction } from "@neondatabase/serverless"

let _sql: NeonQueryFunction<false, false> | null = null

// Now sql is lazily initialized only when first accessed server-side
export function getDb(): NeonQueryFunction<false, false> {
  if (!_sql) {
    const connectionString = process.env.DATABASE_URL
    if (!connectionString) {
      throw new Error(
        "DATABASE_URL environment variable is not set. Please check your environment variables in the Vars section.",
      )
    }
    _sql = neon(connectionString)
  }
  return _sql
}

export const sql = (strings: TemplateStringsArray, ...values: unknown[]) => {
  const db = getDb()
  return db(strings, ...values)
}

// Type definitions for VSS-33.3 database entities
export type UserTier = "guest" | "creator" | "producer" | "syndicate"
export type TrackStatus = "draft" | "processing" | "ready" | "published" | "archived"
export type RoomType = "signal-booth" | "producer-room" | "mix-room"
export type PlaylistType = "genesis" | "labyrinth" | "redfang" | "spotlight" | "custom"
export type ChainType = "xrpl" | "evm" | "dogechain"
export type MintStatus = "pending" | "minting" | "confirmed" | "failed"

export interface User {
  id: string
  email: string | null
  wallet: string | null
  tier: UserTier
  avatar: string | null
  display_name: string | null
  created_at: string
  updated_at: string
}

export interface Track {
  id: string
  user_id: string
  title: string
  status: TrackStatus
  bpm: number | null
  key: string | null
  stem_urls: string[]
  waveform_url: string | null
  audio_url: string | null
  room_origin: string | null
  duration_seconds: number | null
  created_at: string
  updated_at: string
}

export interface Project {
  id: string
  user_id: string
  title: string
  cover_url: string | null
  collaborators: { id: string; name: string; role: string }[]
  royalties: Record<string, number>
  status: "active" | "completed" | "archived"
  created_at: string
  updated_at: string
}

export interface Gate {
  id: string
  user_id: string
  nft_contract: string | null
  token_id: string | null
  chain: string
  tier: UserTier
  verified_at: string
  expires_at: string | null
  created_at: string
}

export interface Playlist {
  id: string
  type: PlaylistType
  name: string
  description: string | null
  cover_url: string | null
  is_public: boolean
  created_by: string | null
  created_at: string
  updated_at: string
}

export interface PlaylistTrack {
  id: string
  playlist_id: string
  track_id: string
  priority_score: number
  added_at: string
}

export interface Mint {
  id: string
  track_id: string
  user_id: string
  chain: ChainType
  contract_address: string | null
  token_id: string | null
  transaction_hash: string | null
  metadata_uri: string | null
  royalty_config: Record<string, number>
  minted_at: string
  status: MintStatus
}
