import { sql, type User, type UserTier } from "./db"

// Get or create user from session/wallet
export async function getOrCreateUser(identifier: string, type: "email" | "wallet"): Promise<User> {
  const column = type === "email" ? "email" : "wallet"

  // Try to find existing user
  const existing = await sql`
    SELECT * FROM users WHERE ${sql(column)} = ${identifier} LIMIT 1
  `

  if (existing.length > 0) {
    return existing[0] as User
  }

  // Create new user
  const newUser = await sql`
    INSERT INTO users (id, ${sql(column)}, tier)
    VALUES (gen_random_uuid()::text, ${identifier}, 'guest')
    RETURNING *
  `

  return newUser[0] as User
}

// Validate user access tier
export async function validateUserTier(userId: string): Promise<UserTier> {
  // Check for active gates (NFT ownership)
  const gates = await sql`
    SELECT tier FROM gates 
    WHERE user_id = ${userId} 
    AND (expires_at IS NULL OR expires_at > NOW())
    ORDER BY 
      CASE tier 
        WHEN 'syndicate' THEN 1 
        WHEN 'producer' THEN 2 
        WHEN 'creator' THEN 3 
        ELSE 4 
      END
    LIMIT 1
  `

  if (gates.length > 0) {
    return gates[0].tier as UserTier
  }

  // Fallback to user's base tier
  const user = await sql`
    SELECT tier FROM users WHERE id = ${userId} LIMIT 1
  `

  return (user[0]?.tier as UserTier) || "guest"
}

// Check if user has access to a specific room
export function canAccessRoom(tier: UserTier, room: string): boolean {
  // All rooms are now accessible to everyone in 33.3 studio
  return true
}

// Get tier display info
export function getTierInfo(tier: UserTier) {
  const tierData = {
    guest: {
      name: "Guest",
      color: "text-muted-foreground",
      badge: "bg-muted",
      description: "30 sec previews, limited tools",
    },
    creator: {
      name: "Creator",
      color: "text-neon-cyan",
      badge: "bg-accent",
      description: "Full recording, basic mixing",
    },
    producer: {
      name: "Producer",
      color: "text-neon-red",
      badge: "bg-primary",
      description: "Full studio access, minting rights",
    },
    syndicate: {
      name: "Syndicate",
      color: "text-neon-green",
      badge: "bg-neon-green",
      description: "Exclusive rooms, cipher tools",
    },
  }

  return tierData[tier]
}
