// OpenSea API Integration for Neon Vault Museum
export interface OpenSeaAsset {
  identifier: string
  contract: string
  token_standard: string
  name: string
  description: string
  image_url: string
  animation_url?: string
  metadata_url: string
  opensea_url: string
  creator: string
  collection: string
  traits: Array<{ trait_type: string; value: string | number }>
}

export interface OpenSeaCollection {
  collection: string
  name: string
  description: string
  image_url: string
  banner_image_url: string
  owner: string
  total_supply: number
  contracts: Array<{ address: string; chain: string }>
}

export async function fetchOpenSeaAsset(
  contractAddress: string,
  tokenId: string,
  chain = "ethereum",
): Promise<OpenSeaAsset | null> {
  try {
    const apiKey = process.env.OPENSEA_API_KEY
    if (!apiKey) {
      console.warn("[v0] OpenSea API key not configured")
      return null
    }

    const url = `https://api.opensea.io/api/v2/chain/${chain}/contract/${contractAddress}/nfts/${tokenId}`

    const response = await fetch(url, {
      headers: {
        "X-API-KEY": apiKey,
        Accept: "application/json",
      },
      next: { revalidate: 3600 }, // Cache for 1 hour
    })

    if (!response.ok) {
      console.error("[v0] OpenSea API error:", response.statusText)
      return null
    }

    const data = await response.json()
    return data.nft
  } catch (error) {
    console.error("[v0] Error fetching OpenSea asset:", error)
    return null
  }
}

export async function fetchOpenSeaCollection(collectionSlug: string): Promise<OpenSeaCollection | null> {
  try {
    const apiKey = process.env.OPENSEA_API_KEY
    if (!apiKey) return null

    const url = `https://api.opensea.io/api/v2/collections/${collectionSlug}`

    const response = await fetch(url, {
      headers: {
        "X-API-KEY": apiKey,
        Accept: "application/json",
      },
      next: { revalidate: 3600 },
    })

    if (!response.ok) return null

    return await response.json()
  } catch (error) {
    console.error("[v0] Error fetching OpenSea collection:", error)
    return null
  }
}

export async function searchOpenSeaNFTs(query: string, chain = "ethereum"): Promise<OpenSeaAsset[]> {
  try {
    const apiKey = process.env.OPENSEA_API_KEY
    if (!apiKey) return []

    const url = `https://api.opensea.io/api/v2/chain/${chain}/nfts?search=${encodeURIComponent(query)}&limit=20`

    const response = await fetch(url, {
      headers: {
        "X-API-KEY": apiKey,
        Accept: "application/json",
      },
    })

    if (!response.ok) return []

    const data = await response.json()
    return data.nfts || []
  } catch (error) {
    console.error("[v0] Error searching OpenSea NFTs:", error)
    return []
  }
}
