/**
 * WIRED CHAOS META - Patch Registry
 *
 * DECLARATIVE MOUNT:
 * - This patch consumes the existing WIRED CHAOS Trinity 3D Core
 * - No new 3D generation
 * - No new galaxy creation
 * - Timeline access governed by Akira Codex
 * - Trinity is read-only infrastructure
 * - This patch operates as CONSUMER, not OWNER
 */

export const PATCH_MANIFEST = {
  id: "vss-33.3",
  name: "Virtual Signal Studio",
  version: "33.3.0",
  floor: "THE_NEON_VAULT",
  realm: "BUSINESS", // Business realm - Akashic mirror exists separately

  // Trinity Floor Mount - READ ONLY
  trinityMount: {
    type: "CONSUMER",
    owner: false,
    readOnly: true,
    timeline: "33.3_FM_DOGECHAIN",
    governedBy: "AKIRA_CODEX",
  },

  // Patch Routes
  routes: {
    studio: {
      path: "/studio",
      label: "Studio Dashboard",
      description: "Main studio overview",
      tier: "GUEST",
    },
    gate: {
      path: "/studio/gate",
      label: "Access Gate",
      description: "Token-gated access verification",
      tier: "GUEST",
    },
    signalBooth: {
      path: "/studio/signal-booth",
      label: "Signal Booth",
      description: "Real-time recording with AI cleanup",
      tier: "CREATOR",
    },
    producerRoom: {
      path: "/studio/producer-room",
      label: "Producer Room",
      description: "AI beat generation & sample packs",
      tier: "CREATOR",
    },
    mixRoom: {
      path: "/studio/mix-room",
      label: "Mix Room",
      description: "DAW-lite multitrack editor",
      tier: "PRODUCER",
    },
    controlRoom: {
      path: "/studio/control-room",
      label: "Control Room",
      description: "Project management & analytics",
      tier: "PRODUCER",
    },
    mint: {
      path: "/studio/mint",
      label: "Mint",
      description: "On-chain NFT minting",
      tier: "SYNDICATE",
    },
    playlists: {
      path: "/studio/playlists",
      label: "Playlists",
      description: "Curated playlist management",
      tier: "GUEST",
    },
    museum: {
      path: "/museum",
      label: "Neon Vault Museum",
      description: "Digital art gallery with OpenSea integration",
      tier: "GUEST",
    },
    galleries: {
      path: "/museum/galleries",
      label: "Galleries",
      description: "Browse curated NFT exhibitions",
      tier: "GUEST",
    },
    audits: {
      path: "/museum/audits",
      label: "IP Audits",
      description: "Blockchain-verified IP ownership",
      tier: "GUEST",
    },
    audioTours: {
      path: "/museum/audio",
      label: "Audio Tours",
      description: "33.3 FM guided experiences",
      tier: "GUEST",
    },
  },

  // Access Tiers
  tiers: {
    GUEST: { level: 0, tokensRequired: 0 },
    CREATOR: { level: 1, tokensRequired: 1 },
    PRODUCER: { level: 2, tokensRequired: 10 },
    SYNDICATE: { level: 3, tokensRequired: 100 },
  },
} as const

export type PatchRoute = keyof typeof PATCH_MANIFEST.routes
export type AccessTier = keyof typeof PATCH_MANIFEST.tiers

// Demo mode flag - opens all pathways for testing
export const DEMO_MODE = true

export function canAccessRoute(route: PatchRoute, userTier: AccessTier): boolean {
  if (DEMO_MODE) return true

  const routeTier = PATCH_MANIFEST.routes[route].tier as AccessTier
  const routeLevel = PATCH_MANIFEST.tiers[routeTier].level
  const userLevel = PATCH_MANIFEST.tiers[userTier].level

  return userLevel >= routeLevel
}
