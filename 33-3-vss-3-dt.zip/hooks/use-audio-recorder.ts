"use client"

import { useState, useRef, useCallback, useEffect } from "react"

export interface RecordingState {
  isRecording: boolean
  isPaused: boolean
  duration: number
  audioBlob: Blob | null
  audioUrl: string | null
  error: string | null
}

export interface AudioRecorderHook {
  state: RecordingState
  startRecording: () => Promise<void>
  stopRecording: () => void
  pauseRecording: () => void
  resumeRecording: () => void
  clearRecording: () => void
  getAudioData: () => Float32Array | null
}

export function useAudioRecorder(): AudioRecorderHook {
  const [state, setState] = useState<RecordingState>({
    isRecording: false,
    isPaused: false,
    duration: 0,
    audioBlob: null,
    audioUrl: null,
    error: null,
  })

  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const audioChunksRef = useRef<Blob[]>([])
  const streamRef = useRef<MediaStream | null>(null)
  const analyserRef = useRef<AnalyserNode | null>(null)
  const audioContextRef = useRef<AudioContext | null>(null)
  const timerRef = useRef<NodeJS.Timeout | null>(null)
  const startTimeRef = useRef<number>(0)

  const startRecording = useCallback(async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setState((prev) => ({
          ...prev,
          error: "Audio recording is not supported in this browser. Please use Chrome, Firefox, or Safari.",
        }))
        return
      }

      if (!window.MediaRecorder) {
        setState((prev) => ({
          ...prev,
          error: "MediaRecorder is not supported in this browser. Please use a modern browser.",
        }))
        return
      }

      if (!window.isSecureContext) {
        setState((prev) => ({
          ...prev,
          error:
            "Audio recording requires a secure connection (HTTPS). Please access this site via HTTPS or localhost.",
        }))
        return
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      streamRef.current = stream

      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext
      if (!AudioContextClass) {
        setState((prev) => ({
          ...prev,
          error: "Web Audio API is not supported in this browser.",
        }))
        stream.getTracks().forEach((track) => track.stop())
        return
      }

      const audioContext = new AudioContextClass()
      const analyser = audioContext.createAnalyser()
      const source = audioContext.createMediaStreamSource(stream)
      source.connect(analyser)
      analyser.fftSize = 2048
      audioContextRef.current = audioContext
      analyserRef.current = analyser

      let mimeType = "audio/webm"
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        mimeType = "audio/mp4"
        if (!MediaRecorder.isTypeSupported(mimeType)) {
          mimeType = "" // Let browser choose
        }
      }

      const mediaRecorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream)
      mediaRecorderRef.current = mediaRecorder
      audioChunksRef.current = []

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data)
        }
      }

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: mimeType || "audio/webm" })
        const audioUrl = URL.createObjectURL(audioBlob)
        setState((prev) => ({
          ...prev,
          isRecording: false,
          isPaused: false,
          audioBlob,
          audioUrl,
        }))
      }

      mediaRecorder.onerror = (event: any) => {
        console.error("[v0] MediaRecorder error:", event.error)
        setState((prev) => ({
          ...prev,
          error: `Recording error: ${event.error?.message || "Unknown error"}`,
          isRecording: false,
        }))
      }

      mediaRecorder.start(100) // Collect data every 100ms
      startTimeRef.current = Date.now()

      // Start duration timer
      timerRef.current = setInterval(() => {
        setState((prev) => ({
          ...prev,
          duration: Math.floor((Date.now() - startTimeRef.current) / 1000),
        }))
      }, 1000)

      setState((prev) => ({
        ...prev,
        isRecording: true,
        isPaused: false,
        error: null,
        audioBlob: null,
        audioUrl: null,
      }))
    } catch (error: any) {
      console.error("[v0] Audio recording error:", error)
      let errorMessage = "Failed to start recording. "

      if (error.name === "NotAllowedError" || error.name === "PermissionDeniedError") {
        errorMessage = "Microphone access denied. Please allow microphone access in your browser settings."
      } else if (error.name === "NotFoundError" || error.name === "DevicesNotFoundError") {
        errorMessage = "No microphone found. Please connect a microphone and try again."
      } else if (error.name === "NotSupportedError") {
        errorMessage =
          "Audio recording is not supported. Please use HTTPS or localhost, and ensure you're using a modern browser."
      } else if (error.name === "NotReadableError" || error.name === "TrackStartError") {
        errorMessage =
          "Microphone is already in use by another application. Please close other apps using the microphone."
      } else if (error.message) {
        errorMessage += error.message
      }

      setState((prev) => ({
        ...prev,
        error: errorMessage,
      }))
    }
  }, [])

  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && state.isRecording) {
      mediaRecorderRef.current.stop()
      streamRef.current?.getTracks().forEach((track) => track.stop())
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
    }
  }, [state.isRecording])

  const pauseRecording = useCallback(() => {
    if (mediaRecorderRef.current && state.isRecording && !state.isPaused) {
      mediaRecorderRef.current.pause()
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
      setState((prev) => ({ ...prev, isPaused: true }))
    }
  }, [state.isRecording, state.isPaused])

  const resumeRecording = useCallback(() => {
    if (mediaRecorderRef.current && state.isRecording && state.isPaused) {
      mediaRecorderRef.current.resume()
      const pausedDuration = state.duration
      startTimeRef.current = Date.now() - pausedDuration * 1000
      timerRef.current = setInterval(() => {
        setState((prev) => ({
          ...prev,
          duration: Math.floor((Date.now() - startTimeRef.current) / 1000),
        }))
      }, 1000)
      setState((prev) => ({ ...prev, isPaused: false }))
    }
  }, [state.isRecording, state.isPaused, state.duration])

  const clearRecording = useCallback(() => {
    if (state.audioUrl) {
      URL.revokeObjectURL(state.audioUrl)
    }
    setState({
      isRecording: false,
      isPaused: false,
      duration: 0,
      audioBlob: null,
      audioUrl: null,
      error: null,
    })
  }, [state.audioUrl])

  const getAudioData = useCallback(() => {
    if (analyserRef.current) {
      const dataArray = new Float32Array(analyserRef.current.frequencyBinCount)
      analyserRef.current.getFloatTimeDomainData(dataArray)
      return dataArray
    }
    return null
  }, [])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
      streamRef.current?.getTracks().forEach((track) => track.stop())
      if (audioContextRef.current && audioContextRef.current.state !== "closed") {
        audioContextRef.current.close()
      }
      if (state.audioUrl) {
        URL.revokeObjectURL(state.audioUrl)
      }
    }
  }, [state.audioUrl])

  return {
    state,
    startRecording,
    stopRecording,
    pauseRecording,
    resumeRecording,
    clearRecording,
    getAudioData,
  }
}
