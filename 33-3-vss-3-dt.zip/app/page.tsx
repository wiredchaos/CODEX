import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Radio,
  ArrowRight,
  Mic,
  Music,
  Sliders,
  Coins,
  Palette,
  ImageIcon,
  Shield,
  Headphones,
  LayoutDashboard,
  Lock,
  Unlock,
  Terminal,
} from "lucide-react"
import { PATCH_MANIFEST, DEMO_MODE } from "@/lib/patch-registry"
import { EnvironmentRenderer } from "@/components/trinity/environment-renderer"

export default function HomePage() {
  return (
    <EnvironmentRenderer
      patchId="VSS-33.3"
      kind="lobby"
      hotspots={[
        { id: "studio", label: "ENTER STUDIO", position: { x: 30, y: 50 }, action: () => {} },
        { id: "museum", label: "NEON VAULT", position: { x: 70, y: 50 }, action: () => {} },
      ]}
    >
      <div className="min-h-screen bg-background circuit-pattern">
        {/* Scan line effect */}
        <div className="fixed inset-0 pointer-events-none overflow-hidden z-30">
          <div className="absolute inset-x-0 h-px bg-gradient-to-r from-transparent via-accent/20 to-transparent animate-scan-line" />
        </div>

        <div className="relative z-10">
          <header className="fixed top-12 inset-x-0 z-40 border-b border-border/30 bg-background/80 backdrop-blur-md">
            <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Radio className="h-6 w-6 text-primary" />
                <span className="font-mono text-sm text-muted-foreground">
                  TRINITY FLOOR: <span className="text-accent">{PATCH_MANIFEST.floor}</span>
                </span>
              </div>
              <div className="flex items-center gap-2">
                {DEMO_MODE && (
                  <Badge variant="outline" className="bg-accent/10 text-accent border-accent/30">
                    <Terminal className="h-3 w-3 mr-1" />
                    DEMO MODE
                  </Badge>
                )}
                <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30">
                  v{PATCH_MANIFEST.version}
                </Badge>
              </div>
            </div>
          </header>

          {/* Hero Section */}
          <section className="min-h-screen flex flex-col items-center justify-center px-6 py-20 pt-36">
            <div className="text-center max-w-5xl mx-auto">
              <div className="glass-panel p-8 rounded-2xl mb-8">
                {/* Logo */}
                <div className="relative inline-block mb-8">
                  <Radio className="h-24 w-24 text-primary animate-pulse-glow" />
                  <div className="absolute inset-0 blur-2xl bg-primary/30" />
                </div>

                <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-4">
                  <span className="text-glow-red">33.3</span>
                  <span className="block text-foreground mt-2">Virtual Signal Studio</span>
                </h1>

                <p className="text-lg md:text-xl text-muted-foreground mb-4 max-w-2xl mx-auto text-balance">
                  The resurrected recording studio. Record, mix, master, and mint your music on the 33.3 FM DOGECHAIN
                  broadcast network.
                </p>

                <p className="text-xs font-mono text-muted-foreground/60 mb-8">
                  TIMELINE: {PATCH_MANIFEST.trinityMount.timeline} | GOVERNED BY:{" "}
                  {PATCH_MANIFEST.trinityMount.governedBy}
                </p>

                <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                  <Link href="/studio">
                    <Button size="lg" className="gap-2 neon-glow-red">
                      Enter Studio
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </Link>
                  <Link href="/museum">
                    <Button
                      variant="outline"
                      size="lg"
                      className="gap-2 bg-transparent border-accent text-accent hover:bg-accent/10"
                    >
                      <Palette className="h-4 w-4" />
                      Neon Vault Museum
                    </Button>
                  </Link>
                </div>
              </div>

              <div className="mt-12">
                <h2 className="text-2xl font-bold mb-2">All Pathways</h2>
                <p className="text-sm text-muted-foreground mb-6">
                  {DEMO_MODE ? "Demo mode active - all routes accessible" : "Access based on token tier"}
                </p>

                {/* Studio Routes */}
                <div className="mb-8">
                  <h3 className="text-sm font-mono text-primary mb-4 flex items-center gap-2">
                    <Radio className="h-4 w-4" />
                    STUDIO ROUTES
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {[
                      {
                        path: "/studio",
                        icon: LayoutDashboard,
                        title: "Dashboard",
                        desc: "Studio overview",
                        tier: "GUEST",
                      },
                      {
                        path: "/studio/gate",
                        icon: Lock,
                        title: "Access Gate",
                        desc: "Token verification",
                        tier: "GUEST",
                      },
                      {
                        path: "/studio/signal-booth",
                        icon: Mic,
                        title: "Signal Booth",
                        desc: "Real-time recording",
                        tier: "CREATOR",
                      },
                      {
                        path: "/studio/producer-room",
                        icon: Music,
                        title: "Producer Room",
                        desc: "AI beat generation",
                        tier: "CREATOR",
                      },
                      {
                        path: "/studio/mix-room",
                        icon: Sliders,
                        title: "Mix Room",
                        desc: "Multitrack editor",
                        tier: "PRODUCER",
                      },
                      {
                        path: "/studio/control-room",
                        icon: LayoutDashboard,
                        title: "Control Room",
                        desc: "Project management",
                        tier: "PRODUCER",
                      },
                      { path: "/studio/mint", icon: Coins, title: "Mint", desc: "NFT minting", tier: "SYNDICATE" },
                      {
                        path: "/studio/playlists",
                        icon: Music,
                        title: "Playlists",
                        desc: "Playlist browser",
                        tier: "GUEST",
                      },
                    ].map((route) => (
                      <Link key={route.path} href={route.path}>
                        <div className="glass-panel rounded-lg p-4 text-left hover:neon-glow-cyan transition-all group h-full">
                          <div className="flex items-start justify-between mb-3">
                            <route.icon className="h-6 w-6 text-accent group-hover:text-cyan-400 transition-colors" />
                            {DEMO_MODE ? (
                              <Unlock className="h-4 w-4 text-green-500" />
                            ) : (
                              <Badge variant="outline" className="text-xs">
                                {route.tier}
                              </Badge>
                            )}
                          </div>
                          <h3 className="font-semibold mb-1">{route.title}</h3>
                          <p className="text-xs text-muted-foreground">{route.desc}</p>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>

                {/* Museum Routes */}
                <div>
                  <h3 className="text-sm font-mono text-accent mb-4 flex items-center gap-2">
                    <Palette className="h-4 w-4" />
                    MUSEUM ROUTES
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {[
                      { path: "/museum", icon: Palette, title: "Neon Vault", desc: "Museum entrance", tier: "GUEST" },
                      {
                        path: "/museum/galleries",
                        icon: ImageIcon,
                        title: "Galleries",
                        desc: "NFT exhibitions",
                        tier: "GUEST",
                      },
                      {
                        path: "/museum/audits",
                        icon: Shield,
                        title: "IP Audits",
                        desc: "Ownership verification",
                        tier: "GUEST",
                      },
                      {
                        path: "/museum/audio",
                        icon: Headphones,
                        title: "Audio Tours",
                        desc: "33.3 FM guides",
                        tier: "GUEST",
                      },
                    ].map((route) => (
                      <Link key={route.path} href={route.path}>
                        <div className="glass-panel rounded-lg p-4 text-left hover:neon-glow-red transition-all group h-full border-accent/20">
                          <div className="flex items-start justify-between mb-3">
                            <route.icon className="h-6 w-6 text-primary group-hover:text-red-400 transition-colors" />
                            {DEMO_MODE ? (
                              <Unlock className="h-4 w-4 text-green-500" />
                            ) : (
                              <Badge variant="outline" className="text-xs">
                                {route.tier}
                              </Badge>
                            )}
                          </div>
                          <h3 className="font-semibold mb-1">{route.title}</h3>
                          <p className="text-xs text-muted-foreground">{route.desc}</p>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Footer */}
          <footer className="border-t border-border/50 py-8 px-6 bg-background/80">
            <div className="max-w-5xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="text-center md:text-left">
                <p className="text-sm text-muted-foreground font-mono">
                  VSS-33.3 | Rebuilt from the Fallen Studio Node – 2090
                </p>
                <p className="text-xs text-muted-foreground/60 font-mono mt-1">
                  PATCH: {PATCH_MANIFEST.id} | REALM: {PATCH_MANIFEST.realm} | MOUNT: {PATCH_MANIFEST.trinityMount.type}
                </p>
              </div>
              <p className="text-sm text-muted-foreground">
                Part of the <span className="text-primary">33.3 FM DOGECHAIN</span> network
              </p>
            </div>
          </footer>
        </div>
      </div>
    </EnvironmentRenderer>
  )
}
