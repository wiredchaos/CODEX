import { NextResponse } from "next/server"
import { sql } from "@/lib/db"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { userId, wallet, chain, nftContract, tokenId } = body

    // Simulate NFT verification (in production, this would call blockchain APIs)
    const isValid = Math.random() > 0.3 // 70% success rate for demo

    if (!isValid) {
      return NextResponse.json({ error: "NFT verification failed" }, { status: 400 })
    }

    // Determine tier based on NFT contract (simplified logic)
    let tier = "creator"
    if (nftContract?.includes("syndicate")) {
      tier = "syndicate"
    } else if (nftContract?.includes("producer")) {
      tier = "producer"
    }

    // Create or update gate entry
    const result = await sql`
      INSERT INTO vss_gates (user_id, nft_contract, token_id, chain, tier, verified_at)
      VALUES (${userId}, ${nftContract}, ${tokenId}, ${chain}, ${tier}, NOW())
      ON CONFLICT (user_id, nft_contract, token_id) 
      DO UPDATE SET verified_at = NOW(), tier = ${tier}
      RETURNING *
    `

    // Update user tier
    await sql`
      UPDATE vss_users SET tier = ${tier}, wallet = ${wallet} WHERE id = ${userId}
    `

    return NextResponse.json({ gate: result[0], tier })
  } catch (error) {
    console.error("[v0] Error verifying gate:", error)
    return NextResponse.json({ error: "Failed to verify gate" }, { status: 500 })
  }
}
