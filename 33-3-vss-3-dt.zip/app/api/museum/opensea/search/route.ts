import { type NextRequest, NextResponse } from "next/server"
import { searchOpenSeaNFTs } from "@/lib/opensea"

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const query = searchParams.get("q")
    const chain = searchParams.get("chain") || "ethereum"

    if (!query) {
      return NextResponse.json({ error: "Query parameter is required" }, { status: 400 })
    }

    const results = await searchOpenSeaNFTs(query, chain)

    return NextResponse.json({ results })
  } catch (error) {
    console.error("[v0] OpenSea search error:", error)
    return NextResponse.json({ error: "Failed to search OpenSea" }, { status: 500 })
  }
}
