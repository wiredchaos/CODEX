import { type NextRequest, NextResponse } from "next/server"
import { getDb } from "@/lib/db"

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const galleryId = searchParams.get("gallery_id")

    const sql = getDb()

    let exhibits
    if (galleryId) {
      exhibits = await sql`
        SELECT * FROM museum_nft_exhibits
        WHERE gallery_id = ${galleryId}
        ORDER BY display_order ASC, created_at DESC
      `
    } else {
      exhibits = await sql`
        SELECT e.*, g.name as gallery_name
        FROM museum_nft_exhibits e
        JOIN museum_galleries g ON e.gallery_id = g.id
        WHERE g.is_active = true
        ORDER BY e.created_at DESC
        LIMIT 50
      `
    }

    return NextResponse.json({ exhibits })
  } catch (error) {
    console.error("[v0] Error fetching exhibits:", error)
    return NextResponse.json({ error: "Failed to fetch exhibits" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      galleryId,
      openseaAssetId,
      contractAddress,
      tokenId,
      chain,
      title,
      artistName,
      description,
      imageUrl,
      animationUrl,
      externalUrl,
      metadata,
    } = body

    const sql = getDb()

    const [exhibit] = await sql`
      INSERT INTO museum_nft_exhibits (
        gallery_id, opensea_asset_id, contract_address, token_id, chain,
        title, artist_name, description, image_url, animation_url, external_url, metadata
      ) VALUES (
        ${galleryId}, ${openseaAssetId}, ${contractAddress}, ${tokenId}, ${chain || "ethereum"},
        ${title}, ${artistName}, ${description}, ${imageUrl}, ${animationUrl}, ${externalUrl}, ${metadata}
      )
      RETURNING *
    `

    return NextResponse.json({ exhibit })
  } catch (error) {
    console.error("[v0] Error creating exhibit:", error)
    return NextResponse.json({ error: "Failed to create exhibit" }, { status: 500 })
  }
}
