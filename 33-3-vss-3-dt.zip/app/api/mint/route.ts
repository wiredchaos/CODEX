import { NextResponse } from "next/server"
import { sql } from "@/lib/db"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { trackId, userId, chain, royaltyConfig, metadata } = body

    // Create mint record
    const result = await sql`
      INSERT INTO vss_mints (track_id, user_id, chain, royalty_config, status)
      VALUES (${trackId}, ${userId}, ${chain}, ${JSON.stringify(royaltyConfig)}, 'pending')
      RETURNING *
    `

    const mintId = result[0].id

    // Simulate blockchain minting (in production, this would call actual blockchain APIs)
    setTimeout(async () => {
      try {
        const txHash = `0x${Math.random().toString(16).substr(2, 64)}`
        const contractAddress = `0x${Math.random().toString(16).substr(2, 40)}`
        const tokenId = Math.floor(Math.random() * 10000).toString()

        await sql`
          UPDATE vss_mints 
          SET status = 'confirmed',
              transaction_hash = ${txHash},
              contract_address = ${contractAddress},
              token_id = ${tokenId},
              minted_at = NOW()
          WHERE id = ${mintId}
        `

        console.log("[v0] Mint confirmed:", { txHash, contractAddress, tokenId })
      } catch (error) {
        console.error("[v0] Mint failed:", error)
        await sql`UPDATE vss_mints SET status = 'failed' WHERE id = ${mintId}`
      }
    }, 3000)

    return NextResponse.json({ mint: result[0], status: "pending" })
  } catch (error) {
    console.error("[v0] Error creating mint:", error)
    return NextResponse.json({ error: "Failed to create mint" }, { status: 500 })
  }
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("user_id")
    const trackId = searchParams.get("track_id")

    let query = "SELECT * FROM vss_mints"
    const conditions = []

    if (userId) {
      conditions.push(`user_id = '${userId}'`)
    }
    if (trackId) {
      conditions.push(`track_id = '${trackId}'`)
    }

    if (conditions.length > 0) {
      query += " WHERE " + conditions.join(" AND ")
    }

    query += " ORDER BY created_at DESC"

    const mints = await sql(query)
    return NextResponse.json({ mints })
  } catch (error) {
    console.error("[v0] Error fetching mints:", error)
    return NextResponse.json({ error: "Failed to fetch mints" }, { status: 500 })
  }
}
