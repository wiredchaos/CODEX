import { NextResponse } from "next/server"
import { sql } from "@/lib/db"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("user_id")
    const status = searchParams.get("status")

    let query = "SELECT * FROM vss_tracks"
    const conditions = []

    if (userId) {
      conditions.push(`user_id = '${userId}'`)
    }
    if (status) {
      conditions.push(`status = '${status}'`)
    }

    if (conditions.length > 0) {
      query += " WHERE " + conditions.join(" AND ")
    }

    query += " ORDER BY created_at DESC"

    const tracks = await sql(query)
    return NextResponse.json({ tracks })
  } catch (error) {
    console.error("[v0] Error fetching tracks:", error)
    return NextResponse.json({ error: "Failed to fetch tracks" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { userId, title, bpm, key, roomOrigin } = body

    const result = await sql`
      INSERT INTO vss_tracks (user_id, title, bpm, key, room_origin, status)
      VALUES (${userId}, ${title}, ${bpm || null}, ${key || null}, ${roomOrigin || null}, 'draft')
      RETURNING *
    `

    return NextResponse.json({ track: result[0] })
  } catch (error) {
    console.error("[v0] Error creating track:", error)
    return NextResponse.json({ error: "Failed to create track" }, { status: 500 })
  }
}
