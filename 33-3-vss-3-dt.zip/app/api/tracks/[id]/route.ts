import { NextResponse } from "next/server"
import { sql } from "@/lib/db"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const result = await sql`
      SELECT * FROM vss_tracks WHERE id = ${params.id}
    `

    if (result.length === 0) {
      return NextResponse.json({ error: "Track not found" }, { status: 404 })
    }

    return NextResponse.json({ track: result[0] })
  } catch (error) {
    console.error("[v0] Error fetching track:", error)
    return NextResponse.json({ error: "Failed to fetch track" }, { status: 500 })
  }
}

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()
    const { title, status, bpm, key, audioUrl, waveformUrl, stemUrls, durationSeconds } = body

    const updates = []
    const values = []

    if (title !== undefined) {
      updates.push(`title = $${updates.length + 1}`)
      values.push(title)
    }
    if (status !== undefined) {
      updates.push(`status = $${updates.length + 1}`)
      values.push(status)
    }
    if (bpm !== undefined) {
      updates.push(`bpm = $${updates.length + 1}`)
      values.push(bpm)
    }
    if (key !== undefined) {
      updates.push(`key = $${updates.length + 1}`)
      values.push(key)
    }
    if (audioUrl !== undefined) {
      updates.push(`audio_url = $${updates.length + 1}`)
      values.push(audioUrl)
    }
    if (waveformUrl !== undefined) {
      updates.push(`waveform_url = $${updates.length + 1}`)
      values.push(waveformUrl)
    }
    if (stemUrls !== undefined) {
      updates.push(`stem_urls = $${updates.length + 1}`)
      values.push(JSON.stringify(stemUrls))
    }
    if (durationSeconds !== undefined) {
      updates.push(`duration_seconds = $${updates.length + 1}`)
      values.push(durationSeconds)
    }

    if (updates.length === 0) {
      return NextResponse.json({ error: "No updates provided" }, { status: 400 })
    }

    updates.push(`updated_at = NOW()`)

    const query = `
      UPDATE vss_tracks 
      SET ${updates.join(", ")}
      WHERE id = $${updates.length + 1}
      RETURNING *
    `

    values.push(params.id)

    const result = await sql(query, values)

    if (result.length === 0) {
      return NextResponse.json({ error: "Track not found" }, { status: 404 })
    }

    return NextResponse.json({ track: result[0] })
  } catch (error) {
    console.error("[v0] Error updating track:", error)
    return NextResponse.json({ error: "Failed to update track" }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const result = await sql`
      DELETE FROM vss_tracks WHERE id = ${params.id} RETURNING id
    `

    if (result.length === 0) {
      return NextResponse.json({ error: "Track not found" }, { status: 404 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("[v0] Error deleting track:", error)
    return NextResponse.json({ error: "Failed to delete track" }, { status: 500 })
  }
}
