import { NextResponse } from "next/server"
import { sql } from "@/lib/db"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const tracks = await sql`
      SELECT t.*, pt.priority_score, pt.added_at
      FROM vss_tracks t
      INNER JOIN vss_playlist_tracks pt ON t.id = pt.track_id
      WHERE pt.playlist_id = ${params.id}
      ORDER BY pt.priority_score DESC, pt.added_at DESC
    `

    return NextResponse.json({ tracks })
  } catch (error) {
    console.error("[v0] Error fetching playlist tracks:", error)
    return NextResponse.json({ error: "Failed to fetch playlist tracks" }, { status: 500 })
  }
}

export async function POST(request: Request, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()
    const { trackId, priorityScore } = body

    const result = await sql`
      INSERT INTO vss_playlist_tracks (playlist_id, track_id, priority_score)
      VALUES (${params.id}, ${trackId}, ${priorityScore || 50})
      RETURNING *
    `

    return NextResponse.json({ playlistTrack: result[0] })
  } catch (error) {
    console.error("[v0] Error adding track to playlist:", error)
    return NextResponse.json({ error: "Failed to add track to playlist" }, { status: 500 })
  }
}
