import { NextResponse } from "next/server"
import { sql } from "@/lib/db"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const type = searchParams.get("type")

    let query = `
      SELECT p.*, COUNT(pt.track_id) as track_count
      FROM vss_playlists p
      LEFT JOIN vss_playlist_tracks pt ON p.id = pt.playlist_id
    `

    if (type) {
      query += ` WHERE p.type = '${type}'`
    }

    query += ` GROUP BY p.id ORDER BY p.created_at DESC`

    const playlists = await sql(query)
    return NextResponse.json({ playlists })
  } catch (error) {
    console.error("[v0] Error fetching playlists:", error)
    return NextResponse.json({ error: "Failed to fetch playlists" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { type, name, description, coverUrl, isPublic, createdBy } = body

    const result = await sql`
      INSERT INTO vss_playlists (type, name, description, cover_url, is_public, created_by)
      VALUES (${type}, ${name}, ${description || null}, ${coverUrl || null}, ${isPublic !== false}, ${createdBy || null})
      RETURNING *
    `

    return NextResponse.json({ playlist: result[0] })
  } catch (error) {
    console.error("[v0] Error creating playlist:", error)
    return NextResponse.json({ error: "Failed to create playlist" }, { status: 500 })
  }
}
