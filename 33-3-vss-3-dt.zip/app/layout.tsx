import type React from "react"
import type { Metadata, Viewport } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"

const _geist = Geist({ subsets: ["latin"] })
const _geistMono = Geist_Mono({ subsets: ["latin"] })

// <CHANGE> Updated metadata for VSS-33.3
export const metadata: Metadata = {
  title: "33.3 Virtual Signal Studio | VSS-33.3",
  description:
    "The resurrected virtual recording studio - Record, mix, master, and mint your music on the 33.3 FM DOGECHAIN network.",
  generator: "v0.app",
  keywords: ["virtual studio", "music production", "NFT", "web3", "recording", "mixing", "dogechain"],
  icons: {
    icon: [
      {
        url: "/icon-light-32x32.png",
        media: "(prefers-color-scheme: light)",
      },
      {
        url: "/icon-dark-32x32.png",
        media: "(prefers-color-scheme: dark)",
      },
      {
        url: "/icon.svg",
        type: "image/svg+xml",
      },
    ],
    apple: "/apple-icon.png",
  },
}

// <CHANGE> Added viewport configuration
export const viewport: Viewport = {
  themeColor: "#dc2626",
  colorScheme: "dark",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark">
      <body className="font-sans antialiased">
        {children}
        <Analytics />
      </body>
    </html>
  )
}
