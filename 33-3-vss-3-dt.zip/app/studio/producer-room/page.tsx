"use client"

import { useState } from "react"
import { AvatarGuide } from "@/components/studio/avatar-guide"
import { DrumPad } from "@/components/studio/drum-pad"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { cn } from "@/lib/utils"
import { Music, Wand2, Play, Square, Save, Layers, Shuffle, Grid3X3, Volume2 } from "lucide-react"

const samplePacks = [
  { id: "trap", name: "Trap Essentials", samples: 64 },
  { id: "lofi", name: "Lo-Fi Dreams", samples: 48 },
  { id: "electronic", name: "Electronic Waves", samples: 72 },
  { id: "hiphop", name: "Hip-Hop Classics", samples: 56 },
  { id: "ambient", name: "Ambient Textures", samples: 32 },
]

const drumPads = [
  { label: "KICK", sound: "kick", color: "red" as const, keyBinding: "Q" },
  { label: "SNARE", sound: "snare", color: "red" as const, keyBinding: "W" },
  { label: "HAT", sound: "hihat", color: "cyan" as const, keyBinding: "E" },
  { label: "CLAP", sound: "clap", color: "cyan" as const, keyBinding: "R" },
  { label: "TOM", sound: "tom", color: "default" as const, keyBinding: "A" },
  { label: "RIDE", sound: "ride", color: "default" as const, keyBinding: "S" },
  { label: "CRASH", sound: "crash", color: "green" as const, keyBinding: "D" },
  { label: "PERC", sound: "perc", color: "green" as const, keyBinding: "F" },
  { label: "808", sound: "808", color: "red" as const, keyBinding: "Z" },
  { label: "SUB", sound: "sub", color: "red" as const, keyBinding: "X" },
  { label: "FX1", sound: "fx1", color: "cyan" as const, keyBinding: "C" },
  { label: "FX2", sound: "fx2", color: "cyan" as const, keyBinding: "V" },
]

const aiStyles = [
  { id: "trap", name: "Trap", bpm: "140-160" },
  { id: "lofi", name: "Lo-Fi Hip Hop", bpm: "70-90" },
  { id: "house", name: "House", bpm: "120-130" },
  { id: "drill", name: "Drill", bpm: "140-145" },
  { id: "rnb", name: "R&B", bpm: "60-80" },
]

export default function ProducerRoomPage() {
  const [selectedPack, setSelectedPack] = useState("trap")
  const [selectedStyle, setSelectedStyle] = useState("trap")
  const [bpm, setBpm] = useState([140])
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedBeat, setGeneratedBeat] = useState<string | null>(null)

  const handleGenerateBeat = () => {
    setIsGenerating(true)
    // Simulate AI generation
    setTimeout(() => {
      setIsGenerating(false)
      setGeneratedBeat(`AI Beat - ${aiStyles.find((s) => s.id === selectedStyle)?.name} @ ${bpm[0]} BPM`)
    }, 3000)
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-3">
            <div className="p-2 rounded-lg bg-accent/20">
              <Music className="h-6 w-6 text-accent" />
            </div>
            Producer Room
          </h1>
          <p className="text-muted-foreground mt-1">AI beat generation, sample packs, and drum machine</p>
        </div>
      </div>

      {/* Avatar Guide */}
      <AvatarGuide
        avatar="neuro"
        message="The Producer Room is your creative engine. Use the drum pads to build patterns, browse sample packs, or let the AI generate beats based on your style preferences. All loops sync to your project BPM."
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          <Tabs defaultValue="drums" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="drums" className="gap-2">
                <Grid3X3 className="h-4 w-4" />
                Drum Machine
              </TabsTrigger>
              <TabsTrigger value="samples" className="gap-2">
                <Layers className="h-4 w-4" />
                Sample Packs
              </TabsTrigger>
              <TabsTrigger value="ai" className="gap-2">
                <Wand2 className="h-4 w-4" />
                AI Generator
              </TabsTrigger>
            </TabsList>

            {/* Drum Machine */}
            <TabsContent value="drums">
              <Card className="glass-panel">
                <CardHeader>
                  <CardTitle>Drum Machine</CardTitle>
                  <CardDescription>Click pads or use keyboard shortcuts (Q-V, Z-F)</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-4 gap-3 mb-6">
                    {drumPads.map((pad) => (
                      <DrumPad key={pad.sound} {...pad} />
                    ))}
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-border/50">
                    <div className="flex items-center gap-4">
                      <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                        <Play className="h-4 w-4" />
                        Play Pattern
                      </Button>
                      <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                        <Square className="h-4 w-4" />
                        Stop
                      </Button>
                    </div>
                    <Button size="sm" className="gap-2">
                      <Save className="h-4 w-4" />
                      Save Pattern
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Sample Packs */}
            <TabsContent value="samples">
              <Card className="glass-panel">
                <CardHeader>
                  <CardTitle>Sample Packs</CardTitle>
                  <CardDescription>Browse and preview sample collections</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {samplePacks.map((pack) => (
                      <div
                        key={pack.id}
                        onClick={() => setSelectedPack(pack.id)}
                        className={cn(
                          "p-4 rounded-lg cursor-pointer transition-all flex items-center justify-between",
                          selectedPack === pack.id
                            ? "bg-accent/20 border border-accent/50 neon-glow-cyan"
                            : "bg-secondary/50 hover:bg-secondary/70 border border-transparent",
                        )}
                      >
                        <div>
                          <p className={cn("font-medium", selectedPack === pack.id && "text-accent")}>{pack.name}</p>
                          <p className="text-sm text-muted-foreground">{pack.samples} samples</p>
                        </div>
                        <Button size="sm" variant="ghost">
                          <Play className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>

                  <div className="mt-6 pt-4 border-t border-border/50">
                    <Button className="w-full gap-2 neon-glow-cyan">
                      <Layers className="h-4 w-4" />
                      Load Selected Pack
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* AI Generator */}
            <TabsContent value="ai">
              <Card className="glass-panel">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Wand2 className="h-5 w-5 text-primary" />
                    AI Beat Generator
                  </CardTitle>
                  <CardDescription>Generate beats using AI based on your style preferences</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Style Selection */}
                  <div className="space-y-3">
                    <label className="text-sm text-muted-foreground">Select Style</label>
                    <div className="grid grid-cols-3 gap-2">
                      {aiStyles.map((style) => (
                        <button
                          key={style.id}
                          onClick={() => setSelectedStyle(style.id)}
                          className={cn(
                            "p-3 rounded-lg text-left transition-all",
                            selectedStyle === style.id
                              ? "bg-primary/20 border border-primary/50"
                              : "bg-secondary/50 hover:bg-secondary/70 border border-transparent",
                          )}
                        >
                          <p className={cn("font-medium text-sm", selectedStyle === style.id && "text-primary")}>
                            {style.name}
                          </p>
                          <p className="text-xs text-muted-foreground">{style.bpm} BPM</p>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* BPM Slider */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-sm text-muted-foreground">BPM</label>
                      <span className="text-sm font-mono text-primary">{bpm[0]}</span>
                    </div>
                    <Slider value={bpm} onValueChange={setBpm} min={60} max={200} step={1} />
                  </div>

                  {/* Generate Button */}
                  <Button
                    className="w-full gap-2 neon-glow-red h-12"
                    onClick={handleGenerateBeat}
                    disabled={isGenerating}
                  >
                    {isGenerating ? (
                      <>
                        <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Shuffle className="h-4 w-4" />
                        Generate Beat
                      </>
                    )}
                  </Button>

                  {/* Generated Beat */}
                  {generatedBeat && (
                    <div className="p-4 rounded-lg bg-primary/10 border border-primary/30">
                      <p className="text-sm text-primary font-medium mb-2">{generatedBeat}</p>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" className="gap-2 bg-transparent">
                          <Play className="h-4 w-4" />
                          Preview
                        </Button>
                        <Button size="sm" className="gap-2">
                          <Save className="h-4 w-4" />
                          Add to Project
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          {/* BPM & Key */}
          <Card className="glass-panel">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Volume2 className="h-4 w-4 text-accent" />
                Session Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm text-muted-foreground">Master BPM</label>
                  <span className="text-sm font-mono text-accent">{bpm[0]}</span>
                </div>
                <Slider value={bpm} onValueChange={setBpm} min={60} max={200} step={1} />
              </div>

              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">Key</label>
                <Select defaultValue="c-minor">
                  <SelectTrigger className="bg-input">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="c-major">C Major</SelectItem>
                    <SelectItem value="c-minor">C Minor</SelectItem>
                    <SelectItem value="g-major">G Major</SelectItem>
                    <SelectItem value="a-minor">A Minor</SelectItem>
                    <SelectItem value="f-major">F Major</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">Swing</label>
                <Slider defaultValue={[0]} min={0} max={100} step={1} />
              </div>
            </CardContent>
          </Card>

          {/* Loop Browser */}
          <Card className="glass-panel">
            <CardHeader>
              <CardTitle className="text-lg">Loop Browser</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {["Melodic Loop 01", "Bass Loop 03", "Arp Sequence 02", "Pad Texture 01"].map((loop) => (
                  <div
                    key={loop}
                    className="flex items-center justify-between p-2 rounded-lg bg-secondary/50 hover:bg-secondary/70"
                  >
                    <span className="text-sm">{loop}</span>
                    <Button size="icon" variant="ghost" className="h-8 w-8">
                      <Play className="h-3 w-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
