"use client"

import { useState } from "react"
import { useAudioRecorder } from "@/hooks/use-audio-recorder"
import { WaveformVisualizer } from "@/components/studio/waveform-visualizer"
import { AvatarGuide } from "@/components/studio/avatar-guide"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { Mic, Square, Pause, Play, Trash2, Save, Wand2, Radio, Volume2 } from "lucide-react"

const aiPresets = [
  { id: "broadcast", name: "Broadcast Clean", description: "Radio-ready clarity and compression" },
  { id: "phantom", name: "Phantom Vocal", description: "Ethereal reverb and presence" },
  { id: "redfang", name: "Red Fang Silk", description: "Warm vintage vocal character" },
  { id: "raw", name: "Raw Signal", description: "No processing, pure capture" },
]

export default function SignalBoothPage() {
  const { state, startRecording, stopRecording, pauseRecording, resumeRecording, clearRecording, getAudioData } =
    useAudioRecorder()

  const [selectedPreset, setSelectedPreset] = useState("broadcast")
  const [inputGain, setInputGain] = useState([75])
  const [takes, setTakes] = useState<{ id: string; name: string; duration: number; url: string }[]>([])

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const handleSaveTake = () => {
    if (state.audioUrl) {
      const newTake = {
        id: `take-${Date.now()}`,
        name: `Take ${takes.length + 1}`,
        duration: state.duration,
        url: state.audioUrl,
      }
      setTakes((prev) => [...prev, newTake])
      clearRecording()
    }
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/20">
              <Mic className="h-6 w-6 text-primary" />
            </div>
            Signal Booth
          </h1>
          <p className="text-muted-foreground mt-1">Real-time recording with AI cleanup presets</p>
        </div>
        <Badge variant="outline" className={cn(state.isRecording ? "text-primary border-primary" : "")}>
          {state.isRecording ? (
            <>
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse mr-2" />
              Recording
            </>
          ) : (
            "Standby"
          )}
        </Badge>
      </div>

      {/* Avatar Guide */}
      <AvatarGuide
        avatar="redfang"
        message="Welcome to the Signal Booth. Select your AI preset, check your input levels, and capture your signal. Each take is stored locally until you save to your project."
      />

      {/* Main Recording Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Waveform & Controls */}
        <div className="lg:col-span-2 space-y-4">
          {/* Waveform Display */}
          <Card className="glass-panel">
            <CardContent className="p-6">
              <WaveformVisualizer isActive={state.isRecording} getAudioData={getAudioData} className="h-40 mb-6" />

              {/* Timer Display */}
              <div className="text-center mb-6">
                <p className="text-5xl font-mono font-bold text-glow-red text-primary">
                  {formatDuration(state.duration)}
                </p>
                {state.isPaused && <p className="text-sm text-accent mt-2 animate-pulse">PAUSED</p>}
              </div>

              {/* Recording Controls */}
              <div className="flex items-center justify-center gap-4">
                {!state.isRecording && !state.audioUrl && (
                  <Button size="lg" className="gap-2 neon-glow-red h-14 px-8" onClick={startRecording}>
                    <Mic className="h-5 w-5" />
                    Start Recording
                  </Button>
                )}

                {state.isRecording && (
                  <>
                    {state.isPaused ? (
                      <Button size="lg" variant="outline" className="gap-2 bg-transparent" onClick={resumeRecording}>
                        <Play className="h-5 w-5" />
                        Resume
                      </Button>
                    ) : (
                      <Button size="lg" variant="outline" className="gap-2 bg-transparent" onClick={pauseRecording}>
                        <Pause className="h-5 w-5" />
                        Pause
                      </Button>
                    )}
                    <Button size="lg" variant="destructive" className="gap-2 h-14 px-8" onClick={stopRecording}>
                      <Square className="h-5 w-5" />
                      Stop
                    </Button>
                  </>
                )}

                {state.audioUrl && (
                  <>
                    <audio controls src={state.audioUrl} className="hidden" id="playback-audio" />
                    <Button
                      size="lg"
                      variant="outline"
                      className="gap-2 bg-transparent"
                      onClick={() => {
                        const audio = document.getElementById("playback-audio") as HTMLAudioElement
                        audio?.play()
                      }}
                    >
                      <Play className="h-5 w-5" />
                      Play
                    </Button>
                    <Button size="lg" className="gap-2 neon-glow-cyan" onClick={handleSaveTake}>
                      <Save className="h-5 w-5" />
                      Save Take
                    </Button>
                    <Button size="lg" variant="ghost" onClick={clearRecording}>
                      <Trash2 className="h-5 w-5" />
                    </Button>
                  </>
                )}
              </div>

              {/* Error Display */}
              {state.error && (
                <div className="mt-4 p-4 rounded-lg bg-destructive/20 border border-destructive/50 text-center">
                  <p className="text-sm text-destructive">{state.error}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Takes List */}
          {takes.length > 0 && (
            <Card className="glass-panel">
              <CardHeader>
                <CardTitle className="text-lg">Saved Takes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {takes.map((take) => (
                    <div
                      key={take.id}
                      className="flex items-center justify-between p-3 rounded-lg bg-secondary/50 hover:bg-secondary/70 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <Radio className="h-4 w-4 text-accent" />
                        <span className="font-medium">{take.name}</span>
                        <span className="text-sm text-muted-foreground font-mono">{formatDuration(take.duration)}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            const audio = new Audio(take.url)
                            audio.play()
                          }}
                        >
                          <Play className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            setTakes((prev) => prev.filter((t) => t.id !== take.id))
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Settings Panel */}
        <div className="space-y-4">
          {/* Input Settings */}
          <Card className="glass-panel">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Volume2 className="h-4 w-4 text-accent" />
                Input Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">Input Device</label>
                <Select defaultValue="default">
                  <SelectTrigger className="bg-input">
                    <SelectValue placeholder="Select microphone" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="default">Default Microphone</SelectItem>
                    <SelectItem value="external">External USB Mic</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm text-muted-foreground">Input Gain</label>
                  <span className="text-sm font-mono text-accent">{inputGain[0]}%</span>
                </div>
                <Slider value={inputGain} onValueChange={setInputGain} max={100} step={1} className="py-2" />
              </div>
            </CardContent>
          </Card>

          {/* AI Presets */}
          <Card className="glass-panel">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Wand2 className="h-4 w-4 text-primary" />
                AI Cleanup Preset
              </CardTitle>
              <CardDescription>Applied on export</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {aiPresets.map((preset) => (
                  <button
                    key={preset.id}
                    onClick={() => setSelectedPreset(preset.id)}
                    className={cn(
                      "w-full p-3 rounded-lg text-left transition-all",
                      selectedPreset === preset.id
                        ? "bg-primary/20 border border-primary/50 neon-glow-red"
                        : "bg-secondary/50 hover:bg-secondary/70 border border-transparent",
                    )}
                  >
                    <p className={cn("font-medium", selectedPreset === preset.id ? "text-primary" : "text-foreground")}>
                      {preset.name}
                    </p>
                    <p className="text-xs text-muted-foreground">{preset.description}</p>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Tips */}
          <Card className="glass-panel border-accent/30">
            <CardContent className="p-4">
              <p className="text-xs text-accent font-mono mb-2">SIGNAL TIP</p>
              <p className="text-sm text-muted-foreground">
                Keep your input gain between 60-80% to avoid clipping. The AI presets will handle the rest.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
