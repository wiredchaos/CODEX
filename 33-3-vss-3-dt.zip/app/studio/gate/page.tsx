"use client"

import { useState } from "react"
import { AvatarGuide } from "@/components/studio/avatar-guide"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Wallet, Mail, CreditCard, Shield, Check, Zap, Crown, Lock } from "lucide-react"

const tiers = [
  {
    id: "creator",
    name: "Creator",
    price: "$9.99/mo",
    fiatPrice: 9.99,
    icon: Zap,
    color: "text-accent",
    glow: "neon-glow-cyan",
    features: ["Full recording access", "Basic mixing tools", "5 exports/month", "Standard support"],
  },
  {
    id: "producer",
    name: "Producer",
    price: "2090 NFT",
    nftRequired: true,
    icon: Crown,
    color: "text-primary",
    glow: "neon-glow-red",
    features: [
      "Full studio access",
      "Unlimited exports",
      "NFT minting rights",
      "Priority playlists",
      "Private control room",
      "Zero platform fee",
    ],
  },
  {
    id: "syndicate",
    name: "Syndicate",
    price: "Vault33 Key",
    nftRequired: true,
    icon: Shield,
    color: "text-neon-green",
    glow: "",
    features: ["All Producer features", "Exclusive rooms", "Cipher-based tools", "Labyrinth OST access", "VIP support"],
  },
]

export default function GatePage() {
  const [selectedTier, setSelectedTier] = useState<string | null>(null)
  const [authMethod, setAuthMethod] = useState<"wallet" | "email">("wallet")

  return (
    <div className="p-6 space-y-8 max-w-5xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold mb-2">Access Gate</h1>
        <p className="text-muted-foreground">Validate your access or upgrade your tier to unlock studio features.</p>
      </div>

      {/* Avatar Guide */}
      <AvatarGuide
        avatar="kiba"
        message="The gate recognizes signal strength. Connect your wallet to verify NFT ownership, or enter via fiat pass. Producer tier unlocks the full studio. Choose your path."
      />

      {/* Tier Selection */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {tiers.map((tier) => {
          const Icon = tier.icon
          const isSelected = selectedTier === tier.id

          return (
            <Card
              key={tier.id}
              className={`glass-panel cursor-pointer transition-all ${
                isSelected ? tier.glow + " border-2" : "hover:border-border"
              } ${tier.id === "producer" ? "border-primary/50" : ""}`}
              onClick={() => setSelectedTier(tier.id)}
            >
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className={`p-3 rounded-lg bg-secondary/50`}>
                    <Icon className={`h-6 w-6 ${tier.color}`} />
                  </div>
                  {tier.nftRequired && (
                    <Badge variant="outline" className="text-xs">
                      NFT Required
                    </Badge>
                  )}
                </div>
                <CardTitle className={`text-xl ${tier.color}`}>{tier.name}</CardTitle>
                <CardDescription className="text-lg font-mono">{tier.price}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {tier.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-sm">
                      <Check className={`h-4 w-4 ${tier.color}`} />
                      <span className="text-muted-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Authentication Section */}
      <Card className="glass-panel">
        <CardHeader>
          <CardTitle>Authenticate Access</CardTitle>
          <CardDescription>Connect your wallet or sign in with email to verify or purchase access.</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={authMethod} onValueChange={(v) => setAuthMethod(v as "wallet" | "email")}>
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="wallet" className="gap-2">
                <Wallet className="h-4 w-4" />
                Wallet
              </TabsTrigger>
              <TabsTrigger value="email" className="gap-2">
                <Mail className="h-4 w-4" />
                Email
              </TabsTrigger>
            </TabsList>

            <TabsContent value="wallet" className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Connect your wallet to automatically verify NFT ownership and unlock your tier.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <Button variant="outline" className="h-16 flex-col gap-2 bg-transparent">
                  <span className="text-lg">🦊</span>
                  <span className="text-xs">MetaMask</span>
                </Button>
                <Button variant="outline" className="h-16 flex-col gap-2 bg-transparent">
                  <span className="text-lg">🔗</span>
                  <span className="text-xs">WalletConnect</span>
                </Button>
                <Button variant="outline" className="h-16 flex-col gap-2 bg-transparent">
                  <span className="text-lg">💎</span>
                  <span className="text-xs">XRPL / Xumm</span>
                </Button>
              </div>
              <p className="text-xs text-muted-foreground text-center">Supported: XRPL, EVM chains, DogeChain</p>
            </TabsContent>

            <TabsContent value="email" className="space-y-4">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input id="email" type="email" placeholder="signal@33fm.io" className="bg-input border-border" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input id="password" type="password" placeholder="••••••••" className="bg-input border-border" />
                </div>
                <div className="flex gap-4">
                  <Button className="flex-1">Sign In</Button>
                  <Button variant="outline" className="flex-1 bg-transparent">
                    Create Account
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Fiat Purchase Section */}
      {selectedTier === "creator" && (
        <Card className="glass-panel border-accent/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5 text-accent" />
              Purchase Creator Pass
            </CardTitle>
            <CardDescription>Get instant access with a monthly subscription.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Button variant="outline" className="h-12 gap-2 bg-transparent">
                <span>💳</span> Stripe
              </Button>
              <Button variant="outline" className="h-12 gap-2 bg-transparent">
                <span>🏦</span> Wyre
              </Button>
              <Button variant="outline" className="h-12 gap-2 bg-transparent">
                <span>🪙</span> Coinbase
              </Button>
            </div>
            <p className="text-xs text-muted-foreground text-center">$9.99/month • Cancel anytime • Instant access</p>
          </CardContent>
        </Card>
      )}

      {/* NFT Purchase Info */}
      {(selectedTier === "producer" || selectedTier === "syndicate") && (
        <Card className="glass-panel border-primary/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5 text-primary" />
              {selectedTier === "producer" ? "2090 Studio Pass NFT" : "Vault33 Key NFT"}
            </CardTitle>
            <CardDescription>
              {selectedTier === "producer"
                ? "The resurrected studio pass from the fallen node. Grants permanent Producer access."
                : "Exclusive syndicate key. Grants access to cipher-based tools and exclusive rooms."}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="glass-panel rounded-lg p-4 flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Available on</p>
                <p className="text-xs text-muted-foreground">DogeChain • XRPL • OpenSea</p>
              </div>
              <Button className="neon-glow-red">View Collection</Button>
            </div>
            <p className="text-xs text-muted-foreground text-center">
              Connect wallet above to check if you already own this NFT
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
