import { Mic, Music, Sliders, Settings, Coins, ListMusic } from "lucide-react"
import { AvatarGuide } from "@/components/studio/avatar-guide"
import { RoomCard } from "@/components/studio/room-card"
import { EnvironmentRenderer } from "@/components/trinity/environment-renderer"

// Mock user tier - will be replaced with real auth
const mockUserTier = "guest" as const

const studioRooms = [
  {
    id: "signal-booth",
    name: "Signal Booth",
    description: "Real-time recording with AI cleanup presets. Capture your signal with broadcast-quality processing.",
    icon: Mic,
    path: "/studio/signal-booth",
    variant: "red" as const,
  },
  {
    id: "producer-room",
    name: "Producer Room",
    description: "AI beat generation, sample packs, and drum machine pads. Create the foundation of your track.",
    icon: Music,
    path: "/studio/producer-room",
    variant: "cyan" as const,
  },
  {
    id: "mix-room",
    name: "Mix Room",
    description: "DAW-lite multitrack editor with timeline, FX rack, and AI mixing presets.",
    icon: Sliders,
    path: "/studio/mix-room",
    variant: "cyan" as const,
  },
  {
    id: "control-room",
    name: "Control Room",
    description: "Project management, collaborator assignments, royalty splits, and playlist preparation.",
    icon: Settings,
    path: "/studio/control-room",
    variant: "red" as const,
  },
  {
    id: "mint",
    name: "Mint",
    description: "Choose your chain, generate metadata, and mint your track as an NFT with royalty configuration.",
    icon: Coins,
    path: "/studio/mint",
    variant: "red" as const,
  },
  {
    id: "playlists",
    name: "Playlists",
    description: "Browse Genesis Rotation, Labyrinth OST, Red Fang Sessions, and Artist Spotlight playlists.",
    icon: ListMusic,
    path: "/studio/playlists",
    variant: "cyan" as const,
  },
]

export default function StudioDashboard() {
  return (
    <EnvironmentRenderer
      patchId="VSS-33.3"
      kind="studio"
      hotspots={[
        { id: "signal", label: "SIGNAL BOOTH", position: { x: 15, y: 35 }, action: () => {} },
        { id: "producer", label: "PRODUCER", position: { x: 50, y: 30 }, action: () => {} },
        { id: "mix", label: "MIX ROOM", position: { x: 85, y: 35 }, action: () => {} },
      ]}
    >
      <div className="p-6 space-y-8 relative">
        {/* Background overlay for content readability */}
        <div className="absolute inset-0 bg-background/70 -z-10" />

        {/* Welcome Section */}
        <div className="max-w-4xl">
          <AvatarGuide
            avatar="neuro"
            message="Welcome to the 33.3 Virtual Signal Studio. The old node has been restored. Your signal awaits processing. Select a room to begin your session."
          />
        </div>

        {/* Status Bar */}
        <div className="glass-panel rounded-lg p-4 flex flex-wrap items-center gap-6">
          <div>
            <p className="text-xs text-muted-foreground mb-1">Studio Status</p>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-neon-green animate-pulse" />
              <span className="text-sm font-mono text-neon-green">ONLINE</span>
            </div>
          </div>
          <div className="h-8 w-px bg-border/50" />
          <div>
            <p className="text-xs text-muted-foreground mb-1">Network</p>
            <span className="text-sm font-mono text-accent">33.3 FM DOGECHAIN</span>
          </div>
          <div className="h-8 w-px bg-border/50" />
          <div>
            <p className="text-xs text-muted-foreground mb-1">Access Level</p>
            <span className="text-sm font-mono text-primary capitalize">{mockUserTier}</span>
          </div>
          <div className="h-8 w-px bg-border/50" />
          <div>
            <p className="text-xs text-muted-foreground mb-1">Studio Pass</p>
            <span className="text-sm font-mono text-muted-foreground">2090 NFT Required for Producer</span>
          </div>
        </div>

        {/* Room Grid */}
        <div>
          <h2 className="text-xl font-semibold mb-4">Studio Rooms</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {studioRooms.map((room) => (
              <RoomCard key={room.id} {...room} userTier={mockUserTier} />
            ))}
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="glass-panel rounded-lg p-6">
            <p className="text-xs text-muted-foreground mb-2">Your Tracks</p>
            <p className="text-3xl font-bold text-foreground">0</p>
            <p className="text-sm text-muted-foreground mt-1">No tracks yet</p>
          </div>
          <div className="glass-panel rounded-lg p-6">
            <p className="text-xs text-muted-foreground mb-2">Projects</p>
            <p className="text-3xl font-bold text-foreground">0</p>
            <p className="text-sm text-muted-foreground mt-1">Start your first project</p>
          </div>
          <div className="glass-panel rounded-lg p-6">
            <p className="text-xs text-muted-foreground mb-2">Minted NFTs</p>
            <p className="text-3xl font-bold text-foreground">0</p>
            <p className="text-sm text-muted-foreground mt-1">Upgrade to Producer tier</p>
          </div>
        </div>
      </div>
    </EnvironmentRenderer>
  )
}
