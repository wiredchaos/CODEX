"use client"

import { useState } from "react"
import { AvatarGuide } from "@/components/studio/avatar-guide"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { cn } from "@/lib/utils"
import {
  Settings,
  FolderOpen,
  Users,
  PieChart,
  ListMusic,
  Plus,
  Trash2,
  Edit2,
  Music,
  Calendar,
  Coins,
  ArrowRight,
} from "lucide-react"

const mockProjects = [
  {
    id: "1",
    title: "Midnight Signal",
    tracks: 4,
    status: "active",
    created: "2024-01-15",
    cover: "/abstract-album-art-midnight.jpg",
  },
  {
    id: "2",
    title: "Cipher Dreams",
    tracks: 2,
    status: "draft",
    created: "2024-01-10",
    cover: "/abstract-album-art-cipher.jpg",
  },
]

const mockCollaborators = [
  { id: "1", name: "DJ Red Fang", role: "Producer", avatar: "/cyberpunk-dj-avatar-red-mask-portrait.jpg", split: 30 },
  {
    id: "2",
    name: "NEURO META X",
    role: "Vocalist",
    avatar: "/cyberpunk-female-avatar-neon-red-portrait.jpg",
    split: 40,
  },
]

const playlists = [
  { id: "genesis", name: "Genesis Rotation", tracks: 24 },
  { id: "labyrinth", name: "Labyrinth OST", tracks: 18 },
  { id: "redfang", name: "Red Fang Sessions", tracks: 32 },
  { id: "spotlight", name: "Artist Spotlight", tracks: 12 },
]

export default function ControlRoomPage() {
  const [selectedProject, setSelectedProject] = useState<string | null>("1")
  const [newCollaborator, setNewCollaborator] = useState("")
  const [selectedPlaylist, setSelectedPlaylist] = useState<string | null>(null)

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/20">
              <Settings className="h-6 w-6 text-primary" />
            </div>
            Control Room
          </h1>
          <p className="text-muted-foreground mt-1">Project management, collaborators, and playlist preparation</p>
        </div>
      </div>

      {/* Avatar Guide */}
      <AvatarGuide
        avatar="neuro"
        message="Welcome to the Control Room. Here you manage your projects, assign collaborators with royalty splits, and prepare tracks for playlist submission."
      />

      <Tabs defaultValue="projects" className="w-full">
        <TabsList className="grid w-full grid-cols-4 mb-6">
          <TabsTrigger value="projects" className="gap-2">
            <FolderOpen className="h-4 w-4" />
            Projects
          </TabsTrigger>
          <TabsTrigger value="collaborators" className="gap-2">
            <Users className="h-4 w-4" />
            Collaborators
          </TabsTrigger>
          <TabsTrigger value="royalties" className="gap-2">
            <PieChart className="h-4 w-4" />
            Royalties
          </TabsTrigger>
          <TabsTrigger value="playlists" className="gap-2">
            <ListMusic className="h-4 w-4" />
            Playlists
          </TabsTrigger>
        </TabsList>

        {/* Projects Tab */}
        <TabsContent value="projects">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold">Your Projects</h2>
                <Button size="sm" className="gap-2">
                  <Plus className="h-4 w-4" />
                  New Project
                </Button>
              </div>

              <div className="space-y-3">
                {mockProjects.map((project) => (
                  <Card
                    key={project.id}
                    className={cn(
                      "glass-panel cursor-pointer transition-all",
                      selectedProject === project.id ? "border-primary/50 neon-glow-red" : "hover:border-border",
                    )}
                    onClick={() => setSelectedProject(project.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center gap-4">
                        <img
                          src={project.cover || "/placeholder.svg"}
                          alt={project.title}
                          className="w-16 h-16 rounded-lg object-cover"
                        />
                        <div className="flex-1">
                          <h3 className="font-semibold">{project.title}</h3>
                          <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Music className="h-3 w-3" />
                              {project.tracks} tracks
                            </span>
                            <span className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              {project.created}
                            </span>
                          </div>
                        </div>
                        <Badge variant={project.status === "active" ? "default" : "secondary"}>{project.status}</Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Project Details */}
            <Card className="glass-panel">
              <CardHeader>
                <CardTitle className="text-lg">Project Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {selectedProject ? (
                  <>
                    <div className="space-y-2">
                      <Label>Title</Label>
                      <Input defaultValue="Midnight Signal" className="bg-input" />
                    </div>
                    <div className="space-y-2">
                      <Label>Cover Art</Label>
                      <div className="w-full aspect-square rounded-lg bg-secondary/50 flex items-center justify-center border-2 border-dashed border-border cursor-pointer hover:border-accent transition-colors">
                        <span className="text-sm text-muted-foreground">Click to upload</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Status</Label>
                      <Select defaultValue="active">
                        <SelectTrigger className="bg-input">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="draft">Draft</SelectItem>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="completed">Completed</SelectItem>
                          <SelectItem value="archived">Archived</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex gap-2 pt-4">
                      <Button className="flex-1 gap-2">
                        <Edit2 className="h-4 w-4" />
                        Save
                      </Button>
                      <Button variant="destructive" size="icon">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-8">Select a project to view details</p>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Collaborators Tab */}
        <TabsContent value="collaborators">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="glass-panel">
              <CardHeader>
                <CardTitle>Project Collaborators</CardTitle>
                <CardDescription>Add team members and assign roles</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {mockCollaborators.map((collab) => (
                  <div key={collab.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary/50">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-10 w-10 border border-border">
                        <AvatarImage src={collab.avatar || "/placeholder.svg"} />
                        <AvatarFallback>{collab.name.slice(0, 2)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{collab.name}</p>
                        <p className="text-sm text-muted-foreground">{collab.role}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="font-mono">
                        {collab.split}%
                      </Badge>
                      <Button size="icon" variant="ghost">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}

                <div className="flex gap-2 pt-4 border-t border-border/50">
                  <Input
                    placeholder="Wallet address or email"
                    value={newCollaborator}
                    onChange={(e) => setNewCollaborator(e.target.value)}
                    className="bg-input"
                  />
                  <Button className="gap-2">
                    <Plus className="h-4 w-4" />
                    Add
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-panel">
              <CardHeader>
                <CardTitle>Role Templates</CardTitle>
                <CardDescription>Quick-assign common roles</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {["Producer", "Vocalist", "Songwriter", "Engineer", "Featured Artist"].map((role) => (
                    <Button key={role} variant="outline" className="w-full justify-start bg-transparent">
                      {role}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Royalties Tab */}
        <TabsContent value="royalties">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="glass-panel">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="h-5 w-5 text-accent" />
                  Royalty Splits
                </CardTitle>
                <CardDescription>Configure how earnings are distributed</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {mockCollaborators.map((collab) => (
                  <div key={collab.id} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">{collab.name}</span>
                      <span className="text-sm font-mono text-accent">{collab.split}%</span>
                    </div>
                    <Slider defaultValue={[collab.split]} max={100} className="py-1" />
                  </div>
                ))}

                <div className="pt-4 border-t border-border/50">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">Remaining</span>
                    <span className="text-sm font-mono">30%</span>
                  </div>
                  <div className="h-2 rounded-full bg-secondary overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-primary via-accent to-neon-green"
                      style={{ width: "70%" }}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-panel">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Coins className="h-5 w-5 text-primary" />
                  Earnings Overview
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 rounded-lg bg-primary/10 border border-primary/30">
                    <p className="text-xs text-muted-foreground mb-1">Total Earnings</p>
                    <p className="text-3xl font-bold text-primary">$0.00</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 rounded-lg bg-secondary/50">
                      <p className="text-xs text-muted-foreground mb-1">Streaming</p>
                      <p className="text-lg font-bold">$0.00</p>
                    </div>
                    <div className="p-3 rounded-lg bg-secondary/50">
                      <p className="text-xs text-muted-foreground mb-1">NFT Sales</p>
                      <p className="text-lg font-bold">$0.00</p>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground text-center">
                    Earnings update in real-time as your tracks generate revenue
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Playlists Tab */}
        <TabsContent value="playlists">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card className="glass-panel">
                <CardHeader>
                  <CardTitle>Submit to Playlists</CardTitle>
                  <CardDescription>Get your tracks featured on 33.3 FM playlists</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {playlists.map((playlist) => (
                      <div
                        key={playlist.id}
                        onClick={() => setSelectedPlaylist(playlist.id)}
                        className={cn(
                          "p-4 rounded-lg cursor-pointer transition-all flex items-center justify-between",
                          selectedPlaylist === playlist.id
                            ? "bg-accent/20 border border-accent/50 neon-glow-cyan"
                            : "bg-secondary/50 hover:bg-secondary/70 border border-transparent",
                        )}
                      >
                        <div>
                          <p className={cn("font-medium", selectedPlaylist === playlist.id && "text-accent")}>
                            {playlist.name}
                          </p>
                          <p className="text-sm text-muted-foreground">{playlist.tracks} tracks</p>
                        </div>
                        <ArrowRight className="h-4 w-4 text-muted-foreground" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="glass-panel">
              <CardHeader>
                <CardTitle className="text-lg">Submission Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center py-8">
                    <ListMusic className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-sm text-muted-foreground">No pending submissions</p>
                  </div>
                  <Button className="w-full gap-2 neon-glow-cyan" disabled={!selectedPlaylist}>
                    Submit Selected Track
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
