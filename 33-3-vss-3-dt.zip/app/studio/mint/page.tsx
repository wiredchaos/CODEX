"use client"

import { useState } from "react"
import { AvatarGuide } from "@/components/studio/avatar-guide"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { cn } from "@/lib/utils"
import { Coins, Upload, Wallet, Check, AlertCircle, Shield, Zap } from "lucide-react"

const chains = [
  { id: "dogechain", name: "DogeChain", icon: "🐕", fee: "~0.1 DOGE" },
  { id: "xrpl", name: "XRPL", icon: "✕", fee: "~0.00001 XRP" },
  { id: "evm", name: "Ethereum", icon: "⟠", fee: "~$5-20" },
]

const contractTemplates = [
  { id: "standard", name: "Standard Music NFT", description: "Basic NFT with streaming royalties" },
  { id: "edition", name: "Limited Edition", description: "Numbered editions with scarcity" },
  { id: "membership", name: "Membership Pass", description: "Unlocks exclusive content access" },
]

export default function MintPage() {
  const [selectedChain, setSelectedChain] = useState("dogechain")
  const [selectedTemplate, setSelectedTemplate] = useState("standard")
  const [royaltyPercentage, setRoyaltyPercentage] = useState([10])
  const [isMinting, setIsMinting] = useState(false)
  const [mintStep, setMintStep] = useState(0)
  const [isProducer, setIsProducer] = useState(true) // Mock - would come from auth

  const handleMint = () => {
    setIsMinting(true)
    // Simulate minting process
    const steps = [1, 2, 3, 4]
    steps.forEach((step, index) => {
      setTimeout(
        () => {
          setMintStep(step)
          if (step === 4) {
            setTimeout(() => setIsMinting(false), 1000)
          }
        },
        (index + 1) * 1500,
      )
    })
  }

  const mintSteps = [
    { label: "Uploading audio", status: mintStep >= 1 },
    { label: "Generating metadata", status: mintStep >= 2 },
    { label: "Creating contract", status: mintStep >= 3 },
    { label: "Minting NFT", status: mintStep >= 4 },
  ]

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/20">
              <Coins className="h-6 w-6 text-primary" />
            </div>
            Mint
          </h1>
          <p className="text-muted-foreground mt-1">Mint your tracks as NFTs on your chosen blockchain</p>
        </div>
        {isProducer ? (
          <Badge className="bg-primary/20 text-primary border-primary/50 gap-2">
            <Shield className="h-3 w-3" />
            Zero Platform Fee
          </Badge>
        ) : (
          <Badge variant="outline">5% Platform Fee</Badge>
        )}
      </div>

      {/* Avatar Guide */}
      <AvatarGuide
        avatar="kiba"
        message="The Mint chamber is ready. Select your chain, configure royalties, and immortalize your signal on-chain. All users can mint - Producer tier holders enjoy zero platform fees and premium contract templates."
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Form */}
        <div className="lg:col-span-2 space-y-6">
          {/* Track Selection */}
          <Card className="glass-panel">
            <CardHeader>
              <CardTitle>Select Track</CardTitle>
              <CardDescription>Choose a completed track to mint</CardDescription>
            </CardHeader>
            <CardContent>
              <Select>
                <SelectTrigger className="bg-input">
                  <SelectValue placeholder="Select a track from your projects" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="midnight">Midnight Signal - Master</SelectItem>
                  <SelectItem value="cipher">Cipher Dreams - Final Mix</SelectItem>
                </SelectContent>
              </Select>

              <div className="mt-4 p-4 rounded-lg bg-secondary/50 flex items-center gap-4">
                <div className="w-16 h-16 rounded-lg bg-primary/20 flex items-center justify-center">
                  <Upload className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="text-sm text-muted-foreground">Or upload a new file</p>
                  <Button variant="outline" size="sm" className="mt-2 bg-transparent">
                    Upload Audio
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Metadata */}
          <Card className="glass-panel">
            <CardHeader>
              <CardTitle>NFT Metadata</CardTitle>
              <CardDescription>Information stored on-chain with your NFT</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Title</Label>
                  <Input placeholder="Track title" className="bg-input" />
                </div>
                <div className="space-y-2">
                  <Label>Artist Name</Label>
                  <Input placeholder="Your artist name" className="bg-input" />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea placeholder="Tell the story behind this track..." className="bg-input min-h-[100px]" />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Genre</Label>
                  <Select>
                    <SelectTrigger className="bg-input">
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hiphop">Hip-Hop</SelectItem>
                      <SelectItem value="electronic">Electronic</SelectItem>
                      <SelectItem value="rnb">R&B</SelectItem>
                      <SelectItem value="ambient">Ambient</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>BPM</Label>
                  <Input type="number" placeholder="140" className="bg-input" />
                </div>
                <div className="space-y-2">
                  <Label>Key</Label>
                  <Select>
                    <SelectTrigger className="bg-input">
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="c-minor">C Minor</SelectItem>
                      <SelectItem value="a-minor">A Minor</SelectItem>
                      <SelectItem value="g-major">G Major</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Chain Selection */}
          <Card className="glass-panel">
            <CardHeader>
              <CardTitle>Select Chain</CardTitle>
              <CardDescription>Choose which blockchain to mint on</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {chains.map((chain) => (
                  <button
                    key={chain.id}
                    onClick={() => setSelectedChain(chain.id)}
                    className={cn(
                      "p-4 rounded-lg text-left transition-all",
                      selectedChain === chain.id
                        ? "bg-primary/20 border-2 border-primary/50 neon-glow-red"
                        : "bg-secondary/50 hover:bg-secondary/70 border-2 border-transparent",
                    )}
                  >
                    <div className="text-2xl mb-2">{chain.icon}</div>
                    <p className={cn("font-medium", selectedChain === chain.id && "text-primary")}>{chain.name}</p>
                    <p className="text-xs text-muted-foreground mt-1">Fee: {chain.fee}</p>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Contract Template */}
          <Card className="glass-panel">
            <CardHeader>
              <CardTitle>Contract Template</CardTitle>
              <CardDescription>Choose your NFT type</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {contractTemplates.map((template) => (
                  <div
                    key={template.id}
                    onClick={() => setSelectedTemplate(template.id)}
                    className={cn(
                      "p-4 rounded-lg cursor-pointer transition-all flex items-center justify-between",
                      selectedTemplate === template.id
                        ? "bg-accent/20 border border-accent/50"
                        : "bg-secondary/50 hover:bg-secondary/70 border border-transparent",
                    )}
                  >
                    <div>
                      <p className={cn("font-medium", selectedTemplate === template.id && "text-accent")}>
                        {template.name}
                      </p>
                      <p className="text-sm text-muted-foreground">{template.description}</p>
                    </div>
                    {selectedTemplate === template.id && <Check className="h-5 w-5 text-accent" />}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          {/* Royalties */}
          <Card className="glass-panel">
            <CardHeader>
              <CardTitle className="text-lg">Royalty Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Secondary Sales Royalty</Label>
                  <span className="text-sm font-mono text-primary">{royaltyPercentage[0]}%</span>
                </div>
                <Slider value={royaltyPercentage} onValueChange={setRoyaltyPercentage} max={25} step={0.5} />
                <p className="text-xs text-muted-foreground">
                  You receive this percentage on all secondary market sales
                </p>
              </div>

              <div className="pt-4 border-t border-border/50 space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox id="split" />
                  <label htmlFor="split" className="text-sm">
                    Split with collaborators
                  </label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="exclusive" />
                  <label htmlFor="exclusive" className="text-sm">
                    Exclusive content unlock
                  </label>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Wallet Status */}
          <Card className="glass-panel">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Wallet className="h-4 w-4 text-accent" />
                Wallet
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="p-3 rounded-lg bg-secondary/50 flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-neon-green animate-pulse" />
                <div className="flex-1">
                  <p className="text-sm font-medium">Connected</p>
                  <p className="text-xs text-muted-foreground font-mono">0x1a2b...3c4d</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Mint Summary */}
          <Card className="glass-panel border-primary/30">
            <CardHeader>
              <CardTitle className="text-lg">Mint Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Network Fee</span>
                  <span>~0.1 DOGE</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Platform Fee</span>
                  <span className={isProducer ? "text-neon-green" : ""}>{isProducer ? "FREE" : "5%"}</span>
                </div>
                <div className="flex justify-between font-medium pt-2 border-t border-border/50">
                  <span>Total</span>
                  <span>~0.1 DOGE</span>
                </div>
              </div>

              {isMinting ? (
                <div className="space-y-3">
                  {mintSteps.map((step, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <div
                        className={cn(
                          "w-5 h-5 rounded-full flex items-center justify-center",
                          step.status ? "bg-neon-green" : "bg-secondary",
                        )}
                      >
                        {step.status ? (
                          <Check className="h-3 w-3 text-background" />
                        ) : (
                          <div className="w-2 h-2 rounded-full bg-muted-foreground" />
                        )}
                      </div>
                      <span className={cn("text-sm", step.status ? "text-foreground" : "text-muted-foreground")}>
                        {step.label}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <Button className="w-full gap-2 neon-glow-red h-12" onClick={handleMint}>
                  <Zap className="h-4 w-4" />
                  Mint NFT
                </Button>
              )}

              <p className="text-xs text-muted-foreground text-center flex items-center justify-center gap-1">
                <AlertCircle className="h-3 w-3" />
                Minting is irreversible
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
