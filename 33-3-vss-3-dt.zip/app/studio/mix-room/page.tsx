"use client"

import { useState } from "react"
import { AvatarGuide } from "@/components/studio/avatar-guide"
import { TrackLane } from "@/components/studio/track-lane"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { cn } from "@/lib/utils"
import {
  Sliders,
  Play,
  Pause,
  Square,
  SkipBack,
  SkipForward,
  Download,
  Wand2,
  Volume2,
  Waves,
  Gauge,
  Radio,
} from "lucide-react"

const mockTracks = [
  { id: "1", name: "Lead Vocal", color: "red" as const },
  { id: "2", name: "Beat", color: "cyan" as const },
  { id: "3", name: "Bass", color: "green" as const },
  { id: "4", name: "Synth Pad", color: "yellow" as const },
]

const fxPresets = [
  { id: "reverb", name: "Reverb", icon: Waves },
  { id: "delay", name: "Delay", icon: Radio },
  { id: "compressor", name: "Compressor", icon: Gauge },
  { id: "eq", name: "EQ", icon: Sliders },
]

const aiMixPresets = [
  { id: "broadcast", name: "33.3 FM Broadcast Master", description: "Radio-optimized loudness and clarity" },
  { id: "streaming", name: "Streaming Ready", description: "Balanced for Spotify/Apple Music" },
  { id: "club", name: "Club Master", description: "Enhanced bass and punch" },
  { id: "lofi", name: "Lo-Fi Texture", description: "Warm, vintage character" },
]

export default function MixRoomPage() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [selectedMixPreset, setSelectedMixPreset] = useState<string | null>(null)
  const [masterVolume, setMasterVolume] = useState([80])
  const [isProcessing, setIsProcessing] = useState(false)

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const handleAIMix = () => {
    if (!selectedMixPreset) return
    setIsProcessing(true)
    setTimeout(() => setIsProcessing(false), 4000)
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-3">
            <div className="p-2 rounded-lg bg-accent/20">
              <Sliders className="h-6 w-6 text-accent" />
            </div>
            Mix Room
          </h1>
          <p className="text-muted-foreground mt-1">DAW-lite multitrack editor with AI mixing</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="font-mono">
            Project: Untitled
          </Badge>
          <Badge variant="outline" className="text-accent border-accent/50 font-mono">
            140 BPM
          </Badge>
        </div>
      </div>

      {/* Avatar Guide */}
      <AvatarGuide
        avatar="redfang"
        message="The Mix Room is where your tracks come together. Adjust levels, apply FX, and use the AI mixing presets for broadcast-ready masters. Export in WAV, MP3, or STEM ZIP format."
      />

      {/* Transport Controls */}
      <Card className="glass-panel">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            {/* Playback Controls */}
            <div className="flex items-center gap-2">
              <Button size="icon" variant="ghost">
                <SkipBack className="h-4 w-4" />
              </Button>
              <Button
                size="icon"
                className={cn("h-12 w-12", isPlaying ? "neon-glow-cyan" : "neon-glow-red")}
                onClick={() => setIsPlaying(!isPlaying)}
              >
                {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5 ml-0.5" />}
              </Button>
              <Button size="icon" variant="ghost" onClick={() => setIsPlaying(false)}>
                <Square className="h-4 w-4" />
              </Button>
              <Button size="icon" variant="ghost">
                <SkipForward className="h-4 w-4" />
              </Button>
            </div>

            {/* Timeline */}
            <div className="flex-1 mx-8">
              <div className="flex items-center gap-4">
                <span className="text-sm font-mono text-muted-foreground w-12">{formatTime(currentTime)}</span>
                <Slider
                  value={[currentTime]}
                  onValueChange={([val]) => setCurrentTime(val)}
                  max={180}
                  className="flex-1"
                />
                <span className="text-sm font-mono text-muted-foreground w-12">3:00</span>
              </div>
            </div>

            {/* Master Volume */}
            <div className="flex items-center gap-3 w-40">
              <Volume2 className="h-4 w-4 text-muted-foreground" />
              <Slider value={masterVolume} onValueChange={setMasterVolume} max={100} />
              <span className="text-sm font-mono w-8">{masterVolume[0]}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Track Lanes */}
        <div className="lg:col-span-3 space-y-3">
          {mockTracks.map((track) => (
            <TrackLane key={track.id} name={track.name} color={track.color} />
          ))}

          {/* Add Track Button */}
          <Button variant="outline" className="w-full h-12 border-dashed bg-transparent">
            + Add Track
          </Button>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          <Tabs defaultValue="fx" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="fx">FX Rack</TabsTrigger>
              <TabsTrigger value="ai">AI Mix</TabsTrigger>
            </TabsList>

            <TabsContent value="fx">
              <Card className="glass-panel">
                <CardContent className="p-4 space-y-3">
                  {fxPresets.map((fx) => {
                    const Icon = fx.icon
                    return (
                      <div key={fx.id} className="p-3 rounded-lg bg-secondary/50 hover:bg-secondary/70 cursor-pointer">
                        <div className="flex items-center gap-3 mb-2">
                          <Icon className="h-4 w-4 text-accent" />
                          <span className="text-sm font-medium">{fx.name}</span>
                        </div>
                        <Slider defaultValue={[50]} max={100} className="h-1" />
                      </div>
                    )
                  })}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="ai">
              <Card className="glass-panel">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Wand2 className="h-4 w-4 text-primary" />
                    AI Mixing
                  </CardTitle>
                  <CardDescription>One-click professional mix</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {aiMixPresets.map((preset) => (
                    <button
                      key={preset.id}
                      onClick={() => setSelectedMixPreset(preset.id)}
                      className={cn(
                        "w-full p-3 rounded-lg text-left transition-all",
                        selectedMixPreset === preset.id
                          ? "bg-primary/20 border border-primary/50"
                          : "bg-secondary/50 hover:bg-secondary/70 border border-transparent",
                      )}
                    >
                      <p className={cn("text-sm font-medium", selectedMixPreset === preset.id && "text-primary")}>
                        {preset.name}
                      </p>
                      <p className="text-xs text-muted-foreground">{preset.description}</p>
                    </button>
                  ))}

                  <Button
                    className="w-full gap-2 neon-glow-red mt-4"
                    disabled={!selectedMixPreset || isProcessing}
                    onClick={handleAIMix}
                  >
                    {isProcessing ? (
                      <>
                        <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Wand2 className="h-4 w-4" />
                        Apply AI Mix
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* Export Options */}
          <Card className="glass-panel">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Download className="h-4 w-4 text-accent" />
                Export
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Select defaultValue="wav">
                <SelectTrigger className="bg-input">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="wav">WAV (Lossless)</SelectItem>
                  <SelectItem value="mp3">MP3 (320kbps)</SelectItem>
                  <SelectItem value="stems">STEM ZIP</SelectItem>
                </SelectContent>
              </Select>
              <Button className="w-full gap-2 neon-glow-cyan">
                <Download className="h-4 w-4" />
                Export Track
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
