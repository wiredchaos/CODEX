import type React from "react"
import { StudioHeader } from "@/components/studio/studio-header"
import { StudioSidebar } from "@/components/studio/studio-sidebar"

// For now, we'll use a mock user - this will be replaced with real auth
const mockUser = {
  id: "demo-user",
  display_name: "Signal Operator",
  tier: "creator" as const,
  wallet: null,
}

export default function StudioLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen bg-background circuit-pattern flex flex-col">
      <StudioHeader user={mockUser} />
      <div className="flex-1 flex">
        <StudioSidebar userTier={mockUser.tier} />
        <main className="flex-1 overflow-auto">{children}</main>
      </div>
    </div>
  )
}
