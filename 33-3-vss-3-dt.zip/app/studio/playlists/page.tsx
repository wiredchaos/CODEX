"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Play, Plus, Radio, TrendingUp, Flame, Star, Music } from "lucide-react"

export default function PlaylistsPage() {
  const [activePlaylist, setActivePlaylist] = useState<string | null>(null)

  const playlists = [
    {
      id: "genesis",
      type: "Genesis Genesis",
      icon: Radio,
      color: "text-cyan-400",
      bgGradient: "from-cyan-500/20 to-cyan-500/5",
      description: "Foundation tracks that shaped 33.3 FM",
      tracks: [
        { id: "1", title: "Signal Zero", artist: "DJ Cipher", duration: "3:45", priority: 95 },
        { id: "2", title: "Neon Dreams", artist: "MixMaster V", duration: "4:12", priority: 92 },
        { id: "3", title: "Chain Reaction", artist: "Block Producer", duration: "3:58", priority: 90 },
      ],
    },
    {
      id: "labyrinth",
      type: "The Labyrinth",
      icon: TrendingUp,
      color: "text-purple-400",
      bgGradient: "from-purple-500/20 to-purple-500/5",
      description: "Deep cuts and experimental sounds",
      tracks: [
        { id: "4", title: "Echo Chamber", artist: "Sound Architect", duration: "5:23", priority: 88 },
        { id: "5", title: "Binary Soul", artist: "Digital Shaman", duration: "4:45", priority: 85 },
        { id: "6", title: "Void Walker", artist: "Bass Nomad", duration: "6:12", priority: 82 },
      ],
    },
    {
      id: "redfang",
      type: "Red Fang",
      icon: Flame,
      color: "text-red-400",
      bgGradient: "from-red-500/20 to-red-500/5",
      description: "High-energy bangers and crowd favorites",
      tracks: [
        { id: "7", title: "Voltage Surge", artist: "Electric Storm", duration: "3:33", priority: 97 },
        { id: "8", title: "Crimson Code", artist: "Neon Syndicate", duration: "4:05", priority: 94 },
        { id: "9", title: "Fire Protocol", artist: "Heat Seeker", duration: "3:47", priority: 91 },
      ],
    },
    {
      id: "spotlight",
      type: "In The Spotlight",
      icon: Star,
      color: "text-yellow-400",
      bgGradient: "from-yellow-500/20 to-yellow-500/5",
      description: "Featured artists and rising stars",
      tracks: [
        { id: "10", title: "Midnight Run", artist: "Shadow Walker", duration: "4:28", priority: 89 },
        { id: "11", title: "Crystal Sky", artist: "Aurora Beats", duration: "3:55", priority: 86 },
        { id: "12", title: "Neon Pulse", artist: "Cyber Dreamer", duration: "4:18", priority: 83 },
      ],
    },
  ]

  return (
    <div className="min-h-screen bg-black p-4 md:p-6">
      <div className="mx-auto max-w-7xl space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">VSS-33.3 Playlists</h1>
            <p className="mt-1 text-sm text-neutral-400">Curated collections from the virtual signal studio</p>
          </div>
          <Button className="neon-glow bg-gradient-to-r from-cyan-500 to-cyan-600 text-white hover:from-cyan-600 hover:to-cyan-700">
            <Plus className="mr-2 h-4 w-4" />
            Create Playlist
          </Button>
        </div>

        {/* Playlist Tabs */}
        <Tabs defaultValue="genesis" className="w-full">
          <TabsList className="glass-panel mb-6 grid w-full grid-cols-2 md:grid-cols-4 gap-2 bg-neutral-900/50 p-2">
            {playlists.map((playlist) => (
              <TabsTrigger
                key={playlist.id}
                value={playlist.id}
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-cyan-500/20 data-[state=active]:to-cyan-500/5"
              >
                <playlist.icon className={`mr-2 h-4 w-4 ${playlist.color}`} />
                <span className="text-sm">{playlist.type}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          {playlists.map((playlist) => (
            <TabsContent key={playlist.id} value={playlist.id} className="space-y-6">
              {/* Playlist Header Card */}
              <Card className={`glass-panel border-neutral-800 bg-gradient-to-br ${playlist.bgGradient}`}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center gap-3">
                        <playlist.icon className={`h-8 w-8 ${playlist.color}`} />
                        <CardTitle className="text-2xl text-white">{playlist.type}</CardTitle>
                      </div>
                      <CardDescription className="text-neutral-300">{playlist.description}</CardDescription>
                      <div className="flex items-center gap-4 pt-2">
                        <Badge variant="outline" className="border-cyan-500/50 text-cyan-400">
                          {playlist.tracks.length} tracks
                        </Badge>
                        <Badge variant="outline" className="border-neutral-700 text-neutral-300">
                          <Music className="mr-1 h-3 w-3" />
                          Curated
                        </Badge>
                      </div>
                    </div>
                    <Button
                      size="lg"
                      className="neon-glow bg-gradient-to-r from-cyan-500 to-cyan-600 text-white hover:from-cyan-600 hover:to-cyan-700"
                    >
                      <Play className="mr-2 h-5 w-5" />
                      Play All
                    </Button>
                  </div>
                </CardHeader>
              </Card>

              {/* Track List */}
              <Card className="glass-panel border-neutral-800 bg-neutral-900/30">
                <CardContent className="p-6">
                  <div className="space-y-1">
                    {playlist.tracks.map((track, index) => (
                      <div
                        key={track.id}
                        className="flex items-center gap-4 rounded-lg p-3 transition-colors hover:bg-neutral-800/50"
                      >
                        <span className="w-8 text-right text-sm text-neutral-500">{index + 1}</span>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-10 w-10 p-0 text-cyan-400 hover:bg-cyan-500/20 hover:text-cyan-300"
                        >
                          <Play className="h-4 w-4" />
                        </Button>
                        <div className="flex-1">
                          <div className="font-medium text-white">{track.title}</div>
                          <div className="text-sm text-neutral-400">{track.artist}</div>
                        </div>
                        <Badge variant="outline" className="border-cyan-500/50 text-cyan-400">
                          Priority: {track.priority}
                        </Badge>
                        <span className="text-sm text-neutral-400">{track.duration}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  )
}
