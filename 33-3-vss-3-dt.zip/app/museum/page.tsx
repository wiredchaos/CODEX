import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { FMPlayerWidget } from "@/components/museum/fm-player-widget"
import { EnvironmentRenderer } from "@/components/trinity/environment-renderer"
import { ArrowRight, Radio, ShieldCheck, ImageIcon, Music } from "lucide-react"

export default async function MuseumPage() {
  return (
    <EnvironmentRenderer
      patchId="NEON-VAULT"
      kind="gallery"
      hotspots={[
        { id: "galleries", label: "GALLERIES", position: { x: 20, y: 40 }, action: () => {} },
        { id: "audits", label: "IP AUDITS", position: { x: 80, y: 40 }, action: () => {} },
        { id: "audio", label: "33.3 FM", position: { x: 50, y: 70 }, action: () => {} },
      ]}
    >
      <div className="min-h-screen">
        {/* Hero Section */}
        <section className="relative overflow-hidden border-b border-primary/20">
          <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/60 to-background/90" />

          <div className="relative container mx-auto px-4 py-20 md:py-32">
            <div className="max-w-4xl mx-auto text-center space-y-6">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-4">
                <Radio className="h-4 w-4 text-primary animate-pulse" />
                <span className="text-sm font-semibold text-primary">33.3 FM DOGECHAIN</span>
              </div>

              <h1 className="text-5xl md:text-7xl font-bold text-foreground leading-tight">
                The Neon <span className="text-gradient">Vault</span> Museum
              </h1>

              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Enter the cyberpunk sanctuary where holographic NFTs float in the void, powered by 33.3 FM and secured
                by blockchain verification
              </p>

              <div className="flex items-center justify-center gap-4 pt-6">
                <Button size="lg" className="neon-glow" asChild>
                  <Link href="/museum/galleries">
                    <ImageIcon className="h-5 w-5 mr-2" />
                    Explore Galleries
                  </Link>
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <Link href="/museum/audio">
                    <Music className="h-5 w-5 mr-2" />
                    Audio Tours
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Features Grid */}
        <section className="relative container mx-auto px-4 py-20">
          <div className="absolute inset-0 bg-background/70" />
          <div className="relative grid md:grid-cols-3 gap-6">
            <Card className="glass-panel circuit-glow">
              <CardHeader>
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <ImageIcon className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>NFT Galleries</CardTitle>
                <CardDescription>
                  Curated exhibitions of verified digital art from OpenSea and blockchain networks
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="ghost" className="group" asChild>
                  <Link href="/museum/galleries">
                    View Galleries
                    <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="glass-panel circuit-glow">
              <CardHeader>
                <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center mb-4">
                  <ShieldCheck className="h-6 w-6 text-accent" />
                </div>
                <CardTitle>IP Audit System</CardTitle>
                <CardDescription>
                  Automated verification of NFT ownership, authenticity, and licensing rights
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="ghost" className="group" asChild>
                  <Link href="/museum/audits">
                    View Audits
                    <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="glass-panel circuit-glow">
              <CardHeader>
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <Music className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>33.3 FM Audio</CardTitle>
                <CardDescription>Immersive audio guides and curated soundscapes for each exhibition</CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="ghost" className="group" asChild>
                  <Link href="/museum/audio">
                    Listen Now
                    <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Featured Gallery Preview */}
        <section className="relative container mx-auto px-4 py-20">
          <div className="absolute inset-0 bg-background/60" />
          <div className="relative space-y-6">
            <div className="flex items-end justify-between">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold text-foreground">Featured Exhibition</h2>
                <p className="text-muted-foreground mt-2">Currently showing in The Neon Vault</p>
              </div>
              <Button variant="outline" asChild>
                <Link href="/museum/galleries/neon-vault">
                  View All
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Link>
              </Button>
            </div>

            <div className="grid md:grid-cols-4 gap-6">
              {Array.from({ length: 4 }).map((_, i) => (
                <Card key={i} className="glass-panel circuit-glow cursor-pointer group">
                  <div className="aspect-square bg-muted/20 relative overflow-hidden">
                    <img
                      src={`/cyberpunk-nft-holographic-art-.jpg?height=400&width=400&query=cyberpunk+nft+holographic+art+${i + 1}`}
                      alt={`Exhibit ${i + 1}`}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold text-foreground">Cipher #{100 + i}</h3>
                    <p className="text-sm text-muted-foreground">Digital Dreams</p>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* FM Player Widget */}
        <FMPlayerWidget />
      </div>
    </EnvironmentRenderer>
  )
}
