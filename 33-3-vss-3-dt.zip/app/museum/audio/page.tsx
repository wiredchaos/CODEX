import { getDb } from "@/lib/db"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { FMPlayerWidget } from "@/components/museum/fm-player-widget"
import { Play, Clock, Headphones, Music2 } from "lucide-react"
import Link from "next/link"

async function getAudioContent() {
  const sql = getDb()

  // Get featured tracks from fm_tracks
  const featuredTracks = await sql`
    SELECT * FROM fm_tracks
    WHERE metadata->>'featured' = 'true'
    OR boost_count > 0
    ORDER BY play_count DESC
    LIMIT 8
  `

  // Get museum playlists
  const playlists = await sql`
    SELECT * FROM museum_playlists
    WHERE is_public = true
    ORDER BY is_featured DESC, created_at DESC
    LIMIT 6
  `

  return { featuredTracks, playlists }
}

export default async function AudioPage() {
  const { featuredTracks, playlists } = await getAudioContent()

  return (
    <div className="min-h-screen bg-background pb-32">
      {/* Header */}
      <div className="relative border-b border-primary/20 overflow-hidden">
        <div className="absolute inset-0 circuit-pattern opacity-5" />
        <div className="absolute inset-0 bg-gradient-to-b from-primary/10 via-transparent to-transparent" />

        <div className="relative container mx-auto px-4 py-16 md:py-24">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-4">
              <Music2 className="h-4 w-4 text-primary animate-pulse" />
              <span className="text-sm font-semibold text-primary">33.3 FM AUDIO EXPERIENCE</span>
            </div>

            <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-4">
              Immersive <span className="text-gradient">Audio Tours</span>
            </h1>

            <p className="text-lg text-muted-foreground">
              Curated soundscapes and artist commentary for every exhibition in The Neon Vault Museum
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12 space-y-12">
        {/* Featured Tracks */}
        <section className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold text-foreground">Featured Audio Guides</h2>
              <p className="text-muted-foreground mt-1">Expert commentary and artist interviews</p>
            </div>
            <Button variant="outline">View All</Button>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredTracks.map((track: any) => (
              <Card
                key={track.id}
                className="glass-panel circuit-glow group cursor-pointer hover:scale-105 transition-all"
              >
                <div className="aspect-square relative overflow-hidden">
                  <img
                    src={track.cover_art_url || "/neon-abstract-album-art.jpg"}
                    alt={track.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/60 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Button size="lg" className="rounded-full neon-glow">
                      <Play className="h-6 w-6" />
                    </Button>
                  </div>
                  <Badge className="absolute top-3 right-3" variant="secondary">
                    <Headphones className="h-3 w-3 mr-1" />
                    {track.play_count || 0}
                  </Badge>
                </div>
                <CardHeader className="pb-4">
                  <CardTitle className="text-base truncate">{track.title}</CardTitle>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    <span>
                      {Math.floor((track.duration || 180) / 60)}:
                      {((track.duration || 180) % 60).toString().padStart(2, "0")}
                    </span>
                  </div>
                </CardHeader>
              </Card>
            ))}
          </div>
        </section>

        {/* Curated Playlists */}
        <section className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold text-foreground">Curated Playlists</h2>
              <p className="text-muted-foreground mt-1">Gallery soundtracks and thematic collections</p>
            </div>
            <Button variant="outline">View All</Button>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {playlists.map((playlist: any) => (
              <Link key={playlist.id} href={`/museum/audio/playlists/${playlist.id}`}>
                <Card className="glass-panel circuit-glow cursor-pointer group hover:border-primary/30 transition-all">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-20 h-20 rounded-lg overflow-hidden bg-muted/20 flex-shrink-0">
                        <img
                          src={playlist.cover_art_url || "/neon-abstract-album-art.jpg"}
                          alt={playlist.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-foreground mb-1 truncate group-hover:text-primary transition-colors">
                          {playlist.name}
                        </h3>
                        <p className="text-sm text-muted-foreground line-clamp-2 mb-2">{playlist.description}</p>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground">
                          <span>{(playlist.track_ids || []).length} tracks</span>
                          <span>•</span>
                          <span>{playlist.play_count || 0} plays</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>

        {/* Audio Zones */}
        <section className="space-y-6">
          <div>
            <h2 className="text-3xl font-bold text-foreground">Gallery Audio Zones</h2>
            <p className="text-muted-foreground mt-1">Spatial audio experiences for each exhibition space</p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <Card className="glass-panel circuit-glow">
              <CardHeader>
                <CardTitle>North Wing - Cyberpunk Dreams</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Ambient Track</span>
                    <span className="text-foreground">Neon Rain</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Volume</span>
                    <span className="text-foreground">70%</span>
                  </div>
                  <Button size="sm" className="w-full neon-glow">
                    <Play className="h-4 w-4 mr-2" />
                    Preview Zone Audio
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-panel circuit-glow">
              <CardHeader>
                <CardTitle>South Wing - Digital Horizons</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Ambient Track</span>
                    <span className="text-foreground">Data Stream</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Volume</span>
                    <span className="text-foreground">65%</span>
                  </div>
                  <Button size="sm" className="w-full neon-glow">
                    <Play className="h-4 w-4 mr-2" />
                    Preview Zone Audio
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </div>

      <FMPlayerWidget />
    </div>
  )
}
