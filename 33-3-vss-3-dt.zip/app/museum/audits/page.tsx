import { getDb } from "@/lib/db"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { IPAuditBadge } from "@/components/museum/ip-audit-badge"
import { FMPlayerWidget } from "@/components/museum/fm-player-widget"
import { Search, TrendingUp, Shield } from "lucide-react"
import Link from "next/link"

async function getAuditStats() {
  const sql = getDb()

  const [stats] = await sql`
    SELECT 
      COUNT(*) as total_audits,
      COUNT(*) FILTER (WHERE status = 'verified') as verified_count,
      COUNT(*) FILTER (WHERE status = 'pending') as pending_count,
      COUNT(*) FILTER (WHERE status = 'disputed') as disputed_count,
      AVG(confidence_score) FILTER (WHERE status = 'verified') as avg_confidence
    FROM museum_ip_audits
  `

  const recentAudits = await sql`
    SELECT 
      a.*,
      e.title,
      e.artist_name,
      e.image_url,
      e.contract_address,
      e.token_id
    FROM museum_ip_audits a
    JOIN museum_nft_exhibits e ON a.exhibit_id = e.id
    ORDER BY a.created_at DESC
    LIMIT 20
  `

  return { stats, recentAudits }
}

export default async function AuditsPage() {
  const { stats, recentAudits } = await getAuditStats()

  return (
    <div className="min-h-screen bg-background pb-32">
      {/* Header */}
      <div className="border-b border-primary/20 bg-muted/30">
        <div className="container mx-auto px-4 py-12">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">IP Audit System</h1>
              <p className="text-lg text-muted-foreground max-w-2xl">
                Automated verification of NFT ownership, authenticity, and licensing rights powered by blockchain
                analysis and OpenSea integration
              </p>
            </div>
            <Shield className="h-16 w-16 text-primary/30" />
          </div>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-4 gap-6 mb-12">
          <Card className="glass-panel">
            <CardHeader className="pb-3">
              <CardDescription>Total Audits</CardDescription>
              <CardTitle className="text-3xl">{stats.total_audits || 0}</CardTitle>
            </CardHeader>
          </Card>

          <Card className="glass-panel">
            <CardHeader className="pb-3">
              <CardDescription>Verified</CardDescription>
              <CardTitle className="text-3xl text-green-400">{stats.verified_count || 0}</CardTitle>
            </CardHeader>
          </Card>

          <Card className="glass-panel">
            <CardHeader className="pb-3">
              <CardDescription>Pending</CardDescription>
              <CardTitle className="text-3xl text-yellow-400">{stats.pending_count || 0}</CardTitle>
            </CardHeader>
          </Card>

          <Card className="glass-panel">
            <CardHeader className="pb-3">
              <CardDescription>Avg. Confidence</CardDescription>
              <CardTitle className="text-3xl flex items-baseline gap-1">
                {Math.round(stats.avg_confidence || 0)}
                <span className="text-base text-muted-foreground">%</span>
              </CardTitle>
            </CardHeader>
          </Card>
        </div>

        {/* Search */}
        <div className="mb-8">
          <div className="relative max-w-2xl">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search by contract address, token ID, or artist..." className="pl-10" />
          </div>
        </div>

        {/* Recent Audits */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-foreground">Recent Audits</h2>
            <Button variant="outline" size="sm">
              <TrendingUp className="h-4 w-4 mr-2" />
              View All
            </Button>
          </div>

          <div className="space-y-3">
            {recentAudits.map((audit: any) => (
              <Link key={audit.id} href={`/museum/audits/${audit.id}`}>
                <Card className="glass-panel hover:border-primary/30 transition-colors cursor-pointer">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      {/* Thumbnail */}
                      <div className="w-16 h-16 rounded-md overflow-hidden bg-muted/20 flex-shrink-0">
                        <img
                          src={audit.image_url || "/placeholder.svg"}
                          alt={audit.title}
                          className="w-full h-full object-cover"
                        />
                      </div>

                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-4">
                          <div className="min-w-0 flex-1">
                            <h3 className="font-semibold text-foreground truncate">{audit.title}</h3>
                            <p className="text-sm text-muted-foreground truncate">{audit.artist_name}</p>
                            <p className="text-xs text-muted-foreground font-mono mt-1 truncate">
                              {audit.contract_address.slice(0, 8)}...{audit.contract_address.slice(-6)} #
                              {audit.token_id}
                            </p>
                          </div>

                          <div className="flex flex-col items-end gap-2">
                            <IPAuditBadge status={audit.status} score={audit.confidence_score} size="sm" />
                            <span className="text-xs text-muted-foreground">
                              {new Date(audit.created_at).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </div>

      <FMPlayerWidget />
    </div>
  )
}
