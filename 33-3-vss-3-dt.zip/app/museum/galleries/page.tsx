import { getDb } from "@/lib/db"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { FMPlayerWidget } from "@/components/museum/fm-player-widget"
import { ArrowRight, Users, ImageIcon } from "lucide-react"
import Link from "next/link"

async function getGalleries() {
  const sql = getDb()

  const galleries = await sql`
    SELECT 
      g.*,
      COUNT(DISTINCT e.id) as exhibit_count
    FROM museum_galleries g
    LEFT JOIN museum_nft_exhibits e ON g.id = e.gallery_id
    WHERE g.is_active = true
    GROUP BY g.id
    ORDER BY g.order_index ASC, g.created_at DESC
  `

  return galleries
}

export default async function GalleriesPage() {
  const galleries = await getGalleries()

  return (
    <div className="min-h-screen bg-background pb-32">
      {/* Header */}
      <div className="border-b border-primary/20 bg-muted/30">
        <div className="container mx-auto px-4 py-12">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Museum Galleries</h1>
          <p className="text-lg text-muted-foreground max-w-2xl">
            Explore curated exhibitions of verified NFT art from across the blockchain multiverse
          </p>
        </div>
      </div>

      {/* Galleries Grid */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {galleries.map((gallery) => (
            <Link key={gallery.id} href={`/museum/galleries/${gallery.slug}`}>
              <Card className="glass-panel circuit-glow h-full cursor-pointer group hover:scale-105 transition-all duration-300">
                {/* Gallery Preview */}
                <div className="relative aspect-[16/9] overflow-hidden bg-muted/20">
                  <img
                    src={`/neon-gallery-.jpg?height=400&width=600&query=neon+gallery+${gallery.name}`}
                    alt={gallery.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />

                  {/* Stats Overlay */}
                  <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
                    <Badge variant="secondary" className="gap-1">
                      <ImageIcon className="h-3 w-3" />
                      {gallery.exhibit_count} exhibits
                    </Badge>
                    <Badge variant="secondary" className="gap-1">
                      <Users className="h-3 w-3" />
                      {gallery.visitor_count} visitors
                    </Badge>
                  </div>
                </div>

                <CardHeader>
                  <CardTitle className="group-hover:text-primary transition-colors">{gallery.name}</CardTitle>
                  <CardDescription className="line-clamp-2">{gallery.description}</CardDescription>
                </CardHeader>

                <CardContent>
                  <Button variant="ghost" className="w-full group/btn">
                    Enter Gallery
                    <ArrowRight className="h-4 w-4 ml-2 group-hover/btn:translate-x-1 transition-transform" />
                  </Button>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>

      <FMPlayerWidget />
    </div>
  )
}
