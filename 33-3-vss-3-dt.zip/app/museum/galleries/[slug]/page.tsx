import { notFound } from "next/navigation"
import { getDb } from "@/lib/db"
import { FMPlayerWidget } from "@/components/museum/fm-player-widget"
import { NFTExhibitCard } from "@/components/museum/nft-exhibit-card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Music, Filter } from "lucide-react"

async function getGalleryWithExhibits(slug: string) {
  const sql = getDb()

  const [gallery] = await sql`
    SELECT * FROM museum_galleries
    WHERE slug = ${slug} AND is_active = true
  `

  if (!gallery) return null

  const exhibits = await sql`
    SELECT * FROM museum_nft_exhibits
    WHERE gallery_id = ${gallery.id}
    ORDER BY display_order ASC, created_at DESC
  `

  return { ...gallery, exhibits }
}

export default async function GalleryPage({ params }: { params: { slug: string } }) {
  const gallery = await getGalleryWithExhibits(params.slug)

  if (!gallery) {
    notFound()
  }

  return (
    <div className="min-h-screen bg-background pb-32">
      {/* Gallery Header */}
      <div className="relative border-b border-primary/20 overflow-hidden">
        <div className="absolute inset-0 circuit-pattern opacity-5" />
        <div
          className="absolute inset-0 bg-gradient-to-b from-primary/10 via-transparent to-transparent"
          style={{ backgroundColor: `${gallery.theme_color}10` }}
        />

        <div className="relative container mx-auto px-4 py-16 md:py-24">
          <div className="max-w-3xl">
            <Badge className="mb-4" style={{ borderColor: gallery.theme_color }}>
              {gallery.exhibits.length} Exhibits
            </Badge>

            <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-4">{gallery.name}</h1>

            <p className="text-lg text-muted-foreground mb-6">{gallery.description}</p>

            <div className="flex items-center gap-3">
              <Button className="neon-glow">
                <Music className="h-4 w-4 mr-2" />
                Play Audio Tour
              </Button>
              <Button variant="outline">
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Exhibits Grid */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {gallery.exhibits.map((exhibit: any) => (
            <NFTExhibitCard
              key={exhibit.id}
              exhibit={{
                id: exhibit.id,
                title: exhibit.title || "Untitled",
                artistName: exhibit.artist_name || "Unknown Artist",
                imageUrl: exhibit.image_url || "/digital-art-collection.png",
                animationUrl: exhibit.animation_url,
                contractAddress: exhibit.contract_address,
                tokenId: exhibit.token_id,
                chain: exhibit.chain,
                ipAuditStatus: exhibit.ip_audit_status,
                ipAuditScore: exhibit.ip_audit_score,
                audioGuideTrackId: exhibit.audio_guide_track_id,
                openseaUrl: exhibit.external_url,
              }}
            />
          ))}
        </div>

        {gallery.exhibits.length === 0 && (
          <div className="text-center py-20">
            <p className="text-lg text-muted-foreground">
              This gallery is currently being curated. Check back soon for new exhibits.
            </p>
          </div>
        )}
      </div>

      <FMPlayerWidget />
    </div>
  )
}
