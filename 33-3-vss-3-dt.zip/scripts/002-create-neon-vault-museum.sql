-- Neon Vault Museum Schema for 33.3 FM DOGECHAIN
-- Digital Art Museum + Audio Player + NFT Gallery + IP Audit System

CREATE TABLE IF NOT EXISTS museum_galleries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  curator_id UUID REFERENCES users(id),
  theme_color TEXT DEFAULT '#00FFFF',
  is_active BOOLEAN DEFAULT true,
  featured_nft_id TEXT,
  visitor_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS museum_nft_exhibits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  gallery_id UUID REFERENCES museum_galleries(id) ON DELETE CASCADE,
  opensea_asset_id TEXT NOT NULL,
  contract_address TEXT NOT NULL,
  token_id TEXT NOT NULL,
  chain TEXT DEFAULT 'ethereum',
  title TEXT,
  artist_name TEXT,
  description TEXT,
  image_url TEXT,
  animation_url TEXT,
  external_url TEXT,
  metadata JSONB,
  display_order INTEGER DEFAULT 0,
  wall_position TEXT, -- 'north', 'south', 'east', 'west', 'ceiling'
  hologram_effect BOOLEAN DEFAULT true,
  audio_guide_track_id TEXT REFERENCES fm_tracks(id),
  ip_audit_status TEXT DEFAULT 'pending', -- 'pending', 'verified', 'disputed'
  ip_audit_score NUMERIC DEFAULT 0,
  views INTEGER DEFAULT 0,
  is_featured BOOLEAN DEFAULT false,
  acquired_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS museum_audio_zones (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  gallery_id UUID REFERENCES museum_galleries(id) ON DELETE CASCADE,
  zone_name TEXT NOT NULL,
  ambient_track_id TEXT REFERENCES fm_tracks(id),
  playlist_id TEXT,
  volume_level NUMERIC DEFAULT 0.7,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS museum_fm_player_state (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) UNIQUE,
  current_track_id TEXT REFERENCES fm_tracks(id),
  current_playlist TEXT,
  position_seconds INTEGER DEFAULT 0,
  is_playing BOOLEAN DEFAULT false,
  volume NUMERIC DEFAULT 0.8,
  repeat_mode TEXT DEFAULT 'off', -- 'off', 'one', 'all'
  shuffle BOOLEAN DEFAULT false,
  queue JSONB DEFAULT '[]',
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS museum_ip_audits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  exhibit_id UUID REFERENCES museum_nft_exhibits(id) ON DELETE CASCADE,
  audit_type TEXT NOT NULL, -- 'ownership', 'authenticity', 'licensing', 'provenance'
  auditor TEXT,
  status TEXT DEFAULT 'pending', -- 'pending', 'approved', 'rejected', 'disputed'
  confidence_score NUMERIC DEFAULT 0,
  findings JSONB,
  evidence_urls TEXT[],
  blockchain_verification JSONB,
  opensea_verification JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  completed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS museum_visitor_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  gallery_id UUID REFERENCES museum_galleries(id),
  exhibit_id UUID REFERENCES museum_nft_exhibits(id),
  action TEXT, -- 'view', 'interact', 'audio_play', 'share'
  duration_seconds INTEGER,
  metadata JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS museum_playlists (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  curator_id UUID REFERENCES users(id),
  cover_art_url TEXT,
  track_ids TEXT[] DEFAULT '{}',
  is_public BOOLEAN DEFAULT true,
  is_featured BOOLEAN DEFAULT false,
  play_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_exhibits_gallery ON museum_nft_exhibits(gallery_id);
CREATE INDEX IF NOT EXISTS idx_exhibits_opensea ON museum_nft_exhibits(opensea_asset_id);
CREATE INDEX IF NOT EXISTS idx_exhibits_contract ON museum_nft_exhibits(contract_address, token_id);
CREATE INDEX IF NOT EXISTS idx_audits_exhibit ON museum_ip_audits(exhibit_id);
CREATE INDEX IF NOT EXISTS idx_visitor_logs_user ON museum_visitor_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_visitor_logs_gallery ON museum_visitor_logs(gallery_id);

-- Insert default gallery: The Neon Vault
INSERT INTO museum_galleries (name, slug, description, theme_color, is_active)
VALUES (
  'The Neon Vault',
  'neon-vault',
  'Enter the cyberpunk sanctuary of digital art where holographic NFTs float in the void, powered by 33.3 FM DOGECHAIN',
  '#FF0055',
  true
) ON CONFLICT (slug) DO NOTHING;
