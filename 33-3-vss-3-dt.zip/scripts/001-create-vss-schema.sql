-- VSS-33.3 Virtual Signal Studio Database Schema
-- Run this script to create all required tables

-- Users table (extends neon_auth.users_sync)
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE,
  wallet TEXT,
  tier TEXT DEFAULT 'guest' CHECK (tier IN ('guest', 'creator', 'producer', 'syndicate')),
  avatar TEXT,
  display_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tracks table
CREATE TABLE IF NOT EXISTS tracks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'processing', 'ready', 'published', 'archived')),
  bpm INTEGER,
  key TEXT,
  stem_urls JSONB DEFAULT '[]'::jsonb,
  waveform_url TEXT,
  audio_url TEXT,
  room_origin TEXT,
  duration_seconds INTEGER,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Projects table
CREATE TABLE IF NOT EXISTS projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  cover_url TEXT,
  collaborators JSONB DEFAULT '[]'::jsonb,
  royalties JSONB DEFAULT '{}'::jsonb,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'completed', 'archived')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Project tracks junction table
CREATE TABLE IF NOT EXISTS project_tracks (
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  track_id UUID REFERENCES tracks(id) ON DELETE CASCADE,
  position INTEGER DEFAULT 0,
  PRIMARY KEY (project_id, track_id)
);

-- Gates table (token-gating)
CREATE TABLE IF NOT EXISTS gates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
  nft_contract TEXT,
  token_id TEXT,
  chain TEXT DEFAULT 'dogechain',
  tier TEXT NOT NULL CHECK (tier IN ('creator', 'producer', 'syndicate')),
  verified_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  expires_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Playlists table
CREATE TABLE IF NOT EXISTS playlists (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type TEXT NOT NULL CHECK (type IN ('genesis', 'labyrinth', 'redfang', 'spotlight', 'custom')),
  name TEXT NOT NULL,
  description TEXT,
  cover_url TEXT,
  is_public BOOLEAN DEFAULT true,
  created_by TEXT REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Playlist tracks junction table
CREATE TABLE IF NOT EXISTS playlist_tracks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  playlist_id UUID REFERENCES playlists(id) ON DELETE CASCADE,
  track_id UUID REFERENCES tracks(id) ON DELETE CASCADE,
  priority_score INTEGER DEFAULT 0,
  added_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(playlist_id, track_id)
);

-- Recording sessions table
CREATE TABLE IF NOT EXISTS recording_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
  room TEXT NOT NULL CHECK (room IN ('signal-booth', 'producer-room', 'mix-room')),
  started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  ended_at TIMESTAMP WITH TIME ZONE,
  duration_seconds INTEGER,
  metadata JSONB DEFAULT '{}'::jsonb
);

-- Mints table (NFT minting records)
CREATE TABLE IF NOT EXISTS mints (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  track_id UUID REFERENCES tracks(id) ON DELETE CASCADE,
  user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
  chain TEXT NOT NULL CHECK (chain IN ('xrpl', 'evm', 'dogechain')),
  contract_address TEXT,
  token_id TEXT,
  transaction_hash TEXT,
  metadata_uri TEXT,
  royalty_config JSONB DEFAULT '{}'::jsonb,
  minted_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'minting', 'confirmed', 'failed'))
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_tracks_user_id ON tracks(user_id);
CREATE INDEX IF NOT EXISTS idx_tracks_status ON tracks(status);
CREATE INDEX IF NOT EXISTS idx_projects_user_id ON projects(user_id);
CREATE INDEX IF NOT EXISTS idx_gates_user_id ON gates(user_id);
CREATE INDEX IF NOT EXISTS idx_playlist_tracks_playlist_id ON playlist_tracks(playlist_id);
CREATE INDEX IF NOT EXISTS idx_mints_track_id ON mints(track_id);
CREATE INDEX IF NOT EXISTS idx_mints_user_id ON mints(user_id);

-- Insert default playlists
INSERT INTO playlists (type, name, description) VALUES
  ('genesis', 'Genesis Rotation', 'The original signal. First broadcasts from the 33.3 frequency.'),
  ('labyrinth', 'Labyrinth OST', 'Soundscapes from the NPC Labyrinth. Cipher-guided compositions.'),
  ('redfang', 'Red Fang Sessions', 'DJ Red Fang curated sessions. Premium signal quality.'),
  ('spotlight', 'Artist Spotlight', 'Featured artists from the VSS-33.3 community.')
ON CONFLICT DO NOTHING;
