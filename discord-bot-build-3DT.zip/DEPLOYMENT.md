# WIRED CHAOS META Bot Deployment Guide

## Overview
This project has two parts:
1. **Next.js App** (API + Dashboard) → Deploy to Vercel
2. **Discord Bot** (in `/bot` folder) → Deploy to Railway

---

## Part 1: Deploy Next.js to Vercel (5 minutes)

### Option A: From v0 (Easiest)
1. Click the **"Publish"** button in the top right of v0
2. Follow the prompts to connect GitHub and deploy to Vercel
3. **Copy your deployed URL** (e.g., `https://wc-dicbot.vercel.app`)

### Option B: Manual Deploy
1. Download this project as ZIP from v0
2. Extract and push to a new GitHub repo
3. Go to [vercel.com](https://vercel.com) and click "New Project"
4. Import your GitHub repo
5. Click "Deploy" (no config needed)
6. **Copy your deployed URL**

---

## Part 2: Create Discord Bot (10 minutes)

### Step 1: Discord Developer Portal
1. Go to https://discord.com/developers/applications
2. Click **"New Application"**
   - Name: `WIRED CHAOS META`
   - Click "Create"

### Step 2: Get Your Bot Token
1. Click **"Bot"** in left sidebar
2. Click **"Add Bot"** → Confirm
3. Under "TOKEN", click **"Reset Token"** and copy it
   - ⚠️ Save this somewhere safe - you'll need it later
   - Format: `MTI...` (long string)

### Step 3: Enable Permissions
Still on the Bot page:
1. Scroll to **"Privileged Gateway Intents"**
2. Enable these three:
   - ✅ PRESENCE INTENT
   - ✅ SERVER MEMBERS INTENT
   - ✅ MESSAGE CONTENT INTENT
3. Click **"Save Changes"**

### Step 4: Get Application ID
1. Click **"General Information"** in left sidebar
2. Copy your **APPLICATION ID**
   - Format: `123456789...` (18-20 digit number)

### Step 5: Get Your Server ID
1. Open Discord desktop/web (not mobile)
2. Go to **User Settings** → **Advanced** → Enable **Developer Mode**
3. Right-click your server icon → **"Copy Server ID"**
   - Format: `123456789...` (18-20 digit number)

### Step 6: Invite Bot to Server
1. Back in Developer Portal, click **"OAuth2"** → **"URL Generator"**
2. Select these scopes:
   - ✅ `bot`
   - ✅ `applications.commands`
3. Select these permissions:
   - ✅ Send Messages
   - ✅ Embed Links
   - ✅ Read Message History
   - ✅ Use Slash Commands
4. Copy the generated URL at the bottom
5. Paste it in your browser and invite the bot to your server

---

## Part 3: Deploy Discord Bot to Railway (5 minutes)

### Step 1: Sign Up for Railway
1. Go to https://railway.app
2. Click **"Login"** → Sign in with GitHub
3. Verify your account (you get $5 free credit)

### Step 2: Create New Project
1. Click **"New Project"** → **"Deploy from GitHub repo"**
2. If this is your first time:
   - Click "Configure GitHub App"
   - Give Railway access to your repo
3. Select your `wc-dicbot` repo
4. Railway will try to auto-detect the project

### Step 3: Configure Root Directory
1. Click on your service (should say "Deploying...")
2. Go to **Settings** tab
3. Find **"Root Directory"** and set it to: `/bot`
4. Click **"Save"**

### Step 4: Add Environment Variables
1. Go to **Variables** tab
2. Click **"New Variable"** and add these one by one:

```
DISCORD_TOKEN=YOUR_BOT_TOKEN_FROM_STEP_2
DISCORD_CLIENT_ID=YOUR_APPLICATION_ID_FROM_STEP_4
DISCORD_GUILD_ID=YOUR_SERVER_ID_FROM_STEP_5
API_BASE_URL=https://your-vercel-url.vercel.app
NODE_ENV=production
```

**Replace with your actual values:**
- `DISCORD_TOKEN`: The token from Part 2, Step 2
- `DISCORD_CLIENT_ID`: The application ID from Part 2, Step 4
- `DISCORD_GUILD_ID`: Your server ID from Part 2, Step 5
- `API_BASE_URL`: Your Vercel URL from Part 1 (⚠️ NO trailing slash)

5. Click **"Deploy"** or wait for auto-deploy

### Step 5: Verify Deployment
1. Go to **Deployments** tab
2. Wait for status to show **"SUCCESS"** (2-3 minutes)
3. Click **"View Logs"** to see if bot connected:
   ```
   ✅ Logged in as WIRED CHAOS META
   ✅ Registered slash commands
   ```

---

## Part 4: Test Your Bot (2 minutes)

### In Discord:
1. Go to your server: https://discord.gg/TsuK6wM4h
2. Type `/` and you should see your commands:
   - `/begin`
   - `/set-gen`
   - `/set-neuro`
   - `/set-wallet`
   - `/labyrinth`
   - `/move`
   - `/wl`

### If commands don't appear:
1. Wait 1 hour (Discord caches globally)
2. Or kick the bot and re-invite it
3. Or restart the Railway deployment

### Check the Dashboard:
1. Go to your Vercel URL
2. You should see the admin dashboard
3. After users run commands, they'll appear here

---

## Costs

- **Vercel**: Free (Hobby plan includes unlimited projects)
- **Railway**: $5/month credit (free for first month with trial)
  - Bot uses ~$0.50-2/month depending on activity
- **Total**: Essentially free for low-medium usage

---

## Troubleshooting

### Bot is offline in Discord
- Check Railway logs for errors
- Verify `DISCORD_TOKEN` is correct
- Make sure bot has "MESSAGE CONTENT INTENT" enabled

### Commands not showing up
- Wait 1 hour (Discord caches)
- Kick and re-invite the bot
- Check Railway logs for "Registered slash commands"

### API errors in bot logs
- Verify `API_BASE_URL` has no trailing slash
- Check Vercel deployment is live
- Test API endpoint: `YOUR_VERCEL_URL/api/discord/begin`

### Bot responds but data doesn't save
- Check Railway logs
- Verify API_BASE_URL is correct
- Add Neon database integration for persistent storage

---

## Next Steps

### Add Database (Recommended)
Right now, data is stored in memory and resets on redeploy.

**To add persistent storage:**
1. In v0, ask: "Add Neon database integration"
2. I'll migrate the in-memory store to PostgreSQL
3. Data will persist across restarts

### Add More Commands
- Custom NPC games (Alchemist, Forge, etc.)
- WL boost commands
- 789 CREW auto-tracking
- Agent response customization

---

## Support

If you get stuck:
1. Check Railway logs for errors
2. Check Vercel function logs
3. Ask in v0: "Bot not responding" or "API error in logs"
```

```sh file="" isHidden
