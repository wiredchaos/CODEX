import { sql, type DiscordUser, type WLEntry, type NPCGame, type WLScore } from "@/lib/db"

// ============================================
// DISCORD USERS
// ============================================

export async function getOrCreateUser(discordId: string, username?: string): Promise<DiscordUser> {
  const existing = await sql`
    SELECT * FROM discord_users WHERE discord_id = ${discordId}
  `

  if (existing.length > 0) {
    return existing[0] as DiscordUser
  }

  const created = await sql`
    INSERT INTO discord_users (discord_id, discord_username, onboarding_started_at)
    VALUES (${discordId}, ${username || null}, NOW())
    RETURNING *
  `

  return created[0] as DiscordUser
}

export async function updateUserGeneration(discordId: string, generation: string): Promise<DiscordUser> {
  const updated = await sql`
    UPDATE discord_users 
    SET generation = ${generation}
    WHERE discord_id = ${discordId}
    RETURNING *
  `
  return updated[0] as DiscordUser
}

export async function updateUserNeuroMode(discordId: string, neuroMode: string): Promise<DiscordUser> {
  const updated = await sql`
    UPDATE discord_users 
    SET neuro_mode = ${neuroMode}
    WHERE discord_id = ${discordId}
    RETURNING *
  `
  return updated[0] as DiscordUser
}

export async function updateUserWallet(discordId: string, wallet: string): Promise<DiscordUser> {
  const updated = await sql`
    UPDATE discord_users 
    SET wallet_address = ${wallet}, onboarding_completed_at = NOW()
    WHERE discord_id = ${discordId}
    RETURNING *
  `
  return updated[0] as DiscordUser
}

export async function set789CrewStatus(discordId: string, is789Crew: boolean, role?: string): Promise<DiscordUser> {
  const updated = await sql`
    UPDATE discord_users 
    SET is_789_crew = ${is789Crew}, crew_role = ${role || null}
    WHERE discord_id = ${discordId}
    RETURNING *
  `
  return updated[0] as DiscordUser
}

// ============================================
// WHITELIST LEDGER
// ============================================

export async function logWLPoints(
  discordId: string,
  project: "VRG33589" | "VAULT33",
  points: number,
  source: string,
  reason?: string,
  awardedBy?: string,
  gameId?: string,
): Promise<WLEntry> {
  const entry = await sql`
    INSERT INTO wl_ledger (discord_id, project, points, source, reason, awarded_by, game_id)
    VALUES (${discordId}, ${project}, ${points}, ${source}, ${reason || null}, ${awardedBy || null}, ${gameId || null})
    RETURNING *
  `
  return entry[0] as WLEntry
}

export async function getWLScore(discordId: string): Promise<WLScore | null> {
  const scores = await sql`
    SELECT * FROM wl_scores WHERE discord_id = ${discordId}
  `
  return scores.length > 0 ? (scores[0] as WLScore) : null
}

export async function getLeaderboard(project?: "VRG33589" | "VAULT33", limit = 25): Promise<WLScore[]> {
  if (project) {
    const column = project === "VRG33589" ? "vrg33589_score" : "vault33_score"
    const scores = await sql`
      SELECT * FROM wl_scores 
      ORDER BY ${sql(column)} DESC 
      LIMIT ${limit}
    `
    return scores as WLScore[]
  }

  const scores = await sql`
    SELECT * FROM wl_scores 
    ORDER BY total_score DESC 
    LIMIT ${limit}
  `
  return scores as WLScore[]
}

export async function getWLLedger(discordId: string): Promise<WLEntry[]> {
  const entries = await sql`
    SELECT * FROM wl_ledger 
    WHERE discord_id = ${discordId}
    ORDER BY created_at DESC
  `
  return entries as WLEntry[]
}

// ============================================
// NPC GAMES
// ============================================

export async function createNPCGame(
  discordId: string,
  gameType: NPCGame["game_type"],
  initialState: Record<string, unknown>,
  maxMoves?: number,
  primaryAgent?: string,
): Promise<NPCGame> {
  const game = await sql`
    INSERT INTO npc_games (discord_id, game_type, state, max_moves, primary_agent)
    VALUES (${discordId}, ${gameType}, ${JSON.stringify(initialState)}, ${maxMoves || null}, ${primaryAgent || null})
    RETURNING *
  `
  return game[0] as NPCGame
}

export async function getActiveGame(discordId: string): Promise<NPCGame | null> {
  const games = await sql`
    SELECT * FROM npc_games 
    WHERE discord_id = ${discordId} AND status = 'ACTIVE'
    ORDER BY started_at DESC
    LIMIT 1
  `
  return games.length > 0 ? (games[0] as NPCGame) : null
}

export async function updateGameState(
  gameId: string,
  state: Record<string, unknown>,
  movesMade: number,
): Promise<NPCGame> {
  const game = await sql`
    UPDATE npc_games 
    SET state = ${JSON.stringify(state)}, moves_made = ${movesMade}
    WHERE id = ${gameId}
    RETURNING *
  `
  return game[0] as NPCGame
}

export async function completeGame(
  gameId: string,
  status: "WON" | "LOST" | "ABANDONED",
  wlReward?: number,
  rewardProject?: "VRG33589" | "VAULT33",
): Promise<NPCGame> {
  const game = await sql`
    UPDATE npc_games 
    SET status = ${status}, wl_reward = ${wlReward || 0}, reward_project = ${rewardProject || null}, completed_at = NOW()
    WHERE id = ${gameId}
    RETURNING *
  `
  return game[0] as NPCGame
}

// ============================================
// AGENT ACTIVITY
// ============================================

export async function logAgentActivity(
  agentId: string,
  actionType: string,
  discordId?: string,
  channelId?: string,
  guildId?: string,
  templateKey?: string,
  inputData?: Record<string, unknown>,
  outputData?: Record<string, unknown>,
): Promise<void> {
  await sql`
    INSERT INTO agent_activity (agent_id, action_type, discord_id, channel_id, guild_id, template_key, input_data, output_data)
    VALUES (${agentId}, ${actionType}, ${discordId || null}, ${channelId || null}, ${guildId || null}, ${templateKey || null}, ${JSON.stringify(inputData || {})}, ${JSON.stringify(outputData || {})})
  `
}

export async function getRecentActivity(limit = 50): Promise<unknown[]> {
  const activity = await sql`
    SELECT * FROM agent_activity 
    ORDER BY created_at DESC 
    LIMIT ${limit}
  `
  return activity
}

// ============================================
// SWARM STATE
// ============================================

export async function getSwarmState(discordId: string): Promise<unknown | null> {
  const state = await sql`
    SELECT * FROM swarm_state WHERE discord_id = ${discordId}
  `
  return state.length > 0 ? state[0] : null
}

export async function updateSwarmState(
  discordId: string,
  updates: {
    skill_tree?: Record<string, unknown>
    completed_paths?: string[]
    current_quest?: string
    last_agent?: string
    chaos_score?: number
    ascension_level?: number
  },
): Promise<void> {
  // Upsert pattern
  await sql`
    INSERT INTO swarm_state (discord_id, skill_tree, completed_paths, current_quest, last_agent, chaos_score, ascension_level)
    VALUES (
      ${discordId},
      ${JSON.stringify(updates.skill_tree || {})},
      ${JSON.stringify(updates.completed_paths || [])},
      ${updates.current_quest || null},
      ${updates.last_agent || null},
      ${updates.chaos_score || 0},
      ${updates.ascension_level || 0}
    )
    ON CONFLICT (discord_id) DO UPDATE SET
      skill_tree = COALESCE(${updates.skill_tree ? JSON.stringify(updates.skill_tree) : null}, swarm_state.skill_tree),
      completed_paths = COALESCE(${updates.completed_paths ? JSON.stringify(updates.completed_paths) : null}, swarm_state.completed_paths),
      current_quest = COALESCE(${updates.current_quest || null}, swarm_state.current_quest),
      last_agent = COALESCE(${updates.last_agent || null}, swarm_state.last_agent),
      chaos_score = COALESCE(${updates.chaos_score || null}, swarm_state.chaos_score),
      ascension_level = COALESCE(${updates.ascension_level || null}, swarm_state.ascension_level)
  `
}

// ============================================
// STATS
// ============================================

export async function getDashboardStats(): Promise<{
  totalUsers: number
  onboardedUsers: number
  crew789Count: number
  totalWLPoints: number
  activeGames: number
  gamesCompleted: number
}> {
  const [users, wl, games] = await Promise.all([
    sql`SELECT 
      COUNT(*) as total,
      COUNT(*) FILTER (WHERE onboarding_completed_at IS NOT NULL) as onboarded,
      COUNT(*) FILTER (WHERE is_789_crew = true) as crew789
    FROM discord_users`,
    sql`SELECT COALESCE(SUM(points), 0) as total FROM wl_ledger`,
    sql`SELECT 
      COUNT(*) FILTER (WHERE status = 'ACTIVE') as active,
      COUNT(*) FILTER (WHERE status IN ('WON', 'LOST')) as completed
    FROM npc_games`,
  ])

  return {
    totalUsers: Number(users[0]?.total || 0),
    onboardedUsers: Number(users[0]?.onboarded || 0),
    crew789Count: Number(users[0]?.crew789 || 0),
    totalWLPoints: Number(wl[0]?.total || 0),
    activeGames: Number(games[0]?.active || 0),
    gamesCompleted: Number(games[0]?.completed || 0),
  }
}

export async function getAllUsers(limit = 100): Promise<DiscordUser[]> {
  const users = await sql`
    SELECT * FROM discord_users 
    ORDER BY created_at DESC 
    LIMIT ${limit}
  `
  return users as DiscordUser[]
}
