// In-memory store (replace with database in production)
import type { UserProfile, WLEntry, NPCSession, WLScore, Platform, Project, WLSource } from "./types"

// In-memory storage
const users: Map<string, UserProfile> = new Map()
const wlLedger: WLEntry[] = []
const npcSessions: Map<string, NPCSession> = new Map()

// Generate unique IDs
function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 11)}`
}

// User operations
export function getOrCreateUser(discordId: string): UserProfile {
  const existing = Array.from(users.values()).find((u) => u.discordId === discordId)
  if (existing) return existing

  const user: UserProfile = {
    id: generateId(),
    discordId,
    neuroMode: false,
    is789Crew: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }
  users.set(user.id, user)
  return user
}

export function getUserByDiscordId(discordId: string): UserProfile | null {
  return Array.from(users.values()).find((u) => u.discordId === discordId) ?? null
}

export function updateUserProfile(
  discordId: string,
  updates: Partial<Pick<UserProfile, "generation" | "neuroMode" | "walletAddress" | "is789Crew">>,
): UserProfile | null {
  const user = getUserByDiscordId(discordId)
  if (!user) return null

  const updated = {
    ...user,
    ...updates,
    updatedAt: new Date().toISOString(),
  }
  users.set(user.id, updated)
  return updated
}

export function getAllUsers(): UserProfile[] {
  return Array.from(users.values())
}

// WL Ledger operations
export function logWLEvent(
  userId: string,
  platform: Platform,
  project: Project,
  source: WLSource,
  delta: number,
  meta?: Record<string, unknown>,
): WLEntry {
  const entry: WLEntry = {
    id: generateId(),
    userId,
    platform,
    project,
    source,
    delta,
    timestamp: new Date().toISOString(),
    meta,
  }
  wlLedger.push(entry)
  return entry
}

export function getWLScoreForUser(userId: string): WLScore {
  const userEntries = wlLedger.filter((e) => e.userId === userId)

  const vrg33589 = userEntries.filter((e) => e.project === "VRG33589").reduce((sum, e) => sum + e.delta, 0)

  const vault33 = userEntries.filter((e) => e.project === "VAULT33").reduce((sum, e) => sum + e.delta, 0)

  const lastEntry = userEntries[userEntries.length - 1]

  return {
    userId,
    vrg33589,
    vault33,
    totalMoves: userEntries.length,
    lastActivity: lastEntry?.timestamp ?? "",
  }
}

export function getAllWLEntries(): WLEntry[] {
  return [...wlLedger]
}

export function getLeaderboard(project: Project, limit = 10): Array<{ userId: string; score: number }> {
  const scoreMap = new Map<string, number>()

  for (const entry of wlLedger) {
    if (entry.project !== project) continue
    const current = scoreMap.get(entry.userId) ?? 0
    scoreMap.set(entry.userId, current + entry.delta)
  }

  return Array.from(scoreMap.entries())
    .map(([userId, score]) => ({ userId, score }))
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
}

// NPC Session operations
export function getOrCreateNPCSession(userId: string, game: NPCSession["game"]): NPCSession {
  const key = `${userId}-${game}`
  const existing = npcSessions.get(key)
  if (existing) return existing

  const session: NPCSession = {
    id: generateId(),
    userId,
    game,
    state: {},
    moveCount: 0,
    lastMoveAt: new Date().toISOString(),
    createdAt: new Date().toISOString(),
  }
  npcSessions.set(key, session)
  return session
}

export function updateNPCSession(
  userId: string,
  game: NPCSession["game"],
  stateUpdates: Record<string, unknown>,
): NPCSession | null {
  const key = `${userId}-${game}`
  const session = npcSessions.get(key)
  if (!session) return null

  const updated: NPCSession = {
    ...session,
    state: { ...session.state, ...stateUpdates },
    moveCount: session.moveCount + 1,
    lastMoveAt: new Date().toISOString(),
  }
  npcSessions.set(key, updated)
  return updated
}

export function getNPCSession(userId: string, game: NPCSession["game"]): NPCSession | null {
  return npcSessions.get(`${userId}-${game}`) ?? null
}
