import { neon } from "@neondatabase/serverless"

// Create reusable SQL client
export const sql = neon(process.env.DATABASE_URL!)

// Helper types
export interface DiscordUser {
  id: string
  discord_id: string
  discord_username: string | null
  generation: "GEN1" | "GEN2" | "GEN3" | null
  neuro_mode: "STANDARD" | "CHAOS" | "ASCEND" | null
  wallet_address: string | null
  is_789_crew: boolean
  onboarding_completed_at: Date | null
  created_at: Date
}

export interface WLEntry {
  id: string
  discord_id: string
  project: "VRG33589" | "VAULT33"
  points: number
  source: string
  reason: string | null
  created_at: Date
}

export interface NPCGame {
  id: string
  discord_id: string
  game_type: "LABYRINTH" | "ALCHEMIST" | "FORGE" | "TRIAGE" | "MULTIVERSE" | "SEQUENCE"
  status: "ACTIVE" | "WON" | "LOST" | "ABANDONED"
  state: Record<string, unknown>
  moves_made: number
  started_at: Date
}

export interface WLScore {
  discord_id: string
  discord_username: string | null
  vrg33589_score: number
  vault33_score: number
  total_score: number
  games_won: number
}
