// TRINITY CONSUMER MODULE
// This module declares and enforces read-only consumer relationship with Trinity 3D Core

import { getPatchConfigSafe } from "./patches"
import type { TrinityMount } from "./patches"

/**
 * Validates that a patch request respects Trinity consumer boundaries
 * Returns the Trinity mount configuration if valid, throws if attempting to mutate
 */
export function validateTrinityAccess(
  patchId: string,
  requestedFloor?: string,
  requestedTimeline?: string,
): TrinityMount | null {
  const patch = getPatchConfigSafe(patchId)
  if (!patch?.trinityMount) {
    // This patch doesn't mount to Trinity - allowed
    return null
  }

  const mount = patch.trinityMount

  // Enforce read-only access
  if (mount.accessLevel !== "read-only" && mount.accessLevel !== "observer") {
    throw new Error(`[Trinity] Patch ${patchId} attempted non-consumer access. Trinity is read-only infrastructure.`)
  }

  // Validate floor assignment
  if (requestedFloor && requestedFloor !== mount.trinityFloor) {
    throw new Error(
      `[Trinity] Patch ${patchId} attempted to access floor ${requestedFloor}, but is mounted to ${mount.trinityFloor}`,
    )
  }

  // Validate timeline access (governed by Akira Codex if specified)
  if (requestedTimeline && requestedTimeline !== mount.timeline) {
    if (mount.governedBy === "akira-codex") {
      throw new Error(
        `[Trinity] Timeline access for ${patchId} is governed by Akira Codex. Requested ${requestedTimeline}, assigned ${mount.timeline || "none"}`,
      )
    }
    throw new Error(
      `[Trinity] Patch ${patchId} attempted to access timeline ${requestedTimeline}, but is assigned ${mount.timeline || "none"}`,
    )
  }

  return mount
}

/**
 * Enforces that no patch can create or modify Trinity infrastructure
 * This patch CONSUMES Trinity, never OWNS it
 */
export function preventTrinityMutation(operation: string): never {
  throw new Error(
    `[Trinity] Operation "${operation}" blocked. This patch is a CONSUMER of Trinity 3D Core. No creation, no modification. Trinity is read-only infrastructure.`,
  )
}

/**
 * Gets the Trinity mount info for a patch
 */
export function getTrinityMount(patchId: string): TrinityMount | null {
  const patch = getPatchConfigSafe(patchId)
  return patch?.trinityMount ?? null
}
