// NEURO SWARM API Schema Types

export interface TickerItem {
  id: string
  label: string
  project: "VRG33589" | "VAULT33"
  delta: number
  source: string
  platform: "discord" | "telegram" | "web"
  createdAt: string
}

export interface HealthStatus {
  npcSessionsToday: number
  xpEventsToday: number
  status: "ok" | "degraded" | "offline"
  swarmAgentsOnline: number
  uptime: string
}

export interface NpcMoveRequest {
  userId: string
  platform: "discord" | "telegram" | "web"
  prompt: string
  source: string
}

export interface NpcMoveResponse {
  narrative: string
  wlDelta: number
  project: "VRG33589" | "VAULT33"
  agentId: string
}

export interface WlLogRequest {
  userId: string
  platform: "discord" | "telegram" | "web"
  project: "VRG33589" | "VAULT33"
  source: string
  delta: number
  meta?: Record<string, unknown>
}

export interface SwarmEventRequest {
  agentId: string
  eventType: string
  patchId?: string // e.g. "creator-codex", "worldbuild-neteru"
  worldKey?: string // e.g. "AkiraCodex:Book1", "Neteru:Apinaya"
  payload: Record<string, unknown>
  trinityContext?: {
    floor: string // Which Trinity floor this event is mounted to
    timeline?: string // Which timeline (if any) this event references
    readOnly: true // Always true - this patch is consumer-only
  }
}

export interface SwarmEventResponse {
  ok: boolean
  patchId: string
  worldKey: string
  agentId: string
  eventType: string
  timestamp: string
  result?: Record<string, unknown>
  error?: string
  trinityMount?: {
    floor: string
    timeline?: string
    accessGranted: boolean
  }
}
