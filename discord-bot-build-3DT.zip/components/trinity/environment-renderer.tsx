"use client"

import { useEffect, useState } from "react"
import { validateTrinityAccess, getTrinityMount } from "@/lib/swarm/trinity-consumer"

interface EnvironmentRendererProps {
  patchId: string
  kind: "lobby" | "timeline" | "elevator" | "floor"
  fallbackVideo?: string
  className?: string
}

/**
 * TRINITY ENVIRONMENT RENDERER (CONSUMER)
 *
 * This component mounts to the existing WIRED CHAOS Trinity 3D Core.
 * - Read-only access
 * - No scene generation
 * - No timeline forking
 * - Respects Akira Codex gating
 *
 * Renders cinematic environment with video fallback.
 */
export function EnvironmentRenderer({ patchId, kind, fallbackVideo, className = "" }: EnvironmentRendererProps) {
  const [mount, setMount] = useState<ReturnType<typeof getTrinityMount>>(null)
  const [error, setError] = useState<string | null>(null)
  const [useFallback, setUseFallback] = useState(false)

  useEffect(() => {
    try {
      // Validate Trinity access
      const mountConfig = getTrinityMount(patchId)

      if (!mountConfig) {
        setError(`Patch ${patchId} not configured for Trinity mount`)
        setUseFallback(true)
        return
      }

      // Validate consumer access (read-only enforcement)
      validateTrinityAccess(patchId)
      setMount(mountConfig)

      // Check if Trinity Core is available (placeholder - would integrate with actual Trinity system)
      const trinityAvailable = false // TODO: Check Trinity Core availability

      if (!trinityAvailable) {
        console.log(`[Trinity Consumer] Core unavailable, using fallback for ${patchId}`)
        setUseFallback(true)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Trinity access error")
      setUseFallback(true)
    }
  }, [patchId])

  // Video fallback renderer
  if (useFallback) {
    return (
      <div className={`relative w-full h-full overflow-hidden bg-black ${className}`}>
        {fallbackVideo ? (
          <video autoPlay loop muted playsInline className="w-full h-full object-cover">
            <source src={fallbackVideo} type="video/mp4" />
          </video>
        ) : (
          <div className="w-full h-full bg-gradient-to-b from-black via-primary/10 to-black flex items-center justify-center">
            <div className="text-center space-y-4 p-8">
              <div className="text-4xl font-bold text-primary font-mono">{patchId.toUpperCase()}</div>
              <div className="text-muted-foreground font-mono text-sm">
                {mount ? `FLOOR ${mount.trinityFloor}` : "ENVIRONMENT"}
              </div>
              {mount?.timeline && (
                <div className="text-xs text-muted-foreground/60 font-mono">TIMELINE: {mount.timeline}</div>
              )}
              {error && <div className="text-xs text-destructive/80 font-mono max-w-md">{error}</div>}
            </div>
          </div>
        )}

        {/* HUD Overlay - supplied by Trinity Core */}
        <div className="absolute top-4 left-4 right-4 flex justify-between items-start pointer-events-none">
          <div className="bg-black/60 backdrop-blur-sm px-3 py-2 rounded border border-primary/20">
            <div className="text-xs font-mono text-primary">
              {mount ? `TRINITY FLOOR ${mount.trinityFloor}` : "STANDALONE"}
            </div>
          </div>

          {mount?.accessLevel && (
            <div className="bg-black/60 backdrop-blur-sm px-3 py-2 rounded border border-green-500/20">
              <div className="text-xs font-mono text-green-400">READ-ONLY</div>
            </div>
          )}
        </div>

        {/* Hotspot indicators - supplied by Trinity Core */}
        {mount && kind === "lobby" && (
          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-4">
            <div className="bg-black/80 backdrop-blur-sm px-4 py-2 rounded-full border border-primary/40 text-xs font-mono text-primary">
              HOTSPOT: ELEVATOR
            </div>
            <div className="bg-black/80 backdrop-blur-sm px-4 py-2 rounded-full border border-primary/40 text-xs font-mono text-primary">
              HOTSPOT: TIMELINE
            </div>
          </div>
        )}
      </div>
    )
  }

  // Trinity 3D Core renderer (placeholder - would integrate with actual Trinity system)
  return (
    <div className={`relative w-full h-full ${className}`}>
      <div className="w-full h-full flex items-center justify-center bg-black">
        <div className="text-center space-y-2">
          <div className="text-sm font-mono text-muted-foreground">TRINITY CORE MOUNT POINT</div>
          <div className="text-xs font-mono text-muted-foreground/60">Awaiting Trinity 3D Core integration</div>
        </div>
      </div>
    </div>
  )
}
