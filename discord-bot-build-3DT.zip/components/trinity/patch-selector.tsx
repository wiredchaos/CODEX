"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { getAllPatches } from "@/lib/swarm/patches"

export function PatchSelector() {
  const router = useRouter()
  const patches = getAllPatches()
  const [selectedPatch, setSelectedPatch] = useState<string | null>(null)

  const handleEnterEnvironment = (patchId: string) => {
    router.push(`/environment/${patchId}`)
  }

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold">TRINITY ENVIRONMENT ACCESS</h2>
        <p className="text-muted-foreground text-sm">Select a patch to enter its mounted Trinity environment</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {patches.map((patch) => (
          <Card
            key={patch.id}
            className={`bg-black/40 border-primary/20 hover:border-primary/40 transition-all cursor-pointer ${
              selectedPatch === patch.id ? "border-primary ring-2 ring-primary/20" : ""
            }`}
            onClick={() => setSelectedPatch(patch.id)}
          >
            <CardHeader>
              <CardTitle className="text-lg">{patch.label}</CardTitle>
              <CardDescription className="text-xs">{patch.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {/* Trinity mount info */}
              {patch.trinityMount ? (
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-xs">
                      FLOOR {patch.trinityMount.trinityFloor}
                    </Badge>
                    {patch.trinityMount.timeline && (
                      <Badge variant="outline" className="text-xs">
                        {patch.trinityMount.timeline}
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <div className="w-2 h-2 rounded-full bg-green-500" />
                    <span>READ-ONLY</span>
                  </div>
                </div>
              ) : (
                <Badge variant="secondary" className="text-xs">
                  STANDALONE
                </Badge>
              )}

              <Button
                size="sm"
                className="w-full"
                variant={selectedPatch === patch.id ? "default" : "outline"}
                onClick={(e) => {
                  e.stopPropagation()
                  handleEnterEnvironment(patch.id)
                }}
              >
                Enter Environment
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
