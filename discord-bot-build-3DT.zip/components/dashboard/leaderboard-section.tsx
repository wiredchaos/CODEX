"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Trophy, Crown, Medal, Award } from "lucide-react"

interface LeaderboardEntry {
  rank: number
  discordId: string
  username: string | null
  vrg33589: number
  vault33: number
  total: number
  gamesWon: number
}

export function LeaderboardSection() {
  const [vrg33589, setVrg33589] = useState<LeaderboardEntry[]>([])
  const [vault33, setVault33] = useState<LeaderboardEntry[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchLeaderboards() {
      try {
        const [vrgRes, vaultRes] = await Promise.all([
          fetch("/api/wl/leaderboard?project=VRG33589&limit=10"),
          fetch("/api/wl/leaderboard?project=VAULT33&limit=10"),
        ])

        const vrgData = await vrgRes.json()
        const vaultData = await vaultRes.json()

        setVrg33589(vrgData.leaderboard || [])
        setVault33(vaultData.leaderboard || [])
      } catch (error) {
        console.error("Failed to fetch leaderboards:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchLeaderboards()
  }, [])

  return (
    <Card className="border-border/50">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-foreground">
          <Trophy className="h-5 w-5 text-accent" />
          WL Leaderboards
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="vault33">
          <TabsList className="grid w-full grid-cols-2 bg-muted/50">
            <TabsTrigger value="vault33" className="data-[state=active]:bg-chart-2/20 data-[state=active]:text-chart-2">
              VAULT33
            </TabsTrigger>
            <TabsTrigger
              value="vrg33589"
              className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary"
            >
              VRG33589
            </TabsTrigger>
          </TabsList>

          <TabsContent value="vault33" className="mt-4">
            <LeaderboardTable entries={vault33} loading={loading} project="VAULT33" />
          </TabsContent>

          <TabsContent value="vrg33589" className="mt-4">
            <LeaderboardTable entries={vrg33589} loading={loading} project="VRG33589" />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

function LeaderboardTable({
  entries,
  loading,
  project,
}: {
  entries: LeaderboardEntry[]
  loading: boolean
  project: string
}) {
  if (loading) {
    return (
      <div className="space-y-2">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="h-12 animate-pulse bg-muted rounded" />
        ))}
      </div>
    )
  }

  if (entries.length === 0) {
    return <p className="text-center text-muted-foreground py-8">No entries yet</p>
  }

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Crown className="h-4 w-4 text-accent" />
    if (rank === 2) return <Medal className="h-4 w-4 text-muted-foreground" />
    if (rank === 3) return <Award className="h-4 w-4 text-chart-3" />
    return null
  }

  const scoreKey = project === "VRG33589" ? "vrg33589" : "vault33"

  return (
    <div className="space-y-2">
      {entries.map((entry) => (
        <div
          key={entry.discordId}
          className={`flex items-center justify-between rounded-lg border p-3 transition-colors ${
            entry.rank === 1
              ? "border-accent/30 bg-accent/5"
              : entry.rank <= 3
                ? "border-border/50 bg-muted/30"
                : "border-border/30 bg-card"
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center">
              {getRankIcon(entry.rank) || (
                <span className="text-sm font-medium text-muted-foreground">{entry.rank}</span>
              )}
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">
                {entry.username || `${entry.discordId.slice(0, 8)}...`}
              </p>
              {entry.gamesWon > 0 && <p className="text-xs text-muted-foreground">{entry.gamesWon} games won</p>}
            </div>
          </div>
          <span className={`text-lg font-bold ${project === "VRG33589" ? "text-primary" : "text-chart-2"}`}>
            {entry[scoreKey as keyof LeaderboardEntry]}
          </span>
        </div>
      ))}
    </div>
  )
}
