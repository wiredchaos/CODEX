"use client"

import { useEffect, useState } from "react"
import { Badge } from "@/components/ui/badge"
import type { TickerItem } from "@/lib/swarm/schema"

export function Ticker() {
  const [items, setItems] = useState<TickerItem[]>([])
  const [isPaused, setIsPaused] = useState(false)

  useEffect(() => {
    async function fetchTicker() {
      try {
        const res = await fetch("/api/ticker?limit=20")
        const data = await res.json()
        setItems(data.items || [])
      } catch (error) {
        console.error("Failed to fetch ticker:", error)
      }
    }

    fetchTicker()
    const interval = setInterval(fetchTicker, 10000)
    return () => clearInterval(interval)
  }, [])

  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr)
    return date.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })
  }

  return (
    <div
      className="relative overflow-hidden bg-black/40 border border-primary/20 rounded-lg p-4"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      <div className="flex items-center gap-2 mb-3">
        <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
        <span className="text-xs font-mono text-muted-foreground uppercase tracking-wider">Live WL Ticker</span>
      </div>

      <div className="relative h-48 overflow-hidden">
        <div
          className={`flex flex-col gap-2 ${!isPaused ? "animate-ticker" : ""}`}
          style={{
            animation: isPaused ? "none" : "ticker 20s linear infinite",
          }}
        >
          {[...items, ...items].map((item, idx) => (
            <div
              key={`${item.id}-${idx}`}
              className="flex items-center justify-between p-2 bg-black/30 rounded border border-primary/10"
            >
              <div className="flex items-center gap-3">
                <Badge
                  variant="outline"
                  className={
                    item.project === "VRG33589"
                      ? "border-cyan-500/50 text-cyan-400"
                      : "border-amber-500/50 text-amber-400"
                  }
                >
                  {item.project}
                </Badge>
                <span className="text-green-400 font-mono font-bold">+{item.delta}</span>
                <span className="text-xs text-muted-foreground">{item.source.replace(/_/g, " ")}</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-xs">
                  {item.platform}
                </Badge>
                <span className="text-xs text-muted-foreground font-mono">{formatTime(item.createdAt)}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <style jsx>{`
        @keyframes ticker {
          0% { transform: translateY(0); }
          100% { transform: translateY(-50%); }
        }
      `}</style>
    </div>
  )
}
