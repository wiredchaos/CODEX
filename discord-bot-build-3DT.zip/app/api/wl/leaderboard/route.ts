// WL Leaderboard endpoint - upgraded to use Neon DB
import { type NextRequest, NextResponse } from "next/server"
import { getLeaderboard } from "@/lib/neuro/db-store"

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const project = searchParams.get("project") as "VRG33589" | "VAULT33" | null
    const limit = Number.parseInt(searchParams.get("limit") || "25", 10)

    const leaderboard = await getLeaderboard(project || undefined, Math.min(limit, 100))

    return NextResponse.json({
      ok: true,
      project: project || "ALL",
      count: leaderboard.length,
      leaderboard: leaderboard.map((entry, index) => ({
        rank: index + 1,
        discordId: entry.discord_id,
        username: entry.discord_username,
        vrg33589: entry.vrg33589_score,
        vault33: entry.vault33_score,
        total: entry.total_score,
        gamesWon: entry.games_won,
      })),
    })
  } catch (error) {
    console.error("[LEADERBOARD] Error:", error)
    return NextResponse.json({ error: "Internal error" }, { status: 500 })
  }
}
