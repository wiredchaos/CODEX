// List all available SWARM patches
import { NextResponse } from "next/server"
import { getAllPatches } from "@/lib/swarm/patches"

export async function GET() {
  const patches = getAllPatches()

  return NextResponse.json({
    patches,
    count: patches.length,
    timestamp: new Date().toISOString(),
  })
}
