// Get swarm status for a user
import { type NextRequest, NextResponse } from "next/server"
import { getProgressSummary, loadSwarmContext } from "@/lib/neuro/swarm-engine"

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const discordId = searchParams.get("discordId")

    if (!discordId) {
      return NextResponse.json({ error: "discordId required" }, { status: 400 })
    }

    const [context, progress] = await Promise.all([loadSwarmContext(discordId), getProgressSummary(discordId)])

    return NextResponse.json({
      ok: true,
      discordId,
      context: {
        chaos_score: context.chaos_score,
        ascension_level: context.ascension_level,
        last_agent: context.last_agent,
      },
      progress,
    })
  } catch (error) {
    console.error("[SWARM_STATUS] Error:", error)
    return NextResponse.json({ error: "Internal error" }, { status: 500 })
  }
}
