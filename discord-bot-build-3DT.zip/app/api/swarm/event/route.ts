// Process a swarm event - patch-aware for Creator Codex, World Build, etc.
import { type NextRequest, NextResponse } from "next/server"
import { processSwarmEvent } from "@/lib/neuro/swarm-engine"
import { getPatchConfigSafe } from "@/lib/swarm/patches"
import { validateTrinityAccess } from "@/lib/swarm/trinity-consumer"
import type { SwarmEventRequest, SwarmEventResponse } from "@/lib/swarm/schema"

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as SwarmEventRequest
    const {
      agentId,
      eventType,
      patchId = "worldbuild-generic",
      worldKey = "default",
      payload = {},
      trinityContext,
    } = body

    // Validate required fields
    if (!agentId || !eventType) {
      return NextResponse.json({ ok: false, error: "agentId and eventType are required" }, { status: 400 })
    }

    // Get patch config (if valid)
    const patchConfig = getPatchConfigSafe(patchId)

    let trinityMount = null
    try {
      if (trinityContext || patchConfig?.trinityMount) {
        trinityMount = validateTrinityAccess(patchId, trinityContext?.floor, trinityContext?.timeline)
      }
    } catch (trinityError) {
      console.error("[TRINITY_VIOLATION]", trinityError)
      return NextResponse.json(
        {
          ok: false,
          error: trinityError instanceof Error ? trinityError.message : "Trinity access violation",
        },
        { status: 403 },
      )
    }

    // Log the event with patch context
    console.log("[SWARM_EVENT]", {
      agentId,
      eventType,
      patchId,
      worldKey,
      patchLabel: patchConfig?.label ?? "Unknown Patch",
      defaultProject: patchConfig?.defaultProject ?? "VRG33589",
      trinityFloor: trinityMount?.trinityFloor,
      trinityTimeline: trinityMount?.timeline,
    })

    // Extract discordId from payload if present (for backward compatibility)
    const discordId = (payload.userId as string) ?? (payload.discordId as string) ?? "system"

    // Process through swarm engine with extended event data
    const result = await processSwarmEvent(discordId, eventType, {
      ...payload,
      patchId,
      worldKey,
      agentId,
      patchConfig: patchConfig ?? undefined,
      trinityMount: trinityMount ?? undefined,
    })

    const response: SwarmEventResponse = {
      ok: true,
      patchId,
      worldKey,
      agentId,
      eventType,
      timestamp: new Date().toISOString(),
      result,
      trinityMount: trinityMount
        ? {
            floor: trinityMount.trinityFloor,
            timeline: trinityMount.timeline,
            accessGranted: true,
          }
        : undefined,
    }

    return NextResponse.json(response)
  } catch (error) {
    console.error("[SWARM_EVENT] Error:", error)
    return NextResponse.json({ ok: false, error: "Internal error" }, { status: 500 })
  }
}

// GET endpoint to list available patches
export async function GET() {
  const { getAllPatches } = await import("@/lib/swarm/patches")
  return NextResponse.json({
    patches: getAllPatches(),
    timestamp: new Date().toISOString(),
  })
}
