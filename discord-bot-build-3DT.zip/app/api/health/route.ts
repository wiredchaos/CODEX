import { NextResponse } from "next/server"
import { sql } from "@/lib/db"
import type { HealthStatus } from "@/lib/swarm/schema"

export async function GET() {
  const startTime = Date.now()

  try {
    // Get today's NPC sessions
    const sessionsResult = await sql`
      SELECT COUNT(*) as count 
      FROM npc_games 
      WHERE created_at >= CURRENT_DATE
    `

    // Get today's WL events
    const eventsResult = await sql`
      SELECT COUNT(*) as count 
      FROM wl_ledger 
      WHERE created_at >= CURRENT_DATE
    `

    const health: HealthStatus = {
      npcSessionsToday: Number.parseInt(sessionsResult[0]?.count || "0"),
      xpEventsToday: Number.parseInt(eventsResult[0]?.count || "0"),
      status: "ok",
      swarmAgentsOnline: 7,
      uptime: `${Date.now() - startTime}ms`,
    }

    return NextResponse.json(health)
  } catch (error) {
    console.error("[Health] Error:", error)
    // Return degraded status with mock data
    return NextResponse.json({
      npcSessionsToday: 0,
      xpEventsToday: 0,
      status: "degraded",
      swarmAgentsOnline: 7,
      uptime: "0ms",
    } satisfies HealthStatus)
  }
}
