// NPC Game move handler - upgraded to use Neon DB
import { type NextRequest, NextResponse } from "next/server"
import {
  getOrCreateUser,
  getActiveGame,
  updateGameState,
  completeGame,
  logWLPoints,
  logAgentActivity,
} from "@/lib/neuro/db-store"
import { getReply } from "@/lib/neuro/router"

// Simple narrative generator (replace with AI in production)
function generateNarrative(prompt: string, moveCount: number, gameType: string): string {
  const narratives: Record<string, string[]> = {
    LABYRINTH: [
      `You push forward with: "${prompt}".\nThe corridor hums with a low, distant frequency. Something shifts in the shadows ahead.`,
      `Your signal echoes through the labyrinth: "${prompt}".\nWalls rearrange themselves. A new path reveals itself.`,
      `The Labyrinth processes your intent: "${prompt}".\nReality bends slightly. You sense you're closer to something important.`,
    ],
    ALCHEMIST: [
      `You combine the elements with intent: "${prompt}".\nThe mixture bubbles and glows with an otherworldly light.`,
      `Your alchemical formula takes shape: "${prompt}".\nSomething transformative is occurring at the molecular level.`,
    ],
    FORGE: [
      `You strike the metal with purpose: "${prompt}".\nSparks fly as the material begins to take form.`,
      `The forge responds to your command: "${prompt}".\nHeat and pressure combine to create something new.`,
    ],
    DEFAULT: [`Move acknowledged: "${prompt}".\nThe system processes your input. Something changes.`],
  }

  const pool = narratives[gameType] || narratives.DEFAULT
  return pool[moveCount % pool.length]
}

// Calculate WL reward based on prompt quality and game progress
function calculateWLReward(prompt: string, moveCount: number): { points: number; project: "VRG33589" | "VAULT33" } {
  const baseReward = 5
  const lengthBonus = Math.min(Math.floor(prompt.length / 20), 5)
  const moveBonus = Math.min(Math.floor(moveCount / 3), 10)

  // Alternate between projects based on move count
  const project = moveCount % 2 === 0 ? "VRG33589" : "VAULT33"

  return {
    points: baseReward + lengthBonus + moveBonus,
    project,
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { discordId, prompt } = body as {
      discordId: string
      prompt: string
    }

    if (!discordId) {
      return NextResponse.json({ error: "discordId required" }, { status: 400 })
    }

    if (!prompt || prompt.trim().length === 0) {
      return NextResponse.json(
        {
          error: "Prompt required. Send your move as text.",
        },
        { status: 400 },
      )
    }

    // Ensure user exists
    await getOrCreateUser(discordId)

    // Get active game
    const game = await getActiveGame(discordId)
    if (!game) {
      return NextResponse.json(
        {
          error: "No active game. Start one with /labyrinth or /npc",
        },
        { status: 404 },
      )
    }

    const newMoveCount = game.moves_made + 1
    const state = game.state as { history?: string[]; currentRoom?: string }

    // Update game state
    const updatedState = {
      ...state,
      history: [...(state.history || []), prompt].slice(-10),
      lastMove: prompt,
    }

    await updateGameState(game.id, updatedState, newMoveCount)

    // Generate narrative
    const narrative = generateNarrative(prompt, newMoveCount, game.game_type)

    // Calculate and award WL
    const reward = calculateWLReward(prompt, newMoveCount)
    await logWLPoints(
      discordId,
      reward.project,
      reward.points,
      "NPC_GAME",
      `${game.game_type} move #${newMoveCount}`,
      "GRYMM",
      game.id,
    )

    // Log agent activity
    await logAgentActivity("META_X", "GAME_MOVE", discordId, undefined, undefined, "npcMove", {
      gameId: game.id,
      moveCount: newMoveCount,
      prompt: prompt.slice(0, 100),
    })

    // Check for game completion
    let gameComplete = false
    let finalMessage = ""

    if (game.max_moves && newMoveCount >= game.max_moves) {
      gameComplete = true
      const bonusWL = 50
      await completeGame(game.id, "WON", bonusWL, "VAULT33")
      await logWLPoints(discordId, "VAULT33", bonusWL, "NPC_WIN", `Completed ${game.game_type}`, "GRYMM", game.id)
      finalMessage = getReply("GRYMM", "gameComplete", { game: game.game_type, bonus: bonusWL })
    }

    // Get ledger note
    const ledgerNote = getReply("GRYMM", "npcMoveNote", {
      delta: reward.points,
      projects: reward.project,
    })

    return NextResponse.json({
      ok: true,
      narrative,
      wlAwarded: {
        points: reward.points,
        project: reward.project,
      },
      ledgerNote,
      session: {
        id: game.id,
        game: game.game_type,
        moveCount: newMoveCount,
        maxMoves: game.max_moves,
      },
      gameComplete,
      finalMessage: gameComplete ? finalMessage : undefined,
    })
  } catch (error) {
    console.error("[NPC_MOVE] Error:", error)
    return NextResponse.json({ error: "Internal error" }, { status: 500 })
  }
}
