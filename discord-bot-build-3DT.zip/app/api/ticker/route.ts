import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import type { TickerItem } from "@/lib/swarm/schema"

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const project = searchParams.get("project")
  const platform = searchParams.get("platform")
  const limit = Number.parseInt(searchParams.get("limit") || "20")

  try {
    let result

    if (project && platform) {
      result = await sql`
        SELECT 
          id,
          discord_id as user_id,
          project,
          points as delta,
          source,
          'discord' as platform,
          created_at
        FROM wl_ledger
        WHERE project = ${project} AND source LIKE ${"%" + platform + "%"}
        ORDER BY created_at DESC 
        LIMIT ${limit}
      `
    } else if (project) {
      result = await sql`
        SELECT 
          id,
          discord_id as user_id,
          project,
          points as delta,
          source,
          'discord' as platform,
          created_at
        FROM wl_ledger
        WHERE project = ${project}
        ORDER BY created_at DESC 
        LIMIT ${limit}
      `
    } else if (platform) {
      result = await sql`
        SELECT 
          id,
          discord_id as user_id,
          project,
          points as delta,
          source,
          'discord' as platform,
          created_at
        FROM wl_ledger
        WHERE source LIKE ${"%" + platform + "%"}
        ORDER BY created_at DESC 
        LIMIT ${limit}
      `
    } else {
      result = await sql`
        SELECT 
          id,
          discord_id as user_id,
          project,
          points as delta,
          source,
          'discord' as platform,
          created_at
        FROM wl_ledger
        ORDER BY created_at DESC 
        LIMIT ${limit}
      `
    }

    const items: TickerItem[] = result.map((row: Record<string, unknown>) => ({
      id: row.id as string,
      label: `+${row.delta} WL`,
      project: row.project as "VRG33589" | "VAULT33",
      delta: row.delta as number,
      source: row.source as string,
      platform: (row.platform as "discord" | "telegram" | "web") || "discord",
      createdAt: (row.created_at as Date).toISOString(),
    }))

    return NextResponse.json({ items })
  } catch (error) {
    console.error("[Ticker] Error:", error)
    // Return mock data if DB not ready
    const mockItems: TickerItem[] = [
      {
        id: "1",
        label: "+5 WL",
        project: "VRG33589",
        delta: 5,
        source: "NPC_LABYRINTH",
        platform: "discord",
        createdAt: new Date().toISOString(),
      },
      {
        id: "2",
        label: "+3 WL",
        project: "VAULT33",
        delta: 3,
        source: "NPC_FORGE",
        platform: "discord",
        createdAt: new Date().toISOString(),
      },
      {
        id: "3",
        label: "+10 WL",
        project: "VRG33589",
        delta: 10,
        source: "789_CREW_AUTO",
        platform: "discord",
        createdAt: new Date().toISOString(),
      },
      {
        id: "4",
        label: "+5 WL",
        project: "VAULT33",
        delta: 5,
        source: "NPC_ALCHEMIST",
        platform: "telegram",
        createdAt: new Date().toISOString(),
      },
      {
        id: "5",
        label: "+7 WL",
        project: "VRG33589",
        delta: 7,
        source: "NPC_SEQUENCE",
        platform: "web",
        createdAt: new Date().toISOString(),
      },
      {
        id: "6",
        label: "+2 WL",
        project: "VAULT33",
        delta: 2,
        source: "ONBOARDING",
        platform: "discord",
        createdAt: new Date().toISOString(),
      },
    ]
    return NextResponse.json({ items: mockItems })
  }
}
