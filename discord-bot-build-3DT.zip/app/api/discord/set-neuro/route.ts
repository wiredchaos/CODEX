// /set-neuro command handler - upgraded to use Neon DB
import { type NextRequest, NextResponse } from "next/server"
import { getOrCreateUser, updateUserNeuroMode, logAgentActivity } from "@/lib/neuro/db-store"

const VALID_MODES = ["STANDARD", "CHAOS", "ASCEND"] as const

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { discordId, mode } = body as {
      discordId: string
      mode: string
    }

    if (!discordId) {
      return NextResponse.json({ error: "discordId required" }, { status: 400 })
    }

    const neuroMode = mode?.toUpperCase() || "STANDARD"
    if (!VALID_MODES.includes(neuroMode as (typeof VALID_MODES)[number])) {
      return NextResponse.json(
        {
          error: "Invalid mode",
          valid: VALID_MODES,
        },
        { status: 400 },
      )
    }

    // Ensure user exists
    await getOrCreateUser(discordId)

    // Update neuro mode
    const updated = await updateUserNeuroMode(discordId, neuroMode)

    // Log activity
    await logAgentActivity("NEUROLUX", "SET_NEURO_MODE", discordId, undefined, undefined, "setNeuro", {
      mode: neuroMode,
    })

    const messages: Record<string, string> = {
      STANDARD: "NEURO MODE set to **STANDARD**. Balanced guidance throughout your journey.",
      CHAOS: "NEURO MODE set to **CHAOS**. Embrace the entropy. Expect the unexpected.",
      ASCEND: "NEURO MODE set to **ASCEND**. Higher frequency guidance activated.",
    }

    return NextResponse.json({
      ok: true,
      message: messages[neuroMode],
      user: {
        discordId: updated.discord_id,
        neuroMode: updated.neuro_mode,
      },
    })
  } catch (error) {
    console.error("[SET-NEURO] Error:", error)
    return NextResponse.json({ error: "Internal error" }, { status: 500 })
  }
}
