import { type NextRequest, NextResponse } from "next/server"
import { validateTrinityAccess, getTrinityMount } from "@/lib/swarm/trinity-consumer"
import { getPatchConfigSafe } from "@/lib/swarm/patches"

/**
 * GET /api/trinity/mount?patchId=X
 * Returns Trinity mount configuration for a patch
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const patchId = searchParams.get("patchId")

    if (!patchId) {
      return NextResponse.json({ error: "patchId required" }, { status: 400 })
    }

    const mount = getTrinityMount(patchId)

    if (!mount) {
      return NextResponse.json(
        {
          error: `Patch ${patchId} is not configured for Trinity mount`,
          standalone: true,
        },
        { status: 404 },
      )
    }

    // Validate access (throws if invalid)
    validateTrinityAccess(patchId)

    const patch = getPatchConfigSafe(patchId)

    return NextResponse.json({
      patchId,
      patchLabel: patch?.label || patchId,
      mount: {
        trinityFloor: mount.trinityFloor,
        timeline: mount.timeline || null,
        accessLevel: mount.accessLevel,
        governedBy: mount.governedBy || null,
      },
      status: "mounted",
      readonly: true,
    })
  } catch (error) {
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : "Trinity mount validation failed",
      },
      { status: 403 },
    )
  }
}
