import { PatchSelector } from "@/components/trinity/patch-selector"

export default function EnvironmentIndexPage() {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-primary/20 bg-black/40">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold tracking-tight">
            <span className="text-primary">TRINITY</span>
            <span className="text-muted-foreground"> × </span>
            <span className="text-foreground">WIRED CHAOS META</span>
          </h1>
          <p className="text-sm text-muted-foreground font-mono mt-2">
            Consumer mount to Trinity 3D Core • Read-only access • Akira Codex governance
          </p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <PatchSelector />
      </main>
    </div>
  )
}
