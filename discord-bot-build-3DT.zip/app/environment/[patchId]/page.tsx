import { EnvironmentRenderer } from "@/components/trinity/environment-renderer"
import { getPatchConfigSafe } from "@/lib/swarm/patches"
import { notFound } from "next/navigation"

interface EnvironmentPageProps {
  params: {
    patchId: string
  }
}

export default async function DynamicEnvironmentPage({ params }: EnvironmentPageProps) {
  const { patchId } = await params
  const patch = getPatchConfigSafe(patchId)

  if (!patch) {
    notFound()
  }

  return (
    <div className="h-screen w-full flex flex-col">
      {/* Header with patch info */}
      <header className="border-b border-primary/20 bg-black/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-primary text-xl font-bold font-mono">{patch.label}</span>
              {patch.trinityMount && (
                <span className="text-xs font-mono text-muted-foreground">
                  TRINITY FLOOR {patch.trinityMount.trinityFloor}
                  {patch.trinityMount.timeline && ` • ${patch.trinityMount.timeline}`}
                </span>
              )}
            </div>
            <div className="text-xs font-mono text-muted-foreground">{patch.description}</div>
          </div>
        </div>
      </header>

      {/* Environment renderer */}
      <div className="flex-1">
        <EnvironmentRenderer patchId={patchId} kind="lobby" />
      </div>
    </div>
  )
}

export async function generateStaticParams() {
  return [
    { patchId: "creator-codex" },
    { patchId: "worldbuild-generic" },
    { patchId: "worldbuild-neteru" },
    { patchId: "worldbuild-ott" },
    { patchId: "worldbuild-akira" },
  ]
}
