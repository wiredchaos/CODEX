# Deploy to Railway - Quick Guide

Railway is the easiest way to deploy your Discord bot with a $5/month free tier.

## Step 1: Prepare Your Code

Make sure you have:
- ✅ Bot code in `/bot` folder
- ✅ `package.json` with build scripts
- ✅ `.env.example` (don't commit `.env`!)

## Step 2: Push to GitHub

```bash
# If not already a git repo
git init
git add .
git commit -m "Initial commit"

# Create a new repo on GitHub, then:
git remote add origin https://github.com/YOUR_USERNAME/wc-dicbot.git
git push -u origin main
```

## Step 3: Deploy to Railway

### A. Create Railway Project
1. Go to [railway.app](https://railway.app)
2. Sign in with GitHub
3. Click **"New Project"**
4. Select **"Deploy from GitHub repo"**
5. Choose your `wc-dicbot` repository

### B. Configure Root Directory
1. Your service will appear (might say "Deploying...")
2. Click on the service card
3. Go to **Settings** tab
4. Scroll to **"Root Directory"**
5. Enter: `/bot`
6. Click **"Update"**

### C. Add Environment Variables
1. Go to **Variables** tab
2. Click **"New Variable"** and add these:

```
DISCORD_BOT_TOKEN=YOUR_BOT_TOKEN_HERE
DISCORD_APP_ID=YOUR_APPLICATION_ID_HERE
DISCORD_GUILD_ID=YOUR_SERVER_ID_HERE
APP_BASE_URL=https://your-vercel-app.vercel.app
NODE_ENV=production
```

**Where to get these values:**

**DISCORD_BOT_TOKEN:**
- Go to [discord.com/developers/applications](https://discord.com/developers/applications)
- Click your application → **Bot** tab
- Click **"Reset Token"** → Copy the token

**DISCORD_APP_ID:**
- Same page → **General Information** tab
- Copy the **"Application ID"**

**DISCORD_GUILD_ID:**
- Open Discord desktop/web
- Enable Developer Mode: Settings → Advanced → Developer Mode
- Right-click your server → **"Copy Server ID"**

**APP_BASE_URL:**
- Your Vercel deployment URL from step 1
- Format: `https://wc-dicbot.vercel.app` (no trailing slash!)

### D. Deploy
1. Railway will auto-deploy once variables are set
2. Go to **Deployments** tab
3. Wait for **"SUCCESS"** status (2-3 minutes)

## Step 4: Verify Bot is Online

### Check Logs
1. In Railway, click **"View Logs"**
2. Look for these messages:
```
Registering 7 slash commands...
Slash commands registered successfully.
NEURO SWARM BOT online as [Your Bot Name]
Connected to 1 guilds
```

### Check Discord
1. Go to your Discord server
2. Bot should show as **Online** (green dot)
3. Type `/` and you should see:
   - `/begin`
   - `/set-gen`
   - `/set-neuro`
   - `/set-wallet`
   - `/labyrinth`
   - `/move`
   - `/wl`

## Step 5: Test Commands

Try `/begin` in your server:
```
User: /begin
Bot: [KIBA response about selecting generation]
```

If it works, you're done!

## Troubleshooting

### Bot shows as Offline
**Check Railway logs for:**
```
Missing required environment variables: DISCORD_BOT_TOKEN
```
→ Add the missing variable in Railway

**OR:**
```
Error: TOKEN_INVALID
```
→ Reset your bot token and update Railway variable

### Commands don't appear
- Wait 1 hour (Discord caches commands globally)
- Or kick the bot and re-invite it
- Or restart the Railway deployment

### Bot responds but nothing saves
**Check logs for API errors:**
```
Failed to call API: fetch failed
```
→ Verify `APP_BASE_URL` is correct and Vercel app is deployed

### "Something glitched in the signal"
- Check Railway logs for the actual error
- Verify Vercel API routes are working
- Test API directly: `curl YOUR_VERCEL_URL/api/discord/begin`

## Cost Breakdown

**Railway Pricing:**
- First $5/month free (trial)
- ~$0.50-2/month for this bot after trial
- Pay-as-you-go after $5 credit

**Tip:** Railway shows usage in real-time on the dashboard

## Advanced: Add Custom Domain

If you want a custom domain for your bot's API:

1. In Railway, click your service → **Settings**
2. Scroll to **"Domains"**
3. Click **"Generate Domain"** for a free `.railway.app` URL
4. Or add your own domain

## Need Help?

- Railway docs: [docs.railway.app](https://docs.railway.app)
- Discord support: [discord.gg/TsuK6wM4h](https://discord.gg/TsuK6wM4h)
- Check main DEPLOYMENT.md for more details
