# NEURO SWARM Discord Bot

Discord bot for WIRED CHAOS META with NEURO agent integration.

## Setup

1. Create a Discord application at https://discord.com/developers/applications
2. Copy `.env.example` to `.env` and fill in your values
3. Install dependencies: `npm install`
4. Build: `npm run build`
5. Start: `npm start`

## Development

Run with hot reload:
```bash
npm run dev
```

## Commands

- `/begin` - Initialize your profile (KIBA)
- `/set-gen` - Set your generation
- `/set-neuro` - Toggle NEURO mode
- `/set-wallet` - Bind wallet address
- `/labyrinth` - Start NPC Labyrinth (META_X)
- `/move` - Send a move to the game
- `/wl` - Check whitelist scores (GRYMM)

## Deployment

Deploy to Railway, Render, or Fly.io with the environment variables configured.

### Railway
```bash
railway up
```

### Render
Connect your repository and set the build command to `npm run build` and start command to `npm start`.

## Architecture

The bot calls your Next.js API routes:
- POST /api/discord/begin
- POST /api/discord/set-gen
- POST /api/discord/set-neuro
- POST /api/discord/set-wallet
- POST /api/npc/start
- POST /api/npc/move
- GET /api/wl/score
