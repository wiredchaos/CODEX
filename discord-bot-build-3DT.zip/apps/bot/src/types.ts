// Bot Types
import type { ChatInputCommandInteraction, SlashCommandBuilder, SlashCommandSubcommandsOnlyBuilder } from "discord.js"

export interface Command {
  data:
    | SlashCommandBuilder
    | SlashCommandSubcommandsOnlyBuilder
    | Omit<SlashCommandBuilder, "addSubcommand" | "addSubcommandGroup">
  execute: (interaction: ChatInputCommandInteraction) => Promise<void>
}

export type AgentId = "META_X" | "KIBA" | "SHADOWLUX" | "GRYMM" | "OYALAN" | "NEUROLUX" | "UPLINK"

export type Generation = "Boomer" | "GenX" | "Millennial" | "GenZ" | "GenAlpha"

// API Response types
export interface BeginResponse {
  ok: boolean
  userId: string
  message: string
  wlAwarded: { vrg33589: number; vault33: number }
}

export interface SetGenResponse {
  ok: boolean
  message: string
  user: {
    generation: Generation
  }
}

export interface SetNeuroResponse {
  ok: boolean
  message: string
  user: {
    neuroMode: boolean
  }
}

export interface SetWalletResponse {
  ok: boolean
  message: string
  user: {
    walletAddress: string
  }
}

export interface NPCStartResponse {
  ok: boolean
  message: string
  session: {
    id: string
    game: string
    moveCount: number
  }
}

export interface NPCMoveResponse {
  ok: boolean
  narrative: string
  wlDelta: number
  project: string
  ledgerNote: string
  session: {
    moveCount: number
    game: string
  }
}

export interface WLScoreResponse {
  ok: boolean
  scores: {
    userId: string
    vrg33589: number
    vault33: number
    totalMoves: number
    lastActivity: string
  }
}

export interface SwarmStatusResponse {
  ok: boolean
  discordId: string
  context: {
    chaos_score: number
    ascension_level: number
    last_agent: AgentId | null
  }
  progress: {
    level: number
    chaos: number
    wl: { vrg: number; vault: number; total: number }
    skills: { unlocked: number; total: number; available: string[] }
    quest: { id: string; name: string; description: string } | null
    nextMilestone: string | null
  }
}

export interface SwarmEventResponse {
  ok: boolean
  agent: AgentId
  message: string
  skillsUnlocked: string[]
  chaosGained: number
}

export interface ErrorResponse {
  error: string
}
