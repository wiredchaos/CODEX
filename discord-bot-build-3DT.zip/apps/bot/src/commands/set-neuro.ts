// /set-neuro - Toggle NEURO mode for gentler guidance
import { SlashCommandBuilder, type ChatInputCommandInteraction } from "discord.js"
import type { Command } from "../types"
import { setNeuro, isError } from "../api"

export const command: Command = {
  data: new SlashCommandBuilder()
    .setName("set-neuro")
    .setDescription("Toggle NEURO mode for step-by-step guidance")
    .addBooleanOption((option) => option.setName("enabled").setDescription("Enable NEURO mode?").setRequired(true)),

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply({ ephemeral: true })

    const discordId = interaction.user.id
    const enabled = interaction.options.getBoolean("enabled", true)

    const response = await setNeuro(discordId, enabled)

    if (isError(response)) {
      await interaction.editReply({
        content: `Signal disrupted: ${response.error}`,
      })
      return
    }

    await interaction.editReply({
      content: response.message,
    })
  },
}

export default command
