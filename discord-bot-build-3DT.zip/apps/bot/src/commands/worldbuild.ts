// Creator Codex / World Build command - sends prompts to NEURO SWARM
import { type ChatInputCommandInteraction, SlashCommandBuilder, EmbedBuilder } from "discord.js"
import { api } from "../api"

export const data = new SlashCommandBuilder()
  .setName("worldbuild")
  .setDescription("Send a worldbuilding prompt to NEURO SWARM")
  .addStringOption((opt) =>
    opt.setName("prompt").setDescription("Describe the world, scene, or NPC you want to build").setRequired(true),
  )
  .addStringOption((opt) =>
    opt
      .setName("patch")
      .setDescription("Which patch to use")
      .setRequired(false)
      .addChoices(
        { name: "Creator Codex", value: "creator-codex" },
        { name: "World Build (Generic)", value: "worldbuild-generic" },
        { name: "Neteru Apinaya", value: "worldbuild-neteru" },
        { name: "789 Studios OTT", value: "worldbuild-ott" },
        { name: "Akira Codex", value: "worldbuild-akira" },
      ),
  )
  .addStringOption((opt) =>
    opt.setName("worldkey").setDescription("Optional world key (e.g. AkiraCodex:Book1)").setRequired(false),
  )

export async function execute(interaction: ChatInputCommandInteraction) {
  await interaction.deferReply()

  const prompt = interaction.options.getString("prompt", true)
  const patchId = interaction.options.getString("patch") ?? "creator-codex"
  const worldKey = interaction.options.getString("worldkey") ?? `${patchId}:default`

  try {
    // Send to swarm event endpoint
    const response = await api.post("/api/swarm/event", {
      agentId: "NEUROLUX",
      eventType: "worldbuild_prompt",
      patchId,
      worldKey,
      payload: {
        userId: interaction.user.id,
        username: interaction.user.username,
        platform: "discord",
        guildId: interaction.guildId,
        channelId: interaction.channelId,
        prompt,
      },
    })

    // Get patch label for display
    const patchLabels: Record<string, string> = {
      "creator-codex": "Creator Codex",
      "worldbuild-generic": "World Build",
      "worldbuild-neteru": "Neteru Apinaya",
      "worldbuild-ott": "789 Studios OTT",
      "worldbuild-akira": "Akira Codex",
    }

    const embed = new EmbedBuilder()
      .setColor(0x00ff88)
      .setTitle("NEURO SWARM // WORLDBUILD")
      .setDescription(`Your prompt has been sent to the **${patchLabels[patchId] ?? patchId}** patch.`)
      .addFields(
        { name: "World Key", value: `\`${worldKey}\``, inline: true },
        { name: "Agent", value: "NEUROLUX", inline: true },
        { name: "Prompt", value: prompt.length > 200 ? prompt.slice(0, 200) + "..." : prompt },
      )
      .setFooter({ text: `Event ID: ${response.timestamp ?? new Date().toISOString()}` })
      .setTimestamp()

    await interaction.editReply({ embeds: [embed] })
  } catch (error) {
    console.error("[WORLDBUILD] Error:", error)
    await interaction.editReply({
      content: "**ERROR** // Failed to process worldbuild prompt. Try again later.",
    })
  }
}

export default { data, execute }
