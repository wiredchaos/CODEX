// Command loader
import type { Command } from "../types"

import beginCommand from "./begin"
import setGenCommand from "./set-gen"
import setNeuroCommand from "./set-neuro"
import setWalletCommand from "./set-wallet"
import labyrinthCommand from "./labyrinth"
import moveCommand from "./move"
import wlCommand from "./wl"
import statusCommand from "./status"
import adminCommand from "./admin"
import worldbuildCommand from "./worldbuild"

export const commands: Command[] = [
  beginCommand,
  setGenCommand,
  setNeuroCommand,
  setWalletCommand,
  labyrinthCommand,
  moveCommand,
  wlCommand,
  statusCommand,
  adminCommand,
  worldbuildCommand,
]

export function getCommandsData() {
  return commands.map((cmd) => cmd.data.toJSON())
}

export function getCommand(name: string): Command | undefined {
  return commands.find((cmd) => cmd.data.name === name)
}
