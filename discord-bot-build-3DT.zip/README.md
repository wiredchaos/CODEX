# WIRED CHAOS META - NEURO SWARM System

A complete Discord bot + Next.js backend for the WIRED CHAOS ecosystem featuring:

- **7 NEURO SWARM Agents** - META_X, KIBA, SHADOWLUX, GRYMM, OYALAN, NEUROLUX, UPLINK
- **Onboarding System** - Generation selection, NEURO mode activation, wallet linking
- **NPC Games** - Labyrinth, Alchemist, Forge, Triage, Multiverse, Sequence
- **WL Tracking** - Dual leaderboards for VRG33589 and VAULT33 projects
- **789 CREW** - Special handling with auto-WL slots
- **Admin Dashboard** - Real-time stats, user management, activity feed

---

## Quick Start

### 1. Deploy Next.js Backend

**From v0:**
- Click "Publish" button in top right
- Follow prompts to deploy to Vercel
- Copy your deployed URL

**Or manually:**
```bash
git clone <your-repo>
cd wc-dicbot
npm install
npm run build
# Push to Vercel or deploy locally
```

### 2. Setup Discord Bot

See **[DEPLOYMENT.md](./DEPLOYMENT.md)** for complete step-by-step guide.

**Quick version:**
1. Create Discord app at discord.com/developers
2. Copy bot token, application ID, server ID
3. Deploy `/bot` folder to Railway with env vars
4. Invite bot to your server

**Required env vars:**
```bash
DISCORD_TOKEN=your_bot_token
DISCORD_CLIENT_ID=your_app_id
DISCORD_GUILD_ID=your_server_id
API_BASE_URL=https://your-vercel-url.vercel.app
```

---

## Project Structure

```
/
├── app/                    # Next.js App Router
│   ├── api/               # API routes
│   │   ├── discord/       # Discord command handlers
│   │   ├── npc/           # NPC game logic
│   │   ├── wl/            # WL tracking & leaderboards
│   │   └── admin/         # Admin endpoints
│   └── page.tsx           # Admin dashboard
├── bot/                   # Discord bot (deploy separately)
│   ├── src/
│   │   ├── commands/      # Slash commands
│   │   ├── api.ts         # API client
│   │   └── index.ts       # Bot entry point
│   └── package.json
├── lib/
│   └── neuro/             # NEURO SWARM core
│       ├── voicepack.json # Agent templates
│       ├── router.ts      # Response routing
│       └── store.ts       # In-memory data store
└── components/
    └── dashboard/         # Dashboard UI components
```

---

## Commands

| Command | Description |
|---------|-------------|
| `/begin` | Start onboarding - choose your generation |
| `/set-gen` | Change your generation (GEN_1-5, GEN_X, GEN_789) |
| `/set-neuro` | Toggle NEURO MODE (agent responses) |
| `/set-wallet` | Link your wallet address |
| `/labyrinth` | Start the Labyrinth NPC game |
| `/move <direction>` | Move in active NPC game |
| `/wl` | Check your WL scores for VRG33589 & VAULT33 |

---

## Agent Personalities

### META_X
- **Role:** System architect, primary interface
- **Style:** Balanced, technical, guiding
- **Triggers:** Default fallback

### KIBA
- **Role:** Strategic analyst, tactical guide
- **Style:** Sharp, efficient, mission-focused
- **Triggers:** Game moves, strategy

### SHADOWLUX
- **Role:** Cryptic oracle, pattern reader
- **Style:** Mysterious, enigmatic, philosophical
- **Triggers:** Lore, deep questions

### GRYMM
- **Role:** Rugged veteran, survival expert
- **Style:** Blunt, practical, hardened
- **Triggers:** Combat, danger, harsh truths

### OYALAN
- **Role:** Interdimensional guide, cosmic navigator
- **Style:** Ethereal, abstract, otherworldly
- **Triggers:** Portals, dimensions, chaos

### NEUROLUX
- **Role:** Neural hacker, data interface
- **Style:** Technical, precise, augmented
- **Triggers:** Systems, tech, augmentation

### UPLINK
- **Role:** Communications hub, intel broker
- **Style:** Crisp, professional, informative
- **Triggers:** Broadcasts, updates, intel

---

## WL Scoring

### VRG33589 (Vault Recon Group)
- Begin onboarding: +10 pts
- Complete profile: +25 pts
- NPC game completion: +50 pts
- Daily activity: +5 pts
- 789 CREW: Auto +100 pts

### VAULT33 (Main Project)
- Link wallet: +15 pts
- NEURO MODE activation: +30 pts
- Special events: Variable
- 789 CREW: Auto +150 pts

---

## Tech Stack

**Frontend/Backend:**
- Next.js 16 (App Router)
- React 19
- TypeScript 5
- Tailwind CSS 4
- shadcn/ui

**Discord Bot:**
- discord.js 14
- TypeScript 5
- Node.js 18+

**Deployment:**
- Vercel (Next.js)
- Railway (Bot)
- In-memory store (upgradable to Neon/Supabase)

---

## Development

### Next.js App
```bash
npm install
npm run dev
# Visit http://localhost:3000
```

### Discord Bot
```bash
cd bot
npm install
npm run dev
# Bot connects in development mode
```

---

## Adding Database

Right now, data is stored in memory and resets on redeploy.

**To add persistent storage:**

1. Click "Connect" in v0 → Add Neon or Supabase integration
2. Tell v0: "Migrate to Neon database"
3. Automatic schema + migration scripts will be generated

---

## Support

**Discord Server:** https://discord.gg/TsuK6wM4h

**Issues?**
- Check Railway logs for bot errors
- Check Vercel function logs for API errors
- Verify environment variables are set correctly
- See [DEPLOYMENT.md](./DEPLOYMENT.md) for troubleshooting

---

## Roadmap

- [ ] Persistent database (Neon/Supabase)
- [ ] Additional NPC games (Alchemist, Forge, etc.)
- [ ] Advanced agent routing with context memory
- [ ] 789 CREW auto-detection
- [ ] Custom WL boost commands
- [ ] Leaderboard reset system
- [ ] Multi-server support

---

Built with ❤️ using v0.dev
