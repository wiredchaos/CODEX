/**
 * WIRED CHAOS META - Discord Server Auto-Setup Script
 *
 * This script creates all the channels, roles, and permissions
 * needed for the NEURO SWARM Discord bot.
 *
 * Usage:
 * 1. Set DISCORD_BOT_TOKEN and DISCORD_GUILD_ID in environment
 * 2. Run: npx ts-node scripts/discord-server-setup.ts
 *
 * Or run via the bot command: /admin setup-server (admin only)
 */

import {
  Client,
  GatewayIntentBits,
  ChannelType,
  PermissionFlagsBits,
  type Guild,
  type CategoryChannel,
  type Role,
} from "discord.js"

// ============================================
// CONFIGURATION
// ============================================

const ROLES_CONFIG = [
  // Staff roles
  { name: "789 ADMIN", color: 0xff0000, hoist: true, position: 100 },
  { name: "789 MOD", color: 0xff4444, hoist: true, position: 99 },
  { name: "789 CREW", color: 0xffd700, hoist: true, position: 98 },

  // WL Tiers - VRG33589
  { name: "VRG ASCENDED", color: 0x00ff88, hoist: false, position: 50 },
  { name: "VRG TIER 3", color: 0x00dd66, hoist: false, position: 49 },
  { name: "VRG TIER 2", color: 0x00bb44, hoist: false, position: 48 },
  { name: "VRG TIER 1", color: 0x009922, hoist: false, position: 47 },

  // WL Tiers - VAULT33
  { name: "VAULT ASCENDED", color: 0x0088ff, hoist: false, position: 40 },
  { name: "VAULT TIER 3", color: 0x0066dd, hoist: false, position: 39 },
  { name: "VAULT TIER 2", color: 0x0044bb, hoist: false, position: 38 },
  { name: "VAULT TIER 1", color: 0x002299, hoist: false, position: 37 },

  // NEURO Modes
  { name: "NEURO CHAOS", color: 0xff00ff, hoist: false, position: 30 },
  { name: "NEURO ASCEND", color: 0xffff00, hoist: false, position: 29 },
  { name: "NEURO STANDARD", color: 0x888888, hoist: false, position: 28 },

  // Generations
  { name: "GEN1", color: 0x444444, hoist: false, position: 20 },
  { name: "GEN2", color: 0x555555, hoist: false, position: 19 },
  { name: "GEN3", color: 0x666666, hoist: false, position: 18 },

  // Special
  { name: "ONBOARDED", color: 0x333333, hoist: false, position: 10 },
  { name: "VISITOR", color: 0x222222, hoist: false, position: 5 },
]

const CATEGORIES_CONFIG = [
  {
    name: "WIRED CHAOS HQ",
    channels: [
      { name: "announcements", type: ChannelType.GuildText, readonly: true },
      { name: "rules", type: ChannelType.GuildText, readonly: true },
      { name: "verify", type: ChannelType.GuildText },
    ],
  },
  {
    name: "ONBOARDING",
    channels: [
      { name: "start-here", type: ChannelType.GuildText },
      { name: "profile-setup", type: ChannelType.GuildText },
      { name: "bot-commands", type: ChannelType.GuildText },
    ],
  },
  {
    name: "NPC LABYRINTH",
    channels: [
      { name: "npc-labyrinth", type: ChannelType.GuildText },
      { name: "npc-forge", type: ChannelType.GuildText },
      { name: "npc-alchemist", type: ChannelType.GuildText },
      { name: "game-leaderboard", type: ChannelType.GuildText, readonly: true },
    ],
  },
  {
    name: "WHITELIST",
    channels: [
      { name: "whitelist-briefings", type: ChannelType.GuildText, readonly: true },
      { name: "wl-leaderboard", type: ChannelType.GuildText, readonly: true },
      { name: "wl-check", type: ChannelType.GuildText },
    ],
  },
  {
    name: "VRG33589",
    channels: [
      { name: "vrg-general", type: ChannelType.GuildText, requireRole: "VRG TIER 1" },
      { name: "vrg-lore", type: ChannelType.GuildText, requireRole: "VRG TIER 1" },
      { name: "vrg-alpha", type: ChannelType.GuildText, requireRole: "VRG TIER 3" },
    ],
  },
  {
    name: "VAULT33",
    channels: [
      { name: "vault33-signals", type: ChannelType.GuildText, requireRole: "VAULT TIER 1" },
      { name: "vault33-core", type: ChannelType.GuildText, requireRole: "VAULT TIER 2" },
      { name: "vault33-inner", type: ChannelType.GuildText, requireRole: "VAULT TIER 3" },
    ],
  },
  {
    name: "789 CREW",
    channels: [
      { name: "crew-lounge", type: ChannelType.GuildText, requireRole: "789 CREW" },
      { name: "crew-alpha", type: ChannelType.GuildText, requireRole: "789 CREW" },
      { name: "crew-voice", type: ChannelType.GuildVoice, requireRole: "789 CREW" },
    ],
  },
  {
    name: "COMMUNITY",
    channels: [
      { name: "general", type: ChannelType.GuildText },
      { name: "off-topic", type: ChannelType.GuildText },
      { name: "memes", type: ChannelType.GuildText },
      { name: "voice-general", type: ChannelType.GuildVoice },
    ],
  },
]

// ============================================
// SETUP FUNCTIONS
// ============================================

async function createRoles(guild: Guild): Promise<Map<string, Role>> {
  console.log("Creating roles...")
  const roleMap = new Map<string, Role>()

  for (const roleConfig of ROLES_CONFIG) {
    // Check if role exists
    let role = guild.roles.cache.find((r) => r.name === roleConfig.name)

    if (!role) {
      role = await guild.roles.create({
        name: roleConfig.name,
        color: roleConfig.color,
        hoist: roleConfig.hoist,
        position: roleConfig.position,
        reason: "NEURO SWARM setup",
      })
      console.log(`  Created role: ${roleConfig.name}`)
    } else {
      console.log(`  Role exists: ${roleConfig.name}`)
    }

    roleMap.set(roleConfig.name, role)
  }

  return roleMap
}

async function createChannels(guild: Guild, roleMap: Map<string, Role>): Promise<void> {
  console.log("Creating channels...")

  for (const categoryConfig of CATEGORIES_CONFIG) {
    // Create or find category
    let category = guild.channels.cache.find(
      (c) => c.name === categoryConfig.name && c.type === ChannelType.GuildCategory,
    ) as CategoryChannel | undefined

    if (!category) {
      category = await guild.channels.create({
        name: categoryConfig.name,
        type: ChannelType.GuildCategory,
        reason: "NEURO SWARM setup",
      })
      console.log(`  Created category: ${categoryConfig.name}`)
    } else {
      console.log(`  Category exists: ${categoryConfig.name}`)
    }

    // Create channels in category
    for (const channelConfig of categoryConfig.channels) {
      const existingChannel = guild.channels.cache.find(
        (c) => c.name === channelConfig.name && c.parentId === category?.id,
      )

      if (!existingChannel) {
        const permissionOverwrites: {
          id: string
          allow?: bigint[]
          deny?: bigint[]
        }[] = []

        // Handle readonly channels
        if (channelConfig.readonly) {
          permissionOverwrites.push({
            id: guild.roles.everyone.id,
            deny: [PermissionFlagsBits.SendMessages],
          })
        }

        // Handle role-gated channels
        if (channelConfig.requireRole) {
          const requiredRole = roleMap.get(channelConfig.requireRole)
          if (requiredRole) {
            permissionOverwrites.push({
              id: guild.roles.everyone.id,
              deny: [PermissionFlagsBits.ViewChannel],
            })
            permissionOverwrites.push({
              id: requiredRole.id,
              allow: [PermissionFlagsBits.ViewChannel],
            })
          }
        }

        await guild.channels.create({
          name: channelConfig.name,
          type: channelConfig.type,
          parent: category,
          permissionOverwrites: permissionOverwrites.length > 0 ? permissionOverwrites : undefined,
          reason: "NEURO SWARM setup",
        })
        console.log(`    Created channel: ${channelConfig.name}`)
      } else {
        console.log(`    Channel exists: ${channelConfig.name}`)
      }
    }
  }
}

async function setupServer(guild: Guild): Promise<void> {
  console.log(`\nSetting up NEURO SWARM on: ${guild.name}`)
  console.log("=".repeat(50))

  const roleMap = await createRoles(guild)
  await createChannels(guild, roleMap)

  console.log("=".repeat(50))
  console.log("Setup complete!")
}

// ============================================
// MAIN EXECUTION
// ============================================

async function main() {
  const token = process.env.DISCORD_BOT_TOKEN
  const guildId = process.env.DISCORD_GUILD_ID

  if (!token || !guildId) {
    console.error("Missing DISCORD_BOT_TOKEN or DISCORD_GUILD_ID")
    process.exit(1)
  }

  const client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers],
  })

  client.once("ready", async () => {
    console.log(`Logged in as ${client.user?.tag}`)

    const guild = client.guilds.cache.get(guildId)
    if (!guild) {
      console.error(`Guild not found: ${guildId}`)
      process.exit(1)
    }

    await setupServer(guild)
    process.exit(0)
  })

  await client.login(token)
}

// Export for use as module
export { setupServer, createRoles, createChannels, ROLES_CONFIG, CATEGORIES_CONFIG }

// Run if executed directly
if (require.main === module) {
  main().catch(console.error)
}
