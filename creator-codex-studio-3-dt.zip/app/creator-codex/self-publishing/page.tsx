"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import { useWcMode } from "@/lib/wc-mode"
import { WcModeToggle } from "@/components/wc-mode-toggle"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { Loader2, CheckCircle2, AlertCircle } from "lucide-react"

interface Draft {
  id: string
  title: string
  body: string
  excerpt: string
  coverImageUrl: string
  tags: string[]
}

interface PublishReceipt {
  platform: string
  status: "success" | "error"
  id?: string
  error?: string
}

export default function SelfPublishingPage() {
  const { mode } = useWcMode()
  const searchParams = useSearchParams()
  const draftId = searchParams.get("draftId")

  const [draft, setDraft] = useState<Draft>({
    id: "",
    title: "",
    body: "",
    excerpt: "",
    coverImageUrl: "",
    tags: [],
  })

  const [publishTo, setPublishTo] = useState({
    paragraph: false,
    cbe: false,
    clear: false,
  })

  const [isLoading, setIsLoading] = useState(false)
  const [isPublishing, setIsPublishing] = useState(false)
  const [receipts, setReceipts] = useState<PublishReceipt[]>([])
  const [canonStatus, setCanonStatus] = useState<"pending" | "approved">("pending")

  useEffect(() => {
    if (draftId) {
      loadDraft(draftId)
    }
  }, [draftId])

  const loadDraft = async (id: string) => {
    setIsLoading(true)
    try {
      const response = await fetch(`/api/creator-codex/drafts?draftId=${id}`)
      if (response.ok) {
        const data = await response.json()
        setDraft(data)
        setCanonStatus(data.canonStatus || "pending")
      }
    } catch (error) {
      console.error("[v0] Failed to load draft:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handlePublish = async () => {
    const selectedPlatforms = Object.entries(publishTo)
      .filter(([_, enabled]) => enabled)
      .map(([platform]) => platform)

    if (selectedPlatforms.length === 0) {
      alert("Please select at least one publishing destination")
      return
    }

    setIsPublishing(true)
    setReceipts([])

    try {
      const response = await fetch("/api/creator-codex/publish", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          draft,
          platforms: selectedPlatforms,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setReceipts(data.receipts)
      }
    } catch (error) {
      console.error("[v0] Publishing failed:", error)
      setReceipts([
        {
          platform: "system",
          status: "error",
          error: "Publishing system error",
        },
      ])
    } finally {
      setIsPublishing(false)
    }
  }

  const handleTagsChange = (value: string) => {
    const tags = value
      .split(",")
      .map((tag) => tag.trim())
      .filter(Boolean)
    setDraft({ ...draft, tags })
  }

  return (
    <main
      className={cn(
        "min-h-screen p-8 transition-colors duration-500",
        mode === "akashic" ? "bg-gradient-to-br from-background via-background to-accent/5" : "bg-background",
      )}
    >
      <div className="max-w-5xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <h1
              className={cn(
                "text-4xl font-bold tracking-tight transition-all duration-300",
                mode === "akashic"
                  ? "text-foreground bg-gradient-to-r from-accent to-accent/50 bg-clip-text text-transparent"
                  : "text-foreground",
              )}
            >
              Creator Codex
            </h1>
            <p
              className={cn(
                "font-mono text-sm uppercase tracking-wider transition-colors duration-300",
                mode === "akashic" ? "text-accent/80" : "text-blue-400",
              )}
            >
              Self-Publishing • Distribution Owner
            </p>
          </div>
          <WcModeToggle />
        </div>

        {/* Canon Status Badge */}
        <div className="flex items-center gap-3">
          <Badge
            variant="outline"
            className={cn(
              "transition-all duration-300",
              mode === "akashic"
                ? "border-accent/40 bg-accent/10 text-accent"
                : "border-blue-500/40 bg-blue-500/10 text-blue-400",
            )}
          >
            Canon governed by Akira Codex
          </Badge>
          <Badge
            variant={canonStatus === "approved" ? "default" : "secondary"}
            className={cn(
              "transition-all duration-300",
              canonStatus === "approved"
                ? mode === "akashic"
                  ? "bg-green-500/20 text-green-400 border-green-500/40"
                  : "bg-green-600/20 text-green-400 border-green-600/40"
                : "bg-yellow-500/20 text-yellow-400 border-yellow-500/40",
            )}
          >
            {canonStatus === "approved" ? "✓ Approved" : "⏳ Validation Pending"}
          </Badge>
        </div>

        {/* Main Editor */}
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="size-8 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div
            className={cn(
              "rounded-lg border p-6 space-y-6 transition-all duration-500",
              mode === "akashic"
                ? "border-accent/20 bg-accent/5 shadow-[0_0_30px_rgba(var(--accent-rgb),0.1)]"
                : "border-border bg-card shadow-sm",
            )}
          >
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-2">
                <Label
                  htmlFor="title"
                  className={cn(
                    "font-mono text-xs uppercase tracking-wider",
                    mode === "akashic" ? "text-accent" : "text-blue-400",
                  )}
                >
                  Title
                </Label>
                <Input
                  id="title"
                  value={draft.title}
                  onChange={(e) => setDraft({ ...draft, title: e.target.value })}
                  placeholder="Enter title..."
                  className={cn(
                    "transition-all duration-300",
                    mode === "akashic"
                      ? "border-accent/30 focus-visible:ring-accent/50"
                      : "border-border focus-visible:ring-blue-500/50",
                  )}
                />
              </div>

              <div className="space-y-2">
                <Label
                  htmlFor="coverImageUrl"
                  className={cn(
                    "font-mono text-xs uppercase tracking-wider",
                    mode === "akashic" ? "text-accent" : "text-blue-400",
                  )}
                >
                  Cover Image URL
                </Label>
                <Input
                  id="coverImageUrl"
                  value={draft.coverImageUrl}
                  onChange={(e) => setDraft({ ...draft, coverImageUrl: e.target.value })}
                  placeholder="https://..."
                  className={cn(
                    "transition-all duration-300",
                    mode === "akashic"
                      ? "border-accent/30 focus-visible:ring-accent/50"
                      : "border-border focus-visible:ring-blue-500/50",
                  )}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label
                htmlFor="excerpt"
                className={cn(
                  "font-mono text-xs uppercase tracking-wider",
                  mode === "akashic" ? "text-accent" : "text-blue-400",
                )}
              >
                Excerpt
              </Label>
              <Textarea
                id="excerpt"
                value={draft.excerpt}
                onChange={(e) => setDraft({ ...draft, excerpt: e.target.value })}
                placeholder="Brief summary..."
                rows={3}
                className={cn(
                  "resize-none transition-all duration-300",
                  mode === "akashic"
                    ? "border-accent/30 focus-visible:ring-accent/50"
                    : "border-border focus-visible:ring-blue-500/50",
                )}
              />
            </div>

            <div className="space-y-2">
              <Label
                htmlFor="body"
                className={cn(
                  "font-mono text-xs uppercase tracking-wider",
                  mode === "akashic" ? "text-accent" : "text-blue-400",
                )}
              >
                Body
              </Label>
              <Textarea
                id="body"
                value={draft.body}
                onChange={(e) => setDraft({ ...draft, body: e.target.value })}
                placeholder="Full content..."
                rows={12}
                className={cn(
                  "resize-none transition-all duration-300",
                  mode === "akashic"
                    ? "border-accent/30 focus-visible:ring-accent/50"
                    : "border-border focus-visible:ring-blue-500/50",
                )}
              />
            </div>

            <div className="space-y-2">
              <Label
                htmlFor="tags"
                className={cn(
                  "font-mono text-xs uppercase tracking-wider",
                  mode === "akashic" ? "text-accent" : "text-blue-400",
                )}
              >
                Tags (comma-separated)
              </Label>
              <Input
                id="tags"
                value={draft.tags.join(", ")}
                onChange={(e) => handleTagsChange(e.target.value)}
                placeholder="tag1, tag2, tag3"
                className={cn(
                  "transition-all duration-300",
                  mode === "akashic"
                    ? "border-accent/30 focus-visible:ring-accent/50"
                    : "border-border focus-visible:ring-blue-500/50",
                )}
              />
            </div>
          </div>
        )}

        {/* Publishing Destinations */}
        <div
          className={cn(
            "rounded-lg border p-6 space-y-4 transition-all duration-500",
            mode === "akashic"
              ? "border-accent/20 bg-accent/5 shadow-[0_0_30px_rgba(var(--accent-rgb),0.1)]"
              : "border-border bg-card shadow-sm",
          )}
        >
          <h3
            className={cn(
              "font-mono text-sm uppercase tracking-wider",
              mode === "akashic" ? "text-accent" : "text-blue-400",
            )}
          >
            Publishing Destinations
          </h3>

          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <Checkbox
                id="paragraph"
                checked={publishTo.paragraph}
                onCheckedChange={(checked) => setPublishTo({ ...publishTo, paragraph: checked as boolean })}
              />
              <Label htmlFor="paragraph" className="font-normal cursor-pointer">
                Publish to Paragraph
              </Label>
            </div>

            <div className="flex items-center space-x-3">
              <Checkbox
                id="cbe"
                checked={publishTo.cbe}
                onCheckedChange={(checked) => setPublishTo({ ...publishTo, cbe: checked as boolean })}
              />
              <Label htmlFor="cbe" className="font-normal cursor-pointer">
                Publish to CBE
              </Label>
            </div>

            <div className="flex items-center space-x-3">
              <Checkbox
                id="clear"
                checked={publishTo.clear}
                onCheckedChange={(checked) => setPublishTo({ ...publishTo, clear: checked as boolean })}
              />
              <Label htmlFor="clear" className="font-normal cursor-pointer">
                Publish to CLEAR
              </Label>
            </div>
          </div>

          <div className="pt-4 border-t border-border/20">
            <Button
              onClick={handlePublish}
              disabled={!draft.title || !draft.body || isPublishing}
              className={cn(
                "w-full font-mono uppercase tracking-wider transition-all duration-300",
                mode === "akashic"
                  ? "bg-accent/20 text-accent border border-accent/40 hover:bg-accent/30 hover:shadow-[0_0_20px_rgba(var(--accent-rgb),0.3)]"
                  : "bg-blue-600 text-white hover:bg-blue-700",
              )}
            >
              {isPublishing ? (
                <>
                  <Loader2 className="size-4 animate-spin" />
                  Publishing...
                </>
              ) : (
                "Publish"
              )}
            </Button>
          </div>
        </div>

        {/* Status Receipts */}
        {receipts.length > 0 && (
          <div
            className={cn(
              "rounded-lg border p-6 space-y-4 transition-all duration-500",
              mode === "akashic"
                ? "border-accent/20 bg-accent/5 shadow-[0_0_30px_rgba(var(--accent-rgb),0.1)]"
                : "border-border bg-card shadow-sm",
            )}
          >
            <h3
              className={cn(
                "font-mono text-sm uppercase tracking-wider",
                mode === "akashic" ? "text-accent" : "text-blue-400",
              )}
            >
              Publication Status
            </h3>

            <div className="space-y-3">
              {receipts.map((receipt, index) => (
                <div
                  key={index}
                  className={cn(
                    "flex items-center justify-between p-3 rounded-md border",
                    receipt.status === "success"
                      ? "bg-green-500/10 border-green-500/30"
                      : "bg-red-500/10 border-red-500/30",
                  )}
                >
                  <div className="flex items-center gap-3">
                    {receipt.status === "success" ? (
                      <CheckCircle2 className="size-5 text-green-400" />
                    ) : (
                      <AlertCircle className="size-5 text-red-400" />
                    )}
                    <div>
                      <p className="font-mono text-sm font-medium capitalize">{receipt.platform}</p>
                      {receipt.id && <p className="text-xs text-muted-foreground">ID: {receipt.id}</p>}
                      {receipt.error && <p className="text-xs text-red-400">{receipt.error}</p>}
                    </div>
                  </div>
                  <Badge variant={receipt.status === "success" ? "default" : "destructive"}>
                    {receipt.status === "success" ? "Published" : "Failed"}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Info */}
        <div
          className={cn(
            "rounded-lg border p-4 transition-all duration-500",
            mode === "akashic" ? "border-accent/10 bg-accent/[0.02]" : "border-border/50 bg-card/50",
          )}
        >
          <p className="text-sm text-muted-foreground leading-relaxed">
            {mode === "akashic"
              ? "This vault receives transmissions from AKIRA Engine. All external publishing is governed here. No redirects away from WIRED CHAOS."
              : "This console receives drafts from AKIRA Engine. All external publishing operations are managed here. System remains within WIRED CHAOS boundaries."}
          </p>
        </div>
      </div>
    </main>
  )
}
