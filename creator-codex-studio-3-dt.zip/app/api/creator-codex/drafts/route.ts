import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const draftId = searchParams.get("draftId")

  if (!draftId) {
    return NextResponse.json({ error: "Missing draftId" }, { status: 400 })
  }

  // Stub: Return mock draft data
  // In production, this would fetch from your database
  const mockDraft = {
    id: draftId,
    title: "Sample Draft from AKIRA Engine",
    body: "This is the full body content of the draft. It would come from the AKIRA Engine submission.",
    excerpt: "Brief summary of the draft content for preview purposes.",
    coverImageUrl: "https://placeholder.svg?height=400&width=800",
    tags: ["wired-chaos", "creator-codex", "akira-engine"],
    canonStatus: "pending",
    createdAt: new Date().toISOString(),
  }

  return NextResponse.json(mockDraft)
}
