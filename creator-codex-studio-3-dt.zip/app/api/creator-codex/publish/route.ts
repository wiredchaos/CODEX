import { type NextRequest, NextResponse } from "next/server"
import { publishToParagraph } from "@/lib/services/publishing/paragraph-publisher"

interface PublishRequest {
  draft: {
    title: string
    body: string
    excerpt: string
    coverImageUrl: string
    tags: string[]
  }
  platforms: string[]
}

export async function POST(request: NextRequest) {
  try {
    const body: PublishRequest = await request.json()
    const { draft, platforms } = body

    const receipts = []

    const publishPromises = platforms.map(async (platform) => {
      try {
        if (platform === "paragraph") {
          // Server-side Paragraph SDK integration
          const result = await publishToParagraph(draft)
          return {
            platform: "paragraph",
            status: "success" as const,
            id: result.id,
            url: result.url,
            publishedAt: result.publishedAt,
          }
        } else if (platform === "cbe") {
          // Delegate to CBE stub route
          const response = await fetch(
            `${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/api/cbe/publish`,
            {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(draft),
            },
          )
          const result = await response.json()
          return {
            platform: "cbe",
            status: "success" as const,
            id: result.id,
            url: result.url,
            publishedAt: result.publishedAt,
          }
        } else if (platform === "clear") {
          // Delegate to CLEAR stub route
          const response = await fetch(
            `${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/api/clear/publish`,
            {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(draft),
            },
          )
          const result = await response.json()
          return {
            platform: "clear",
            status: "success" as const,
            id: result.id,
            url: result.url,
            publishedAt: result.publishedAt,
          }
        }
      } catch (error) {
        return {
          platform,
          status: "error" as const,
          error: error instanceof Error ? error.message : "Publishing failed",
        }
      }
    })

    receipts.push(...(await Promise.all(publishPromises)))

    return NextResponse.json({ receipts })
  } catch (error) {
    console.error("[v0] Publishing error:", error)
    return NextResponse.json({ error: "Publishing system error" }, { status: 500 })
  }
}
