import { type NextRequest, NextResponse } from "next/server"

interface HandoffRequest {
  title: string
  content: string
  mode: "akashic" | "business"
}

export async function POST(request: NextRequest) {
  try {
    const body: HandoffRequest = await request.json()
    const { title, content, mode } = body

    if (!title || !content) {
      return NextResponse.json({ error: "Title and content required" }, { status: 400 })
    }

    // Create draft in Creator Codex system
    const draftId = `draft_${Date.now()}_${Math.random().toString(36).substring(7)}`

    // Store draft (stub - in production would save to database)
    console.log("[v0] AKIRA Engine handoff:", { draftId, title, mode })

    // Generate redirect URL to Creator Codex with draft loaded
    const nextUrl = `/creator-codex/self-publishing?draftId=${draftId}`

    return NextResponse.json({
      success: true,
      draftId,
      nextUrl,
      message: "Draft submitted to Creator Codex",
    })
  } catch (error) {
    console.error("[v0] Handoff error:", error)
    return NextResponse.json({ error: "Handoff system error" }, { status: 500 })
  }
}
