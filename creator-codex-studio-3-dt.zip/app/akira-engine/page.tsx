"use client"

import { useWcMode } from "@/lib/wc-mode"
import { WcModeToggle } from "@/components/wc-mode-toggle"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useState } from "react"
import { cn } from "@/lib/utils"

export default function AkiraEnginePage() {
  const { mode } = useWcMode()
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)

  const subtitle = mode === "akashic" ? "Generate. Expand. Convert. Handoff." : "Draft. Refine. Package. Submit."

  const handleSubmit = async () => {
    setIsGenerating(true)
    try {
      const response = await fetch("/api/akira-engine/handoff", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, content, mode }),
      })

      const result = await response.json()

      if (result.success && result.nextUrl) {
        // Redirect to Creator Codex with draft loaded
        window.location.href = result.nextUrl
      } else {
        console.error("[v0] Handoff failed:", result.error)
        alert("Failed to submit to Creator Codex")
      }
    } catch (error) {
      console.error("[v0] Handoff error:", error)
      alert("System error during handoff")
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <main
      className={cn(
        "min-h-screen p-8 transition-colors duration-500",
        mode === "akashic" ? "bg-gradient-to-br from-background via-background to-accent/5" : "bg-background",
      )}
    >
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header with Toggle */}
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <h1
              className={cn(
                "text-4xl font-bold tracking-tight transition-all duration-300",
                mode === "akashic"
                  ? "text-foreground bg-gradient-to-r from-accent to-accent/50 bg-clip-text text-transparent"
                  : "text-foreground",
              )}
            >
              AKIRA Engine
            </h1>
            <p
              className={cn(
                "font-mono text-sm uppercase tracking-wider transition-colors duration-300",
                mode === "akashic" ? "text-accent/80" : "text-blue-400",
              )}
            >
              {subtitle}
            </p>
          </div>
          <WcModeToggle />
        </div>

        {/* Main Content Area */}
        <div
          className={cn(
            "rounded-lg border p-6 space-y-6 transition-all duration-500",
            mode === "akashic"
              ? "border-accent/20 bg-accent/5 shadow-[0_0_30px_rgba(var(--accent-rgb),0.1)]"
              : "border-border bg-card shadow-sm",
          )}
        >
          <div className="space-y-2">
            <Label
              htmlFor="title"
              className={cn(
                "font-mono text-xs uppercase tracking-wider",
                mode === "akashic" ? "text-accent" : "text-blue-400",
              )}
            >
              Title
            </Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={mode === "akashic" ? "Enter codex title..." : "Enter document title..."}
              className={cn(
                "transition-all duration-300",
                mode === "akashic"
                  ? "border-accent/30 focus-visible:ring-accent/50"
                  : "border-border focus-visible:ring-blue-500/50",
              )}
            />
          </div>

          <div className="space-y-2">
            <Label
              htmlFor="content"
              className={cn(
                "font-mono text-xs uppercase tracking-wider",
                mode === "akashic" ? "text-accent" : "text-blue-400",
              )}
            >
              Content
            </Label>
            <Textarea
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder={mode === "akashic" ? "Channel your vision into the vault..." : "Enter your content here..."}
              rows={12}
              className={cn(
                "resize-none transition-all duration-300",
                mode === "akashic"
                  ? "border-accent/30 focus-visible:ring-accent/50"
                  : "border-border focus-visible:ring-blue-500/50",
              )}
            />
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-border/20">
            <p className={cn("font-mono text-xs", mode === "akashic" ? "text-accent/60" : "text-muted-foreground")}>
              {mode === "akashic" ? "Canon governed by Akira Codex" : "Canon validation pending"}
            </p>

            <Button
              onClick={handleSubmit}
              disabled={!title || !content || isGenerating}
              className={cn(
                "font-mono uppercase tracking-wider transition-all duration-300",
                mode === "akashic"
                  ? "bg-accent/20 text-accent border border-accent/40 hover:bg-accent/30 hover:shadow-[0_0_20px_rgba(var(--accent-rgb),0.3)]"
                  : "bg-blue-600 text-white hover:bg-blue-700",
              )}
            >
              {isGenerating ? "Submitting..." : "Submit to Creator Codex"}
            </Button>
          </div>
        </div>

        {/* Info Panel */}
        <div
          className={cn(
            "rounded-lg border p-4 transition-all duration-500",
            mode === "akashic" ? "border-accent/10 bg-accent/[0.02]" : "border-border/50 bg-card/50",
          )}
        >
          <h3
            className={cn(
              "font-mono text-xs uppercase tracking-wider mb-2",
              mode === "akashic" ? "text-accent" : "text-blue-400",
            )}
          >
            {mode === "akashic" ? "Sigil Protocol" : "Operator Console"}
          </h3>
          <p className="text-sm text-muted-foreground leading-relaxed">
            {mode === "akashic"
              ? "This interface channels your creative output into the Creator Codex vault. All submissions are indexed within the Akashic realm for mystical governance and eternal preservation."
              : "This console packages your drafts for submission to the Creator Codex. All documents are processed through standard validation protocols before distribution."}
          </p>
        </div>
      </div>
    </main>
  )
}
