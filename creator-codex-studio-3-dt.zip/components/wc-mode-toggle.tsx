"use client"

import { useWcMode } from "@/lib/wc-mode"
import { cn } from "@/lib/utils"

export function WcModeToggle() {
  const { mode, setMode } = useWcMode()

  return (
    <div
      className="inline-flex items-center gap-2 rounded-full p-1 backdrop-blur-md"
      style={{
        background: "var(--wc-glass)",
        border: "1px solid rgba(255,255,255,0.1)",
        boxShadow: "inset 0 1px 1px rgba(255,255,255,0.1), 0 0 20px rgba(0,245,255,0.1)",
      }}
    >
      <button
        onClick={() => setMode("akashic")}
        className={cn(
          "px-4 py-1.5 rounded-full font-mono text-xs uppercase tracking-wider transition-all duration-300",
          mode === "akashic" ? "backdrop-blur-sm" : "text-muted-foreground hover:text-foreground",
        )}
        style={
          mode === "akashic"
            ? {
                background: "rgba(0, 245, 255, 0.15)",
                color: "var(--wc-cyan)",
                boxShadow: "0 0 16px rgba(0, 245, 255, 0.4), inset 0 0 12px rgba(0, 245, 255, 0.2)",
              }
            : {}
        }
      >
        Akashic
      </button>
      <button
        onClick={() => setMode("business")}
        className={cn(
          "px-4 py-1.5 rounded-full font-mono text-xs uppercase tracking-wider transition-all duration-300",
          mode === "business" ? "backdrop-blur-sm" : "text-muted-foreground hover:text-foreground",
        )}
        style={
          mode === "business"
            ? {
                background: "rgba(57, 255, 20, 0.15)",
                color: "var(--wc-lime)",
                boxShadow: "0 0 16px rgba(57, 255, 20, 0.4), inset 0 0 12px rgba(57, 255, 20, 0.2)",
              }
            : {}
        }
      >
        Business
      </button>
    </div>
  )
}
