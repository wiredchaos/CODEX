"use client"

import { useEffect } from "react"

export function MotherboardCircuits() {
  useEffect(() => {
    // Animate circuit pulses
    const pulseElements = document.querySelectorAll<SVGCircleElement>(".circuit-pulse")

    pulseElements.forEach((pulse, index) => {
      // Stagger animation start times
      setTimeout(() => {
        pulse.style.animation = `pulse-glow ${2 + Math.random() * 2}s ease-in-out infinite`
      }, index * 300)
    })
  }, [])

  return (
    <div className="fixed inset-0 pointer-events-none z-0" aria-hidden="true">
      {/* SVG Circuit Layer */}
      <svg
        className="absolute inset-0 w-full h-full opacity-30"
        xmlns="http://www.w3.org/2000/svg"
        preserveAspectRatio="xMidYMid slice"
      >
        <defs>
          {/* Cyan circuit glow filter */}
          <filter id="cyan-glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="2" result="blur" />
            <feFlood floodColor="#00f5ff" floodOpacity="0.6" result="color" />
            <feComposite in="color" in2="blur" operator="in" result="glow" />
            <feMerge>
              <feMergeNode in="glow" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          {/* Red pulse glow filter */}
          <filter id="red-glow" x="-100%" y="-100%" width="300%" height="300%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="3" result="blur" />
            <feFlood floodColor="#ff3131" floodOpacity="0.8" result="color" />
            <feComposite in="color" in2="blur" operator="in" result="glow" />
            <feMerge>
              <feMergeNode in="glow" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          {/* Lime system alive filter */}
          <filter id="lime-glow" x="-100%" y="-100%" width="300%" height="300%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="4" result="blur" />
            <feFlood floodColor="#39ff14" floodOpacity="0.7" result="color" />
            <feComposite in="color" in2="blur" operator="in" result="glow" />
            <feMerge>
              <feMergeNode in="glow" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          {/* Animated gradient for circuit traces */}
          <linearGradient id="circuit-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#00f5ff" stopOpacity="0.1">
              <animate attributeName="stopOpacity" values="0.1;0.4;0.1" dur="3s" repeatCount="indefinite" />
            </stop>
            <stop offset="50%" stopColor="#00f5ff" stopOpacity="0.3">
              <animate attributeName="stopOpacity" values="0.3;0.6;0.3" dur="3s" repeatCount="indefinite" />
            </stop>
            <stop offset="100%" stopColor="#00f5ff" stopOpacity="0.1">
              <animate attributeName="stopOpacity" values="0.1;0.4;0.1" dur="3s" repeatCount="indefinite" />
            </stop>
          </linearGradient>
        </defs>

        {/* Horizontal circuit traces with gradient drift */}
        <g className="circuit-traces-horizontal">
          <line x1="0" y1="15%" x2="100%" y2="15%" stroke="url(#circuit-gradient)" strokeWidth="1" />
          <line x1="0" y1="35%" x2="100%" y2="35%" stroke="url(#circuit-gradient)" strokeWidth="1" />
          <line x1="0" y1="65%" x2="100%" y2="65%" stroke="url(#circuit-gradient)" strokeWidth="1" />
          <line x1="0" y1="85%" x2="100%" y2="85%" stroke="url(#circuit-gradient)" strokeWidth="1" />
        </g>

        {/* Vertical circuit traces */}
        <g className="circuit-traces-vertical">
          <line x1="20%" y1="0" x2="20%" y2="100%" stroke="url(#circuit-gradient)" strokeWidth="1" />
          <line x1="45%" y1="0" x2="45%" y2="100%" stroke="url(#circuit-gradient)" strokeWidth="1" />
          <line x1="70%" y1="0" x2="70%" y2="100%" stroke="url(#circuit-gradient)" strokeWidth="1" />
          <line x1="90%" y1="0" x2="90%" y2="100%" stroke="url(#circuit-gradient)" strokeWidth="1" />
        </g>

        {/* Red pulses at intersections */}
        <g className="circuit-intersections">
          <circle className="circuit-pulse" cx="20%" cy="15%" r="3" fill="#ff3131" filter="url(#red-glow)" />
          <circle className="circuit-pulse" cx="45%" cy="35%" r="3" fill="#ff3131" filter="url(#red-glow)" />
          <circle className="circuit-pulse" cx="70%" cy="65%" r="3" fill="#ff3131" filter="url(#red-glow)" />
          <circle className="circuit-pulse" cx="90%" cy="85%" r="3" fill="#ff3131" filter="url(#red-glow)" />
          <circle className="circuit-pulse" cx="20%" cy="85%" r="3" fill="#ff3131" filter="url(#red-glow)" />
          <circle className="circuit-pulse" cx="70%" cy="15%" r="3" fill="#ff3131" filter="url(#red-glow)" />
        </g>

        {/* Very rare lime system alive signals */}
        <g className="system-alive-signals">
          <circle cx="10%" cy="50%" r="2" fill="#39ff14" filter="url(#lime-glow)" opacity="0.6">
            <animate attributeName="opacity" values="0.3;0.8;0.3" dur="4s" repeatCount="indefinite" />
          </circle>
          <circle cx="85%" cy="25%" r="2" fill="#39ff14" filter="url(#lime-glow)" opacity="0.6">
            <animate attributeName="opacity" values="0.3;0.8;0.3" dur="5s" repeatCount="indefinite" />
          </circle>
        </g>
      </svg>

      {/* CSS gradient overlay for additional depth */}
      <div className="absolute inset-0 bg-gradient-to-br from-transparent via-transparent to-cyan-950/5" />
    </div>
  )
}
