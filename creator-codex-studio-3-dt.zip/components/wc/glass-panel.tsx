import { cn } from "@/lib/utils"
import type { ReactNode } from "react"

interface GlassPanelProps {
  children: ReactNode
  variant?: "akashic" | "business"
  className?: string
}

export function GlassPanel({ children, variant = "business", className }: GlassPanelProps) {
  return (
    <div
      className={cn(
        "relative rounded-sm",
        "border-2",
        variant === "akashic" && "border-cyan-400/50",
        variant === "business" && "border-cyan-400/45",
        "bg-black/[0.03]",
        variant === "akashic" && "shadow-[0_0_20px_rgba(0,245,255,0.2),0_4px_12px_rgba(0,0,0,0.6)]",
        variant === "business" && "shadow-[0_0_16px_rgba(0,245,255,0.15),0_4px_12px_rgba(0,0,0,0.6)]",
        className,
      )}
      style={{
        backdropFilter: "none !important",
        WebkitBackdropFilter: "none !important",
      }}
    >
      <div
        className="absolute top-0 left-0 right-1/2 h-[2px] pointer-events-none opacity-70"
        style={{
          background: "linear-gradient(90deg, rgba(0,245,255,0.9), transparent)",
        }}
      />

      <div
        className="absolute inset-[1px] rounded-sm pointer-events-none"
        style={{
          boxShadow: "inset 0 1px 2px rgba(0,245,255,0.6), inset 0 -1px 1px rgba(0,245,255,0.4)",
        }}
      />

      <div
        className="absolute inset-0 rounded-sm pointer-events-none opacity-[0.02]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
        }}
      />

      <div className="relative z-10 pointer-events-auto">{children}</div>
    </div>
  )
}
