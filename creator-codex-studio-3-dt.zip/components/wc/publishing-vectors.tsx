"use client"

import { useEffect, useRef, useState } from "react"

export function PublishingVectors() {
  const canvasRef = useRef<HTMLDivElement>(null)
  const [mousePos, setMousePos] = useState({ x: 0.5, y: 0.5 })
  const animationRef = useRef<number>()
  const timeRef = useRef(0)

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (canvasRef.current) {
        const rect = canvasRef.current.getBoundingClientRect()
        setMousePos({
          x: e.clientX / rect.width,
          y: e.clientY / rect.height,
        })
      }
    }

    window.addEventListener("mousemove", handleMouseMove)
    return () => window.removeEventListener("mousemove", handleMouseMove)
  }, [])

  useEffect(() => {
    const animate = () => {
      timeRef.current += 0.01
      animationRef.current = requestAnimationFrame(animate)
    }
    animate()
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [])

  const inkStreams = [
    { startX: 10, startY: 20, endX: 40, endY: 80, color: "cyan", delay: 0 },
    { startX: 60, startY: 10, endX: 85, endY: 60, color: "cyan", delay: 1 },
    { startX: 30, startY: 70, endX: 70, endY: 40, color: "red", delay: 2 },
  ]

  const glyphBlocks = [
    { x: 15, y: 30, size: 8, delay: 0 },
    { x: 45, y: 60, size: 6, delay: 0.5 },
    { x: 75, y: 25, size: 10, delay: 1 },
    { x: 25, y: 80, size: 7, delay: 1.5 },
    { x: 85, y: 70, size: 9, delay: 2 },
  ]

  // Publishing pipeline nodes
  const pipelineNodes = [
    { x: 20, y: 50, label: "draft", color: "cyan" },
    { x: 50, y: 50, label: "validate", color: "lime" },
    { x: 80, y: 50, label: "distribute", color: "red" },
  ]

  return (
    <div ref={canvasRef} className="fixed inset-0 pointer-events-none z-[5]" aria-hidden="true">
      <svg
        className="absolute inset-0 w-full h-full opacity-25"
        xmlns="http://www.w3.org/2000/svg"
        preserveAspectRatio="xMidYMid slice"
        style={{
          transform: `translate(${(mousePos.x - 0.5) * 20}px, ${(mousePos.y - 0.5) * 20}px)`,
          transition: "transform 0.3s ease-out",
        }}
      >
        <defs>
          <filter id="ink-cyan-glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="0.8" />
            <feFlood floodColor="#00f5ff" floodOpacity="0.3" />
            <feComposite in2="SourceGraphic" operator="in" />
            <feMerge>
              <feMergeNode />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          <filter id="ink-red-glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="0.8" />
            <feFlood floodColor="#ff3131" floodOpacity="0.3" />
            <feComposite in2="SourceGraphic" operator="in" />
            <feMerge>
              <feMergeNode />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          <filter id="ink-lime-glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="0.8" />
            <feFlood floodColor="#39ff14" floodOpacity="0.3" />
            <feComposite in2="SourceGraphic" operator="in" />
            <feMerge>
              <feMergeNode />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        <g className="ink-streams">
          {inkStreams.map((stream, i) => {
            const controlX = (stream.startX + stream.endX) / 2 + Math.sin(timeRef.current + stream.delay) * 10
            const controlY = (stream.startY + stream.endY) / 2 + Math.cos(timeRef.current + stream.delay) * 10

            return (
              <path
                key={`stream-${i}`}
                d={`M ${stream.startX}% ${stream.startY}% Q ${controlX}% ${controlY}% ${stream.endX}% ${stream.endY}%`}
                stroke={stream.color === "cyan" ? "#00f5ff" : "#ff3131"}
                strokeWidth="1.2"
                fill="none"
                opacity="0.6"
                filter={stream.color === "cyan" ? "url(#ink-cyan-glow)" : "url(#ink-red-glow)"}
                style={{
                  strokeDasharray: "200",
                  strokeDashoffset: Math.sin(timeRef.current * 0.5 + stream.delay) * 100 + 100,
                }}
              />
            )
          })}
        </g>

        <g className="glyph-blocks">
          {glyphBlocks.map((block, i) => {
            const offsetX = Math.sin(timeRef.current * 0.5 + block.delay) * 2
            const offsetY = Math.cos(timeRef.current * 0.3 + block.delay) * 3
            const rotation = Math.sin(timeRef.current * 0.2 + block.delay) * 5

            return (
              <g
                key={`glyph-${i}`}
                transform={`translate(${block.x + offsetX}%, ${block.y + offsetY}%) rotate(${rotation})`}
              >
                <rect
                  x="0"
                  y="0"
                  width={block.size}
                  height={block.size}
                  fill="none"
                  stroke="#00f5ff"
                  strokeWidth="1"
                  opacity="0.5"
                  filter="url(#ink-cyan-glow)"
                />
              </g>
            )
          })}
        </g>

        <g className="pipeline">
          {pipelineNodes.map((node, i) => {
            const scale = 1 + Math.sin(timeRef.current + i) * 0.1

            return (
              <g key={`node-${i}`}>
                <circle
                  cx={`${node.x}%`}
                  cy={`${node.y}%`}
                  r="4"
                  fill="none"
                  stroke={node.color === "cyan" ? "#00f5ff" : node.color === "lime" ? "#39ff14" : "#ff3131"}
                  strokeWidth="1.5"
                  opacity="0.6"
                  filter={`url(#ink-${node.color}-glow)`}
                  style={{ transform: `scale(${scale})`, transformOrigin: `${node.x}% ${node.y}%` }}
                />

                {/* Arrow to next node */}
                {i < 2 && (
                  <line
                    x1={`${node.x}%`}
                    y1={`${node.y}%`}
                    x2={`${node.x + 30}%`}
                    y2={`${node.y}%`}
                    stroke={node.color === "cyan" ? "#00f5ff" : node.color === "lime" ? "#39ff14" : "#ff3131"}
                    strokeWidth="1"
                    opacity="0.5"
                    markerEnd="url(#arrow)"
                  />
                )}
              </g>
            )
          })}

          <defs>
            <marker
              id="arrow"
              markerWidth="10"
              markerHeight="10"
              refX="5"
              refY="3"
              orient="auto"
              markerUnits="strokeWidth"
            >
              <path d="M0,0 L0,6 L9,3 z" fill="#00f5ff" opacity="0.6" />
            </marker>
          </defs>
        </g>

        <g className="quill-elements">
          <path
            d="M 90% 15% L 92% 25% M 88% 18% L 90% 28%"
            stroke="#00f5ff"
            strokeWidth="1"
            opacity="0.4"
            filter="url(#ink-cyan-glow)"
          >
            <animateTransform
              attributeName="transform"
              type="rotate"
              from="0 91 20"
              to="10 91 20"
              dur="3s"
              repeatCount="indefinite"
            />
          </path>

          <path
            d="M 5% 5% L 12% 5% L 12% 10% L 10% 10% Z"
            fill="none"
            stroke="#00f5ff"
            strokeWidth="1"
            opacity="0.3"
            filter="url(#ink-cyan-glow)"
          />
        </g>

        <circle
          cx={`${mousePos.x * 100}%`}
          cy={`${mousePos.y * 100}%`}
          r="30"
          fill="none"
          stroke="#00f5ff"
          strokeWidth="1"
          opacity="0.2"
          style={{
            transition: "r 0.3s ease-out",
          }}
        />
      </svg>
    </div>
  )
}
