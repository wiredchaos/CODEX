"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"

export type WcMode = "akashic" | "business"

interface WcModeStore {
  mode: WcMode
  setMode: (mode: WcMode) => void
}

export const useWcMode = create<WcModeStore>()(
  persist(
    (set) => ({
      mode: "akashic",
      setMode: (mode) => set({ mode }),
    }),
    {
      name: "wc_mode",
    },
  ),
)

export function getMode(): WcMode {
  if (typeof window === "undefined") return "akashic"
  const stored = localStorage.getItem("wc_mode")
  if (stored) {
    try {
      const parsed = JSON.parse(stored)
      return parsed.state?.mode || "akashic"
    } catch {
      return "akashic"
    }
  }
  return "akashic"
}

export function setMode(mode: WcMode): void {
  if (typeof window === "undefined") return
  useWcMode.getState().setMode(mode)
}
