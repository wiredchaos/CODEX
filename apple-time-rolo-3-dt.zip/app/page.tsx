import { TimeMachineRolodex } from "@/components/time-machine-rolodex"

export default function Page() {
  return (
    <div className="flex flex-col">
      <section className="w-full max-w-6xl mx-auto mb-12 px-4">
        <div className="space-y-6">
          <img
            src="/images/1-welcome.png"
            alt="Welcome - This space helps you explore information clearly, one moment at a time"
            className="w-full rounded-xl"
            loading="eager"
          />
          <img
            src="/images/2-how-the-timeline-works.png"
            alt="How the Timeline Works - Each card represents a moment in time"
            className="w-full rounded-xl"
            loading="lazy"
          />
          <img
            src="/images/3-you-are-in-system-mode.png"
            alt="You Are in System Mode - Designed for clarity and guidance"
            className="w-full rounded-xl"
            loading="lazy"
          />
          <img
            src="/images/4-youre-always-in-control.png"
            alt="You're Always in Control - Exit or return anytime"
            className="w-full rounded-xl"
            loading="lazy"
          />
          <img
            src="/images/5-youre-ready.png"
            alt="You're Ready - Scroll the timeline or select a date to begin exploring"
            className="w-full rounded-xl"
            loading="lazy"
          />
        </div>
      </section>
      <TimeMachineRolodex />
    </div>
  )
}
