// NETERU APINAYA ARTIFACT TERMINAL - TYPE DEFINITIONS

export type Chain = "XRPL" | "SOL" | "ETH" | "HBAR"
export type Realm = "Desert" | "Neon" | "Ancestral Tech" | "Oceana Water"
export type NFTState = "SYNCED" | "DESYNCED" | "CORRUPTED" | "EVOLVED"
export type ExchangeType = "BASIC" | "NTRU_FUELED"
export type ResultQuality = "COMMON" | "RARE" | "EPIC" | "LEGENDARY"

export interface User {
  id: string
  wallet_address: string
  username?: string
  created_at: string
  last_active: string
}

export interface NTRUBalance {
  id: string
  user_id: string
  balance: number
  lifetime_earned: number
  lifetime_spent: number
  updated_at: string
}

export interface NFTCollection {
  id: string
  name: string
  contract_address: string
  chain: Chain
  realm: Realm
  created_at: string
}

export interface UserNFT {
  id: string
  user_id: string
  collection_id: string
  token_id: string
  metadata?: Record<string, any>
  acquired_at: string
  collection?: NFTCollection
}

export interface Dynamic404NFT {
  id: string
  nft_id: string
  current_state: NFTState
  desync_count: number
  last_mutation_epoch: number
  mutation_history: MutationRecord[]
  created_at: string
  updated_at: string
  nft?: UserNFT
}

export interface MutationRecord {
  epoch: number
  from_state: NFTState
  to_state: NFTState
  timestamp: string
}

export interface ExchangeHistory {
  id: string
  user_id: string
  exchange_type: ExchangeType
  input_nft_id?: string
  output_nft_id?: string
  ntru_cost: number
  result_quality?: ResultQuality
  timestamp: string
}

export interface MutationEpoch {
  id: string
  epoch_number: number
  start_date: string
  end_date: string
  chapter_theme?: string
  mutation_rules?: Record<string, any>
  created_at: string
}

export interface EchoEngineerSettings {
  id: string
  user_id: string
  is_power_user: boolean
  advanced_features_enabled: boolean
  custom_mutation_rules: Record<string, any>
  created_at: string
  updated_at: string
}

export interface ExchangeRequest {
  user_id: string
  exchange_type: ExchangeType
  input_nft_id?: string
  ntru_amount?: number
}

export interface ExchangeResult {
  success: boolean
  output_nft?: UserNFT
  result_quality?: ResultQuality
  ntru_spent: number
  message: string
}
