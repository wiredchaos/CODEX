import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.NEON_DATABASE_URL!)

// User Operations
export async function getUserByWallet(wallet_address: string) {
  const [user] = await sql`
    SELECT * FROM users WHERE wallet_address = ${wallet_address}
  `
  return user
}

export async function createUser(wallet_address: string, username?: string) {
  const [user] = await sql`
    INSERT INTO users (wallet_address, username)
    VALUES (${wallet_address}, ${username})
    RETURNING *
  `

  // Initialize NTRU balance
  await sql`
    INSERT INTO ntru_balances (user_id, balance)
    VALUES (${user.id}, 0)
  `

  return user
}

// NTRU Balance Operations
export async function getNTRUBalance(user_id: string) {
  const [balance] = await sql`
    SELECT * FROM ntru_balances WHERE user_id = ${user_id}
  `
  return balance
}

export async function updateNTRUBalance(user_id: string, amount: number, operation: "ADD" | "SUBTRACT") {
  if (operation === "ADD") {
    await sql`
      UPDATE ntru_balances
      SET balance = balance + ${amount},
          lifetime_earned = lifetime_earned + ${amount},
          updated_at = NOW()
      WHERE user_id = ${user_id}
    `
  } else {
    await sql`
      UPDATE ntru_balances
      SET balance = balance - ${amount},
          lifetime_spent = lifetime_spent + ${amount},
          updated_at = NOW()
      WHERE user_id = ${user_id}
    `
  }

  return getNTRUBalance(user_id)
}

// NFT Operations
export async function getUserNFTs(user_id: string) {
  const nfts = await sql`
    SELECT un.*, nc.name as collection_name, nc.chain, nc.realm
    FROM user_nfts un
    JOIN nft_collections nc ON un.collection_id = nc.id
    WHERE un.user_id = ${user_id}
    ORDER BY un.acquired_at DESC
  `
  return nfts
}

export async function get404Status(nft_id: string) {
  const [status] = await sql`
    SELECT * FROM dynamic_404_nfts WHERE nft_id = ${nft_id}
  `
  return status
}

export async function update404State(nft_id: string, new_state: string, epoch: number) {
  const current = await get404Status(nft_id)

  if (!current) {
    // Initialize 404 status
    await sql`
      INSERT INTO dynamic_404_nfts (nft_id, current_state, last_mutation_epoch)
      VALUES (${nft_id}, ${new_state}, ${epoch})
    `
  } else {
    const mutation_history = current.mutation_history || []
    mutation_history.push({
      epoch,
      from_state: current.current_state,
      to_state: new_state,
      timestamp: new Date().toISOString(),
    })

    await sql`
      UPDATE dynamic_404_nfts
      SET current_state = ${new_state},
          desync_count = desync_count + 1,
          last_mutation_epoch = ${epoch},
          mutation_history = ${JSON.stringify(mutation_history)},
          updated_at = NOW()
      WHERE nft_id = ${nft_id}
    `
  }
}

// Exchange Operations
export async function recordExchange(
  user_id: string,
  exchange_type: string,
  input_nft_id: string | null,
  output_nft_id: string | null,
  ntru_cost: number,
  result_quality: string,
) {
  const [exchange] = await sql`
    INSERT INTO exchange_history (
      user_id, exchange_type, input_nft_id, output_nft_id, ntru_cost, result_quality
    )
    VALUES (
      ${user_id}, ${exchange_type}, ${input_nft_id}, ${output_nft_id}, ${ntru_cost}, ${result_quality}
    )
    RETURNING *
  `
  return exchange
}

export async function getExchangeHistory(user_id: string, limit = 20) {
  const history = await sql`
    SELECT * FROM exchange_history
    WHERE user_id = ${user_id}
    ORDER BY timestamp DESC
    LIMIT ${limit}
  `
  return history
}

// Mutation Epoch Operations
export async function getCurrentEpoch() {
  const [epoch] = await sql`
    SELECT * FROM mutation_epochs
    WHERE start_date <= NOW() AND end_date >= NOW()
    ORDER BY epoch_number DESC
    LIMIT 1
  `
  return epoch
}

export async function createMutationEpoch(
  epoch_number: number,
  start_date: string,
  end_date: string,
  chapter_theme: string,
  mutation_rules: Record<string, any>,
) {
  const [epoch] = await sql`
    INSERT INTO mutation_epochs (epoch_number, start_date, end_date, chapter_theme, mutation_rules)
    VALUES (${epoch_number}, ${start_date}, ${end_date}, ${chapter_theme}, ${JSON.stringify(mutation_rules)})
    RETURNING *
  `
  return epoch
}
