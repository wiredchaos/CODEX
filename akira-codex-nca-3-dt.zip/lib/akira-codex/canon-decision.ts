/**
 * AKIRA CODEX — CANON DECISION SERVICE
 *
 * Evaluates canonization candidates and makes deterministic decisions.
 * NO UI. NO external SDK. Internal contracts only.
 *
 * WIRED CHAOS META | AKIRA CODEX
 */

import type { CanonizationCandidate, CanonDecision, CanonProbability, CanonProbabilityScore, LoreObject } from "./types"
import { CANON_THRESHOLDS } from "./types"
import {
  getLoreObjects,
  registerLoreObject,
  createLoreObjectFromCandidate,
  updateLoreObjectStatus,
} from "./canon-registry"

// In-memory decision registry (will be replaced with database in production)
const DECISION_REGISTRY = new Map<string, CanonDecision>()

/**
 * Submit a canonization candidate for review
 * Returns candidate ID for tracking
 */
export function submitCanonizationCandidate(payload: CanonizationCandidate): string {
  const loreObject = createLoreObjectFromCandidate(payload)
  registerLoreObject(loreObject)

  console.log(`[Akira Codex] Canonization candidate submitted: ${loreObject.id} - ${loreObject.name}`)

  // Automatically trigger evaluation
  evaluateCandidate(loreObject.id)

  return loreObject.id
}

/**
 * Get canon decision by candidate ID
 */
export function getCanonDecision(candidateId: string): CanonDecision | null {
  return DECISION_REGISTRY.get(candidateId) || null
}

/**
 * Evaluate canon probability for a candidate
 * Deterministic scoring algorithm
 */
export function evaluateCanonProbability(candidate: LoreObject): CanonProbabilityScore {
  const factors = {
    consistency: calculateConsistency(candidate),
    impact: calculateImpact(candidate),
    conflicts: calculateConflicts(candidate),
    source: calculateSourceAuthority(candidate),
    community: 5, // Default neutral score (not implemented yet)
  }

  // Weighted average
  const score = Math.round(
    (factors.consistency * 0.3 +
      factors.impact * 0.2 +
      factors.conflicts * 0.3 +
      factors.source * 0.15 +
      factors.community * 0.05) /
      1,
  ) as CanonProbability

  return {
    score: Math.max(0, Math.min(10, score)) as CanonProbability,
    factors,
    reasoning: generateReasoning(factors, score),
    timestamp: new Date(),
  }
}

/**
 * Evaluate a candidate and create a canon decision
 * Internal use
 */
function evaluateCandidate(candidateId: string): CanonDecision | null {
  const candidate = getLoreObjects().find((obj) => obj.id === candidateId)
  if (!candidate) return null

  const probabilityScore = evaluateCanonProbability(candidate)
  const conflicts = detectConflicts(candidate)

  let decision: CanonDecision["decision"] = "PENDING"

  if (probabilityScore.score >= CANON_THRESHOLDS.AUTO_APPROVE) {
    decision = "APPROVED"
    updateLoreObjectStatus(candidateId, "CANON")
  } else if (probabilityScore.score <= CANON_THRESHOLDS.AUTO_REJECT) {
    decision = "REJECTED"
    updateLoreObjectStatus(candidateId, "REJECTED")
  } else if (probabilityScore.score >= CANON_THRESHOLDS.REQUIRES_REVIEW) {
    decision = "REQUIRES_REVIEW"
  } else {
    decision = "PENDING"
  }

  const canonDecision: CanonDecision = {
    id: `decision_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    candidateId,
    decision,
    canonProbability: probabilityScore.score,
    reasoning: probabilityScore.reasoning,
    decidedAt: new Date(),
    decidedBy: "AKIRA_CODEX",
    conflicts: conflicts.map((c) => c.id),
    recommendations: generateRecommendations(candidate, probabilityScore, conflicts),
    metadata: {
      factors: probabilityScore.factors,
    },
  }

  DECISION_REGISTRY.set(candidateId, canonDecision)

  console.log(
    `[Akira Codex] Canon decision made for ${candidateId}: ${decision} (probability: ${probabilityScore.score}/10)`,
  )

  return canonDecision
}

// Helper functions for deterministic scoring

function calculateConsistency(candidate: LoreObject): number {
  // Check consistency with existing canon
  const existingObjects = getLoreObjects({
    type: candidate.type,
    status: "CANON",
    realm: candidate.realm,
  })

  if (existingObjects.length === 0) return 8 // New type/realm gets high consistency

  // Check for naming conflicts
  const nameConflicts = existingObjects.filter((obj) => obj.name.toLowerCase() === candidate.name.toLowerCase())
  if (nameConflicts.length > 0) return 2

  // Check for description similarities (basic check)
  const descriptionOverlap = existingObjects.filter((obj) =>
    obj.description.toLowerCase().includes(candidate.name.toLowerCase()),
  )
  if (descriptionOverlap.length > 0) return 5

  return 8
}

function calculateImpact(candidate: LoreObject): number {
  // Assess narrative significance based on type and metadata
  const impactScores: Record<string, number> = {
    NETERU: 10,
    TIMELINE: 9,
    REALM: 9,
    EVENT: 7,
    CHARACTER: 6,
    LOCATION: 6,
    ARTIFACT: 5,
    CONCEPT: 5,
    PATCH: 4,
  }

  return impactScores[candidate.type] || 5
}

function calculateConflicts(candidate: LoreObject): number {
  const conflicts = detectConflicts(candidate)
  // Invert: more conflicts = lower score
  return Math.max(0, 10 - conflicts.length * 2)
}

function calculateSourceAuthority(candidate: LoreObject): number {
  // Score based on source authority
  const authorityScores: Record<string, number> = {
    "WIRED CHAOS META": 10,
    "AKIRA CODEX": 10,
    "CREATOR CODEX": 8,
    "SIGNAL FORGE": 7,
    COMMUNITY: 5,
    UNKNOWN: 3,
  }

  return authorityScores[candidate.source] || 5
}

function detectConflicts(candidate: LoreObject): LoreObject[] {
  // Find potential conflicts with existing canon
  return getLoreObjects({
    type: candidate.type,
    status: "CANON",
    realm: candidate.realm,
  }).filter((obj) => {
    // Name conflict
    if (obj.name.toLowerCase() === candidate.name.toLowerCase()) return true

    // Check related objects conflicts (simplified)
    if (candidate.relatedObjects.includes(obj.id)) return false

    return false
  })
}

function generateReasoning(factors: CanonProbabilityScore["factors"], score: CanonProbability): string {
  const reasons: string[] = []

  if (factors.consistency >= 8) reasons.push("High consistency with existing canon")
  if (factors.consistency <= 3) reasons.push("Low consistency - conflicts detected")

  if (factors.impact >= 8) reasons.push("High narrative impact")
  if (factors.impact <= 3) reasons.push("Low narrative significance")

  if (factors.conflicts >= 8) reasons.push("No conflicts detected")
  if (factors.conflicts <= 3) reasons.push("Multiple conflicts with existing canon")

  if (factors.source >= 8) reasons.push("Authoritative source")
  if (factors.source <= 3) reasons.push("Low source authority")

  if (score >= CANON_THRESHOLDS.AUTO_APPROVE) {
    reasons.push("AUTO-APPROVED: Meets all canon criteria")
  } else if (score <= CANON_THRESHOLDS.AUTO_REJECT) {
    reasons.push("AUTO-REJECTED: Does not meet canon criteria")
  } else if (score >= CANON_THRESHOLDS.REQUIRES_REVIEW) {
    reasons.push("REQUIRES REVIEW: Moderate canon probability")
  }

  return reasons.join(". ")
}

function generateRecommendations(
  candidate: LoreObject,
  score: CanonProbabilityScore,
  conflicts: LoreObject[],
): string[] {
  const recommendations: string[] = []

  if (conflicts.length > 0) {
    recommendations.push(`Resolve conflicts with: ${conflicts.map((c) => c.name).join(", ")}`)
  }

  if (score.factors.consistency < 5) {
    recommendations.push("Review for consistency with existing canon")
  }

  if (score.factors.source < 5) {
    recommendations.push("Verify source authority")
  }

  if (candidate.relatedObjects.length === 0) {
    recommendations.push("Consider linking to related lore objects")
  }

  return recommendations
}

/**
 * Get all decisions (for monitoring)
 */
export function getAllDecisions(): CanonDecision[] {
  return Array.from(DECISION_REGISTRY.values())
}
