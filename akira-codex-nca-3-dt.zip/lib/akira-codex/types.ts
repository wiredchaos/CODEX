/**
 * AKIRA CODEX — CANON AUTHORITY TYPES
 *
 * Role: Sole canon authority for WIRED CHAOS META
 * Responsibilities:
 * - Canon registry for all lore objects
 * - Canon probability evaluation
 * - Canon lock issuance and lifecycle
 * - Timeline / Floor access gating (read-only signals to Trinity)
 * - Canon decision API for downstream consumers
 *
 * Constraints:
 * - No creative authorship
 * - No UI responsibilities
 * - No Trinity ownership
 * - No lore invention
 * - No story generation
 * - No payment processing
 * - No 3D/timeline/floor creation
 *
 * WIRED CHAOS META | AKIRA CODEX
 */

// Lore Object Types
export type LoreObjectType =
  | "CHARACTER"
  | "LOCATION"
  | "ARTIFACT"
  | "EVENT"
  | "CONCEPT"
  | "TIMELINE"
  | "REALM"
  | "NETERU"
  | "PATCH"

export type LoreObjectStatus = "CANON" | "CANDIDATE" | "REJECTED" | "PENDING_REVIEW" | "LOCKED"

export type CanonProbability = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10

// Lore Object Registry Model
export interface LoreObject {
  id: string
  name: string
  type: LoreObjectType
  status: LoreObjectStatus
  canonProbability: CanonProbability
  description: string
  source: string // Origin patch or creator
  createdAt: Date
  updatedAt: Date
  lockedAt?: Date
  lockId?: string
  metadata: Record<string, unknown>
  tags: string[]
  relatedObjects: string[] // IDs of related lore objects
  realm?: "NEURALIS" | "CHAOSPHERE" | "AKIRA_SANCTUM" | "NETERU_DEPTHS"
  tier?: "BUSINESS" | "AKASHIC"
}

// Canon Lock Model
export interface CanonLock {
  id: string
  loreObjectId: string
  branchId?: string
  issuedAt: Date
  expiresAt?: Date
  status: "ACTIVE" | "EXPIRED" | "REVOKED"
  issuedBy: string // System or authority
  reason: string
  metadata: Record<string, unknown>
}

// Canon Decision Model
export interface CanonDecision {
  id: string
  candidateId: string
  decision: "APPROVED" | "REJECTED" | "PENDING" | "REQUIRES_REVIEW"
  canonProbability: CanonProbability
  reasoning: string
  decidedAt: Date
  decidedBy: "AKIRA_CODEX" | "CREATOR_CODEX" | "SIGNAL_FORGE"
  conflicts: string[] // Conflicting lore object IDs
  recommendations: string[]
  metadata: Record<string, unknown>
}

// Canonization Candidate Payload
export interface CanonizationCandidate {
  name: string
  type: LoreObjectType
  description: string
  source: string
  proposedBy: string
  realm?: "NEURALIS" | "CHAOSPHERE" | "AKIRA_SANCTUM" | "NETERU_DEPTHS"
  tier?: "BUSINESS" | "AKASHIC"
  metadata?: Record<string, unknown>
  tags?: string[]
  relatedObjects?: string[]
}

// Filter options for getLoreObjects
export interface LoreObjectFilter {
  type?: LoreObjectType | LoreObjectType[]
  status?: LoreObjectStatus | LoreObjectStatus[]
  realm?: "NEURALIS" | "CHAOSPHERE" | "AKIRA_SANCTUM" | "NETERU_DEPTHS"
  tier?: "BUSINESS" | "AKASHIC"
  tags?: string[]
  minCanonProbability?: CanonProbability
  locked?: boolean
  source?: string
}

// Timeline / Floor Access Signal (read-only)
export interface AccessGateSignal {
  floorId: string
  timelineId?: string
  requester: string
  requestedAt: Date
  grantAccess: boolean
  reason: string
  requiredCanonProbability?: CanonProbability
  requiredLoreObjects?: string[]
}

// Canon Probability Scoring Interface
export interface CanonProbabilityScore {
  score: CanonProbability
  factors: {
    consistency: number // 0-10: Alignment with existing canon
    impact: number // 0-10: Narrative significance
    conflicts: number // 0-10: Number of contradictions (inverted)
    source: number // 0-10: Authority of source
    community: number // 0-10: Community acceptance (if applicable)
  }
  reasoning: string
  timestamp: Date
}

// System Constants
export const CANON_THRESHOLDS = {
  AUTO_APPROVE: 9 as CanonProbability,
  REQUIRES_REVIEW: 5 as CanonProbability,
  AUTO_REJECT: 2 as CanonProbability,
} as const

export const LOCK_DURATIONS = {
  PERMANENT: null,
  ONE_YEAR: 365 * 24 * 60 * 60 * 1000,
  ONE_MONTH: 30 * 24 * 60 * 60 * 1000,
  ONE_WEEK: 7 * 24 * 60 * 60 * 1000,
} as const
