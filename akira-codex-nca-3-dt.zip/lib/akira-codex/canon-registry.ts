/**
 * AKIRA CODEX — CANON REGISTRY SERVICE
 *
 * Internal service for managing the lore object registry.
 * NO UI. NO external SDK. Internal contracts only.
 *
 * WIRED CHAOS META | AKIRA CODEX
 */

import type {
  LoreObject,
  LoreObjectFilter,
  CanonizationCandidate,
  CanonProbability,
  LoreObjectType,
  LoreObjectStatus,
} from "./types"

// In-memory registry (will be replaced with database in production)
const LORE_REGISTRY = new Map<string, LoreObject>()

/**
 * Get lore objects matching filter criteria
 * Internal contract for downstream consumers
 */
export function getLoreObjects(filter?: LoreObjectFilter): LoreObject[] {
  let objects = Array.from(LORE_REGISTRY.values())

  if (!filter) return objects

  // Filter by type
  if (filter.type) {
    const types = Array.isArray(filter.type) ? filter.type : [filter.type]
    objects = objects.filter((obj) => types.includes(obj.type))
  }

  // Filter by status
  if (filter.status) {
    const statuses = Array.isArray(filter.status) ? filter.status : [filter.status]
    objects = objects.filter((obj) => statuses.includes(obj.status))
  }

  // Filter by realm
  if (filter.realm) {
    objects = objects.filter((obj) => obj.realm === filter.realm)
  }

  // Filter by tier
  if (filter.tier) {
    objects = objects.filter((obj) => obj.tier === filter.tier)
  }

  // Filter by tags
  if (filter.tags && filter.tags.length > 0) {
    objects = objects.filter((obj) => filter.tags!.some((tag) => obj.tags.includes(tag)))
  }

  // Filter by minimum canon probability
  if (filter.minCanonProbability !== undefined) {
    objects = objects.filter((obj) => obj.canonProbability >= filter.minCanonProbability!)
  }

  // Filter by locked status
  if (filter.locked !== undefined) {
    objects = objects.filter((obj) => (filter.locked ? !!obj.lockId : !obj.lockId))
  }

  // Filter by source
  if (filter.source) {
    objects = objects.filter((obj) => obj.source === filter.source)
  }

  return objects
}

/**
 * Get a single lore object by ID
 */
export function getLoreObjectById(id: string): LoreObject | null {
  return LORE_REGISTRY.get(id) || null
}

/**
 * Register a new lore object (internal use)
 */
export function registerLoreObject(object: LoreObject): void {
  LORE_REGISTRY.set(object.id, object)
  console.log(`[Akira Codex] Lore object registered: ${object.id} - ${object.name}`)
}

/**
 * Update lore object status (internal use)
 */
export function updateLoreObjectStatus(id: string, status: LoreObjectStatus): boolean {
  const object = LORE_REGISTRY.get(id)
  if (!object) return false

  object.status = status
  object.updatedAt = new Date()
  LORE_REGISTRY.set(id, object)

  console.log(`[Akira Codex] Lore object ${id} status updated to ${status}`)
  return true
}

/**
 * Update canon probability (internal use)
 */
export function updateCanonProbability(id: string, probability: CanonProbability): boolean {
  const object = LORE_REGISTRY.get(id)
  if (!object) return false

  object.canonProbability = probability
  object.updatedAt = new Date()
  LORE_REGISTRY.set(id, object)

  console.log(`[Akira Codex] Lore object ${id} canon probability updated to ${probability}`)
  return true
}

/**
 * Create lore object from canonization candidate
 */
export function createLoreObjectFromCandidate(candidate: CanonizationCandidate): LoreObject {
  const now = new Date()
  const id = `lore_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`

  return {
    id,
    name: candidate.name,
    type: candidate.type,
    status: "PENDING_REVIEW",
    canonProbability: 5, // Default middle score
    description: candidate.description,
    source: candidate.source,
    createdAt: now,
    updatedAt: now,
    metadata: candidate.metadata || {},
    tags: candidate.tags || [],
    relatedObjects: candidate.relatedObjects || [],
    realm: candidate.realm,
    tier: candidate.tier,
  }
}

/**
 * Get canon statistics (for monitoring)
 */
export function getCanonStatistics() {
  const objects = Array.from(LORE_REGISTRY.values())

  return {
    total: objects.length,
    canon: objects.filter((o) => o.status === "CANON").length,
    pending: objects.filter((o) => o.status === "PENDING_REVIEW").length,
    rejected: objects.filter((o) => o.status === "REJECTED").length,
    locked: objects.filter((o) => !!o.lockId).length,
    byType: objects.reduce(
      (acc, obj) => {
        acc[obj.type] = (acc[obj.type] || 0) + 1
        return acc
      },
      {} as Record<LoreObjectType, number>,
    ),
    byRealm: objects.reduce(
      (acc, obj) => {
        if (obj.realm) {
          acc[obj.realm] = (acc[obj.realm] || 0) + 1
        }
        return acc
      },
      {} as Record<string, number>,
    ),
  }
}
