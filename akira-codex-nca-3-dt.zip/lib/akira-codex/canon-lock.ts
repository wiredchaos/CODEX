/**
 * AKIRA CODEX — CANON LOCK SERVICE
 *
 * Manages canon locks and lifecycle.
 * Prevents unauthorized modifications to locked lore.
 * NO UI. NO external SDK. Internal contracts only.
 *
 * WIRED CHAOS META | AKIRA CODEX
 */

import type { CanonLock } from "./types"
import { LOCK_DURATIONS } from "./types"
import { getLoreObjectById } from "./canon-registry"

// In-memory lock registry (will be replaced with database in production)
const LOCK_REGISTRY = new Map<string, CanonLock>()

/**
 * Issue a canon lock for a lore object
 */
export function issueCanonLock(
  loreObjectId: string,
  reason: string,
  duration: number | null = LOCK_DURATIONS.PERMANENT,
  issuedBy = "AKIRA_CODEX",
  branchId?: string,
): CanonLock | null {
  const loreObject = getLoreObjectById(loreObjectId)
  if (!loreObject) {
    console.error(`[Akira Codex] Cannot issue lock: Lore object ${loreObjectId} not found`)
    return null
  }

  if (loreObject.lockId) {
    console.warn(`[Akira Codex] Lore object ${loreObjectId} is already locked`)
    return getLockById(loreObject.lockId)
  }

  const now = new Date()
  const lock: CanonLock = {
    id: `lock_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    loreObjectId,
    branchId,
    issuedAt: now,
    expiresAt: duration ? new Date(now.getTime() + duration) : undefined,
    status: "ACTIVE",
    issuedBy,
    reason,
    metadata: {},
  }

  LOCK_REGISTRY.set(lock.id, lock)

  // Update lore object with lock
  loreObject.lockId = lock.id
  loreObject.lockedAt = now

  console.log(`[Akira Codex] Canon lock issued: ${lock.id} for lore object ${loreObjectId}`)

  return lock
}

/**
 * Get canon locks by branch ID
 */
export function getCanonLocks(branchId?: string): CanonLock[] {
  const locks = Array.from(LOCK_REGISTRY.values())

  if (!branchId) return locks.filter((lock) => lock.status === "ACTIVE")

  return locks.filter((lock) => lock.branchId === branchId && lock.status === "ACTIVE")
}

/**
 * Get lock by ID
 */
export function getLockById(lockId: string): CanonLock | null {
  return LOCK_REGISTRY.get(lockId) || null
}

/**
 * Check if a lore object is locked
 */
export function isLocked(loreObjectId: string): boolean {
  const loreObject = getLoreObjectById(loreObjectId)
  if (!loreObject || !loreObject.lockId) return false

  const lock = LOCK_REGISTRY.get(loreObject.lockId)
  if (!lock) return false

  // Check if lock is expired
  if (lock.expiresAt && lock.expiresAt < new Date()) {
    expireLock(lock.id)
    return false
  }

  return lock.status === "ACTIVE"
}

/**
 * Revoke a canon lock (internal use)
 */
export function revokeLock(lockId: string, reason: string): boolean {
  const lock = LOCK_REGISTRY.get(lockId)
  if (!lock) return false

  lock.status = "REVOKED"
  lock.metadata.revokedAt = new Date()
  lock.metadata.revocationReason = reason

  // Update lore object
  const loreObject = getLoreObjectById(lock.loreObjectId)
  if (loreObject) {
    loreObject.lockId = undefined
    loreObject.lockedAt = undefined
  }

  console.log(`[Akira Codex] Canon lock revoked: ${lockId} - ${reason}`)

  return true
}

/**
 * Expire a canon lock (internal use)
 */
function expireLock(lockId: string): boolean {
  const lock = LOCK_REGISTRY.get(lockId)
  if (!lock) return false

  lock.status = "EXPIRED"
  lock.metadata.expiredAt = new Date()

  // Update lore object
  const loreObject = getLoreObjectById(lock.loreObjectId)
  if (loreObject) {
    loreObject.lockId = undefined
    loreObject.lockedAt = undefined
  }

  console.log(`[Akira Codex] Canon lock expired: ${lockId}`)

  return true
}

/**
 * Process expired locks (should be called periodically)
 */
export function processExpiredLocks(): number {
  const now = new Date()
  let expiredCount = 0

  for (const lock of LOCK_REGISTRY.values()) {
    if (lock.status === "ACTIVE" && lock.expiresAt && lock.expiresAt < now) {
      expireLock(lock.id)
      expiredCount++
    }
  }

  if (expiredCount > 0) {
    console.log(`[Akira Codex] Processed ${expiredCount} expired locks`)
  }

  return expiredCount
}

/**
 * Get lock statistics
 */
export function getLockStatistics() {
  const locks = Array.from(LOCK_REGISTRY.values())

  return {
    total: locks.length,
    active: locks.filter((l) => l.status === "ACTIVE").length,
    expired: locks.filter((l) => l.status === "EXPIRED").length,
    revoked: locks.filter((l) => l.status === "REVOKED").length,
    permanent: locks.filter((l) => l.status === "ACTIVE" && !l.expiresAt).length,
  }
}
