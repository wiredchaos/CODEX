/**
 * AKIRA CODEX — ACCESS GATE SERVICE
 *
 * Timeline / Floor access gating (read-only signals to Trinity)
 * NO UI. NO external SDK. Internal contracts only.
 *
 * WIRED CHAOS META | AKIRA CODEX
 */

import type { AccessGateSignal, CanonProbability } from "./types"
import { TRINITY_FLOORS, type TrinityFloor, FLOOR_METADATA } from "../trinity-mount"
import { getLoreObjects } from "./canon-registry"

/**
 * Signal access gate decision to Trinity (read-only)
 * Returns signal for Trinity to consume
 */
export function signalFloorAccess(
  floorId: TrinityFloor,
  requester: string,
  requiredCanonProbability?: CanonProbability,
  requiredLoreObjects?: string[],
): AccessGateSignal {
  const metadata = FLOOR_METADATA[floorId]

  let grantAccess = false
  let reason = ""

  // Check floor status
  if (metadata.status === "OPEN") {
    grantAccess = true
    reason = "Floor is open to all"
  } else if (metadata.status === "LOCKED") {
    grantAccess = false
    reason = "Floor is locked - requires special access"
  } else if (metadata.status === "RESTRICTED") {
    grantAccess = false
    reason = "Floor is restricted - Akira Codex authorization required"
  }

  // Check canon probability requirements
  if (requiredCanonProbability !== undefined) {
    const requesterLore = getLoreObjects({ source: requester })
    const hasRequiredProbability = requesterLore.some((obj) => obj.canonProbability >= requiredCanonProbability)

    if (!hasRequiredProbability) {
      grantAccess = false
      reason = `Requires canon probability of ${requiredCanonProbability} or higher`
    }
  }

  // Check required lore objects
  if (requiredLoreObjects && requiredLoreObjects.length > 0) {
    const requesterLore = getLoreObjects({ source: requester })
    const hasAllRequired = requiredLoreObjects.every((reqId) => requesterLore.some((obj) => obj.id === reqId))

    if (!hasAllRequired) {
      grantAccess = false
      reason = "Missing required lore objects"
    }
  }

  const signal: AccessGateSignal = {
    floorId,
    requester,
    requestedAt: new Date(),
    grantAccess,
    reason,
    requiredCanonProbability,
    requiredLoreObjects,
  }

  console.log(
    `[Akira Codex] Access gate signal: ${floorId} - ${requester} - ${grantAccess ? "GRANTED" : "DENIED"} - ${reason}`,
  )

  return signal
}

/**
 * Check if floor is accessible (simplified check)
 */
export function isFloorAccessible(floorId: TrinityFloor): boolean {
  const metadata = FLOOR_METADATA[floorId]
  return metadata.status === "OPEN"
}

/**
 * Get access requirements for a floor
 */
export function getFloorAccessRequirements(floorId: TrinityFloor) {
  const metadata = FLOOR_METADATA[floorId]

  const requirements: {
    status: typeof metadata.status
    canonProbability?: CanonProbability
    loreObjects?: string[]
    description: string
  } = {
    status: metadata.status,
    description: "",
  }

  switch (floorId) {
    case TRINITY_FLOORS.NEURALIS:
      requirements.description = "Open to all - Realm of Neural Consciousness"
      break
    case TRINITY_FLOORS.CHAOSPHERE:
      requirements.description = "Open to all - Domain of Creative Chaos"
      break
    case TRINITY_FLOORS.AKIRA_SANCTUM:
      requirements.canonProbability = 8
      requirements.description = "Locked - Requires canon probability 8+ and Akira Codex approval"
      break
    case TRINITY_FLOORS.NETERU_DEPTHS:
      requirements.canonProbability = 9
      requirements.loreObjects = ["neteru_ancestral_key"]
      requirements.description = "Restricted - Requires canon probability 9+ and Ancestral Key"
      break
  }

  return requirements
}
