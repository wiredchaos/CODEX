/**
 * AKIRA CODEX — CANON AUTHORITY ENTRY POINT
 *
 * Internal contracts ONLY. NO UI. NO external SDK.
 *
 * Role:
 * - Sole canon authority for WIRED CHAOS META
 * - Canon registry for all lore objects
 * - Canon probability evaluation
 * - Canon lock issuance and lifecycle
 * - Timeline / Floor access gating (read-only signals to Trinity)
 * - Canon decision API for downstream consumers
 *
 * Compatible with:
 * - Creator Codex
 * - Signal Forge
 * - Environment Registry
 * - Trinity Timeline / Floor resolver (read-only)
 *
 * WIRED CHAOS META | AKIRA CODEX
 */

// Types
export type {
  LoreObject,
  LoreObjectType,
  LoreObjectStatus,
  LoreObjectFilter,
  CanonizationCandidate,
  CanonDecision,
  CanonLock,
  CanonProbability,
  CanonProbabilityScore,
  AccessGateSignal,
} from "./types"

export { CANON_THRESHOLDS, LOCK_DURATIONS } from "./types"

// Canon Registry
export { getLoreObjects, getLoreObjectById, getCanonStatistics } from "./canon-registry"

// Canon Decision
export {
  submitCanonizationCandidate,
  getCanonDecision,
  evaluateCanonProbability,
  getAllDecisions,
} from "./canon-decision"

// Canon Lock
export {
  issueCanonLock,
  getCanonLocks,
  getLockById,
  isLocked,
  revokeLock,
  processExpiredLocks,
  getLockStatistics,
} from "./canon-lock"

// Access Gate
export { signalFloorAccess, isFloorAccessible, getFloorAccessRequirements } from "./access-gate"
