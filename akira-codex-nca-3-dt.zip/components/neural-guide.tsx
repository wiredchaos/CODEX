"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { Palette, User, MessageSquare, Film, Music, BookOpen, Layers, Shield, Check } from "lucide-react"

const subsystems = [
  {
    id: "aesthetic",
    name: "AESTHETIC ENGINE",
    status: "ACTIVE",
    icon: Palette,
    description: "Visual identity and design language processor",
    metrics: { load: 87, uptime: "99.9%" },
  },
  {
    id: "persona",
    name: "PERSONA KERNEL",
    status: "ACTIVE",
    icon: User,
    description: "Character and identity management system",
    metrics: { load: 64, uptime: "99.8%" },
  },
  {
    id: "dialogue",
    name: "DIALOGUE MATRIX",
    status: "ACTIVE",
    icon: MessageSquare,
    description: "Natural language and communication protocols",
    metrics: { load: 92, uptime: "99.7%" },
  },
  {
    id: "motion",
    name: "MOTION ENGINE",
    status: "STANDBY",
    icon: Film,
    description: "Animation and movement choreography",
    metrics: { load: 23, uptime: "98.5%" },
  },
  {
    id: "audio",
    name: "AUDIO HARMONICS",
    status: "ACTIVE",
    icon: Music,
    description: "Sound design and frequency modulation",
    metrics: { load: 78, uptime: "99.9%" },
  },
  {
    id: "lore",
    name: "LORE ANCHOR",
    status: "ACTIVE",
    icon: BookOpen,
    description: "Narrative continuity and world-building",
    metrics: { load: 56, uptime: "99.6%" },
  },
  {
    id: "ux",
    name: "UX INTEGRATION",
    status: "ACTIVE",
    icon: Layers,
    description: "User experience and interface layer",
    metrics: { load: 71, uptime: "99.8%" },
  },
  {
    id: "ip",
    name: "IP PROTECTION",
    status: "ACTIVE",
    icon: Shield,
    description: "Intellectual property and security shell",
    metrics: { load: 100, uptime: "100%" },
  },
]

export function NeuralGuide() {
  const [selectedSystem, setSelectedSystem] = useState(subsystems[0])

  return (
    <section id="neural" className="relative py-24">
      <div className="container mx-auto px-4">
        {/* Section header */}
        <div className="text-center mb-16">
          <span className="font-mono text-xs tracking-widest text-cyan-400 mb-4 block drop-shadow-[0_0_10px_rgba(34,211,238,0.8)]">
            WIRED CHAOS META
          </span>
          <h2 className="text-3xl md:text-5xl font-bold mb-4 text-white drop-shadow-[0_0_20px_rgba(255,255,255,0.5)]">
            NEURAL GUIDE <span className="text-red-500 drop-shadow-[0_0_15px_rgba(239,68,68,0.8)]">v33.3</span>
          </h2>
          <p className="text-zinc-200 max-w-xl mx-auto drop-shadow-[0_0_8px_rgba(255,255,255,0.3)]">
            The Circuit Mind avatar intelligence. Monitor subsystem status and unlock new tiers.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Subsystem list */}
          <div className="lg:col-span-1 space-y-2">
            {subsystems.map((system) => {
              const Icon = system.icon
              return (
                <button
                  key={system.id}
                  onClick={() => setSelectedSystem(system)}
                  className={cn(
                    "w-full flex items-center gap-3 p-3 rounded-lg border transition-all text-left",
                    selectedSystem.id === system.id
                      ? "border-red-500 bg-red-500/10 shadow-[0_0_20px_rgba(239,68,68,0.4)]"
                      : "border-zinc-700 hover:border-red-500/50 bg-card",
                  )}
                >
                  <div className="h-5 w-5 flex items-center justify-center">
                    <img
                      src={`/glowing-.jpg?key=hui7r&height=20&width=20&query=glowing+${system.name.toLowerCase()}+icon+animated`}
                      alt=""
                      className="animate-pulse"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-mono text-xs font-bold tracking-wider truncate text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.6)]">
                      {system.name}
                    </div>
                    <div
                      className={cn(
                        "text-xs font-bold drop-shadow-[0_0_10px_currentColor]",
                        system.status === "ACTIVE" ? "text-green-400" : "text-amber-400",
                      )}
                    >
                      {system.status}
                    </div>
                  </div>
                </button>
              )
            })}
          </div>

          {/* Selected system details */}
          <div className="lg:col-span-2">
            <Card className="bg-zinc-900/90 border-zinc-700 h-full">
              <CardHeader className="border-b border-zinc-700">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img
                      src={`/glowing-.jpg?key=lps78&height=24&width=24&query=glowing+${selectedSystem.name.toLowerCase()}+animated+icon`}
                      alt=""
                      className="h-6 w-6 animate-pulse"
                    />
                    <CardTitle className="font-mono tracking-wider text-white drop-shadow-[0_0_10px_rgba(255,255,255,0.5)]">
                      {selectedSystem.name}
                    </CardTitle>
                  </div>
                  <span
                    className={cn(
                      "px-3 py-1 rounded-full text-xs font-mono font-bold drop-shadow-[0_0_10px_currentColor]",
                      selectedSystem.status === "ACTIVE"
                        ? "bg-green-500/20 text-green-400"
                        : "bg-amber-500/20 text-amber-400",
                    )}
                  >
                    {selectedSystem.status}
                  </span>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <p className="text-zinc-200 mb-6 drop-shadow-[0_0_8px_rgba(255,255,255,0.3)]">
                  {selectedSystem.description}
                </p>

                {/* Metrics */}
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="p-4 rounded-lg bg-zinc-800/50 border border-zinc-700">
                    <div className="font-mono text-xs text-cyan-400 mb-1 drop-shadow-[0_0_8px_rgba(34,211,238,0.6)]">
                      LOAD
                    </div>
                    <div className="flex items-end gap-2">
                      <span className="text-2xl font-bold text-white drop-shadow-[0_0_10px_rgba(255,255,255,0.5)]">
                        {selectedSystem.metrics.load}%
                      </span>
                      <div className="flex-1 h-2 rounded-full bg-zinc-700 overflow-hidden">
                        <div
                          className="h-full bg-red-500 transition-all shadow-[0_0_10px_rgba(239,68,68,0.8)]"
                          style={{ width: `${selectedSystem.metrics.load}%` }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="p-4 rounded-lg bg-zinc-800/50 border border-zinc-700">
                    <div className="font-mono text-xs text-cyan-400 mb-1 drop-shadow-[0_0_8px_rgba(34,211,238,0.6)]">
                      UPTIME
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold text-white drop-shadow-[0_0_10px_rgba(255,255,255,0.5)]">
                        {selectedSystem.metrics.uptime}
                      </span>
                      <Check className="h-5 w-5 text-green-400 drop-shadow-[0_0_10px_rgba(74,222,128,0.8)]" />
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-wrap gap-3">
                  <Button className="bg-red-600 text-white font-mono text-xs hover:bg-red-500 shadow-[0_0_20px_rgba(239,68,68,0.5)] font-bold">
                    RUN DIAGNOSTICS
                  </Button>
                  <Button
                    variant="outline"
                    className="border-cyan-500 text-cyan-400 font-mono text-xs bg-transparent hover:bg-cyan-500/10 shadow-[0_0_15px_rgba(34,211,238,0.3)] font-bold"
                  >
                    VIEW LOGS
                  </Button>
                  <Button
                    variant="outline"
                    className="border-zinc-500 text-white font-mono text-xs bg-transparent hover:bg-zinc-700 font-bold"
                  >
                    CONFIGURE
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Unlock tiers */}
        <div className="mt-16 text-center">
          <h3 className="font-mono text-lg font-bold mb-6 text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.6)]">
            UNLOCK NEW TIERS
          </h3>
          <div className="flex flex-wrap justify-center gap-4">
            <Button
              variant="outline"
              className="border-red-500 text-red-400 font-mono text-xs bg-transparent hover:bg-red-500/10 shadow-[0_0_15px_rgba(239,68,68,0.4)] font-bold"
            >
              GIGA ENGINE PACK
            </Button>
            <Button
              variant="outline"
              className="border-cyan-500 text-cyan-400 font-mono text-xs bg-transparent hover:bg-cyan-500/10 shadow-[0_0_15px_rgba(34,211,238,0.4)] font-bold"
            >
              META-BRAIN BEHAVIOR
            </Button>
            <Button
              variant="outline"
              className="border-amber-500 text-amber-400 font-mono text-xs bg-transparent hover:bg-amber-500/10 shadow-[0_0_15px_rgba(251,191,36,0.4)] font-bold"
            >
              NEURAL CATHEDRAL
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
