"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Play, Pause, Volume2, Maximize2 } from "lucide-react"

const gameFeatures = [
  {
    title: "RESONANCE NAVIGATION",
    description: "Navigate through rhythm-based challenges using the 33.3 FM spectrum",
    icon: "◎",
  },
  {
    title: "CODEX DECRYPTION",
    description: "Unlock hidden narratives through gameplay progression",
    icon: "◈",
  },
  {
    title: "CREATOR PORTALS",
    description: "Build and share your own NETERU experiences",
    icon: "◇",
  },
  {
    title: "MYTHIC ECONOMY",
    description: "On-chain assets tied to gameplay achievements",
    icon: "◆",
  },
]

export function FlinchGameHub() {
  const [isPlaying, setIsPlaying] = useState(false)

  return (
    <section id="neteru-hub" className="relative py-24">
      <div className="container mx-auto px-4">
        {/* Section header */}
        <div className="text-center mb-16">
          <span className="font-mono text-xs tracking-widest text-cyan-400 mb-4 block drop-shadow-[0_0_10px_rgba(34,211,238,0.8)] font-bold">
            META PATCH WCX-META-NTR-001
          </span>
          <h2 className="text-3xl md:text-5xl font-bold mb-4">
            <span className="text-red-500 drop-shadow-[0_0_20px_rgba(239,68,68,0.8)]">NETERU ARTIFACTS</span>
            <span className="text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.5)]"> : RESONANCE PROTOCOL</span>
          </h2>
          <p className="text-zinc-100 max-w-xl mx-auto drop-shadow-[0_0_8px_rgba(255,255,255,0.4)]">
            A rhythm narrative game where every beat unlocks a fragment of the Akira Codex
          </p>
        </div>

        {/* Game preview area */}
        <div className="grid lg:grid-cols-2 gap-8 items-center">
          {/* Game screen */}
          <div className="relative aspect-video rounded-lg overflow-hidden border-2 border-red-500 bg-zinc-900 shadow-[0_0_30px_rgba(239,68,68,0.5)]">
            <div className="absolute inset-0 bg-gradient-to-br from-red-500/10 to-cyan-500/10" />

            <div className="absolute inset-0 flex items-center justify-center">
              <img
                src="/animated-cyberpunk-game-interface-glowing-neon-rhy.jpg"
                alt="Game Preview"
                className="w-full h-full object-cover opacity-80"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="w-24 h-24 mx-auto mb-4 rounded-full border-2 border-red-500 flex items-center justify-center shadow-[0_0_30px_rgba(239,68,68,0.8)]">
                    <div className="w-16 h-16 rounded-full bg-red-500/20 flex items-center justify-center">
                      {isPlaying ? (
                        <Pause className="h-8 w-8 text-red-400 drop-shadow-[0_0_10px_rgba(248,113,113,0.8)]" />
                      ) : (
                        <Play className="h-8 w-8 text-red-400 ml-1 drop-shadow-[0_0_10px_rgba(248,113,113,0.8)]" />
                      )}
                    </div>
                  </div>
                  <span className="font-mono text-sm text-white drop-shadow-[0_0_10px_rgba(255,255,255,0.6)] font-bold">
                    DEMO PREVIEW
                  </span>
                </div>
              </div>
            </div>

            {/* Controls overlay */}
            <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Button
                    size="icon"
                    variant="ghost"
                    className="h-8 w-8 text-white hover:text-red-400"
                    onClick={() => setIsPlaying(!isPlaying)}
                  >
                    {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                  </Button>
                  <Button size="icon" variant="ghost" className="h-8 w-8 text-white hover:text-red-400">
                    <Volume2 className="h-4 w-4" />
                  </Button>
                </div>
                <Button size="icon" variant="ghost" className="h-8 w-8 text-white hover:text-red-400">
                  <Maximize2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Features grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {gameFeatures.map((feature, index) => (
              <Card
                key={feature.title}
                className="bg-zinc-900 border-zinc-700 hover:border-red-500/50 transition-colors group shadow-[0_0_15px_rgba(0,0,0,0.5)] hover:shadow-[0_0_25px_rgba(239,68,68,0.3)]"
              >
                <CardContent className="p-6">
                  <div className="w-12 h-12 mb-4">
                    <img
                      src={`/animated-glowing-.jpg?key=tohlm&height=48&width=48&query=animated+glowing+${feature.title.toLowerCase()}+icon`}
                      alt=""
                      className="w-full h-full animate-pulse"
                    />
                  </div>
                  <h3 className="font-mono text-sm font-bold tracking-wider mb-2 text-white drop-shadow-[0_0_10px_rgba(255,255,255,0.6)]">
                    {feature.title}
                  </h3>
                  <p className="text-xs text-zinc-200 leading-relaxed drop-shadow-[0_0_8px_rgba(255,255,255,0.3)]">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Launch CTA */}
        <div className="mt-12 text-center">
          <Button
            size="lg"
            className="bg-red-600 text-white font-mono tracking-wider hover:bg-red-500 shadow-[0_0_30px_rgba(239,68,68,0.6)] font-bold text-base"
          >
            ENTER RESONANCE PROTOCOL
          </Button>
        </div>
      </div>
    </section>
  )
}
