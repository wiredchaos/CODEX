/**
 * TRINITY ENVIRONMENT RENDERER — CONSUMER COMPONENT
 *
 * This component is a CONSUMER of the WIRED CHAOS Trinity 3D Core.
 * Rules:
 * - Do NOT implement own 3D engine
 * - Do NOT create timelines or elevators
 * - Mount existing Trinity environment
 * - Read-only Trinity Core
 * - Respect Akira Codex gating
 * - Use hotspots + HUD supplied by core
 * - Business data stays firewalled
 *
 * WIRED CHAOS META | NEURO CODE APINAYA
 */

"use client"

import { useState, useEffect, useCallback } from "react"
import { PATCH_DECLARATION } from "@/lib/trinity-mount"

// Environment types supplied by Trinity Core
type EnvironmentKind = "lobby" | "sanctum" | "portal" | "void" | "stream"

interface EnvironmentRendererProps {
  patchId: string
  kind: EnvironmentKind
  videoFallback?: string
  onHotspotClick?: (hotspotId: string) => void
}

// Trinity Core HUD elements (read-only consumption)
interface TrinityHotspot {
  id: string
  label: string
  position: { x: number; y: number }
  action: string
  gated: boolean
}

// Core-supplied hotspots for lobby environment
const LOBBY_HOTSPOTS: TrinityHotspot[] = [
  { id: "neuralis-gate", label: "NEURALIS", position: { x: 15, y: 40 }, action: "/cathedral", gated: false },
  { id: "chaosphere-gate", label: "CHAOSPHERE", position: { x: 85, y: 40 }, action: "/terminal", gated: false },
  { id: "sanctum-gate", label: "AKIRA SANCTUM", position: { x: 50, y: 20 }, action: "/realm/akira", gated: true },
  { id: "neteru-gate", label: "NETERU DEPTHS", position: { x: 50, y: 80 }, action: "/realm/neteru", gated: true },
  { id: "vault-access", label: "NTRU VAULT", position: { x: 30, y: 65 }, action: "/vault", gated: false },
  { id: "signal-era", label: "33.3 FM", position: { x: 70, y: 65 }, action: "/radio", gated: false },
]

export function EnvironmentRenderer({ patchId, kind, videoFallback, onHotspotClick }: EnvironmentRendererProps) {
  const [mounted, setMounted] = useState(false)
  const [trinityConnected, setTrinityConnected] = useState(false)
  const [useVideoFallback, setUseVideoFallback] = useState(false)
  const [hoveredHotspot, setHoveredHotspot] = useState<string | null>(null)
  const [hudVisible, setHudVisible] = useState(true)

  // Verify patch alignment on mount
  useEffect(() => {
    setMounted(true)

    // Validate Trinity Core connection (consumer mode)
    const isValidConsumer = PATCH_DECLARATION.governance.role === "CONSUMER"
    const hasReadAccess = PATCH_DECLARATION.governance.infrastructure === "READ_ONLY"

    if (isValidConsumer && hasReadAccess) {
      setTrinityConnected(true)
      // Check if 3D rendering is available from core
      // If not, fallback to video
      const trinity3DAvailable = typeof window !== "undefined" && "WebGLRenderingContext" in window
      if (!trinity3DAvailable || videoFallback) {
        setUseVideoFallback(true)
      }
    } else {
      // Fallback to video if not properly aligned
      setUseVideoFallback(true)
    }
  }, [videoFallback])

  const handleHotspotClick = useCallback(
    (hotspot: TrinityHotspot) => {
      if (hotspot.gated) {
        // Check Akira Codex gating
        console.log(`[Trinity] Gated hotspot: ${hotspot.id} - Access denied by Akira Codex`)
        return
      }

      if (onHotspotClick) {
        onHotspotClick(hotspot.id)
      } else {
        // Default navigation
        window.location.href = hotspot.action
      }
    },
    [onHotspotClick],
  )

  if (!mounted) return null

  return (
    <div
      className="relative w-full h-full min-h-screen overflow-hidden"
      role="region"
      aria-label={`Trinity ${kind} environment - ${patchId}`}
    >
      {/* Trinity Core Status Badge */}
      <div className="absolute top-4 left-4 z-50 flex items-center gap-2">
        <div className={`w-2 h-2 rounded-full ${trinityConnected ? "bg-[#00FFF7] animate-pulse" : "bg-red-500"}`} />
        <span className="text-[10px] font-mono text-white/60 uppercase tracking-wider">
          Trinity Core: {trinityConnected ? "MOUNTED" : "DISCONNECTED"}
        </span>
      </div>

      {/* Patch ID Badge */}
      <div className="absolute top-4 right-4 z-50">
        <span className="text-[10px] font-mono text-[#00FFF7]/60 uppercase tracking-wider">
          PATCH: {patchId} | KIND: {kind.toUpperCase()}
        </span>
      </div>

      {/* Environment Layer - Video Fallback */}
      {useVideoFallback ? (
        <div className="absolute inset-0 bg-[#0D0D0D]">
          {/* Cinematic Video Background */}
          {videoFallback ? (
            <video
              autoPlay
              loop
              muted
              playsInline
              className="absolute inset-0 w-full h-full object-cover opacity-60"
              aria-label="Trinity environment cinematic background"
            >
              <source src={videoFallback} type="video/mp4" />
            </video>
          ) : (
            /* Animated Fallback Environment */
            <div className="absolute inset-0">
              {/* Liquid glass base */}
              <div className="absolute inset-0 bg-gradient-to-b from-[#0D0D0D] via-[#0a1a1a] to-[#0D0D0D]" />

              {/* Animated grid floor */}
              <div
                className="absolute inset-0 opacity-20"
                style={{
                  backgroundImage: `
                    linear-gradient(rgba(0,255,247,0.1) 1px, transparent 1px),
                    linear-gradient(90deg, rgba(0,255,247,0.1) 1px, transparent 1px)
                  `,
                  backgroundSize: "80px 80px",
                  transform: "perspective(500px) rotateX(60deg)",
                  transformOrigin: "center top",
                }}
              />

              {/* Horizon glow */}
              <div className="absolute top-1/3 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#00FFF7]/40 to-transparent" />
              <div className="absolute top-1/3 left-0 right-0 h-32 bg-gradient-to-b from-[#00FFF7]/10 to-transparent blur-xl" />

              {/* Side pillars - Neuralis (left) */}
              <div className="absolute left-8 top-1/4 bottom-1/4 w-1 bg-gradient-to-b from-transparent via-[#00FFF7]/60 to-transparent" />
              <div className="absolute left-8 top-1/4 w-8 h-8 border border-[#00FFF7]/40 rotate-45" />

              {/* Side pillars - Chaosphere (right) */}
              <div className="absolute right-8 top-1/4 bottom-1/4 w-1 bg-gradient-to-b from-transparent via-[#FF1A1A]/60 to-transparent" />
              <div className="absolute right-8 top-1/4 w-8 h-8 border border-[#FF1A1A]/40 rotate-45" />

              {/* Central portal glow */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 rounded-full bg-[#00FFF7]/5 blur-3xl animate-pulse" />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 rounded-full border border-[#00FFF7]/20" />
              <div
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 rounded-full border border-[#FF1A1A]/10 animate-spin"
                style={{ animationDuration: "20s" }}
              />

              {/* Data streams */}
              {[...Array(5)].map((_, i) => (
                <div
                  key={i}
                  className="absolute h-px bg-gradient-to-r from-transparent via-[#00FFF7]/40 to-transparent"
                  style={{
                    top: `${30 + i * 10}%`,
                    left: 0,
                    right: 0,
                    animation: `dataStream ${3 + i}s linear infinite`,
                    animationDelay: `${i * 0.5}s`,
                  }}
                />
              ))}
            </div>
          )}
        </div>
      ) : (
        /* Trinity 3D Core Mount Point */
        <div className="absolute inset-0 bg-[#0D0D0D]">
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-[#00FFF7]/40 font-mono text-xs">[TRINITY 3D CORE MOUNT POINT - READ ONLY]</span>
          </div>
        </div>
      )}

      {/* Liquid Glass Overlay */}
      <div
        className="absolute inset-0 pointer-events-none z-10"
        style={{
          background: `
            radial-gradient(ellipse at center, transparent 0%, rgba(13,13,13,0.4) 70%, rgba(13,13,13,0.8) 100%)
          `,
        }}
      />

      {/* Trinity Core HUD - Hotspots */}
      {hudVisible && kind === "lobby" && (
        <div className="absolute inset-0 z-20">
          {LOBBY_HOTSPOTS.map((hotspot) => (
            <button
              key={hotspot.id}
              className={`
                absolute transform -translate-x-1/2 -translate-y-1/2 
                transition-all duration-300 group
                ${hotspot.gated ? "cursor-not-allowed opacity-50" : "cursor-pointer hover:scale-110"}
              `}
              style={{ left: `${hotspot.position.x}%`, top: `${hotspot.position.y}%` }}
              onClick={() => handleHotspotClick(hotspot)}
              onMouseEnter={() => setHoveredHotspot(hotspot.id)}
              onMouseLeave={() => setHoveredHotspot(null)}
              aria-label={`${hotspot.label} ${hotspot.gated ? "(Locked - Akira Codex Required)" : ""}`}
              disabled={hotspot.gated}
            >
              {/* Hotspot marker */}
              <div
                className={`
                w-4 h-4 rounded-full border-2 
                ${
                  hotspot.gated
                    ? "border-[#fbbf24]/60 bg-[#fbbf24]/10"
                    : "border-[#00FFF7]/80 bg-[#00FFF7]/20 group-hover:bg-[#00FFF7]/40"
                }
                ${hoveredHotspot === hotspot.id ? "animate-ping" : ""}
              `}
              />

              {/* Hotspot label */}
              <div
                className={`
                absolute top-6 left-1/2 -translate-x-1/2 whitespace-nowrap
                px-3 py-1 rounded bg-black/80 border
                ${hotspot.gated ? "border-[#fbbf24]/40" : "border-[#00FFF7]/40"}
                transition-opacity duration-200
                ${hoveredHotspot === hotspot.id ? "opacity-100" : "opacity-0 group-hover:opacity-100"}
              `}
              >
                <span
                  className={`
                  text-xs font-mono uppercase tracking-wider
                  ${hotspot.gated ? "text-[#fbbf24]" : "text-[#00FFF7]"}
                `}
                >
                  {hotspot.label}
                </span>
                {hotspot.gated && (
                  <span className="block text-[8px] text-[#fbbf24]/60 mt-0.5">AKIRA CODEX REQUIRED</span>
                )}
              </div>
            </button>
          ))}
        </div>
      )}

      {/* HUD Toggle */}
      <button
        className="absolute bottom-4 right-4 z-50 px-3 py-1 rounded border border-white/20 bg-black/60 text-white/60 text-xs font-mono hover:bg-black/80 transition-colors"
        onClick={() => setHudVisible(!hudVisible)}
        aria-label={hudVisible ? "Hide navigation hotspots" : "Show navigation hotspots"}
      >
        HUD: {hudVisible ? "ON" : "OFF"}
      </button>

      {/* Governance Watermark */}
      <div className="absolute bottom-4 left-4 z-50 text-[8px] font-mono text-white/20 uppercase tracking-widest">
        GOVERNED BY AKIRA CODEX | BUSINESS DATA FIREWALLED
      </div>

      {/* Keyframes for data streams */}
      <style jsx>{`
        @keyframes dataStream {
          0% { transform: translateX(-100%); opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { transform: translateX(100%); opacity: 0; }
        }
      `}</style>
    </div>
  )
}

// Export for Trinity Core consumption
export default EnvironmentRenderer
