"use client"

import { useState, useRef, useEffect } from "react"
import { Play, Pause, Volume2, VolumeX, Radio, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"

interface RadioPlayerProps {
  streamUrl?: string
  stationName?: string
  className?: string
}

export function RadioPlayer({
  streamUrl = "", // Placeholder - will be replaced with actual stream URL
  stationName = "33.3 FM DOGECHAIN",
  className = "",
}: RadioPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [volume, setVolume] = useState(70)
  const [isMuted, setIsMuted] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  useEffect(() => {
    // Create audio element
    audioRef.current = new Audio()
    audioRef.current.preload = "none"

    const audio = audioRef.current

    const handleCanPlay = () => {
      setIsLoading(false)
      setError(null)
    }

    const handleError = () => {
      setIsLoading(false)
      setIsPlaying(false)
      setError("Stream unavailable")
    }

    const handleWaiting = () => {
      setIsLoading(true)
    }

    const handlePlaying = () => {
      setIsLoading(false)
    }

    audio.addEventListener("canplay", handleCanPlay)
    audio.addEventListener("error", handleError)
    audio.addEventListener("waiting", handleWaiting)
    audio.addEventListener("playing", handlePlaying)

    return () => {
      audio.removeEventListener("canplay", handleCanPlay)
      audio.removeEventListener("error", handleError)
      audio.removeEventListener("waiting", handleWaiting)
      audio.removeEventListener("playing", handlePlaying)
      audio.pause()
      audio.src = ""
    }
  }, [])

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume / 100
    }
  }, [volume, isMuted])

  const togglePlay = async () => {
    if (!audioRef.current) return

    if (!streamUrl) {
      setError("Stream URL not configured")
      return
    }

    if (isPlaying) {
      audioRef.current.pause()
      setIsPlaying(false)
    } else {
      setIsLoading(true)
      setError(null)

      if (!audioRef.current.src) {
        audioRef.current.src = streamUrl
      }

      try {
        await audioRef.current.play()
        setIsPlaying(true)
      } catch (err) {
        setError("Failed to play stream")
        setIsLoading(false)
      }
    }
  }

  const toggleMute = () => {
    setIsMuted(!isMuted)
  }

  return (
    <div
      className={`rounded-lg border border-red-500/30 bg-black/50 p-4 ${className}`}
      style={{ boxShadow: "0 0 20px rgba(255,26,26,0.2)" }}
      role="region"
      aria-label={`${stationName} Radio Player`}
    >
      <div className="flex items-center gap-3 mb-3">
        <div
          className="h-10 w-10 rounded bg-red-500/20 flex items-center justify-center"
          style={{ boxShadow: "0 0 15px rgba(255,26,26,0.3)" }}
          aria-hidden="true"
        >
          <Radio className="h-5 w-5 text-red-400 animate-pulse" />
        </div>
        <div className="flex-1">
          <h3 className="font-mono text-sm font-bold text-white" style={{ textShadow: "0 0 10px #FF1A1A" }}>
            {stationName}
          </h3>
          <p className="text-[10px] font-mono text-red-400">
            {isPlaying ? "LIVE BROADCAST" : error || "CLICK TO TUNE IN"}
          </p>
        </div>
        <div
          className={`h-3 w-3 rounded-full ${isPlaying ? "bg-red-500 animate-pulse" : "bg-zinc-600"}`}
          style={isPlaying ? { boxShadow: "0 0 10px #FF1A1A" } : {}}
          aria-label={isPlaying ? "Live" : "Offline"}
        />
      </div>

      <div className="flex items-center gap-3">
        <Button
          variant="ghost"
          size="icon"
          onClick={togglePlay}
          disabled={isLoading}
          className="h-12 w-12 rounded-full border border-red-500/50 bg-red-500/10 hover:bg-red-500/20 text-red-400 focus:outline-none focus:ring-2 focus:ring-red-500"
          aria-label={isPlaying ? "Pause radio" : "Play radio"}
        >
          {isLoading ? (
            <Loader2 className="h-6 w-6 animate-spin" aria-hidden="true" />
          ) : isPlaying ? (
            <Pause className="h-6 w-6" aria-hidden="true" />
          ) : (
            <Play className="h-6 w-6 ml-1" aria-hidden="true" />
          )}
        </Button>

        <div className="flex-1 flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleMute}
            className="h-8 w-8 text-zinc-400 hover:text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
            aria-label={isMuted ? "Unmute" : "Mute"}
          >
            {isMuted ? (
              <VolumeX className="h-4 w-4" aria-hidden="true" />
            ) : (
              <Volume2 className="h-4 w-4" aria-hidden="true" />
            )}
          </Button>
          <Slider
            value={[isMuted ? 0 : volume]}
            onValueChange={(v) => {
              setVolume(v[0])
              if (v[0] > 0) setIsMuted(false)
            }}
            max={100}
            step={1}
            className="flex-1"
            aria-label="Volume control"
          />
          <span className="text-[10px] font-mono text-zinc-500 w-8 text-right">{isMuted ? "0" : volume}%</span>
        </div>
      </div>

      {!streamUrl && (
        <p className="text-[10px] font-mono text-amber-400 mt-2 text-center">Awaiting stream URL configuration</p>
      )}
    </div>
  )
}
