"use client"

import { useState, useEffect } from "react"
import { X, Zap, Terminal, Radio } from "lucide-react"

interface AgenticWelcomeProps {
  pageName?: string
  onComplete?: () => void
}

const bootMessages = [
  "INITIALIZING NEURAL INTERFACE...",
  "CONNECTING TO 33.3 FM SPECTRUM...",
  "LOADING AKIRA CODEX PROTOCOLS...",
  "SYNCHRONIZING WIRED CHAOS META...",
  "ESTABLISHING SECURE CHANNEL...",
  "NEURAL HANDSHAKE COMPLETE.",
]

const welcomeVariants = [
  {
    title: "WELCOME TO THE GRID",
    message: "The motherboard recognizes your signal. NEURO META X protocols are now active.",
    icon: Zap,
  },
  {
    title: "SIGNAL DETECTED",
    message: "Your frequency has been locked. The NETERU APINAYA awaits your command.",
    icon: Radio,
  },
  {
    title: "NEURAL LINK ESTABLISHED",
    message: "WIRED CHAOS META systems online. All subsystems responding.",
    icon: Terminal,
  },
]

export function AgenticWelcome({ pageName = "AKIRA CODEX", onComplete }: AgenticWelcomeProps) {
  const [isVisible, setIsVisible] = useState(false)
  const [bootPhase, setBootPhase] = useState(0)
  const [currentMessage, setCurrentMessage] = useState(0)
  const [typedText, setTypedText] = useState("")
  const [isBooting, setIsBooting] = useState(true)
  const [variant] = useState(() => welcomeVariants[Math.floor(Math.random() * welcomeVariants.length)])

  useEffect(() => {
    // Check if user has seen welcome recently
    const lastSeen = sessionStorage.getItem("akira-welcome-seen")
    const now = Date.now()

    if (!lastSeen || now - Number.parseInt(lastSeen) > 300000) {
      // 5 minutes
      setIsVisible(true)
      sessionStorage.setItem("akira-welcome-seen", now.toString())
    } else {
      onComplete?.()
    }
  }, [onComplete])

  useEffect(() => {
    if (!isVisible) return

    // Boot sequence
    if (isBooting && bootPhase < bootMessages.length) {
      const timer = setTimeout(() => {
        setBootPhase((prev) => prev + 1)
      }, 400)
      return () => clearTimeout(timer)
    } else if (isBooting && bootPhase >= bootMessages.length) {
      setTimeout(() => setIsBooting(false), 500)
    }
  }, [isVisible, isBooting, bootPhase])

  useEffect(() => {
    if (!isVisible || isBooting) return

    // Typewriter effect for welcome message
    const message = variant.message
    if (typedText.length < message.length) {
      const timer = setTimeout(() => {
        setTypedText(message.slice(0, typedText.length + 1))
      }, 30)
      return () => clearTimeout(timer)
    }
  }, [isVisible, isBooting, typedText, variant.message])

  const handleDismiss = () => {
    setIsVisible(false)
    onComplete?.()
  }

  if (!isVisible) return null

  const IconComponent = variant.icon

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-sm">
      {/* Animated border frame */}
      <div className="relative w-full max-w-lg mx-4">
        {/* Corner accents */}
        <div
          className="absolute -top-1 -left-1 w-8 h-8 border-t-2 border-l-2 border-cyan-400"
          style={{ boxShadow: "0 0 10px #00FFF7, inset 0 0 10px #00FFF7" }}
        />
        <div
          className="absolute -top-1 -right-1 w-8 h-8 border-t-2 border-r-2 border-cyan-400"
          style={{ boxShadow: "0 0 10px #00FFF7, inset 0 0 10px #00FFF7" }}
        />
        <div
          className="absolute -bottom-1 -left-1 w-8 h-8 border-b-2 border-l-2 border-red-500"
          style={{ boxShadow: "0 0 10px #FF1A1A, inset 0 0 10px #FF1A1A" }}
        />
        <div
          className="absolute -bottom-1 -right-1 w-8 h-8 border-b-2 border-r-2 border-red-500"
          style={{ boxShadow: "0 0 10px #FF1A1A, inset 0 0 10px #FF1A1A" }}
        />

        <div className="bg-black/80 border border-zinc-800 p-6 relative overflow-hidden">
          {/* Scan line effect */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div
              className="absolute inset-x-0 h-px bg-gradient-to-r from-transparent via-cyan-400/50 to-transparent animate-scan"
              style={{ animation: "scan 3s linear infinite" }}
            />
          </div>

          {/* Close button */}
          <button
            onClick={handleDismiss}
            className="absolute top-4 right-4 text-zinc-500 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Header */}
          <div className="flex items-center gap-3 mb-6">
            <div
              className="w-12 h-12 rounded bg-gradient-to-br from-red-600 to-red-800 flex items-center justify-center"
              style={{ boxShadow: "0 0 20px rgba(255, 26, 26, 0.5)" }}
            >
              <span className="text-white font-bold text-lg font-mono">AK</span>
            </div>
            <div>
              <h2
                className="text-xl font-bold text-white font-mono tracking-wider"
                style={{ textShadow: "0 0 10px #00FFF7" }}
              >
                {pageName}
              </h2>
              <p className="text-cyan-400 text-xs font-mono">NEURAL INTERFACE v33.3</p>
            </div>
          </div>

          {/* Boot sequence or welcome */}
          {isBooting ? (
            <div className="space-y-1 font-mono text-sm">
              {bootMessages.slice(0, bootPhase).map((msg, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <span className="text-green-400">[OK]</span>
                  <span className="text-zinc-300">{msg}</span>
                </div>
              ))}
              {bootPhase < bootMessages.length && (
                <div className="flex items-center gap-2">
                  <span className="text-yellow-400 animate-pulse">[..]</span>
                  <span className="text-zinc-400">{bootMessages[bootPhase]}</span>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <IconComponent className="w-8 h-8 text-cyan-400" style={{ filter: "drop-shadow(0 0 10px #00FFF7)" }} />
                <h3
                  className="text-2xl font-bold text-white font-mono tracking-wider"
                  style={{ textShadow: "0 0 15px #00FFF7, 0 0 30px #00FFF7" }}
                >
                  {variant.title}
                </h3>
              </div>

              <p className="text-zinc-200 font-mono text-sm leading-relaxed min-h-[3rem]">
                {typedText}
                <span className="animate-pulse text-cyan-400">|</span>
              </p>

              <div className="flex items-center justify-between pt-4 border-t border-zinc-800">
                <div className="flex items-center gap-2">
                  <div
                    className="w-2 h-2 rounded-full bg-green-400 animate-pulse"
                    style={{ boxShadow: "0 0 10px #22c55e" }}
                  />
                  <span className="text-green-400 text-xs font-mono">SYSTEMS ONLINE</span>
                </div>

                <button
                  onClick={handleDismiss}
                  className="px-4 py-2 bg-gradient-to-r from-cyan-600 to-cyan-800 text-white font-mono text-sm font-bold tracking-wider hover:from-cyan-500 hover:to-cyan-700 transition-all"
                  style={{ boxShadow: "0 0 20px rgba(0, 255, 247, 0.3)" }}
                >
                  ENTER GRID
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      <style jsx>{`
        @keyframes scan {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(100vh); }
        }
        .animate-scan {
          animation: scan 3s linear infinite;
        }
      `}</style>
    </div>
  )
}
