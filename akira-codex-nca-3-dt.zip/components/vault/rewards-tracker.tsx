"use client"

import { Gift, Calendar, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"

interface RewardsTrackerProps {
  dailyReward: number
  weeklyBonus: number
  streakDays: number
  nextRewardIn: string
}

export function RewardsTracker({ dailyReward, weeklyBonus, streakDays, nextRewardIn }: RewardsTrackerProps) {
  return (
    <div
      className="rounded-lg border border-amber-500/30 bg-zinc-900/50 p-6"
      style={{ boxShadow: "0 0 20px rgba(245,158,11,0.1)" }}
    >
      <div className="flex items-center gap-3 mb-6">
        <div
          className="h-10 w-10 rounded bg-amber-500/20 flex items-center justify-center"
          style={{ boxShadow: "0 0 15px rgba(245,158,11,0.3)" }}
        >
          <Gift className="h-5 w-5 text-amber-400" style={{ filter: "drop-shadow(0 0 8px #F59E0B)" }} />
        </div>
        <div>
          <h3 className="font-mono text-sm font-bold text-white" style={{ textShadow: "0 0 10px #FFFFFF" }}>
            REWARDS TRACKER
          </h3>
          <p className="text-xs text-zinc-300" style={{ textShadow: "0 0 6px #FFFFFF" }}>
            Daily and weekly bonuses
          </p>
        </div>
      </div>

      {/* Streak */}
      <div className="text-center py-4 mb-4">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Zap className="h-5 w-5 text-amber-400" style={{ filter: "drop-shadow(0 0 8px #F59E0B)" }} />
          <span className="text-[10px] font-mono text-zinc-300">CURRENT STREAK</span>
        </div>
        <p
          className="font-mono text-4xl font-bold text-amber-400"
          style={{ textShadow: "0 0 25px #F59E0B, 0 0 50px #F59E0B" }}
        >
          {streakDays}
        </p>
        <p className="text-xs text-zinc-300 mt-1" style={{ textShadow: "0 0 6px #FFFFFF" }}>
          DAYS
        </p>
      </div>

      {/* Rewards Grid */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        <div
          className="rounded-lg bg-black/50 p-3 text-center border border-cyan-500/20"
          style={{ boxShadow: "0 0 10px rgba(0,255,247,0.1)" }}
        >
          <Calendar className="h-4 w-4 text-cyan-400 mx-auto mb-2" style={{ filter: "drop-shadow(0 0 6px #00FFF7)" }} />
          <p className="text-[10px] font-mono text-zinc-300">DAILY</p>
          <p className="font-mono text-lg font-bold text-cyan-400" style={{ textShadow: "0 0 15px #00FFF7" }}>
            +{dailyReward}
          </p>
        </div>
        <div
          className="rounded-lg bg-black/50 p-3 text-center border border-red-500/20"
          style={{ boxShadow: "0 0 10px rgba(255,26,26,0.1)" }}
        >
          <Gift className="h-4 w-4 text-red-500 mx-auto mb-2" style={{ filter: "drop-shadow(0 0 6px #FF1A1A)" }} />
          <p className="text-[10px] font-mono text-zinc-300">WEEKLY</p>
          <p className="font-mono text-lg font-bold text-red-500" style={{ textShadow: "0 0 15px #FF1A1A" }}>
            +{weeklyBonus}
          </p>
        </div>
      </div>

      {/* Next Reward Timer */}
      <div
        className="rounded-lg border border-dashed border-zinc-700 p-3 text-center mb-4 bg-black/30"
        style={{ boxShadow: "0 0 10px rgba(0,255,247,0.05)" }}
      >
        <p className="text-[10px] font-mono text-zinc-300 mb-1">NEXT REWARD IN</p>
        <p className="font-mono text-lg font-bold text-white" style={{ textShadow: "0 0 15px #FFFFFF" }}>
          {nextRewardIn}
        </p>
      </div>

      <Button
        className="w-full bg-amber-500 hover:bg-amber-400 text-black font-mono text-xs font-bold"
        style={{ boxShadow: "0 0 20px rgba(245,158,11,0.3)" }}
      >
        <Gift className="h-4 w-4 mr-2" />
        CLAIM DAILY REWARD
      </Button>
    </div>
  )
}
