"use client"

import { useState } from "react"
import { Lock, TrendingUp, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"

interface StakingPanelProps {
  stakedAmount: number
  availableBalance: number
  apr: number
  lockPeriod: string
}

export function StakingPanel({ stakedAmount, availableBalance, apr, lockPeriod }: StakingPanelProps) {
  const [stakeAmount, setStakeAmount] = useState("")
  const [isStaking, setIsStaking] = useState(false)

  const handleStake = async () => {
    if (!stakeAmount || Number(stakeAmount) <= 0) return
    setIsStaking(true)
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsStaking(false)
    setStakeAmount("")
  }

  return (
    <div
      className="rounded-lg border border-red-500/30 bg-zinc-900/50 p-6"
      style={{ boxShadow: "0 0 20px rgba(255,26,26,0.1)" }}
    >
      <div className="flex items-center gap-3 mb-6">
        <div
          className="h-10 w-10 rounded bg-red-500/20 flex items-center justify-center"
          style={{ boxShadow: "0 0 15px rgba(255,26,26,0.3)" }}
        >
          <Lock className="h-5 w-5 text-red-500" style={{ filter: "drop-shadow(0 0 8px #FF1A1A)" }} />
        </div>
        <div>
          <h3 className="font-mono text-sm font-bold text-white" style={{ textShadow: "0 0 10px #FFFFFF" }}>
            NTRU STAKING
          </h3>
          <p className="text-xs text-zinc-300" style={{ textShadow: "0 0 6px #FFFFFF" }}>
            Lock tokens for rewards
          </p>
        </div>
      </div>

      {/* Staking Stats */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div
          className="rounded-lg bg-black/50 p-4 border border-red-500/20"
          style={{ boxShadow: "0 0 10px rgba(255,26,26,0.1)" }}
        >
          <div className="flex items-center gap-2 mb-2">
            <Lock className="h-4 w-4 text-red-500" style={{ filter: "drop-shadow(0 0 6px #FF1A1A)" }} />
            <span className="text-[10px] font-mono text-zinc-300">STAKED</span>
          </div>
          <p className="font-mono text-xl font-bold text-red-500" style={{ textShadow: "0 0 15px #FF1A1A" }}>
            {stakedAmount.toLocaleString()}
          </p>
        </div>
        <div
          className="rounded-lg bg-black/50 p-4 border border-cyan-500/20"
          style={{ boxShadow: "0 0 10px rgba(0,255,247,0.1)" }}
        >
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="h-4 w-4 text-cyan-400" style={{ filter: "drop-shadow(0 0 6px #00FFF7)" }} />
            <span className="text-[10px] font-mono text-zinc-300">APR</span>
          </div>
          <p className="font-mono text-xl font-bold text-cyan-400" style={{ textShadow: "0 0 15px #00FFF7" }}>
            {apr}%
          </p>
        </div>
      </div>

      {/* Lock Period */}
      <div
        className="flex items-center justify-between rounded-lg border border-zinc-700 p-3 mb-6 bg-black/30"
        style={{ boxShadow: "0 0 10px rgba(0,255,247,0.05)" }}
      >
        <div className="flex items-center gap-2">
          <Clock className="h-4 w-4 text-zinc-300" />
          <span className="text-xs font-mono text-zinc-300">LOCK PERIOD</span>
        </div>
        <span className="font-mono text-sm text-white" style={{ textShadow: "0 0 8px #FFFFFF" }}>
          {lockPeriod}
        </span>
      </div>

      {/* Stake Input */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs font-mono text-zinc-300">
          <span>AMOUNT TO STAKE</span>
          <span style={{ textShadow: "0 0 6px #00FFF7" }}>AVAILABLE: {availableBalance.toLocaleString()}</span>
        </div>
        <div className="relative">
          <input
            type="number"
            value={stakeAmount}
            onChange={(e) => setStakeAmount(e.target.value)}
            placeholder="0"
            className="w-full rounded-lg border border-zinc-700 bg-black px-4 py-3 font-mono text-lg text-white placeholder:text-zinc-600 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500"
            style={{ boxShadow: "inset 0 0 10px rgba(0,0,0,0.5)" }}
          />
          <button
            onClick={() => setStakeAmount(availableBalance.toString())}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] font-mono text-red-500 hover:text-red-400"
            style={{ textShadow: "0 0 8px #FF1A1A" }}
          >
            MAX
          </button>
        </div>
        <Button
          onClick={handleStake}
          disabled={!stakeAmount || Number(stakeAmount) <= 0 || isStaking}
          className="w-full bg-red-600 hover:bg-red-500 text-white font-mono text-xs"
          style={{ boxShadow: "0 0 20px rgba(255,26,26,0.3)" }}
        >
          {isStaking ? (
            <span className="flex items-center gap-2">
              <span className="h-4 w-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
              STAKING...
            </span>
          ) : (
            <>
              <Lock className="h-4 w-4 mr-2" />
              STAKE NTRU
            </>
          )}
        </Button>
      </div>
    </div>
  )
}
