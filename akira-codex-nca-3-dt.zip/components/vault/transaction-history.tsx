"use client"

import { ArrowUpRight, ArrowDownLeft, Repeat, Sparkles } from "lucide-react"

interface Transaction {
  id: string
  type: "EARN" | "SPEND" | "EXCHANGE" | "MUTATION"
  amount: number
  description: string
  timestamp: string
}

interface TransactionHistoryProps {
  transactions: Transaction[]
}

export function TransactionHistory({ transactions }: TransactionHistoryProps) {
  const getIcon = (type: Transaction["type"]) => {
    switch (type) {
      case "EARN":
        return <ArrowDownLeft className="h-4 w-4 text-cyan-400" style={{ filter: "drop-shadow(0 0 8px #00FFF7)" }} />
      case "SPEND":
        return <ArrowUpRight className="h-4 w-4 text-red-500" style={{ filter: "drop-shadow(0 0 8px #FF1A1A)" }} />
      case "EXCHANGE":
        return <Repeat className="h-4 w-4 text-amber-400" style={{ filter: "drop-shadow(0 0 8px #F59E0B)" }} />
      case "MUTATION":
        return <Sparkles className="h-4 w-4 text-purple-400" style={{ filter: "drop-shadow(0 0 8px #A020F0)" }} />
    }
  }

  const getAmountStyle = (type: Transaction["type"]) => {
    switch (type) {
      case "EARN":
        return { color: "#00FFF7", textShadow: "0 0 15px #00FFF7" }
      case "SPEND":
        return { color: "#FF1A1A", textShadow: "0 0 15px #FF1A1A" }
      case "EXCHANGE":
        return { color: "#F59E0B", textShadow: "0 0 15px #F59E0B" }
      case "MUTATION":
        return { color: "#A020F0", textShadow: "0 0 15px #A020F0" }
    }
  }

  return (
    <div
      className="rounded-lg border border-cyan-500/30 bg-zinc-900/50"
      style={{ boxShadow: "0 0 20px rgba(0,255,247,0.1)" }}
    >
      <div className="p-4 border-b border-zinc-700">
        <h3 className="font-mono text-sm font-bold text-white" style={{ textShadow: "0 0 10px #FFFFFF" }}>
          TRANSACTION HISTORY
        </h3>
      </div>
      <div className="divide-y divide-zinc-700/50 max-h-96 overflow-y-auto">
        {transactions.map((tx) => (
          <div key={tx.id} className="flex items-center justify-between p-4 hover:bg-black/50 transition-colors">
            <div className="flex items-center gap-3">
              <div
                className="h-8 w-8 rounded bg-black/80 flex items-center justify-center border border-zinc-700"
                style={{ boxShadow: "0 0 10px rgba(0,255,247,0.2)" }}
              >
                {getIcon(tx.type)}
              </div>
              <div>
                <p className="font-mono text-xs text-white" style={{ textShadow: "0 0 8px #FFFFFF" }}>
                  {tx.description}
                </p>
                <p className="text-[10px] text-zinc-400">{tx.timestamp}</p>
              </div>
            </div>
            <span className="font-mono text-sm font-bold" style={getAmountStyle(tx.type)}>
              {tx.type === "EARN" ? "+" : tx.type === "SPEND" ? "-" : ""}
              {tx.amount} NTRU
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}
