"use client"

import { useState, useRef, useEffect } from "react"
import { Play, Pause, Volume2, VolumeX, Maximize, Minimize, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"

interface VideoPlayerProps {
  src?: string
  poster?: string
  title?: string
  className?: string
  autoPlay?: boolean
}

export function VideoPlayer({
  src = "",
  poster = "/cyberpunk-video-thumbnail-neon.jpg",
  title = "WIRED CHAOS BROADCAST",
  className = "",
  autoPlay = false,
}: VideoPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [volume, setVolume] = useState(70)
  const [isMuted, setIsMuted] = useState(false)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [progress, setProgress] = useState(0)
  const [duration, setDuration] = useState(0)
  const [currentTime, setCurrentTime] = useState(0)
  const [error, setError] = useState<string | null>(null)

  const videoRef = useRef<HTMLVideoElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    const handleTimeUpdate = () => {
      setCurrentTime(video.currentTime)
      setProgress((video.currentTime / video.duration) * 100 || 0)
    }

    const handleLoadedMetadata = () => {
      setDuration(video.duration)
      setIsLoading(false)
    }

    const handleWaiting = () => setIsLoading(true)
    const handlePlaying = () => {
      setIsLoading(false)
      setIsPlaying(true)
    }
    const handlePause = () => setIsPlaying(false)
    const handleError = () => {
      setError("Video unavailable")
      setIsLoading(false)
    }

    video.addEventListener("timeupdate", handleTimeUpdate)
    video.addEventListener("loadedmetadata", handleLoadedMetadata)
    video.addEventListener("waiting", handleWaiting)
    video.addEventListener("playing", handlePlaying)
    video.addEventListener("pause", handlePause)
    video.addEventListener("error", handleError)

    return () => {
      video.removeEventListener("timeupdate", handleTimeUpdate)
      video.removeEventListener("loadedmetadata", handleLoadedMetadata)
      video.removeEventListener("waiting", handleWaiting)
      video.removeEventListener("playing", handlePlaying)
      video.removeEventListener("pause", handlePause)
      video.removeEventListener("error", handleError)
    }
  }, [])

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.volume = isMuted ? 0 : volume / 100
    }
  }, [volume, isMuted])

  const togglePlay = () => {
    if (!videoRef.current) return

    if (isPlaying) {
      videoRef.current.pause()
    } else {
      videoRef.current.play()
    }
  }

  const toggleMute = () => setIsMuted(!isMuted)

  const toggleFullscreen = () => {
    if (!containerRef.current) return

    if (!isFullscreen) {
      containerRef.current.requestFullscreen?.()
    } else {
      document.exitFullscreen?.()
    }
    setIsFullscreen(!isFullscreen)
  }

  const handleSeek = (value: number[]) => {
    if (!videoRef.current) return
    const newTime = (value[0] / 100) * duration
    videoRef.current.currentTime = newTime
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  return (
    <div
      ref={containerRef}
      className={`rounded-lg border border-cyan-500/30 bg-black overflow-hidden ${className}`}
      style={{ boxShadow: "0 0 20px rgba(0,255,247,0.2)" }}
      role="region"
      aria-label={`${title} Video Player`}
    >
      {/* Video Element */}
      <div className="relative aspect-video bg-black">
        <video
          ref={videoRef}
          src={src}
          poster={poster}
          className="w-full h-full object-cover"
          playsInline
          autoPlay={autoPlay}
          aria-label={title}
        />

        {/* Overlay for loading/error states */}
        {(isLoading || error || !src) && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/70">
            {isLoading ? (
              <Loader2 className="h-12 w-12 text-cyan-400 animate-spin" aria-label="Loading video" />
            ) : error ? (
              <p className="text-red-400 font-mono text-sm">{error}</p>
            ) : (
              <div className="text-center">
                <p className="text-zinc-400 font-mono text-sm">Video source not configured</p>
              </div>
            )}
          </div>
        )}

        {/* Click to play overlay */}
        {!isPlaying && !isLoading && src && (
          <button
            onClick={togglePlay}
            className="absolute inset-0 flex items-center justify-center bg-black/30 hover:bg-black/40 transition-colors focus:outline-none focus:ring-2 focus:ring-cyan-500"
            aria-label="Play video"
          >
            <div
              className="h-20 w-20 rounded-full bg-cyan-500/20 flex items-center justify-center border border-cyan-500/50"
              style={{ boxShadow: "0 0 30px rgba(0,255,247,0.3)" }}
            >
              <Play className="h-10 w-10 text-cyan-400 ml-1" aria-hidden="true" />
            </div>
          </button>
        )}
      </div>

      {/* Controls */}
      <div className="p-3 bg-zinc-900/80 space-y-2">
        {/* Title */}
        <div className="flex items-center justify-between mb-2">
          <h3 className="font-mono text-sm font-bold text-white truncate" style={{ textShadow: "0 0 10px #00FFF7" }}>
            {title}
          </h3>
          <span className="text-[10px] font-mono text-zinc-500">
            {formatTime(currentTime)} / {formatTime(duration)}
          </span>
        </div>

        {/* Progress bar */}
        <Slider
          value={[progress]}
          onValueChange={handleSeek}
          max={100}
          step={0.1}
          className="w-full"
          aria-label="Video progress"
        />

        {/* Control buttons */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={togglePlay}
              className="h-8 w-8 text-white hover:text-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-500"
              aria-label={isPlaying ? "Pause" : "Play"}
            >
              {isPlaying ? (
                <Pause className="h-4 w-4" aria-hidden="true" />
              ) : (
                <Play className="h-4 w-4" aria-hidden="true" />
              )}
            </Button>

            <Button
              variant="ghost"
              size="icon"
              onClick={toggleMute}
              className="h-8 w-8 text-white hover:text-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-500"
              aria-label={isMuted ? "Unmute" : "Mute"}
            >
              {isMuted ? (
                <VolumeX className="h-4 w-4" aria-hidden="true" />
              ) : (
                <Volume2 className="h-4 w-4" aria-hidden="true" />
              )}
            </Button>

            <Slider
              value={[isMuted ? 0 : volume]}
              onValueChange={(v) => {
                setVolume(v[0])
                if (v[0] > 0) setIsMuted(false)
              }}
              max={100}
              step={1}
              className="w-20"
              aria-label="Volume"
            />
          </div>

          <Button
            variant="ghost"
            size="icon"
            onClick={toggleFullscreen}
            className="h-8 w-8 text-white hover:text-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-500"
            aria-label={isFullscreen ? "Exit fullscreen" : "Enter fullscreen"}
          >
            {isFullscreen ? (
              <Minimize className="h-4 w-4" aria-hidden="true" />
            ) : (
              <Maximize className="h-4 w-4" aria-hidden="true" />
            )}
          </Button>
        </div>
      </div>
    </div>
  )
}
