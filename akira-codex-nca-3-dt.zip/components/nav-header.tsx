"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X, ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { cn } from "@/lib/utils"

const navLinks = [
  { href: "/", label: "HOME" },
  { href: "/terminal", label: "TERMINAL" },
  { href: "/vault", label: "VAULT" },
  { href: "/portal", label: "PORTAL" },
  { href: "/echo-engineers", label: "ECHO ENGINEERS" },
]

const systemLinks = [
  { href: "/giga-engine", label: "GIGA ENGINE PACK" },
  { href: "/meta-brain", label: "META-BRAIN" },
  { href: "/cathedral", label: "NEURAL CATHEDRAL" },
]

export function NavHeader() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b border-zinc-800/50 bg-black/80 backdrop-blur-md">
      <nav className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link href="/" className="flex items-center gap-2">
          <div className="relative h-8 w-8">
            <div className="absolute inset-0 rounded bg-red-500 animate-pulse-glow" />
            <div className="absolute inset-1 rounded bg-black flex items-center justify-center">
              <span className="text-red-500 font-mono text-xs font-bold drop-shadow-[0_0_8px_rgba(239,68,68,0.8)]">
                AK
              </span>
            </div>
          </div>
          <span className="font-mono text-sm font-bold tracking-widest text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]">
            AKIRA CODEX
          </span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-6">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={cn(
                "font-mono text-xs tracking-wider transition-colors drop-shadow-[0_0_6px_rgba(255,255,255,0.5)]",
                link.href === "/terminal" || link.href === "/vault" || link.href === "/portal"
                  ? "text-red-400 hover:text-red-300 drop-shadow-[0_0_8px_rgba(239,68,68,0.8)]"
                  : link.href === "/echo-engineers"
                    ? "text-cyan-400 hover:text-cyan-300 drop-shadow-[0_0_8px_rgba(34,211,238,0.8)]"
                    : "text-zinc-200 hover:text-red-400",
              )}
            >
              {link.label}
            </Link>
          ))}

          {/* Systems Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="font-mono text-xs tracking-wider text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition-colors drop-shadow-[0_0_8px_rgba(34,211,238,0.8)]">
                SYSTEMS <ChevronDown className="h-3 w-3" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="bg-zinc-900 border-zinc-800">
              {systemLinks.map((link) => (
                <DropdownMenuItem key={link.href} asChild>
                  <Link
                    href={link.href}
                    className="font-mono text-xs text-zinc-200 hover:text-white cursor-pointer drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]"
                  >
                    {link.label}
                  </Link>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          <Button
            size="sm"
            className="bg-red-600 text-white font-mono text-xs tracking-wider hover:bg-red-500 drop-shadow-[0_0_12px_rgba(239,68,68,0.6)]"
          >
            CONNECT
          </Button>
        </div>

        {/* Mobile Menu Toggle */}
        <Button variant="ghost" size="icon" className="md:hidden text-white" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </nav>

      {/* Mobile Nav */}
      <div
        className={cn(
          "md:hidden absolute top-16 left-0 right-0 bg-black border-b border-zinc-800 transition-all duration-300",
          isOpen ? "opacity-100 visible" : "opacity-0 invisible",
        )}
      >
        <div className="container mx-auto px-4 py-4 flex flex-col gap-4">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              onClick={() => setIsOpen(false)}
              className={cn(
                "font-mono text-sm tracking-wider transition-colors drop-shadow-[0_0_6px_rgba(255,255,255,0.5)]",
                link.href === "/terminal" || link.href === "/vault" || link.href === "/portal"
                  ? "text-red-400 hover:text-red-300"
                  : link.href === "/echo-engineers"
                    ? "text-cyan-400 hover:text-cyan-300"
                    : "text-zinc-200 hover:text-red-400",
              )}
            >
              {link.label}
            </Link>
          ))}
          <div className="border-t border-zinc-800 pt-4 mt-2">
            <p className="font-mono text-[10px] text-cyan-400 mb-2 drop-shadow-[0_0_6px_rgba(34,211,238,0.8)]">
              SYSTEMS
            </p>
            {systemLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setIsOpen(false)}
                className="block font-mono text-sm tracking-wider text-zinc-200 hover:text-cyan-400 py-2 drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]"
              >
                {link.label}
              </Link>
            ))}
          </div>
          <Button size="sm" className="bg-red-600 text-white font-mono text-xs tracking-wider w-full mt-2">
            CONNECT
          </Button>
        </div>
      </div>
    </header>
  )
}
