"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ExternalLink, ChevronLeft, ChevronRight } from "lucide-react"
import Link from "next/link"

const nftCollections = [
  {
    id: 1,
    title: "NETERU GENESIS",
    description: "Original collection - Foundation of the Codex",
    image: "/cyberpunk-neon-art-with-red-and-cyan-colors-abstra.jpg",
    status: "OWNED",
  },
  {
    id: 2,
    title: "WIRED CHAOS",
    description: "Neural pathways visualized in digital form",
    image: "/neural-network-digital-art-dark-background-with-re.jpg",
    status: "OWNED",
  },
  {
    id: 3,
    title: "APINAYA SIGNAL",
    description: "33.3 FM frequency captured in visual form",
    image: "/radio-frequency-visualization-cyberpunk-style-crim.jpg",
    status: "OWNED",
  },
  {
    id: 4,
    title: "NETERU GATE",
    description: "Portal to the mythic economy",
    image: "/ancient-futuristic-gate-portal-dark-sci-fi-art.jpg",
    status: "OWNED",
  },
]

export function NFTGallery() {
  const [activeIndex, setActiveIndex] = useState(0)

  const nextSlide = () => {
    setActiveIndex((prev) => (prev + 1) % nftCollections.length)
  }

  const prevSlide = () => {
    setActiveIndex((prev) => (prev - 1 + nftCollections.length) % nftCollections.length)
  }

  return (
    <section id="gallery" className="relative py-24 bg-zinc-900/50">
      <div className="container mx-auto px-4">
        {/* Section header */}
        <div className="text-center mb-16">
          <span className="font-mono text-xs tracking-widest text-red-400 mb-4 block drop-shadow-[0_0_10px_rgba(248,113,113,0.8)] font-bold">
            ON-CHAIN ASSETS
          </span>
          <h2 className="text-3xl md:text-5xl font-bold mb-4 text-white drop-shadow-[0_0_20px_rgba(255,255,255,0.6)]">
            NETERU ARTIFACTS COLLECTION
          </h2>
          <p className="text-zinc-100 max-w-xl mx-auto mb-6 drop-shadow-[0_0_8px_rgba(255,255,255,0.4)]">
            Verified ownership by BlockchaintrapperETH | NEURO META X | DeGenSith.eth | NETERU STUDIOS. Each piece
            carries IP rights within the WIRED CHAOS META ecosystem.
          </p>
          <Link
            href="https://opensea.io/BlockchaintrapperETH"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-cyan-400 hover:text-cyan-300 transition-colors font-mono text-sm font-bold drop-shadow-[0_0_10px_rgba(34,211,238,0.8)]"
          >
            VIEW ON OPENSEA
            <ExternalLink className="h-4 w-4" />
          </Link>
        </div>

        {/* Gallery carousel */}
        <div className="relative max-w-4xl mx-auto">
          {/* Navigation buttons */}
          <Button
            size="icon"
            variant="ghost"
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-12 z-10 hidden md:flex text-white hover:text-red-400 hover:drop-shadow-[0_0_15px_rgba(248,113,113,0.8)]"
            onClick={prevSlide}
          >
            <ChevronLeft className="h-6 w-6" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-12 z-10 hidden md:flex text-white hover:text-red-400 hover:drop-shadow-[0_0_15px_rgba(248,113,113,0.8)]"
            onClick={nextSlide}
          >
            <ChevronRight className="h-6 w-6" />
          </Button>

          {/* Main display */}
          <div className="grid md:grid-cols-2 gap-8 items-center">
            {/* Image */}
            <div className="relative aspect-square rounded-lg overflow-hidden border-2 border-red-500 shadow-[0_0_30px_rgba(239,68,68,0.5)]">
              <img
                src={`/animated-cyberpunk-nft-artifact-glowing-neon-.jpg?key=v8p31&height=600&width=600&query=animated+cyberpunk+nft+artifact+glowing+neon+${nftCollections[activeIndex].title}`}
                alt={nftCollections[activeIndex].title}
                className="w-full h-full object-cover animate-pulse"
              />
              <div className="absolute top-4 right-4 px-3 py-1 rounded-full bg-red-600 text-white font-mono text-xs font-bold shadow-[0_0_15px_rgba(239,68,68,0.8)]">
                {nftCollections[activeIndex].status}
              </div>
            </div>

            {/* Info */}
            <div className="text-center md:text-left">
              <span className="font-mono text-xs text-cyan-400 tracking-widest drop-shadow-[0_0_10px_rgba(34,211,238,0.8)] font-bold">
                #{String(activeIndex + 1).padStart(3, "0")}
              </span>
              <h3 className="text-2xl md:text-3xl font-bold mt-2 mb-4 text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.6)]">
                {nftCollections[activeIndex].title}
              </h3>
              <p className="text-zinc-100 mb-6 drop-shadow-[0_0_8px_rgba(255,255,255,0.4)]">
                {nftCollections[activeIndex].description}
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                <Button className="bg-red-600 text-white font-mono text-sm hover:bg-red-500 shadow-[0_0_20px_rgba(239,68,68,0.5)] font-bold">
                  VIEW DETAILS
                </Button>
                <Button
                  variant="outline"
                  className="border-zinc-400 text-white font-mono text-sm bg-transparent hover:bg-zinc-800 shadow-[0_0_15px_rgba(255,255,255,0.3)] font-bold"
                >
                  VERIFY ON-CHAIN
                </Button>
              </div>
            </div>
          </div>

          {/* Thumbnails */}
          <div className="flex justify-center gap-4 mt-8">
            {nftCollections.map((nft, index) => (
              <button
                key={nft.id}
                onClick={() => setActiveIndex(index)}
                className={`w-16 h-16 rounded overflow-hidden border-2 transition-all ${
                  index === activeIndex
                    ? "border-red-500 scale-110 shadow-[0_0_20px_rgba(239,68,68,0.6)]"
                    : "border-zinc-600 opacity-50 hover:opacity-100 hover:border-red-400"
                }`}
              >
                <img
                  src={`/animated-nft-thumbnail-.jpg?key=eyhbd&height=64&width=64&query=animated+nft+thumbnail+${nft.title}`}
                  alt={nft.title}
                  className="w-full h-full object-cover"
                />
              </button>
            ))}
          </div>

          {/* Mobile navigation */}
          <div className="flex justify-center gap-4 mt-6 md:hidden">
            <Button size="icon" variant="ghost" onClick={prevSlide} className="text-white">
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <Button size="icon" variant="ghost" onClick={nextSlide} className="text-white">
              <ChevronRight className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
