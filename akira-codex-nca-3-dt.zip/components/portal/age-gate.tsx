"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import dynamic from "next/dynamic"
import { GlitchText } from "@/components/glitch-text"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Shield, Sparkles, Flame, Eye, Lock } from "lucide-react"

const PortalScene = dynamic(() => import("@/components/three/portal-scene").then((mod) => mod.PortalScene), {
  ssr: false,
  loading: () => <div className="w-full h-full bg-black" />,
})

export type AgeTier = "light" | "shadow" | "redveil" | "void"

interface TierConfig {
  id: AgeTier
  name: string
  ageRequirement: string
  description: string
  icon: typeof Shield
  color: string
  glowColor: "cyan" | "gold" | "crimson" | "white"
  features: string[]
  restricted?: boolean
}

const tiers: TierConfig[] = [
  {
    id: "light",
    name: "LIGHT GATE",
    ageRequirement: "ALL AGES",
    description: "Safe passage for all seekers. Mythology, symbolism, and family-friendly lore exploration.",
    icon: Shield,
    color: "#06b6d4",
    glowColor: "cyan",
    features: ["Mythological Stories", "Symbol Dictionary", "Character Bios", "World Building"],
  },
  {
    id: "shadow",
    name: "SHADOW GATE",
    ageRequirement: "18+",
    description: "Mature themes emerge. Complex narratives, moral ambiguity, and darker storytelling.",
    icon: Sparkles,
    color: "#fbbf24",
    glowColor: "gold",
    features: ["Mature Narratives", "Complex Characters", "Dark Themes", "Psychological Depth"],
  },
  {
    id: "redveil",
    name: "RED VEIL",
    ageRequirement: "21+",
    description: "Symbolic eroticism and adult content. Artistic expression within platform guidelines.",
    icon: Flame,
    color: "#dc2626",
    glowColor: "crimson",
    features: ["Symbolic Eroticism", "Adult Themes", "Artistic Expression", "Mature Romance"],
    restricted: true,
  },
  {
    id: "void",
    name: "VOID SANCTUM",
    ageRequirement: "21+ NSFW",
    description: "Unrestricted creative expression. Toggle-gated for explicit content.",
    icon: Eye,
    color: "#8b5cf6",
    glowColor: "white",
    features: ["Unrestricted Content", "NSFW Toggle", "Full Expression", "Private Realm"],
    restricted: true,
  },
]

interface AgeGateProps {
  onTierSelect?: (tier: AgeTier) => void
  defaultTier?: AgeTier
}

export function AgeGate({ onTierSelect, defaultTier }: AgeGateProps) {
  const router = useRouter()
  const [selectedTier, setSelectedTier] = useState<AgeTier | null>(defaultTier || null)
  const [nsfwEnabled, setNsfwEnabled] = useState(false)
  const [confirmed, setConfirmed] = useState(false)
  const [birthYear, setBirthYear] = useState("")

  const calculateAge = (year: string) => {
    const currentYear = new Date().getFullYear()
    return currentYear - Number.parseInt(year)
  }

  const canAccessTier = (tier: TierConfig) => {
    if (!birthYear) return tier.id === "light"
    const age = calculateAge(birthYear)
    if (tier.id === "light") return true
    if (tier.id === "shadow") return age >= 18
    if (tier.id === "redveil") return age >= 21
    if (tier.id === "void") return age >= 21 && nsfwEnabled
    return false
  }

  const handleEnterPortal = () => {
    if (selectedTier && onTierSelect) {
      onTierSelect(selectedTier)
    }
    // Store tier in localStorage for persistence
    if (selectedTier) {
      localStorage.setItem("akira-tier", selectedTier)
      localStorage.setItem("akira-nsfw", nsfwEnabled.toString())
      router.push(`/realm/${selectedTier}`)
    }
  }

  return (
    <div className="min-h-screen bg-black text-white relative overflow-hidden">
      {/* 3D Background */}
      <div className="absolute inset-0 opacity-30">
        <PortalScene />
      </div>

      {/* Content Overlay */}
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center p-4">
        {/* Header */}
        <div className="text-center mb-8">
          <GlitchText
            text="AKIRA CODEX"
            as="h1"
            className="text-4xl md:text-5xl font-bold mb-2"
            glow={true}
            glowColor="crimson"
          />
          <p className="font-mono text-sm text-cyan-400" style={{ textShadow: "0 0 10px rgba(6,182,212,0.8)" }}>
            NETERU APINAYA GATEWAY
          </p>
        </div>

        {/* Age Verification */}
        {!confirmed && (
          <div className="w-full max-w-md mb-8">
            <div className="p-6 rounded-lg border border-zinc-800 bg-zinc-900/80 backdrop-blur">
              <h2 className="font-mono text-sm font-bold text-white mb-4 text-center">AGE VERIFICATION</h2>
              <div className="flex items-center justify-center gap-4 mb-4">
                <label className="font-mono text-xs text-zinc-400">BIRTH YEAR:</label>
                <input
                  type="number"
                  min="1900"
                  max={new Date().getFullYear()}
                  value={birthYear}
                  onChange={(e) => setBirthYear(e.target.value)}
                  placeholder="YYYY"
                  className="w-24 px-3 py-2 rounded bg-zinc-800 border border-zinc-700 font-mono text-sm text-white text-center focus:border-cyan-500 focus:outline-none"
                />
              </div>
              {birthYear && (
                <p className="text-center text-xs text-zinc-400 mb-4">
                  Calculated Age: <span className="text-cyan-400 font-bold">{calculateAge(birthYear)} years</span>
                </p>
              )}
              <Button
                onClick={() => setConfirmed(true)}
                disabled={!birthYear || calculateAge(birthYear) < 13}
                className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-mono text-xs"
              >
                VERIFY & CONTINUE
              </Button>
            </div>
          </div>
        )}

        {/* Tier Selection */}
        {confirmed && (
          <>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 w-full max-w-6xl mb-8">
              {tiers.map((tier) => {
                const Icon = tier.icon
                const accessible = canAccessTier(tier)
                const isSelected = selectedTier === tier.id

                return (
                  <button
                    key={tier.id}
                    onClick={() => accessible && setSelectedTier(tier.id)}
                    disabled={!accessible}
                    className={`relative p-6 rounded-lg border text-left transition-all ${
                      isSelected
                        ? "border-opacity-100 bg-opacity-20"
                        : accessible
                          ? "border-zinc-700 bg-zinc-900/50 hover:border-opacity-50"
                          : "border-zinc-800 bg-zinc-900/30 opacity-50 cursor-not-allowed"
                    }`}
                    style={{
                      borderColor: isSelected ? tier.color : undefined,
                      backgroundColor: isSelected ? `${tier.color}15` : undefined,
                      boxShadow: isSelected ? `0 0 30px ${tier.color}30` : undefined,
                    }}
                  >
                    {!accessible && (
                      <div className="absolute top-3 right-3">
                        <Lock className="h-4 w-4 text-zinc-500" />
                      </div>
                    )}

                    <div
                      className="h-12 w-12 rounded-lg flex items-center justify-center mb-4"
                      style={{ backgroundColor: `${tier.color}20` }}
                    >
                      <Icon className="h-6 w-6" style={{ color: tier.color }} />
                    </div>

                    <h3 className="font-mono text-sm font-bold text-white mb-1">{tier.name}</h3>
                    <p
                      className="font-mono text-[10px] mb-3"
                      style={{ color: tier.color, textShadow: `0 0 10px ${tier.color}` }}
                    >
                      {tier.ageRequirement}
                    </p>
                    <p className="text-xs text-zinc-400 mb-4">{tier.description}</p>

                    <div className="space-y-1">
                      {tier.features.map((feature) => (
                        <div key={feature} className="flex items-center gap-2">
                          <div className="w-1 h-1 rounded-full" style={{ backgroundColor: tier.color }} />
                          <span className="text-[10px] text-zinc-300">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </button>
                )
              })}
            </div>

            {/* NSFW Toggle (for 21+ users) */}
            {birthYear && calculateAge(birthYear) >= 21 && (
              <div className="w-full max-w-md mb-8">
                <div className="p-4 rounded-lg border border-zinc-800 bg-zinc-900/80 backdrop-blur">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-mono text-sm font-bold text-white">NSFW CONTENT</p>
                      <p className="text-xs text-zinc-400">Enable access to Void Sanctum</p>
                    </div>
                    <Switch
                      checked={nsfwEnabled}
                      onCheckedChange={setNsfwEnabled}
                      className="data-[state=checked]:bg-red-600"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Enter Button */}
            {selectedTier && (
              <Button
                onClick={handleEnterPortal}
                className="px-8 py-3 text-lg font-mono tracking-wider"
                style={{
                  backgroundColor: tiers.find((t) => t.id === selectedTier)?.color,
                  boxShadow: `0 0 30px ${tiers.find((t) => t.id === selectedTier)?.color}50`,
                }}
              >
                ENTER {tiers.find((t) => t.id === selectedTier)?.name}
              </Button>
            )}
          </>
        )}

        {/* Footer */}
        <div className="mt-8 text-center">
          <p className="font-mono text-[10px] text-zinc-500">
            WIRED CHAOS META ECOSYSTEM | NETERU STUDIOS | 789 STUDIOS
          </p>
          <p className="font-mono text-[10px] text-zinc-600 mt-1">
            By entering, you agree to our content policies and age verification.
          </p>
        </div>
      </div>
    </div>
  )
}
