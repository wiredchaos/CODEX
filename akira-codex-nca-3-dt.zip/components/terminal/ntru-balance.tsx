"use client"

import { Coins, TrendingUp, Clock } from "lucide-react"

interface NTRUBalanceProps {
  balance: number
  pendingRewards: number
  nextEpoch: string
}

export function NTRUBalance({ balance, pendingRewards, nextEpoch }: NTRUBalanceProps) {
  return (
    <div
      className="rounded-lg border border-amber-500/30 bg-zinc-900/50 p-6"
      style={{ boxShadow: "0 0 20px rgba(245,158,11,0.15)" }}
    >
      <div className="flex items-center gap-3 mb-6">
        <div
          className="h-10 w-10 rounded bg-amber-500/20 flex items-center justify-center"
          style={{ boxShadow: "0 0 15px rgba(245,158,11,0.4)" }}
        >
          <Coins className="h-5 w-5 text-amber-400" style={{ filter: "drop-shadow(0 0 8px #F59E0B)" }} />
        </div>
        <div>
          <h3 className="font-mono text-sm font-bold text-white" style={{ textShadow: "0 0 10px #FFFFFF" }}>
            NTRU VAULT
          </h3>
          <p className="text-xs text-zinc-300" style={{ textShadow: "0 0 6px #FFFFFF" }}>
            Neteru Token Balance
          </p>
        </div>
      </div>

      {/* Main Balance */}
      <div className="text-center py-6 border-y border-zinc-700/50 mb-6">
        <p className="text-[10px] font-mono text-zinc-300 mb-2">AVAILABLE BALANCE</p>
        <p
          className="font-mono text-4xl font-bold text-amber-400"
          style={{ textShadow: "0 0 30px #F59E0B, 0 0 60px #F59E0B" }}
        >
          {balance.toLocaleString()}
        </p>
        <p className="font-mono text-xs text-zinc-300 mt-1" style={{ textShadow: "0 0 6px #FFFFFF" }}>
          NTRU
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div
          className="rounded-lg bg-black/50 p-3 border border-cyan-500/20"
          style={{ boxShadow: "0 0 10px rgba(0,255,247,0.1)" }}
        >
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="h-4 w-4 text-cyan-400" style={{ filter: "drop-shadow(0 0 6px #00FFF7)" }} />
            <span className="text-[10px] font-mono text-zinc-300">PENDING</span>
          </div>
          <p className="font-mono text-lg font-bold text-cyan-400" style={{ textShadow: "0 0 15px #00FFF7" }}>
            +{pendingRewards}
          </p>
        </div>

        <div
          className="rounded-lg bg-black/50 p-3 border border-red-500/20"
          style={{ boxShadow: "0 0 10px rgba(255,26,26,0.1)" }}
        >
          <div className="flex items-center gap-2 mb-2">
            <Clock className="h-4 w-4 text-red-500" style={{ filter: "drop-shadow(0 0 6px #FF1A1A)" }} />
            <span className="text-[10px] font-mono text-zinc-300">NEXT EPOCH</span>
          </div>
          <p className="font-mono text-lg font-bold text-red-500" style={{ textShadow: "0 0 15px #FF1A1A" }}>
            {nextEpoch}
          </p>
        </div>
      </div>
    </div>
  )
}
