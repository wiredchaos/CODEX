"use client"

import Link from "next/link"
import { cn } from "@/lib/utils"
import { ExternalLink } from "lucide-react"
import type { NFTArtifact } from "@/lib/types/ntru"

interface ArtifactCardProps {
  artifact: NFTArtifact
  selected?: boolean
  onSelect?: () => void
}

export function ArtifactCard({ artifact, selected, onSelect }: ArtifactCardProps) {
  const chainColors: Record<string, string> = {
    ETH: "text-blue-400 border-blue-400/30",
    SOL: "text-purple-400 border-purple-400/30",
    XRPL: "text-cyan-400 border-cyan-400/30",
    HBAR: "text-green-400 border-green-400/30",
  }

  const rarityColors: Record<string, string> = {
    COMMON: "bg-zinc-500/20 text-zinc-300",
    UNCOMMON: "bg-green-500/20 text-green-400",
    RARE: "bg-blue-500/20 text-blue-400",
    EPIC: "bg-purple-500/20 text-purple-400",
    LEGENDARY: "bg-amber-500/20 text-amber-400",
    MYTHIC: "bg-red-500/20 text-red-500",
  }

  return (
    <div
      className={cn(
        "relative group w-full text-left rounded-lg border bg-zinc-900/50 p-3 transition-all duration-300",
        selected
          ? "border-red-500 shadow-lg shadow-red-500/20"
          : "border-zinc-700 hover:border-red-500/50 hover:bg-zinc-900/80",
        artifact.is_404_state && "animate-pulse border-cyan-500",
      )}
      style={{ boxShadow: selected ? "0 0 25px rgba(255,26,26,0.3)" : "0 0 15px rgba(0,255,247,0.1)" }}
    >
      {/* 404 State Indicator */}
      {artifact.is_404_state && (
        <div
          className="absolute -top-2 -right-2 px-2 py-0.5 bg-cyan-500 text-black text-[10px] font-mono font-bold rounded"
          style={{ boxShadow: "0 0 15px #00FFF7" }}
        >
          404
        </div>
      )}

      <Link
        href={`/artifact/${artifact.id}`}
        className="absolute top-2 left-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity"
      >
        <div
          className="p-1.5 rounded bg-black/80 border border-cyan-500/50 hover:bg-cyan-500/20"
          style={{ boxShadow: "0 0 10px rgba(0,255,247,0.3)" }}
        >
          <ExternalLink className="h-3 w-3 text-cyan-400" />
        </div>
      </Link>

      {/* Artifact Image - clickable for selection */}
      <button onClick={onSelect} className="w-full">
        <div className="aspect-square rounded bg-black/50 mb-3 overflow-hidden">
          <img
            src={artifact.image_url || `/placeholder.svg?height=200&width=200&query=${artifact.name} NFT artifact`}
            alt={artifact.name}
            className={cn(
              "w-full h-full object-cover transition-transform duration-300",
              "group-hover:scale-105",
              artifact.is_404_state && "grayscale contrast-125",
            )}
          />
        </div>
      </button>

      {/* Artifact Info */}
      <div className="space-y-2">
        <div className="flex items-start justify-between gap-2">
          <h4 className="font-mono text-xs font-bold text-white truncate" style={{ textShadow: "0 0 8px #FFFFFF" }}>
            {artifact.name}
          </h4>
          <span
            className={cn("text-[10px] font-mono px-1.5 py-0.5 rounded border", chainColors[artifact.chain])}
            style={{ textShadow: "0 0 8px currentColor" }}
          >
            {artifact.chain}
          </span>
        </div>

        <div className="flex items-center justify-between">
          <span
            className={cn("text-[10px] font-mono px-2 py-0.5 rounded", rarityColors[artifact.rarity])}
            style={{ textShadow: "0 0 8px currentColor" }}
          >
            {artifact.rarity}
          </span>
          <span className="text-[10px] font-mono text-amber-400" style={{ textShadow: "0 0 8px #F59E0B" }}>
            PWR: {artifact.resonance_power}
          </span>
        </div>

        {/* Mutation Progress with glow */}
        {artifact.mutation_level > 0 && (
          <div className="pt-1">
            <div className="flex items-center justify-between text-[10px] font-mono text-zinc-300 mb-1">
              <span style={{ textShadow: "0 0 6px #FFFFFF" }}>MUTATION LV.{artifact.mutation_level}</span>
              <span style={{ textShadow: "0 0 6px #00FFF7" }}>{artifact.mutation_progress}%</span>
            </div>
            <div className="h-1.5 bg-black rounded-full overflow-hidden border border-zinc-700">
              <div
                className="h-full bg-gradient-to-r from-red-500 to-cyan-500 transition-all duration-500"
                style={{
                  width: `${artifact.mutation_progress}%`,
                  boxShadow: "0 0 10px #00FFF7, 0 0 20px #FF1A1A",
                }}
              />
            </div>
          </div>
        )}

        <div className="pt-2 border-t border-zinc-700/50">
          <Link
            href={`/artifact/${artifact.id}`}
            className="flex items-center justify-between text-[10px] font-mono text-cyan-400 hover:text-cyan-300 transition-colors"
          >
            <span style={{ textShadow: "0 0 8px #00FFF7" }}>VIEW PROFILE / RENT</span>
            <ExternalLink className="h-3 w-3" />
          </Link>
        </div>
      </div>
    </div>
  )
}
