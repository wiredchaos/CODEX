"use client"

import { useState } from "react"
import { ArrowRight, Zap, Shield, Sparkles, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface ExchangeConsoleProps {
  ntruBalance: number
  selectedArtifact?: {
    id: string
    name: string
    resonance_power: number
  }
}

type ExchangePath = "BASIC" | "NTRU"

export function ExchangeConsole({ ntruBalance, selectedArtifact }: ExchangeConsoleProps) {
  const [exchangePath, setExchangePath] = useState<ExchangePath>("BASIC")
  const [isProcessing, setIsProcessing] = useState(false)

  const handleExchange = async () => {
    if (!selectedArtifact) return
    setIsProcessing(true)
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setIsProcessing(false)
  }

  return (
    <div className="rounded-lg border border-zinc-700 bg-zinc-900/50 p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="h-10 w-10 rounded bg-red-500/20 flex items-center justify-center">
          <Sparkles className="h-5 w-5 text-red-500 drop-shadow-[0_0_8px_rgba(239,68,68,0.8)]" />
        </div>
        <div>
          <h3 className="font-mono text-sm font-bold text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]">
            ARTIFACT EXCHANGE
          </h3>
          <p className="text-xs text-zinc-200">Choose your transmutation path</p>
        </div>
      </div>

      {/* Exchange Path Toggle */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        <button
          onClick={() => setExchangePath("BASIC")}
          className={cn(
            "relative rounded-lg border p-4 text-left transition-all duration-300",
            exchangePath === "BASIC"
              ? "border-cyan-400 bg-cyan-500/20 shadow-[0_0_20px_rgba(34,211,238,0.3)]"
              : "border-zinc-700 hover:border-cyan-500/50",
          )}
        >
          <Shield className="h-5 w-5 text-cyan-400 mb-2 drop-shadow-[0_0_8px_rgba(34,211,238,0.8)]" />
          <h4 className="font-mono text-xs font-bold text-white drop-shadow-[0_0_6px_rgba(255,255,255,0.8)]">
            BASIC PATH
          </h4>
          <p className="text-[10px] text-zinc-200 mt-1">Free, stable outcomes</p>
          <div className="mt-3 flex items-center gap-2">
            <span className="text-[10px] font-mono text-cyan-300 drop-shadow-[0_0_6px_rgba(34,211,238,0.8)]">
              COST: FREE
            </span>
          </div>
        </button>

        <button
          onClick={() => setExchangePath("NTRU")}
          className={cn(
            "relative rounded-lg border p-4 text-left transition-all duration-300",
            exchangePath === "NTRU"
              ? "border-red-500 bg-red-500/20 shadow-[0_0_20px_rgba(239,68,68,0.3)]"
              : "border-zinc-700 hover:border-red-500/50",
          )}
        >
          <Zap className="h-5 w-5 text-red-500 mb-2 drop-shadow-[0_0_8px_rgba(239,68,68,0.8)]" />
          <h4 className="font-mono text-xs font-bold text-white drop-shadow-[0_0_6px_rgba(255,255,255,0.8)]">
            NTRU PATH
          </h4>
          <p className="text-[10px] text-zinc-200 mt-1">High variance, rare mutations</p>
          <div className="mt-3 flex items-center gap-2">
            <span className="text-[10px] font-mono text-red-400 drop-shadow-[0_0_6px_rgba(239,68,68,0.8)]">
              COST: 100 NTRU
            </span>
          </div>
        </button>
      </div>

      {/* Selected Artifact Display */}
      <div className="rounded-lg border border-zinc-700 bg-black/50 p-4 mb-6">
        <p className="text-[10px] font-mono text-zinc-200 mb-2 drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]">
          SELECTED ARTIFACT
        </p>
        {selectedArtifact ? (
          <div className="flex items-center justify-between">
            <span className="font-mono text-sm text-white drop-shadow-[0_0_6px_rgba(255,255,255,0.8)]">
              {selectedArtifact.name}
            </span>
            <span className="text-xs font-mono text-cyan-300 drop-shadow-[0_0_6px_rgba(34,211,238,0.8)]">
              PWR: {selectedArtifact.resonance_power}
            </span>
          </div>
        ) : (
          <p className="font-mono text-sm text-zinc-300">Select an artifact from inventory</p>
        )}
      </div>

      {/* Exchange Preview */}
      <div className="rounded-lg border border-dashed border-zinc-700 p-4 mb-6">
        <div className="flex items-center justify-between">
          <div className="text-center">
            <p className="text-[10px] font-mono text-zinc-200 mb-1 drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]">
              INPUT
            </p>
            <p className="font-mono text-sm text-white drop-shadow-[0_0_6px_rgba(255,255,255,0.8)]">
              {selectedArtifact?.name || "---"}
            </p>
          </div>
          <ArrowRight className="h-5 w-5 text-zinc-400" />
          <div className="text-center">
            <p className="text-[10px] font-mono text-zinc-200 mb-1 drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]">
              OUTPUT
            </p>
            <p
              className={cn(
                "font-mono text-sm",
                exchangePath === "NTRU"
                  ? "text-red-400 drop-shadow-[0_0_8px_rgba(239,68,68,0.8)]"
                  : "text-cyan-300 drop-shadow-[0_0_8px_rgba(34,211,238,0.8)]",
              )}
            >
              {exchangePath === "NTRU" ? "??? RARE" : "STANDARD"}
            </p>
          </div>
        </div>
      </div>

      {/* Warning for NTRU Path */}
      {exchangePath === "NTRU" && ntruBalance < 100 && (
        <div className="flex items-start gap-2 rounded-lg bg-red-500/10 border border-red-500/30 p-3 mb-6">
          <AlertTriangle className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
          <p className="text-xs text-red-400">Insufficient NTRU balance. You need 100 NTRU to use this path.</p>
        </div>
      )}

      {/* Execute Button */}
      <Button
        onClick={handleExchange}
        disabled={!selectedArtifact || isProcessing || (exchangePath === "NTRU" && ntruBalance < 100)}
        className={cn(
          "w-full font-mono text-xs tracking-wider text-white",
          exchangePath === "NTRU" ? "bg-red-600 hover:bg-red-500" : "bg-cyan-600 hover:bg-cyan-500",
        )}
      >
        {isProcessing ? (
          <span className="flex items-center gap-2">
            <span className="h-4 w-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
            TRANSMUTING...
          </span>
        ) : (
          `EXECUTE ${exchangePath} EXCHANGE`
        )}
      </Button>
    </div>
  )
}
