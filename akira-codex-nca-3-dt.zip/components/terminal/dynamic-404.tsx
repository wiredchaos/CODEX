"use client"

import { useState, useEffect } from "react"
import { AlertOctagon, RefreshCw, Zap, Shuffle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface Dynamic404Props {
  artifact404Count: number
  onRecoveryAttempt?: () => void
}

const DYNAMIC_404_ART_FORMS = [
  // Original 22
  {
    name: "VOID SPECTER",
    style: "Ethereal ghost outline with crimson energy trails",
    icon: "👻",
    color: "from-red-500/20 to-purple-500/20",
  },
  {
    name: "GLITCH PHANTOM",
    style: "Pixelated distortion with scan lines",
    icon: "📺",
    color: "from-cyan-500/20 to-red-500/20",
  },
  {
    name: "TEMPORAL FRACTURE",
    style: "Shattered glass timeline fragments",
    icon: "🔮",
    color: "from-purple-500/20 to-blue-500/20",
  },
  {
    name: "NEURAL DECAY",
    style: "Corrupted neural network visualization",
    icon: "🧠",
    color: "from-green-500/20 to-red-500/20",
  },
  {
    name: "SIGNAL STATIC",
    style: "TV static noise pattern overlay",
    icon: "📡",
    color: "from-zinc-500/20 to-white/10",
  },
  { name: "CRIMSON VEIL", style: "Blood mist obscuring form", icon: "🩸", color: "from-red-600/30 to-red-900/20" },
  {
    name: "FREQUENCY GHOST",
    style: "Sound wave silhouette distortion",
    icon: "🎵",
    color: "from-cyan-400/20 to-purple-400/20",
  },
  {
    name: "QUANTUM BLUR",
    style: "Probability cloud superposition",
    icon: "⚛️",
    color: "from-blue-500/20 to-cyan-500/20",
  },
  { name: "SHADOW ECHO", style: "Multiple shadow afterimages", icon: "🌑", color: "from-zinc-900/40 to-black/60" },
  {
    name: "DATA CORRUPTION",
    style: "Binary cascade waterfall effect",
    icon: "💾",
    color: "from-green-500/20 to-black/40",
  },
  {
    name: "ASTRAL DRIFT",
    style: "Cosmic dust particle dissolution",
    icon: "✨",
    color: "from-yellow-500/20 to-purple-500/20",
  },
  {
    name: "CIRCUIT BREAK",
    style: "Broken circuitry spark patterns",
    icon: "⚡",
    color: "from-yellow-400/20 to-orange-500/20",
  },
  { name: "MIRROR CRACK", style: "Fractured reflection shards", icon: "🪞", color: "from-zinc-400/20 to-cyan-400/20" },
  {
    name: "ENTROPY WAVE",
    style: "Dissolving into chaos particles",
    icon: "🌊",
    color: "from-purple-600/20 to-red-600/20",
  },
  {
    name: "NEON BURN",
    style: "Overexposed neon outline flicker",
    icon: "💡",
    color: "from-pink-500/30 to-cyan-500/30",
  },
  {
    name: "HOLLOW SHELL",
    style: "Empty vessel with core extracted",
    icon: "🎭",
    color: "from-zinc-800/40 to-zinc-600/20",
  },
  {
    name: "PLASMA LEAK",
    style: "Energy bleeding from artifact edges",
    icon: "🔥",
    color: "from-orange-500/30 to-red-500/20",
  },
  { name: "DIMENSION RIP", style: "Portal tear revealing void", icon: "🕳️", color: "from-black/60 to-purple-900/40" },
  { name: "CODEC ERROR", style: "Compression artifact banding", icon: "📼", color: "from-green-700/20 to-cyan-700/20" },
  {
    name: "AKASHIC FADE",
    style: "Dissolving into cosmic memory",
    icon: "📖",
    color: "from-amber-500/20 to-yellow-500/20",
  },
  {
    name: "RESONANCE COLLAPSE",
    style: "Imploding frequency visualization",
    icon: "💫",
    color: "from-red-500/30 to-cyan-500/30",
  },
  {
    name: "NETERU VOIDFORM",
    style: "Ancient deity silhouette emergence",
    icon: "𓂀",
    color: "from-amber-600/20 to-red-600/20",
  },

  {
    name: "CHRONO SHATTER",
    style: "Time crystals fragmenting into past/future shards",
    icon: "⏳",
    color: "from-blue-400/30 to-purple-600/20",
  },
  {
    name: "MARZIAN DUST",
    style: "Red planet sandstorm engulfing form",
    icon: "🔴",
    color: "from-red-700/30 to-orange-500/20",
  },
  {
    name: "CYBER SERPENT",
    style: "Digital snake coiling through artifact code",
    icon: "🐍",
    color: "from-green-400/30 to-cyan-400/20",
  },
  {
    name: "HOLOGRAM TEAR",
    style: "3D projection flickering with missing polygons",
    icon: "💠",
    color: "from-cyan-300/30 to-blue-500/20",
  },
  {
    name: "OBSIDIAN PULSE",
    style: "Black glass heartbeat emanating dark waves",
    icon: "🖤",
    color: "from-zinc-900/50 to-purple-900/30",
  },
  {
    name: "AURORA BLEED",
    style: "Northern lights leaking from artifact cracks",
    icon: "🌌",
    color: "from-green-400/20 to-pink-400/20",
  },
  {
    name: "CODEC PHANTOM",
    style: "Legacy format ghost data surfacing",
    icon: "📀",
    color: "from-purple-400/20 to-zinc-500/20",
  },
  {
    name: "TRON LEGACY",
    style: "Light cycle trails circling artifact",
    icon: "🏍️",
    color: "from-cyan-500/40 to-orange-500/20",
  },
  {
    name: "MATRIX RAIN",
    style: "Green code cascading over form",
    icon: "💚",
    color: "from-green-500/30 to-green-900/20",
  },
  {
    name: "SOLAR FLARE",
    style: "Coronal mass ejection burning edges",
    icon: "☀️",
    color: "from-yellow-500/40 to-orange-600/30",
  },
  {
    name: "CRYO FREEZE",
    style: "Ice crystal formation overtaking surface",
    icon: "❄️",
    color: "from-cyan-200/30 to-blue-400/20",
  },
  {
    name: "LAVA CORE",
    style: "Molten energy erupting from center",
    icon: "🌋",
    color: "from-red-600/40 to-yellow-500/30",
  },
  {
    name: "SPIRIT CHAIN",
    style: "Ethereal links binding artifact to void",
    icon: "⛓️",
    color: "from-purple-500/30 to-zinc-600/20",
  },
  {
    name: "BYTE STORM",
    style: "Data tornado swirling around form",
    icon: "🌪️",
    color: "from-cyan-400/30 to-purple-400/20",
  },
  {
    name: "SCARAB CURSE",
    style: "Ancient beetle glyphs crawling across surface",
    icon: "🪲",
    color: "from-amber-600/30 to-green-600/20",
  },
  {
    name: "PHOENIX ASH",
    style: "Rising from digital flames reborn",
    icon: "🦅",
    color: "from-orange-500/40 to-red-600/30",
  },
  {
    name: "ZERO DAY",
    style: "Exploit vulnerability tearing through code",
    icon: "🔓",
    color: "from-red-500/40 to-black/40",
  },
  {
    name: "WIRED CHAOS",
    style: "Tangled cable nightmare ensnaring form",
    icon: "🔌",
    color: "from-red-500/30 to-cyan-500/30",
  },
  {
    name: "DOPPLER SHIFT",
    style: "Red/blue color separation as form moves",
    icon: "🎭",
    color: "from-red-400/30 to-blue-400/30",
  },
  {
    name: "SPHINX RIDDLE",
    style: "Hieroglyphic encryption masking form",
    icon: "🦁",
    color: "from-amber-500/30 to-purple-600/20",
  },
  {
    name: "DARK MATTER",
    style: "Invisible mass warping space around artifact",
    icon: "⚫",
    color: "from-zinc-900/60 to-purple-900/40",
  },
  {
    name: "PULSE NOVA",
    style: "Explosive shockwave emanating outward",
    icon: "💥",
    color: "from-white/30 to-cyan-400/20",
  },
  {
    name: "GHOST PROTOCOL",
    style: "Stealth mode cloaking failing mid-cycle",
    icon: "🥷",
    color: "from-zinc-700/40 to-cyan-600/20",
  },
  {
    name: "ANUBIS GATE",
    style: "Underworld portal opening beneath artifact",
    icon: "𓃢",
    color: "from-purple-700/40 to-black/50",
  },
  {
    name: "SYNTHWAVE ECHO",
    style: "Retro 80s grid distortion waves",
    icon: "🎹",
    color: "from-pink-500/30 to-purple-500/30",
  },
]

export function Dynamic404({ artifact404Count, onRecoveryAttempt }: Dynamic404Props) {
  const [currentFormIndex, setCurrentFormIndex] = useState(0)
  const [isTransitioning, setIsTransitioning] = useState(false)

  useEffect(() => {
    if (artifact404Count > 0) {
      const interval = setInterval(() => {
        setIsTransitioning(true)
        setTimeout(() => {
          setCurrentFormIndex((prev) => (prev + 1) % DYNAMIC_404_ART_FORMS.length)
          setIsTransitioning(false)
        }, 300)
      }, 3000)
      return () => clearInterval(interval)
    }
  }, [artifact404Count])

  const currentForm = DYNAMIC_404_ART_FORMS[currentFormIndex]

  const shuffleForm = () => {
    setIsTransitioning(true)
    setTimeout(() => {
      setCurrentFormIndex(Math.floor(Math.random() * DYNAMIC_404_ART_FORMS.length))
      setIsTransitioning(false)
    }, 300)
  }

  return (
    <div
      className={cn(
        "rounded-lg border p-6 transition-all duration-500",
        artifact404Count > 0
          ? "border-cyan-500 bg-gradient-to-br " + currentForm.color
          : "border-zinc-700 bg-zinc-900/50",
      )}
      style={{
        boxShadow:
          artifact404Count > 0 ? "0 0 20px rgba(0, 255, 247, 0.3), inset 0 0 30px rgba(0, 255, 247, 0.1)" : "none",
      }}
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div
            className={cn(
              "h-12 w-12 rounded flex items-center justify-center transition-all duration-300",
              artifact404Count > 0 ? "bg-cyan-500/20 animate-pulse" : "bg-zinc-800",
              isTransitioning && "scale-110",
            )}
            style={{
              boxShadow: artifact404Count > 0 ? "0 0 15px rgba(0, 255, 247, 0.5)" : "none",
            }}
          >
            {artifact404Count > 0 ? (
              <span className="text-2xl">{currentForm.icon}</span>
            ) : (
              <AlertOctagon className="h-6 w-6 text-zinc-500" />
            )}
          </div>
          <div>
            <h3
              className="font-mono text-sm font-bold text-white"
              style={{ textShadow: "0 0 10px #00FFF7, 0 0 20px #00FFF7" }}
            >
              404 DYNAMIC STATE
            </h3>
            <p className="text-xs text-cyan-300" style={{ textShadow: "0 0 8px #00FFF7" }}>
              Timeline distortion artifacts
            </p>
          </div>
        </div>
        {artifact404Count > 0 && (
          <Button
            size="icon"
            variant="ghost"
            onClick={shuffleForm}
            className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/20"
            style={{ textShadow: "0 0 10px #00FFF7" }}
          >
            <Shuffle className="h-5 w-5" />
          </Button>
        )}
      </div>

      {/* Current 404 Art Form Display */}
      {artifact404Count > 0 && (
        <div
          className={cn(
            "mb-6 p-4 rounded border border-cyan-500/50 bg-black/60 transition-all duration-300",
            isTransitioning && "opacity-50 scale-95",
          )}
          style={{
            boxShadow: "0 0 15px rgba(0, 255, 247, 0.2), inset 0 0 20px rgba(0, 0, 0, 0.5)",
          }}
        >
          <div className="flex items-center justify-between mb-2">
            <span
              className="font-mono text-[10px] text-cyan-400 tracking-widest"
              style={{ textShadow: "0 0 8px #00FFF7" }}
            >
              CURRENT DISTORTION FORM
            </span>
            <span className="font-mono text-[10px] text-white" style={{ textShadow: "0 0 8px #FFFFFF" }}>
              {currentFormIndex + 1}/{DYNAMIC_404_ART_FORMS.length}
            </span>
          </div>
          <p
            className="font-mono text-xl font-bold text-white mb-1"
            style={{ textShadow: "0 0 15px #FF1A1A, 0 0 30px #FF1A1A" }}
          >
            {currentForm.name}
          </p>
          <p className="text-sm text-zinc-200" style={{ textShadow: "0 0 5px rgba(255,255,255,0.5)" }}>
            {currentForm.style}
          </p>
        </div>
      )}

      {/* 404 Counter */}
      <div className="text-center py-6 border-y border-cyan-500/30 mb-6">
        <p
          className="text-[10px] font-mono text-cyan-300 mb-2 tracking-widest"
          style={{ textShadow: "0 0 8px #00FFF7" }}
        >
          ARTIFACTS IN DISTORTION
        </p>
        <p
          className={cn(
            "font-mono text-6xl font-bold transition-all duration-300",
            artifact404Count > 0 ? "text-cyan-400" : "text-zinc-600",
            isTransitioning && "scale-110",
          )}
          style={{
            textShadow: artifact404Count > 0 ? "0 0 20px #00FFF7, 0 0 40px #00FFF7, 0 0 60px #00FFF7" : "none",
          }}
        >
          {artifact404Count}
        </p>
      </div>

      {artifact404Count > 0 ? (
        <>
          <p className="text-sm text-zinc-200 text-center mb-4" style={{ textShadow: "0 0 5px rgba(255,255,255,0.3)" }}>
            Your artifacts have entered a timeline distortion state. Form shifting every 3 seconds. Attempt recovery or
            wait for epoch reset.
          </p>
          <div className="grid grid-cols-2 gap-3">
            <Button
              variant="outline"
              onClick={onRecoveryAttempt}
              className="font-mono text-sm bg-transparent border-cyan-500/50 text-cyan-300 hover:bg-cyan-500/20 hover:border-cyan-400"
              style={{ textShadow: "0 0 8px #00FFF7" }}
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              RECOVER
            </Button>
            <Button
              className="bg-cyan-600 hover:bg-cyan-500 text-white font-mono text-sm"
              style={{
                textShadow: "0 0 8px #FFFFFF",
                boxShadow: "0 0 15px rgba(0, 255, 247, 0.5)",
              }}
            >
              <Zap className="h-4 w-4 mr-2" />
              FORCE SYNC
            </Button>
          </div>
        </>
      ) : (
        <p className="text-sm text-zinc-300 text-center" style={{ textShadow: "0 0 5px rgba(255,255,255,0.3)" }}>
          All artifacts are synchronized. No timeline distortions detected.
        </p>
      )}
    </div>
  )
}
