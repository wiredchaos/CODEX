"use client"

import { Dna, Timer, Flame } from "lucide-react"
import { cn } from "@/lib/utils"

interface MutationEpochProps {
  currentEpoch: number
  epochName: string
  timeRemaining: string
  mutationChance: number
  activeArtifacts: number
}

export function MutationEpoch({
  currentEpoch,
  epochName,
  timeRemaining,
  mutationChance,
  activeArtifacts,
}: MutationEpochProps) {
  return (
    <div className="rounded-lg border border-zinc-700 bg-zinc-900/50 p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded bg-red-500/20 flex items-center justify-center">
            <Dna className="h-5 w-5 text-red-500 drop-shadow-[0_0_8px_rgba(239,68,68,0.8)]" />
          </div>
          <div>
            <h3 className="font-mono text-sm font-bold text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]">
              MUTATION EPOCH
            </h3>
            <p className="text-xs text-zinc-200">Weekly evolution cycle</p>
          </div>
        </div>
        <div className="text-right">
          <p className="font-mono text-2xl font-bold text-red-500 drop-shadow-[0_0_12px_rgba(239,68,68,0.9)]">
            #{currentEpoch}
          </p>
          <p className="text-[10px] font-mono text-zinc-200 drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]">{epochName}</p>
        </div>
      </div>

      {/* Timer */}
      <div className="rounded-lg bg-black/50 p-4 mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Timer className="h-4 w-4 text-cyan-400 drop-shadow-[0_0_8px_rgba(34,211,238,0.8)]" />
            <span className="text-xs font-mono text-zinc-200 drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]">
              TIME REMAINING
            </span>
          </div>
          <span className="font-mono text-lg font-bold text-cyan-300 drop-shadow-[0_0_12px_rgba(34,211,238,0.9)]">
            {timeRemaining}
          </span>
        </div>
      </div>

      {/* Mutation Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="rounded-lg border border-zinc-700 p-3">
          <div className="flex items-center gap-2 mb-2">
            <Flame className="h-4 w-4 text-red-500 drop-shadow-[0_0_8px_rgba(239,68,68,0.8)]" />
            <span className="text-[10px] font-mono text-zinc-200 drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]">
              MUTATION CHANCE
            </span>
          </div>
          <div className="flex items-end gap-1">
            <span className="font-mono text-2xl font-bold text-red-500 drop-shadow-[0_0_12px_rgba(239,68,68,0.9)]">
              {mutationChance}
            </span>
            <span className="font-mono text-sm text-zinc-200 mb-1">%</span>
          </div>
          <div className="mt-2 h-1.5 bg-black rounded-full overflow-hidden">
            <div
              className={cn(
                "h-full rounded-full transition-all duration-500",
                mutationChance > 50 ? "bg-red-500" : "bg-cyan-500",
              )}
              style={{ width: `${mutationChance}%` }}
            />
          </div>
        </div>

        <div className="rounded-lg border border-zinc-700 p-3">
          <div className="flex items-center gap-2 mb-2">
            <Dna className="h-4 w-4 text-cyan-400 drop-shadow-[0_0_8px_rgba(34,211,238,0.8)]" />
            <span className="text-[10px] font-mono text-zinc-200 drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]">
              ACTIVE ARTIFACTS
            </span>
          </div>
          <span className="font-mono text-2xl font-bold text-cyan-300 drop-shadow-[0_0_12px_rgba(34,211,238,0.9)]">
            {activeArtifacts}
          </span>
        </div>
      </div>
    </div>
  )
}
