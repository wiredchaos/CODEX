"use client"

import { useEffect, useState } from "react"
import { cn } from "@/lib/utils"

interface TickerItem {
  label: string
  value: string | number
  color: "crimson" | "cyan" | "gold" | "white"
  prefix?: string
}

interface VaultTickerProps {
  items: TickerItem[]
  className?: string
  speed?: number
}

export function VaultTicker({ items, className, speed = 30 }: VaultTickerProps) {
  const [offset, setOffset] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setOffset((prev) => prev - 1)
    }, speed)
    return () => clearInterval(interval)
  }, [speed])

  const colorMap = {
    crimson: "text-red-500",
    cyan: "text-cyan-400",
    gold: "text-amber-400",
    white: "text-white",
  }

  const glowMap = {
    crimson: "drop-shadow-[0_0_10px_rgba(220,38,38,0.8)]",
    cyan: "drop-shadow-[0_0_10px_rgba(6,182,212,0.8)]",
    gold: "drop-shadow-[0_0_10px_rgba(245,158,11,0.8)]",
    white: "drop-shadow-[0_0_10px_rgba(255,255,255,0.8)]",
  }

  // Duplicate items for seamless loop
  const tickerItems = [...items, ...items, ...items]

  return (
    <div className={cn("relative overflow-hidden bg-black/80 border-y border-zinc-800", className)}>
      {/* Gradient masks */}
      <div className="absolute left-0 top-0 bottom-0 w-20 bg-gradient-to-r from-black to-transparent z-10" />
      <div className="absolute right-0 top-0 bottom-0 w-20 bg-gradient-to-l from-black to-transparent z-10" />

      <div
        className="flex items-center gap-8 py-3 whitespace-nowrap"
        style={{
          transform: `translateX(${offset}px)`,
          width: "max-content",
        }}
      >
        {tickerItems.map((item, index) => (
          <div key={index} className="flex items-center gap-2">
            <span className="font-mono text-xs text-zinc-500 tracking-wider">{item.label}</span>
            <span className={cn("font-mono text-sm font-bold", colorMap[item.color], glowMap[item.color])}>
              {item.prefix}
              {item.value}
            </span>
            <span className="text-zinc-700 mx-4">|</span>
          </div>
        ))}
      </div>
    </div>
  )
}
