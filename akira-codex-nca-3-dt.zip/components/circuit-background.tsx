"use client"

import { useEffect, useRef } from "react"

export function CircuitBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let animationId: number
    let time = 0

    const resize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }
    resize()
    window.addEventListener("resize", resize)

    // WIRED CHAOS Brand Colors - FURTHER reduced opacity for dimmer effect
    const CHAOS_RED = "#FF1A1A"
    const NEON_CYAN = "#00FFF7"

    // Create motherboard grid nodes
    const createNodes = () => {
      const nodes: { x: number; y: number; connections: number[]; pulsePhase: number; type: string }[] = []
      const gridSize = 100 // Larger grid = fewer nodes = dimmer overall
      const cols = Math.ceil(canvas.width / gridSize) + 1
      const rows = Math.ceil(canvas.height / gridSize) + 1

      for (let row = 0; row < rows; row++) {
        for (let col = 0; col < cols; col++) {
          const offsetX = (Math.random() - 0.5) * 20
          const offsetY = (Math.random() - 0.5) * 20

          const types = ["processor", "memory", "io", "junction"]
          const type = types[Math.floor(Math.random() * types.length)]

          nodes.push({
            x: col * gridSize + offsetX,
            y: row * gridSize + offsetY,
            connections: [],
            pulsePhase: Math.random() * Math.PI * 2,
            type,
          })
        }
      }

      nodes.forEach((node, i) => {
        nodes.forEach((other, j) => {
          if (i === j) return
          const dx = node.x - other.x
          const dy = node.y - other.y
          const dist = Math.sqrt(dx * dx + dy * dy)
          if (dist < gridSize * 1.5 && Math.random() > 0.5) {
            node.connections.push(j)
          }
        })
      })

      return nodes
    }

    const createPackets = (nodes: { x: number; y: number }[]) => {
      const packets: {
        x: number
        y: number
        targetX: number
        targetY: number
        speed: number
        color: string
        trail: { x: number; y: number }[]
      }[] = []
      const colors = [NEON_CYAN, CHAOS_RED, NEON_CYAN, NEON_CYAN, CHAOS_RED]

      for (let i = 0; i < 15; i++) {
        const startNode = nodes[Math.floor(Math.random() * nodes.length)]
        packets.push({
          x: startNode.x,
          y: startNode.y,
          targetX: startNode.x,
          targetY: startNode.y,
          speed: 1 + Math.random() * 2,
          color: colors[Math.floor(Math.random() * colors.length)],
          trail: [],
        })
      }
      return packets
    }

    let nodes = createNodes()
    let packets = createPackets(nodes)

    let breathPhase = 0

    const animate = () => {
      time += 0.016
      breathPhase += 0.015

      const gradient = ctx.createRadialGradient(
        canvas.width / 2,
        canvas.height / 2,
        0,
        canvas.width / 2,
        canvas.height / 2,
        canvas.width,
      )
      gradient.addColorStop(0, "rgba(5, 5, 7, 0.99)")
      gradient.addColorStop(0.5, "rgba(3, 3, 5, 1)")
      gradient.addColorStop(1, "rgba(0, 0, 0, 1)")
      ctx.fillStyle = gradient
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      const breathIntensity = 0.08 + Math.sin(breathPhase) * 0.04

      // Draw circuit traces with very dim outlines
      nodes.forEach((node, i) => {
        node.connections.forEach((connIdx) => {
          const other = nodes[connIdx]
          if (!other) return

          ctx.beginPath()
          ctx.moveTo(node.x, node.y)

          const midX = node.x + (other.x - node.x) * 0.5
          ctx.lineTo(midX, node.y)
          ctx.lineTo(midX, other.y)
          ctx.lineTo(other.x, other.y)

          const traceGlow = 0.008 + Math.sin(time * 0.5 + i * 0.1) * 0.004
          ctx.strokeStyle = `rgba(0, 255, 247, ${traceGlow * breathIntensity})`
          ctx.lineWidth = 0.5
          ctx.stroke()
        })
      })

      // Draw nodes with much dimmer glow
      nodes.forEach((node) => {
        const pulse = Math.sin(time * 2 + node.pulsePhase) * 0.5 + 0.5
        const nodeGlow = pulse * breathIntensity * 0.2

        ctx.beginPath()

        if (node.type === "processor") {
          const size = 4
          ctx.rect(node.x - size / 2, node.y - size / 2, size, size)
          ctx.fillStyle = `rgba(255, 26, 26, ${0.04 + nodeGlow * 0.06})`
          ctx.fill()
          ctx.strokeStyle = `rgba(255, 26, 26, ${0.06 + nodeGlow * 0.06})`
          ctx.lineWidth = 0.3
          ctx.stroke()
        } else if (node.type === "memory") {
          ctx.rect(node.x - 2.5, node.y - 1, 5, 2)
          ctx.fillStyle = `rgba(0, 255, 247, ${0.03 + nodeGlow * 0.04})`
          ctx.fill()
        } else if (node.type === "io") {
          ctx.arc(node.x, node.y, 1.5, 0, Math.PI * 2)
          ctx.fillStyle = `rgba(160, 32, 240, ${0.04 + nodeGlow * 0.05})`
          ctx.fill()
        } else {
          ctx.arc(node.x, node.y, 1, 0, Math.PI * 2)
          ctx.fillStyle = `rgba(0, 255, 247, ${0.02 + nodeGlow * 0.03})`
          ctx.fill()
        }
      })

      // Draw data packets with dimmer trails
      packets.forEach((packet) => {
        const dx = packet.targetX - packet.x
        const dy = packet.targetY - packet.y
        const dist = Math.sqrt(dx * dx + dy * dy)

        if (dist < 5) {
          const currentNode = nodes.find((n) => Math.abs(n.x - packet.x) < 10 && Math.abs(n.y - packet.y) < 10)
          if (currentNode && currentNode.connections.length > 0) {
            const nextIdx = currentNode.connections[Math.floor(Math.random() * currentNode.connections.length)]
            const nextNode = nodes[nextIdx]
            if (nextNode) {
              packet.targetX = nextNode.x
              packet.targetY = nextNode.y
            }
          } else {
            const randomNode = nodes[Math.floor(Math.random() * nodes.length)]
            packet.targetX = randomNode.x
            packet.targetY = randomNode.y
          }
        }

        const angle = Math.atan2(dy, dx)
        packet.x += Math.cos(angle) * packet.speed
        packet.y += Math.sin(angle) * packet.speed

        packet.trail.push({ x: packet.x, y: packet.y })
        if (packet.trail.length > 12) {
          packet.trail.shift()
        }

        if (packet.trail.length > 1) {
          ctx.beginPath()
          ctx.moveTo(packet.trail[0].x, packet.trail[0].y)
          packet.trail.forEach((point) => {
            ctx.lineTo(point.x, point.y)
          })

          const trailGradient = ctx.createLinearGradient(packet.trail[0].x, packet.trail[0].y, packet.x, packet.y)
          trailGradient.addColorStop(0, "transparent")
          const dimColor = packet.color === NEON_CYAN ? "rgba(0, 255, 247, 0.25)" : "rgba(255, 26, 26, 0.25)"
          trailGradient.addColorStop(1, dimColor)

          ctx.strokeStyle = trailGradient
          ctx.lineWidth = 1
          ctx.lineCap = "round"
          ctx.stroke()
        }

        ctx.beginPath()
        ctx.arc(packet.x, packet.y, 2, 0, Math.PI * 2)
        const packetColor = packet.color === NEON_CYAN ? "rgba(0, 255, 247, 0.4)" : "rgba(255, 26, 26, 0.4)"
        ctx.fillStyle = packetColor
        ctx.shadowColor = packet.color
        ctx.shadowBlur = 3
        ctx.fill()
        ctx.shadowBlur = 0
      })

      const scanY = (time * 40) % canvas.height
      ctx.beginPath()
      ctx.moveTo(0, scanY)
      ctx.lineTo(canvas.width, scanY)
      const scanGradient = ctx.createLinearGradient(0, scanY - 2, 0, scanY + 2)
      scanGradient.addColorStop(0, "transparent")
      scanGradient.addColorStop(0.5, `rgba(0, 255, 247, ${0.01 * breathIntensity})`)
      scanGradient.addColorStop(1, "transparent")
      ctx.strokeStyle = scanGradient
      ctx.lineWidth = 1
      ctx.stroke()

      const glassGradient = ctx.createLinearGradient(0, 0, 0, canvas.height)
      glassGradient.addColorStop(0, "rgba(0, 0, 0, 0.7)")
      glassGradient.addColorStop(0.2, "rgba(0, 0, 0, 0.6)")
      glassGradient.addColorStop(0.5, "rgba(0, 0, 0, 0.55)")
      glassGradient.addColorStop(0.8, "rgba(0, 0, 0, 0.6)")
      glassGradient.addColorStop(1, "rgba(0, 0, 0, 0.75)")
      ctx.fillStyle = glassGradient
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      const vignetteGradient = ctx.createRadialGradient(
        canvas.width / 2,
        canvas.height / 2,
        canvas.height * 0.2,
        canvas.width / 2,
        canvas.height / 2,
        canvas.width * 0.7,
      )
      vignetteGradient.addColorStop(0, "transparent")
      vignetteGradient.addColorStop(0.6, "rgba(0, 0, 0, 0.4)")
      vignetteGradient.addColorStop(1, "rgba(0, 0, 0, 0.85)")
      ctx.fillStyle = vignetteGradient
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      animationId = requestAnimationFrame(animate)
    }

    animate()

    const handleResize = () => {
      resize()
      nodes = createNodes()
      packets = createPackets(nodes)
    }

    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", resize)
      window.removeEventListener("resize", handleResize)
      cancelAnimationFrame(animationId)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-0"
      style={{ opacity: 0.45 }}
      aria-hidden="true"
      role="presentation"
    />
  )
}
