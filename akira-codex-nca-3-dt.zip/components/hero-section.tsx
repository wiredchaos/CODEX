"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { GlitchText } from "@/components/glitch-text"
import { ArrowRight, Radio } from "lucide-react"

export function HeroSection() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center pt-16">
      {/* Scan line effect */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute w-full h-px bg-primary/20 animate-scan-line" />
      </div>

      <div className="container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto text-center">
          {/* Frequency indicator */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-red-500/50 bg-red-500/10 mb-8">
            <Radio className="h-4 w-4 text-red-500 animate-pulse" />
            <span
              className="font-mono text-xs tracking-widest text-red-500 font-bold"
              style={{
                textShadow: "0 0 10px rgba(220,38,38,0.8), 0 0 20px rgba(220,38,38,0.5)",
              }}
            >
              33.3 FM SPECTRUM ACTIVE
            </span>
          </div>

          {/* Main title - Enhanced glow */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 tracking-tight">
            <GlitchText
              text="NEURO CODE"
              as="span"
              className="block text-5xl md:text-7xl lg:text-8xl"
              glow={true}
              glowColor="white"
            />
            <GlitchText
              text="APINAYA FREQUENCY"
              as="span"
              className="block mt-2 text-3xl md:text-5xl lg:text-6xl"
              glow={true}
              glowColor="crimson"
            />
          </h1>

          {/* Subtitle - Brighter text */}
          <p className="text-lg md:text-xl text-zinc-300 max-w-2xl mx-auto mb-8 leading-relaxed">
            Enter the myth-tech odyssey. The motherboard routes to you. The architecture aligns with you. The Neural
            Guide answers to you alone.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/terminal">
              <Button
                size="lg"
                className="bg-red-600 text-white font-mono tracking-wider hover:bg-red-700 group shadow-[0_0_20px_rgba(220,38,38,0.5)]"
              >
                ARTIFACT TERMINAL
                <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
            <Link href="/vault">
              <Button
                size="lg"
                variant="outline"
                className="border-cyan-500 text-cyan-400 hover:bg-cyan-500/20 font-mono tracking-wider bg-transparent shadow-[0_0_20px_rgba(6,182,212,0.3)]"
              >
                NTRU VAULT
              </Button>
            </Link>
          </div>

          {/* Stats bar - Glowing stats */}
          <div className="mt-16 grid grid-cols-3 gap-8 max-w-lg mx-auto">
            <div className="text-center">
              <div
                className="font-mono text-2xl md:text-3xl font-bold text-red-500"
                style={{ textShadow: "0 0 20px rgba(220,38,38,0.8)" }}
              >
                789
              </div>
              <div className="font-mono text-xs text-zinc-400 tracking-wider">STUDIOS</div>
            </div>
            <div className="text-center">
              <div
                className="font-mono text-2xl md:text-3xl font-bold text-cyan-400"
                style={{ textShadow: "0 0 20px rgba(6,182,212,0.8)" }}
              >
                33.3
              </div>
              <div className="font-mono text-xs text-zinc-400 tracking-wider">FREQUENCY</div>
            </div>
            <div className="text-center">
              <div
                className="font-mono text-2xl md:text-3xl font-bold text-amber-400"
                style={{ textShadow: "0 0 20px rgba(245,158,11,0.8)" }}
              >
                FILM3
              </div>
              <div className="font-mono text-xs text-zinc-400 tracking-wider">PROTOCOL</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
