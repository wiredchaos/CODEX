"use client"

import { useState, useEffect } from "react"
import {
  CURRENT_PATCH,
  FLOOR_METADATA,
  getTimelinePosition,
  getPatchRole,
  isGovernedByAkiraCodex,
  PATCH_DECLARATION,
} from "@/lib/trinity-mount"
import { Shield, Lock, Eye, Cpu } from "lucide-react"

export function TrinityStatus() {
  const [mounted, setMounted] = useState(false)
  const [timeline, setTimeline] = useState(getTimelinePosition())

  useEffect(() => {
    setMounted(true)
    const interval = setInterval(() => {
      setTimeline(getTimelinePosition())
    }, 1000)
    return () => clearInterval(interval)
  }, [])

  if (!mounted) return null

  const currentFloor = FLOOR_METADATA[CURRENT_PATCH.floorId]

  return (
    <div
      className="fixed bottom-4 left-4 z-40 p-3 rounded-lg border border-white/10 bg-black/60 backdrop-blur-md max-w-xs"
      role="status"
      aria-label="Trinity mount status"
    >
      <div className="flex items-center gap-2 mb-2">
        <Cpu className="w-4 h-4 text-[#00FFF7]" aria-hidden="true" />
        <span className="text-xs font-mono text-[#00FFF7] uppercase tracking-wider">Trinity Mount</span>
        <span className="ml-auto px-1.5 py-0.5 text-[10px] font-mono bg-[#00FFF7]/20 text-[#00FFF7] rounded">
          {getPatchRole()}
        </span>
      </div>

      <div className="space-y-1.5 text-[10px] font-mono text-white/70">
        <div className="flex items-center gap-2">
          <Eye className="w-3 h-3" aria-hidden="true" />
          <span>Floor:</span>
          <span style={{ color: currentFloor.color }}>{currentFloor.name}</span>
        </div>

        <div className="flex items-center gap-2">
          <Lock className="w-3 h-3" aria-hidden="true" />
          <span>Access:</span>
          <span className="text-white/50">{CURRENT_PATCH.accessLevel}</span>
        </div>

        <div className="flex items-center gap-2">
          <Shield className="w-3 h-3" aria-hidden="true" />
          <span>Governed:</span>
          <span className="text-[#fbbf24]">{isGovernedByAkiraCodex() ? "AKIRA CODEX" : "NONE"}</span>
        </div>

        <div className="pt-1 border-t border-white/10 text-[9px] text-white/40">
          {PATCH_DECLARATION.name} v{PATCH_DECLARATION.version}
        </div>
      </div>
    </div>
  )
}
