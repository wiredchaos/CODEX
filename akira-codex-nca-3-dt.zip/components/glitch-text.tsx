"use client"

import { useEffect, useState } from "react"
import { cn } from "@/lib/utils"

interface GlitchTextProps {
  text: string
  className?: string
  as?: "h1" | "h2" | "h3" | "p" | "span"
  glow?: boolean
  glowColor?: "crimson" | "cyan" | "gold" | "white"
}

export function GlitchText({
  text,
  className,
  as: Component = "span",
  glow = true,
  glowColor = "crimson",
}: GlitchTextProps) {
  const [glitchText, setGlitchText] = useState(text)

  useEffect(() => {
    const chars = "!@#$%^&*()_+-=[]{}|;:,.<>?"
    let interval: NodeJS.Timeout

    const glitch = () => {
      const glitched = text
        .split("")
        .map((char, i) => {
          if (Math.random() > 0.95) {
            return chars[Math.floor(Math.random() * chars.length)]
          }
          return char
        })
        .join("")
      setGlitchText(glitched)
      setTimeout(() => setGlitchText(text), 100)
    }

    interval = setInterval(glitch, 3000)
    return () => clearInterval(interval)
  }, [text])

  const glowStyles = {
    crimson: {
      color: "#ff3333",
      textShadow: `
        0 0 5px #ff3333,
        0 0 10px #ff3333,
        0 0 20px #ff3333,
        0 0 40px #dc2626,
        0 0 80px #dc2626,
        2px 0 #dc2626,
        -2px 0 #06b6d4
      `,
    },
    cyan: {
      color: "#22d3ee",
      textShadow: `
        0 0 5px #22d3ee,
        0 0 10px #22d3ee,
        0 0 20px #22d3ee,
        0 0 40px #06b6d4,
        0 0 80px #06b6d4,
        2px 0 #06b6d4,
        -2px 0 #dc2626
      `,
    },
    gold: {
      color: "#fbbf24",
      textShadow: `
        0 0 5px #fbbf24,
        0 0 10px #fbbf24,
        0 0 20px #fbbf24,
        0 0 40px #f59e0b,
        0 0 80px #f59e0b
      `,
    },
    white: {
      color: "#ffffff",
      textShadow: `
        0 0 5px #ffffff,
        0 0 10px #ffffff,
        0 0 20px #ffffff,
        0 0 40px #e5e5e5,
        2px 0 #dc2626,
        -2px 0 #06b6d4
      `,
    },
  }

  return (
    <Component
      className={cn("relative inline-block font-bold", className)}
      style={
        glow
          ? glowStyles[glowColor]
          : {
              textShadow: "2px 0 #dc2626, -2px 0 #06b6d4",
            }
      }
    >
      {glitchText}
    </Component>
  )
}
