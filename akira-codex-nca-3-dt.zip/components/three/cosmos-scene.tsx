"use client"

import { useRef, useMemo } from "react"
import { Canvas, useFrame, useThree } from "@react-three/fiber"
import { Points, PointMaterial } from "@react-three/drei"
import * as THREE from "three"

// Particle sphere component
function ParticleSphere({ count = 5000 }: { count?: number }) {
  const ref = useRef<THREE.Points>(null)

  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3)
    for (let i = 0; i < count; i++) {
      const radius = 4 + Math.random() * 2
      const theta = Math.random() * Math.PI * 2
      const phi = Math.acos(2 * Math.random() - 1)

      pos[i * 3] = radius * Math.sin(phi) * Math.cos(theta)
      pos[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta)
      pos[i * 3 + 2] = radius * Math.cos(phi)
    }
    return pos
  }, [count])

  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.y = state.clock.elapsedTime * 0.05
      ref.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.03) * 0.1
    }
  })

  return (
    <Points ref={ref} positions={positions} stride={3}>
      <PointMaterial
        transparent
        color="#00FFF7"
        size={0.02}
        sizeAttenuation
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </Points>
  )
}

// Orbiting ring of particles
function OrbitRing({
  radius,
  speed,
  color,
  particleCount = 200,
}: {
  radius: number
  speed: number
  color: string
  particleCount?: number
}) {
  const ref = useRef<THREE.Points>(null)

  const positions = useMemo(() => {
    const pos = new Float32Array(particleCount * 3)
    for (let i = 0; i < particleCount; i++) {
      const angle = (i / particleCount) * Math.PI * 2
      pos[i * 3] = Math.cos(angle) * radius + (Math.random() - 0.5) * 0.3
      pos[i * 3 + 1] = (Math.random() - 0.5) * 0.2
      pos[i * 3 + 2] = Math.sin(angle) * radius + (Math.random() - 0.5) * 0.3
    }
    return pos
  }, [radius, particleCount])

  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.y = state.clock.elapsedTime * speed
    }
  })

  return (
    <Points ref={ref} positions={positions} stride={3}>
      <PointMaterial
        transparent
        color={color}
        size={0.03}
        sizeAttenuation
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </Points>
  )
}

// Floating data nodes
function DataNode({ position, delay }: { position: [number, number, number]; delay: number }) {
  const ref = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    if (ref.current) {
      ref.current.position.y = position[1] + Math.sin(state.clock.elapsedTime * 2 + delay) * 0.3
      ref.current.rotation.x = state.clock.elapsedTime * 0.5
      ref.current.rotation.z = state.clock.elapsedTime * 0.3
    }
  })

  return (
    <mesh ref={ref} position={position}>
      <octahedronGeometry args={[0.15, 0]} />
      <meshBasicMaterial color="#FF1A1A" wireframe transparent opacity={0.8} />
    </mesh>
  )
}

// Central core
function CentralCore() {
  const ref = useRef<THREE.Group>(null)
  const innerRef = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.y = state.clock.elapsedTime * 0.2
    }
    if (innerRef.current) {
      innerRef.current.scale.setScalar(1 + Math.sin(state.clock.elapsedTime * 2) * 0.1)
    }
  })

  return (
    <group ref={ref}>
      {/* Inner glowing core */}
      <mesh ref={innerRef}>
        <icosahedronGeometry args={[0.8, 1]} />
        <meshBasicMaterial color="#FF1A1A" wireframe transparent opacity={0.6} />
      </mesh>
      {/* Outer shell */}
      <mesh>
        <icosahedronGeometry args={[1.2, 1]} />
        <meshBasicMaterial color="#00FFF7" wireframe transparent opacity={0.3} />
      </mesh>
    </group>
  )
}

// Traveling data packets along orbit paths
function DataPacket({ radius, speed, color }: { radius: number; speed: number; color: string }) {
  const ref = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    if (ref.current) {
      const angle = state.clock.elapsedTime * speed
      ref.current.position.x = Math.cos(angle) * radius
      ref.current.position.z = Math.sin(angle) * radius
    }
  })

  return (
    <mesh ref={ref}>
      <sphereGeometry args={[0.08, 8, 8]} />
      <meshBasicMaterial color={color} />
    </mesh>
  )
}

// Star field background
function StarField({ count = 2000 }: { count?: number }) {
  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3)
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 100
      pos[i * 3 + 1] = (Math.random() - 0.5) * 100
      pos[i * 3 + 2] = (Math.random() - 0.5) * 100
    }
    return pos
  }, [count])

  return (
    <Points positions={positions} stride={3}>
      <PointMaterial transparent color="#FFFFFF" size={0.05} sizeAttenuation depthWrite={false} />
    </Points>
  )
}

// Camera animation
function CameraRig() {
  const { camera } = useThree()

  useFrame((state) => {
    camera.position.x = Math.sin(state.clock.elapsedTime * 0.1) * 2
    camera.position.y = Math.cos(state.clock.elapsedTime * 0.08) * 1 + 2
    camera.lookAt(0, 0, 0)
  })

  return null
}

// Main scene
function Scene() {
  const dataNodes = useMemo(() => {
    const nodes = []
    for (let i = 0; i < 8; i++) {
      const angle = (i / 8) * Math.PI * 2
      const radius = 3 + Math.random() * 2
      nodes.push({
        position: [Math.cos(angle) * radius, (Math.random() - 0.5) * 2, Math.sin(angle) * radius] as [
          number,
          number,
          number,
        ],
        delay: i * 0.5,
      })
    }
    return nodes
  }, [])

  return (
    <>
      <color attach="background" args={["#0D0D0D"]} />
      <fog attach="fog" args={["#0D0D0D", 10, 50]} />

      <CameraRig />
      <StarField />

      {/* Central core */}
      <CentralCore />

      {/* Main particle sphere */}
      <ParticleSphere count={6000} />

      {/* Orbit rings */}
      <OrbitRing radius={2.5} speed={0.3} color="#00FFF7" particleCount={150} />
      <OrbitRing radius={3.5} speed={-0.2} color="#FF1A1A" particleCount={200} />
      <OrbitRing radius={5} speed={0.15} color="#A020F0" particleCount={250} />

      {/* Data packets traveling along orbits */}
      <DataPacket radius={2.5} speed={1.5} color="#00FFF7" />
      <DataPacket radius={2.5} speed={1.5} color="#00FFF7" />
      <DataPacket radius={3.5} speed={-1.2} color="#FF1A1A" />
      <DataPacket radius={3.5} speed={-1.2} color="#FF1A1A" />
      <DataPacket radius={5} speed={0.8} color="#A020F0" />

      {/* Floating data nodes */}
      {dataNodes.map((node, i) => (
        <DataNode key={i} position={node.position} delay={node.delay} />
      ))}

      <ambientLight intensity={0.2} />
      <pointLight position={[0, 0, 0]} intensity={2} color="#00FFF7" />
    </>
  )
}

export function CosmosScene() {
  return (
    <div className="absolute inset-0">
      <Canvas camera={{ position: [0, 3, 10], fov: 60 }}>
        <Scene />
      </Canvas>
    </div>
  )
}
