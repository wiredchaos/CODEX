"use client"

import { useRef, useState } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { Image, Environment, Float, Text, Html } from "@react-three/drei"
import * as THREE from "three"
import { useRouter } from "next/navigation"

interface VideoFrameProps {
  position: [number, number, number]
  rotation?: [number, number, number]
  url: string
  title: string
  link?: string
}

function VideoFrame({ position, rotation = [0, 0, 0], url, title, link }: VideoFrameProps) {
  const meshRef = useRef<THREE.Mesh>(null)
  const groupRef = useRef<THREE.Group>(null)
  const [hovered, setHovered] = useState(false)
  const router = useRouter()

  useFrame((state) => {
    if (meshRef.current && hovered) {
      meshRef.current.scale.lerp(new THREE.Vector3(1.15, 1.15, 1.15), 0.1)
    } else if (meshRef.current) {
      meshRef.current.scale.lerp(new THREE.Vector3(1, 1, 1), 0.1)
    }

    if (groupRef.current) {
      groupRef.current.position.y += Math.sin(state.clock.elapsedTime + position[0]) * 0.0003
    }
  })

  const handleClick = () => {
    if (link) {
      router.push(link)
    }
  }

  return (
    <Float speed={1.5} rotationIntensity={0.2} floatIntensity={0.4}>
      <group ref={groupRef} position={position} rotation={rotation}>
        <mesh
          ref={meshRef}
          onPointerOver={() => setHovered(true)}
          onPointerOut={() => setHovered(false)}
          onClick={handleClick}
        >
          <planeGeometry args={[2.4, 1.6]} />
          <meshStandardMaterial
            color={hovered ? "#1a1a2e" : "#0a0a0f"}
            metalness={0.8}
            roughness={0.2}
            emissive={hovered ? "#FF1A1A" : "#000000"}
            emissiveIntensity={hovered ? 0.3 : 0}
          />
        </mesh>

        <lineSegments>
          <edgesGeometry args={[new THREE.PlaneGeometry(2.5, 1.7)]} />
          <lineBasicMaterial color={hovered ? "#FF1A1A" : "#00FFF7"} linewidth={3} />
        </lineSegments>

        {/* Image with glow */}
        <Image url={url} scale={[2.2, 1.4]} position={[0, 0, 0.01]} transparent opacity={hovered ? 1 : 0.9} />

        {/* Title with enhanced styling */}
        <Text
          position={[0, -1.1, 0]}
          fontSize={0.14}
          color={hovered ? "#FF1A1A" : "#00FFF7"}
          anchorX="center"
          font="/fonts/Geist-Bold.ttf"
          outlineWidth={0.005}
          outlineColor="#000000"
        >
          {title}
        </Text>

        {hovered && link && (
          <Html position={[0, -1.5, 0]} center>
            <div className="text-xs font-mono text-cyan-400 bg-black/90 px-3 py-1 rounded border border-cyan-500/50 whitespace-nowrap">
              CLICK TO EXPLORE
            </div>
          </Html>
        )}

        {/* Dynamic glow on hover */}
        {hovered && <pointLight color="#FF1A1A" intensity={3} distance={4} decay={2} />}
      </group>
    </Float>
  )
}

function VisionBoardGrid() {
  const frames = [
    {
      position: [-3, 2, 0] as [number, number, number],
      title: "NETERU ARTIFACTS",
      url: "/cyberpunk-warrior-nft.jpg",
      link: "/terminal",
    },
    {
      position: [0, 2, 0] as [number, number, number],
      title: "NEURAL CATHEDRAL",
      url: "/neon-samurai-nft.jpg",
      link: "/cathedral",
    },
    {
      position: [3, 2, 0] as [number, number, number],
      title: "AKIRA CODEX",
      url: "/dark-mystic-nft.jpg",
      link: "/",
    },
    {
      position: [-3, -0.5, 0] as [number, number, number],
      title: "GIGA ENGINE",
      url: "/ancient-tech-artifact-nft.jpg",
      link: "/giga-engine",
    },
    {
      position: [0, -0.5, 0] as [number, number, number],
      title: "WIRED CHAOS",
      url: "/neural-network-digital-art-dark-background-with-re.jpg",
      link: "/wired-chaos",
    },
    {
      position: [3, -0.5, 0] as [number, number, number],
      title: "NTRU VAULT",
      url: "/radio-frequency-visualization-cyberpunk-style-crim.jpg",
      link: "/vault",
    },
  ]

  return (
    <>
      {frames.map((frame, i) => (
        <VideoFrame key={i} {...frame} />
      ))}
    </>
  )
}

export function VisionBoard() {
  return (
    <Canvas camera={{ position: [0, 0.5, 6], fov: 50 }} className="w-full h-full">
      <color attach="background" args={["#0a0a0f"]} />

      <ambientLight intensity={0.4} />
      <pointLight position={[0, 5, 5]} intensity={1.5} color="#FF1A1A" decay={2} />
      <pointLight position={[-5, 0, 5]} intensity={0.8} color="#00FFF7" decay={2} />
      <pointLight position={[5, -2, 3]} intensity={0.6} color="#A020F0" decay={2} />

      <VisionBoardGrid />

      <Environment preset="city" />
    </Canvas>
  )
}
