"use client"

import { useRef, useMemo } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { Environment, Float, Text3D, MeshDistortMaterial, Sparkles } from "@react-three/drei"
import type * as THREE from "three"

function Portal({ color = "#dc2626", position = [0, 0, 0] as [number, number, number] }) {
  const ringRef = useRef<THREE.Mesh>(null)
  const innerRef = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    if (ringRef.current) {
      ringRef.current.rotation.z = state.clock.elapsedTime * 0.3
    }
    if (innerRef.current) {
      innerRef.current.rotation.z = -state.clock.elapsedTime * 0.5
    }
  })

  return (
    <group position={position}>
      {/* Outer Ring */}
      <mesh ref={ringRef}>
        <torusGeometry args={[2.5, 0.15, 16, 100]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={2} />
      </mesh>

      {/* Inner Ring */}
      <mesh ref={innerRef}>
        <torusGeometry args={[2, 0.1, 16, 100]} />
        <meshStandardMaterial color="#06b6d4" emissive="#06b6d4" emissiveIntensity={1.5} />
      </mesh>

      {/* Portal Surface */}
      <mesh>
        <circleGeometry args={[1.9, 64]} />
        <MeshDistortMaterial color="#0f0f0f" emissive="#1a1a2e" emissiveIntensity={0.5} distort={0.4} speed={2} />
      </mesh>

      {/* Glow Effect */}
      <pointLight color={color} intensity={3} distance={10} />
      <pointLight color="#06b6d4" intensity={2} distance={8} position={[0, 0, 1]} />
    </group>
  )
}

function FloatingRunes() {
  const groupRef = useRef<THREE.Group>(null)
  const runes = useMemo(
    () =>
      Array.from({ length: 12 }, (_, i) => ({
        angle: (i / 12) * Math.PI * 2,
        radius: 4,
        symbol: ["◈", "◇", "△", "○", "□", "⬡", "⬢", "◉", "◎", "⊕", "⊗", "⊛"][i],
      })),
    [],
  )

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = state.clock.elapsedTime * 0.1
    }
  })

  return (
    <group ref={groupRef}>
      {runes.map((rune, i) => (
        <Float key={i} speed={2} rotationIntensity={0.5} floatIntensity={1}>
          <Text3D
            font="/fonts/Inter_Bold.json"
            size={0.3}
            position={[Math.cos(rune.angle) * rune.radius, Math.sin(rune.angle) * rune.radius, 0]}
          >
            {rune.symbol}
            <meshStandardMaterial color="#fbbf24" emissive="#fbbf24" emissiveIntensity={1} />
          </Text3D>
        </Float>
      ))}
    </group>
  )
}

function CathedralPillars() {
  const positions = [
    [-5, 0, -3],
    [5, 0, -3],
    [-5, 0, 3],
    [5, 0, 3],
  ] as [number, number, number][]

  return (
    <>
      {positions.map((pos, i) => (
        <mesh key={i} position={pos}>
          <cylinderGeometry args={[0.3, 0.4, 8, 8]} />
          <meshStandardMaterial color="#1a1a2e" metalness={0.8} roughness={0.2} />
        </mesh>
      ))}
    </>
  )
}

function ParticleField() {
  return (
    <>
      <Sparkles count={200} scale={15} size={2} speed={0.5} color="#dc2626" />
      <Sparkles count={150} scale={12} size={1.5} speed={0.3} color="#06b6d4" />
      <Sparkles count={100} scale={10} size={1} speed={0.4} color="#fbbf24" />
    </>
  )
}

export function PortalScene() {
  return (
    <Canvas camera={{ position: [0, 0, 8], fov: 60 }} className="w-full h-full">
      <color attach="background" args={["#050508"]} />
      <fog attach="fog" args={["#050508", 5, 25]} />

      <ambientLight intensity={0.1} />
      <directionalLight position={[5, 5, 5]} intensity={0.5} />

      <Portal />
      <FloatingRunes />
      <CathedralPillars />
      <ParticleField />

      <Environment preset="night" />
    </Canvas>
  )
}
