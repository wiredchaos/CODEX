import Link from "next/link"
import { ExternalLink } from "lucide-react"

export function Footer() {
  return (
    <footer className="border-t border-zinc-800 bg-zinc-900/50 py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="relative h-8 w-8">
                <div className="absolute inset-0 rounded bg-red-500" />
                <div className="absolute inset-1 rounded bg-black flex items-center justify-center">
                  <span className="text-red-500 font-mono text-xs font-bold drop-shadow-[0_0_8px_rgba(239,68,68,0.8)]">
                    AK
                  </span>
                </div>
              </div>
              <span className="font-mono text-sm font-bold tracking-widest text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]">
                AKIRA CODEX
              </span>
            </div>
            <p className="text-sm text-zinc-200 max-w-sm mb-4 drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]">
              NEURO CODE: APINAYA FREQUENCY. A myth-tech odyssey on the 33.3 FM spectrum. Film3 interactive experiences
              powered by the NETERU APINAYA protocol.
            </p>
            <Link
              href="https://opensea.io/BlockchaintrapperETH"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-cyan-400 hover:text-cyan-300 transition-colors font-mono text-xs drop-shadow-[0_0_6px_rgba(34,211,238,0.8)]"
            >
              BlockchaintrapperETH
              <ExternalLink className="h-3 w-3" />
            </Link>
          </div>

          <div>
            <h4 className="font-mono text-xs font-bold tracking-widest mb-4 text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]">
              ECOSYSTEM
            </h4>
            <ul className="space-y-2">
              <li>
                <Link
                  href="/terminal"
                  className="text-sm text-zinc-200 hover:text-red-400 transition-colors drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]"
                >
                  Artifact Terminal
                </Link>
              </li>
              <li>
                <Link
                  href="/vault"
                  className="text-sm text-zinc-200 hover:text-red-400 transition-colors drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]"
                >
                  NTRU Vault
                </Link>
              </li>
              <li>
                <Link
                  href="/echo-engineers"
                  className="text-sm text-zinc-200 hover:text-cyan-400 transition-colors drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]"
                >
                  Echo Engineers
                </Link>
              </li>
              <li>
                <Link
                  href="/portal"
                  className="text-sm text-zinc-200 hover:text-red-400 transition-colors drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]"
                >
                  Age Gate Portal
                </Link>
              </li>
            </ul>
          </div>

          {/* Connect */}
          <div>
            <h4 className="font-mono text-xs font-bold tracking-widest mb-4 text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]">
              CONNECT
            </h4>
            <ul className="space-y-2">
              <li>
                <Link
                  href="https://opensea.io/BlockchaintrapperETH"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-zinc-200 hover:text-cyan-400 transition-colors drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]"
                >
                  OpenSea
                </Link>
              </li>
              <li>
                <Link
                  href="https://x.com/NeteruApinaya"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-zinc-200 hover:text-cyan-400 transition-colors drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]"
                >
                  X / Twitter
                </Link>
              </li>
              <li>
                <Link
                  href="https://instagram.com/queciacobain"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-zinc-200 hover:text-cyan-400 transition-colors drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]"
                >
                  Instagram
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-12 pt-6 border-t border-zinc-800 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="font-mono text-xs text-zinc-300 drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]">
            &copy; {new Date().getFullYear()} AKIRA CODEX / NETERU STUDIOS. All rights reserved.
          </p>
          <p className="font-mono text-xs text-cyan-400 drop-shadow-[0_0_6px_rgba(34,211,238,0.8)]">
            NEURO META X — PRIME NAVIGATOR
          </p>
        </div>
      </div>
    </footer>
  )
}
