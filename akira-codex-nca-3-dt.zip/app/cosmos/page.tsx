"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { CosmosScene } from "@/components/three/cosmos-scene"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronRight, Zap, Shield, Database, Radio } from "lucide-react"

export default function CosmosLanding() {
  const router = useRouter()
  const [bootPhase, setBootPhase] = useState(0)
  const [showContent, setShowContent] = useState(false)
  const [entering, setEntering] = useState(false)

  // Boot sequence
  useEffect(() => {
    const phases = [500, 1000, 1500, 2000, 2500]
    phases.forEach((delay, index) => {
      setTimeout(() => setBootPhase(index + 1), delay)
    })
    setTimeout(() => setShowContent(true), 3000)
  }, [])

  const handleEnterGrid = () => {
    setEntering(true)
    setTimeout(() => router.push("/"), 1500)
  }

  const bootMessages = [
    "INITIALIZING NEURAL INTERFACE...",
    "CONNECTING TO AKIRA CODEX...",
    "SYNCING NETERU FREQUENCY 33.3 FM...",
    "ESTABLISHING QUANTUM BRIDGE...",
    "SYSTEM ONLINE — WELCOME, NAVIGATOR",
  ]

  const features = [
    { icon: Zap, label: "NTRU TOKEN ECONOMY", desc: "Mythic currency system" },
    { icon: Shield, label: "404 DYNAMIC NFTS", desc: "Timeline distortion artifacts" },
    { icon: Database, label: "ARTIFACT TERMINAL", desc: "Multi-chain exchange console" },
    { icon: Radio, label: "33.3 FM SPECTRUM", desc: "Resonance navigation" },
  ]

  return (
    <main className="relative min-h-screen bg-[#0D0D0D] overflow-hidden">
      {/* 3D Cosmos Background */}
      <CosmosScene />

      {/* Glass overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/20 to-black/60 pointer-events-none" />

      {/* Boot sequence overlay */}
      <AnimatePresence>
        {!showContent && (
          <motion.div
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
            className="absolute inset-0 z-50 bg-[#0D0D0D] flex items-center justify-center"
          >
            <div className="font-mono text-sm space-y-2">
              {bootMessages.slice(0, bootPhase).map((msg, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={`flex items-center gap-3 ${i === bootPhase - 1 ? "text-[#00FFF7]" : "text-zinc-500"}`}
                  style={{
                    textShadow: i === bootPhase - 1 ? "0 0 10px #00FFF7" : "none",
                  }}
                >
                  <span className={i < bootPhase - 1 ? "text-green-400" : "text-[#00FFF7]"}>
                    {i < bootPhase - 1 ? "[OK]" : "[>>]"}
                  </span>
                  {msg}
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Enter transition overlay */}
      <AnimatePresence>
        {entering && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0 z-50 bg-[#0D0D0D] flex items-center justify-center"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: [0, 1.5, 0] }}
              transition={{ duration: 1.5 }}
              className="w-32 h-32 rounded-full border-2 border-[#00FFF7]"
              style={{ boxShadow: "0 0 60px #00FFF7, inset 0 0 60px #00FFF7" }}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main content */}
      <AnimatePresence>
        {showContent && !entering && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1 }}
            className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4"
          >
            {/* Title */}
            <motion.div
              initial={{ y: -50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.8 }}
              className="text-center mb-12"
            >
              <h1
                className="text-5xl md:text-7xl font-bold tracking-wider mb-4"
                style={{
                  color: "#FFFFFF",
                  textShadow: "0 0 20px #00FFF7, 0 0 40px #00FFF7, 0 0 60px #00FFF7",
                }}
              >
                AKIRA CODEX
              </h1>
              <p
                className="text-xl md:text-2xl font-mono tracking-widest"
                style={{
                  color: "#FF1A1A",
                  textShadow: "0 0 10px #FF1A1A, 0 0 20px #FF1A1A",
                }}
              >
                NETERU APINAYA FREQUENCY
              </p>
              <p
                className="text-lg font-mono mt-2 tracking-wider"
                style={{
                  color: "#00FFF7",
                  textShadow: "0 0 10px #00FFF7",
                }}
              >
                33.3 FM SPECTRUM
              </p>
            </motion.div>

            {/* Feature cards */}
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.6, duration: 0.8 }}
              className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12 max-w-4xl"
            >
              {features.map((feature, i) => (
                <motion.div
                  key={feature.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.8 + i * 0.1 }}
                  className="bg-black/40 backdrop-blur-sm border border-zinc-800 rounded-lg p-4 text-center hover:border-[#00FFF7] transition-all duration-300 group"
                  style={{
                    boxShadow: "0 0 20px rgba(0, 255, 247, 0.1)",
                  }}
                >
                  <feature.icon
                    className="w-8 h-8 mx-auto mb-2 text-[#00FFF7] group-hover:text-[#FF1A1A] transition-colors"
                    style={{ filter: "drop-shadow(0 0 8px currentColor)" }}
                  />
                  <h3
                    className="text-xs font-bold tracking-wider mb-1"
                    style={{ color: "#FFFFFF", textShadow: "0 0 5px rgba(255,255,255,0.5)" }}
                  >
                    {feature.label}
                  </h3>
                  <p className="text-xs text-zinc-400">{feature.desc}</p>
                </motion.div>
              ))}
            </motion.div>

            {/* Enter button */}
            <motion.button
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 1.2, duration: 0.5 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleEnterGrid}
              className="relative group px-12 py-4 rounded-lg font-bold text-lg tracking-widest overflow-hidden"
              style={{
                background: "linear-gradient(135deg, rgba(255, 26, 26, 0.3), rgba(0, 255, 247, 0.3))",
                border: "2px solid #00FFF7",
                color: "#FFFFFF",
                textShadow: "0 0 10px #FFFFFF",
                boxShadow: "0 0 30px rgba(0, 255, 247, 0.4), inset 0 0 30px rgba(0, 255, 247, 0.1)",
              }}
            >
              <span className="relative z-10 flex items-center gap-3">
                ENTER THE GRID
                <ChevronRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
              </span>
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                style={{
                  background: "linear-gradient(135deg, rgba(0, 255, 247, 0.4), rgba(255, 26, 26, 0.4))",
                }}
              />
            </motion.button>

            {/* Bottom info */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.5 }}
              className="absolute bottom-8 left-0 right-0 text-center"
            >
              <p
                className="text-sm font-mono tracking-wider"
                style={{ color: "#00FFF7", textShadow: "0 0 5px #00FFF7" }}
              >
                WIRED CHAOS META ECOSYSTEM
              </p>
              <p className="text-xs text-zinc-500 mt-1">NEURO META X | BlockchaintrapperETH | NETERU STUDIOS</p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  )
}
