"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ArrowLeft, Wallet, ArrowRightLeft, Settings, Zap, TrendingUp, Clock, Gift } from "lucide-react"
import { Button } from "@/components/ui/button"
import { CircuitBackground } from "@/components/circuit-background"
import { GlitchText } from "@/components/glitch-text"
import { AgenticWelcome } from "@/components/agentic-welcome"
import { RadioPlayer } from "@/components/radio-player"

// Mock transaction data
const mockTransactions = [
  { id: "1", type: "EARN" as const, amount: 50, description: "Daily Login Reward", timestamp: "2 hours ago" },
  { id: "2", type: "SPEND" as const, amount: 100, description: "NTRU Path Exchange", timestamp: "5 hours ago" },
  { id: "3", type: "MUTATION" as const, amount: 25, description: "Mutation Epoch Bonus", timestamp: "1 day ago" },
  { id: "4", type: "EARN" as const, amount: 75, description: "Staking Rewards", timestamp: "1 day ago" },
  { id: "5", type: "EXCHANGE" as const, amount: 200, description: "Artifact Trade", timestamp: "2 days ago" },
  { id: "6", type: "EARN" as const, amount: 150, description: "Weekly Streak Bonus", timestamp: "3 days ago" },
  { id: "7", type: "SPEND" as const, amount: 50, description: "404 Recovery Fee", timestamp: "4 days ago" },
]

const tickerItems = [
  { label: "TOTAL IN VAULT", value: "2,450", color: "cyan" },
  { label: "STAKED", value: "1,800", color: "gold" },
  { label: "PENDING REWARDS", value: "+125", color: "red" },
  { label: "ARTIFACTS", value: "24", color: "white" },
]

export default function VaultPage() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <main className="relative min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-cyan-400 font-mono animate-pulse">LOADING VAULT...</div>
      </main>
    )
  }

  return (
    <main className="relative min-h-screen bg-black text-white">
      <CircuitBackground />

      {/* Liquid glass overlay */}
      <div
        className="fixed inset-0 pointer-events-none z-[1]"
        style={{
          background: "linear-gradient(180deg, rgba(0,0,0,0.4) 0%, rgba(0,0,0,0.2) 50%, rgba(0,0,0,0.5) 100%)",
        }}
        aria-hidden="true"
      />

      <AgenticWelcome pageName="NTRU VAULT" />

      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-zinc-800 bg-black/80 backdrop-blur-md">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-4">
            <Link href="/" aria-label="Back to home">
              <Button variant="ghost" size="icon" className="text-white hover:text-red-500" aria-label="Go back">
                <ArrowLeft className="h-5 w-5" aria-hidden="true" />
              </Button>
            </Link>
            <div>
              <GlitchText
                text="NTRU VAULT"
                as="h1"
                className="font-mono text-lg font-bold tracking-widest"
                glow={true}
                glowColor="cyan"
              />
              <p className="text-[10px] font-mono text-cyan-300" style={{ textShadow: "0 0 8px #00FFF7" }}>
                NETERU TOKEN MANAGEMENT
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Link href="/terminal">
              <Button
                variant="outline"
                size="sm"
                className="font-mono text-xs bg-transparent border-cyan-500/50 text-cyan-300 hover:bg-cyan-500/20 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                style={{ textShadow: "0 0 8px #00FFF7" }}
              >
                <ArrowRightLeft className="h-4 w-4 mr-2" aria-hidden="true" />
                TERMINAL
              </Button>
            </Link>
            <Button variant="ghost" size="icon" className="text-white hover:text-red-500" aria-label="Settings">
              <Settings className="h-4 w-4" aria-hidden="true" />
            </Button>
          </div>
        </div>
      </header>

      {/* Ticker */}
      <div className="border-b border-zinc-800 bg-black/50 py-2 overflow-hidden relative z-10">
        <div className="flex animate-scroll gap-8 whitespace-nowrap">
          {[...tickerItems, ...tickerItems].map((item, i) => (
            <div key={i} className="flex items-center gap-2 px-4">
              <span className="text-[10px] font-mono text-zinc-500">{item.label}</span>
              <span
                className={`font-mono text-sm font-bold ${
                  item.color === "cyan"
                    ? "text-cyan-400"
                    : item.color === "gold"
                      ? "text-amber-400"
                      : item.color === "red"
                        ? "text-red-500"
                        : "text-white"
                }`}
                style={{
                  textShadow:
                    item.color === "cyan"
                      ? "0 0 10px #00FFF7"
                      : item.color === "gold"
                        ? "0 0 10px #F59E0B"
                        : item.color === "red"
                          ? "0 0 10px #FF1A1A"
                          : "none",
                }}
              >
                {item.value}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        {/* Balance Overview */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {/* NTRU Balance Card */}
          <div
            className="rounded-lg border border-cyan-500/30 bg-zinc-900/50 p-6"
            style={{ boxShadow: "0 0 20px rgba(0,255,247,0.15)" }}
            role="region"
            aria-label="NTRU Balance"
          >
            <div className="flex items-center gap-3 mb-4">
              <div
                className="h-12 w-12 rounded bg-cyan-500/20 flex items-center justify-center"
                style={{ boxShadow: "0 0 15px rgba(0,255,247,0.3)" }}
                aria-hidden="true"
              >
                <Zap className="h-6 w-6 text-cyan-400" />
              </div>
              <div>
                <p className="text-[10px] font-mono text-zinc-400">AVAILABLE BALANCE</p>
                <p
                  className="font-mono text-3xl font-bold text-cyan-400"
                  style={{ textShadow: "0 0 15px #00FFF7" }}
                  aria-label="2,450 NTRU available"
                >
                  2,450
                </p>
              </div>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-zinc-400">NTRU</span>
              <span className="text-green-400">+125 pending</span>
            </div>
            <div className="mt-4 pt-4 border-t border-zinc-700">
              <div className="flex items-center justify-between text-xs">
                <span className="text-zinc-500">Next Epoch</span>
                <span className="font-mono text-cyan-400">3d 14h</span>
              </div>
            </div>
          </div>

          {/* Wallet Overview */}
          <div
            className="md:col-span-2 rounded-lg border border-cyan-500/30 bg-zinc-900/50 p-6"
            style={{ boxShadow: "0 0 20px rgba(0,255,247,0.1)" }}
            role="region"
            aria-label="Wallet Overview"
          >
            <div className="flex items-center gap-3 mb-6">
              <div
                className="h-10 w-10 rounded bg-cyan-500/20 flex items-center justify-center"
                style={{ boxShadow: "0 0 15px rgba(0,255,247,0.3)" }}
                aria-hidden="true"
              >
                <Wallet className="h-5 w-5 text-cyan-400" />
              </div>
              <div>
                <h3 className="font-mono text-sm font-bold text-white" style={{ textShadow: "0 0 10px #00FFF7" }}>
                  WALLET OVERVIEW
                </h3>
                <p className="text-xs text-cyan-300">NEURO META X | BlockchaintrapperETH</p>
              </div>
            </div>

            <div className="grid grid-cols-4 gap-4">
              <div className="text-center">
                <p className="text-[10px] font-mono text-zinc-400 mb-1">TOTAL EARNED</p>
                <p className="font-mono text-xl font-bold text-cyan-400" style={{ textShadow: "0 0 15px #00FFF7" }}>
                  12,450
                </p>
              </div>
              <div className="text-center">
                <p className="text-[10px] font-mono text-zinc-400 mb-1">TOTAL SPENT</p>
                <p className="font-mono text-xl font-bold text-red-500" style={{ textShadow: "0 0 15px #FF1A1A" }}>
                  8,200
                </p>
              </div>
              <div className="text-center">
                <p className="text-[10px] font-mono text-zinc-400 mb-1">STAKED</p>
                <p className="font-mono text-xl font-bold text-amber-400" style={{ textShadow: "0 0 15px #F59E0B" }}>
                  1,800
                </p>
              </div>
              <div className="text-center">
                <p className="text-[10px] font-mono text-zinc-400 mb-1">ARTIFACTS</p>
                <p className="font-mono text-xl font-bold text-white" style={{ textShadow: "0 0 10px #FFFFFF" }}>
                  24
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left Column - Transactions */}
          <div className="lg:col-span-2 space-y-6">
            {/* Transaction History */}
            <div
              className="rounded-lg border border-zinc-700 bg-zinc-900/50 p-6"
              style={{ boxShadow: "0 0 15px rgba(0,255,247,0.1)" }}
              role="region"
              aria-label="Transaction History"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <Clock className="h-5 w-5 text-cyan-400" aria-hidden="true" />
                  <h3 className="font-mono text-sm font-bold text-white" style={{ textShadow: "0 0 10px #00FFF7" }}>
                    TRANSACTION HISTORY
                  </h3>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-xs text-cyan-400 hover:text-cyan-300 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                >
                  VIEW ALL
                </Button>
              </div>

              <div className="space-y-3" role="list" aria-label="Recent transactions">
                {mockTransactions.map((tx) => (
                  <div
                    key={tx.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-black/30 border border-zinc-800 hover:border-zinc-700 transition-colors"
                    role="listitem"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`h-8 w-8 rounded flex items-center justify-center ${
                          tx.type === "EARN"
                            ? "bg-green-500/20"
                            : tx.type === "SPEND"
                              ? "bg-red-500/20"
                              : tx.type === "MUTATION"
                                ? "bg-purple-500/20"
                                : "bg-amber-500/20"
                        }`}
                      >
                        {tx.type === "EARN" ? (
                          <TrendingUp className="h-4 w-4 text-green-400" aria-hidden="true" />
                        ) : tx.type === "SPEND" ? (
                          <ArrowRightLeft className="h-4 w-4 text-red-400" aria-hidden="true" />
                        ) : tx.type === "MUTATION" ? (
                          <Zap className="h-4 w-4 text-purple-400" aria-hidden="true" />
                        ) : (
                          <Gift className="h-4 w-4 text-amber-400" aria-hidden="true" />
                        )}
                      </div>
                      <div>
                        <p className="font-mono text-sm text-white">{tx.description}</p>
                        <p className="text-[10px] text-zinc-500">{tx.timestamp}</p>
                      </div>
                    </div>
                    <p
                      className={`font-mono text-sm font-bold ${
                        tx.type === "EARN" || tx.type === "MUTATION" ? "text-green-400" : "text-red-400"
                      }`}
                    >
                      {tx.type === "EARN" || tx.type === "MUTATION" ? "+" : "-"}
                      {tx.amount} NTRU
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column - Staking & Rewards */}
          <div className="space-y-6">
            {/* Staking Panel */}
            <div
              className="rounded-lg border border-amber-500/30 bg-zinc-900/50 p-6"
              style={{ boxShadow: "0 0 15px rgba(245,158,11,0.15)" }}
              role="region"
              aria-label="NTRU Staking"
            >
              <div className="flex items-center gap-3 mb-4">
                <div
                  className="h-10 w-10 rounded bg-amber-500/20 flex items-center justify-center"
                  style={{ boxShadow: "0 0 15px rgba(245,158,11,0.3)" }}
                  aria-hidden="true"
                >
                  <TrendingUp className="h-5 w-5 text-amber-400" />
                </div>
                <div>
                  <h3 className="font-mono text-sm font-bold text-white">NTRU STAKING</h3>
                  <p className="text-[10px] text-amber-400">12% APR</p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-xs text-zinc-400">Currently Staked</span>
                  <span className="font-mono text-lg font-bold text-amber-400">1,800 NTRU</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-zinc-400">Lock Period</span>
                  <span className="font-mono text-sm text-white">7 DAYS</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-zinc-400">Projected Rewards</span>
                  <span className="font-mono text-sm text-green-400">+216 NTRU/year</span>
                </div>
                <Button
                  className="w-full bg-amber-600 hover:bg-amber-500 text-white font-mono focus:outline-none focus:ring-2 focus:ring-amber-400 focus:ring-offset-2 focus:ring-offset-black"
                  aria-label="Stake more NTRU tokens"
                >
                  STAKE MORE
                </Button>
              </div>
            </div>

            {/* Rewards Tracker */}
            <div
              className="rounded-lg border border-green-500/30 bg-zinc-900/50 p-6"
              style={{ boxShadow: "0 0 15px rgba(34,197,94,0.15)" }}
              role="region"
              aria-label="Daily Rewards"
            >
              <div className="flex items-center gap-3 mb-4">
                <div
                  className="h-10 w-10 rounded bg-green-500/20 flex items-center justify-center"
                  style={{ boxShadow: "0 0 15px rgba(34,197,94,0.3)" }}
                  aria-hidden="true"
                >
                  <Gift className="h-5 w-5 text-green-400" />
                </div>
                <div>
                  <h3 className="font-mono text-sm font-bold text-white">DAILY REWARDS</h3>
                  <p className="text-[10px] text-green-400">14 DAY STREAK</p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-xs text-zinc-400">Daily Reward</span>
                  <span className="font-mono text-lg font-bold text-green-400">+50 NTRU</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-zinc-400">Weekly Bonus</span>
                  <span className="font-mono text-sm text-cyan-400">+250 NTRU</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-zinc-400">Next Reward In</span>
                  <span className="font-mono text-sm text-white">6h 32m</span>
                </div>
                <Button
                  className="w-full bg-green-600 hover:bg-green-500 text-white font-mono focus:outline-none focus:ring-2 focus:ring-green-400 focus:ring-offset-2 focus:ring-offset-black"
                  aria-label="Claim your daily reward"
                >
                  CLAIM REWARD
                </Button>
              </div>
            </div>

            {/* 33.3 FM Radio Player */}
            <RadioPlayer
              stationName="33.3 FM DOGECHAIN"
              streamUrl="" // Placeholder - user will provide stream URL
            />
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes scroll {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-scroll {
          animation: scroll 30s linear infinite;
        }
      `}</style>
    </main>
  )
}
