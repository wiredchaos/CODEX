"use client"

import Link from "next/link"
import { CircuitBackground } from "@/components/circuit-background"
import { GlitchText } from "@/components/glitch-text"
import { Button } from "@/components/ui/button"
import { Users, Tv, Film, Gamepad2 } from "lucide-react"

const creators = [
  {
    id: "neuro-meta-x",
    name: "NEURO META X",
    role: "PRIME NAVIGATOR",
    bio: "Architect of the WIRED CHAOS META system. Builder of myth-tech odysseys.",
    works: 12,
    followers: "8.5K",
    avatar: "/placeholder.svg?key=njuk9",
  },
]

export default function EchoEngineersPage() {
  return (
    <main className="relative min-h-screen bg-black text-white">
      <CircuitBackground />

      <div className="container mx-auto px-4 py-16">
        <div className="mb-12 text-center">
          <GlitchText className="mb-4 text-4xl font-bold md:text-6xl">ECHO ENGINEERS</GlitchText>
          <p className="mx-auto max-w-2xl text-lg text-zinc-200 drop-shadow-[0_0_8px_rgba(255,255,255,0.5)]">
            The creators behind the WIRED CHAOS META ecosystem. Architects of narrative, code, and vision.
          </p>
        </div>

        <div className="mb-12 grid gap-4 md:grid-cols-4">
          <div className="rounded-lg border border-cyan-500/50 bg-cyan-500/10 p-6">
            <Users className="h-8 w-8 text-cyan-400 mb-3 drop-shadow-[0_0_12px_rgba(34,211,238,0.8)]" />
            <h3 className="font-mono text-2xl font-bold text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]">
              {creators.length}
            </h3>
            <p className="text-sm text-zinc-200">Active Creators</p>
          </div>
          <div className="rounded-lg border border-red-500/50 bg-red-500/10 p-6">
            <Film className="h-8 w-8 text-red-500 mb-3 drop-shadow-[0_0_12px_rgba(239,68,68,0.8)]" />
            <h3 className="font-mono text-2xl font-bold text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]">42</h3>
            <p className="text-sm text-zinc-200">Total Projects</p>
          </div>
          <div className="rounded-lg border border-amber-500/50 bg-amber-500/10 p-6">
            <Tv className="h-8 w-8 text-amber-400 mb-3 drop-shadow-[0_0_12px_rgba(251,191,36,0.8)]" />
            <h3 className="font-mono text-2xl font-bold text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]">
              156h
            </h3>
            <p className="text-sm text-zinc-200">Content Hours</p>
          </div>
          <div className="rounded-lg border border-purple-500/50 bg-purple-500/10 p-6">
            <Gamepad2 className="h-8 w-8 text-purple-400 mb-3 drop-shadow-[0_0_12px_rgba(168,85,247,0.8)]" />
            <h3 className="font-mono text-2xl font-bold text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]">8</h3>
            <p className="text-sm text-zinc-200">Interactive Experiences</p>
          </div>
        </div>

        <div className="space-y-6">
          {creators.map((creator) => (
            <Link
              key={creator.id}
              href={`/echo-engineers/${creator.id}`}
              className="block rounded-lg border border-zinc-700 bg-zinc-900/50 p-8 transition-all hover:border-cyan-500 hover:shadow-[0_0_20px_rgba(34,211,238,0.3)]"
            >
              <div className="flex items-start gap-6">
                <div className="h-20 w-20 rounded-full bg-gradient-to-br from-cyan-500 to-red-500 p-0.5">
                  <div className="h-full w-full rounded-full bg-black flex items-center justify-center">
                    <span className="font-mono text-2xl font-bold text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]">
                      {creator.name.substring(0, 2)}
                    </span>
                  </div>
                </div>
                <div className="flex-1">
                  <div className="mb-2 flex items-center gap-3">
                    <h3 className="font-mono text-xl font-bold text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]">
                      {creator.name}
                    </h3>
                    <span className="rounded-full border border-cyan-500 bg-cyan-500/20 px-3 py-1 text-xs font-mono text-cyan-300 drop-shadow-[0_0_6px_rgba(34,211,238,0.8)]">
                      {creator.role}
                    </span>
                  </div>
                  <p className="mb-4 text-zinc-200 drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]">{creator.bio}</p>
                  <div className="flex gap-6 text-sm">
                    <div>
                      <span className="font-mono text-cyan-300 drop-shadow-[0_0_6px_rgba(34,211,238,0.8)]">
                        {creator.works}
                      </span>
                      <span className="ml-2 text-zinc-300">Works</span>
                    </div>
                    <div>
                      <span className="font-mono text-cyan-300 drop-shadow-[0_0_6px_rgba(34,211,238,0.8)]">
                        {creator.followers}
                      </span>
                      <span className="ml-2 text-zinc-300">Followers</span>
                    </div>
                  </div>
                </div>
                <Button className="bg-red-600 hover:bg-red-500 text-white font-mono">VIEW PROFILE</Button>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </main>
  )
}
