"use client"

import Link from "next/link"
import { CircuitBackground } from "@/components/circuit-background"
import { GlitchText } from "@/components/glitch-text"
import { Button } from "@/components/ui/button"
import { ArrowLeft, ExternalLink, BookOpen, Film, Tv, Gamepad2 } from "lucide-react"

const creatorData = {
  "neuro-meta-x": {
    name: "NEURO META X",
    role: "PRIME NAVIGATOR",
    bio: "Architect of the WIRED CHAOS META ecosystem. Building myth-tech odysseys that blend ancient wisdom with cyberpunk futures.",
    social: {
      x: "https://x.com/NeteruApinaya",
      opensea: "https://opensea.io/BlockchaintrapperETH",
    },
    works: [
      {
        title: "AKIRA CODEX: NETERU APINAYA",
        type: "Interactive",
        category: "Game",
        description: "A myth-tech odyssey through the 33.3 FM spectrum",
        icon: Gamepad2,
        color: "cyan",
      },
      {
        title: "NETERU ARTIFACTS Collection",
        type: "NFT Series",
        category: "Blockchain",
        description: "Dynamic 404 NFT artifacts with mutation mechanics",
        icon: Film,
        color: "red",
      },
      {
        title: "NEURAL GUIDE v33.3",
        type: "AI System",
        category: "Interactive",
        description: "The Circuit Mind avatar intelligence framework",
        icon: Tv,
        color: "amber",
      },
      {
        title: "WIRED CHAOS META OS",
        type: "Platform",
        category: "System",
        description: "Dual-realm architecture for Business and Akashic operations",
        icon: BookOpen,
        color: "purple",
      },
    ],
  },
}

export default function CreatorProfilePage({ params }: { params: { id: string } }) {
  const creator = creatorData[params.id as keyof typeof creatorData]

  if (!creator) {
    return <div>Creator not found</div>
  }

  return (
    <main className="relative min-h-screen bg-black text-white">
      <CircuitBackground />

      <div className="container mx-auto px-4 py-16">
        <Link href="/echo-engineers">
          <Button variant="ghost" className="mb-8 text-white hover:text-cyan-400">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Echo Engineers
          </Button>
        </Link>

        <div className="mb-12 flex flex-col md:flex-row items-start gap-8">
          <div className="h-32 w-32 rounded-full bg-gradient-to-br from-cyan-500 to-red-500 p-1">
            <div className="h-full w-full rounded-full bg-black flex items-center justify-center">
              <span className="font-mono text-4xl font-bold text-white drop-shadow-[0_0_12px_rgba(255,255,255,0.8)]">
                {creator.name.substring(0, 2)}
              </span>
            </div>
          </div>

          <div className="flex-1">
            <GlitchText className="mb-2 text-4xl font-bold">{creator.name}</GlitchText>
            <p className="mb-4 text-lg font-mono text-cyan-300 drop-shadow-[0_0_8px_rgba(34,211,238,0.8)]">
              {creator.role}
            </p>
            <p className="mb-6 max-w-2xl text-zinc-200 drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]">{creator.bio}</p>

            <div className="flex gap-4">
              <a href={creator.social.x} target="_blank" rel="noopener noreferrer">
                <Button className="bg-cyan-600 hover:bg-cyan-500 text-white font-mono">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  X/Twitter
                </Button>
              </a>
              <a href={creator.social.opensea} target="_blank" rel="noopener noreferrer">
                <Button className="bg-red-600 hover:bg-red-500 text-white font-mono">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  OpenSea
                </Button>
              </a>
            </div>
          </div>
        </div>

        <div>
          <h2 className="mb-6 font-mono text-2xl font-bold text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]">
            WORKS
          </h2>
          <div className="grid gap-6 md:grid-cols-2">
            {creator.works.map((work, index) => {
              const Icon = work.icon
              const colorMap = {
                cyan: "border-cyan-500/50 bg-cyan-500/10 text-cyan-400",
                red: "border-red-500/50 bg-red-500/10 text-red-500",
                amber: "border-amber-500/50 bg-amber-500/10 text-amber-400",
                purple: "border-purple-500/50 bg-purple-500/10 text-purple-400",
              }
              return (
                <div key={index} className={`rounded-lg border p-6 ${colorMap[work.color as keyof typeof colorMap]}`}>
                  <Icon className="h-8 w-8 mb-3 drop-shadow-[0_0_12px_rgba(34,211,238,0.8)]" />
                  <h3 className="mb-2 font-mono text-lg font-bold text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]">
                    {work.title}
                  </h3>
                  <p className="mb-2 text-sm font-mono text-zinc-200">
                    {work.type} • {work.category}
                  </p>
                  <p className="text-sm text-zinc-200 drop-shadow-[0_0_4px_rgba(255,255,255,0.5)]">
                    {work.description}
                  </p>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </main>
  )
}
