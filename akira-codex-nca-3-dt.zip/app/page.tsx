"use client"

import { useState } from "react"
import { CircuitBackground } from "@/components/circuit-background"
import { NavHeader } from "@/components/nav-header"
import { HeroSection } from "@/components/hero-section"
import { FlinchGameHub } from "@/components/flinch-game-hub"
import { NFTGallery } from "@/components/nft-gallery"
import { NeuralGuide } from "@/components/neural-guide"
import { Footer } from "@/components/footer"
import { AgenticWelcome } from "@/components/agentic-welcome"

export default function Home() {
  const [welcomeComplete, setWelcomeComplete] = useState(false)

  return (
    <main className="relative min-h-screen bg-[#0D0D0D] text-foreground overflow-x-hidden">
      <CircuitBackground />
      <AgenticWelcome pageName="THE GRID" onComplete={() => setWelcomeComplete(true)} />
      <NavHeader />
      <HeroSection />
      <FlinchGameHub />
      <NFTGallery />
      <NeuralGuide />
      <Footer />
    </main>
  )
}
