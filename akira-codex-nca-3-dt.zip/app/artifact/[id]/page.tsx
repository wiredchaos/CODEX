"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import Link from "next/link"
import { ArrowLeft, Zap, Clock, DollarSign, User, TrendingUp, Calendar, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { CircuitBackground } from "@/components/circuit-background"
import { GlitchText } from "@/components/glitch-text"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const mockArtifacts: Record<
  string,
  {
    id: string
    name: string
    chain: string
    power: number
    rarity: string
    mutationLevel: number
    image: string
    description: string
    owner: {
      address: string
      name: string
      since: string
    }
    rental: {
      available: boolean
      ratePerDay: number
      ratePerWeek: number
      ratePerMonth: number
      minDuration: string
      maxDuration: string
      currentHolder: null | {
        address: string
        name: string
        since: string
        expiresIn: string
        revenue: number
      }
    }
    stats: {
      totalRentals: number
      totalRevenue: number
      avgRating: number
      activeRentals: number
    }
    attributes: { trait: string; value: string }[]
  }
> = {
  "1": {
    id: "1",
    name: "NETERU PHANTOM WALKER",
    chain: "SOL",
    power: 420,
    rarity: "RARE",
    mutationLevel: 1,
    image: "/cyberpunk-warrior-neon-red-desert-phantom.jpg",
    description:
      "A desert phantom from the ancient Neteru realm. This artifact channels crimson fire energy and grants the holder access to hidden pathways.",
    owner: {
      address: "BlockchaintrapperETH",
      name: "NEURO META X",
      since: "Jan 2024",
    },
    rental: {
      available: true,
      ratePerDay: 25,
      ratePerWeek: 150,
      ratePerMonth: 500,
      minDuration: "7 days",
      maxDuration: "90 days",
      currentHolder: null,
    },
    stats: {
      totalRentals: 12,
      totalRevenue: 3600,
      avgRating: 4.8,
      activeRentals: 0,
    },
    attributes: [
      { trait: "Realm", value: "Desert" },
      { trait: "Element", value: "Crimson Fire" },
      { trait: "Era", value: "Genesis" },
      { trait: "Power Type", value: "Chaos Energy" },
    ],
  },
  "2": {
    id: "2",
    name: "NETERU CODEX GUARDIAN",
    chain: "XRPL",
    power: 999,
    rarity: "MYTHIC",
    mutationLevel: 5,
    image: "/neon-samurai-cyberpunk-cyan-lightning-guardian.jpg",
    description:
      "The legendary Codex Guardian from the Neon City realm. This mythic artifact has ascended through all mutation epochs.",
    owner: {
      address: "BlockchaintrapperETH",
      name: "NEURO META X",
      since: "Jan 2024",
    },
    rental: {
      available: true,
      ratePerDay: 50,
      ratePerWeek: 300,
      ratePerMonth: 1000,
      minDuration: "14 days",
      maxDuration: "180 days",
      currentHolder: {
        address: "0x7def...89ab",
        name: "ChaosSeeker777",
        since: "3 days ago",
        expiresIn: "11 days",
        revenue: 150,
      },
    },
    stats: {
      totalRentals: 8,
      totalRevenue: 8400,
      avgRating: 5.0,
      activeRentals: 1,
    },
    attributes: [
      { trait: "Realm", value: "Neon City" },
      { trait: "Element", value: "Cyan Lightning" },
      { trait: "Era", value: "Ascended" },
      { trait: "Power Type", value: "Neural Network" },
    ],
  },
  "3": {
    id: "3",
    name: "CHAOS REAPER PRIME",
    chain: "ETH",
    power: 777,
    rarity: "LEGENDARY",
    mutationLevel: 3,
    image: "/dark-reaper-cyberpunk-red-glowing-scythe.jpg",
    description:
      "A legendary reaper forged in the chaos dimension. Wields dark energy and grants bonus mutations in combat.",
    owner: {
      address: "BlockchaintrapperETH",
      name: "NEURO META X",
      since: "Feb 2024",
    },
    rental: {
      available: true,
      ratePerDay: 40,
      ratePerWeek: 250,
      ratePerMonth: 800,
      minDuration: "7 days",
      maxDuration: "120 days",
      currentHolder: null,
    },
    stats: {
      totalRentals: 15,
      totalRevenue: 6000,
      avgRating: 4.9,
      activeRentals: 0,
    },
    attributes: [
      { trait: "Realm", value: "Chaos Dimension" },
      { trait: "Element", value: "Dark Energy" },
      { trait: "Era", value: "Awakened" },
      { trait: "Power Type", value: "Soul Harvest" },
    ],
  },
}

export default function ArtifactProfilePage() {
  const params = useParams()
  const id = (params?.id as string) || "1"
  const artifact = mockArtifacts[id] || mockArtifacts["1"]
  const [rentalDuration, setRentalDuration] = useState<"day" | "week" | "month">("week")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const getRentalRate = () => {
    switch (rentalDuration) {
      case "day":
        return artifact.rental.ratePerDay
      case "week":
        return artifact.rental.ratePerWeek
      case "month":
        return artifact.rental.ratePerMonth
    }
  }

  if (!mounted) {
    return (
      <main className="relative min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-cyan-400 font-mono animate-pulse">LOADING ARTIFACT...</div>
      </main>
    )
  }

  return (
    <main className="relative min-h-screen bg-black text-white">
      <CircuitBackground />

      <div
        className="fixed inset-0 pointer-events-none z-[1]"
        style={{
          background: "linear-gradient(180deg, rgba(0,0,0,0.4) 0%, rgba(0,0,0,0.2) 50%, rgba(0,0,0,0.5) 100%)",
          backdropFilter: "blur(0.5px)",
        }}
        aria-hidden="true"
      />

      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-zinc-800 bg-black/80 backdrop-blur-md">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-4">
            <Link href="/terminal" aria-label="Back to Terminal">
              <Button
                variant="ghost"
                size="icon"
                className="text-white hover:text-red-500"
                aria-label="Go back to terminal"
              >
                <ArrowLeft className="h-5 w-5" aria-hidden="true" />
              </Button>
            </Link>
            <div>
              <GlitchText
                text="ARTIFACT PROFILE"
                as="h1"
                className="font-mono text-lg font-bold tracking-widest"
                glow={true}
                glowColor="cyan"
              />
              <p className="text-[10px] font-mono text-cyan-300" style={{ textShadow: "0 0 8px #00FFF7" }}>
                NFT DETAILS & RENTAL MARKET
              </p>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left - Image & Quick Stats */}
          <div className="lg:col-span-1 space-y-6">
            {/* NFT Image */}
            <div
              className="relative rounded-lg border border-cyan-500/30 overflow-hidden"
              style={{ boxShadow: "0 0 30px rgba(0,255,247,0.2)" }}
            >
              <img
                src={artifact.image || "/placeholder.svg"}
                alt={`${artifact.name} - ${artifact.rarity} NFT artifact from the ${artifact.attributes[0]?.value || "Unknown"} realm`}
                className="w-full aspect-square object-cover"
              />
              <div className="absolute top-3 right-3 flex gap-2">
                <Badge className="bg-cyan-500/20 text-cyan-300 border-cyan-500/50">{artifact.chain}</Badge>
                <Badge
                  className={
                    artifact.rarity === "MYTHIC"
                      ? "bg-red-500/20 text-red-300 border-red-500/50"
                      : artifact.rarity === "LEGENDARY"
                        ? "bg-amber-500/20 text-amber-300 border-amber-500/50"
                        : "bg-cyan-500/20 text-cyan-300 border-cyan-500/50"
                  }
                >
                  {artifact.rarity}
                </Badge>
              </div>
            </div>

            {/* Owner Info */}
            <div
              className="rounded-lg border border-zinc-700 bg-zinc-900/50 p-4"
              style={{ boxShadow: "0 0 15px rgba(0,255,247,0.1)" }}
              role="region"
              aria-label="Owner Information"
            >
              <div className="flex items-center gap-3 mb-4">
                <div
                  className="h-10 w-10 rounded bg-amber-500/20 flex items-center justify-center"
                  style={{ boxShadow: "0 0 15px rgba(245,158,11,0.3)" }}
                  aria-hidden="true"
                >
                  <User className="h-5 w-5 text-amber-400" style={{ filter: "drop-shadow(0 0 8px #F59E0B)" }} />
                </div>
                <div>
                  <p className="text-[10px] font-mono text-zinc-400">OWNED BY</p>
                  <p className="font-mono text-sm font-bold text-white" style={{ textShadow: "0 0 10px #FFFFFF" }}>
                    {artifact.owner.name}
                  </p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 text-center">
                <div className="rounded bg-black/50 p-2">
                  <p className="text-[10px] font-mono text-zinc-400">PWR</p>
                  <p className="font-mono text-lg font-bold text-amber-400" aria-label={`Power: ${artifact.power}`}>
                    {artifact.power}
                  </p>
                </div>
                <div className="rounded bg-black/50 p-2">
                  <p className="text-[10px] font-mono text-zinc-400">MUT LV</p>
                  <p
                    className="font-mono text-lg font-bold text-red-500"
                    aria-label={`Mutation Level: ${artifact.mutationLevel}`}
                  >
                    {artifact.mutationLevel}
                  </p>
                </div>
              </div>
            </div>

            {/* Description */}
            <div
              className="rounded-lg border border-zinc-700 bg-zinc-900/50 p-4"
              style={{ boxShadow: "0 0 15px rgba(0,255,247,0.1)" }}
            >
              <p className="text-[10px] font-mono text-cyan-400 mb-2">ARTIFACT LORE</p>
              <p className="text-sm text-zinc-300 leading-relaxed">{artifact.description}</p>
            </div>
          </div>

          {/* Right - Details & Rental */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="details" className="w-full">
              <TabsList
                className="grid w-full grid-cols-3 bg-zinc-900/50 border border-zinc-700"
                aria-label="Artifact information tabs"
              >
                <TabsTrigger value="details" className="data-[state=active]:text-cyan-400">
                  DETAILS
                </TabsTrigger>
                <TabsTrigger value="rental" className="data-[state=active]:text-cyan-400">
                  RENTAL INFO
                </TabsTrigger>
                <TabsTrigger value="stats" className="data-[state=active]:text-cyan-400">
                  PASSIVE INCOME
                </TabsTrigger>
              </TabsList>

              {/* Details Tab */}
              <TabsContent value="details" className="space-y-6">
                <div
                  className="rounded-lg border border-zinc-700 bg-zinc-900/50 p-6"
                  style={{ boxShadow: "0 0 15px rgba(0,255,247,0.1)" }}
                >
                  <h2
                    className="font-mono text-2xl font-bold text-white mb-2"
                    style={{ textShadow: "0 0 15px #00FFF7" }}
                  >
                    {artifact.name}
                  </h2>
                  <p className="text-sm text-zinc-400 mb-6">
                    Premium NETERU ARTIFACT from the WIRED CHAOS META ecosystem. Each artifact is unique and carries
                    distinct power signatures from the Akira Codex.
                  </p>

                  <h3 className="font-mono text-sm font-bold text-cyan-400 mb-4">ATTRIBUTES</h3>
                  <div className="grid grid-cols-2 gap-3" role="list" aria-label="Artifact attributes">
                    {artifact.attributes.map((attr, i) => (
                      <div key={i} className="rounded bg-black/50 p-3 border border-zinc-700" role="listitem">
                        <p className="text-[10px] font-mono text-zinc-400 mb-1">{attr.trait}</p>
                        <p className="font-mono text-sm text-white">{attr.value}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              {/* Rental Tab */}
              <TabsContent value="rental" className="space-y-6">
                {artifact.rental.currentHolder ? (
                  <div
                    className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-6"
                    style={{ boxShadow: "0 0 20px rgba(245,158,11,0.2)" }}
                    role="region"
                    aria-label="Current rental information"
                  >
                    <div className="flex items-center gap-3 mb-4">
                      <Clock className="h-6 w-6 text-amber-400" aria-hidden="true" />
                      <h3 className="font-mono text-lg font-bold text-white">CURRENTLY RENTED</h3>
                    </div>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-[10px] font-mono text-zinc-400 mb-1">CURRENT HOLDER</p>
                        <p className="font-mono text-sm text-white">{artifact.rental.currentHolder.name}</p>
                        <p className="text-xs text-zinc-500">{artifact.rental.currentHolder.address}</p>
                      </div>
                      <div>
                        <p className="text-[10px] font-mono text-zinc-400 mb-1">RENTAL PERIOD</p>
                        <p className="font-mono text-sm text-white">Started {artifact.rental.currentHolder.since}</p>
                        <p className="text-xs text-amber-400">Expires in {artifact.rental.currentHolder.expiresIn}</p>
                      </div>
                    </div>
                    <div className="mt-4 pt-4 border-t border-amber-500/30">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-zinc-400">Revenue from this rental</span>
                        <span className="font-mono text-lg font-bold text-amber-400">
                          +{artifact.rental.currentHolder.revenue} NTRU
                        </span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div
                    className="rounded-lg border border-green-500/30 bg-green-500/10 p-6"
                    style={{ boxShadow: "0 0 20px rgba(34,197,94,0.2)" }}
                    role="region"
                    aria-label="Rental options"
                  >
                    <div className="flex items-center gap-3 mb-6">
                      <Zap className="h-6 w-6 text-green-400" aria-hidden="true" />
                      <h3 className="font-mono text-lg font-bold text-white">AVAILABLE FOR RENT</h3>
                    </div>

                    {/* Rental Options */}
                    <div className="grid grid-cols-3 gap-3 mb-6" role="radiogroup" aria-label="Rental duration options">
                      <button
                        type="button"
                        onClick={() => setRentalDuration("day")}
                        aria-pressed={rentalDuration === "day"}
                        className={`p-4 rounded-lg border text-center transition-all focus:outline-none focus:ring-2 focus:ring-cyan-500 ${
                          rentalDuration === "day"
                            ? "border-cyan-500/50 bg-cyan-500/20 shadow-[0_0_15px_rgba(0,255,247,0.2)]"
                            : "border-zinc-700 bg-zinc-900/50 hover:border-zinc-600"
                        }`}
                      >
                        <p className="text-[10px] font-mono text-zinc-400 mb-1">DAILY</p>
                        <p className="font-mono text-lg font-bold text-white">{artifact.rental.ratePerDay}</p>
                        <p className="text-[10px] text-zinc-500">NTRU/DAY</p>
                      </button>
                      <button
                        type="button"
                        onClick={() => setRentalDuration("week")}
                        aria-pressed={rentalDuration === "week"}
                        className={`p-4 rounded-lg border text-center transition-all focus:outline-none focus:ring-2 focus:ring-cyan-500 ${
                          rentalDuration === "week"
                            ? "border-cyan-500/50 bg-cyan-500/20 shadow-[0_0_15px_rgba(0,255,247,0.2)]"
                            : "border-zinc-700 bg-zinc-900/50 hover:border-zinc-600"
                        }`}
                      >
                        <p className="text-[10px] font-mono text-zinc-400 mb-1">WEEKLY</p>
                        <p className="font-mono text-lg font-bold text-white">{artifact.rental.ratePerWeek}</p>
                        <p className="text-[10px] text-zinc-500">NTRU/WEEK</p>
                      </button>
                      <button
                        type="button"
                        onClick={() => setRentalDuration("month")}
                        aria-pressed={rentalDuration === "month"}
                        className={`p-4 rounded-lg border text-center transition-all focus:outline-none focus:ring-2 focus:ring-cyan-500 ${
                          rentalDuration === "month"
                            ? "border-cyan-500/50 bg-cyan-500/20 shadow-[0_0_15px_rgba(0,255,247,0.2)]"
                            : "border-zinc-700 bg-zinc-900/50 hover:border-zinc-600"
                        }`}
                      >
                        <p className="text-[10px] font-mono text-zinc-400 mb-1">MONTHLY</p>
                        <p className="font-mono text-lg font-bold text-white">{artifact.rental.ratePerMonth}</p>
                        <p className="text-[10px] text-zinc-500">NTRU/MONTH</p>
                      </button>
                    </div>

                    {/* Rental Terms */}
                    <div className="rounded-lg bg-black/50 p-4 border border-zinc-700 mb-6">
                      <div className="flex items-start gap-2">
                        <Info className="h-4 w-4 text-zinc-400 mt-0.5 flex-shrink-0" aria-hidden="true" />
                        <div className="space-y-2 text-xs text-zinc-400">
                          <p>
                            <span className="text-white font-mono">Minimum Duration:</span>{" "}
                            {artifact.rental.minDuration}
                          </p>
                          <p>
                            <span className="text-white font-mono">Maximum Duration:</span>{" "}
                            {artifact.rental.maxDuration}
                          </p>
                          <p>
                            <span className="text-white font-mono">Payment:</span> NTRU tokens locked in escrow
                          </p>
                          <p>
                            <span className="text-white font-mono">Benefits:</span> Use in games, breeding rights,
                            mutation boosts
                          </p>
                        </div>
                      </div>
                    </div>

                    <Button
                      className="w-full bg-green-600 hover:bg-green-500 text-white font-mono focus:outline-none focus:ring-2 focus:ring-green-400 focus:ring-offset-2 focus:ring-offset-black"
                      aria-label={`Rent this artifact for ${getRentalRate()} NTRU`}
                    >
                      <DollarSign className="h-4 w-4 mr-2" aria-hidden="true" />
                      RENT FOR {getRentalRate()} NTRU
                    </Button>
                  </div>
                )}
              </TabsContent>

              {/* Stats Tab */}
              <TabsContent value="stats" className="space-y-6">
                <div
                  className="rounded-lg border border-zinc-700 bg-zinc-900/50 p-6"
                  style={{ boxShadow: "0 0 15px rgba(0,255,247,0.1)" }}
                  role="region"
                  aria-label="Passive income analytics"
                >
                  <div className="flex items-center gap-3 mb-6">
                    <TrendingUp className="h-6 w-6 text-cyan-400" aria-hidden="true" />
                    <h3 className="font-mono text-lg font-bold text-white">PASSIVE INCOME ANALYTICS</h3>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6 mb-6">
                    <div className="rounded-lg bg-black/50 p-4 border border-cyan-500/30">
                      <p className="text-[10px] font-mono text-zinc-400 mb-2">TOTAL RENTAL REVENUE</p>
                      <p
                        className="font-mono text-3xl font-bold text-cyan-400"
                        style={{ textShadow: "0 0 15px #00FFF7" }}
                        aria-label={`Total revenue: ${artifact.stats.totalRevenue.toLocaleString()} NTRU`}
                      >
                        {artifact.stats.totalRevenue.toLocaleString()}
                      </p>
                      <p className="text-xs text-zinc-500 mt-1">NTRU EARNED</p>
                    </div>
                    <div className="rounded-lg bg-black/50 p-4 border border-amber-500/30">
                      <p className="text-[10px] font-mono text-zinc-400 mb-2">AVG RATING</p>
                      <p
                        className="font-mono text-3xl font-bold text-amber-400"
                        style={{ textShadow: "0 0 15px #F59E0B" }}
                        aria-label={`Average rating: ${artifact.stats.avgRating} out of 5`}
                      >
                        {artifact.stats.avgRating}
                      </p>
                      <p className="text-xs text-zinc-500 mt-1">OUT OF 5.0</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="rounded bg-black/50 p-4 border border-zinc-700 text-center">
                      <Calendar className="h-5 w-5 text-zinc-400 mx-auto mb-2" aria-hidden="true" />
                      <p className="text-[10px] font-mono text-zinc-400">TOTAL RENTALS</p>
                      <p className="font-mono text-2xl font-bold text-white">{artifact.stats.totalRentals}</p>
                    </div>
                    <div className="rounded bg-black/50 p-4 border border-zinc-700 text-center">
                      <Zap className="h-5 w-5 text-green-400 mx-auto mb-2" aria-hidden="true" />
                      <p className="text-[10px] font-mono text-zinc-400">ACTIVE NOW</p>
                      <p className="font-mono text-2xl font-bold text-green-400">{artifact.stats.activeRentals}</p>
                    </div>
                  </div>

                  <div className="mt-6 p-4 rounded-lg bg-gradient-to-r from-cyan-500/10 to-red-500/10 border border-cyan-500/30">
                    <p className="text-sm text-zinc-300 mb-2">
                      <span className="font-bold text-cyan-400">PASSIVE INCOME STRATEGY:</span>
                    </p>
                    <p className="text-xs text-zinc-400">
                      By renting out your NETERU ARTIFACTS, you earn NTRU tokens while maintaining ownership. Renters
                      gain access to gameplay features, breeding rights, and mutation boosts. Your NFT generates income
                      24/7 while you sleep!
                    </p>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </main>
  )
}
