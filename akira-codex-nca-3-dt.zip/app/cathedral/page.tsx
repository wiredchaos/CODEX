"use client"

import { useState } from "react"
import Link from "next/link"
import dynamic from "next/dynamic"
import { ArrowLeft, Sparkles, Play, Pause, Volume2, VolumeX, Maximize2, Grid3X3 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { GlitchText } from "@/components/glitch-text"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Dynamic import for 3D components (client-side only)
const PortalScene = dynamic(() => import("@/components/three/portal-scene").then((mod) => mod.PortalScene), {
  ssr: false,
  loading: () => (
    <div className="w-full h-full flex items-center justify-center bg-black">
      <div className="text-center">
        <div className="animate-pulse text-cyan-400 font-mono text-sm">LOADING PORTAL...</div>
      </div>
    </div>
  ),
})

const VisionBoard = dynamic(() => import("@/components/three/vision-board").then((mod) => mod.VisionBoard), {
  ssr: false,
  loading: () => (
    <div className="w-full h-full flex items-center justify-center bg-black">
      <div className="text-center">
        <div className="animate-pulse text-amber-400 font-mono text-sm">LOADING VISION BOARD...</div>
      </div>
    </div>
  ),
})

const cathedralStats = [
  { label: "REALMS UNLOCKED", value: "4", color: "cyan" },
  { label: "STORIES WRITTEN", value: "127", color: "crimson" },
  { label: "ARTIFACTS FORGED", value: "89", color: "gold" },
  { label: "PORTALS ACTIVE", value: "3", color: "white" },
]

const realmGates = [
  { id: "neuralis", name: "NEURALIS", description: "Realm of Neural Consciousness", status: "OPEN", color: "#06b6d4" },
  { id: "chaosphere", name: "CHAOSPHERE", description: "Domain of Creative Chaos", status: "OPEN", color: "#dc2626" },
  { id: "akira", name: "AKIRA SANCTUM", description: "Ancient Codex Repository", status: "LOCKED", color: "#fbbf24" },
  {
    id: "neteru",
    name: "NETERU DEPTHS",
    description: "Ancestral Spirit Realm",
    status: "RESTRICTED",
    color: "#8b5cf6",
  },
]

export default function CathedralPage() {
  const [isPlaying, setIsPlaying] = useState(true)
  const [isMuted, setIsMuted] = useState(false)
  const [activeTab, setActiveTab] = useState("portal")

  return (
    <main className="relative min-h-screen bg-black text-white">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-zinc-800 bg-black/80 backdrop-blur-md">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon" className="text-white hover:text-red-500">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <GlitchText
                text="NEURAL CATHEDRAL"
                as="h1"
                className="font-mono text-lg font-bold tracking-widest"
                glow={true}
                glowColor="crimson"
              />
              <p className="text-[10px] font-mono text-zinc-400">IMMERSIVE REALM GATEWAY</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsPlaying(!isPlaying)}
              className="text-white hover:text-cyan-400"
            >
              {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMuted(!isMuted)}
              className="text-white hover:text-cyan-400"
            >
              {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </Button>
            <Button variant="ghost" size="icon" className="text-white hover:text-cyan-400">
              <Maximize2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        {/* Stats Bar */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          {cathedralStats.map((stat) => (
            <div key={stat.label} className="rounded-lg border border-zinc-800 bg-zinc-900/50 p-3 text-center">
              <p className="text-[10px] font-mono text-zinc-400 mb-1">{stat.label}</p>
              <p
                className={`font-mono text-xl font-bold ${
                  stat.color === "cyan"
                    ? "text-cyan-400"
                    : stat.color === "crimson"
                      ? "text-red-500"
                      : stat.color === "gold"
                        ? "text-amber-400"
                        : "text-white"
                }`}
                style={{
                  textShadow:
                    stat.color === "cyan"
                      ? "0 0 15px rgba(6,182,212,0.8)"
                      : stat.color === "crimson"
                        ? "0 0 15px rgba(220,38,38,0.8)"
                        : stat.color === "gold"
                          ? "0 0 15px rgba(245,158,11,0.8)"
                          : "none",
                }}
              >
                {stat.value}
              </p>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-4 gap-6">
          {/* Main 3D Viewport */}
          <div className="lg:col-span-3">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="w-full justify-start bg-zinc-900 border border-zinc-800 mb-4">
                <TabsTrigger
                  value="portal"
                  className="font-mono text-xs data-[state=active]:bg-red-500/20 data-[state=active]:text-red-400"
                >
                  <Sparkles className="h-3 w-3 mr-2" />
                  PORTAL VIEW
                </TabsTrigger>
                <TabsTrigger
                  value="vision"
                  className="font-mono text-xs data-[state=active]:bg-amber-500/20 data-[state=active]:text-amber-400"
                >
                  <Grid3X3 className="h-3 w-3 mr-2" />
                  VISION BOARD
                </TabsTrigger>
              </TabsList>

              <TabsContent value="portal" className="mt-0">
                <div className="relative aspect-video rounded-lg border border-zinc-800 overflow-hidden bg-black">
                  <PortalScene />
                  {/* Overlay UI */}
                  <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                    <div className="px-3 py-1.5 rounded bg-black/60 backdrop-blur border border-zinc-700">
                      <span className="font-mono text-[10px] text-cyan-400">REALM: NEURALIS</span>
                    </div>
                    <div className="px-3 py-1.5 rounded bg-black/60 backdrop-blur border border-zinc-700">
                      <span className="font-mono text-[10px] text-amber-400">33.3 FM ACTIVE</span>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="vision" className="mt-0">
                <div className="relative aspect-video rounded-lg border border-zinc-800 overflow-hidden bg-black">
                  <VisionBoard />
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Right Sidebar - Realm Gates */}
          <div className="lg:col-span-1">
            <h2 className="font-mono text-sm font-bold text-white mb-4 flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-red-500" />
              REALM GATES
            </h2>
            <div className="space-y-3">
              {realmGates.map((gate) => (
                <button
                  key={gate.id}
                  className="w-full p-4 rounded-lg border border-zinc-800 bg-zinc-900/50 hover:border-zinc-700 transition-all text-left group"
                  style={{
                    borderColor: gate.status === "OPEN" ? `${gate.color}30` : undefined,
                  }}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-mono text-sm font-bold text-white">{gate.name}</h3>
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                        gate.status === "OPEN"
                          ? "bg-green-500/20 text-green-400"
                          : gate.status === "LOCKED"
                            ? "bg-red-500/20 text-red-400"
                            : "bg-amber-500/20 text-amber-400"
                      }`}
                    >
                      {gate.status}
                    </span>
                  </div>
                  <p className="text-xs text-zinc-400">{gate.description}</p>
                  <div className="mt-2 h-1 rounded-full bg-zinc-800 overflow-hidden">
                    <div
                      className="h-full transition-all"
                      style={{
                        width: gate.status === "OPEN" ? "100%" : gate.status === "RESTRICTED" ? "60%" : "20%",
                        backgroundColor: gate.color,
                      }}
                    />
                  </div>
                </button>
              ))}
            </div>

            {/* Quick Enter */}
            <div className="mt-6">
              <Button className="w-full bg-red-600 hover:bg-red-700 text-white font-mono text-xs shadow-[0_0_20px_rgba(220,38,38,0.4)]">
                ENTER PORTAL
              </Button>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
