"use client"

import { useParams } from "next/navigation"
import Link from "next/link"
import { ArrowLeft, Shield, Sparkles, Flame, Eye } from "lucide-react"
import { Button } from "@/components/ui/button"
import { GlitchText } from "@/components/glitch-text"
import { CircuitBackground } from "@/components/circuit-background"
import type { AgeTier } from "@/components/portal/age-gate"

const tierContent: Record<
  AgeTier,
  {
    name: string
    subtitle: string
    description: string
    icon: typeof Shield
    color: string
    glowColor: "cyan" | "gold" | "crimson" | "white"
    stories: { title: string; type: string }[]
  }
> = {
  light: {
    name: "LIGHT GATE",
    subtitle: "REALM OF ILLUMINATION",
    description:
      "Welcome to the Light Gate, seeker. Here you will find the foundational myths of the Neteru, the symbolism of the Akira Codex, and family-friendly lore exploration.",
    icon: Shield,
    color: "#06b6d4",
    glowColor: "cyan",
    stories: [
      { title: "The Birth of Neuralis", type: "ORIGIN MYTH" },
      { title: "Symbols of the Codex", type: "LORE GUIDE" },
      { title: "The First Navigators", type: "HERO TALE" },
      { title: "Gateway to Chaos", type: "WORLD BUILDING" },
    ],
  },
  shadow: {
    name: "SHADOW GATE",
    subtitle: "REALM OF DUALITY",
    description:
      "You have crossed into the Shadow Gate. Moral ambiguity awaits. The stories here explore the darker aspects of consciousness, complex characters, and mature themes.",
    icon: Sparkles,
    color: "#fbbf24",
    glowColor: "gold",
    stories: [
      { title: "The Betrayer's Path", type: "DARK NARRATIVE" },
      { title: "Echoes of Lost Souls", type: "PSYCHOLOGICAL" },
      { title: "The Price of Power", type: "MORAL TALE" },
      { title: "Shadows Within", type: "CHARACTER STUDY" },
    ],
  },
  redveil: {
    name: "RED VEIL",
    subtitle: "REALM OF PASSION",
    description:
      "Beyond the Red Veil lies artistic expression in its most sensual form. Symbolic eroticism, mature romance, and the dance of desire await.",
    icon: Flame,
    color: "#dc2626",
    glowColor: "crimson",
    stories: [
      { title: "The Crimson Dance", type: "SYMBOLIC ROMANCE" },
      { title: "Whispers of Desire", type: "MATURE NARRATIVE" },
      { title: "The Flame and the Void", type: "ARTISTIC EROTICA" },
      { title: "Passion Codex", type: "EXPRESSION" },
    ],
  },
  void: {
    name: "VOID SANCTUM",
    subtitle: "REALM WITHOUT LIMITS",
    description:
      "You have entered the Void Sanctum. Here, creative expression knows no bounds. NSFW content is enabled. Proceed with intention.",
    icon: Eye,
    color: "#8b5cf6",
    glowColor: "white",
    stories: [
      { title: "Unrestricted Genesis", type: "NSFW NARRATIVE" },
      { title: "The Void Embrace", type: "EXPLICIT" },
      { title: "Beyond All Veils", type: "UNCENSORED" },
      { title: "Sanctum Secrets", type: "PRIVATE REALM" },
    ],
  },
}

export default function RealmPage() {
  const params = useParams()
  const tier = params.tier as AgeTier

  const content = tierContent[tier] || tierContent.light
  const Icon = content.icon

  return (
    <main className="relative min-h-screen bg-black text-white">
      <CircuitBackground />

      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-zinc-800 bg-black/80 backdrop-blur-md">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-4">
            <Link href="/portal">
              <Button variant="ghost" size="icon" className="text-white hover:text-red-500">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <GlitchText
                text={content.name}
                as="h1"
                className="font-mono text-lg font-bold tracking-widest"
                glow={true}
                glowColor={content.glowColor}
              />
              <p className="text-[10px] font-mono text-zinc-400">{content.subtitle}</p>
            </div>
          </div>

          <div
            className="flex items-center gap-2 px-3 py-1.5 rounded"
            style={{ backgroundColor: `${content.color}20`, borderColor: `${content.color}50` }}
          >
            <Icon className="h-4 w-4" style={{ color: content.color }} />
            <span className="font-mono text-xs" style={{ color: content.color }}>
              {tier.toUpperCase()} TIER ACTIVE
            </span>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        {/* Welcome Banner */}
        <div
          className="p-8 rounded-lg border mb-12"
          style={{
            borderColor: `${content.color}30`,
            backgroundColor: `${content.color}05`,
            boxShadow: `0 0 50px ${content.color}10`,
          }}
        >
          <div className="flex items-start gap-6">
            <div
              className="h-16 w-16 rounded-lg flex items-center justify-center flex-shrink-0"
              style={{ backgroundColor: `${content.color}20` }}
            >
              <Icon className="h-8 w-8" style={{ color: content.color }} />
            </div>
            <div>
              <h2
                className="font-mono text-2xl font-bold mb-2"
                style={{ color: content.color, textShadow: `0 0 20px ${content.color}` }}
              >
                WELCOME TO THE {content.name}
              </h2>
              <p className="text-zinc-300 leading-relaxed">{content.description}</p>
            </div>
          </div>
        </div>

        {/* Story Grid */}
        <h3 className="font-mono text-sm font-bold text-white mb-6">AVAILABLE STORIES</h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {content.stories.map((story, i) => (
            <div
              key={i}
              className="p-6 rounded-lg border border-zinc-800 bg-zinc-900/50 hover:border-zinc-700 transition-all cursor-pointer group"
            >
              <span
                className="text-[10px] font-mono px-2 py-0.5 rounded mb-3 inline-block"
                style={{ backgroundColor: `${content.color}20`, color: content.color }}
              >
                {story.type}
              </span>
              <h4 className="font-mono text-sm font-bold text-white group-hover:text-opacity-80 transition-colors">
                {story.title}
              </h4>
              <p className="text-xs text-zinc-500 mt-2">Click to begin reading...</p>
            </div>
          ))}
        </div>

        {/* Navigation */}
        <div className="mt-12 flex justify-center gap-4">
          <Link href="/portal">
            <Button
              variant="outline"
              className="font-mono text-xs bg-transparent border-zinc-700 text-white hover:bg-zinc-800"
            >
              CHANGE REALM
            </Button>
          </Link>
          <Link href="/">
            <Button
              variant="outline"
              className="font-mono text-xs bg-transparent border-zinc-700 text-white hover:bg-zinc-800"
            >
              RETURN HOME
            </Button>
          </Link>
        </div>
      </div>
    </main>
  )
}
