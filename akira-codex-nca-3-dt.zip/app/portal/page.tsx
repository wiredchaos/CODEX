"use client"

import { AgeGate } from "@/components/portal/age-gate"

export default function PortalPage() {
  return <AgeGate />
}
