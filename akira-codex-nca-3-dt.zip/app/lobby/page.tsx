/**
 * TRINITY LOBBY — CONSUMER MOUNT
 *
 * Renders the lobby environment using EnvironmentRenderer
 * Consumes Trinity 3D Core (read-only)
 * Video fallback if 3D unavailable
 */

import { EnvironmentRenderer } from "@/components/trinity/environment-renderer"

export default function LobbyPage() {
  return <EnvironmentRenderer patchId="NEURO-CODE-APINAYA" kind="lobby" />
}
