import type React from "react"
import type { Metadata, Viewport } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Orbitron } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"
import { TrinityStatus } from "@/components/trinity-status"

const _geist = Geist({ subsets: ["latin"] })
const _geistMono = Geist_Mono({ subsets: ["latin"] })
const _orbitron = Orbitron({ subsets: ["latin"], variable: "--font-display" })

// Updated metadata for AKIRA CODEX
export const metadata: Metadata = {
  title: "AKIRA CODEX | NEURO CODE: APINAYA FREQUENCY",
  description:
    "Enter the 33.3 FM spectrum. NETERU ARTIFACTS rhythm game. Film3 interactive experiences. Wired Chaos Meta.",
  generator: "v0.app",
  keywords: [
    "AKIRA CODEX",
    "NETERU ARTIFACTS",
    "NETERU APINAYA",
    "NFT",
    "Film3",
    "Web3 Gaming",
    "Rhythm Game",
    "Neuro Code",
    "WIRED CHAOS META",
  ],
  authors: [{ name: "NEURO META X | NETERU STUDIOS", url: "https://opensea.io/BlockchaintrapperETH" }],
  openGraph: {
    title: "AKIRA CODEX | NEURO CODE: APINAYA FREQUENCY",
    description: "Enter the 33.3 FM spectrum. The motherboard routes to you. NETERU STUDIOS.",
    type: "website",
  },
  icons: {
    icon: [
      {
        url: "/icon-light-32x32.png",
        media: "(prefers-color-scheme: light)",
      },
      {
        url: "/icon-dark-32x32.png",
        media: "(prefers-color-scheme: dark)",
      },
      {
        url: "/icon.svg",
        type: "image/svg+xml",
      },
    ],
    apple: "/apple-icon.png",
  },
}

export const viewport: Viewport = {
  themeColor: "#0a0a0f",
  colorScheme: "dark",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark">
      <body className={`font-sans antialiased ${_orbitron.variable}`}>
        {children}
        <TrinityStatus />
        <Analytics />
      </body>
    </html>
  )
}
