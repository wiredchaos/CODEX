"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Grid3X3, List, Filter } from "lucide-react"
import { Button } from "@/components/ui/button"
import { CircuitBackground } from "@/components/circuit-background"
import { ArtifactCard } from "@/components/terminal/artifact-card"
import { ExchangeConsole } from "@/components/terminal/exchange-console"
import { NTRUBalance } from "@/components/terminal/ntru-balance"
import { MutationEpoch } from "@/components/terminal/mutation-epoch"
import { Dynamic404 } from "@/components/terminal/dynamic-404"
import { AgenticWelcome } from "@/components/agentic-welcome"
import { cn } from "@/lib/utils"
import type { NFTArtifact } from "@/lib/types/ntru"

const mockArtifacts: NFTArtifact[] = [
  {
    id: "1",
    user_id: "user1",
    token_id: "NTR-001",
    contract_address: "0x...",
    chain: "ETH",
    name: "NETERU GENESIS #001",
    image_url: "/cyberpunk-warrior-nft.jpg",
    rarity: "LEGENDARY",
    resonance_power: 850,
    is_404_state: false,
    mutation_level: 3,
    mutation_progress: 75,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: "2",
    user_id: "user1",
    token_id: "NTR-002",
    contract_address: "0x...",
    chain: "ETH",
    name: "NETERU ECHO #042",
    image_url: "/neon-samurai-nft.jpg",
    rarity: "EPIC",
    resonance_power: 620,
    is_404_state: true,
    mutation_level: 2,
    mutation_progress: 45,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: "3",
    user_id: "user1",
    token_id: "NTR-003",
    contract_address: "0x...",
    chain: "SOL",
    name: "NETERU PHANTOM #108",
    image_url: "/dark-mystic-nft.jpg",
    rarity: "RARE",
    resonance_power: 420,
    is_404_state: false,
    mutation_level: 1,
    mutation_progress: 90,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: "4",
    user_id: "user1",
    token_id: "NTR-004",
    contract_address: "0x...",
    chain: "XRPL",
    name: "NETERU CODEX #256",
    image_url: "/ancient-tech-artifact-nft.jpg",
    rarity: "MYTHIC",
    resonance_power: 999,
    is_404_state: false,
    mutation_level: 5,
    mutation_progress: 100,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
]

export default function TerminalPage() {
  const [selectedArtifact, setSelectedArtifact] = useState<NFTArtifact | null>(null)
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")

  const artifact404Count = mockArtifacts.filter((a) => a.is_404_state).length

  return (
    <main className="relative min-h-screen bg-black text-white">
      <CircuitBackground />
      <AgenticWelcome pageName="ARTIFACT TERMINAL" />

      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-zinc-800 bg-black/80 backdrop-blur-md">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon" className="text-white hover:text-red-500">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1
                className="font-mono text-sm font-bold tracking-widest text-white"
                style={{ textShadow: "0 0 10px #00FFF7, 0 0 20px #00FFF7" }}
              >
                ARTIFACT TERMINAL
              </h1>
              <p className="text-[10px] font-mono text-cyan-300" style={{ textShadow: "0 0 8px #00FFF7" }}>
                NETERU APINAYA EXCHANGE CONSOLE
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setViewMode("grid")}
              className={cn("text-white", viewMode === "grid" && "bg-red-500/20 text-red-500")}
            >
              <Grid3X3 className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setViewMode("list")}
              className={cn("text-white", viewMode === "list" && "bg-red-500/20 text-red-500")}
            >
              <List className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="font-mono text-xs bg-transparent border-cyan-500/50 text-cyan-300 hover:bg-cyan-500/20"
              style={{ textShadow: "0 0 8px #00FFF7" }}
            >
              <Filter className="h-4 w-4 mr-2" />
              FILTER
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left Column - Inventory */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between">
              <h2
                className="font-mono text-xs font-bold tracking-widest text-white"
                style={{ textShadow: "0 0 10px #00FFF7" }}
              >
                ARTIFACT INVENTORY
              </h2>
              <span className="font-mono text-xs text-cyan-300">{mockArtifacts.length} ITEMS</span>
            </div>

            <div className={cn("grid gap-4", viewMode === "grid" ? "grid-cols-2 md:grid-cols-3" : "grid-cols-1")}>
              {mockArtifacts.map((artifact) => (
                <ArtifactCard
                  key={artifact.id}
                  artifact={artifact}
                  selected={selectedArtifact?.id === artifact.id}
                  onSelect={() => setSelectedArtifact(artifact)}
                />
              ))}
            </div>
          </div>

          {/* Right Column - Controls */}
          <div className="space-y-6">
            <NTRUBalance balance={2450} pendingRewards={125} nextEpoch="3d 14h" />

            <ExchangeConsole
              ntruBalance={2450}
              selectedArtifact={
                selectedArtifact
                  ? {
                      id: selectedArtifact.id,
                      name: selectedArtifact.name,
                      resonance_power: selectedArtifact.resonance_power,
                    }
                  : undefined
              }
            />

            <MutationEpoch
              currentEpoch={7}
              epochName="CRIMSON TIDE"
              timeRemaining="3d 14h 22m"
              mutationChance={35}
              activeArtifacts={mockArtifacts.length}
            />

            <Dynamic404 artifact404Count={artifact404Count} onRecoveryAttempt={() => console.log("Recovery attempt")} />
          </div>
        </div>
      </div>
    </main>
  )
}
