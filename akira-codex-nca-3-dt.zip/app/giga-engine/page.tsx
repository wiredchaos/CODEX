"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  Cpu,
  Zap,
  Database,
  Shield,
  Layers,
  Settings,
  Play,
  Pause,
  RefreshCw,
  ChevronRight,
  Lock,
  Unlock,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { CircuitBackground } from "@/components/circuit-background"
import { GlitchText } from "@/components/glitch-text"
import { Progress } from "@/components/ui/progress"
import { AgenticWelcome } from "@/components/agentic-welcome"

const engineModules = [
  {
    id: "aesthetic",
    name: "AESTHETIC ENGINE",
    description: "Visual identity processor for realm-specific styling",
    status: "ACTIVE",
    power: 92,
    icon: Layers,
    color: "cyan",
  },
  {
    id: "persona",
    name: "PERSONA KERNEL",
    description: "Character behavior and identity matrix",
    status: "ACTIVE",
    power: 88,
    icon: Cpu,
    color: "crimson",
  },
  {
    id: "dialogue",
    name: "DIALOGUE MATRIX",
    description: "Narrative response and conversation engine",
    status: "STANDBY",
    power: 75,
    icon: Database,
    color: "gold",
  },
  {
    id: "motion",
    name: "MOTION ENGINE",
    description: "Animation and kinetic response system",
    status: "ACTIVE",
    power: 95,
    icon: Zap,
    color: "cyan",
  },
  {
    id: "audio",
    name: "AUDIO HARMONICS",
    description: "Sound design and frequency modulation",
    status: "ACTIVE",
    power: 82,
    icon: Settings,
    color: "crimson",
  },
  {
    id: "lore",
    name: "LORE ANCHOR",
    description: "Mythos database and narrative continuity",
    status: "SYNCING",
    power: 67,
    icon: Database,
    color: "gold",
  },
  {
    id: "ux",
    name: "UX INTEGRATION",
    description: "User experience flow controller",
    status: "ACTIVE",
    power: 90,
    icon: Layers,
    color: "cyan",
  },
  {
    id: "ip",
    name: "IP PROTECTION",
    description: "Intellectual property security shell",
    status: "LOCKED",
    power: 100,
    icon: Shield,
    color: "crimson",
  },
]

const contentGenerators = [
  {
    id: "story",
    name: "STORY WEAVER",
    description: "Generate narrative content with Akira Codex lore",
    outputs: ["Mini-Novellas", "Character Arcs", "World Building"],
  },
  {
    id: "visual",
    name: "VISUAL FORGE",
    description: "Create realm-specific imagery and assets",
    outputs: ["NFT Art", "Scene Compositions", "UI Elements"],
  },
  {
    id: "audio",
    name: "SONIC ARCHITECT",
    description: "Compose frequency-aligned soundscapes",
    outputs: ["33.3 FM Tracks", "Ambient Loops", "Effect Libraries"],
  },
  {
    id: "code",
    name: "CODE SYNTHESIZER",
    description: "Generate production-ready implementations",
    outputs: ["Components", "Smart Contracts", "API Routes"],
  },
]

export default function GigaEnginePage() {
  const [selectedModule, setSelectedModule] = useState<string | null>("aesthetic")
  const [isRunning, setIsRunning] = useState(true)

  const colorMap = {
    cyan: {
      text: "text-cyan-400",
      bg: "bg-cyan-500/20",
      border: "border-cyan-500/50",
      glow: "shadow-[0_0_20px_rgba(0,255,247,0.4)]",
      textShadow: "0 0 15px #00FFF7",
    },
    crimson: {
      text: "text-red-500",
      bg: "bg-red-500/20",
      border: "border-red-500/50",
      glow: "shadow-[0_0_20px_rgba(255,26,26,0.4)]",
      textShadow: "0 0 15px #FF1A1A",
    },
    gold: {
      text: "text-amber-400",
      bg: "bg-amber-500/20",
      border: "border-amber-500/50",
      glow: "shadow-[0_0_20px_rgba(245,158,11,0.4)]",
      textShadow: "0 0 15px #F59E0B",
    },
  }

  return (
    <main className="relative min-h-screen bg-black text-white">
      <CircuitBackground />
      <AgenticWelcome pageName="GIGA ENGINE PACK" />

      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-zinc-800 bg-black/80 backdrop-blur-md">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon" className="text-white hover:text-red-500">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <GlitchText
                text="GIGA ENGINE PACK"
                as="h1"
                className="font-mono text-lg font-bold tracking-widest"
                glow={true}
                glowColor="gold"
              />
              <p className="text-[10px] font-mono text-amber-300" style={{ textShadow: "0 0 8px #F59E0B" }}>
                NEURAL GUIDE v33.3 CORE SYSTEMS
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsRunning(!isRunning)}
              className={`font-mono text-xs bg-transparent ${isRunning ? "border-green-500 text-green-400" : "border-red-500 text-red-400"}`}
              style={{ textShadow: isRunning ? "0 0 10px #22C55E" : "0 0 10px #FF1A1A" }}
            >
              {isRunning ? <Pause className="h-4 w-4 mr-2" /> : <Play className="h-4 w-4 mr-2" />}
              {isRunning ? "RUNNING" : "PAUSED"}
            </Button>
            <Button variant="ghost" size="icon" className="text-white hover:text-amber-400">
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* System Overview */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          <div
            className="rounded-lg border border-cyan-500/50 bg-black/50 p-4 text-center"
            style={{ boxShadow: "0 0 25px rgba(0,255,247,0.2)" }}
          >
            <p className="text-[10px] font-mono text-cyan-300 mb-1" style={{ textShadow: "0 0 8px #00FFF7" }}>
              TOTAL POWER
            </p>
            <p
              className="font-mono text-2xl font-bold text-cyan-400"
              style={{ textShadow: "0 0 25px #00FFF7, 0 0 50px #00FFF7" }}
            >
              86.1%
            </p>
          </div>
          <div
            className="rounded-lg border border-red-500/50 bg-black/50 p-4 text-center"
            style={{ boxShadow: "0 0 25px rgba(255,26,26,0.2)" }}
          >
            <p className="text-[10px] font-mono text-red-300 mb-1" style={{ textShadow: "0 0 8px #FF1A1A" }}>
              ACTIVE MODULES
            </p>
            <p
              className="font-mono text-2xl font-bold text-red-500"
              style={{ textShadow: "0 0 25px #FF1A1A, 0 0 50px #FF1A1A" }}
            >
              6 / 8
            </p>
          </div>
          <div
            className="rounded-lg border border-amber-500/50 bg-black/50 p-4 text-center"
            style={{ boxShadow: "0 0 25px rgba(245,158,11,0.2)" }}
          >
            <p className="text-[10px] font-mono text-amber-300 mb-1" style={{ textShadow: "0 0 8px #F59E0B" }}>
              CONTENT QUEUE
            </p>
            <p
              className="font-mono text-2xl font-bold text-amber-400"
              style={{ textShadow: "0 0 25px #F59E0B, 0 0 50px #F59E0B" }}
            >
              12
            </p>
          </div>
          <div className="rounded-lg border border-zinc-700 bg-black/50 p-4 text-center">
            <p className="text-[10px] font-mono text-zinc-400 mb-1">UPTIME</p>
            <p className="font-mono text-2xl font-bold text-white" style={{ textShadow: "0 0 15px #FFFFFF" }}>
              789h
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left - Module Grid */}
          <div className="lg:col-span-2">
            <h2
              className="font-mono text-sm font-bold text-white mb-4 flex items-center gap-2"
              style={{ textShadow: "0 0 10px #00FFF7" }}
            >
              <Cpu className="h-4 w-4 text-cyan-400" style={{ filter: "drop-shadow(0 0 8px #00FFF7)" }} />
              ENGINE MODULES
            </h2>
            <div className="grid md:grid-cols-2 gap-4">
              {engineModules.map((module) => {
                const colors = colorMap[module.color as keyof typeof colorMap]
                const Icon = module.icon
                const isSelected = selectedModule === module.id

                return (
                  <button
                    key={module.id}
                    onClick={() => setSelectedModule(module.id)}
                    className={`text-left p-4 rounded-lg border transition-all ${
                      isSelected
                        ? `${colors.border} ${colors.bg} ${colors.glow}`
                        : "border-zinc-800 bg-black/50 hover:border-zinc-700"
                    }`}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div
                        className={`h-10 w-10 rounded ${colors.bg} flex items-center justify-center`}
                        style={{
                          boxShadow: `0 0 15px ${module.color === "cyan" ? "rgba(0,255,247,0.3)" : module.color === "crimson" ? "rgba(255,26,26,0.3)" : "rgba(245,158,11,0.3)"}`,
                        }}
                      >
                        <Icon
                          className={`h-5 w-5 ${colors.text}`}
                          style={{
                            filter: `drop-shadow(0 0 8px ${module.color === "cyan" ? "#00FFF7" : module.color === "crimson" ? "#FF1A1A" : "#F59E0B"})`,
                          }}
                        />
                      </div>
                      <div className="flex items-center gap-2">
                        {module.status === "LOCKED" ? (
                          <Lock className="h-4 w-4 text-zinc-500" />
                        ) : module.status === "ACTIVE" ? (
                          <Unlock
                            className="h-4 w-4 text-green-400"
                            style={{ filter: "drop-shadow(0 0 5px #22C55E)" }}
                          />
                        ) : null}
                        <span
                          className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                            module.status === "ACTIVE"
                              ? "bg-green-500/20 text-green-400"
                              : module.status === "STANDBY"
                                ? "bg-amber-500/20 text-amber-400"
                                : module.status === "SYNCING"
                                  ? "bg-cyan-500/20 text-cyan-400"
                                  : "bg-zinc-700 text-zinc-400"
                          }`}
                          style={{
                            textShadow:
                              module.status === "ACTIVE"
                                ? "0 0 8px #22C55E"
                                : module.status === "STANDBY"
                                  ? "0 0 8px #F59E0B"
                                  : module.status === "SYNCING"
                                    ? "0 0 8px #00FFF7"
                                    : "none",
                          }}
                        >
                          {module.status}
                        </span>
                      </div>
                    </div>
                    <h3
                      className="font-mono text-sm font-bold text-white mb-1"
                      style={{ textShadow: colors.textShadow }}
                    >
                      {module.name}
                    </h3>
                    <p className="text-xs text-zinc-300 mb-3">{module.description}</p>
                    <div className="flex items-center gap-2">
                      <Progress value={module.power} className="h-1.5 flex-1 bg-zinc-800" />
                      <span className={`font-mono text-xs ${colors.text}`} style={{ textShadow: colors.textShadow }}>
                        {module.power}%
                      </span>
                    </div>
                  </button>
                )
              })}
            </div>
          </div>

          {/* Right - Content Generators */}
          <div>
            <h2
              className="font-mono text-sm font-bold text-white mb-4 flex items-center gap-2"
              style={{ textShadow: "0 0 10px #F59E0B" }}
            >
              <Zap className="h-4 w-4 text-amber-400" style={{ filter: "drop-shadow(0 0 8px #F59E0B)" }} />
              CONTENT GENERATORS
            </h2>
            <div className="space-y-4">
              {contentGenerators.map((gen) => (
                <div
                  key={gen.id}
                  className="p-4 rounded-lg border border-zinc-800 bg-black/50 hover:border-amber-500/50 transition-colors cursor-pointer group"
                  style={{ transition: "box-shadow 0.3s" }}
                  onMouseEnter={(e) => (e.currentTarget.style.boxShadow = "0 0 20px rgba(245,158,11,0.2)")}
                  onMouseLeave={(e) => (e.currentTarget.style.boxShadow = "none")}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h3
                      className="font-mono text-sm font-bold text-white group-hover:text-amber-400 transition-colors"
                      style={{ textShadow: "0 0 8px rgba(255,255,255,0.5)" }}
                    >
                      {gen.name}
                    </h3>
                    <ChevronRight className="h-4 w-4 text-zinc-500 group-hover:text-amber-400 transition-colors" />
                  </div>
                  <p className="text-xs text-zinc-300 mb-3">{gen.description}</p>
                  <div className="flex flex-wrap gap-1">
                    {gen.outputs.map((output) => (
                      <span
                        key={output}
                        className="text-[10px] font-mono px-2 py-0.5 rounded bg-zinc-800 text-cyan-300"
                        style={{ textShadow: "0 0 5px #00FFF7" }}
                      >
                        {output}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Quick Actions */}
            <div
              className="mt-6 p-4 rounded-lg border border-amber-500/50 bg-black/50"
              style={{ boxShadow: "0 0 25px rgba(245,158,11,0.15)" }}
            >
              <h3
                className="font-mono text-xs font-bold text-amber-400 mb-3"
                style={{ textShadow: "0 0 10px #F59E0B" }}
              >
                QUICK GENERATE
              </h3>
              <div className="space-y-2">
                <Button className="w-full justify-start font-mono text-xs bg-zinc-900 hover:bg-amber-500/20 text-white border border-zinc-700 hover:border-amber-500/50">
                  <Play className="h-3 w-3 mr-2 text-amber-400" />
                  Generate Mini-Novella
                </Button>
                <Button className="w-full justify-start font-mono text-xs bg-zinc-900 hover:bg-cyan-500/20 text-white border border-zinc-700 hover:border-cyan-500/50">
                  <Play className="h-3 w-3 mr-2 text-cyan-400" />
                  Create NFT Artwork
                </Button>
                <Button className="w-full justify-start font-mono text-xs bg-zinc-900 hover:bg-red-500/20 text-white border border-zinc-700 hover:border-red-500/50">
                  <Play className="h-3 w-3 mr-2 text-red-500" />
                  Compose 33.3 FM Track
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
