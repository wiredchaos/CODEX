"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  Brain,
  Sparkles,
  Users,
  MessageSquare,
  Heart,
  Zap,
  Target,
  TrendingUp,
  Activity,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { CircuitBackground } from "@/components/circuit-background"
import { GlitchText } from "@/components/glitch-text"
import { Slider } from "@/components/ui/slider"

const behaviorTraits = [
  { id: "charisma", name: "CHARISMA", value: 78, icon: Sparkles, color: "gold" },
  { id: "wisdom", name: "WISDOM", value: 92, icon: Brain, color: "cyan" },
  { id: "empathy", name: "EMPATHY", value: 85, icon: Heart, color: "crimson" },
  { id: "focus", name: "FOCUS", value: 67, icon: Target, color: "cyan" },
  { id: "energy", name: "ENERGY", value: 88, icon: Zap, color: "gold" },
  { id: "influence", name: "INFLUENCE", value: 73, icon: TrendingUp, color: "crimson" },
]

const personaModes = [
  {
    id: "guide",
    name: "NEURAL GUIDE",
    description: "Wise mentor archetype - balanced, insightful, patient",
    traits: { wisdom: 95, empathy: 80, charisma: 70 },
    active: true,
  },
  {
    id: "warrior",
    name: "CHAOS WARRIOR",
    description: "Action-oriented archetype - bold, decisive, protective",
    traits: { energy: 95, focus: 85, influence: 90 },
    active: false,
  },
  {
    id: "mystic",
    name: "AKIRA MYSTIC",
    description: "Cryptic seer archetype - mysterious, prophetic, ancient",
    traits: { wisdom: 90, charisma: 60, empathy: 75 },
    active: false,
  },
  {
    id: "trickster",
    name: "NETERU TRICKSTER",
    description: "Playful disruptor archetype - witty, unpredictable, clever",
    traits: { charisma: 95, energy: 88, influence: 70 },
    active: false,
  },
]

const dialogueStyles = [
  { id: "formal", name: "FORMAL", description: "Professional, structured responses" },
  { id: "casual", name: "CASUAL", description: "Relaxed, friendly conversation" },
  { id: "cryptic", name: "CRYPTIC", description: "Mysterious, riddle-like speech" },
  { id: "poetic", name: "POETIC", description: "Lyrical, metaphor-rich language" },
]

const recentInteractions = [
  { id: 1, user: "DeGenSith.eth", type: "DIALOGUE", mood: "curious", timestamp: "2m ago" },
  { id: 2, user: "BlockchainTrapper", type: "EXCHANGE", mood: "excited", timestamp: "15m ago" },
  { id: 3, user: "NeteruSeeker", type: "LORE_QUERY", mood: "reverent", timestamp: "1h ago" },
  { id: 4, user: "ChaosWalker", type: "ARTIFACT_MINT", mood: "triumphant", timestamp: "3h ago" },
]

export default function MetaBrainPage() {
  const [activePersona, setActivePersona] = useState("guide")
  const [dialogueStyle, setDialogueStyle] = useState("formal")
  const [traits, setTraits] = useState(behaviorTraits)

  const updateTrait = (id: string, newValue: number[]) => {
    setTraits(traits.map((t) => (t.id === id ? { ...t, value: newValue[0] } : t)))
  }

  const colorMap = {
    cyan: "text-cyan-400",
    crimson: "text-red-500",
    gold: "text-amber-400",
  }

  return (
    <main className="relative min-h-screen bg-black text-white">
      <CircuitBackground />

      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-zinc-800 bg-black/80 backdrop-blur-md">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon" className="text-white hover:text-red-500">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <GlitchText
                text="META-BRAIN BEHAVIOR"
                as="h1"
                className="font-mono text-lg font-bold tracking-widest"
                glow={true}
                glowColor="cyan"
              />
              <p className="text-[10px] font-mono text-zinc-400">PERSONA & DIALOGUE CONTROL SYSTEM</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded bg-green-500/20 border border-green-500/30">
              <Activity className="h-4 w-4 text-green-400 animate-pulse" />
              <span className="font-mono text-xs text-green-400">BRAIN ONLINE</span>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left Column - Trait Sliders */}
          <div className="lg:col-span-1">
            <h2 className="font-mono text-sm font-bold text-white mb-4 flex items-center gap-2">
              <Brain className="h-4 w-4 text-cyan-400" />
              BEHAVIOR TRAITS
            </h2>
            <div className="space-y-6 p-4 rounded-lg border border-zinc-800 bg-zinc-900/50">
              {traits.map((trait) => {
                const Icon = trait.icon
                return (
                  <div key={trait.id}>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Icon className={`h-4 w-4 ${colorMap[trait.color as keyof typeof colorMap]}`} />
                        <span className="font-mono text-xs text-white">{trait.name}</span>
                      </div>
                      <span
                        className={`font-mono text-sm font-bold ${colorMap[trait.color as keyof typeof colorMap]}`}
                        style={{
                          textShadow:
                            trait.color === "cyan"
                              ? "0 0 10px rgba(6,182,212,0.8)"
                              : trait.color === "crimson"
                                ? "0 0 10px rgba(220,38,38,0.8)"
                                : "0 0 10px rgba(245,158,11,0.8)",
                        }}
                      >
                        {trait.value}%
                      </span>
                    </div>
                    <Slider
                      value={[trait.value]}
                      onValueChange={(v) => updateTrait(trait.id, v)}
                      max={100}
                      step={1}
                      className="w-full"
                    />
                  </div>
                )
              })}
            </div>

            {/* Dialogue Style */}
            <h2 className="font-mono text-sm font-bold text-white mb-4 mt-8 flex items-center gap-2">
              <MessageSquare className="h-4 w-4 text-amber-400" />
              DIALOGUE STYLE
            </h2>
            <div className="grid grid-cols-2 gap-2">
              {dialogueStyles.map((style) => (
                <button
                  key={style.id}
                  onClick={() => setDialogueStyle(style.id)}
                  className={`p-3 rounded-lg border text-left transition-all ${
                    dialogueStyle === style.id
                      ? "border-amber-500/50 bg-amber-500/20 shadow-[0_0_15px_rgba(245,158,11,0.2)]"
                      : "border-zinc-800 bg-zinc-900/50 hover:border-zinc-700"
                  }`}
                >
                  <p className="font-mono text-xs font-bold text-white mb-1">{style.name}</p>
                  <p className="text-[10px] text-zinc-400">{style.description}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Middle Column - Persona Modes */}
          <div className="lg:col-span-1">
            <h2 className="font-mono text-sm font-bold text-white mb-4 flex items-center gap-2">
              <Users className="h-4 w-4 text-red-500" />
              PERSONA MODES
            </h2>
            <div className="space-y-4">
              {personaModes.map((persona) => (
                <button
                  key={persona.id}
                  onClick={() => setActivePersona(persona.id)}
                  className={`w-full p-4 rounded-lg border text-left transition-all ${
                    activePersona === persona.id
                      ? "border-red-500/50 bg-red-500/10 shadow-[0_0_20px_rgba(220,38,38,0.2)]"
                      : "border-zinc-800 bg-zinc-900/50 hover:border-zinc-700"
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-mono text-sm font-bold text-white">{persona.name}</h3>
                    {activePersona === persona.id && (
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-green-500/20 text-green-400">
                        ACTIVE
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-zinc-400 mb-3">{persona.description}</p>
                  <div className="flex gap-4">
                    {Object.entries(persona.traits).map(([key, val]) => (
                      <div key={key} className="text-center">
                        <p className="font-mono text-xs font-bold text-cyan-400">{val}</p>
                        <p className="text-[10px] text-zinc-500 uppercase">{key}</p>
                      </div>
                    ))}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Right Column - Interaction Feed */}
          <div className="lg:col-span-1">
            <h2 className="font-mono text-sm font-bold text-white mb-4 flex items-center gap-2">
              <Activity className="h-4 w-4 text-green-400" />
              RECENT INTERACTIONS
            </h2>
            <div className="space-y-3 p-4 rounded-lg border border-zinc-800 bg-zinc-900/50">
              {recentInteractions.map((interaction) => (
                <div
                  key={interaction.id}
                  className="flex items-center justify-between p-3 rounded bg-zinc-800/50 border border-zinc-700"
                >
                  <div>
                    <p className="font-mono text-xs text-white">{interaction.user}</p>
                    <p className="text-[10px] text-zinc-400">
                      {interaction.type} • {interaction.mood}
                    </p>
                  </div>
                  <span className="text-[10px] text-zinc-500">{interaction.timestamp}</span>
                </div>
              ))}
            </div>

            {/* Brain Stats */}
            <div className="mt-6 p-4 rounded-lg border border-cyan-500/30 bg-cyan-500/10">
              <h3 className="font-mono text-xs font-bold text-cyan-400 mb-3">BRAIN STATISTICS</h3>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-zinc-400">Total Conversations</span>
                  <span className="font-mono text-white">12,847</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Avg Response Time</span>
                  <span className="font-mono text-white">1.2s</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Sentiment Score</span>
                  <span className="font-mono text-green-400">+87%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Learning Rate</span>
                  <span className="font-mono text-amber-400">OPTIMAL</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
