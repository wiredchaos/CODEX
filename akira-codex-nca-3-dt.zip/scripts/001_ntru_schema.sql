-- NETERU APINAYA ARTIFACT TERMINAL - DATABASE SCHEMA
-- Core tables for NTRU Token Economy, Artifact Exchange, and 404 Dynamic NFTs

-- Users and Wallet Connections
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_address TEXT UNIQUE NOT NULL,
  username TEXT UNIQUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  last_active TIMESTAMPTZ DEFAULT NOW()
);

-- NTRU Token Balances (In-universe utility token)
CREATE TABLE IF NOT EXISTS ntru_balances (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  balance DECIMAL(18, 6) DEFAULT 0 NOT NULL,
  lifetime_earned DECIMAL(18, 6) DEFAULT 0 NOT NULL,
  lifetime_spent DECIMAL(18, 6) DEFAULT 0 NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id)
);

-- NFT Collections (Multi-chain support)
CREATE TABLE IF NOT EXISTS nft_collections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  contract_address TEXT NOT NULL,
  chain TEXT NOT NULL, -- XRPL, SOL, ETH, HBAR
  realm TEXT NOT NULL, -- Desert, Neon, Ancestral Tech, Oceana Water
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(contract_address, chain)
);

-- User NFT Inventory
CREATE TABLE IF NOT EXISTS user_nfts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  collection_id UUID REFERENCES nft_collections(id) ON DELETE CASCADE,
  token_id TEXT NOT NULL,
  metadata JSONB,
  acquired_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, collection_id, token_id)
);

-- 404 Dynamic NFTs (Timeline Distortion States)
CREATE TABLE IF NOT EXISTS dynamic_404_nfts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nft_id UUID REFERENCES user_nfts(id) ON DELETE CASCADE,
  current_state TEXT DEFAULT 'SYNCED', -- SYNCED, DESYNCED, CORRUPTED, EVOLVED
  desync_count INTEGER DEFAULT 0,
  last_mutation_epoch INTEGER DEFAULT 0,
  mutation_history JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(nft_id)
);

-- Artifact Exchange History
CREATE TABLE IF NOT EXISTS exchange_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  exchange_type TEXT NOT NULL, -- BASIC, NTRU_FUELED
  input_nft_id UUID REFERENCES user_nfts(id),
  output_nft_id UUID REFERENCES user_nfts(id),
  ntru_cost DECIMAL(18, 6) DEFAULT 0,
  result_quality TEXT, -- COMMON, RARE, EPIC, LEGENDARY
  timestamp TIMESTAMPTZ DEFAULT NOW()
);

-- Weekly Mutation Epochs
CREATE TABLE IF NOT EXISTS mutation_epochs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  epoch_number INTEGER UNIQUE NOT NULL,
  start_date TIMESTAMPTZ NOT NULL,
  end_date TIMESTAMPTZ NOT NULL,
  chapter_theme TEXT,
  mutation_rules JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Echo Engineer Advanced Controls
CREATE TABLE IF NOT EXISTS echo_engineer_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  is_power_user BOOLEAN DEFAULT FALSE,
  advanced_features_enabled BOOLEAN DEFAULT FALSE,
  custom_mutation_rules JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id)
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_users_wallet ON users(wallet_address);
CREATE INDEX IF NOT EXISTS idx_ntru_balances_user ON ntru_balances(user_id);
CREATE INDEX IF NOT EXISTS idx_user_nfts_user ON user_nfts(user_id);
CREATE INDEX IF NOT EXISTS idx_user_nfts_collection ON user_nfts(collection_id);
CREATE INDEX IF NOT EXISTS idx_dynamic_404_nft ON dynamic_404_nfts(nft_id);
CREATE INDEX IF NOT EXISTS idx_exchange_history_user ON exchange_history(user_id);
CREATE INDEX IF NOT EXISTS idx_mutation_epochs_number ON mutation_epochs(epoch_number);
