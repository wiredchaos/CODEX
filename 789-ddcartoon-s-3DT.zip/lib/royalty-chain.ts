// 789 Studios OTT - Royalty Chain Reader
// Connects to Dogechain for on-chain royalty data

import type { RoyaltySplit, BlockchainStatus } from "@/types/royalty"

/**
 * Environment configuration for Dogechain
 */
const DOGECHAIN_RPC_URL = process.env.DOGECHAIN_RPC_URL || null
const ROYALTY_ENGINE_ADDRESS = process.env.ROYALTY_ENGINE_ADDRESS || null
const RIGHTS_REGISTRY_ADDRESS = process.env.RIGHTS_REGISTRY_ADDRESS || null
const STUDIO_TOKEN_ADDRESS = process.env.STUDIO_TOKEN_ADDRESS || null
const STAKING_VAULT_ADDRESS = process.env.STAKING_VAULT_ADDRESS || null

/**
 * Basis points to percentage conversion
 */
const BPS_DIVISOR = 10000

/**
 * Convert basis points to normalized percentage (0-1)
 */
export function bpsToPercentage(bps: number): number {
  return bps / BPS_DIVISOR
}

/**
 * Convert percentage to basis points
 */
export function percentageToBps(percentage: number): number {
  return Math.round(percentage * BPS_DIVISOR)
}

/**
 * Get current blockchain status
 */
export function getBlockchainStatus(): BlockchainStatus {
  const hasRpc = !!DOGECHAIN_RPC_URL
  const hasContracts = !!(
    ROYALTY_ENGINE_ADDRESS ||
    RIGHTS_REGISTRY_ADDRESS ||
    STUDIO_TOKEN_ADDRESS ||
    STAKING_VAULT_ADDRESS
  )

  let mode: BlockchainStatus["mode"] = "off-chain"
  if (hasRpc && hasContracts) {
    mode = "hybrid"
  }

  return {
    isConnected: hasRpc,
    network: "Dogechain",
    rpcUrl: DOGECHAIN_RPC_URL,
    contracts: {
      royaltyEngine: ROYALTY_ENGINE_ADDRESS,
      rightsRegistry: RIGHTS_REGISTRY_ADDRESS,
      studioToken: STUDIO_TOKEN_ADDRESS,
      stakingVault: STAKING_VAULT_ADDRESS,
    },
    lastSyncTime: hasRpc ? new Date().toISOString() : null,
    mode,
  }
}

/**
 * Check if chain integration is available
 */
export function isChainAvailable(): boolean {
  return !!DOGECHAIN_RPC_URL && !!ROYALTY_ENGINE_ADDRESS
}

/**
 * Fetch royalty split from on-chain (mock implementation)
 * In production, this would use ethers.js or viem to call the contract
 *
 * @param episodeId - Episode identifier
 * @returns RoyaltySplit or null if not configured on-chain
 */
export async function fetchChainRoyaltySplit(episodeId: string): Promise<RoyaltySplit | null> {
  if (!isChainAvailable()) {
    return null
  }

  // Mock chain response - in production this would be a contract call
  // const contract = new ethers.Contract(ROYALTY_ENGINE_ADDRESS, abi, provider)
  // const split = await contract.getSplit(episodeId)

  console.log(`[RoyaltyChain] Fetching split for episode: ${episodeId}`)

  // Return null to indicate fallback to default split
  // When contracts are deployed, this would return actual chain data
  return null
}

/**
 * Verify IP license on-chain
 */
export async function verifyIPLicense(assetId: string): Promise<boolean> {
  if (!RIGHTS_REGISTRY_ADDRESS) {
    console.log(`[RoyaltyChain] Rights Registry not configured, skipping verification`)
    return true // Default to allowed in off-chain mode
  }

  // Mock verification - in production this would query the Rights Registry contract
  console.log(`[RoyaltyChain] Verifying license for asset: ${assetId}`)
  return true
}

/**
 * Get staking tier for an address
 */
export async function getStakingTier(address: string): Promise<number> {
  if (!STAKING_VAULT_ADDRESS) {
    return 0 // Default to Viewer tier
  }

  // Mock tier lookup - in production this would call StakingVault.getTier(address)
  console.log(`[RoyaltyChain] Fetching staking tier for: ${address}`)
  return 0
}
