// 789 Studios OTT - Mock Data
// Used for UI testing and TV app approvals

import type { Episode, Studio, IPLicense, StakingInfo } from "@/types/royalty"

/**
 * DD CARTOONS Studio
 */
export const ddCartoonsStudio: Studio = {
  id: "dd-cartoons",
  name: "DD CARTOONS",
  description:
    "Independent animation and IP studio producing original shows, episodes, and characters for 789 Studios OTT. Operating its own royalty logic and licensing with Dogechain integration.",
  logoUrl: "/dd-cartoons-animated-studio-logo-gold.jpg",
  bannerUrl: "/dd-cartoons-animation-studio-banner-colorful-chara.jpg",
  totalEpisodes: 24,
  totalRevenue: 156780,
  createdAt: "2024-01-15",
}

/**
 * Mock Episodes for DD CARTOONS
 */
export const mockEpisodes: Episode[] = [
  {
    id: "ep-001",
    title: "The Great Doge Adventure",
    description: "Follow our heroes as they discover the blockchain realm and learn about digital ownership.",
    thumbnailUrl: "/cartoon-dog-adventure-blockchain-animated.jpg",
    duration: 1320,
    season: 1,
    episode: 1,
    releaseDate: "2024-02-01",
    viewCount: 45230,
    revenueUsd: 12450,
    studioId: "dd-cartoons",
  },
  {
    id: "ep-002",
    title: "NFT Island Escape",
    description: "The gang gets stranded on NFT Island and must collect rare tokens to find their way home.",
    thumbnailUrl: "/tropical-island-cartoon-nft-treasure-animated.jpg",
    duration: 1380,
    season: 1,
    episode: 2,
    releaseDate: "2024-02-08",
    viewCount: 38920,
    revenueUsd: 10890,
    studioId: "dd-cartoons",
  },
  {
    id: "ep-003",
    title: "The Staking Stakes",
    description: "When the treasury runs low, our heroes learn the power of staking and community governance.",
    thumbnailUrl: "/cartoon-characters-staking-coins-vault-animated.jpg",
    duration: 1260,
    season: 1,
    episode: 3,
    releaseDate: "2024-02-15",
    viewCount: 52100,
    revenueUsd: 14320,
    studioId: "dd-cartoons",
  },
  {
    id: "ep-004",
    title: "Royalty Rumble",
    description: "A dispute over creator royalties leads to an epic showdown in the smart contract arena.",
    thumbnailUrl: "/cartoon-battle-arena-golden-coins-animated.jpg",
    duration: 1440,
    season: 1,
    episode: 4,
    releaseDate: "2024-02-22",
    viewCount: 61500,
    revenueUsd: 18900,
    studioId: "dd-cartoons",
  },
  {
    id: "ep-005",
    title: "The Doginal Dogs Crossover",
    description: "Special crossover episode featuring the legendary Doginal Dogs NFT collection characters.",
    thumbnailUrl: "/cartoon-dogs-crossover-special-episode-animated-co.jpg",
    duration: 1800,
    season: 1,
    episode: 5,
    releaseDate: "2024-03-01",
    viewCount: 89200,
    revenueUsd: 28750,
    studioId: "dd-cartoons",
  },
  {
    id: "ep-006",
    title: "Wallet Warriors",
    description: "The team must protect their wallets from the notorious Phishing Gang.",
    thumbnailUrl: "/cartoon-warriors-protecting-treasure-digital-anima.jpg",
    duration: 1320,
    season: 1,
    episode: 6,
    releaseDate: "2024-03-08",
    viewCount: 42300,
    revenueUsd: 11200,
    studioId: "dd-cartoons",
  },
]

/**
 * Mock IP Licenses for Rights Registry
 */
export const mockIPLicenses: IPLicense[] = [
  {
    assetId: "char-doge-max",
    assetName: "Doge Max",
    owner: "0x789Studios...abc1",
    licenseType: "Studio",
    uri: "ipfs://QmDogeMax123/metadata.json",
    expiry: null,
    permissionsMask: 0b11111111, // Full permissions
    restrictionsMask: 0b00000000,
    isActive: true,
  },
  {
    assetId: "char-pixel-pup",
    assetName: "Pixel Pup",
    owner: "0x789Studios...abc2",
    licenseType: "Studio",
    uri: "ipfs://QmPixelPup456/metadata.json",
    expiry: null,
    permissionsMask: 0b11111111,
    restrictionsMask: 0b00000000,
    isActive: true,
  },
  {
    assetId: "char-doginal-001",
    assetName: "Doginal Dog #1234",
    owner: "0xCommunity...def1",
    licenseType: "Community",
    uri: "ipfs://QmDoginal1234/metadata.json",
    expiry: "2025-12-31",
    permissionsMask: 0b00001111, // Limited: Streaming, Merch only
    restrictionsMask: 0b11110000, // No commercial ads
    isActive: true,
  },
  {
    assetId: "char-crypto-kitty",
    assetName: "Crypto Kitty Cameo",
    owner: "0xExternal...ghi1",
    licenseType: "Commercial",
    uri: "ipfs://QmCryptoKitty789/metadata.json",
    expiry: "2024-06-30",
    permissionsMask: 0b00000011, // Streaming only
    restrictionsMask: 0b11111100,
    isActive: false, // Expired
  },
  {
    assetId: "char-block-bear",
    assetName: "Block Bear",
    owner: "0x789Studios...abc3",
    licenseType: "Studio",
    uri: "ipfs://QmBlockBear321/metadata.json",
    expiry: null,
    permissionsMask: 0b11111111,
    restrictionsMask: 0b00000000,
    isActive: true,
  },
]

/**
 * Mock Staking Info
 */
export const mockStakingUsers: StakingInfo[] = [
  {
    address: "0xUser...viewer1",
    stakedAmount: 0,
    tier: "Viewer",
    tierIndex: 0,
    lockPeriodDays: 0,
    unlockDate: null,
  },
  {
    address: "0xUser...member1",
    stakedAmount: 5000,
    tier: "Member",
    tierIndex: 1,
    lockPeriodDays: 30,
    unlockDate: "2024-04-15",
  },
  {
    address: "0xUser...premium1",
    stakedAmount: 25000,
    tier: "Premium",
    tierIndex: 2,
    lockPeriodDays: 60,
    unlockDate: "2024-05-01",
  },
  {
    address: "0xUser...exec1",
    stakedAmount: 100000,
    tier: "Executive",
    tierIndex: 3,
    lockPeriodDays: 90,
    unlockDate: "2024-06-15",
  },
]

/**
 * Get episode by ID
 */
export function getEpisodeById(episodeId: string): Episode | null {
  return mockEpisodes.find((ep) => ep.id === episodeId) || null
}

/**
 * Get all episodes for a studio
 */
export function getEpisodesByStudio(studioId: string): Episode[] {
  return mockEpisodes.filter((ep) => ep.studioId === studioId)
}

/**
 * Get license by asset ID
 */
export function getLicenseByAssetId(assetId: string): IPLicense | null {
  return mockIPLicenses.find((lic) => lic.assetId === assetId) || null
}

/**
 * Get all active licenses
 */
export function getActiveLicenses(): IPLicense[] {
  return mockIPLicenses.filter((lic) => lic.isActive)
}
