// Creator Codex - Bot Management Utilities
// Handles NPC URL generation and bot operations

import type { CreatorCodexBot, CreateBotInput, BotPersona } from "@/types/creator-codex"

const NPC_BASE_URL = "https://npc.hyperfy.ai"

/**
 * Build the NPC launch URL with bot metadata
 */
export function buildNpcLaunchUrl(bot: CreatorCodexBot): string {
  const params = new URLSearchParams({
    botId: bot.id,
    name: bot.name,
    persona: bot.persona,
    studio: bot.studioId,
  })

  if (bot.avatarImageUrl) {
    params.set("avatar", bot.avatarImageUrl)
  }

  if (bot.accentColor) {
    params.set("accent", bot.accentColor)
  }

  return `${NPC_BASE_URL}?${params.toString()}`
}

/**
 * Generate a URL-safe slug from bot name
 */
export function generateSlug(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
}

/**
 * Create a new bot with defaults
 */
export function createBot(input: CreateBotInput, studioId: string, ownerWallet: string): CreatorCodexBot {
  const id = `bot-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`
  const now = new Date().toISOString()

  const bot: CreatorCodexBot = {
    id,
    slug: input.slug || generateSlug(input.name),
    name: input.name,
    description: input.description || "",
    persona: input.persona,
    status: "draft",
    studioId,
    ownerWallet,
    avatarImageUrl: input.avatarImageUrl,
    accentColor: input.accentColor || "#DAA520", // Gold default
    npcWorldUrl: NPC_BASE_URL,
    npcLaunchUrl: "", // Set after creation
    attachedShows: input.attachedShows || [],
    revShareBps: input.revShareBps ?? 2000, // Default 20%
    isActive: true,
    createdAt: now,
    updatedAt: now,
  }

  // Generate launch URL with bot data
  bot.npcLaunchUrl = buildNpcLaunchUrl(bot)

  return bot
}

/**
 * Get persona badge color class
 */
export function getPersonaColor(persona: BotPersona): string {
  const colors: Record<BotPersona, string> = {
    HOST: "bg-amber-500/20 text-amber-400 border-amber-500/30",
    GUIDE: "bg-blue-500/20 text-blue-400 border-blue-500/30",
    TEACHER: "bg-green-500/20 text-green-400 border-green-500/30",
    CONCIERGE: "bg-purple-500/20 text-purple-400 border-purple-500/30",
    NPC_STORY: "bg-pink-500/20 text-pink-400 border-pink-500/30",
    SUPPORT: "bg-cyan-500/20 text-cyan-400 border-cyan-500/30",
  }
  return colors[persona]
}

/**
 * Calculate revenue share from BPS
 */
export function bpsToPercent(bps: number): number {
  return bps / 100
}

/**
 * Format BPS as percentage string
 */
export function formatBps(bps: number): string {
  return `${(bps / 100).toFixed(1)}%`
}
