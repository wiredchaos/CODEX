// 789 Studios OTT - Royalty Engine (Off-chain)
// Implements the 40/20/20/10/10 split model

import type { RoyaltySplit, RoyaltyAmounts, EpisodeRoyaltyMeta } from "@/types/royalty"
import { getEpisodeById } from "./mock-data"

/**
 * Default royalty split percentages
 * 40% Studio | 20% Creator | 20% NFT Holder | 10% Treasury | 10% Stakers
 */
export const DEFAULT_SPLIT: RoyaltySplit = {
  studio: 0.4,
  creator: 0.2,
  nftHolder: 0.2,
  treasury: 0.1,
  stakers: 0.1,
}

/**
 * Internal helper to calculate amounts from split
 */
function calculateSplit(totalRevenueUsd: number, split: RoyaltySplit): RoyaltyAmounts {
  return {
    studioAmount: totalRevenueUsd * split.studio,
    creatorAmount: totalRevenueUsd * split.creator,
    nftHolderAmount: totalRevenueUsd * split.nftHolder,
    treasuryAmount: totalRevenueUsd * split.treasury,
    stakersAmount: totalRevenueUsd * split.stakers,
    totalAmount: totalRevenueUsd,
  }
}

/**
 * Calculate royalty split for a given revenue amount
 * Uses the standard 40/20/20/10/10 model
 *
 * @param totalRevenueUsd - Total revenue in USD
 * @param customSplit - Optional custom split (defaults to 40/20/20/10/10)
 * @returns RoyaltyAmounts with computed dollar values
 */
export function calculateRoyaltySplit(totalRevenueUsd: number, customSplit?: Partial<RoyaltySplit>): RoyaltyAmounts {
  const split: RoyaltySplit = {
    ...DEFAULT_SPLIT,
    ...customSplit,
  }

  // Validate split totals to 100%
  const total = split.studio + split.creator + split.nftHolder + split.treasury + split.stakers
  if (Math.abs(total - 1) > 0.001) {
    console.warn(`[RoyaltyEngine] Split does not total 100%: ${(total * 100).toFixed(2)}%`)
  }

  return calculateSplit(totalRevenueUsd, split)
}

/**
 * Get full royalty metadata for an episode
 * Combines episode data with royalty calculations
 *
 * @param episodeId - Episode identifier
 * @param customSplit - Optional custom split override
 * @returns EpisodeRoyaltyMeta or null if episode not found
 */
export function getEpisodeRoyaltyMeta(
  episodeId: string,
  customSplit?: Partial<RoyaltySplit>,
): EpisodeRoyaltyMeta | null {
  const episode = getEpisodeById(episodeId)

  if (!episode) {
    return null
  }

  const split: RoyaltySplit = {
    ...DEFAULT_SPLIT,
    ...customSplit,
  }

  const amounts = calculateRoyaltySplit(episode.revenueUsd, split)

  return {
    episodeId: episode.id,
    episodeTitle: episode.title,
    totalRevenueUsd: episode.revenueUsd,
    split,
    amounts,
    lastUpdated: new Date().toISOString(),
    source: "mock",
  }
}

/**
 * Calculate aggregate royalties for multiple episodes
 */
export function calculateAggregateRoyalties(
  episodes: { revenueUsd: number }[],
  customSplit?: Partial<RoyaltySplit>,
): RoyaltyAmounts {
  const totalRevenue = episodes.reduce((sum, ep) => sum + ep.revenueUsd, 0)
  return calculateRoyaltySplit(totalRevenue, customSplit)
}

/**
 * Format currency for display
 */
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount)
}

/**
 * Format percentage for display
 */
export function formatPercentage(value: number): string {
  return `${(value * 100).toFixed(0)}%`
}
