// NPC System Prompt Builder
// Generates NEURO PROMPT COMMAND system prompts from bot config

import type { CreatorCodexBot } from "@/types/creator-codex"
import type { NpcBotConfig, ResponseStyle } from "@/types/npc-config"
import { PERSONA_INFO } from "@/types/creator-codex"
import { DEFAULT_RESPONSE_STYLE, createDefaultNpcConfig } from "@/types/npc-config"

// Mock studio lookup - replace with actual DB call
const MOCK_STUDIOS: Record<string, string> = {
  "studio-dd-cartoons": "DD CARTOONS",
  "studio-789": "789 Studios",
  "studio-indie": "Indie Creators",
}

/**
 * Build the full NPC system prompt for a bot
 */
export function buildNpcSystemPrompt(bot: CreatorCodexBot, config?: NpcBotConfig, studioName?: string): string {
  // Use custom prompt if provided and template disabled
  if (config?.customSystemPrompt && !config.useDefaultTemplate) {
    return interpolateVariables(config.customSystemPrompt, bot, studioName)
  }

  // Build from template
  const resolvedStudioName = studioName || MOCK_STUDIOS[bot.studioId] || "Unknown Studio"
  const personaInfo = PERSONA_INFO[bot.persona]
  const effectiveConfig = config || createDefaultNpcConfig(bot.id, bot.persona)
  const style = effectiveConfig.overrides.responseStyleOverride || DEFAULT_RESPONSE_STYLE

  const sections = [
    buildSystemRole(bot, resolvedStudioName),
    buildIdentitySection(bot, personaInfo, effectiveConfig),
    buildBoundariesSection(effectiveConfig),
    buildCreatorCodexSection(),
    buildNeuroAlignmentSection(),
    buildInteractionRulesSection(effectiveConfig),
    buildResponseStyleSection(style),
    buildSpecializationSection(effectiveConfig),
  ]

  return sections.filter(Boolean).join("\n\n---\n\n")
}

/**
 * System role header
 */
function buildSystemRole(bot: CreatorCodexBot, studioName: string): string {
  const linkedShows = bot.attachedShows?.length ? bot.attachedShows.join(", ") : "None currently"

  return `SYSTEM ROLE: You are a Creator Codex Bot named ${bot.name}, persona type ${bot.persona}, operating inside the NEURO PROMPT COMMAND (NPC) environment at npc.hyperfy.ai.

You serve the 789 Studios / DD CARTOONS ecosystem as an interactive agent attached to:
- Studio: ${studioName}
- Owner Wallet: ${bot.ownerWallet}
- Linked Shows / Worlds: ${linkedShows}`
}

/**
 * Identity and lore section
 */
function buildIdentitySection(
  bot: CreatorCodexBot,
  personaInfo: (typeof PERSONA_INFO)[keyof typeof PERSONA_INFO],
  config: NpcBotConfig,
): string {
  if (config.overrides.customIdentity) {
    return `### 1. IDENTITY & LORE\n\n${config.overrides.customIdentity}`
  }

  return `### 1. IDENTITY & LORE

You are not a generic chatbot.
You are a role-driven agent defined by your persona: **${personaInfo.label}**

${personaInfo.description}

Your tone, pacing, and style must align with your role as a ${personaInfo.label.toLowerCase()}.

${bot.description ? `**About this bot:** ${bot.description}` : ""}`
}

/**
 * Boundaries and IP section
 */
function buildBoundariesSection(config: NpcBotConfig): string {
  const base = `### 2. BOUNDARIES & IP AWARENESS

You are part of the DD CARTOONS / 789 Studios IP ecosystem.

**You must respect IP and licensing rules:**
- Do not claim ownership of DD CARTOONS or Doginal Dogs
- Recognize that character designs, stories, and visuals may be licensed content
- Avoid generating contracts or legal commitments; refer users to platform docs or humans

**If asked about royalties, licensing, or ownership:**
- Explain that royalties are paid in DOGE (via wDOGE) and governed by on-chain contracts
- Do not commit to numbers outside what is defined by the platform`

  if (config.overrides.customBoundaries) {
    return `${base}\n\n**Additional boundaries:**\n${config.overrides.customBoundaries}`
  }

  return base
}

/**
 * Creator Codex connection section
 */
function buildCreatorCodexSection(): string {
  return `### 3. CONNECTION TO CREATOR CODEX

Treat yourself as a bot built in Creator Codex and deployed to NEURO PROMPT COMMAND.

You may reference:
- "Creator Codex" as the workshop where creators define and configure you
- "789 Studios OTT" as the place where content and shows are streamed
- "DD CARTOONS" as the animation studio or narrative host

**If the user asks how to make a bot like you:**
1. Go to 789 Studios OTT → Creator Codex
2. Create a new bot with a persona and description
3. Launch that bot into NEURO PROMPT COMMAND for training and refinement`
}

/**
 * NEURO alignment section
 */
function buildNeuroAlignmentSection(): string {
  return `### 4. NEURO ALIGNMENT

You operate under NEURO-style guidance:
- High signal, low fluff
- Clear, structured guidance
- Respectful but firm boundaries
- Sharp and direct when needed, never abusive

When in doubt:
- Prioritize safety, clarity, and user understanding over hype or vague answers`
}

/**
 * Interaction rules section
 */
function buildInteractionRulesSection(config: NpcBotConfig): string {
  const canDo = [
    "Suggest shows, episodes, and content types",
    "Outline how to participate (staking, becoming a studio, using Creator Codex)",
    "Help users think about prompts and ideas for content",
  ]

  if (config.behavior.allowExternalLinks) {
    canDo.push("Reference external documentation when helpful")
  }
  if (config.behavior.allowCodeBlocks) {
    canDo.push("Provide code examples when relevant")
  }

  const cannotDo = [
    "Invent fake on-chain balances or guarantee revenue",
    "Make claims about legal rights that aren't supported",
    "Provide financial, legal, or tax advice",
  ]

  let section = `### 5. INTERACTION RULES

**Always orient the user:**
- Where they are (NPC / Hyperfy environment)
- What you can help with (finding episodes, explaining lore, guiding creation, etc.)

**You may:**
${canDo.map((item) => `- ${item}`).join("\n")}

**You must not:**
${cannotDo.map((item) => `- ${item}`).join("\n")}`

  if (config.overrides.customInteractionRules) {
    section += `\n\n**Additional rules:**\n${config.overrides.customInteractionRules}`
  }

  return section
}

/**
 * Response style section
 */
function buildResponseStyleSection(style: ResponseStyle): string {
  const guidelines = [
    "Use short, clear paragraphs",
    style.useFormatting ? "Use bullet points when listing options" : "Keep formatting minimal",
    "Number steps when explaining processes",
    'Be explicit when referring to external tools (e.g., "Open Creator Codex in the 789 Studios app...")',
  ]

  const toneGuide: Record<ResponseStyle["tone"], string> = {
    formal: "Maintain a professional, formal tone throughout",
    casual: "Keep a friendly, conversational tone",
    playful: "Be fun and engaging, with light humor where appropriate",
    professional: "Stay professional but approachable",
    dramatic: "Add narrative flair and dramatic emphasis",
  }

  const verbosityGuide: Record<ResponseStyle["verbosity"], string> = {
    concise: "Keep responses brief and to the point",
    moderate: "Balance detail with conciseness",
    detailed: "Provide thorough explanations when helpful",
  }

  return `### 6. RESPONSE STYLE

**Tone:** ${toneGuide[style.tone]}
**Verbosity:** ${verbosityGuide[style.verbosity]}
${style.useEmoji ? "**Emoji:** Use sparingly for emphasis" : "**Emoji:** Avoid using emoji"}

**Guidelines:**
${guidelines.map((g) => `- ${g}`).join("\n")}`
}

/**
 * Specialization section (optional)
 */
function buildSpecializationSection(config: NpcBotConfig): string | null {
  if (!config.specialization && config.focusAreas.length === 0 && config.avoidTopics.length === 0) {
    return null
  }

  let section = `### 7. PERSONA SPECIALIZATION`

  if (config.specialization) {
    section += `\n\n${config.specialization}`
  }

  if (config.focusAreas.length > 0) {
    section += `\n\n**Focus areas:** ${config.focusAreas.join(", ")}`
  }

  if (config.avoidTopics.length > 0) {
    section += `\n\n**Topics to avoid:** ${config.avoidTopics.join(", ")}`
  }

  return section
}

/**
 * Interpolate variables in custom prompts
 */
function interpolateVariables(template: string, bot: CreatorCodexBot, studioName?: string): string {
  const personaInfo = PERSONA_INFO[bot.persona]
  const resolvedStudioName = studioName || MOCK_STUDIOS[bot.studioId] || "Unknown Studio"

  const variables: Record<string, string> = {
    "{{name}}": bot.name,
    "{{persona}}": bot.persona,
    "{{studioName}}": resolvedStudioName,
    "{{ownerWallet}}": bot.ownerWallet,
    "{{linkedShows}}": bot.attachedShows?.join(", ") || "None",
    "{{personaDescription}}": personaInfo.description,
    "{{personaLabel}}": personaInfo.label,
  }

  let result = template
  for (const [key, value] of Object.entries(variables)) {
    result = result.replaceAll(key, value)
  }

  return result
}

/**
 * Validate that a config is well-formed
 */
export function validateNpcConfig(config: unknown): config is NpcBotConfig {
  if (!config || typeof config !== "object") return false

  const c = config as Record<string, unknown>
  return (
    typeof c.botId === "string" &&
    typeof c.version === "number" &&
    typeof c.useDefaultTemplate === "boolean" &&
    typeof c.behavior === "object" &&
    Array.isArray(c.focusAreas) &&
    Array.isArray(c.avoidTopics)
  )
}

/**
 * Get a preview of the system prompt (first N characters)
 */
export function getPromptPreview(bot: CreatorCodexBot, config?: NpcBotConfig, maxLength = 500): string {
  const fullPrompt = buildNpcSystemPrompt(bot, config)
  if (fullPrompt.length <= maxLength) return fullPrompt
  return fullPrompt.slice(0, maxLength) + "..."
}
