// 789 Studios OTT - Shared Styles
// TV-friendly styling utilities

/**
 * Glow styles for blockchain/royalty UI elements
 */
export const glowStyles = {
  gold: "shadow-[0_0_20px_rgba(218,165,32,0.3),0_0_40px_rgba(218,165,32,0.1)]",
  success: "shadow-[0_0_20px_rgba(34,197,94,0.3),0_0_40px_rgba(34,197,94,0.1)]",
  amber: "shadow-[0_0_20px_rgba(245,158,11,0.3),0_0_40px_rgba(245,158,11,0.1)]",
  chain: "shadow-[0_0_15px_rgba(34,197,94,0.4)]",
  inactive: "shadow-[0_0_10px_rgba(107,114,128,0.2)]",
}

/**
 * TV-friendly button sizes (large touch targets)
 */
export const tvButtonStyles = {
  base: "min-h-[48px] min-w-[120px] px-6 py-3 text-lg font-medium rounded-lg transition-all duration-200",
  focus: "focus:ring-4 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background focus:outline-none",
  hover: "hover:scale-105 hover:brightness-110",
}

/**
 * Card styles for content tiles
 */
export const cardStyles = {
  base: "bg-card border border-border rounded-xl overflow-hidden transition-all duration-300",
  hover: "hover:border-primary/50 hover:shadow-lg",
  focus: "focus-within:ring-2 focus-within:ring-primary focus-within:ring-offset-2",
}

/**
 * Tier badge colors
 */
export const tierColors = {
  Viewer: "bg-muted text-muted-foreground",
  Member: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  Premium: "bg-purple-500/20 text-purple-400 border-purple-500/30",
  Executive: "bg-primary/20 text-primary border-primary/30",
}

/**
 * License type colors
 */
export const licenseColors = {
  Studio: "bg-primary/20 text-primary",
  Community: "bg-blue-500/20 text-blue-400",
  Commercial: "bg-green-500/20 text-green-400",
}
