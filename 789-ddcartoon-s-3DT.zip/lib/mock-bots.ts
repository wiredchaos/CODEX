// Mock Creator Codex Bot Data
// For UI testing and TV app approvals

import type { CreatorCodexBot, BotStats } from "@/types/creator-codex"
import { buildNpcLaunchUrl } from "./creator-codex"

/**
 * Mock bots for DD CARTOONS studio
 */
export const mockBots: CreatorCodexBot[] = [
  {
    id: "bot-doge-host",
    slug: "doge-host",
    name: "Doge Max Host",
    description: "The charismatic host of DD CARTOONS, guiding viewers through episodes and behind-the-scenes content.",
    persona: "HOST",
    status: "active",
    studioId: "dd-cartoons",
    ownerWallet: "0x789Studios...abc1",
    avatarImageUrl: "/cartoon-dog-host-character-gold.jpg",
    accentColor: "#DAA520",
    npcWorldUrl: "https://npc.hyperfy.ai",
    npcLaunchUrl: "",
    attachedShows: ["ep-001", "ep-002", "ep-003"],
    ipAssetId: "char-doge-max",
    revShareBps: 2000,
    isActive: true,
    createdAt: "2024-02-01T10:00:00Z",
    updatedAt: "2024-03-15T14:30:00Z",
  },
  {
    id: "bot-pixel-guide",
    slug: "pixel-guide",
    name: "Pixel Pup Guide",
    description: "An interactive guide helping new viewers navigate the 789 Studios ecosystem and discover content.",
    persona: "GUIDE",
    status: "active",
    studioId: "dd-cartoons",
    ownerWallet: "0x789Studios...abc2",
    avatarImageUrl: "/cute-pixel-art-puppy-character-blue.jpg",
    accentColor: "#3B82F6",
    npcWorldUrl: "https://npc.hyperfy.ai",
    npcLaunchUrl: "",
    attachedShows: [],
    ipAssetId: "char-pixel-pup",
    revShareBps: 1500,
    isActive: true,
    createdAt: "2024-02-10T12:00:00Z",
    updatedAt: "2024-03-10T09:15:00Z",
  },
  {
    id: "bot-block-teacher",
    slug: "block-teacher",
    name: "Professor Block Bear",
    description: "Educational bot teaching viewers about blockchain, NFTs, and the economics of creator royalties.",
    persona: "TEACHER",
    status: "active",
    studioId: "dd-cartoons",
    ownerWallet: "0x789Studios...abc3",
    avatarImageUrl: "/cartoon-bear-professor-glasses-green.jpg",
    accentColor: "#22C55E",
    npcWorldUrl: "https://npc.hyperfy.ai",
    npcLaunchUrl: "",
    attachedShows: ["ep-003", "ep-004"],
    ipAssetId: "char-block-bear",
    revShareBps: 2500,
    isActive: true,
    createdAt: "2024-02-15T08:00:00Z",
    updatedAt: "2024-03-12T16:45:00Z",
  },
  {
    id: "bot-story-npc",
    slug: "shadow-villain",
    name: "The Shadow Trader",
    description:
      "A mysterious antagonist NPC from the Doginal Dogs Crossover, now available for interactive story experiences.",
    persona: "NPC_STORY",
    status: "training",
    studioId: "dd-cartoons",
    ownerWallet: "0x789Studios...abc1",
    avatarImageUrl: "/mysterious-shadow-character-villain-purple.jpg",
    accentColor: "#A855F7",
    npcWorldUrl: "https://npc.hyperfy.ai",
    npcLaunchUrl: "",
    attachedShows: ["ep-005"],
    revShareBps: 1000,
    isActive: false,
    createdAt: "2024-03-01T14:00:00Z",
    updatedAt: "2024-03-01T14:00:00Z",
  },
  {
    id: "bot-support-agent",
    slug: "help-pup",
    name: "Help Pup",
    description:
      "24/7 support agent helping viewers with technical issues, account questions, and platform navigation.",
    persona: "SUPPORT",
    status: "active",
    studioId: "dd-cartoons",
    ownerWallet: "0x789Studios...abc2",
    avatarImageUrl: "/friendly-support-dog-character-headset-cyan.jpg",
    accentColor: "#06B6D4",
    npcWorldUrl: "https://npc.hyperfy.ai",
    npcLaunchUrl: "",
    attachedShows: [],
    revShareBps: 500,
    isActive: true,
    createdAt: "2024-02-20T10:00:00Z",
    updatedAt: "2024-03-14T11:20:00Z",
  },
]

// Generate NPC launch URLs for mock bots
mockBots.forEach((bot) => {
  bot.npcLaunchUrl = buildNpcLaunchUrl(bot)
})

/**
 * Mock bot statistics
 */
export const mockBotStats: BotStats[] = [
  {
    botId: "bot-doge-host",
    totalInteractions: 12450,
    uniqueUsers: 3200,
    revenueGenerated: 4580.5,
    lastActiveAt: "2024-03-15T14:30:00Z",
  },
  {
    botId: "bot-pixel-guide",
    totalInteractions: 8920,
    uniqueUsers: 2100,
    revenueGenerated: 1250.0,
    lastActiveAt: "2024-03-15T12:15:00Z",
  },
  {
    botId: "bot-block-teacher",
    totalInteractions: 5600,
    uniqueUsers: 1800,
    revenueGenerated: 2890.75,
    lastActiveAt: "2024-03-15T10:45:00Z",
  },
  {
    botId: "bot-story-npc",
    totalInteractions: 0,
    uniqueUsers: 0,
    revenueGenerated: 0,
    lastActiveAt: null,
  },
  {
    botId: "bot-support-agent",
    totalInteractions: 15230,
    uniqueUsers: 4500,
    revenueGenerated: 320.25,
    lastActiveAt: "2024-03-15T15:00:00Z",
  },
]

/**
 * Get bot by ID
 */
export function getBotById(botId: string): CreatorCodexBot | null {
  return mockBots.find((bot) => bot.id === botId) || null
}

/**
 * Get bots by studio
 */
export function getBotsByStudio(studioId: string): CreatorCodexBot[] {
  return mockBots.filter((bot) => bot.studioId === studioId)
}

/**
 * Get bot stats by ID
 */
export function getBotStatsById(botId: string): BotStats | null {
  return mockBotStats.find((stats) => stats.botId === botId) || null
}

/**
 * Get active bots only
 */
export function getActiveBots(): CreatorCodexBot[] {
  return mockBots.filter((bot) => bot.isActive && bot.status === "active")
}
