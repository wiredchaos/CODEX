# Creator Codex Patch - Implementation Guide

## Overview

The Creator Codex patch enables bot creation for studios/creators and formally links those bots to **NEURO PROMPT COMMAND** at https://npc.hyperfy.ai as the execution/training environment.

## Architecture Position

```
789 Studios OTT = Viewer / Streaming layer
DD CARTOONS = Animation + IP / Royalty layer
Creator Codex = Bot & content creation studio
NEURO PROMPT COMMAND (NPC) @ npc.hyperfy.ai = 3D prompt + agent training arena
```

## Key Files

### Types
- `types/creator-codex.ts` - Bot blueprint, persona types, stats interfaces

### Library
- `lib/creator-codex.ts` - NPC URL builder, utilities
- `lib/mock-bots.ts` - Sample bot data for testing

### API Routes
- `POST /api/creator-codex/bots` - Create new bot
- `GET /api/creator-codex/bots` - List studio bots
- `GET /api/creator-codex/bots/[botId]` - Get bot detail
- `PATCH /api/creator-codex/bots/[botId]` - Update bot
- `DELETE /api/creator-codex/bots/[botId]` - Delete bot

### Pages
- `/creator-codex` - Hub landing page
- `/creator-codex/bots` - Bot list
- `/creator-codex/bots/new` - Create bot form
- `/creator-codex/bots/[botId]` - Bot detail/management

### Components
- `components/bot-card.tsx` - Bot display card
- `components/bot-create-form.tsx` - Bot creation form

## Bot Personas

| Persona | Label | Use Case |
|---------|-------|----------|
| HOST | Show Host | Presents shows, engages audiences |
| GUIDE | Interactive Guide | Leads users through experiences |
| TEACHER | Teacher | Educational content delivery |
| CONCIERGE | Concierge | Service and recommendations |
| NPC_STORY | Story NPC | Interactive narrative characters |
| SUPPORT | Support Agent | Technical assistance |

## NPC Integration

### URL Construction

```typescript
function buildNpcLaunchUrl(bot: CreatorCodexBot): string {
  const params = new URLSearchParams({
    botId: bot.id,
    name: bot.name,
    persona: bot.persona,
    studio: bot.studioId,
  });
  return `https://npc.hyperfy.ai?${params.toString()}`;
}
```

### NPC-Side Handling (Conceptual)

On load at npc.hyperfy.ai:
1. Inspect URL params: `botId`, `name`, `persona`, `studio`
2. Prefill in-world UI with bot identity
3. Load/create config entry for that bot
4. Tie to NEURO avatars / NEURO PROMPT COMMAND flows

## IP & Royalty Integration

Each bot can participate in revenue:

| Field | Purpose |
|-------|---------|
| `ipAssetId` | References RightsRegistry asset |
| `royaltySplitId` | References RoyaltyEngine split |
| `revShareBps` | Creator percentage (basis points) |

### Revenue Flow

When a bot:
- Hosts a live show
- Runs an interactive lesson
- Acts as primary interface for premium feature

Revenue is allocated via the 40/20/20/10/10 model with bot-specific creator share.

## Quick Start

1. Navigate to `/creator-codex`
2. Click "Create New Bot"
3. Fill in bot details and persona
4. Click "Create Bot"
5. Click "Launch in NEURO PROMPT COMMAND"
6. Train and refine at npc.hyperfy.ai

## Environment Variables

No additional environment variables required for basic functionality.

For production deployment with on-chain bot registration:
- `DOGECHAIN_RPC_URL` - Dogechain RPC endpoint
- `RIGHTS_REGISTRY_ADDRESS` - For IP asset linking
- `ROYALTY_ENGINE_ADDRESS` - For revenue splits

## Next Steps

- [ ] Implement persistent bot storage (database)
- [ ] Add bot analytics dashboard
- [ ] Integrate on-chain bot registration
- [ ] Add NPC webhook for training completion
- [ ] Implement bot versioning
