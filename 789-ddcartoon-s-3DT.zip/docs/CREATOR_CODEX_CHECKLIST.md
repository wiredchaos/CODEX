# Creator Codex Patch – Implementation Checklist

Use this as a quick audit and onboarding reference for any developer touching this subsystem.

---

## A. Types (Domain Model)

**File:** `types/creator-codex.ts`

Verify the following exist and are exported:

- `BotPersona`
- `CreatorCodexBot`
- `CreateBotInput`
- `BotStats`
- `PERSONA_INFO` (metadata for personas: label, description, suggested colors)

### Dev Checks

- [ ] `CreatorCodexBot` includes `npcWorldUrl` and `npcLaunchUrl`
- [ ] `ownerWallet` and `studioId` are present for on-chain + studio linkage
- [ ] Optional fields for IP and royalties exist (`ipAssetId`, `royaltySplitId`, `revShareBps`)

---

## B. Utilities

**File:** `lib/creator-codex.ts`

Confirm these helpers exist and are imported where needed:

| Function | Purpose |
|----------|---------|
| `buildNpcLaunchUrl(bot: CreatorCodexBot): string` | Constructs NPC deep link |
| `createBot(input, studioId, ownerWallet): CreatorCodexBot` | Factory for new bots |
| `getPersonaColor(persona: BotPersona): string` | Tailwind color classes per persona |
| `formatBps(bps: number): string` | e.g., "2000" → "20%" |

### Dev Checks

- [ ] `buildNpcLaunchUrl` constructs a URL to `https://npc.hyperfy.ai` with `botId`, `name`, `persona`, `studio`, etc., as query params
- [ ] `createBot` sets:
  - `npcWorldUrl = "https://npc.hyperfy.ai"`
  - `npcLaunchUrl = buildNpcLaunchUrl(...)`
- [ ] All utilities are tree-shaken and used (no dead code)

---

## C. Components

Key components:

| Component | File |
|-----------|------|
| `BotCard` | `components/bot-card.tsx` |
| `BotCreateForm` | `components/bot-create-form.tsx` |
| `BotStatsPanel` | (optional) |

### Dev Checks

**BotCard:**
- [ ] Displays persona, name, owner, studio
- [ ] Shows "Launch in NEURO PROMPT COMMAND" button using `bot.npcLaunchUrl`
- [ ] Uses `getPersonaColor` to color-code different personas

**BotCreateForm:**
- [ ] Uses `CreateBotInput` as the shape
- [ ] On submit, calls `/api/creator-codex/bots` (POST)
- [ ] On success, shows a "Launch in NPC" link or redirects to bot detail

---

## D. Pages / Routes

| Route | Purpose |
|-------|---------|
| `/creator-codex` | Hub page |
| `/creator-codex/bots` | Bot list |
| `/creator-codex/bots/new` | Create new bot |
| `/creator-codex/bots/[botId]` | Bot detail |

### Dev Checks

- [ ] Hub page explains Creator Codex and links to Bots and New Bot
- [ ] Bots list page loads via `GET /api/creator-codex/bots` and renders `BotCard` grid
- [ ] Create page uses `BotCreateForm` and handles success states
- [ ] Bot detail page shows:
  - Bot metadata
  - NPC launch button
  - Any connected show/episode info
  - Future: IP + Royalty status

---

## E. API Routes

**Files:**
- `app/api/creator-codex/bots/route.ts`
- `app/api/creator-codex/bots/[botId]/route.ts`

| Method | Endpoint | Purpose |
|--------|----------|---------|
| `GET` | `/api/creator-codex/bots` | List for current studio |
| `POST` | `/api/creator-codex/bots` | Create new bot |
| `GET` | `/api/creator-codex/bots/[botId]` | Bot detail |
| `PATCH` | `/api/creator-codex/bots/[botId]` | Update bot |
| `DELETE` | `/api/creator-codex/bots/[botId]` | Soft or hard delete |

### Dev Checks

- [ ] All routes authenticate studio/owner (via wallet/session)
- [ ] `npcLaunchUrl` is computed in lib or API, not hard-coded in components
- [ ] Error responses are clear (401 unauthorized, 404 not found, etc.)

---

## F. Integration with Hybrid System

- [ ] Each `CreatorCodexBot` can optionally reference:
  - `ipAssetId` (on-chain RightsRegistry)
  - `royaltySplitId` (RoyaltyEngine)
- [ ] Dashboard surfaces bot stats:
  - DOGE revenue share (if wired)
  - Interactions
  - Usage metrics

---

## G. NPC System Prompt Integration

- [ ] `NpcBotConfig` type defined in `types/npc-config.ts`
- [ ] `buildNpcSystemPrompt()` utility in `lib/npc-prompts.ts`
- [ ] Each bot can have custom prompt overrides stored in config
- [ ] System prompt template follows NEURO alignment guidelines

---

## Quick Start for New Devs

```bash
# 1. Review types
cat types/creator-codex.ts
cat types/npc-config.ts

# 2. Check utilities
cat lib/creator-codex.ts
cat lib/npc-prompts.ts

# 3. Test API
curl -X GET http://localhost:3000/api/creator-codex/bots

# 4. Create a test bot
curl -X POST http://localhost:3000/api/creator-codex/bots \
  -H "Content-Type: application/json" \
  -d '{"name":"Test Bot","persona":"HOST"}'
```

---

## Related Documentation

- [Developer Onboarding](./DEVELOPER_ONBOARDING.md)
- [Creator Codex Patch Overview](./CREATOR_CODEX_PATCH.md)
- [NPC System Prompt Template](./NPC_SYSTEM_PROMPT.md)
