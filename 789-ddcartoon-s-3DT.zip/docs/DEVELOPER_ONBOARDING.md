# 789 Studios OTT - Developer Onboarding

## Quick Start

Welcome to the 789 Studios OTT platform! This guide walks you through setting up the development environment and understanding the Hybrid Mode architecture.

---

## 1. Project Overview

**789 Studios OTT** is a Smart TV / OTT streaming platform with **DD CARTOONS** as the flagship animation studio.

### Hybrid Mode Architecture

The platform operates in **Hybrid Mode**, combining:
- **Off-chain services** (DB/mock data) for UI and analytics
- **On-chain contracts** (Dogechain) for royalties, staking, and IP licensing

```
┌─────────────────────────────────────────────────────────┐
│                    FRONTEND (Next.js)                   │
├─────────────────────────────────────────────────────────┤
│  Navigation │ Episode Cards │ Royalty HUD │ Status     │
└──────────────────────┬──────────────────────────────────┘
                       │
          ┌────────────┴────────────┐
          ▼                         ▼
┌─────────────────┐       ┌─────────────────┐
│   OFF-CHAIN     │       │    ON-CHAIN     │
│   (lib/*)       │       │   (Dogechain)   │
├─────────────────┤       ├─────────────────┤
│ mock-data.ts    │       │ RoyaltyEngine   │
│ royalty-engine  │  ◄──► │ RightsRegistry  │
│ (calculations)  │       │ StudioToken     │
│                 │       │ StakingVault    │
└─────────────────┘       └─────────────────┘
```

---

## 2. Environment Setup

### Prerequisites
- Node.js 18+
- pnpm or npm
- (Optional) MetaMask or wallet for Dogechain

### Installation

```bash
# Clone and install
git clone <repo-url>
cd 789-studios-ott
pnpm install

# Start development server
pnpm dev
```

### Environment Variables

Create `.env.local` with these variables (all optional for demo mode):

```env
# Dogechain RPC (enables Hybrid Mode)
DOGECHAIN_RPC_URL=https://rpc.dogechain.dog

# Contract Addresses (set after deployment)
ROYALTY_ENGINE_ADDRESS=0x...
RIGHTS_REGISTRY_ADDRESS=0x...
STUDIO_TOKEN_ADDRESS=0x...
STAKING_VAULT_ADDRESS=0x...
```

**Without these variables**: App runs in Demo/Off-Chain Mode using mock data.
**With these variables**: App runs in Hybrid Mode with on-chain verification.

---

## 3. Key Files & Modules

### Types
\`types/royalty.ts\` - Core TypeScript interfaces:
- \`RoyaltySplit\` - Percentage breakdown (0.4, 0.2, etc.)
- \`EpisodeRoyaltyMeta\` - Full royalty data for UI
- \`IPLicense\` - Rights Registry entries
- \`StakingInfo\` - User staking data

### Mock Data
\`lib/mock-data.ts\` - Test fixtures:
- \`mockEpisodes\` - DD CARTOONS episodes
- \`mockIPLicenses\` - Character licenses
- \`mockStakingUsers\` - Staking tier examples

### Royalty Engine (Off-chain)
\`lib/royalty-engine.ts\` - Business logic:
- \`calculateRoyaltySplit(revenue)\` - Computes 40/20/20/10/10 split
- \`getEpisodeRoyaltyMeta(episodeId)\` - Full royalty metadata
- \`formatCurrency()\`, \`formatPercentage()\` - Display helpers

### Chain Reader
\`lib/royalty-chain.ts\` - Dogechain integration:
- \`getBlockchainStatus()\` - Current connection state
- \`fetchChainRoyaltySplit()\` - On-chain split lookup
- \`isChainAvailable()\` - Check if chain is configured

---

## 4. Royalty Model (40/20/20/10/10)

All revenue is split as:

| Recipient | Percentage | Description |
|-----------|------------|-------------|
| DD CARTOONS | 40% | Studio share |
| Creator(s) | 20% | Episode creator |
| NFT Holder | 20% | Licensed character owner |
| Treasury | 10% | Platform reserve |
| Stakers | 10% | $CARTOON token stakers |

This is implemented in:
- **Off-chain**: \`lib/royalty-engine.ts\`
- **On-chain**: \`contracts/RoyaltyEngine.sol\` (BPS-based)

---

## 5. API Routes

### GET /api/royalty/[episodeId]
Returns \`EpisodeRoyaltyMeta\` with computed royalties.

1. Checks if chain is available
2. Fetches on-chain split (if deployed)
3. Falls back to default 40/20/20/10/10
4. Merges with off-chain revenue data

### GET /api/blockchain/status
Returns \`BlockchainStatus\` showing:
- Connection state
- Contract addresses
- Current mode (off-chain/hybrid/on-chain)

---

## 6. Smart Contracts

Located in \`contracts/\` (deploy with Hardhat or Foundry):

### RoyaltyEngine.sol
- ERC-2981 compatible
- Per-episode splits in BPS
- \`setSplit(episodeId, split)\`
- \`getSplit(episodeId)\`
- \`royaltyInfo(episodeId, salePrice)\`

### RightsRegistry.sol
- IP license tracking
- Permission/restriction masks
- \`registerLicense(assetId, data)\`
- \`verifyPermission(assetId, bit)\`

### StudioToken.sol ($CARTOON)
- ERC-20 utility token
- Used for staking and governance

### StakingVault.sol
- Lock periods: 30/60/90 days
- Tiers: Viewer (0) → Executive (3)
- \`stake(amount, lockDays)\`
- \`getTier(address)\`

---

## 7. Deployment Steps

### 1. Deploy Contracts (Dogechain)

```bash
# Using Hardhat
npx hardhat run scripts/deploy.js --network dogechain
```

### 2. Update Environment Variables

Add deployed addresses to Vercel:
- \`ROYALTY_ENGINE_ADDRESS\`
- \`RIGHTS_REGISTRY_ADDRESS\`
- \`STUDIO_TOKEN_ADDRESS\`
- \`STAKING_VAULT_ADDRESS\`

### 3. Configure Initial Splits

```javascript
// scripts/configure-splits.js
const royaltyEngine = await RoyaltyEngine.attach(address)
await royaltyEngine.setSplit("ep-001", {
  studio: 4000,    // 40% in BPS
  creator: 2000,   // 20%
  nftHolder: 2000, // 20%
  treasury: 1000,  // 10%
  stakers: 1000    // 10%
})
```

### 4. Verify Hybrid Mode

Visit \`/blockchain\` to confirm:
- ✅ RPC Connected
- ✅ Contracts show addresses
- ✅ Mode shows "Hybrid Mode"

---

## 8. Testing the Royalty HUD

1. Navigate to any episode or \`/royalties\`
2. Royalty HUD displays:
   - Total revenue (USD)
   - Split percentages
   - Dollar amounts per recipient
   - Source badge (Demo Data / Dogechain)
3. Click refresh to re-fetch data

---

## 9. Troubleshooting

### "Demo Data" badge showing
- Chain environment variables not set
- RPC URL unreachable
- Contract addresses not deployed

### Royalty calculations off
- Check \`DEFAULT_SPLIT\` in \`royalty-engine.ts\`
- Verify on-chain BPS values sum to 10000

### UI not updating
- Check API route responses in Network tab
- Verify \`source\` field in response

---

## 10. Next Steps

- [ ] Deploy contracts to Dogechain testnet
- [ ] Configure RPC and addresses in Vercel
- [ ] Test royalty distribution flow
- [ ] Add wallet connect integration
- [ ] Implement staking UI
- [ ] Set up real episode data from DB

---

**Questions?** Check the \`/blockchain\` page or reach out to the team.
```
