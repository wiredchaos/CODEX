"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2, XCircle, Link2, Wallet, FileCode, Coins, Lock, RefreshCw, AlertCircle } from "lucide-react"
import { glowStyles } from "@/lib/styles"
import type { BlockchainStatus } from "@/types/royalty"

export function BlockchainStatusDashboard() {
  const [status, setStatus] = useState<BlockchainStatus | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchStatus()
  }, [])

  async function fetchStatus() {
    setLoading(true)
    try {
      const res = await fetch("/api/blockchain/status")
      const data = await res.json()
      setStatus(data)
    } catch (err) {
      console.error("Failed to fetch blockchain status:", err)
    } finally {
      setLoading(false)
    }
  }

  if (loading || !status) {
    return (
      <Card className="animate-pulse">
        <CardHeader>
          <div className="h-6 w-48 bg-muted rounded" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-12 bg-muted rounded" />
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  const modeColors = {
    "off-chain": "bg-muted text-muted-foreground",
    hybrid: "bg-primary/20 text-primary border-primary/30",
    "on-chain": "bg-green-500/20 text-green-400 border-green-500/30",
  }

  return (
    <Card className={status.mode === "hybrid" ? glowStyles.gold : ""}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-bold">Blockchain Status</CardTitle>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className={modeColors[status.mode]}>
              {status.mode === "off-chain" && "Off-Chain Mode"}
              {status.mode === "hybrid" && "Hybrid Mode"}
              {status.mode === "on-chain" && "On-Chain Mode"}
            </Badge>
            <button
              onClick={fetchStatus}
              className="p-2 hover:bg-muted rounded-lg transition-colors"
              aria-label="Refresh status"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Network Status */}
        <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
          <div className="flex items-center gap-3">
            <Link2 className={`w-5 h-5 ${status.isConnected ? "text-green-400" : "text-muted-foreground"}`} />
            <div>
              <p className="font-medium">{status.network}</p>
              <p className="text-xs text-muted-foreground">{status.rpcUrl ? "RPC Connected" : "RPC Not Configured"}</p>
            </div>
          </div>
          <StatusIndicator active={status.isConnected} />
        </div>

        {/* Contracts */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            <FileCode className="w-4 h-4" />
            Smart Contracts
          </h4>

          <ContractRow
            icon={Coins}
            name="Royalty Engine"
            address={status.contracts.royaltyEngine}
            description="Manages royalty splits (ERC-2981)"
          />
          <ContractRow
            icon={FileCode}
            name="Rights Registry"
            address={status.contracts.rightsRegistry}
            description="IP licenses and permissions"
          />
          <ContractRow
            icon={Wallet}
            name="Studio Token ($CARTOON)"
            address={status.contracts.studioToken}
            description="ERC-20 utility token"
          />
          <ContractRow
            icon={Lock}
            name="Staking Vault"
            address={status.contracts.stakingVault}
            description="Token staking and tiers"
          />
        </div>

        {/* Last Sync */}
        {status.lastSyncTime && (
          <p className="text-xs text-muted-foreground text-right">
            Last synced: {new Date(status.lastSyncTime).toLocaleString()}
          </p>
        )}

        {/* Info Banner */}
        {status.mode === "off-chain" && (
          <div className="flex items-start gap-3 p-4 bg-amber-500/10 border border-amber-500/20 rounded-lg">
            <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-amber-400">Running in Demo Mode</p>
              <p className="text-xs text-muted-foreground mt-1">
                Configure Dogechain RPC and contract addresses to enable Hybrid Mode with on-chain royalty verification.
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

function ContractRow({
  icon: Icon,
  name,
  address,
  description,
}: {
  icon: React.ComponentType<{ className?: string }>
  name: string
  address: string | null
  description: string
}) {
  const isDeployed = !!address

  return (
    <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
      <div className="flex items-center gap-3">
        <Icon className={`w-4 h-4 ${isDeployed ? "text-primary" : "text-muted-foreground"}`} />
        <div>
          <p className="text-sm font-medium">{name}</p>
          <p className="text-xs text-muted-foreground">{description}</p>
          {address && <p className="text-xs font-mono text-primary/70 mt-1">{truncateAddress(address)}</p>}
        </div>
      </div>
      <StatusIndicator active={isDeployed} />
    </div>
  )
}

function StatusIndicator({ active }: { active: boolean }) {
  return active ? (
    <CheckCircle2 className="w-5 h-5 text-green-400" />
  ) : (
    <XCircle className="w-5 h-5 text-muted-foreground" />
  )
}

function truncateAddress(address: string): string {
  if (address.length <= 16) return address
  return `${address.slice(0, 8)}...${address.slice(-6)}`
}
