"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { formatCurrency, formatPercentage } from "@/lib/royalty-engine"
import { glowStyles } from "@/lib/styles"
import type { EpisodeRoyaltyMeta } from "@/types/royalty"
import { Building2, User, ImageIcon, Landmark, Users, RefreshCw, Link2, Link2Off } from "lucide-react"

interface RoyaltyHUDProps {
  episodeId?: string
  initialData?: EpisodeRoyaltyMeta
  showRefresh?: boolean
}

export function RoyaltyHUD({ episodeId, initialData, showRefresh = true }: RoyaltyHUDProps) {
  const [data, setData] = useState<EpisodeRoyaltyMeta | null>(initialData || null)
  const [loading, setLoading] = useState(!initialData && !!episodeId)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (episodeId && !initialData) {
      fetchRoyaltyData()
    }
  }, [episodeId, initialData])

  async function fetchRoyaltyData() {
    if (!episodeId) return

    setLoading(true)
    setError(null)

    try {
      const res = await fetch(`/api/royalty/${episodeId}`)
      if (!res.ok) throw new Error("Failed to fetch royalty data")
      const json = await res.json()
      setData(json)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unknown error")
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <RoyaltyHUDSkeleton />
  }

  if (error) {
    return (
      <Card className="bg-destructive/10 border-destructive/30">
        <CardContent className="p-6 text-center">
          <p className="text-destructive">{error}</p>
        </CardContent>
      </Card>
    )
  }

  if (!data) {
    return null
  }

  const isChainSource = data.source === "chain"
  const sourceLabel = {
    mock: "Demo Data",
    db: "Database",
    chain: "Dogechain",
  }[data.source]

  return (
    <Card className={`relative overflow-hidden ${glowStyles.gold}`}>
      {/* Header */}
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-bold text-foreground">Royalty Distribution</CardTitle>
          <div className="flex items-center gap-2">
            <Badge
              variant="outline"
              className={isChainSource ? "border-green-500 text-green-400" : "border-muted-foreground"}
            >
              {isChainSource ? <Link2 className="w-3 h-3 mr-1" /> : <Link2Off className="w-3 h-3 mr-1" />}
              {sourceLabel}
            </Badge>
            {showRefresh && (
              <button
                onClick={fetchRoyaltyData}
                className="p-2 hover:bg-muted rounded-lg transition-colors"
                aria-label="Refresh royalty data"
              >
                <RefreshCw className="w-4 h-4 text-muted-foreground" />
              </button>
            )}
          </div>
        </div>
        <p className="text-sm text-muted-foreground">{data.episodeTitle}</p>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Total Revenue */}
        <div className="text-center py-4 bg-primary/10 rounded-lg">
          <p className="text-sm text-muted-foreground mb-1">Total Revenue</p>
          <p className="text-3xl font-bold text-primary">{formatCurrency(data.totalRevenueUsd)}</p>
        </div>

        {/* Split Breakdown */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          <SplitCard
            icon={Building2}
            label="DD CARTOONS"
            percentage={data.split.studio}
            amount={data.amounts.studioAmount}
            color="text-primary"
          />
          <SplitCard
            icon={User}
            label="Creator"
            percentage={data.split.creator}
            amount={data.amounts.creatorAmount}
            color="text-blue-400"
          />
          <SplitCard
            icon={ImageIcon}
            label="NFT Holder"
            percentage={data.split.nftHolder}
            amount={data.amounts.nftHolderAmount}
            color="text-purple-400"
          />
          <SplitCard
            icon={Landmark}
            label="Treasury"
            percentage={data.split.treasury}
            amount={data.amounts.treasuryAmount}
            color="text-amber-400"
          />
          <SplitCard
            icon={Users}
            label="Stakers"
            percentage={data.split.stakers}
            amount={data.amounts.stakersAmount}
            color="text-green-400"
          />
        </div>

        {/* Last Updated */}
        <p className="text-xs text-muted-foreground text-right">
          Last updated: {new Date(data.lastUpdated).toLocaleString()}
        </p>
      </CardContent>
    </Card>
  )
}

interface SplitCardProps {
  icon: React.ComponentType<{ className?: string }>
  label: string
  percentage: number
  amount: number
  color: string
}

function SplitCard({ icon: Icon, label, percentage, amount, color }: SplitCardProps) {
  return (
    <div className="bg-muted/50 rounded-lg p-3 text-center">
      <Icon className={`w-5 h-5 mx-auto mb-2 ${color}`} />
      <p className="text-xs text-muted-foreground mb-1">{label}</p>
      <p className={`text-lg font-bold ${color}`}>{formatPercentage(percentage)}</p>
      <p className="text-sm text-foreground">{formatCurrency(amount)}</p>
    </div>
  )
}

function RoyaltyHUDSkeleton() {
  return (
    <Card>
      <CardHeader>
        <Skeleton className="h-6 w-48" />
        <Skeleton className="h-4 w-32 mt-2" />
      </CardHeader>
      <CardContent className="space-y-4">
        <Skeleton className="h-24 w-full" />
        <div className="grid grid-cols-5 gap-3">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
