"use client"

import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { CheckCircle2, XCircle, ExternalLink, Shield } from "lucide-react"
import { licenseColors } from "@/lib/styles"
import type { IPLicense } from "@/types/royalty"

interface IPLicensesTableProps {
  licenses: IPLicense[]
  title?: string
}

export function IPLicensesTable({ licenses, title = "IP Licenses" }: IPLicensesTableProps) {
  const activeLicenses = licenses.filter((l) => l.isActive).length

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-primary" />
            {title}
          </CardTitle>
          <Badge variant="outline">
            {activeLicenses} / {licenses.length} Active
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Asset</TableHead>
                <TableHead>License Type</TableHead>
                <TableHead>Owner</TableHead>
                <TableHead>Expiry</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Metadata</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {licenses.map((license) => (
                <TableRow key={license.assetId}>
                  <TableCell>
                    <div>
                      <p className="font-medium">{license.assetName}</p>
                      <p className="text-xs text-muted-foreground font-mono">{license.assetId}</p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={licenseColors[license.licenseType]}>{license.licenseType}</Badge>
                  </TableCell>
                  <TableCell>
                    <span className="font-mono text-xs">{truncateAddress(license.owner)}</span>
                  </TableCell>
                  <TableCell>
                    {license.expiry ? (
                      <span className={isExpired(license.expiry) ? "text-destructive" : "text-muted-foreground"}>
                        {formatDate(license.expiry)}
                      </span>
                    ) : (
                      <span className="text-green-400">Perpetual</span>
                    )}
                  </TableCell>
                  <TableCell>
                    {license.isActive ? (
                      <div className="flex items-center gap-1 text-green-400">
                        <CheckCircle2 className="w-4 h-4" />
                        <span className="text-sm">Active</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <XCircle className="w-4 h-4" />
                        <span className="text-sm">Inactive</span>
                      </div>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <a
                      href={license.uri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-primary hover:underline text-sm"
                    >
                      View
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}

function truncateAddress(address: string): string {
  if (address.length <= 16) return address
  return `${address.slice(0, 10)}...${address.slice(-4)}`
}

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  })
}

function isExpired(dateStr: string): boolean {
  return new Date(dateStr) < new Date()
}
