"use client"

import Image from "next/image"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Play, Clock, Eye, DollarSign } from "lucide-react"
import { formatCurrency } from "@/lib/royalty-engine"
import { cardStyles } from "@/lib/styles"
import type { Episode } from "@/types/royalty"

interface EpisodeCardProps {
  episode: Episode
  showRevenue?: boolean
}

export function EpisodeCard({ episode, showRevenue = false }: EpisodeCardProps) {
  const duration = formatDuration(episode.duration)
  const views = formatViews(episode.viewCount)

  return (
    <Link href={`/watch/${episode.id}`} className="block group">
      <Card className={`${cardStyles.base} ${cardStyles.hover} ${cardStyles.focus}`}>
        {/* Thumbnail */}
        <div className="relative aspect-video overflow-hidden">
          <Image
            src={episode.thumbnailUrl || "/placeholder.svg"}
            alt={episode.title}
            fill
            className="object-cover transition-transform duration-300 group-hover:scale-105"
          />
          {/* Play overlay */}
          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
            <div className="w-16 h-16 rounded-full bg-primary/90 flex items-center justify-center">
              <Play className="w-8 h-8 text-primary-foreground ml-1" />
            </div>
          </div>
          {/* Duration badge */}
          <Badge className="absolute bottom-2 right-2 bg-black/70 text-white">
            <Clock className="w-3 h-3 mr-1" />
            {duration}
          </Badge>
          {/* Episode number */}
          <Badge className="absolute top-2 left-2 bg-primary text-primary-foreground">
            S{episode.season} E{episode.episode}
          </Badge>
        </div>

        <CardContent className="p-4">
          <h3 className="font-semibold text-foreground line-clamp-1 mb-1">{episode.title}</h3>
          <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{episode.description}</p>

          {/* Stats */}
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <Eye className="w-3 h-3" />
              {views}
            </span>
            {showRevenue && (
              <span className="flex items-center gap-1 text-primary">
                <DollarSign className="w-3 h-3" />
                {formatCurrency(episode.revenueUsd)}
              </span>
            )}
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}

function formatDuration(seconds: number): string {
  const mins = Math.floor(seconds / 60)
  const secs = seconds % 60
  return `${mins}:${secs.toString().padStart(2, "0")}`
}

function formatViews(count: number): string {
  if (count >= 1000000) {
    return `${(count / 1000000).toFixed(1)}M`
  }
  if (count >= 1000) {
    return `${(count / 1000).toFixed(1)}K`
  }
  return count.toString()
}
