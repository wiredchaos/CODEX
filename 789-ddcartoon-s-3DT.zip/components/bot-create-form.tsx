// Bot Creation Form Component
// Form for creating new Creator Codex bots

"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import type { BotPersona, CreateBotInput } from "@/types/creator-codex"
import { PERSONA_INFO } from "@/types/creator-codex"
import { getPersonaColor } from "@/lib/creator-codex"
import { mockEpisodes } from "@/lib/mock-data"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Mic2,
  Compass,
  GraduationCap,
  Bell,
  Drama,
  Headphones,
  Loader2,
  ExternalLink,
  CheckCircle2,
} from "lucide-react"

const iconMap = {
  Mic2,
  Compass,
  GraduationCap,
  Bell,
  Drama,
  HeadphonesIcon: Headphones,
}

const ACCENT_COLORS = [
  { name: "Gold", value: "#DAA520" },
  { name: "Blue", value: "#3B82F6" },
  { name: "Green", value: "#22C55E" },
  { name: "Purple", value: "#A855F7" },
  { name: "Cyan", value: "#06B6D4" },
  { name: "Pink", value: "#EC4899" },
]

export function BotCreateForm() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [createdBot, setCreatedBot] = useState<{ id: string; npcLaunchUrl: string } | null>(null)

  const [form, setForm] = useState<CreateBotInput>({
    name: "",
    description: "",
    persona: "HOST",
    accentColor: "#DAA520",
    attachedShows: [],
    revShareBps: 2000,
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const res = await fetch("/api/creator-codex/bots", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      })

      if (!res.ok) throw new Error("Failed to create bot")

      const bot = await res.json()
      setCreatedBot({ id: bot.id, npcLaunchUrl: bot.npcLaunchUrl })
    } catch (error) {
      console.error("Error creating bot:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleShowToggle = (episodeId: string, checked: boolean) => {
    setForm((prev) => ({
      ...prev,
      attachedShows: checked
        ? [...(prev.attachedShows || []), episodeId]
        : (prev.attachedShows || []).filter((id) => id !== episodeId),
    }))
  }

  if (createdBot) {
    return (
      <Card className="bg-card border-border max-w-2xl mx-auto">
        <CardContent className="p-8 text-center space-y-6">
          <div className="w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-8 h-8 text-green-400" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-2">Bot Created Successfully!</h2>
            <p className="text-muted-foreground">
              Your bot is ready. Launch it in NEURO PROMPT COMMAND to start training.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <a href={createdBot.npcLaunchUrl} target="_blank" rel="noopener noreferrer">
              <Button size="lg" className="gap-2 min-h-[48px]">
                <ExternalLink className="w-5 h-5" />
                Launch in NEURO PROMPT COMMAND
              </Button>
            </a>
            <Button
              variant="outline"
              size="lg"
              className="min-h-[48px] bg-transparent"
              onClick={() => router.push("/creator-codex/bots")}
            >
              View All Bots
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-8 max-w-2xl mx-auto">
      {/* Basic Info */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Bot Identity</CardTitle>
          <CardDescription>Define your bot's name and purpose</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Bot Name *</Label>
            <Input
              id="name"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="e.g., Doge Max Host"
              required
              className="bg-background"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              placeholder="Describe what this bot does..."
              rows={3}
              className="bg-background"
            />
          </div>
        </CardContent>
      </Card>

      {/* Persona Selection */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Select Persona</CardTitle>
          <CardDescription>Choose the role and behavior type for your bot</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {(Object.keys(PERSONA_INFO) as BotPersona[]).map((persona) => {
              const info = PERSONA_INFO[persona]
              const IconComponent = iconMap[info.icon as keyof typeof iconMap] || Mic2
              const isSelected = form.persona === persona

              return (
                <button
                  key={persona}
                  type="button"
                  onClick={() => setForm({ ...form, persona })}
                  className={`p-4 rounded-lg border text-left transition-all ${
                    isSelected ? "border-primary bg-primary/10" : "border-border bg-background hover:border-primary/50"
                  }`}
                >
                  <div className="flex items-center gap-3 mb-2">
                    <div className={`p-2 rounded-lg ${getPersonaColor(persona)}`}>
                      <IconComponent className="w-4 h-4" />
                    </div>
                    <span className="font-semibold text-foreground">{info.label}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">{info.description}</p>
                </button>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Accent Color */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Accent Color</CardTitle>
          <CardDescription>Choose a color to represent your bot</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            {ACCENT_COLORS.map((color) => (
              <button
                key={color.value}
                type="button"
                onClick={() => setForm({ ...form, accentColor: color.value })}
                className={`w-12 h-12 rounded-full border-4 transition-all ${
                  form.accentColor === color.value
                    ? "border-foreground scale-110"
                    : "border-transparent hover:scale-105"
                }`}
                style={{ backgroundColor: color.value }}
                title={color.name}
              />
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Attach to Shows */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Attach to Shows (Optional)</CardTitle>
          <CardDescription>Link this bot to specific episodes</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 max-h-[200px] overflow-y-auto">
            {mockEpisodes.map((episode) => (
              <label
                key={episode.id}
                className="flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-muted/50 cursor-pointer transition-colors"
              >
                <Checkbox
                  checked={form.attachedShows?.includes(episode.id)}
                  onCheckedChange={(checked) => handleShowToggle(episode.id, checked as boolean)}
                />
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-foreground text-sm truncate">{episode.title}</p>
                  <p className="text-xs text-muted-foreground">
                    S{episode.season} E{episode.episode}
                  </p>
                </div>
              </label>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Revenue Share */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Revenue Share</CardTitle>
          <CardDescription>Percentage of bot-driven revenue allocated to creator</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Creator Share</span>
              <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30">
                {((form.revShareBps || 2000) / 100).toFixed(1)}%
              </Badge>
            </div>
            <input
              type="range"
              min="500"
              max="5000"
              step="100"
              value={form.revShareBps || 2000}
              onChange={(e) => setForm({ ...form, revShareBps: Number.parseInt(e.target.value) })}
              className="w-full accent-primary"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>5%</span>
              <span>50%</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Submit */}
      <div className="flex gap-4 justify-end">
        <Button type="button" variant="outline" className="bg-transparent min-h-[48px]" onClick={() => router.back()}>
          Cancel
        </Button>
        <Button type="submit" disabled={!form.name || isSubmitting} className="min-h-[48px] gap-2">
          {isSubmitting ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Creating...
            </>
          ) : (
            "Create Bot"
          )}
        </Button>
      </div>
    </form>
  )
}
