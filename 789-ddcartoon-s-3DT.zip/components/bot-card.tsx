// Bot Card Component
// Displays Creator Codex bot in list view

"use client"

import type { CreatorCodexBot, BotStats } from "@/types/creator-codex"
import { PERSONA_INFO } from "@/types/creator-codex"
import { getPersonaColor, formatBps } from "@/lib/creator-codex"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  ExternalLink,
  Mic2,
  Compass,
  GraduationCap,
  Bell,
  Drama,
  Headphones,
  Users,
  Zap,
  DollarSign,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"

const iconMap = {
  Mic2,
  Compass,
  GraduationCap,
  Bell,
  Drama,
  HeadphonesIcon: Headphones,
}

interface BotCardProps {
  bot: CreatorCodexBot
  stats?: BotStats | null
  showActions?: boolean
}

export function BotCard({ bot, stats, showActions = true }: BotCardProps) {
  const personaInfo = PERSONA_INFO[bot.persona]
  const IconComponent = iconMap[personaInfo.icon as keyof typeof iconMap] || Mic2

  const statusColors = {
    draft: "bg-muted text-muted-foreground",
    active: "bg-green-500/20 text-green-400 border-green-500/30",
    inactive: "bg-red-500/20 text-red-400 border-red-500/30",
    training: "bg-amber-500/20 text-amber-400 border-amber-500/30",
  }

  return (
    <Card className="bg-card border-border hover:border-primary/50 transition-all duration-300 overflow-hidden">
      <CardContent className="p-0">
        {/* Avatar Header */}
        <div
          className="relative h-32 flex items-center justify-center"
          style={{ backgroundColor: `${bot.accentColor}20` }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-card" />
          {bot.avatarImageUrl ? (
            <Image
              src={bot.avatarImageUrl || "/placeholder.svg"}
              alt={bot.name}
              width={80}
              height={80}
              className="rounded-full border-4 border-card relative z-10"
            />
          ) : (
            <div
              className="w-20 h-20 rounded-full border-4 border-card flex items-center justify-center relative z-10"
              style={{ backgroundColor: bot.accentColor }}
            >
              <IconComponent className="w-10 h-10 text-white" />
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-4 space-y-4">
          {/* Header */}
          <div className="space-y-2">
            <div className="flex items-start justify-between gap-2">
              <h3 className="font-bold text-foreground text-lg leading-tight">{bot.name}</h3>
              <Badge variant="outline" className={statusColors[bot.status]}>
                {bot.status}
              </Badge>
            </div>
            <Badge variant="outline" className={getPersonaColor(bot.persona)}>
              <IconComponent className="w-3 h-3 mr-1" />
              {personaInfo.label}
            </Badge>
          </div>

          {/* Description */}
          <p className="text-sm text-muted-foreground line-clamp-2">{bot.description}</p>

          {/* Stats */}
          {stats && (
            <div className="grid grid-cols-3 gap-2 text-center py-2 border-y border-border">
              <div>
                <div className="flex items-center justify-center gap-1 text-muted-foreground">
                  <Zap className="w-3 h-3" />
                </div>
                <p className="text-sm font-semibold text-foreground">{stats.totalInteractions.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">Interactions</p>
              </div>
              <div>
                <div className="flex items-center justify-center gap-1 text-muted-foreground">
                  <Users className="w-3 h-3" />
                </div>
                <p className="text-sm font-semibold text-foreground">{stats.uniqueUsers.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">Users</p>
              </div>
              <div>
                <div className="flex items-center justify-center gap-1 text-muted-foreground">
                  <DollarSign className="w-3 h-3" />
                </div>
                <p className="text-sm font-semibold text-foreground">${stats.revenueGenerated.toFixed(0)}</p>
                <p className="text-xs text-muted-foreground">Revenue</p>
              </div>
            </div>
          )}

          {/* Rev Share */}
          {bot.revShareBps !== undefined && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Creator Rev Share</span>
              <span className="font-semibold text-primary">{formatBps(bot.revShareBps)}</span>
            </div>
          )}

          {/* Actions */}
          {showActions && (
            <div className="flex gap-2 pt-2">
              <Link href={`/creator-codex/bots/${bot.id}`} className="flex-1">
                <Button variant="outline" size="sm" className="w-full bg-transparent">
                  View Details
                </Button>
              </Link>
              <a href={bot.npcLaunchUrl} target="_blank" rel="noopener noreferrer" className="flex-1">
                <Button size="sm" className="w-full gap-1" disabled={bot.status !== "active"}>
                  <ExternalLink className="w-3 h-3" />
                  Launch NPC
                </Button>
              </a>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
