"use client"

import { useEffect } from "react"

// that occurs with responsive layouts and doesn't affect functionality
export function ResizeObserverFix() {
  useEffect(() => {
    const resizeObserverError = (e: ErrorEvent) => {
      if (e.message === "ResizeObserver loop completed with undelivered notifications.") {
        e.stopImmediatePropagation()
      }
    }

    window.addEventListener("error", resizeObserverError)
    return () => window.removeEventListener("error", resizeObserverError)
  }, [])

  return null
}
