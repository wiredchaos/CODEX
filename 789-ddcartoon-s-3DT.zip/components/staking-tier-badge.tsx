"use client"

import { Badge } from "@/components/ui/badge"
import { tierColors } from "@/lib/styles"
import { Star, Crown, Gem, Eye } from "lucide-react"
import type { StakingTier } from "@/types/royalty"

interface StakingTierBadgeProps {
  tier: StakingTier
  showIcon?: boolean
  size?: "sm" | "md" | "lg"
}

const tierIcons = {
  Viewer: Eye,
  Member: Star,
  Premium: Gem,
  Executive: Crown,
}

export function StakingTierBadge({ tier, showIcon = true, size = "md" }: StakingTierBadgeProps) {
  const Icon = tierIcons[tier]

  const sizeClasses = {
    sm: "text-xs px-2 py-0.5",
    md: "text-sm px-3 py-1",
    lg: "text-base px-4 py-1.5",
  }

  const iconSizes = {
    sm: "w-3 h-3",
    md: "w-4 h-4",
    lg: "w-5 h-5",
  }

  return (
    <Badge variant="outline" className={`${tierColors[tier]} ${sizeClasses[size]} font-medium`}>
      {showIcon && <Icon className={`${iconSizes[size]} mr-1`} />}
      {tier}
    </Badge>
  )
}
