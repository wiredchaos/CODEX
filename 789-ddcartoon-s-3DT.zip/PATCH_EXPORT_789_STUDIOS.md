# 789 STUDIOS OTT + DD CARTOONS + CREATOR CODEX
## MONOREPO PATCH MODULE EXPORT

---

## PATCH MANIFEST

```json
{
  "patch": "789_STUDIOS_OTT",
  "version": "1.0.0",
  "realm": "business",
  "mount": "/world/789",
  "ui": true,
  "scene": true,
  "description": "Smart TV / OTT streaming platform for 789 Studios with DD CARTOONS animation studio, Creator Codex bot lab, and NEURO PROMPT COMMAND integration. Features blockchain royalty tracking (Dogechain), IP licensing dashboard, and staking tiers.",
  
  "trinity": {
    "mode": "consumer",
    "floorAssignment": "789_STUDIOS",
    "timelineAccess": "akira_codex_governed",
    "permissions": {
      "read3D": true,
      "write3D": false,
      "createGalaxy": false,
      "modifyTrinity": false
    },
    "declaration": "This patch consumes existing WIRED CHAOS Trinity 3D Core. No new 3D generation. No new galaxy creation. Trinity is read-only infrastructure."
  },
  
  "dependencies": {
    "next": "^16.0.0",
    "react": "^19.2.0",
    "tailwindcss": "^4.0.0",
    "@supabase/ssr": "latest",
    "viem": "^2.0.0",
    "recharts": "^2.12.0"
  },
  "integrations": {
    "required": ["Neon", "Supabase"],
    "optional": ["Upstash for Redis", "Blob", "Stripe", "Groq", "Grok"]
  },
  "blockchain": {
    "network": "Dogechain",
    "contracts": [
      "RoyaltyEngine",
      "RightsRegistry",
      "StudioToken",
      "StakingVault"
    ]
  },
  "externalLinks": {
    "npcWorldUrl": "https://npc.hyperfy.ai"
  }
}
```

---

## TRINITY FLOOR / TIMELINE DECLARATION

> **CONSUMER PATCH DECLARATION**
> 
> This patch (789_STUDIOS_OTT) operates as a **consumer** of the existing WIRED CHAOS Trinity 3D Core infrastructure.
> 
> **Declarations:**
> - No new 3D generation
> - No new galaxy creation  
> - This patch mounts to its assigned Trinity Floor or Timeline
> - Timeline access is governed by **Akira Codex**
> - Trinity infrastructure is **read-only** from this patch's perspective
> 
> **This patch operates as a consumer, not an owner.**

### Trinity Integration Points

| Integration | Access Level | Notes |
|-------------|--------------|-------|
| Trinity Floor | **Read** | Mounts to assigned floor `789_STUDIOS` |
| Timeline | **Read** | Governed by Akira Codex |
| 3D Core | **None** | No 3D generation or modification |
| Galaxy | **None** | No galaxy creation or ownership |
| Scene Graph | **Read** | Can reference existing scenes |
| Hyperfy/NPC | **External** | Hands off to npc.hyperfy.ai |

### Akira Codex Governance

Timeline access for this patch follows Akira Codex rules:

```ts
interface AkiraCodexGate {
  patch: "789_STUDIOS_OTT";
  timelinePermissions: {
    read: true;
    write: false;
    branch: false;
    merge: false;
  };
  floorBinding: "789_STUDIOS";
  escalationPath: "akira_codex_council";
}
```

---

## FILE TREE

### 📦 Patch Structure

```
789_STUDIOS_OTT/
├── 📋 PATCH_MANIFEST.json
├── 📄 README.md
│
├── 🎨 UI_COMPONENTS/
│   ├── blockchain-status.tsx
│   ├── bot-card.tsx
│   ├── bot-create-form.tsx
│   ├── episode-card.tsx
│   ├── ip-licenses-table.tsx
│   ├── navigation.tsx
│   ├── resize-observer-fix.tsx
│   ├── royalty-hud.tsx
│   ├── staking-tier-badge.tsx
│   └── theme-provider.tsx
│
├── 🌐 ROUTES/ (Next.js App Router)
│   ├── api/
│   │   ├── blockchain/
│   │   │   └── status/route.ts
│   │   ├── creator-codex/
│   │   │   └── bots/
│   │   │       ├── route.ts
│   │   │       └── [botId]/
│   │   │           ├── route.ts
│   │   │           ├── config/route.ts
│   │   │           └── prompt/route.ts
│   │   └── royalty/
│   │       └── [episodeId]/route.ts
│   │
│   ├── pages/
│   │   ├── page.tsx                    (Landing)
│   │   ├── dd-cartoons/page.tsx        (Studio Hub)
│   │   ├── royalties/page.tsx          (Revenue Dashboard)
│   │   ├── licenses/page.tsx           (IP Rights Registry)
│   │   ├── blockchain/page.tsx         (Contract Status)
│   │   └── creator-codex/
│   │       ├── page.tsx                (Bot Lab Hub)
│   │       └── bots/
│   │           ├── page.tsx            (Bot List)
│   │           ├── new/page.tsx        (Create Bot)
│   │           └── [botId]/page.tsx    (Bot Detail)
│   │
│   ├── layout.tsx
│   └── globals.css
│
├── 📚 TYPES/
│   ├── royalty.ts
│   ├── creator-codex.ts
│   └── npc-config.ts
│
├── 🔧 LIB/ (Utilities)
│   ├── royalty-engine.ts          (Off-chain split logic)
│   ├── royalty-chain.ts           (Dogechain connector)
│   ├── creator-codex.ts           (Bot utilities)
│   ├── npc-prompts.ts             (System prompt builder)
│   ├── mock-data.ts               (Episodes, studios)
│   ├── mock-bots.ts               (Sample bots)
│   ├── styles.ts                  (Glow styles)
│   └── utils.ts                   (cn, etc.)
│
├── 📖 DOCS/
│   ├── DEVELOPER_ONBOARDING.md
│   ├── CREATOR_CODEX_CHECKLIST.md
│   ├── CREATOR_CODEX_PATCH.md
│   └── NPC_SYSTEM_PROMPT.md
│
└── 🎬 ASSETS/
    └── public/
        ├── dd-cartoons-*.jpg
        ├── cartoon-*.jpg
        └── icons/
```

---

## COMPONENT CLASSIFICATION

### a) UI Components (Pure Presentation)
**Location:** `components/`
**Trinity Role:** Consumer (renders to assigned floor)

- `blockchain-status.tsx` - Contract deployment status cards
- `bot-card.tsx` - Creator Codex bot display card with NPC launch
- `bot-create-form.tsx` - Bot creation form with persona selection
- `episode-card.tsx` - Episode card with revenue display
- `ip-licenses-table.tsx` - Rights Registry table view
- `navigation.tsx` - Main navigation with wallet connect
- `royalty-hud.tsx` - Revenue split breakdown display (40/20/20/10/10)
- `staking-tier-badge.tsx` - Tier badge (Viewer → Executive)
- `theme-provider.tsx` - Dark mode provider
- `resize-observer-fix.tsx` - ResizeObserver error suppression

### b) Scene / Layout Logic (Container Components)
**Location:** `app/`
**Trinity Role:** Consumer (mounts to floor, does not create scenes)

**Pages:**
- `app/page.tsx` - Landing hero with stats and featured content
- `app/dd-cartoons/page.tsx` - Studio hub with episodes + royalties
- `app/royalties/page.tsx` - Full revenue dashboard
- `app/licenses/page.tsx` - IP licensing management
- `app/blockchain/page.tsx` - Contract documentation
- `app/creator-codex/page.tsx` - Bot lab hub with NPC flow
- `app/creator-codex/bots/page.tsx` - Bot list (Active/Training/Draft)
- `app/creator-codex/bots/new/page.tsx` - Bot creation wizard
- `app/creator-codex/bots/[botId]/page.tsx` - Bot detail with stats

**Layout:**
- `app/layout.tsx` - Root layout with navigation + metadata

### c) Patch-Specific Routes (API)
**Location:** `app/api/`
**Trinity Role:** Consumer (reads chain state, does not modify Trinity)

**Hybrid Mode APIs:**
- `GET /api/royalty/[episodeId]` - Merge off-chain revenue + on-chain split
- `GET /api/blockchain/status` - Contract deployment + RPC health

**Creator Codex APIs:**
- `GET /api/creator-codex/bots` - List bots for studio
- `POST /api/creator-codex/bots` - Create bot with NPC URL
- `GET /api/creator-codex/bots/[botId]` - Get bot details
- `PATCH /api/creator-codex/bots/[botId]` - Update bot
- `DELETE /api/creator-codex/bots/[botId]` - Delete bot
- `GET/PUT /api/creator-codex/bots/[botId]/config` - NPC config CRUD
- `GET /api/creator-codex/bots/[botId]/prompt` - Generate system prompt

---

## REALM ASSIGNMENT

| Component | Realm | Trinity Role | Reason |
|-----------|-------|--------------|--------|
| Landing page, streaming UI | **Business** | Consumer | Public-facing viewer experience |
| DD CARTOONS studio | **Business** | Consumer | IP + content production |
| Royalty dashboards | **Business** | Consumer | Revenue tracking + splits |
| Creator Codex | **Business** | Consumer | Bot creation studio |
| Blockchain status | **Business** | Consumer | Hybrid mode transparency |
| NPC integration | **Akashic** | External | Agent training / metaphysical layer |
| Future: Bot chat UI | **Akashic** | Consumer | Live agent interactions |

**Current Patch:** Business realm only  
**Trinity Mode:** Consumer (read-only)  
**Floor Assignment:** 789_STUDIOS  
**Timeline Governance:** Akira Codex

---

## INTEGRATION POINTS

### 1. NEURO PROMPT COMMAND (npc.hyperfy.ai)
**File:** `lib/creator-codex.ts` → `buildNpcLaunchUrl()`

**Flow:**
1. User creates bot in Creator Codex
2. Bot gets `npcLaunchUrl` with params: `botId`, `name`, `persona`, `studio`
3. "Launch in NEURO PROMPT COMMAND" button opens URL
4. NPC Hyperfy world receives bot metadata and prefills training UI

**System Prompt:** `lib/npc-prompts.ts` → `buildNpcSystemPrompt()`

### 2. Dogechain (Blockchain)
**File:** `lib/royalty-chain.ts`

**Contracts:**
- `RoyaltyEngine` - Stores per-episode splits in BPS
- `RightsRegistry` - Tracks IP licenses with permissions
- `StudioToken` ($CARTOON) - ERC-20 for staking
- `StakingVault` - Lock periods + tier mapping

**Environment Variables:**
```
DOGECHAIN_RPC_URL
ROYALTY_ENGINE_ADDRESS
RIGHTS_REGISTRY_ADDRESS
STUDIO_TOKEN_ADDRESS
STAKING_VAULT_ADDRESS
```

### 3. Database (Supabase / Neon)
**Off-chain data:**
- Episodes (title, description, revenue)
- Studios (DD CARTOONS, etc.)
- Bots (Creator Codex bot blueprints)
- NPC Configs (system prompts, behavior overrides)

**Hybrid Mode:**
- Revenue from DB
- Splits from chain
- Merged in `/api/royalty/[episodeId]`

---

## MOUNTING INSTRUCTIONS

### For Monorepo Integration:

1. **Copy files to patch directory:**
   ```bash
   cp -r 789_STUDIOS_OTT/ /monorepo/patches/789_studios_ott/
   ```

2. **Register as Trinity Consumer:**
   ```ts
   // lib/trinity-registry.ts
   registerPatch({
     id: "789_studios_ott",
     mode: "consumer",
     floor: "789_STUDIOS",
     timelineGovernance: "akira_codex",
     permissions: {
       read3D: true,
       write3D: false,
       createGalaxy: false
     }
   })
   ```

3. **Update imports to use patch prefix:**
   ```ts
   // Before
   import { RoyaltyHUD } from "@/components/royalty-hud"
   
   // After (in monorepo)
   import { RoyaltyHUD } from "@/patches/789_studios_ott/components/royalty-hud"
   ```

4. **Mount routes in main App Router:**
   ```ts
   // app/world/789/[...slug]/page.tsx
   import { routes as patch789Routes } from "@/patches/789_studios_ott/routes"
   
   export default function Patch789Page({ params }: { params: { slug: string[] } }) {
     return patch789Routes.render(params.slug)
   }
   ```

5. **Register in Global Telemetry Bus:**
   ```ts
   // lib/telemetry-bus.ts
   registerPatch({
     id: "789_studios_ott",
     realm: "business",
     mount: "/world/789",
     trinityMode: "consumer",
     telemetryEndpoints: [
       "/api/royalty/*",
       "/api/creator-codex/*"
     ]
   })
   ```

6. **Add to Hemisphere Mapping System:**
   ```ts
   // lib/hemisphere-map.ts
   const patches = {
     "789_studios_ott": {
       hemisphere: "business",
       features: ["streaming", "royalties", "bot_lab"],
       npcIntegration: true,
       trinityRole: "consumer",
       floorBinding: "789_STUDIOS"
     }
   }
   ```

7. **Verify Akira Codex Gate:**
   ```ts
   // lib/akira-codex.ts
   verifyTimelineAccess({
     patch: "789_studios_ott",
     requestedPermissions: ["read"],
     floor: "789_STUDIOS"
   })
   ```

---

## DEPLOYMENT CHECKLIST

### Trinity Consumer Verification
- [ ] Patch registered as consumer in Trinity Registry
- [ ] Floor assignment confirmed: `789_STUDIOS`
- [ ] Akira Codex timeline access verified
- [ ] No 3D generation code present
- [ ] No galaxy creation code present
- [ ] Read-only Trinity access confirmed

### Standard Deployment
- [ ] Copy patch files to monorepo
- [ ] Update import paths
- [ ] Mount routes at `/world/789`
- [ ] Add environment variables
- [ ] Deploy Dogechain contracts (optional for Hybrid Mode)
- [ ] Seed mock data (episodes, bots)
- [ ] Test NPC launch flow to npc.hyperfy.ai
- [ ] Register in Global Telemetry Bus
- [ ] Update Hemisphere Mapping System
- [ ] Verify ResizeObserver fix is active
- [ ] Test royalty HUD with mock/chain data
- [ ] Verify bot creation → NPC launch

---

## NOTES

- **Trinity Consumer:** This patch does NOT own or modify Trinity 3D Core. It mounts to an assigned floor and reads from timeline via Akira Codex governance.
- **Autonomous Infrastructure:** No manual intervention needed; mock data enables TV app approval while chain contracts activate progressively.
- **Anti-Moloch Logic:** Revenue splits are trustless (on-chain) and transparent (dashboard).
- **Continuity:** Patch preserves dual realm architecture (Business for UI, future Akashic for NPC).
- **White Label Ready:** Bot system supports studio-specific branding via `accentColor` and `avatarImageUrl`.
- **Firewalled:** Business and Akashic realms are separated; bot training (NPC) is external to streaming UI.

---

## FUTURE EXPANSION

- [ ] Add Akashic realm for live bot chat overlays
- [ ] Integrate WL Gamification (whitelist scoring)
- [ ] Add Wired Chaos OTT integration
- [ ] Implement NPC Engine for in-app bot interactions
- [ ] Add hemisphere scoring to bot stats
- [ ] Create Studio789 OTT crossover patch

---

**Patch Lead:** PM Lead for WIRED CHAOS META  
**Build Date:** 2025-01-16  
**Status:** Production-ready, Hybrid Mode enabled  
**Next Steps:** Mount in monorepo + deploy contracts
