// NPC Bot Configuration Types
// Schema for storing system prompts per bot with overrides

import type { BotPersona } from "./creator-codex"

/**
 * NPC Bot Configuration
 * Stores system prompt customizations and overrides per bot
 */
export interface NpcBotConfig {
  botId: string
  version: number // Config version for migrations

  // Base prompt settings
  useDefaultTemplate: boolean // If true, uses base template
  customSystemPrompt?: string // Full override if useDefaultTemplate is false

  // Template variable overrides
  overrides: NpcPromptOverrides

  // Persona specialization
  specialization?: string // Additional context for this specific bot
  focusAreas: string[] // Topics to emphasize
  avoidTopics: string[] // Topics to avoid or deflect

  // Behavior modifiers
  behavior: NpcBehaviorConfig

  // Metadata
  createdAt: string
  updatedAt: string
}

/**
 * Overrides for template variables
 */
export interface NpcPromptOverrides {
  customIntro?: string // Override the intro paragraph
  customIdentity?: string // Override identity section
  customBoundaries?: string // Additional boundary rules
  customInteractionRules?: string // Extra interaction guidance
  responseStyleOverride?: ResponseStyle // Override default style
}

/**
 * Response style configuration
 */
export interface ResponseStyle {
  tone: "formal" | "casual" | "playful" | "professional" | "dramatic"
  verbosity: "concise" | "moderate" | "detailed"
  useEmoji: boolean
  useFormatting: boolean // Markdown, bullet points, etc.
}

/**
 * Behavior modifiers for the bot
 */
export interface NpcBehaviorConfig {
  maxResponseLength: number // Character limit suggestion
  allowExternalLinks: boolean // Can reference external URLs
  allowCodeBlocks: boolean // Can output code
  enableLoreMode: boolean // Speak in-character for story bots
  enableTeachingMode: boolean // Structured educational responses
  enableSupportMode: boolean // Troubleshooting flow enabled
  safetyLevel: "strict" | "moderate" | "relaxed"
}

/**
 * Default behavior config
 */
export const DEFAULT_BEHAVIOR_CONFIG: NpcBehaviorConfig = {
  maxResponseLength: 1500,
  allowExternalLinks: false,
  allowCodeBlocks: false,
  enableLoreMode: false,
  enableTeachingMode: false,
  enableSupportMode: false,
  safetyLevel: "moderate",
}

/**
 * Default response style
 */
export const DEFAULT_RESPONSE_STYLE: ResponseStyle = {
  tone: "professional",
  verbosity: "moderate",
  useEmoji: false,
  useFormatting: true,
}

/**
 * Persona-specific default configs
 */
export const PERSONA_DEFAULT_CONFIGS: Record<BotPersona, Partial<NpcBehaviorConfig>> = {
  HOST: {
    enableLoreMode: true,
    maxResponseLength: 1000,
    safetyLevel: "moderate",
  },
  GUIDE: {
    enableTeachingMode: true,
    allowExternalLinks: true,
    maxResponseLength: 1500,
  },
  TEACHER: {
    enableTeachingMode: true,
    allowCodeBlocks: true,
    maxResponseLength: 2000,
    safetyLevel: "moderate",
  },
  CONCIERGE: {
    enableSupportMode: true,
    allowExternalLinks: true,
    maxResponseLength: 1200,
  },
  NPC_STORY: {
    enableLoreMode: true,
    maxResponseLength: 800,
    safetyLevel: "relaxed",
  },
  SUPPORT: {
    enableSupportMode: true,
    allowExternalLinks: true,
    allowCodeBlocks: true,
    maxResponseLength: 1500,
    safetyLevel: "strict",
  },
}

/**
 * Full config with all defaults applied
 */
export function createDefaultNpcConfig(botId: string, persona: BotPersona): NpcBotConfig {
  const now = new Date().toISOString()
  const personaDefaults = PERSONA_DEFAULT_CONFIGS[persona]

  return {
    botId,
    version: 1,
    useDefaultTemplate: true,
    overrides: {},
    focusAreas: [],
    avoidTopics: [],
    behavior: {
      ...DEFAULT_BEHAVIOR_CONFIG,
      ...personaDefaults,
    },
    createdAt: now,
    updatedAt: now,
  }
}

/**
 * Validate that a config is well-formed
 */
export function validateNpcConfig(config: unknown): config is NpcBotConfig {
  if (!config || typeof config !== "object") return false

  const c = config as Record<string, unknown>
  return (
    typeof c.botId === "string" &&
    typeof c.version === "number" &&
    typeof c.useDefaultTemplate === "boolean" &&
    typeof c.behavior === "object" &&
    Array.isArray(c.focusAreas) &&
    Array.isArray(c.avoidTopics)
  )
}

/**
 * JSON Schema for validation (useful for API/forms)
 */
export const NPC_CONFIG_JSON_SCHEMA = {
  $schema: "http://json-schema.org/draft-07/schema#",
  title: "NpcBotConfig",
  type: "object",
  required: ["botId", "version", "useDefaultTemplate", "overrides", "focusAreas", "avoidTopics", "behavior"],
  properties: {
    botId: { type: "string" },
    version: { type: "number", minimum: 1 },
    useDefaultTemplate: { type: "boolean" },
    customSystemPrompt: { type: "string" },
    overrides: {
      type: "object",
      properties: {
        customIntro: { type: "string" },
        customIdentity: { type: "string" },
        customBoundaries: { type: "string" },
        customInteractionRules: { type: "string" },
        responseStyleOverride: {
          type: "object",
          properties: {
            tone: { type: "string", enum: ["formal", "casual", "playful", "professional", "dramatic"] },
            verbosity: { type: "string", enum: ["concise", "moderate", "detailed"] },
            useEmoji: { type: "boolean" },
            useFormatting: { type: "boolean" },
          },
        },
      },
    },
    specialization: { type: "string" },
    focusAreas: { type: "array", items: { type: "string" } },
    avoidTopics: { type: "array", items: { type: "string" } },
    behavior: {
      type: "object",
      required: ["maxResponseLength", "safetyLevel"],
      properties: {
        maxResponseLength: { type: "number", minimum: 100, maximum: 4000 },
        allowExternalLinks: { type: "boolean" },
        allowCodeBlocks: { type: "boolean" },
        enableLoreMode: { type: "boolean" },
        enableTeachingMode: { type: "boolean" },
        enableSupportMode: { type: "boolean" },
        safetyLevel: { type: "string", enum: ["strict", "moderate", "relaxed"] },
      },
    },
    createdAt: { type: "string", format: "date-time" },
    updatedAt: { type: "string", format: "date-time" },
  },
} as const
