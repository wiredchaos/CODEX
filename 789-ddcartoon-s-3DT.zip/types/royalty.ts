// 789 Studios OTT - Royalty Types
// Hybrid Mode: Off-chain + On-chain royalty system for DD CARTOONS

/**
 * Royalty split percentages (normalized 0-1)
 * Standard Model: 40/20/20/10/10
 */
export interface RoyaltySplit {
  studio: number // 40% - DD CARTOONS
  creator: number // 20% - Episode creator(s)
  nftHolder: number // 20% - NFT/Licensed character owner
  treasury: number // 10% - Platform treasury
  stakers: number // 10% - $CARTOON token stakers
}

/**
 * Computed royalty amounts in USD
 */
export interface RoyaltyAmounts {
  studioAmount: number
  creatorAmount: number
  nftHolderAmount: number
  treasuryAmount: number
  stakersAmount: number
  totalAmount: number
}

/**
 * Combined royalty data for UI consumption
 */
export interface EpisodeRoyaltyMeta {
  episodeId: string
  episodeTitle: string
  totalRevenueUsd: number
  split: RoyaltySplit
  amounts: RoyaltyAmounts
  lastUpdated: string
  source: "mock" | "db" | "chain"
}

/**
 * IP License types for Rights Registry
 */
export type LicenseType = "Studio" | "Community" | "Commercial"

/**
 * IP License entry from Rights Registry
 */
export interface IPLicense {
  assetId: string
  assetName: string
  owner: string
  licenseType: LicenseType
  uri: string
  expiry: string | null
  permissionsMask: number
  restrictionsMask: number
  isActive: boolean
}

/**
 * Staking tiers based on $CARTOON holdings
 */
export type StakingTier = "Viewer" | "Member" | "Premium" | "Executive"

export interface StakingInfo {
  address: string
  stakedAmount: number
  tier: StakingTier
  tierIndex: number // 0-3
  lockPeriodDays: number
  unlockDate: string | null
}

/**
 * Episode data structure
 */
export interface Episode {
  id: string
  title: string
  description: string
  thumbnailUrl: string
  duration: number // seconds
  season: number
  episode: number
  releaseDate: string
  viewCount: number
  revenueUsd: number
  studioId: string
}

/**
 * Studio data structure
 */
export interface Studio {
  id: string
  name: string
  description: string
  logoUrl: string
  bannerUrl: string
  totalEpisodes: number
  totalRevenue: number
  createdAt: string
}

/**
 * Blockchain status for Hybrid Mode
 */
export interface BlockchainStatus {
  isConnected: boolean
  network: string
  rpcUrl: string | null
  contracts: {
    royaltyEngine: string | null
    rightsRegistry: string | null
    studioToken: string | null
    stakingVault: string | null
  }
  lastSyncTime: string | null
  mode: "off-chain" | "hybrid" | "on-chain"
}
