// Creator Codex Types
// Bot creation and NEURO PROMPT COMMAND integration

/**
 * Bot persona types defining the bot's role and behavior
 */
export type BotPersona =
  | "HOST" // Show hosts and presenters
  | "GUIDE" // Interactive guides and helpers
  | "TEACHER" // Educational content bots
  | "CONCIERGE" // Service and support bots
  | "NPC_STORY" // Story-driven NPCs
  | "SUPPORT" // Technical support agents

/**
 * Bot status for lifecycle management
 */
export type BotStatus = "draft" | "active" | "inactive" | "training"

/**
 * Creator Codex Bot Blueprint
 * Core entity for bot creation and NPC integration
 */
export interface CreatorCodexBot {
  id: string
  slug: string
  name: string
  description: string
  persona: BotPersona
  status: BotStatus

  // Studio linkage
  studioId: string
  ownerWallet: string

  // Visual identity
  avatarImageUrl?: string
  accentColor?: string

  // NEURO PROMPT COMMAND linkage
  npcWorldUrl: string // "https://npc.hyperfy.ai"
  npcLaunchUrl: string // Deep link with params
  npcConfigRef?: string // Optional config ID in Hyperfy

  // Show/Episode attachments
  attachedShows?: string[] // Episode IDs

  // IP & Royalties
  ipAssetId?: string // RightsRegistry asset ID
  royaltySplitId?: string // RoyaltyEngine split mapping
  revShareBps?: number // Creator % in basis points (e.g., 2000 = 20%)

  // Metadata
  isActive: boolean
  createdAt: string
  updatedAt: string
}

/**
 * Bot creation input
 */
export interface CreateBotInput {
  name: string
  slug?: string
  description?: string
  persona: BotPersona
  avatarImageUrl?: string
  accentColor?: string
  attachedShows?: string[]
  revShareBps?: number
}

/**
 * Bot statistics for dashboard
 */
export interface BotStats {
  botId: string
  totalInteractions: number
  uniqueUsers: number
  revenueGenerated: number
  lastActiveAt: string | null
}

/**
 * Persona display metadata
 */
export interface PersonaInfo {
  type: BotPersona
  label: string
  description: string
  icon: string // Lucide icon name
}

export const PERSONA_INFO: Record<BotPersona, PersonaInfo> = {
  HOST: {
    type: "HOST",
    label: "Show Host",
    description: "Presents shows and engages audiences",
    icon: "Mic2",
  },
  GUIDE: {
    type: "GUIDE",
    label: "Interactive Guide",
    description: "Leads users through experiences",
    icon: "Compass",
  },
  TEACHER: {
    type: "TEACHER",
    label: "Teacher",
    description: "Delivers educational content",
    icon: "GraduationCap",
  },
  CONCIERGE: {
    type: "CONCIERGE",
    label: "Concierge",
    description: "Provides service and recommendations",
    icon: "Bell",
  },
  NPC_STORY: {
    type: "NPC_STORY",
    label: "Story NPC",
    description: "Character in interactive narratives",
    icon: "Drama",
  },
  SUPPORT: {
    type: "SUPPORT",
    label: "Support Agent",
    description: "Handles technical assistance",
    icon: "HeadphonesIcon",
  },
}
