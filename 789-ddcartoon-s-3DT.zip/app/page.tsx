import type React from "react"
import { Navigation } from "@/components/navigation"
import { EpisodeCard } from "@/components/episode-card"
import { RoyaltyHUD } from "@/components/royalty-hud"
import { BlockchainStatusDashboard } from "@/components/blockchain-status"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { mockEpisodes, ddCartoonsStudio } from "@/lib/mock-data"
import { calculateAggregateRoyalties, formatCurrency } from "@/lib/royalty-engine"
import { Play, TrendingUp, Users, Film, ArrowRight } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function HomePage() {
  const featuredEpisode = mockEpisodes[4] // Doginal Dogs Crossover
  const recentEpisodes = mockEpisodes.slice(0, 4)
  const aggregateRoyalties = calculateAggregateRoyalties(mockEpisodes)

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main>
        {/* Hero Section */}
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-primary/10 via-background to-background" />
          <div className="relative max-w-7xl mx-auto px-4 py-16 sm:py-24">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <Badge className="bg-primary/20 text-primary border-primary/30">Now Streaming</Badge>
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground text-balance">
                  789 Studios
                  <span className="block text-primary">OTT Platform</span>
                </h1>
                <p className="text-lg text-muted-foreground max-w-xl text-pretty">
                  Smart TV streaming with blockchain-powered royalties. Watch DD CARTOONS originals while creators earn
                  through transparent, on-chain revenue distribution.
                </p>
                <div className="flex flex-wrap gap-4">
                  <Link href="/dd-cartoons">
                    <Button size="lg" className="gap-2 min-h-[48px]">
                      <Play className="w-5 h-5" />
                      Start Watching
                    </Button>
                  </Link>
                  <Link href="/royalties">
                    <Button size="lg" variant="outline" className="gap-2 min-h-[48px] bg-transparent">
                      <TrendingUp className="w-5 h-5" />
                      View Royalties
                    </Button>
                  </Link>
                </div>
              </div>

              {/* Featured Episode */}
              <div className="relative">
                <div className="aspect-video rounded-2xl overflow-hidden border border-border shadow-2xl">
                  <Image
                    src={featuredEpisode.thumbnailUrl || "/placeholder.svg"}
                    alt={featuredEpisode.title}
                    fill
                    className="object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-6">
                    <Badge className="bg-primary text-primary-foreground mb-2">Featured</Badge>
                    <h3 className="text-xl font-bold text-white mb-1">{featuredEpisode.title}</h3>
                    <p className="text-sm text-white/70">{featuredEpisode.description}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Bar */}
        <section className="border-y border-border bg-card/50">
          <div className="max-w-7xl mx-auto px-4 py-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
              <StatCard icon={Film} value={ddCartoonsStudio.totalEpisodes.toString()} label="Episodes" />
              <StatCard icon={Users} value="156K" label="Total Views" />
              <StatCard
                icon={TrendingUp}
                value={formatCurrency(aggregateRoyalties.totalAmount)}
                label="Total Revenue"
              />
              <StatCard icon={Play} value="40/20/20/10/10" label="Split Model" />
            </div>
          </div>
        </section>

        {/* Recent Episodes */}
        <section className="max-w-7xl mx-auto px-4 py-16">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold text-foreground">Latest Episodes</h2>
            <Link href="/dd-cartoons">
              <Button variant="ghost" className="gap-2">
                View All
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {recentEpisodes.map((episode) => (
              <EpisodeCard key={episode.id} episode={episode} />
            ))}
          </div>
        </section>

        {/* Royalty Preview */}
        <section className="max-w-7xl mx-auto px-4 py-16">
          <div className="grid lg:grid-cols-2 gap-8">
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-4">Transparent Royalty Distribution</h2>
              <p className="text-muted-foreground mb-6">
                Every stream, every sale - royalties are calculated and distributed using our 40/20/20/10/10 model. DD
                CARTOONS (Studio), Creators, NFT Holders, Treasury, and Token Stakers all benefit.
              </p>
              <RoyaltyHUD episodeId="ep-005" showRefresh={false} />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-4">Hybrid Mode Architecture</h2>
              <p className="text-muted-foreground mb-6">
                Combining off-chain speed with on-chain trust. The platform works immediately with mock data for TV app
                approvals, while Dogechain contracts can be activated for trustless royalty distribution.
              </p>
              <BlockchainStatusDashboard />
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-card/50 py-12">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <span className="text-sm font-bold text-primary-foreground">789</span>
            </div>
            <span className="font-bold">Studios OTT</span>
          </div>
          <p className="text-sm text-muted-foreground">
            Smart TV streaming with blockchain-powered royalties on Dogechain.
          </p>
          <p className="text-xs text-muted-foreground mt-4">© 2025 789 Studios × DD CARTOONS. Hybrid Mode v1.0</p>
        </div>
      </footer>
    </div>
  )
}

function StatCard({
  icon: Icon,
  value,
  label,
}: {
  icon: React.ComponentType<{ className?: string }>
  value: string
  label: string
}) {
  return (
    <div className="space-y-2">
      <Icon className="w-6 h-6 text-primary mx-auto" />
      <p className="text-2xl font-bold text-foreground">{value}</p>
      <p className="text-sm text-muted-foreground">{label}</p>
    </div>
  )
}
