import type React from "react"
import type { Metadata } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import { ResizeObserverFix } from "@/components/resize-observer-fix"
import "./globals.css"

const _geist = Geist({ subsets: ["latin"] })
const _geistMono = Geist_Mono({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "789 Studios OTT | DD CARTOONS",
  description:
    "Smart TV streaming platform with blockchain-powered royalties on Dogechain. Watch DD CARTOONS originals with transparent creator revenue distribution.",
  generator: "v0.app",
  keywords: ["OTT", "streaming", "blockchain", "royalties", "Dogechain", "NFT", "DD CARTOONS", "789 Studios"],
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark">
      <body className={`font-sans antialiased`}>
        <ResizeObserverFix />
        {children}
        <Analytics />
      </body>
    </html>
  )
}
