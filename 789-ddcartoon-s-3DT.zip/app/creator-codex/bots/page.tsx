// Bot List Page
// Displays all Creator Codex bots for the studio

import { Navigation } from "@/components/navigation"
import { BotCard } from "@/components/bot-card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { mockBots, mockBotStats } from "@/lib/mock-bots"
import { Plus, Bot } from "lucide-react"
import Link from "next/link"

export default function BotsListPage() {
  const botsWithStats = mockBots.map((bot) => ({
    bot,
    stats: mockBotStats.find((s) => s.botId === bot.id) || null,
  }))

  const activeBots = botsWithStats.filter((b) => b.bot.status === "active")
  const trainingBots = botsWithStats.filter((b) => b.bot.status === "training")
  const draftBots = botsWithStats.filter((b) => b.bot.status === "draft")

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="max-w-7xl mx-auto px-4 py-12">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Bot className="w-6 h-6 text-primary" />
              <h1 className="text-3xl font-bold text-foreground">Your Bots</h1>
            </div>
            <p className="text-muted-foreground">Manage your Creator Codex bot collection</p>
          </div>
          <Link href="/creator-codex/bots/new">
            <Button size="lg" className="gap-2 min-h-[48px]">
              <Plus className="w-5 h-5" />
              Create New Bot
            </Button>
          </Link>
        </div>

        {/* Active Bots */}
        {activeBots.length > 0 && (
          <section className="mb-12">
            <div className="flex items-center gap-2 mb-6">
              <h2 className="text-xl font-bold text-foreground">Active Bots</h2>
              <Badge variant="outline" className="bg-green-500/20 text-green-400 border-green-500/30">
                {activeBots.length}
              </Badge>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {activeBots.map(({ bot, stats }) => (
                <BotCard key={bot.id} bot={bot} stats={stats} />
              ))}
            </div>
          </section>
        )}

        {/* Training Bots */}
        {trainingBots.length > 0 && (
          <section className="mb-12">
            <div className="flex items-center gap-2 mb-6">
              <h2 className="text-xl font-bold text-foreground">In Training</h2>
              <Badge variant="outline" className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                {trainingBots.length}
              </Badge>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {trainingBots.map(({ bot, stats }) => (
                <BotCard key={bot.id} bot={bot} stats={stats} />
              ))}
            </div>
          </section>
        )}

        {/* Draft Bots */}
        {draftBots.length > 0 && (
          <section className="mb-12">
            <div className="flex items-center gap-2 mb-6">
              <h2 className="text-xl font-bold text-foreground">Drafts</h2>
              <Badge variant="outline" className="bg-muted text-muted-foreground">
                {draftBots.length}
              </Badge>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {draftBots.map(({ bot, stats }) => (
                <BotCard key={bot.id} bot={bot} stats={stats} />
              ))}
            </div>
          </section>
        )}

        {/* Empty State */}
        {mockBots.length === 0 && (
          <div className="text-center py-16">
            <Bot className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-xl font-bold text-foreground mb-2">No Bots Yet</h2>
            <p className="text-muted-foreground mb-6">Create your first bot to get started with Creator Codex.</p>
            <Link href="/creator-codex/bots/new">
              <Button size="lg" className="gap-2">
                <Plus className="w-5 h-5" />
                Create Your First Bot
              </Button>
            </Link>
          </div>
        )}
      </main>
    </div>
  )
}
