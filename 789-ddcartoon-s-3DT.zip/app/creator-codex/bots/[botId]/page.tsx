// Bot Detail Page
// View and manage a single bot

import { Navigation } from "@/components/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { getBotById, getBotStatsById } from "@/lib/mock-bots"
import { getEpisodeById } from "@/lib/mock-data"
import { PERSONA_INFO } from "@/types/creator-codex"
import { getPersonaColor, formatBps } from "@/lib/creator-codex"
import {
  ExternalLink,
  ArrowLeft,
  Zap,
  Users,
  DollarSign,
  Film,
  Shield,
  Edit,
  Mic2,
  Compass,
  GraduationCap,
  Bell,
  Drama,
  Headphones,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { notFound } from "next/navigation"

const iconMap = {
  Mic2,
  Compass,
  GraduationCap,
  Bell,
  Drama,
  HeadphonesIcon: Headphones,
}

export default async function BotDetailPage({
  params,
}: {
  params: Promise<{ botId: string }>
}) {
  const { botId } = await params
  const bot = getBotById(botId)
  const stats = getBotStatsById(botId)

  if (!bot) {
    notFound()
  }

  const personaInfo = PERSONA_INFO[bot.persona]
  const IconComponent = iconMap[personaInfo.icon as keyof typeof iconMap] || Mic2
  const attachedEpisodes = (bot.attachedShows || []).map((id) => getEpisodeById(id)).filter(Boolean)

  const statusColors = {
    draft: "bg-muted text-muted-foreground",
    active: "bg-green-500/20 text-green-400 border-green-500/30",
    inactive: "bg-red-500/20 text-red-400 border-red-500/30",
    training: "bg-amber-500/20 text-amber-400 border-amber-500/30",
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="max-w-7xl mx-auto px-4 py-12">
        {/* Back Link */}
        <Link
          href="/creator-codex/bots"
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Bots
        </Link>

        {/* Header */}
        <div className="flex flex-col lg:flex-row gap-8 mb-12">
          {/* Avatar Card */}
          <Card
            className="lg:w-80 shrink-0 overflow-hidden border-border"
            style={{ borderColor: `${bot.accentColor}40` }}
          >
            <div
              className="h-48 flex items-center justify-center relative"
              style={{ backgroundColor: `${bot.accentColor}20` }}
            >
              <div className="absolute inset-0 bg-gradient-to-b from-transparent to-card" />
              {bot.avatarImageUrl ? (
                <Image
                  src={bot.avatarImageUrl || "/placeholder.svg"}
                  alt={bot.name}
                  width={120}
                  height={120}
                  className="rounded-full border-4 border-card relative z-10"
                />
              ) : (
                <div
                  className="w-28 h-28 rounded-full border-4 border-card flex items-center justify-center relative z-10"
                  style={{ backgroundColor: bot.accentColor }}
                >
                  <IconComponent className="w-14 h-14 text-white" />
                </div>
              )}
            </div>
            <CardContent className="p-6 text-center">
              <h1 className="text-2xl font-bold text-foreground mb-2">{bot.name}</h1>
              <div className="flex items-center justify-center gap-2 mb-4">
                <Badge variant="outline" className={statusColors[bot.status]}>
                  {bot.status}
                </Badge>
                <Badge variant="outline" className={getPersonaColor(bot.persona)}>
                  <IconComponent className="w-3 h-3 mr-1" />
                  {personaInfo.label}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground mb-6">{bot.description}</p>

              <div className="space-y-2">
                <a href={bot.npcLaunchUrl} target="_blank" rel="noopener noreferrer" className="block">
                  <Button className="w-full gap-2" disabled={bot.status !== "active"}>
                    <ExternalLink className="w-4 h-4" />
                    Launch in NEURO PROMPT COMMAND
                  </Button>
                </a>
                <Button variant="outline" className="w-full gap-2 bg-transparent">
                  <Edit className="w-4 h-4" />
                  Edit Bot
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Details */}
          <div className="flex-1 space-y-6">
            {/* Stats */}
            {stats && (
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle>Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
                    <div className="text-center">
                      <Zap className="w-6 h-6 text-primary mx-auto mb-2" />
                      <p className="text-2xl font-bold text-foreground">{stats.totalInteractions.toLocaleString()}</p>
                      <p className="text-sm text-muted-foreground">Interactions</p>
                    </div>
                    <div className="text-center">
                      <Users className="w-6 h-6 text-blue-400 mx-auto mb-2" />
                      <p className="text-2xl font-bold text-foreground">{stats.uniqueUsers.toLocaleString()}</p>
                      <p className="text-sm text-muted-foreground">Unique Users</p>
                    </div>
                    <div className="text-center">
                      <DollarSign className="w-6 h-6 text-green-400 mx-auto mb-2" />
                      <p className="text-2xl font-bold text-foreground">${stats.revenueGenerated.toFixed(2)}</p>
                      <p className="text-sm text-muted-foreground">Revenue</p>
                    </div>
                    <div className="text-center">
                      <Shield className="w-6 h-6 text-amber-400 mx-auto mb-2" />
                      <p className="text-2xl font-bold text-foreground">{formatBps(bot.revShareBps || 0)}</p>
                      <p className="text-sm text-muted-foreground">Rev Share</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* NPC Link */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle>NEURO PROMPT COMMAND Integration</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">World URL</p>
                  <p className="font-mono text-sm text-foreground bg-muted px-3 py-2 rounded-lg">{bot.npcWorldUrl}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Launch URL</p>
                  <p className="font-mono text-xs text-foreground bg-muted px-3 py-2 rounded-lg break-all">
                    {bot.npcLaunchUrl}
                  </p>
                </div>
                {bot.npcConfigRef && (
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Config Ref</p>
                    <p className="font-mono text-sm text-foreground">{bot.npcConfigRef}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Attached Shows */}
            {attachedEpisodes.length > 0 && (
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Film className="w-5 h-5" />
                    Attached Shows
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {attachedEpisodes.map(
                      (episode) =>
                        episode && (
                          <div key={episode.id} className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                            <div className="w-16 h-10 rounded bg-muted overflow-hidden">
                              <Image
                                src={episode.thumbnailUrl || "/placeholder.svg"}
                                alt={episode.title}
                                width={64}
                                height={40}
                                className="object-cover w-full h-full"
                              />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-medium text-foreground text-sm truncate">{episode.title}</p>
                              <p className="text-xs text-muted-foreground">
                                S{episode.season} E{episode.episode}
                              </p>
                            </div>
                            <Link href="/dd-cartoons">
                              <Button variant="ghost" size="sm">
                                View
                              </Button>
                            </Link>
                          </div>
                        ),
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* IP & Royalties */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle>IP & Royalty Configuration</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground mb-1">IP Asset ID</p>
                    <p className="font-mono text-sm text-foreground">{bot.ipAssetId || "Not linked"}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground mb-1">Royalty Split ID</p>
                    <p className="font-mono text-sm text-foreground">{bot.royaltySplitId || "Default split"}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground mb-1">Owner Wallet</p>
                    <p className="font-mono text-sm text-foreground truncate">{bot.ownerWallet}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground mb-1">Studio</p>
                    <p className="font-mono text-sm text-foreground">{bot.studioId}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
