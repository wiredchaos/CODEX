// New Bot Page
// Bot creation form

import { Navigation } from "@/components/navigation"
import { BotCreateForm } from "@/components/bot-create-form"
import { Badge } from "@/components/ui/badge"
import { Sparkles } from "lucide-react"

export default function NewBotPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="max-w-7xl mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <Badge className="bg-primary/20 text-primary border-primary/30 mb-4">
            <Sparkles className="w-3 h-3 mr-1" />
            Creator Codex
          </Badge>
          <h1 className="text-3xl font-bold text-foreground mb-2">Create New Bot</h1>
          <p className="text-muted-foreground">Design a bot blueprint to deploy in NEURO PROMPT COMMAND</p>
        </div>

        {/* Form */}
        <BotCreateForm />
      </main>
    </div>
  )
}
