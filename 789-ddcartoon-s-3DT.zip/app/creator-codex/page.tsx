// Creator Codex Hub Page
// Main entry point for bot creation studio

import { Navigation } from "@/components/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { mockBots } from "@/lib/mock-bots"
import { getActiveBots } from "@/lib/mock-bots"
import { Bot, Sparkles, Zap, Shield, ExternalLink } from "lucide-react"
import Link from "next/link"

export default function CreatorCodexPage() {
  const activeBots = getActiveBots()
  const totalBots = mockBots.length

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="max-w-7xl mx-auto px-4 py-12">
        {/* Hero */}
        <section className="text-center mb-16">
          <Badge className="bg-primary/20 text-primary border-primary/30 mb-4">Bot Workshop</Badge>
          <h1 className="text-4xl sm:text-5xl font-bold text-foreground mb-4 text-balance">Creator Codex</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8 text-pretty">
            Design and deploy intelligent bots for your shows, experiences, and communities. Train them in NEURO PROMPT
            COMMAND at npc.hyperfy.ai.
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Link href="/creator-codex/bots/new">
              <Button size="lg" className="gap-2 min-h-[48px]">
                <Sparkles className="w-5 h-5" />
                Create New Bot
              </Button>
            </Link>
            <Link href="/creator-codex/bots">
              <Button size="lg" variant="outline" className="gap-2 min-h-[48px] bg-transparent">
                <Bot className="w-5 h-5" />
                View All Bots ({totalBots})
              </Button>
            </Link>
          </div>
        </section>

        {/* Stats */}
        <section className="grid sm:grid-cols-3 gap-6 mb-16">
          <Card className="bg-card border-border">
            <CardContent className="p-6 text-center">
              <Bot className="w-8 h-8 text-primary mx-auto mb-3" />
              <p className="text-3xl font-bold text-foreground">{totalBots}</p>
              <p className="text-sm text-muted-foreground">Total Bots</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-6 text-center">
              <Zap className="w-8 h-8 text-green-400 mx-auto mb-3" />
              <p className="text-3xl font-bold text-foreground">{activeBots.length}</p>
              <p className="text-sm text-muted-foreground">Active Bots</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-6 text-center">
              <Shield className="w-8 h-8 text-amber-400 mx-auto mb-3" />
              <p className="text-3xl font-bold text-foreground">IP + Royalty</p>
              <p className="text-sm text-muted-foreground">On-Chain Ready</p>
            </CardContent>
          </Card>
        </section>

        {/* How It Works */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-foreground mb-8 text-center">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold text-primary">1</span>
              </div>
              <h3 className="font-bold text-foreground mb-2">Design Your Bot</h3>
              <p className="text-sm text-muted-foreground">
                Choose a persona, set visual identity, and attach to shows or episodes.
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold text-primary">2</span>
              </div>
              <h3 className="font-bold text-foreground mb-2">Launch in NPC</h3>
              <p className="text-sm text-muted-foreground">
                Train and refine your bot in NEURO PROMPT COMMAND at npc.hyperfy.ai.
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold text-primary">3</span>
              </div>
              <h3 className="font-bold text-foreground mb-2">Earn Revenue</h3>
              <p className="text-sm text-muted-foreground">
                Bot interactions drive royalties through the 789 Studios hybrid system.
              </p>
            </div>
          </div>
        </section>

        {/* NPC Integration */}
        <section className="mb-16">
          <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
            <CardContent className="p-8 sm:p-12 flex flex-col lg:flex-row items-center gap-8">
              <div className="flex-1 space-y-4">
                <Badge className="bg-primary/20 text-primary border-primary/30">Powered By</Badge>
                <h2 className="text-3xl font-bold text-foreground">NEURO PROMPT COMMAND</h2>
                <p className="text-muted-foreground text-pretty">
                  The 3D prompt console and agent training arena at npc.hyperfy.ai. Every bot you create in Creator
                  Codex can be launched directly into NEURO PROMPT COMMAND for advanced training, testing, and
                  deployment across Hyperfy worlds.
                </p>
                <a href="https://npc.hyperfy.ai" target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" className="gap-2 bg-transparent">
                    <ExternalLink className="w-4 h-4" />
                    Visit npc.hyperfy.ai
                  </Button>
                </a>
              </div>
              <div className="w-full lg:w-80 aspect-video rounded-xl bg-card border border-border flex items-center justify-center">
                <div className="text-center">
                  <Bot className="w-16 h-16 text-primary mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">NPC Training Arena</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Quick Actions */}
        <section>
          <h2 className="text-2xl font-bold text-foreground mb-6">Quick Actions</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Link href="/creator-codex/bots/new">
              <Card className="bg-card border-border hover:border-primary/50 transition-all cursor-pointer group">
                <CardContent className="p-6">
                  <Sparkles className="w-6 h-6 text-primary mb-3 group-hover:scale-110 transition-transform" />
                  <h3 className="font-bold text-foreground mb-1">New Bot</h3>
                  <p className="text-xs text-muted-foreground">Create a new bot blueprint</p>
                </CardContent>
              </Card>
            </Link>
            <Link href="/creator-codex/bots">
              <Card className="bg-card border-border hover:border-primary/50 transition-all cursor-pointer group">
                <CardContent className="p-6">
                  <Bot className="w-6 h-6 text-blue-400 mb-3 group-hover:scale-110 transition-transform" />
                  <h3 className="font-bold text-foreground mb-1">Manage Bots</h3>
                  <p className="text-xs text-muted-foreground">View and edit your bots</p>
                </CardContent>
              </Card>
            </Link>
            <Link href="/licenses">
              <Card className="bg-card border-border hover:border-primary/50 transition-all cursor-pointer group">
                <CardContent className="p-6">
                  <Shield className="w-6 h-6 text-green-400 mb-3 group-hover:scale-110 transition-transform" />
                  <h3 className="font-bold text-foreground mb-1">IP Licenses</h3>
                  <p className="text-xs text-muted-foreground">Manage bot IP rights</p>
                </CardContent>
              </Card>
            </Link>
            <Link href="/royalties">
              <Card className="bg-card border-border hover:border-primary/50 transition-all cursor-pointer group">
                <CardContent className="p-6">
                  <Zap className="w-6 h-6 text-amber-400 mb-3 group-hover:scale-110 transition-transform" />
                  <h3 className="font-bold text-foreground mb-1">Bot Revenue</h3>
                  <p className="text-xs text-muted-foreground">Track bot earnings</p>
                </CardContent>
              </Card>
            </Link>
          </div>
        </section>
      </main>
    </div>
  )
}
