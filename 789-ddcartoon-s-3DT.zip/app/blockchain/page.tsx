import type React from "react"
import { Navigation } from "@/components/navigation"
import { BlockchainStatusDashboard } from "@/components/blockchain-status"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Code2, FileCode, Shield, BookOpen, ExternalLink, Terminal, GitBranch } from "lucide-react"

export default function BlockchainPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Blockchain Integration</h1>
          <p className="text-muted-foreground">
            Dogechain smart contracts for trustless royalty distribution and IP rights management.
          </p>
        </div>

        {/* Status Dashboard */}
        <section className="mb-8">
          <BlockchainStatusDashboard />
        </section>

        {/* Contract Documentation */}
        <section className="grid md:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Code2 className="w-5 h-5 text-primary" />
                Royalty Engine
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">
                ERC-2981 compatible contract for managing per-episode royalty splits in basis points (BPS).
              </p>
              <div className="space-y-2">
                <FunctionDoc name="setSplit" params="episodeId, Split" />
                <FunctionDoc name="getSplit" params="episodeId" />
                <FunctionDoc name="royaltyInfo" params="episodeId, salePrice" />
              </div>
              <Badge variant="outline">contracts/RoyaltyEngine.sol</Badge>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-primary" />
                Rights Registry
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Tracks IP licenses by assetId. Records owner, license type, URI, expiry, and permission masks.
              </p>
              <div className="space-y-2">
                <FunctionDoc name="registerLicense" params="assetId, LicenseData" />
                <FunctionDoc name="getLicense" params="assetId" />
                <FunctionDoc name="verifyPermission" params="assetId, permissionBit" />
              </div>
              <Badge variant="outline">contracts/RightsRegistry.sol</Badge>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileCode className="w-5 h-5 text-primary" />
                Studio Token ($CARTOON)
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">
                ERC-20 utility token for DD CARTOONS. Used for staking, tier upgrades, and future governance.
              </p>
              <div className="space-y-2">
                <FunctionDoc name="transfer" params="to, amount" />
                <FunctionDoc name="approve" params="spender, amount" />
                <FunctionDoc name="balanceOf" params="address" />
              </div>
              <Badge variant="outline">contracts/StudioToken.sol</Badge>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GitBranch className="w-5 h-5 text-primary" />
                Staking Vault
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Stake $CARTOON with lock periods (30/60/90 days) to earn tier status: Viewer, Member, Premium,
                Executive.
              </p>
              <div className="space-y-2">
                <FunctionDoc name="stake" params="amount, lockDays" />
                <FunctionDoc name="unstake" params="" />
                <FunctionDoc name="getTier" params="address" />
              </div>
              <Badge variant="outline">contracts/StakingVault.sol</Badge>
            </CardContent>
          </Card>
        </section>

        {/* Environment Setup */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Terminal className="w-5 h-5 text-primary" />
              Environment Configuration
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Set these environment variables in Vercel to enable Hybrid Mode:
            </p>
            <div className="bg-muted rounded-lg p-4 font-mono text-sm space-y-2">
              <EnvVar name="DOGECHAIN_RPC_URL" example="https://rpc.dogechain.dog" />
              <EnvVar name="ROYALTY_ENGINE_ADDRESS" example="0x..." />
              <EnvVar name="RIGHTS_REGISTRY_ADDRESS" example="0x..." />
              <EnvVar name="STUDIO_TOKEN_ADDRESS" example="0x..." />
              <EnvVar name="STAKING_VAULT_ADDRESS" example="0x..." />
            </div>
          </CardContent>
        </Card>

        {/* Documentation Links */}
        <section className="mt-8 grid md:grid-cols-3 gap-4">
          <DocLink icon={BookOpen} title="Architecture Guide" description="Full Hybrid Mode documentation" href="#" />
          <DocLink icon={Code2} title="API Reference" description="Royalty and blockchain API docs" href="#" />
          <DocLink icon={GitBranch} title="Developer Onboarding" description="Setup guide for new engineers" href="#" />
        </section>
      </main>
    </div>
  )
}

function FunctionDoc({ name, params }: { name: string; params: string }) {
  return (
    <div className="flex items-center gap-2 text-sm">
      <span className="text-primary font-mono">{name}</span>
      <span className="text-muted-foreground">({params})</span>
    </div>
  )
}

function EnvVar({ name, example }: { name: string; example: string }) {
  return (
    <div className="flex flex-wrap gap-2">
      <span className="text-primary">{name}</span>
      <span className="text-muted-foreground">=</span>
      <span className="text-foreground">{example}</span>
    </div>
  )
}

function DocLink({
  icon: Icon,
  title,
  description,
  href,
}: {
  icon: React.ComponentType<{ className?: string }>
  title: string
  description: string
  href: string
}) {
  return (
    <a href={href} className="block">
      <Card className="hover:border-primary/50 transition-colors">
        <CardContent className="p-4 flex items-center gap-4">
          <div className="p-3 rounded-lg bg-primary/10">
            <Icon className="w-5 h-5 text-primary" />
          </div>
          <div className="flex-1">
            <p className="font-medium text-foreground">{title}</p>
            <p className="text-sm text-muted-foreground">{description}</p>
          </div>
          <ExternalLink className="w-4 h-4 text-muted-foreground" />
        </CardContent>
      </Card>
    </a>
  )
}
