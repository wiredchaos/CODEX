import type React from "react"
import { Navigation } from "@/components/navigation"
import { RoyaltyHUD } from "@/components/royalty-hud"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { mockEpisodes } from "@/lib/mock-data"
import { calculateRoyaltySplit, formatCurrency, formatPercentage, DEFAULT_SPLIT } from "@/lib/royalty-engine"
import { Building2, User, ImageIcon, Landmark, Users, TrendingUp } from "lucide-react"

export default function RoyaltiesPage() {
  const totalRevenue = mockEpisodes.reduce((sum, ep) => sum + ep.revenueUsd, 0)
  const aggregateSplit = calculateRoyaltySplit(totalRevenue)

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Royalty Dashboard</h1>
          <p className="text-muted-foreground">
            Track revenue distribution across all DD CARTOONS episodes using the 40/20/20/10/10 model.
          </p>
        </div>

        {/* Aggregate Stats */}
        <section className="grid md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
          <SplitStatCard
            icon={Building2}
            label="DD CARTOONS"
            percentage={DEFAULT_SPLIT.studio}
            amount={aggregateSplit.studioAmount}
            color="text-primary"
          />
          <SplitStatCard
            icon={User}
            label="Creators"
            percentage={DEFAULT_SPLIT.creator}
            amount={aggregateSplit.creatorAmount}
            color="text-blue-400"
          />
          <SplitStatCard
            icon={ImageIcon}
            label="NFT Holders"
            percentage={DEFAULT_SPLIT.nftHolder}
            amount={aggregateSplit.nftHolderAmount}
            color="text-purple-400"
          />
          <SplitStatCard
            icon={Landmark}
            label="Treasury"
            percentage={DEFAULT_SPLIT.treasury}
            amount={aggregateSplit.treasuryAmount}
            color="text-amber-400"
          />
          <SplitStatCard
            icon={Users}
            label="Stakers"
            percentage={DEFAULT_SPLIT.stakers}
            amount={aggregateSplit.stakersAmount}
            color="text-green-400"
          />
        </section>

        {/* Total Revenue */}
        <Card className="mb-8 glow-gold">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-4 rounded-xl bg-primary/20">
                  <TrendingUp className="w-8 h-8 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Platform Revenue</p>
                  <p className="text-4xl font-bold text-primary">{formatCurrency(totalRevenue)}</p>
                </div>
              </div>
              <Badge variant="outline" className="text-lg px-4 py-2">
                {mockEpisodes.length} Episodes
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Per-Episode Breakdown */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Per-Episode Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Episode</TableHead>
                    <TableHead className="text-right">Revenue</TableHead>
                    <TableHead className="text-right">Studio (40%)</TableHead>
                    <TableHead className="text-right">Creator (20%)</TableHead>
                    <TableHead className="text-right">NFT (20%)</TableHead>
                    <TableHead className="text-right">Treasury (10%)</TableHead>
                    <TableHead className="text-right">Stakers (10%)</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockEpisodes.map((episode) => {
                    const split = calculateRoyaltySplit(episode.revenueUsd)
                    return (
                      <TableRow key={episode.id}>
                        <TableCell>
                          <div>
                            <p className="font-medium">{episode.title}</p>
                            <p className="text-xs text-muted-foreground">
                              S{episode.season} E{episode.episode}
                            </p>
                          </div>
                        </TableCell>
                        <TableCell className="text-right font-medium">{formatCurrency(episode.revenueUsd)}</TableCell>
                        <TableCell className="text-right text-primary">{formatCurrency(split.studioAmount)}</TableCell>
                        <TableCell className="text-right text-blue-400">
                          {formatCurrency(split.creatorAmount)}
                        </TableCell>
                        <TableCell className="text-right text-purple-400">
                          {formatCurrency(split.nftHolderAmount)}
                        </TableCell>
                        <TableCell className="text-right text-amber-400">
                          {formatCurrency(split.treasuryAmount)}
                        </TableCell>
                        <TableCell className="text-right text-green-400">
                          {formatCurrency(split.stakersAmount)}
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Episode Detail HUD */}
        <section>
          <h2 className="text-xl font-bold text-foreground mb-4">Episode Detail View</h2>
          <RoyaltyHUD episodeId="ep-004" />
        </section>
      </main>
    </div>
  )
}

function SplitStatCard({
  icon: Icon,
  label,
  percentage,
  amount,
  color,
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  percentage: number
  amount: number
  color: string
}) {
  return (
    <Card>
      <CardContent className="p-4 text-center">
        <Icon className={`w-6 h-6 mx-auto mb-2 ${color}`} />
        <p className="text-xs text-muted-foreground mb-1">{label}</p>
        <p className={`text-2xl font-bold ${color}`}>{formatPercentage(percentage)}</p>
        <p className="text-sm text-foreground">{formatCurrency(amount)}</p>
      </CardContent>
    </Card>
  )
}
