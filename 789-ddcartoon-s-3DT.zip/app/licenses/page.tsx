import type React from "react"
import { Navigation } from "@/components/navigation"
import { IPLicensesTable } from "@/components/ip-licenses-table"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { mockIPLicenses } from "@/lib/mock-data"
import { licenseColors } from "@/lib/styles"
import { Shield, Building2, Users, Briefcase } from "lucide-react"

export default function LicensesPage() {
  const studioLicenses = mockIPLicenses.filter((l) => l.licenseType === "Studio")
  const communityLicenses = mockIPLicenses.filter((l) => l.licenseType === "Community")
  const commercialLicenses = mockIPLicenses.filter((l) => l.licenseType === "Commercial")
  const activeLicenses = mockIPLicenses.filter((l) => l.isActive)

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">IP Licenses</h1>
          <p className="text-muted-foreground">
            Rights Registry for DD CARTOONS characters and assets. Managed on-chain via Dogechain.
          </p>
        </div>

        {/* License Stats */}
        <section className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <LicenseStatCard icon={Shield} value={mockIPLicenses.length} label="Total Licenses" color="text-foreground" />
          <LicenseStatCard icon={Building2} value={studioLicenses.length} label="Studio Owned" color="text-primary" />
          <LicenseStatCard icon={Users} value={communityLicenses.length} label="Community" color="text-blue-400" />
          <LicenseStatCard
            icon={Briefcase}
            value={commercialLicenses.length}
            label="Commercial"
            color="text-green-400"
          />
        </section>

        {/* License Types Info */}
        <section className="grid md:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <Badge className={`${licenseColors.Studio} w-fit`}>Studio</Badge>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Full ownership by DD CARTOONS. Perpetual rights for all usage types including streaming, merch, ads, and
                external licensing.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <Badge className={`${licenseColors.Community} w-fit`}>Community</Badge>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Licensed from community NFT holders (e.g., Doginal Dogs). Limited permissions, time-bound, requires
                royalty payments to NFT owner.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <Badge className={`${licenseColors.Commercial} w-fit`}>Commercial</Badge>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                External IP partnerships. Strict usage limits defined in contract. Typically streaming-only with
                specific expiration dates.
              </p>
            </CardContent>
          </Card>
        </section>

        {/* Full Licenses Table */}
        <IPLicensesTable licenses={mockIPLicenses} title="All Registered IP" />

        {/* Active Only */}
        <section className="mt-8">
          <IPLicensesTable licenses={activeLicenses} title="Active Licenses" />
        </section>
      </main>
    </div>
  )
}

function LicenseStatCard({
  icon: Icon,
  value,
  label,
  color,
}: {
  icon: React.ComponentType<{ className?: string }>
  value: number
  label: string
  color: string
}) {
  return (
    <Card>
      <CardContent className="p-4 flex items-center gap-4">
        <div className="p-3 rounded-lg bg-muted">
          <Icon className={`w-5 h-5 ${color}`} />
        </div>
        <div>
          <p className={`text-2xl font-bold ${color}`}>{value}</p>
          <p className="text-sm text-muted-foreground">{label}</p>
        </div>
      </CardContent>
    </Card>
  )
}
