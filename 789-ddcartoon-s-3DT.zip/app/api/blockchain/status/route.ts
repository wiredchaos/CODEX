import { NextResponse } from "next/server"
import { getBlockchainStatus } from "@/lib/royalty-chain"

export async function GET() {
  try {
    const status = getBlockchainStatus()
    return NextResponse.json(status)
  } catch (error) {
    console.error("[API] Blockchain status error:", error)
    return NextResponse.json({ error: "Failed to get blockchain status" }, { status: 500 })
  }
}
