// Creator Codex Bot API
// GET: List bots for studio
// POST: Create new bot

import { NextResponse } from "next/server"
import { mockBots, mockBotStats } from "@/lib/mock-bots"
import { createBot } from "@/lib/creator-codex"
import type { CreateBotInput } from "@/types/creator-codex"

// Simulated current studio (in production, from auth/session)
const MOCK_STUDIO = {
  id: "dd-cartoons",
  ownerWallet: "0x789Studios...abc1",
}

export async function GET() {
  // In production: const studio = await getCurrentStudio()
  const studio = MOCK_STUDIO

  const bots = mockBots.filter((bot) => bot.studioId === studio.id)

  // Enrich with stats
  const botsWithStats = bots.map((bot) => {
    const stats = mockBotStats.find((s) => s.botId === bot.id)
    return { ...bot, stats: stats || null }
  })

  return NextResponse.json({
    bots: botsWithStats,
    studioId: studio.id,
    total: botsWithStats.length,
  })
}

export async function POST(req: Request) {
  try {
    const studio = MOCK_STUDIO
    const body: CreateBotInput = await req.json()

    // Validate required fields
    if (!body.name || !body.persona) {
      return NextResponse.json({ error: "Name and persona are required" }, { status: 400 })
    }

    // Create bot with NPC URL
    const newBot = createBot(body, studio.id, studio.ownerWallet)

    // In production: await saveBot(newBot)
    // For mock: just return the created bot

    return NextResponse.json(newBot, { status: 201 })
  } catch (error) {
    console.error("Failed to create bot:", error)
    return NextResponse.json({ error: "Failed to create bot" }, { status: 500 })
  }
}
