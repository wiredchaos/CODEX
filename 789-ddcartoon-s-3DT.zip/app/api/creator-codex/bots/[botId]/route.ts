// Creator Codex Bot Detail API
// GET: Get single bot
// PATCH: Update bot
// DELETE: Delete bot

import { NextResponse } from "next/server"
import { mockBots, mockBotStats } from "@/lib/mock-bots"
import { buildNpcLaunchUrl } from "@/lib/creator-codex"

export async function GET(req: Request, { params }: { params: Promise<{ botId: string }> }) {
  const { botId } = await params

  const bot = mockBots.find((b) => b.id === botId)

  if (!bot) {
    return NextResponse.json({ error: "Bot not found" }, { status: 404 })
  }

  const stats = mockBotStats.find((s) => s.botId === botId)

  return NextResponse.json({
    bot,
    stats: stats || null,
  })
}

export async function PATCH(req: Request, { params }: { params: Promise<{ botId: string }> }) {
  try {
    const { botId } = await params
    const updates = await req.json()

    const botIndex = mockBots.findIndex((b) => b.id === botId)

    if (botIndex === -1) {
      return NextResponse.json({ error: "Bot not found" }, { status: 404 })
    }

    // Apply updates
    const updatedBot = {
      ...mockBots[botIndex],
      ...updates,
      updatedAt: new Date().toISOString(),
    }

    // Regenerate NPC URL if relevant fields changed
    if (updates.name || updates.persona || updates.avatarImageUrl) {
      updatedBot.npcLaunchUrl = buildNpcLaunchUrl(updatedBot)
    }

    // In production: await updateBot(botId, updatedBot)

    return NextResponse.json(updatedBot)
  } catch (error) {
    console.error("Failed to update bot:", error)
    return NextResponse.json({ error: "Failed to update bot" }, { status: 500 })
  }
}

export async function DELETE(req: Request, { params }: { params: Promise<{ botId: string }> }) {
  const { botId } = await params

  const bot = mockBots.find((b) => b.id === botId)

  if (!bot) {
    return NextResponse.json({ error: "Bot not found" }, { status: 404 })
  }

  // In production: await deleteBot(botId)

  return NextResponse.json({ success: true, deletedId: botId })
}
