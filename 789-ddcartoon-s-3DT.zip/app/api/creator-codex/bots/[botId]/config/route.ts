// NPC Config API Route
// Manages bot system prompt configurations

import { NextResponse } from "next/server"
import type { NpcBotConfig } from "@/types/npc-config"
import { createDefaultNpcConfig, validateNpcConfig } from "@/types/npc-config"
import { mockBots } from "@/lib/mock-bots"

// In-memory config store (replace with DB in production)
const configStore = new Map<string, NpcBotConfig>()

export async function GET(request: Request, { params }: { params: Promise<{ botId: string }> }) {
  const { botId } = await params

  // Find the bot
  const bot = mockBots.find((b) => b.id === botId)
  if (!bot) {
    return NextResponse.json({ error: "Bot not found" }, { status: 404 })
  }

  // Get or create default config
  let config = configStore.get(botId)
  if (!config) {
    config = createDefaultNpcConfig(botId, bot.persona)
    configStore.set(botId, config)
  }

  return NextResponse.json(config)
}

export async function PUT(request: Request, { params }: { params: Promise<{ botId: string }> }) {
  const { botId } = await params

  // Find the bot
  const bot = mockBots.find((b) => b.id === botId)
  if (!bot) {
    return NextResponse.json({ error: "Bot not found" }, { status: 404 })
  }

  const body = await request.json()

  // Merge with existing or default config
  const existingConfig = configStore.get(botId) || createDefaultNpcConfig(botId, bot.persona)
  const updatedConfig: NpcBotConfig = {
    ...existingConfig,
    ...body,
    botId, // Ensure botId cannot be overwritten
    updatedAt: new Date().toISOString(),
  }

  // Validate
  if (!validateNpcConfig(updatedConfig)) {
    return NextResponse.json({ error: "Invalid config format" }, { status: 400 })
  }

  configStore.set(botId, updatedConfig)

  return NextResponse.json(updatedConfig)
}

export async function PATCH(request: Request, { params }: { params: Promise<{ botId: string }> }) {
  const { botId } = await params

  // Find the bot
  const bot = mockBots.find((b) => b.id === botId)
  if (!bot) {
    return NextResponse.json({ error: "Bot not found" }, { status: 404 })
  }

  const body = await request.json()

  // Get existing or default
  const existingConfig = configStore.get(botId) || createDefaultNpcConfig(botId, bot.persona)

  // Deep merge for nested objects
  const updatedConfig: NpcBotConfig = {
    ...existingConfig,
    ...body,
    overrides: {
      ...existingConfig.overrides,
      ...(body.overrides || {}),
    },
    behavior: {
      ...existingConfig.behavior,
      ...(body.behavior || {}),
    },
    focusAreas: body.focusAreas ?? existingConfig.focusAreas,
    avoidTopics: body.avoidTopics ?? existingConfig.avoidTopics,
    botId,
    updatedAt: new Date().toISOString(),
  }

  configStore.set(botId, updatedConfig)

  return NextResponse.json(updatedConfig)
}
