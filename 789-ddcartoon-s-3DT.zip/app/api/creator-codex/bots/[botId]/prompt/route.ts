// NPC System Prompt API Route
// Returns the generated system prompt for a bot

import { NextResponse } from "next/server"
import { mockBots } from "@/lib/mock-bots"
import { buildNpcSystemPrompt, getPromptPreview } from "@/lib/npc-prompts"
import { createDefaultNpcConfig } from "@/types/npc-config"

// In-memory config store reference (shared with config route in real app)
const configStore = new Map()

export async function GET(request: Request, { params }: { params: Promise<{ botId: string }> }) {
  const { botId } = await params
  const { searchParams } = new URL(request.url)
  const preview = searchParams.get("preview") === "true"
  const maxLength = Number.parseInt(searchParams.get("maxLength") || "500", 10)

  // Find the bot
  const bot = mockBots.find((b) => b.id === botId)
  if (!bot) {
    return NextResponse.json({ error: "Bot not found" }, { status: 404 })
  }

  // Get config
  const config = configStore.get(botId) || createDefaultNpcConfig(botId, bot.persona)

  // Generate prompt
  const prompt = preview ? getPromptPreview(bot, config, maxLength) : buildNpcSystemPrompt(bot, config)

  return NextResponse.json({
    botId,
    botName: bot.name,
    persona: bot.persona,
    prompt,
    promptLength: prompt.length,
    configVersion: config.version,
    generatedAt: new Date().toISOString(),
  })
}
