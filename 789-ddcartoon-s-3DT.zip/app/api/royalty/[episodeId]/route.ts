import { type NextRequest, NextResponse } from "next/server"
import { getEpisodeRoyaltyMeta, DEFAULT_SPLIT } from "@/lib/royalty-engine"
import { fetchChainRoyaltySplit, isChainAvailable } from "@/lib/royalty-chain"
import type { EpisodeRoyaltyMeta, RoyaltySplit } from "@/types/royalty"

export async function GET(request: NextRequest, { params }: { params: Promise<{ episodeId: string }> }) {
  const { episodeId } = await params

  if (!episodeId) {
    return NextResponse.json({ error: "Episode ID is required" }, { status: 400 })
  }

  try {
    // Step 1: Try to get on-chain split if available
    let chainSplit: RoyaltySplit | null = null
    let source: EpisodeRoyaltyMeta["source"] = "mock"

    if (isChainAvailable()) {
      chainSplit = await fetchChainRoyaltySplit(episodeId)
      if (chainSplit) {
        source = "chain"
      }
    }

    // Step 2: Get episode data with royalty calculations
    const royaltyMeta = getEpisodeRoyaltyMeta(episodeId, chainSplit || DEFAULT_SPLIT)

    if (!royaltyMeta) {
      return NextResponse.json({ error: "Episode not found" }, { status: 404 })
    }

    // Step 3: Update source based on chain availability
    const response: EpisodeRoyaltyMeta = {
      ...royaltyMeta,
      source,
    }

    return NextResponse.json(response)
  } catch (error) {
    console.error("[API] Royalty fetch error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
