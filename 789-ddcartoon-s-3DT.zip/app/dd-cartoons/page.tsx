import type React from "react"
import { Navigation } from "@/components/navigation"
import { EpisodeCard } from "@/components/episode-card"
import { RoyaltyHUD } from "@/components/royalty-hud"
import { IPLicensesTable } from "@/components/ip-licenses-table"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { mockEpisodes, ddCartoonsStudio, mockIPLicenses } from "@/lib/mock-data"
import { calculateAggregateRoyalties, formatCurrency } from "@/lib/royalty-engine"
import { Film, DollarSign, Eye, Calendar } from "lucide-react"
import Image from "next/image"

export default function DDCartoonsPage() {
  const studioLicenses = mockIPLicenses.filter((l) => l.licenseType === "Studio" || l.isActive)
  const aggregateRoyalties = calculateAggregateRoyalties(mockEpisodes)
  const totalViews = mockEpisodes.reduce((sum, ep) => sum + ep.viewCount, 0)

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Studio Header */}
        <section className="mb-12">
          <div className="relative h-48 sm:h-64 rounded-2xl overflow-hidden mb-6">
            <Image
              src={ddCartoonsStudio.bannerUrl || "/placeholder.svg"}
              alt={ddCartoonsStudio.name}
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-end gap-6 -mt-16 relative z-10 px-4">
            <div className="w-24 h-24 rounded-2xl border-4 border-background bg-card overflow-hidden shadow-lg">
              <Image
                src={ddCartoonsStudio.logoUrl || "/placeholder.svg"}
                alt={ddCartoonsStudio.name}
                width={96}
                height={96}
                className="object-cover"
              />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-3xl font-bold text-foreground">{ddCartoonsStudio.name}</h1>
                <Badge className="bg-primary/20 text-primary border-primary/30">Studio</Badge>
              </div>
              <p className="text-muted-foreground max-w-2xl">{ddCartoonsStudio.description}</p>
            </div>
          </div>
        </section>

        {/* Stats */}
        <section className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          <StatCard icon={Film} value={mockEpisodes.length.toString()} label="Episodes" />
          <StatCard icon={Eye} value={formatViews(totalViews)} label="Total Views" />
          <StatCard icon={DollarSign} value={formatCurrency(aggregateRoyalties.totalAmount)} label="Revenue" />
          <StatCard icon={Calendar} value={ddCartoonsStudio.createdAt} label="Since" />
        </section>

        {/* Royalty Overview */}
        <section className="mb-12">
          <h2 className="text-xl font-bold text-foreground mb-4">Studio Royalty Overview</h2>
          <RoyaltyHUD episodeId="ep-005" />
        </section>

        {/* Episodes Grid */}
        <section className="mb-12">
          <h2 className="text-xl font-bold text-foreground mb-4">All Episodes</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {mockEpisodes.map((episode) => (
              <EpisodeCard key={episode.id} episode={episode} showRevenue />
            ))}
          </div>
        </section>

        {/* IP Licenses */}
        <section>
          <h2 className="text-xl font-bold text-foreground mb-4">Character Licenses</h2>
          <IPLicensesTable licenses={studioLicenses} title="DD CARTOONS IP Registry" />
        </section>
      </main>
    </div>
  )
}

function StatCard({
  icon: Icon,
  value,
  label,
}: {
  icon: React.ComponentType<{ className?: string }>
  value: string
  label: string
}) {
  return (
    <Card>
      <CardContent className="p-4 flex items-center gap-4">
        <div className="p-3 rounded-lg bg-primary/10">
          <Icon className="w-5 h-5 text-primary" />
        </div>
        <div>
          <p className="text-xl font-bold text-foreground">{value}</p>
          <p className="text-sm text-muted-foreground">{label}</p>
        </div>
      </CardContent>
    </Card>
  )
}

function formatViews(count: number): string {
  if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M`
  if (count >= 1000) return `${(count / 1000).toFixed(1)}K`
  return count.toString()
}
