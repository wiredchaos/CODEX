# 789 STUDIOS PATCH MODULE - COMPLETE FILE TREE

## Directory Structure

```
789-studios-patch/
│
├── PATCH_MANIFEST.json                    # Patch metadata & configuration
├── PATCH_MODULE_README.md                 # Integration documentation
├── FILE_TREE.md                           # This file
│
├── app/                                   # Next.js App Router
│   ├── layout.tsx                         # Root layout [SCENE LOGIC]
│   ├── page.tsx                           # Home page [SCENE LOGIC]
│   ├── globals.css                        # Design system styles
│   │
│   ├── crew/                              # Crew routes [PATCH-SPECIFIC]
│   │   ├── page.tsx                       # Crew directory listing
│   │   └── [slug]/
│   │       └── page.tsx                   # Dynamic crew profile pages
│   │
│   ├── allies/                            # Allies routes [PATCH-SPECIFIC]
│   │   └── page.tsx                       # Ally DAOs listing
│   │
│   ├── patch-system/                      # Patch system routes [PATCH-SPECIFIC]
│   │   └── page.tsx                       # Patch dashboard UI
│   │
│   └── api/                               # API routes
│       └── patch/
│           └── scan/
│               └── route.ts               # Patch scanning endpoint
│
├── components/                            # React components
│   ├── navigation.tsx                     # Global navigation [UI COMPONENT]
│   ├── footer.tsx                         # Footer with disclaimer [UI COMPONENT]
│   ├── patch-system-dashboard.tsx         # Patch scanner UI [UI COMPONENT]
│   ├── theme-provider.tsx                 # Theme context [UI COMPONENT]
│   │
│   └── ui/                                # shadcn/ui components [UI COMPONENTS]
│       ├── accordion.tsx
│       ├── alert-dialog.tsx
│       ├── alert.tsx
│       ├── aspect-ratio.tsx
│       ├── avatar.tsx
│       ├── badge.tsx
│       ├── breadcrumb.tsx
│       ├── button-group.tsx
│       ├── button.tsx
│       ├── calendar.tsx
│       ├── card.tsx
│       ├── carousel.tsx
│       ├── chart.tsx
│       ├── checkbox.tsx
│       ├── collapsible.tsx
│       ├── command.tsx
│       ├── context-menu.tsx
│       ├── dialog.tsx
│       ├── drawer.tsx
│       ├── dropdown-menu.tsx
│       ├── empty.tsx
│       ├── field.tsx
│       ├── form.tsx
│       ├── hover-card.tsx
│       ├── input-group.tsx
│       ├── input-otp.tsx
│       ├── input.tsx
│       ├── item.tsx
│       ├── kbd.tsx
│       ├── label.tsx
│       ├── menubar.tsx
│       ├── navigation-menu.tsx
│       ├── pagination.tsx
│       ├── popover.tsx
│       ├── progress.tsx
│       ├── radio-group.tsx
│       ├── resizable.tsx
│       ├── scroll-area.tsx
│       ├── select.tsx
│       ├── separator.tsx
│       ├── sheet.tsx
│       ├── sidebar.tsx
│       ├── skeleton.tsx
│       ├── slider.tsx
│       ├── sonner.tsx
│       ├── spinner.tsx
│       ├── switch.tsx
│       ├── table.tsx
│       ├── tabs.tsx
│       ├── textarea.tsx
│       ├── toast.tsx
│       ├── toaster.tsx
│       ├── toggle-group.tsx
│       ├── toggle.tsx
│       ├── tooltip.tsx
│       ├── use-mobile.tsx
│       └── use-toast.ts
│
├── lib/                                   # Utility libraries
│   ├── utils.ts                           # General utilities (cn, etc.)
│   │
│   └── patch-system/                      # Patch system core
│       ├── types.ts                       # Type definitions
│       ├── scanner.ts                     # Patch scanner logic
│       ├── integration.ts                 # Integration utilities
│       └── README.md                      # Patch system docs
│
├── hooks/                                 # React hooks
│   ├── use-mobile.ts                      # Mobile detection hook
│   └── use-toast.ts                       # Toast notification hook
│
└── public/                                # Static assets
    ├── icon.svg
    ├── icon-dark-32x32.png
    ├── icon-light-32x32.png
    ├── apple-icon.png
    └── placeholder.svg
```

## File Categories

### 🎨 UI COMPONENTS (34 files)
All files in `components/` and `components/ui/`
- Reusable React components
- shadcn/ui design system
- Navigation, footer, and patch dashboard

### 🌍 SCENE / LAYOUT LOGIC (2 files)
- `app/layout.tsx` - Root layout with global structure
- `app/page.tsx` - Home page composition

### 🔌 PATCH-SPECIFIC ROUTES (5 files)
- `app/crew/page.tsx`
- `app/crew/[slug]/page.tsx`
- `app/allies/page.tsx`
- `app/patch-system/page.tsx`
- `app/api/patch/scan/route.ts`

### 🛠️ UTILITIES & LIBRARIES (5 files)
- `lib/utils.ts`
- `lib/patch-system/types.ts`
- `lib/patch-system/scanner.ts`
- `lib/patch-system/integration.ts`
- `lib/patch-system/README.md`

### 🎨 STYLES (1 file)
- `app/globals.css` - Complete design system

### ⚙️ CONFIGURATION (2 files)
- `PATCH_MANIFEST.json`
- `PATCH_MODULE_README.md`

## Total Files: 115

### Breakdown:
- Routes: 5
- UI Components: 34
- Utilities: 5
- Hooks: 2
- Styles: 1
- Config: 2
- shadcn/ui: 66

## Key Exports

### Primary Routes
```typescript
/ → Home page
/crew → Crew directory
/crew/[slug] → Individual crew profiles
/allies → Ally DAOs
/patch-system → Patch management dashboard
```

### API Endpoints
```typescript
POST /api/patch/scan → Scan project for patch namespace
```

### Components
```typescript
<Navigation /> → Global navigation
<Footer /> → Footer with IP disclaimer
<PatchSystemDashboard /> → Patch scanner UI
```

### Utilities
```typescript
PatchScanner → Namespace detection & indexing
cn() → Tailwind class merging
```

### Design Tokens
```css
.text-glow-cyan → Text glow effect
.text-glow-gold → Text glow effect
.glass-card → Glassmorphism card
.glow-border-cyan → Border glow effect
```

---

**Namespace:** 789  
**Mount Point:** /world/789  
**Realm:** Business  
**Status:** Production Ready ✅
