"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface PatchManifest {
  patch: {
    name: string | null
    slug: string | null
    indexed: string
  }
  inventory: {
    routes: number
    components: number
    content: number
    lib: number
    assets: number
    api: number
  }
  files: {
    routes: string[]
    components: string[]
    content: string[]
    lib: string[]
    assets: string[]
    api: string[]
  }
}

export function PatchSystemDashboard() {
  const [scanning, setScanning] = useState(false)
  const [manifest, setManifest] = useState<PatchManifest | null>(null)
  const [status, setStatus] = useState<string>("")

  const runScan = async () => {
    setScanning(true)
    try {
      // In real implementation, this would scan the actual file system
      // For now, we'll use a mock file list
      const mockFiles = [
        "app/page.tsx",
        "app/layout.tsx",
        "app/crew/page.tsx",
        "app/crew/[slug]/page.tsx",
        "app/allies/page.tsx",
        "components/navigation.tsx",
        "components/footer.tsx",
        "lib/utils.ts",
        "lib/patch-system/scanner.ts",
        "lib/patch-system/types.ts",
        "lib/patch-system/integration.ts",
      ]

      const response = await fetch("/api/patch/scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ files: mockFiles }),
      })

      const data = await response.json()
      setStatus(data.status)
      setManifest(data.manifest)
    } catch (error) {
      console.error("[v0] Patch scan failed:", error)
      setStatus("SCAN FAILED")
    } finally {
      setScanning(false)
    }
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <Card className="bg-black/40 backdrop-blur-lg border-cyan-500/20">
        <CardHeader>
          <CardTitle className="text-glow-cyan">789 Patch System</CardTitle>
          <CardDescription className="text-zinc-400">
            Non-destructive patch indexing and integration management
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button
            onClick={runScan}
            disabled={scanning}
            className="bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 hover:bg-cyan-500/20"
          >
            {scanning ? "Scanning..." : "Run Patch Scan"}
          </Button>

          {status && (
            <div className="p-4 bg-zinc-900/50 rounded-lg border border-green-500/30">
              <p className="text-glow-cyan font-mono text-sm">{status}</p>
            </div>
          )}

          {manifest && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <Card className="bg-zinc-900/50 border-zinc-800">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm text-zinc-400">Patch Name</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-glow-gold text-lg font-mono">{manifest.patch.name || "None"}</p>
                  </CardContent>
                </Card>

                <Card className="bg-zinc-900/50 border-zinc-800">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm text-zinc-400">Routes</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-glow-cyan text-2xl font-mono">{manifest.inventory.routes}</p>
                  </CardContent>
                </Card>

                <Card className="bg-zinc-900/50 border-zinc-800">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm text-zinc-400">Components</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-glow-cyan text-2xl font-mono">{manifest.inventory.components}</p>
                  </CardContent>
                </Card>
              </div>

              <Tabs defaultValue="routes" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="routes">Routes</TabsTrigger>
                  <TabsTrigger value="components">Components</TabsTrigger>
                  <TabsTrigger value="lib">Libraries</TabsTrigger>
                </TabsList>
                <TabsContent value="routes" className="space-y-2">
                  {manifest.files.routes.map((file) => (
                    <div key={file} className="p-2 bg-zinc-900/30 rounded border border-zinc-800">
                      <code className="text-sm text-cyan-300">{file}</code>
                    </div>
                  ))}
                </TabsContent>
                <TabsContent value="components" className="space-y-2">
                  {manifest.files.components.map((file) => (
                    <div key={file} className="p-2 bg-zinc-900/30 rounded border border-zinc-800">
                      <code className="text-sm text-cyan-300">{file}</code>
                    </div>
                  ))}
                </TabsContent>
                <TabsContent value="lib" className="space-y-2">
                  {manifest.files.lib.map((file) => (
                    <div key={file} className="p-2 bg-zinc-900/30 rounded border border-zinc-800">
                      <code className="text-sm text-cyan-300">{file}</code>
                    </div>
                  ))}
                </TabsContent>
              </Tabs>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
