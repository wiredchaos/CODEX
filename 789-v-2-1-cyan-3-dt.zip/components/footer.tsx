import Link from "next/link"
import { Twitter, Instagram, Youtube } from "lucide-react"

export function Footer() {
  return (
    <footer className="mt-auto border-t border-[#262A33]/60 bg-[#050608]">
      <div className="mx-auto max-w-6xl px-4 py-8">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* Brand */}
          <div>
            <Link href="/" className="flex items-center gap-2 mb-4">
              <span className="text-xl font-bold tracking-[0.2em] text-glow-cyan text-cyan-400">789</span>
              <span className="text-xs font-medium tracking-[0.15em] uppercase text-white/80 text-glow-white">
                Studios
              </span>
            </Link>
            <p className="text-sm text-white/60 text-glow-white leading-relaxed">
              Virtual studio & content network for Web3-native storytelling.
            </p>
          </div>

          {/* Links */}
          <div>
            <h3 className="text-sm font-semibold tracking-[0.15em] uppercase text-cyan-400 text-glow-cyan mb-4">
              Explore
            </h3>
            <ul className="space-y-2">
              <li>
                <Link href="/crew" className="text-sm text-white/60 hover:text-white transition-colors text-glow-white">
                  789 Crew
                </Link>
              </li>
              <li>
                <Link
                  href="/allies"
                  className="text-sm text-white/60 hover:text-white transition-colors text-glow-white"
                >
                  Ally DAOs
                </Link>
              </li>
              <li>
                <Link
                  href="/spaces"
                  className="text-sm text-white/60 hover:text-white transition-colors text-glow-white"
                >
                  Crypto Spaces
                </Link>
              </li>
              <li>
                <Link
                  href="/film3"
                  className="text-sm text-white/60 hover:text-white transition-colors text-glow-white"
                >
                  Film3 Ecosystem
                </Link>
              </li>
            </ul>
          </div>

          {/* Social */}
          <div>
            <h3 className="text-sm font-semibold tracking-[0.15em] uppercase text-cyan-400 text-glow-cyan mb-4">
              Connect
            </h3>
            <div className="flex gap-4">
              <a
                href="https://twitter.com/789studiosonx"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 glass-card glow-border-cyan hover:bg-cyan-400/10 transition-colors"
                aria-label="X (Twitter)"
              >
                <Twitter size={18} className="text-cyan-400" />
              </a>
              <a
                href="https://instagram.com/789.studios"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 glass-card glow-border-gold hover:bg-yellow-400/10 transition-colors"
                aria-label="Instagram"
              >
                <Instagram size={18} className="text-yellow-400" />
              </a>
              <a
                href="https://youtube.com/@789studios"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 glass-card hover:bg-white/5 transition-colors"
                aria-label="YouTube"
              >
                <Youtube size={18} className="text-white/80" />
              </a>
            </div>
          </div>
        </div>

        {/* IP Disclaimer */}
        <div className="border-t border-[#262A33]/60 pt-6">
          <div className="glass-card p-4 mb-4">
            <h4 className="text-xs font-semibold tracking-[0.15em] uppercase text-yellow-400 text-glow-gold mb-2">
              Intellectual Property & NFT Ownership Notice
            </h4>
            <p className="text-xs text-white/50 text-glow-white leading-relaxed">
              789 Studios does not own third-party film IP. NFT ownership does not equal film IP ownership. All
              references are for educational/creative purposes only. All descriptions of third-party brands and
              platforms on this site are based on publicly available information from their own websites and social
              media. 789 Studios does not claim ownership of, or formal partnership with, any external brand, DAO, or
              platform unless explicitly stated. All trademarks, graphics, and intellectual property remain the
              exclusive property of their respective owners.
            </p>
          </div>

          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-xs text-white/40 text-glow-white">
              &copy; {new Date().getFullYear()} 789 Studios. All rights reserved.
            </p>
            <p className="text-xs text-white/40 text-glow-white">Built for Web3 creators</p>
          </div>
        </div>
      </div>
    </footer>
  )
}
