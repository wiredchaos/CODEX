// API Route: Patch System Scanner
import { NextResponse } from "next/server"
import { PatchScanner } from "@/lib/patch-system/scanner"
import { PatchIntegration } from "@/lib/patch-system/integration"

export async function POST(request: Request) {
  try {
    const { files } = await request.json()

    if (!Array.isArray(files)) {
      return NextResponse.json({ error: "Files array required" }, { status: 400 })
    }

    // Initialize scanner
    const scanner = new PatchScanner()

    // Phase 1: Detect namespace
    const namespace = scanner.detectPatchNamespace(files)

    // Phase 2: Scan project
    scanner.scanProject(files)

    // Phase 3 & 4: Get state
    const state = scanner.getState()

    // Generate integration manifest
    const integration = new PatchIntegration(state)
    const manifest = integration.generateManifest()

    // Phase 5: Return status
    return NextResponse.json({
      status: scanner.getStatus(),
      ready: scanner.isReady(),
      namespace,
      manifest,
      state,
    })
  } catch (error) {
    console.error("[Patch System] Scan error:", error)
    return NextResponse.json({ error: "Scan failed" }, { status: 500 })
  }
}
