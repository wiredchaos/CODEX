import type React from "react"
import { notFound } from "next/navigation"
import Link from "next/link"
import { ArrowLeft, Twitter, Instagram, Youtube, ExternalLink, Tv, Radio, Film, BookOpen } from "lucide-react"

const crewData: Record<
  string,
  {
    name: string
    handle: string
    role: string
    bio: string
    color: "cyan" | "gold"
    feature?: { title: string; description: string }
    socials: { platform: string; url: string; icon: React.ElementType }[]
    actions: { label: string; icon: React.ElementType; href: string }[]
  }
> = {
  neuro: {
    name: "NEURO",
    handle: "@neurometax",
    role: "Content Creator + AI Ghostwriter",
    bio: "NEURO DD#1787 Content Creator + AI Ghostwriter Translator Bridging Web2 → Web3 | Reporting via Wired Chaos + BWB",
    color: "cyan",
    feature: {
      title: "NeuroMetaX — Decode the Hidden Layers",
      description:
        "Exploring neural networks, metaphysics, and media history. Translating complex concepts for the Web3 generation.",
    },
    socials: [
      { platform: "X", url: "https://twitter.com/neurometax", icon: Twitter },
      { platform: "Instagram", url: "https://instagram.com/neurometax", icon: Instagram },
      { platform: "YouTube", url: "https://youtube.com/@neurometax", icon: Youtube },
    ],
    actions: [
      { label: "Watch Content", icon: Tv, href: "#" },
      { label: "Join Spaces", icon: Radio, href: "/spaces" },
      { label: "View NFTs", icon: Film, href: "#" },
      { label: "FLINCH Course", icon: BookOpen, href: "/film3/flinch-case-study" },
    ],
  },
  vibes: {
    name: "VIBES",
    handle: "@789vibes",
    role: "Creative Director",
    bio: "Setting the creative vision and tone for 789 Studios. Curating the aesthetic that defines Web3-native content.",
    color: "gold",
    socials: [
      { platform: "X", url: "https://twitter.com/789vibes", icon: Twitter },
      { platform: "Instagram", url: "https://instagram.com/789vibes", icon: Instagram },
    ],
    actions: [
      { label: "Watch Content", icon: Tv, href: "#" },
      { label: "Join Spaces", icon: Radio, href: "/spaces" },
    ],
  },
  gator: {
    name: "GATOR",
    handle: "@789gator",
    role: "Community Lead",
    bio: "Building bridges across the Web3 ecosystem. Connecting creators, collectors, and communities.",
    color: "gold",
    socials: [{ platform: "X", url: "https://twitter.com/789gator", icon: Twitter }],
    actions: [{ label: "Join Spaces", icon: Radio, href: "/spaces" }],
  },
  wooki: {
    name: "WOOKI",
    handle: "@789wooki",
    role: "Technical Director",
    bio: "Making the impossible possible. Building the technical infrastructure for 789 Studios.",
    color: "cyan",
    socials: [{ platform: "X", url: "https://twitter.com/789wooki", icon: Twitter }],
    actions: [{ label: "Join Spaces", icon: Radio, href: "/spaces" }],
  },
  jeep: {
    name: "JEEP",
    handle: "@789jeep",
    role: "Strategy",
    bio: "Navigating the Web3 landscape. Charting the course for 789 Studios growth and partnerships.",
    color: "gold",
    socials: [{ platform: "X", url: "https://twitter.com/789jeep", icon: Twitter }],
    actions: [{ label: "Join Spaces", icon: Radio, href: "/spaces" }],
  },
  artsy: {
    name: "ARTSY",
    handle: "@789artsy",
    role: "Visual Design",
    bio: "Creating visual narratives for the decentralized future. Designing the 789 Studios brand identity.",
    color: "cyan",
    socials: [
      { platform: "X", url: "https://twitter.com/789artsy", icon: Twitter },
      { platform: "Instagram", url: "https://instagram.com/789artsy", icon: Instagram },
    ],
    actions: [{ label: "View NFTs", icon: Film, href: "#" }],
  },
}

export async function generateStaticParams() {
  return Object.keys(crewData).map((slug) => ({
    slug,
  }))
}

export default function CrewMemberPage({ params }: { params: { slug: string } }) {
  const { slug } = params
  const member = crewData[slug]

  if (!member) {
    notFound()
  }

  const colorClass = member.color === "cyan" ? "cyan" : "yellow"
  const glowClass = member.color === "cyan" ? "text-glow-cyan" : "text-glow-gold"
  const borderClass = member.color === "cyan" ? "glow-border-cyan" : "glow-border-gold"
  const bgClass = member.color === "cyan" ? "bg-cyan-400" : "bg-yellow-400"

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="mx-auto max-w-2xl">
        {/* Back Link */}
        <Link
          href="/crew"
          className="inline-flex items-center gap-2 text-sm text-white/60 hover:text-white mb-8 text-glow-white"
        >
          <ArrowLeft size={16} />
          Back to Crew
        </Link>

        {/* Profile Card - Chirp Style */}
        <div className={`glass-card ${borderClass} overflow-hidden`}>
          {/* Header Banner */}
          <div className={`h-24 ${bgClass}/20`} />

          {/* Avatar & Info */}
          <div className="px-6 pb-6">
            <div
              className={`w-24 h-24 -mt-12 rounded-full border-4 border-[#101217] flex items-center justify-center text-4xl font-bold ${
                member.color === "cyan" ? "bg-cyan-400/30 text-cyan-400" : "bg-yellow-400/30 text-yellow-400"
              }`}
            >
              {member.name[0]}
            </div>

            <div className="mt-4">
              <h1 className={`text-2xl font-bold tracking-wide text-${colorClass}-400 ${glowClass}`}>{member.name}</h1>
              <p className="text-white/50 text-glow-white">{member.handle}</p>
              <p className="text-sm text-white/70 text-glow-white mt-1">{member.role}</p>
            </div>

            {/* Bio */}
            <p className="mt-4 text-white/80 text-glow-white leading-relaxed">{member.bio}</p>

            {/* Social Links */}
            <div className="flex gap-3 mt-6">
              {member.socials.map((social) => (
                <a
                  key={social.platform}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`glass-card p-3 ${borderClass} hover:${bgClass}/10 transition-colors`}
                  aria-label={social.platform}
                >
                  <social.icon size={20} className={`text-${colorClass}-400`} />
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Featured Content */}
        {member.feature && (
          <div className={`glass-card ${borderClass} p-6 mt-6`}>
            <h2 className={`text-lg font-semibold tracking-wide text-${colorClass}-400 ${glowClass} mb-2`}>
              {member.feature.title}
            </h2>
            <p className="text-sm text-white/60 text-glow-white leading-relaxed">{member.feature.description}</p>
          </div>
        )}

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-4 mt-6">
          {member.actions.map((action) => (
            <Link
              key={action.label}
              href={action.href}
              className={`glass-card ${borderClass} p-4 flex items-center gap-3 hover:${bgClass}/10 transition-colors`}
            >
              <action.icon size={20} className={`text-${colorClass}-400`} />
              <span className="text-sm text-white text-glow-white font-medium">{action.label}</span>
              <ExternalLink size={14} className="ml-auto text-white/30" />
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
