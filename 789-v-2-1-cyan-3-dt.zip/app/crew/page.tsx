import Link from "next/link"
import { ArrowRight, Twitter, Instagram, Youtube } from "lucide-react"

const crewMembers = [
  {
    slug: "vibes",
    name: "VIBES",
    role: "Creative Director",
    tagline: "Setting the tone for Web3 content",
    color: "gold",
    socials: { x: true, instagram: true },
  },
  {
    slug: "neuro",
    name: "NEURO",
    role: "Content Creator + AI Ghostwriter",
    tagline: "Bridging Web2 → Web3 | Reporting via Wired Chaos + BWB",
    color: "cyan",
    handle: "@neurometax",
    socials: { x: true, youtube: true, instagram: true },
  },
  {
    slug: "gator",
    name: "GATOR",
    role: "Community Lead",
    tagline: "Building bridges across the ecosystem",
    color: "gold",
    socials: { x: true },
  },
  {
    slug: "wooki",
    name: "WOOKI",
    role: "Technical Director",
    tagline: "Making the impossible, possible",
    color: "cyan",
    socials: { x: true },
  },
  {
    slug: "jeep",
    name: "JEEP",
    role: "Strategy",
    tagline: "Navigating the Web3 landscape",
    color: "gold",
    socials: { x: true },
  },
  {
    slug: "artsy",
    name: "ARTSY",
    role: "Visual Design",
    tagline: "Creating visual narratives for the decentralized future",
    color: "cyan",
    socials: { x: true, instagram: true },
  },
]

export default function CrewPage() {
  return (
    <div className="min-h-screen py-12 px-4">
      <div className="mx-auto max-w-6xl">
        {/* Header */}
        <header className="text-center mb-12">
          <h1 className="text-3xl md:text-5xl font-bold tracking-[0.15em] text-white text-glow-white mb-4">
            THE <span className="text-cyan-400 text-glow-cyan">789</span> CREW
          </h1>
          <p className="text-lg text-white/60 text-glow-white max-w-xl mx-auto">
            Meet the team building the future of Web3 content creation
          </p>
        </header>

        {/* Crew Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {crewMembers.map((member) => (
            <Link
              key={member.slug}
              href={`/crew/${member.slug}`}
              className={`glass-card p-6 hover:scale-[1.02] transition-all group ${
                member.color === "cyan" ? "glow-border-cyan" : "glow-border-gold"
              }`}
            >
              {/* Avatar */}
              <div className="flex items-start gap-4 mb-4">
                <div
                  className={`w-16 h-16 rounded-full flex items-center justify-center text-2xl font-bold ${
                    member.color === "cyan" ? "bg-cyan-400/20 text-cyan-400" : "bg-yellow-400/20 text-yellow-400"
                  }`}
                >
                  {member.name[0]}
                </div>
                <div className="flex-1">
                  <h2
                    className={`text-xl font-bold tracking-wide ${
                      member.color === "cyan" ? "text-cyan-400 text-glow-cyan" : "text-yellow-400 text-glow-gold"
                    }`}
                  >
                    {member.name}
                  </h2>
                  {member.handle && <p className="text-sm text-white/50 text-glow-white">{member.handle}</p>}
                  <p className="text-sm text-white/70 text-glow-white mt-1">{member.role}</p>
                </div>
              </div>

              {/* Tagline */}
              <p className="text-sm text-white/60 text-glow-white leading-relaxed mb-4">{member.tagline}</p>

              {/* Social Icons & CTA */}
              <div className="flex items-center justify-between">
                <div className="flex gap-2">
                  {member.socials.x && (
                    <div className="p-2 rounded-lg bg-white/5">
                      <Twitter size={14} className="text-white/50" />
                    </div>
                  )}
                  {member.socials.instagram && (
                    <div className="p-2 rounded-lg bg-white/5">
                      <Instagram size={14} className="text-white/50" />
                    </div>
                  )}
                  {member.socials.youtube && (
                    <div className="p-2 rounded-lg bg-white/5">
                      <Youtube size={14} className="text-white/50" />
                    </div>
                  )}
                </div>
                <span
                  className={`text-sm flex items-center gap-1 ${
                    member.color === "cyan" ? "text-cyan-400" : "text-yellow-400"
                  } group-hover:gap-2 transition-all`}
                >
                  View Profile <ArrowRight size={14} />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
