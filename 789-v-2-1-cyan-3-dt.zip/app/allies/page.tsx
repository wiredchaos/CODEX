import { ExternalLink, Twitter } from "lucide-react"

const allies = [
  {
    name: "TYPE Media",
    handle: "@typebrand",
    website: "typebrand.xyz",
    description: "Premium Web3 branding and media production. Creating visual identities for the decentralized future.",
    color: "cyan",
  },
  {
    name: "Beanies on Business",
    handle: "@BeanieDaoX",
    website: null,
    description: "Community-driven DAO focused on business development and networking in the Web3 space.",
    color: "gold",
  },
  {
    name: "BowMafia / BowDAO",
    handle: "@BowDAOMeta",
    website: null,
    description: "Collaborative DAO ecosystem building connections across NFT communities.",
    color: "cyan",
  },
  {
    name: "Dogwarts DAO",
    handle: "@DogwartsDAO",
    website: "dogwartsdao.com",
    description: "Educational DAO focused on onboarding creators and collectors into the Web3 ecosystem.",
    color: "gold",
  },
  {
    name: "OTF Media",
    handle: "@OTFMediaX",
    website: null,
    description: "Independent media collective covering Web3 culture, music, and entertainment.",
    color: "cyan",
  },
  {
    name: "Yellow DAO",
    handle: "@YellowDAO",
    website: "yellowdao.xyz",
    description: "Decentralized collective supporting artists and creators in the NFT space.",
    color: "gold",
  },
  {
    name: "KennelDAO",
    handle: "@KennelDAO",
    website: null,
    description: "Community DAO bringing together collectors and builders in the dog-themed NFT ecosystem.",
    color: "cyan",
  },
]

export default function AlliesPage() {
  return (
    <div className="min-h-screen py-12 px-4">
      <div className="mx-auto max-w-6xl">
        {/* Header */}
        <header className="text-center mb-12">
          <h1 className="text-3xl md:text-5xl font-bold tracking-[0.15em] text-white text-glow-white mb-4">
            ALLY <span className="text-yellow-400 text-glow-gold">DAOs</span>
          </h1>
          <p className="text-lg text-white/60 text-glow-white max-w-xl mx-auto">
            Our ecosystem partners building the decentralized future together
          </p>
        </header>

        {/* Allies Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {allies.map((ally) => (
            <div
              key={ally.name}
              className={`glass-card p-6 ${ally.color === "cyan" ? "glow-border-cyan" : "glow-border-gold"}`}
            >
              {/* Avatar */}
              <div className="flex items-start gap-4 mb-4">
                <div
                  className={`w-14 h-14 rounded-full flex items-center justify-center text-xl font-bold ${
                    ally.color === "cyan" ? "bg-cyan-400/20 text-cyan-400" : "bg-yellow-400/20 text-yellow-400"
                  }`}
                >
                  {ally.name[0]}
                </div>
                <div className="flex-1">
                  <h2
                    className={`text-lg font-bold tracking-wide ${
                      ally.color === "cyan" ? "text-cyan-400 text-glow-cyan" : "text-yellow-400 text-glow-gold"
                    }`}
                  >
                    {ally.name}
                  </h2>
                  <p className="text-sm text-white/50 text-glow-white">{ally.handle}</p>
                </div>
              </div>

              {/* Description */}
              <p className="text-sm text-white/60 text-glow-white leading-relaxed mb-4">{ally.description}</p>

              {/* Links */}
              <div className="flex gap-3">
                <a
                  href={`https://twitter.com/${ally.handle.replace("@", "")}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`p-2 glass-card ${
                    ally.color === "cyan"
                      ? "glow-border-cyan hover:bg-cyan-400/10"
                      : "glow-border-gold hover:bg-yellow-400/10"
                  } transition-colors`}
                  aria-label={`${ally.name} on X`}
                >
                  <Twitter size={16} className={ally.color === "cyan" ? "text-cyan-400" : "text-yellow-400"} />
                </a>
                {ally.website && (
                  <a
                    href={`https://${ally.website}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`p-2 glass-card ${
                      ally.color === "cyan"
                        ? "glow-border-cyan hover:bg-cyan-400/10"
                        : "glow-border-gold hover:bg-yellow-400/10"
                    } transition-colors flex items-center gap-2`}
                  >
                    <ExternalLink size={16} className={ally.color === "cyan" ? "text-cyan-400" : "text-yellow-400"} />
                    <span className="text-xs text-white/60 text-glow-white">{ally.website}</span>
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Partner with us CTA */}
        <div className="mt-12 text-center">
          <div className="glass-card glow-border-cyan inline-block p-8">
            <h3 className="text-xl font-bold text-cyan-400 text-glow-cyan mb-2">Want to become an ally?</h3>
            <p className="text-sm text-white/60 text-glow-white mb-4">
              Join our ecosystem of creators, DAOs, and builders
            </p>
            <a
              href="https://twitter.com/789studiosonx"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 bg-cyan-400/20 border border-cyan-400/40 rounded-lg text-cyan-400 font-medium hover:bg-cyan-400/30 transition-colors"
            >
              <Twitter size={18} />
              Reach out on X
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}
