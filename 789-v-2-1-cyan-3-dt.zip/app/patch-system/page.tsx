import { PatchSystemDashboard } from "@/components/patch-system-dashboard"

export default function PatchSystemPage() {
  return (
    <div className="min-h-screen">
      <PatchSystemDashboard />
    </div>
  )
}
