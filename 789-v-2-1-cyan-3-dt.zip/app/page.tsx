import Link from "next/link"
import { ArrowRight, Play, Users, Tv, Film, Radio } from "lucide-react"

const services = [
  {
    icon: Tv,
    title: "Virtual Studio",
    description: "Professional-grade virtual production environment for Web3 creators",
    color: "cyan",
  },
  {
    icon: Radio,
    title: "Crypto Spaces",
    description: "24/7 audio spaces network with curated programming",
    color: "gold",
  },
  {
    icon: Film,
    title: "Film3 Hub",
    description: "Decentralized film production and distribution ecosystem",
    color: "purple",
  },
  {
    icon: Users,
    title: "Creator Network",
    description: "Multi-platform publishing across YouTube, X, TikTok, and more",
    color: "cyan",
  },
]

const crew = [
  { name: "VIBES", role: "Creative Director", color: "gold" },
  { name: "NEURO", role: "Content Creator + AI Ghostwriter", color: "cyan" },
  { name: "GATOR", role: "Community Lead", color: "gold" },
  { name: "WOOKI", role: "Technical Director", color: "cyan" },
  { name: "JEEP", role: "Strategy", color: "gold" },
  { name: "ARTSY", role: "Visual Design", color: "cyan" },
]

export default function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 md:py-32 px-4">
        <div className="mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-bold tracking-[0.1em] text-white text-glow-white mb-6">
              <span className="text-cyan-400 text-glow-cyan">789</span> STUDIOS
            </h1>
            <p className="text-xl md:text-2xl text-white/70 text-glow-white max-w-2xl mx-auto leading-relaxed">
              Virtual studio & content network for <span className="text-yellow-400 text-glow-gold">Web3-native</span>{" "}
              storytelling
            </p>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-20">
            <Link
              href="/crew"
              className="glass-card glow-border-cyan px-8 py-4 flex items-center justify-center gap-3 hover:bg-cyan-400/10 transition-all group"
            >
              <Users size={20} className="text-cyan-400" />
              <span className="text-white text-glow-white font-medium tracking-wide">Meet the Crew</span>
              <ArrowRight size={18} className="text-cyan-400 group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link
              href="/allies"
              className="glass-card glow-border-gold px-8 py-4 flex items-center justify-center gap-3 hover:bg-yellow-400/10 transition-all group"
            >
              <Play size={20} className="text-yellow-400" />
              <span className="text-white text-glow-white font-medium tracking-wide">Explore Allies</span>
              <ArrowRight size={18} className="text-yellow-400 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>

          {/* Services Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {services.map((service) => (
              <div
                key={service.title}
                className={`glass-card p-6 ${
                  service.color === "cyan" ? "glow-border-cyan" : service.color === "gold" ? "glow-border-gold" : ""
                } hover:scale-[1.02] transition-transform`}
              >
                <div className="flex items-start gap-4">
                  <div
                    className={`p-3 rounded-lg ${
                      service.color === "cyan"
                        ? "bg-cyan-400/10"
                        : service.color === "gold"
                          ? "bg-yellow-400/10"
                          : "bg-purple-400/10"
                    }`}
                  >
                    <service.icon
                      size={24}
                      className={
                        service.color === "cyan"
                          ? "text-cyan-400"
                          : service.color === "gold"
                            ? "text-yellow-400"
                            : "text-purple-400"
                      }
                    />
                  </div>
                  <div>
                    <h3
                      className={`text-lg font-semibold tracking-wide mb-2 ${
                        service.color === "cyan"
                          ? "text-cyan-400 text-glow-cyan"
                          : service.color === "gold"
                            ? "text-yellow-400 text-glow-gold"
                            : "text-purple-400 text-glow-purple"
                      }`}
                    >
                      {service.title}
                    </h3>
                    <p className="text-sm text-white/60 text-glow-white leading-relaxed">{service.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Crew Preview */}
      <section className="py-16 px-4 border-t border-[#262A33]/60">
        <div className="mx-auto max-w-6xl">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold tracking-[0.1em] text-white text-glow-white">
              THE <span className="text-cyan-400 text-glow-cyan">CREW</span>
            </h2>
            <Link href="/crew" className="text-sm text-cyan-400 text-glow-cyan hover:underline flex items-center gap-2">
              View All <ArrowRight size={14} />
            </Link>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {crew.map((member) => (
              <Link
                key={member.name}
                href={`/crew/${member.name.toLowerCase()}`}
                className={`glass-card p-4 text-center hover:scale-105 transition-transform ${
                  member.color === "cyan" ? "glow-border-cyan" : "glow-border-gold"
                }`}
              >
                <div
                  className={`w-12 h-12 mx-auto mb-3 rounded-full flex items-center justify-center text-lg font-bold ${
                    member.color === "cyan" ? "bg-cyan-400/20 text-cyan-400" : "bg-yellow-400/20 text-yellow-400"
                  }`}
                >
                  {member.name[0]}
                </div>
                <h3
                  className={`text-sm font-semibold tracking-wide ${
                    member.color === "cyan" ? "text-cyan-400 text-glow-cyan" : "text-yellow-400 text-glow-gold"
                  }`}
                >
                  {member.name}
                </h3>
                <p className="text-xs text-white/50 text-glow-white mt-1">{member.role}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
