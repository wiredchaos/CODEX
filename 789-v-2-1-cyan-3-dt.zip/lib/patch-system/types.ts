// Patch System Types for 789 Studios Integration

export interface TrinityMount {
  consumer: boolean
  owner: boolean
  floor: "assigned" | string
  timeline: "assigned" | string
  permissions: TrinityPermissions
  governance: "akira_codex" | string
  infrastructure: "read_only" | "read_write"
}

export interface TrinityPermissions {
  read: boolean
  write: boolean
  generate_3d: boolean
  generate_galaxy: boolean
}

export interface TrinityDeclarations {
  no_3d_generation: boolean
  no_galaxy_creation: boolean
  mounts_to_assigned_floor: boolean
  timeline_access_governed_by_akira_codex: boolean
  trinity_read_only: boolean
  consumer_not_owner: boolean
}

export interface PatchManifest {
  patch: string
  version: string
  realm: "business" | "akashic" | "dual"
  mount: string
  ui: boolean
  scene: boolean
  trinity: TrinityMount
  declarations: TrinityDeclarations
  features: Record<string, boolean>
  dependencies: Record<string, string>
  integrations: Record<string, boolean>
  routes: string[]
  description: string
  author: string
  tags: string[]
}

// Patch System Types for 789 Studios Integration
export interface PatchIndex {
  routes: string[]
  components: string[]
  content: string[]
  lib: string[]
  assets: string[]
  api: string[]
}

export interface PatchState {
  patchName: string | null
  patchSlug: string | null
  index: PatchIndex
  timestamp: string
}

export const PATCH_NAMESPACES = [
  "wired-chaos",
  "chaos-os",
  "chaos lab",
  "789",
  "789-studios",
  "ott-789",
  "film3",
  "csn",
  "akira",
  "akira-codex",
  "creator-codex",
  "npc",
  "neuro prompt command",
  "tax-suite",
  "trust-suite",
  "neura-tax",
  "fen",
  "fenn-engine",
  "vrg33589",
  "589-magazine",
  "vault33",
  "vault-33",
] as const

export type PatchNamespace = (typeof PATCH_NAMESPACES)[number]

export const DEFAULT_789_TRINITY: TrinityMount = {
  consumer: true,
  owner: false,
  floor: "assigned",
  timeline: "assigned",
  permissions: {
    read: true,
    write: false,
    generate_3d: false,
    generate_galaxy: false,
  },
  governance: "akira_codex",
  infrastructure: "read_only",
}

export const DEFAULT_789_DECLARATIONS: TrinityDeclarations = {
  no_3d_generation: true,
  no_galaxy_creation: true,
  mounts_to_assigned_floor: true,
  timeline_access_governed_by_akira_codex: true,
  trinity_read_only: true,
  consumer_not_owner: true,
}
