// Patch System Integration Utilities
import type { PatchState } from "./types"

export class PatchIntegration {
  constructor(private state: PatchState) {}

  // Generate integration manifest for lab combination
  generateManifest() {
    return {
      patch: {
        name: this.state.patchName,
        slug: this.state.patchSlug,
        indexed: this.state.timestamp,
      },
      inventory: {
        routes: this.state.index.routes.length,
        components: this.state.index.components.length,
        content: this.state.index.content.length,
        lib: this.state.index.lib.length,
        assets: this.state.index.assets.length,
        api: this.state.index.api.length,
      },
      files: this.state.index,
    }
  }

  // Check for conflicts before integration
  checkConflicts(targetFiles: string[]): string[] {
    const allIndexedFiles = [
      ...this.state.index.routes,
      ...this.state.index.components,
      ...this.state.index.content,
      ...this.state.index.lib,
      ...this.state.index.assets,
      ...this.state.index.api,
    ]

    return allIndexedFiles.filter((file) => targetFiles.includes(file))
  }

  // Get files by category
  getFilesByCategory(category: keyof PatchState["index"]): string[] {
    return [...this.state.index[category]]
  }

  // Export state for persistence
  exportState(): string {
    return JSON.stringify(this.state, null, 2)
  }

  // Import state from persistence
  static importState(json: string): PatchIntegration {
    const state = JSON.parse(json) as PatchState
    return new PatchIntegration(state)
  }
}
