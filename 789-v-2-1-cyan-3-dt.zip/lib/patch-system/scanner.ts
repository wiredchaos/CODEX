// Patch System Scanner - Non-destructive indexing
import { PATCH_NAMESPACES, type PatchIndex, type PatchState } from "./types"

export class PatchScanner {
  private state: PatchState = {
    patchName: null,
    patchSlug: null,
    index: {
      routes: [],
      components: [],
      content: [],
      lib: [],
      assets: [],
      api: [],
    },
    timestamp: new Date().toISOString(),
  }

  // Phase 1: Detect active patch namespace
  detectPatchNamespace(projectFiles: string[]): string | null {
    for (const namespace of PATCH_NAMESPACES) {
      const found = projectFiles.some(
        (file) => file.toLowerCase().includes(namespace.toLowerCase()) || file.includes(this.toKebabCase(namespace)),
      )

      if (found) {
        this.state.patchName = namespace
        this.state.patchSlug = this.toKebabCase(namespace)
        return namespace
      }
    }

    return null
  }

  // Phase 2: Project-wide patch search
  scanProject(files: string[]): void {
    const { patchName, patchSlug } = this.state

    if (!patchName) {
      console.log("[Patch System] No patch namespace detected - clean scaffold")
      return
    }

    files.forEach((file) => {
      const lowerFile = file.toLowerCase()
      const matchesNamespace =
        lowerFile.includes(patchName.toLowerCase()) || (patchSlug && lowerFile.includes(patchSlug))

      if (matchesNamespace) {
        // Categorize by directory
        if (file.startsWith("app/") && !file.startsWith("app/api/")) {
          this.state.index.routes.push(file)
        } else if (file.startsWith("app/api/")) {
          this.state.index.api.push(file)
        } else if (file.startsWith("components/")) {
          this.state.index.components.push(file)
        } else if (file.startsWith("content/") || file.includes(".json") || file.includes(".md")) {
          this.state.index.content.push(file)
        } else if (file.startsWith("lib/")) {
          this.state.index.lib.push(file)
        } else if (file.startsWith("public/")) {
          this.state.index.assets.push(file)
        }
      }
    })
  }

  // Phase 3: Get internal index (read-only)
  getIndex(): PatchIndex {
    return { ...this.state.index }
  }

  // Phase 4: Get full state snapshot
  getState(): PatchState {
    return { ...this.state }
  }

  // Helper: Convert to kebab-case
  private toKebabCase(str: string): string {
    return str
      .toLowerCase()
      .replace(/\s+/g, "-")
      .replace(/[^a-z0-9-]/g, "")
  }

  // Phase 5: Confirm ready
  isReady(): boolean {
    return this.state.patchName !== null
  }

  getStatus(): string {
    if (this.state.patchName) {
      return `PATCH SEARCH COMPLETE. INDEX READY. [${this.state.patchName}]`
    }
    return "PATCH SEARCH COMPLETE. INDEX READY. [No namespace detected]"
  }
}
