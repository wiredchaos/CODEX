export interface OTTChannel {
  id: string
  name: string
  slug: string
  description: string
  logo?: string
  heroArt?: string
  color: string
}

export interface OTTEpisode {
  id: string
  showId: string
  title: string
  slug: string
  description: string
  duration: number // in seconds
  thumbnail: string
  videoUrl: string
  episodeNumber?: number
  seasonNumber?: number
}

export interface OTTShow {
  id: string
  title: string
  slug: string
  channelId: string
  description: string
  tags: string[]
  genres: string[]
  heroArt: string
  thumbnail: string
  trailerId?: string
  episodes: OTTEpisode[]
  year?: number
  rating?: string
}
