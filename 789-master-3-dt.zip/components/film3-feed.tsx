// Film3 Community Feed Component
// Displays curated #Film3 content from X/Twitter
"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Heart, Repeat2, MessageCircle, Radio, Video, FileText, ExternalLink } from "lucide-react"
import type { Film3Post } from "@/app/api/film3-feed/route"

export function Film3Feed() {
  const [posts, setPosts] = useState<Film3Post[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<"all" | "post" | "space" | "video" | "thread">("all")

  useEffect(() => {
    async function fetchFeed() {
      try {
        const res = await fetch("/api/film3-feed")
        const data = await res.json()
        setPosts(data.posts)
      } catch (error) {
        console.error("Failed to fetch Film3 feed:", error)
      } finally {
        setLoading(false)
      }
    }
    fetchFeed()
  }, [])

  const filteredPosts = filter === "all" ? posts : posts.filter((p) => p.type === filter)

  const typeIcons = {
    post: MessageCircle,
    space: Radio,
    video: Video,
    thread: FileText,
  }

  const typeColors = {
    post: "#00F0FF",
    space: "#FF003C",
    video: "#FFD700",
    thread: "#00FF88",
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-2 border-[#00F0FF] border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Filter tabs */}
      <div className="flex flex-wrap gap-2 mb-8">
        {(["all", "post", "space", "video", "thread"] as const).map((type) => (
          <button
            key={type}
            onClick={() => setFilter(type)}
            className={`px-4 py-2 rounded-full font-mono text-xs uppercase tracking-wider transition-all ${
              filter === type
                ? "bg-[#00F0FF] text-black"
                : "bg-white/5 text-white/60 hover:bg-white/10 hover:text-white"
            }`}
          >
            {type}
          </button>
        ))}
      </div>

      {/* Posts grid */}
      <div className="grid gap-4">
        {filteredPosts.map((post, index) => {
          const TypeIcon = typeIcons[post.type]
          const typeColor = typeColors[post.type]

          return (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="bg-black/40 border border-white/10 rounded-lg p-5 hover:border-[#00F0FF]/30 transition-all group"
            >
              {/* Header */}
              <div className="flex items-start gap-4 mb-4">
                <div
                  className="relative w-12 h-12 rounded-full overflow-hidden border-2"
                  style={{ borderColor: typeColor }}
                >
                  <img
                    src={post.avatar || "/placeholder.svg"}
                    alt={post.author}
                    className="w-full h-full object-cover"
                  />
                  <div
                    className="absolute inset-0 rounded-full"
                    style={{ boxShadow: `inset 0 0 20px ${typeColor}40` }}
                  />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white">{post.author}</span>
                    <TypeIcon className="w-4 h-4" style={{ color: typeColor }} />
                  </div>
                  <span className="text-white/40 text-sm font-mono">@{post.handle}</span>
                </div>
                <span className="text-white/30 text-xs font-mono">{new Date(post.timestamp).toLocaleDateString()}</span>
              </div>

              {/* Content */}
              <p className="text-white/80 leading-relaxed mb-4">{post.content}</p>

              {/* Footer */}
              <div className="flex items-center justify-between pt-4 border-t border-white/5">
                <div className="flex items-center gap-6">
                  <span className="flex items-center gap-2 text-white/40 text-sm">
                    <Heart className="w-4 h-4" />
                    {post.likes.toLocaleString()}
                  </span>
                  <span className="flex items-center gap-2 text-white/40 text-sm">
                    <Repeat2 className="w-4 h-4" />
                    {post.retweets.toLocaleString()}
                  </span>
                </div>
                <a
                  href={`https://twitter.com/${post.handle}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-[#00F0FF]/60 hover:text-[#00F0FF] text-sm transition-colors"
                >
                  <span className="font-mono">View on X</span>
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </motion.div>
          )
        })}
      </div>

      {/* Source attribution */}
      <div className="text-center pt-8 border-t border-white/10">
        <p className="text-white/30 font-mono text-xs">Curated from #Film3 community voices on X</p>
      </div>
    </div>
  )
}
