export function SEOSchema() {
  const schema = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "789 Studios",
    description: "Web3 Creator Ecosystem & Virtual Production Platform",
    url: "https://789studios.com",
    logo: "https://789studios.com/789-logo.png",
    sameAs: ["https://twitter.com/789studios", "https://discord.gg/789studios", "https://github.com/789studios"],
    offers: [
      {
        "@type": "Offer",
        name: "Recording Studio Services",
        description: "Professional recording, mixing, and mastering services",
        price: "75",
        priceCurrency: "USD",
        availability: "https://schema.org/InStock",
      },
      {
        "@type": "Course",
        name: "Film3: Web2 Filmmakers Meet Web3",
        description: "Comprehensive course on blockchain filmmaking featuring FLINCH NFT case study",
        provider: {
          "@type": "Person",
          name: "NEURO",
        },
        offers: {
          "@type": "Offer",
          price: "149",
          priceCurrency: "USD",
        },
      },
    ],
  }

  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
}
