"use client"

import { useEffect, useState } from "react"

// Animated floating 3D-style vectors for film production & blockchain
export function Elevator3DVectors() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Film Reel - Top Left */}
      <svg
        className="absolute top-8 left-8 w-16 h-16 text-cyan-500/30 animate-spin-slow"
        viewBox="0 0 100 100"
        fill="none"
        style={{ animationDuration: "8s" }}
      >
        <circle cx="50" cy="50" r="45" stroke="currentColor" strokeWidth="3" />
        <circle cx="50" cy="50" r="35" stroke="currentColor" strokeWidth="2" />
        <circle cx="50" cy="50" r="10" fill="currentColor" />
        {/* Sprocket holes */}
        {[0, 45, 90, 135, 180, 225, 270, 315].map((angle) => (
          <circle
            key={angle}
            cx={50 + 40 * Math.cos((angle * Math.PI) / 180)}
            cy={50 + 40 * Math.sin((angle * Math.PI) / 180)}
            r="4"
            fill="currentColor"
          />
        ))}
      </svg>

      {/* Clapperboard - Top Right */}
      <svg
        className="absolute top-12 right-12 w-14 h-14 text-orange-500/40"
        viewBox="0 0 100 100"
        fill="none"
        style={{ animation: "float 4s ease-in-out infinite" }}
      >
        {/* Clapper top */}
        <path
          d="M10 30 L90 30 L85 15 L15 15 Z"
          fill="currentColor"
          style={{ animation: "clap 2s ease-in-out infinite" }}
        />
        {/* Stripes on clapper */}
        <rect x="20" y="16" width="12" height="13" fill="black" opacity="0.5" />
        <rect x="44" y="16" width="12" height="13" fill="black" opacity="0.5" />
        <rect x="68" y="16" width="12" height="13" fill="black" opacity="0.5" />
        {/* Board body */}
        <rect x="10" y="30" width="80" height="55" rx="3" stroke="currentColor" strokeWidth="3" fill="none" />
        {/* Text lines */}
        <line x1="20" y1="45" x2="80" y2="45" stroke="currentColor" strokeWidth="2" opacity="0.5" />
        <line x1="20" y1="55" x2="70" y2="55" stroke="currentColor" strokeWidth="2" opacity="0.5" />
        <line x1="20" y1="65" x2="60" y2="65" stroke="currentColor" strokeWidth="2" opacity="0.5" />
      </svg>

      {/* Blockchain Cube - Center Left */}
      <div
        className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12"
        style={{ animation: "float 5s ease-in-out infinite", animationDelay: "1s" }}
      >
        <svg viewBox="0 0 100 100" className="w-full h-full text-purple-500/30">
          {/* 3D Cube */}
          <polygon points="50,10 90,30 90,70 50,90 10,70 10,30" fill="none" stroke="currentColor" strokeWidth="2" />
          <line x1="50" y1="10" x2="50" y2="50" stroke="currentColor" strokeWidth="2" />
          <line x1="90" y1="30" x2="50" y2="50" stroke="currentColor" strokeWidth="2" />
          <line x1="10" y1="30" x2="50" y2="50" stroke="currentColor" strokeWidth="2" />
          <line x1="50" y1="50" x2="50" y2="90" stroke="currentColor" strokeWidth="2" />
          {/* Chain links */}
          <circle cx="50" cy="10" r="5" fill="currentColor" />
          <circle cx="90" cy="30" r="5" fill="currentColor" />
          <circle cx="10" cy="30" r="5" fill="currentColor" />
          <circle cx="50" cy="90" r="5" fill="currentColor" />
        </svg>
      </div>

      {/* Camera - Bottom Left */}
      <svg
        className="absolute bottom-16 left-10 w-12 h-12 text-cyan-400/25"
        viewBox="0 0 100 100"
        fill="none"
        style={{ animation: "float 6s ease-in-out infinite", animationDelay: "2s" }}
      >
        {/* Camera body */}
        <rect x="15" y="35" width="50" height="35" rx="5" stroke="currentColor" strokeWidth="3" />
        {/* Lens */}
        <circle cx="75" cy="52" r="18" stroke="currentColor" strokeWidth="3" />
        <circle cx="75" cy="52" r="10" stroke="currentColor" strokeWidth="2" />
        <circle cx="75" cy="52" r="4" fill="currentColor" />
        {/* Viewfinder */}
        <rect x="20" y="25" width="15" height="10" rx="2" stroke="currentColor" strokeWidth="2" />
        {/* Film magazine */}
        <circle cx="30" cy="45" r="6" stroke="currentColor" strokeWidth="2" />
        <circle cx="50" cy="45" r="6" stroke="currentColor" strokeWidth="2" />
      </svg>

      {/* Blockchain Network Nodes - Right Side */}
      <svg
        className="absolute right-6 top-1/3 w-20 h-24 text-green-500/25"
        viewBox="0 0 100 120"
        fill="none"
        style={{ animation: "pulse-glow 3s ease-in-out infinite" }}
      >
        {/* Network nodes */}
        <circle cx="50" cy="20" r="8" fill="currentColor" className="animate-pulse" />
        <circle
          cx="20"
          cy="60"
          r="8"
          fill="currentColor"
          className="animate-pulse"
          style={{ animationDelay: "0.5s" }}
        />
        <circle cx="80" cy="60" r="8" fill="currentColor" className="animate-pulse" style={{ animationDelay: "1s" }} />
        <circle
          cx="35"
          cy="100"
          r="8"
          fill="currentColor"
          className="animate-pulse"
          style={{ animationDelay: "1.5s" }}
        />
        <circle cx="65" cy="100" r="8" fill="currentColor" className="animate-pulse" style={{ animationDelay: "2s" }} />
        {/* Connection lines */}
        <line x1="50" y1="20" x2="20" y2="60" stroke="currentColor" strokeWidth="2" strokeDasharray="4,4">
          <animate attributeName="stroke-dashoffset" from="0" to="8" dur="1s" repeatCount="indefinite" />
        </line>
        <line x1="50" y1="20" x2="80" y2="60" stroke="currentColor" strokeWidth="2" strokeDasharray="4,4">
          <animate attributeName="stroke-dashoffset" from="0" to="8" dur="1s" repeatCount="indefinite" />
        </line>
        <line x1="20" y1="60" x2="35" y2="100" stroke="currentColor" strokeWidth="2" strokeDasharray="4,4">
          <animate attributeName="stroke-dashoffset" from="0" to="8" dur="1s" repeatCount="indefinite" />
        </line>
        <line x1="80" y1="60" x2="65" y2="100" stroke="currentColor" strokeWidth="2" strokeDasharray="4,4">
          <animate attributeName="stroke-dashoffset" from="0" to="8" dur="1s" repeatCount="indefinite" />
        </line>
        <line x1="35" y1="100" x2="65" y2="100" stroke="currentColor" strokeWidth="2" strokeDasharray="4,4">
          <animate attributeName="stroke-dashoffset" from="0" to="8" dur="1s" repeatCount="indefinite" />
        </line>
      </svg>

      {/* Film Strip - Bottom */}
      <svg
        className="absolute bottom-8 left-1/2 -translate-x-1/2 w-32 h-8 text-white/10"
        viewBox="0 0 200 40"
        fill="none"
      >
        <rect x="0" y="5" width="200" height="30" fill="currentColor" rx="2" />
        {/* Perforations */}
        {[10, 30, 50, 70, 90, 110, 130, 150, 170, 190].map((x) => (
          <g key={x}>
            <rect x={x - 4} y="8" width="8" height="5" rx="1" fill="black" />
            <rect x={x - 4} y="27" width="8" height="5" rx="1" fill="black" />
          </g>
        ))}
        {/* Frames */}
        {[20, 60, 100, 140, 180].map((x, i) => (
          <rect
            key={x}
            x={x - 12}
            y="14"
            width="24"
            height="12"
            rx="1"
            fill="none"
            stroke="rgba(0,255,255,0.3)"
            strokeWidth="1"
            style={{ animation: `pulse 2s ease-in-out infinite`, animationDelay: `${i * 0.2}s` }}
          />
        ))}
      </svg>

      {/* Play Button / Director's Chair - Bottom Right */}
      <svg
        className="absolute bottom-20 right-8 w-10 h-10 text-orange-400/30"
        viewBox="0 0 100 100"
        fill="none"
        style={{ animation: "float 4.5s ease-in-out infinite", animationDelay: "0.5s" }}
      >
        {/* Play triangle in circle */}
        <circle cx="50" cy="50" r="40" stroke="currentColor" strokeWidth="3" />
        <polygon points="40,30 40,70 75,50" fill="currentColor" />
      </svg>

      {/* NFT Token - Top Center */}
      <svg
        className="absolute top-6 left-1/2 -translate-x-1/2 w-10 h-10 text-pink-500/30"
        viewBox="0 0 100 100"
        fill="none"
        style={{ animation: "spin-slow 10s linear infinite" }}
      >
        {/* Hexagon token */}
        <polygon points="50,5 93,27.5 93,72.5 50,95 7,72.5 7,27.5" stroke="currentColor" strokeWidth="3" fill="none" />
        <text
          x="50"
          y="58"
          textAnchor="middle"
          fill="currentColor"
          fontSize="24"
          fontFamily="monospace"
          fontWeight="bold"
        >
          NFT
        </text>
      </svg>

      {/* Floating Particles */}
      {[...Array(8)].map((_, i) => (
        <div
          key={i}
          className="absolute w-1 h-1 rounded-full bg-cyan-500/40"
          style={{
            left: `${10 + i * 12}%`,
            top: `${20 + (i % 3) * 25}%`,
            animation: `float ${3 + i * 0.5}s ease-in-out infinite`,
            animationDelay: `${i * 0.3}s`,
          }}
        />
      ))}
    </div>
  )
}
