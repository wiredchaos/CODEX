"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Headphones, TrendingUp, Radio, ExternalLink } from "lucide-react"
import Link from "next/link"

export function LurkyIntegration() {
  return (
    <section className="space-y-8">
      <div className="glass-panel border-2 border-cyan-500/30 p-8 rounded-lg relative overflow-hidden">
        {/* Background animation */}
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-transparent" />

        <div className="relative z-10 grid md:grid-cols-2 gap-8 items-center">
          <div className="space-y-6">
            <div className="space-y-2">
              <Badge className="font-mono text-xs bg-cyan-500/20 text-cyan-400 border-cyan-500/50">
                <Radio className="w-3 h-3 mr-1 animate-pulse" />
                POWERED BY LURKY
              </Badge>
              <h3 className="font-mono text-2xl font-bold text-white">The Market Talks. Lurky Listens.</h3>
              <p className="font-mono text-sm text-white/80 leading-relaxed">
                Lurky listens to every important X Space, extracts real-time alpha, and delivers insights—so you can
                hear what matters, before the market reacts.
              </p>
            </div>

            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <Headphones className="w-5 h-5 text-cyan-400 mt-1" />
                <div>
                  <div className="font-mono text-sm text-white font-semibold">Cut Through the Chatter</div>
                  <div className="font-mono text-xs text-white/70">
                    No need to scroll or listen for hours—Lurky does it for you
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <TrendingUp className="w-5 h-5 text-cyan-400 mt-1" />
                <div>
                  <div className="font-mono text-sm text-white font-semibold">Real-Time Alpha</div>
                  <div className="font-mono text-xs text-white/70">
                    Get insights from millions of conversations across crypto Spaces
                  </div>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <Link
                href="https://alpha.lurky.app/"
                target="_blank"
                className="inline-flex items-center gap-2 font-mono text-sm bg-cyan-500/20 text-cyan-400 border border-cyan-500/50 px-4 py-2 rounded-lg hover:bg-cyan-500/30 hover:border-cyan-500 transition-all"
              >
                Access Lurky Alpha
                <ExternalLink className="w-4 h-4" />
              </Link>

              <Link
                href="https://lurky.app"
                target="_blank"
                className="inline-flex items-center gap-2 font-mono text-sm text-white/70 border border-white/20 px-4 py-2 rounded-lg hover:text-white hover:border-white/40 transition-all"
              >
                Learn More
              </Link>
            </div>
          </div>

          <div className="space-y-4">
            <Card className="glass-panel border border-white/10 p-4 space-y-3">
              <div className="font-mono text-xs text-white/60 uppercase">Live Insights from 789 Spaces</div>

              <div className="space-y-2">
                {[
                  { topic: "NEURO Tech Talk", signal: "AI Integration trending", time: "1:23 AM" },
                  { topic: "VIBES Energy Hour", signal: "Community sentiment: Bullish", time: "7:15 PM" },
                  { topic: "GATOR Game Night", signal: "NFT gaming discussion", time: "9:42 PM" },
                ].map((insight, i) => (
                  <div
                    key={i}
                    className="bg-black/40 border border-cyan-500/20 p-3 rounded space-y-1 hover:border-cyan-500/40 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <div className="font-mono text-xs text-white font-semibold">{insight.topic}</div>
                      <div className="font-mono text-[10px] text-white/50">{insight.time}</div>
                    </div>
                    <div className="font-mono text-xs text-cyan-400">{insight.signal}</div>
                  </div>
                ))}
              </div>

              <div className="text-center pt-2">
                <div className="font-mono text-[10px] text-white/40">Powered by Lurky • Real-time Space analysis</div>
              </div>
            </Card>
          </div>
        </div>
      </div>

      <div className="text-center">
        <p className="font-mono text-xs text-white/50">© Stashh Labs 2025 • Integration with 789 Studios</p>
      </div>
    </section>
  )
}
