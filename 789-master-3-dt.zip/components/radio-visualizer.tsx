"use client"

import { useEffect, useRef, useState } from "react"

export function RadioVisualizer() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isPlaying, setIsPlaying] = useState(false)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = 300
    canvas.height = 100

    const bars = 32
    const barWidth = canvas.width / bars - 2
    let animationId: number

    const animate = () => {
      ctx.fillStyle = "#0a0a14"
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      for (let i = 0; i < bars; i++) {
        const height = isPlaying ? Math.random() * 60 + 10 : 10 + Math.sin(Date.now() / 500 + i * 0.5) * 5

        const gradient = ctx.createLinearGradient(0, canvas.height - height, 0, canvas.height)
        gradient.addColorStop(0, "#00ffff")
        gradient.addColorStop(0.5, "#ff00ff")
        gradient.addColorStop(1, "#ffd700")

        ctx.fillStyle = gradient
        ctx.fillRect(i * (barWidth + 2), canvas.height - height, barWidth, height)
      }

      animationId = requestAnimationFrame(animate)
    }

    animate()

    return () => cancelAnimationFrame(animationId)
  }, [isPlaying])

  return (
    <div className="flex flex-col items-center gap-4 p-6 rounded-xl bg-card/50 backdrop-blur border border-[#ffd700]/30">
      <div className="flex items-center gap-3">
        <span className="neon-text-gold font-mono font-black text-2xl">33.3</span>
        <span className="text-muted-foreground font-mono">FM</span>
        <div className={`w-3 h-3 rounded-full ${isPlaying ? "bg-[#00ff88] animate-pulse" : "bg-muted"}`} />
      </div>

      <canvas ref={canvasRef} className="rounded-lg" />

      <button
        onClick={() => setIsPlaying(!isPlaying)}
        className="px-6 py-2 rounded-full font-mono font-bold uppercase tracking-wider transition-all"
        style={{
          background: isPlaying ? "#ffd700" : "transparent",
          color: isPlaying ? "#0a0a14" : "#ffd700",
          border: "2px solid #ffd700",
          boxShadow: isPlaying ? "0 0 20px #ffd700, 0 0 40px #ffd700" : "none",
        }}
      >
        {isPlaying ? "LIVE" : "TUNE IN"}
      </button>
    </div>
  )
}
