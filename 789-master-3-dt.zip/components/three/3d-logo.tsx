"use client"

import { Canvas, useFrame } from "@react-three/fiber"
import { Float, Text3D, Center } from "@react-three/drei"
import { useRef, Suspense } from "react"
import type * as THREE from "three"

function RotatingLogo({ text }: { text: string }) {
  const meshRef = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y = state.clock.elapsedTime * 0.5
    }
  })

  return (
    <Float speed={2} rotationIntensity={0.5} floatIntensity={0.5}>
      <Center>
        <Text3D
          ref={meshRef}
          font="/fonts/Geist_Bold.json"
          size={1}
          height={0.2}
          curveSegments={12}
          bevelEnabled
          bevelThickness={0.02}
          bevelSize={0.02}
          bevelOffset={0}
          bevelSegments={5}
        >
          {text}
          <meshStandardMaterial color="#ff8800" emissive="#ff8800" emissiveIntensity={0.5} metalness={0.9} />
        </Text3D>
      </Center>
    </Float>
  )
}

export function ThreeDLogo({ text = "789", className = "" }: { text?: string; className?: string }) {
  return (
    <div className={`w-full h-full ${className}`}>
      <Canvas camera={{ position: [0, 0, 5], fov: 50 }}>
        <Suspense fallback={null}>
          <ambientLight intensity={0.3} />
          <pointLight position={[10, 10, 10]} intensity={1.5} color="#00ffff" />
          <pointLight position={[-10, -10, -10]} intensity={0.8} color="#ff8800" />
          <RotatingLogo text={text} />
        </Suspense>
      </Canvas>
    </div>
  )
}
