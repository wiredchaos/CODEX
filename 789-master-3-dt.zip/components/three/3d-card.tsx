"use client"

import type React from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { Float, PerspectiveCamera, Environment } from "@react-three/drei"
import { useRef, Suspense } from "react"
import type * as THREE from "three"

function FloatingCard({ children, ...props }: { children?: React.ReactNode } & React.ComponentProps<"group">) {
  const groupRef = useRef<THREE.Group>(null)

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.3) * 0.1
      groupRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.2) * 0.05
    }
  })

  return (
    <Float speed={1.5} rotationIntensity={0.3} floatIntensity={0.4}>
      <group ref={groupRef} {...props}>
        {children}
      </group>
    </Float>
  )
}

export function ThreeDCard({ className = "" }: { className?: string }) {
  return (
    <div className={`w-full h-full ${className}`}>
      <Canvas>
        <Suspense fallback={null}>
          <PerspectiveCamera makeDefault position={[0, 0, 5]} />
          <ambientLight intensity={0.5} />
          <pointLight position={[10, 10, 10]} intensity={1} color="#00ffff" />
          <pointLight position={[-10, -10, -10]} intensity={0.5} color="#ff8800" />

          <FloatingCard>
            <mesh>
              <boxGeometry args={[2, 3, 0.1]} />
              <meshStandardMaterial
                color="#0a0a0f"
                emissive="#00ffff"
                emissiveIntensity={0.3}
                metalness={0.8}
                roughness={0.2}
              />
            </mesh>
          </FloatingCard>

          <Environment preset="night" />
        </Suspense>
      </Canvas>
    </div>
  )
}
