"use client"

import { Canvas, useFrame } from "@react-three/fiber"
import { Sphere, OrbitControls, Stars } from "@react-three/drei"
import { useRef, Suspense } from "react"
import type * as THREE from "three"

function RotatingGlobe() {
  const sphereRef = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    if (sphereRef.current) {
      sphereRef.current.rotation.y += 0.002
    }
  })

  return (
    <Sphere ref={sphereRef} args={[2, 64, 64]}>
      <meshStandardMaterial
        color="#001a1a"
        emissive="#00ffff"
        emissiveIntensity={0.2}
        metalness={0.9}
        roughness={0.1}
        wireframe
      />
    </Sphere>
  )
}

export function ThreeDGlobe({ className = "" }: { className?: string }) {
  return (
    <div className={`w-full h-full ${className}`}>
      <Canvas camera={{ position: [0, 0, 6], fov: 60 }}>
        <Suspense fallback={null}>
          <ambientLight intensity={0.2} />
          <pointLight position={[10, 10, 10]} intensity={1} color="#00ffff" />
          <RotatingGlobe />
          <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
          <OrbitControls enableZoom={false} autoRotate autoRotateSpeed={0.5} />
        </Suspense>
      </Canvas>
    </div>
  )
}
