"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { X, ArrowRight, SkipForward, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { INTAKE_QUESTIONS, NeuroConcierge } from "@/lib/kilo/concierge"
import { TourStateMachine } from "@/lib/kilo/tour"
import { TrinityLogic } from "@/lib/trinity/logic"
import { useRouter } from "next/navigation"
import Image from "next/image"

export function NeuroConciergeModal() {
  const router = useRouter()
  const [isOpen, setIsOpen] = useState(false)
  const [greeting, setGreeting] = useState("")
  const [tourMachine] = useState(() => new TourStateMachine())
  const [concierge] = useState(() => new NeuroConcierge())
  const [trinityLogic] = useState(() => new TrinityLogic())
  const [currentStep, setCurrentStep] = useState<"greeting" | "intake" | "plan" | "launching">("greeting")
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [responses, setResponses] = useState<Record<string, string[]>>({})
  const [tourPlanMessage, setTourPlanMessage] = useState("")

  useEffect(() => {
    const hasSeenConcierge = localStorage.getItem("789_concierge_seen")
    if (!hasSeenConcierge) {
      setTimeout(() => {
        setIsOpen(true)
        loadGreeting()
      }, 1000)
    }
  }, [])

  async function loadGreeting() {
    const msg = await concierge.generateGreeting()
    setGreeting(msg)
  }

  function handleStartTour() {
    setCurrentStep("intake")
    tourMachine.dispatch({ type: "START_TOUR" })
  }

  function handleSkipToElevator() {
    localStorage.setItem("789_concierge_seen", "true")
    tourMachine.dispatch({ type: "SKIP_TOUR" })
    setIsOpen(false)
  }

  function handleClose() {
    localStorage.setItem("789_concierge_seen", "true")
    setIsOpen(false)
  }

  function handleAnswerSelect(questionId: string, answer: string, isMultiple: boolean) {
    if (isMultiple) {
      const current = responses[questionId] || []
      const updated = current.includes(answer) ? current.filter((a) => a !== answer) : [...current, answer]
      setResponses({ ...responses, [questionId]: updated })
    } else {
      setResponses({ ...responses, [questionId]: [answer] })
    }
  }

  async function handleNextQuestion() {
    if (currentQuestion < INTAKE_QUESTIONS.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    } else {
      setCurrentStep("plan")
      const intakeResponses = Object.entries(responses).map(([questionId, answers]) => ({
        questionId,
        answers,
      }))

      tourMachine.dispatch({ type: "SUBMIT_INTAKE", payload: intakeResponses })

      const message = await concierge.generateTourIntro(intakeResponses)
      setTourPlanMessage(message)

      const goals = responses["goal"] || []
      const comfort = responses["comfort"]?.[0] || "intermediate"
      const format = responses["format"]?.[0] || "guided"

      const plan = trinityLogic.generateTourPlan(goals, comfort, format)
      trinityLogic.startTour(plan)
    }
  }

  function handleLaunchTour() {
    setCurrentStep("launching")
    tourMachine.dispatch({ type: "CONFIRM_PLAN" })
    localStorage.setItem("789_concierge_seen", "true")

    setTimeout(() => {
      setIsOpen(false)
      const plan = trinityLogic.getState().tourPlan
      if (plan && plan.floors.length > 0) {
        const firstFloor = plan.floors[0]
        router.push(`/${firstFloor}`)
      }
    }, 1500)
  }

  const currentQ = INTAKE_QUESTIONS[currentQuestion]
  const hasAnswer = currentQ && responses[currentQ.id]?.length > 0

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm p-4"
        >
          <motion.div
            initial={{ scale: 0.9, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="relative w-full max-w-2xl max-h-[90vh] flex flex-col bg-black/95 border-2 border-cyan-500/50 rounded-xl shadow-2xl overflow-hidden"
            style={{ boxShadow: "0 0 60px rgba(0, 255, 255, 0.3)" }}
          >
            {currentStep === "greeting" && (
              <button
                onClick={handleClose}
                className="absolute top-4 right-4 z-10 p-2 rounded-lg bg-background/80 hover:bg-muted transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            )}

            <div className="relative h-48 sm:h-56 bg-gradient-to-b from-cyan-950/50 to-transparent flex items-center justify-center overflow-hidden">
              <div className="relative w-32 h-32 sm:w-40 sm:h-40">
                <Image
                  src="/images/photo-20dec-2003-202025-2c-207-2045-2053-20am.png"
                  alt="NEURO Concierge"
                  fill
                  className="object-contain"
                  priority
                />
                {/* Animated glow ring */}
                <div
                  className="absolute inset-0 rounded-full border-2 border-cyan-500/50 animate-pulse"
                  style={{ transform: "scale(1.1)" }}
                />
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-6">
              {currentStep === "greeting" && (
                <div className="space-y-6">
                  <div>
                    <h2
                      className="text-xl sm:text-2xl font-bold mb-2"
                      style={{ color: "#00ffff", textShadow: "0 0 20px rgba(0, 255, 255, 0.7)" }}
                    >
                      NEURO CONCIERGE
                    </h2>
                    <p className="text-base sm:text-lg text-white/90">{greeting}</p>
                  </div>

                  <div className="flex flex-col gap-3">
                    <Button
                      onClick={handleStartTour}
                      className="w-full bg-cyan-500 hover:bg-cyan-600 text-black font-bold py-6"
                    >
                      Start Guided Tour
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                    <Button
                      onClick={handleSkipToElevator}
                      variant="outline"
                      className="w-full border-cyan-500/50 text-cyan-500 hover:bg-cyan-500/10 bg-transparent py-6"
                    >
                      Skip to Elevator
                      <SkipForward className="w-4 h-4 ml-2" />
                    </Button>
                  </div>

                  <p
                    className="text-sm text-center"
                    style={{ color: "#00ffff", textShadow: "0 0 10px rgba(0, 255, 255, 0.5)" }}
                  >
                    You can always access the elevator from anywhere in 789 Studios
                  </p>
                </div>
              )}

              {currentStep === "intake" && currentQ && (
                <div className="space-y-4 sm:space-y-6">
                  <div
                    className="flex items-center gap-2 text-sm mb-4"
                    style={{ color: "#00ffff", textShadow: "0 0 10px rgba(0, 255, 255, 0.5)" }}
                  >
                    <span className="font-mono">
                      Question {currentQuestion + 1} of {INTAKE_QUESTIONS.length}
                    </span>
                    <div className="flex-1 h-1 bg-cyan-500/20 rounded-full overflow-hidden">
                      <motion.div
                        className="h-full bg-cyan-500"
                        initial={{ width: 0 }}
                        animate={{ width: `${((currentQuestion + 1) / INTAKE_QUESTIONS.length) * 100}%` }}
                        transition={{ duration: 0.3 }}
                      />
                    </div>
                  </div>

                  <h3 className="text-lg sm:text-xl font-bold text-white">{currentQ.question}</h3>

                  <div className="space-y-2 sm:space-y-3 max-h-[35vh] overflow-y-auto">
                    {currentQ.options.map((option) => {
                      const isSelected = responses[currentQ.id]?.includes(option)
                      return (
                        <button
                          key={option}
                          onClick={() => handleAnswerSelect(currentQ.id, option, currentQ.type === "multiple")}
                          className={`w-full p-3 sm:p-4 rounded-lg border-2 transition-all text-left ${
                            isSelected
                              ? "border-cyan-500 bg-cyan-500/10"
                              : "border-white/10 hover:border-white/30 bg-white/5"
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-white text-sm sm:text-base">{option}</span>
                            {isSelected && <Check className="w-5 h-5 text-cyan-500 flex-shrink-0" />}
                          </div>
                        </button>
                      )
                    })}
                  </div>
                </div>
              )}

              {currentStep === "plan" && (
                <div className="space-y-6">
                  <div>
                    <h2
                      className="text-xl sm:text-2xl font-bold mb-4"
                      style={{ color: "#00ffff", textShadow: "0 0 20px rgba(0, 255, 255, 0.7)" }}
                    >
                      Your Personalized Tour
                    </h2>
                    <p className="text-base sm:text-lg text-white/90 mb-6">{tourPlanMessage}</p>
                  </div>

                  <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-4 sm:p-6 space-y-3">
                    <h3
                      className="font-bold mb-3"
                      style={{ color: "#00ffff", textShadow: "0 0 10px rgba(0, 255, 255, 0.5)" }}
                    >
                      Tour Stops:
                    </h3>
                    {trinityLogic.getState().tourPlan?.floors.map((floorId, index) => (
                      <div key={floorId} className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-cyan-500/20 border border-cyan-500 flex items-center justify-center text-sm font-bold text-cyan-500">
                          {index + 1}
                        </div>
                        <span className="text-white capitalize">{floorId.replace("-", " ")}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {currentStep === "launching" && (
                <div className="space-y-6 text-center py-8">
                  <div className="w-16 h-16 mx-auto rounded-full border-4 border-cyan-500 border-t-transparent animate-spin" />
                  <p
                    className="text-lg font-bold"
                    style={{ color: "#00ffff", textShadow: "0 0 15px rgba(0, 255, 255, 0.7)" }}
                  >
                    Boarding the elevator...
                  </p>
                </div>
              )}
            </div>

            {(currentStep === "intake" || currentStep === "plan") && (
              <div className="sticky bottom-0 left-0 right-0 bg-black/95 border-t border-cyan-500/30 p-4 pb-6 sm:pb-4">
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button
                    onClick={handleSkipToElevator}
                    variant="outline"
                    className="border-white/20 text-white/70 hover:bg-white/5 bg-transparent"
                  >
                    Skip Tour
                  </Button>
                  {currentStep === "intake" && (
                    <Button
                      onClick={handleNextQuestion}
                      disabled={!hasAnswer}
                      className="flex-1 bg-cyan-500 hover:bg-cyan-600 text-black font-bold disabled:opacity-50"
                    >
                      {currentQuestion < INTAKE_QUESTIONS.length - 1 ? "Next" : "Generate Tour"}
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  )}
                  {currentStep === "plan" && (
                    <Button
                      onClick={handleLaunchTour}
                      className="flex-1 bg-cyan-500 hover:bg-cyan-600 text-black font-bold"
                    >
                      Begin Tour
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  )}
                </div>
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
