"use client"

import { Card } from "@/components/ui/card"
import { Play, Eye, Heart, Share2, Lock, Clock } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface CreatorPost {
  id: string
  creator: string
  title: string
  thumbnail: string
  views: string
  likes: string
  timestamp: string
  isTokenGated: boolean
  blockchain: string
  platforms: string[]
  isComingSoon?: boolean
}

const CREATOR_POSTS: CreatorPost[] = [
  {
    id: "1",
    creator: "NEURO",
    title: "Building Web3 Creator Tools - Live Session",
    thumbnail: "/web3-creator-studio-recording.jpg",
    views: "12.5K",
    likes: "892",
    timestamp: "2 hours ago",
    isTokenGated: true,
    blockchain: "Dogecoin",
    platforms: ["YouTube", "X"],
  },
  {
    id: "2",
    creator: "WOOKI",
    title: "Crypto Spaces Network - Coming Soon",
    thumbnail: "/crypto-podcast-studio-neon.jpg",
    views: "0",
    likes: "0",
    timestamp: "Coming Soon",
    isTokenGated: false,
    blockchain: "Dogecoin",
    platforms: ["YouTube"],
    isComingSoon: true,
  },
  {
    id: "3",
    creator: "VIBES",
    title: "Community Content - Coming Soon",
    thumbnail: "/music-production-studio-equipment.jpg",
    views: "0",
    likes: "0",
    timestamp: "Coming Soon",
    isTokenGated: false,
    blockchain: "Dogecoin",
    platforms: ["YouTube"],
    isComingSoon: true,
  },
  {
    id: "4",
    creator: "GATOR",
    title: "Gaming Content - Coming Soon",
    thumbnail: "/nft-art-studio-creation.jpg",
    views: "0",
    likes: "0",
    timestamp: "Coming Soon",
    isTokenGated: false,
    blockchain: "Dogecoin",
    platforms: ["YouTube"],
    isComingSoon: true,
  },
  {
    id: "5",
    creator: "JEEP",
    title: "Hip-Hop Culture - Coming Soon",
    thumbnail: "/film-production-cinema-camera.jpg",
    views: "0",
    likes: "0",
    timestamp: "Coming Soon",
    isTokenGated: false,
    blockchain: "Dogecoin",
    platforms: ["YouTube"],
    isComingSoon: true,
  },
  {
    id: "6",
    creator: "ARTSY",
    title: "Creative Direction - Coming Soon",
    thumbnail: "/blockchain-economics-crypto-chart.jpg",
    views: "0",
    likes: "0",
    timestamp: "Coming Soon",
    isTokenGated: false,
    blockchain: "Dogecoin",
    platforms: ["YouTube"],
    isComingSoon: true,
  },
]

export function CreatorContentFeed() {
  return (
    <div className="space-y-6">
      {/* Feed Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-mono text-2xl font-bold text-white mb-1">Creator Feed</h2>
          <p className="font-mono text-sm text-white/70">
            Latest content from 789 Studios creators - NEURO active, others coming soon
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="border-[#00ffff]/50 text-[#00ffff] font-mono">
            <div className="w-1.5 h-1.5 bg-[#00ffff] rounded-full mr-2 animate-pulse" />
            LIVE
          </Badge>
        </div>
      </div>

      {/* Content Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {CREATOR_POSTS.map((post) => (
          <Card
            key={post.id}
            className={`glass-panel border-white/10 overflow-hidden hover:border-[#ffd700]/50 transition-all duration-300 cursor-pointer group ${
              post.isComingSoon ? "opacity-70" : "hover:scale-105"
            }`}
          >
            {/* Thumbnail */}
            <div className="relative aspect-video overflow-hidden">
              <img src={post.thumbnail || "/placeholder.svg"} alt={post.title} className="w-full h-full object-cover" />

              {!post.isComingSoon && (
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div
                    className="w-16 h-16 rounded-full bg-[#ffd700]/20 backdrop-blur-sm border-2 border-[#ffd700] flex items-center justify-center"
                    style={{ boxShadow: "0 0 30px rgba(255, 215, 0, 0.6)" }}
                  >
                    <Play className="w-8 h-8 text-[#ffd700] ml-1" fill="#ffd700" />
                  </div>
                </div>
              )}

              {post.isComingSoon && (
                <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                  <div className="text-center space-y-2">
                    <Clock className="w-12 h-12 text-white/50 mx-auto" />
                    <div className="font-mono text-sm text-white/80">COMING SOON</div>
                  </div>
                </div>
              )}

              {/* Token gated badge */}
              {post.isTokenGated && !post.isComingSoon && (
                <div className="absolute top-2 right-2">
                  <Badge className="bg-[#daa520]/90 border-[#daa520] text-white font-mono text-xs">
                    <Lock className="w-3 h-3 mr-1" />
                    TOKEN GATED
                  </Badge>
                </div>
              )}

              {/* Platform badges */}
              <div className="absolute bottom-2 left-2 flex gap-1">
                {post.platforms.map((platform) => (
                  <Badge
                    key={platform}
                    variant="secondary"
                    className="bg-black/80 backdrop-blur-sm border-white/20 text-white font-mono text-[10px] px-2 py-0.5"
                  >
                    {platform}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Content Info */}
            <div className="p-4 space-y-3">
              <div className="flex items-start justify-between gap-2">
                <h3 className="font-mono text-sm font-bold text-white line-clamp-2 flex-1">{post.title}</h3>
              </div>

              <div className="flex items-center gap-2">
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center border-2 text-xs font-mono font-bold"
                  style={{ borderColor: "#00ffff", color: "#00ffff" }}
                >
                  {post.creator.slice(0, 2)}
                </div>
                <div className="flex-1">
                  <div className="font-mono text-xs font-bold text-white">{post.creator}</div>
                  <div className="font-mono text-[10px] text-white/60">{post.timestamp}</div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-white/10">
                <div className="flex items-center gap-4 font-mono text-xs text-white/70">
                  <div className="flex items-center gap-1">
                    <Eye className="w-4 h-4" />
                    <span>{post.views}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Heart className="w-4 h-4" />
                    <span>{post.likes}</span>
                  </div>
                </div>
                {!post.isComingSoon && (
                  <button className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors">
                    <Share2 className="w-4 h-4 text-white/70" />
                  </button>
                )}
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
