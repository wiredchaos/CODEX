"use client"

interface StudioBayCardProps {
  title: string
  episodeId: string
  description: string
  duration?: string
  status?: "live" | "on-demand" | "arg"
  thumbnail?: string
  onClick?: () => void
}

export function StudioBayCard({
  title,
  episodeId,
  description,
  duration = "45:30",
  status = "on-demand",
  thumbnail,
  onClick,
}: StudioBayCardProps) {
  const statusColors = {
    live: "#00ffff",
    "on-demand": "#ffd700",
    arg: "#daa520",
  }

  const statusLabels = {
    live: "LIVE",
    "on-demand": "AVAILABLE",
    arg: "PREMIUM",
  }

  return (
    <div className="studio-bay rounded-lg overflow-hidden cursor-pointer group" onClick={onClick}>
      {/* Thumbnail */}
      <div className="relative aspect-video bg-gradient-to-br from-black/80 to-black/60 overflow-hidden">
        {thumbnail ? (
          <img
            src={thumbnail || "/placeholder.svg"}
            alt={title}
            className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <div className="text-6xl opacity-20 group-hover:opacity-30 transition-opacity">⬡</div>
          </div>
        )}

        <div className="absolute top-3 left-3 font-mono text-xs font-bold px-2 py-1 rounded neon-text-gold border border-[#ffd700]/40 bg-black/90 backdrop-blur-md">
          {episodeId}
        </div>

        {/* Status badge */}
        <div
          className="absolute top-3 right-3 font-mono text-[10px] font-bold px-2 py-1 rounded flex items-center gap-1.5 border bg-black/90 backdrop-blur-md"
          style={{
            color: statusColors[status],
            borderColor: `${statusColors[status]}50`,
            boxShadow: `0 0 10px ${statusColors[status]}40`,
          }}
        >
          <span
            className="w-1.5 h-1.5 rounded-full"
            style={{ background: statusColors[status], boxShadow: `0 0 6px ${statusColors[status]}` }}
          />
          {statusLabels[status]}
        </div>

        {/* Duration */}
        <div className="absolute bottom-3 right-3 font-mono text-xs font-bold px-2 py-1 rounded bg-black/90 backdrop-blur-md text-white/90">
          {duration}
        </div>

        <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
          <div
            className="absolute inset-0 border-2 border-[#ffd700]/60"
            style={{ boxShadow: "inset 0 0 20px rgba(255, 215, 0, 0.3)" }}
          />
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-2">
        <h3 className="font-mono font-bold text-lg chrome-text line-clamp-1">{title}</h3>
        <p className="font-mono text-xs text-white/70 line-clamp-2">{description}</p>
      </div>
    </div>
  )
}
