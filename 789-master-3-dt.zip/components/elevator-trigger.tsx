"use client"

import { useElevator } from "@/lib/core/elevator/elevator-provider"
import { GlassSurface } from "@/lib/core/ui-glass/glass-surface"
import { ArrowUpDown } from "lucide-react"

export function ElevatorTrigger() {
  const { openElevator } = useElevator()

  return (
    <button
      onClick={openElevator}
      className="fixed bottom-20 sm:bottom-4 left-4 z-40"
      aria-label="Open elevator navigation"
    >
      <GlassSurface blur="heavy" opacity="medium" border="accent" glow="subtle" interactive className="p-3">
        <ArrowUpDown className="w-6 h-6 text-cyan-400" />
      </GlassSurface>
    </button>
  )
}
