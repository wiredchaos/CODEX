"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Bot, Sparkles, Zap, Share2, Copy, ExternalLink, ChevronLeft, ChevronRight, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { Campaign } from "@/lib/lurky/campaign-crawler"

interface PromoCard {
  campaign: Campaign
  promoText: string
  hashtags: string[]
}

export function LurkyCampaignBot() {
  const [promos, setPromos] = useState<PromoCard[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [loading, setLoading] = useState(true)
  const [generating, setGenerating] = useState(false)
  const [copied, setCopied] = useState(false)
  const [filter, setFilter] = useState<string>("all")

  useEffect(() => {
    fetchPromos()
  }, [filter])

  async function fetchPromos() {
    setLoading(true)
    try {
      const params = new URLSearchParams({ promo: "true" })
      if (filter !== "all") params.append("type", filter)

      const res = await fetch(`/api/lurky/campaigns?${params}`)
      const data = await res.json()
      setPromos(data.promos || [])
      setCurrentIndex(0)
    } catch (error) {
      console.error("Failed to fetch promos:", error)
    } finally {
      setLoading(false)
    }
  }

  async function regenerate() {
    setGenerating(true)
    await fetchPromos()
    setGenerating(false)
  }

  function copyPromo() {
    if (!promos[currentIndex]) return
    const promo = promos[currentIndex]
    const text = `${promo.promoText}\n\n${promo.hashtags.join(" ")}`
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  function shareToX() {
    if (!promos[currentIndex]) return
    const promo = promos[currentIndex]
    const text = encodeURIComponent(`${promo.promoText}\n\n${promo.hashtags.join(" ")}`)
    window.open(`https://twitter.com/intent/tweet?text=${text}`, "_blank")
  }

  const currentPromo = promos[currentIndex]

  return (
    <div className="relative overflow-hidden rounded-2xl border border-cyan-500/30 bg-black/80 backdrop-blur-xl">
      {/* Holographic Background */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/20 via-transparent to-fuchsia-500/20" />
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `
              linear-gradient(90deg, transparent 0%, rgba(0,255,255,0.03) 50%, transparent 100%),
              linear-gradient(0deg, transparent 0%, rgba(255,0,255,0.03) 50%, transparent 100%)
            `,
            backgroundSize: "100px 100px",
            animation: "holoPulse 4s ease-in-out infinite",
          }}
        />
      </div>

      {/* Header */}
      <div className="relative border-b border-cyan-500/20 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="absolute inset-0 animate-ping rounded-full bg-cyan-500/50" />
              <div className="relative rounded-full bg-gradient-to-br from-cyan-400 to-fuchsia-500 p-2">
                <Bot className="h-5 w-5 text-black" />
              </div>
            </div>
            <div>
              <h3 className="font-mono text-sm font-bold text-cyan-400">LURKY CAMPAIGN BOT</h3>
              <p className="font-mono text-xs text-white/50">Autonomous Promo Generator</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 rounded-full bg-green-500/20 px-2 py-1">
              <div className="h-2 w-2 animate-pulse rounded-full bg-green-400" />
              <span className="font-mono text-xs text-green-400">ACTIVE</span>
            </div>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="mt-4 flex flex-wrap gap-2">
          {["all", "documentary", "show", "space", "ally", "event"].map((type) => (
            <button
              key={type}
              onClick={() => setFilter(type)}
              className={`rounded-full px-3 py-1 font-mono text-xs transition-all ${
                filter === type ? "bg-cyan-500 text-black" : "bg-white/5 text-white/60 hover:bg-white/10"
              }`}
            >
              {type.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* 3D Promo Card Display */}
      <div className="relative min-h-[400px] p-6">
        {loading ? (
          <div className="flex h-[350px] items-center justify-center">
            <div className="text-center">
              <RefreshCw className="mx-auto h-8 w-8 animate-spin text-cyan-400" />
              <p className="mt-2 font-mono text-sm text-white/50">Crawling campaigns...</p>
            </div>
          </div>
        ) : promos.length === 0 ? (
          <div className="flex h-[350px] items-center justify-center">
            <p className="font-mono text-sm text-white/50">No campaigns found</p>
          </div>
        ) : (
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, rotateY: -15, scale: 0.9 }}
              animate={{ opacity: 1, rotateY: 0, scale: 1 }}
              exit={{ opacity: 0, rotateY: 15, scale: 0.9 }}
              transition={{ duration: 0.5, ease: "easeOut" }}
              className="perspective-1000"
            >
              {/* 3D Holographic Card */}
              <div
                className="relative mx-auto max-w-md transform-gpu rounded-xl border border-cyan-500/50 bg-gradient-to-br from-black via-cyan-950/20 to-black p-1"
                style={{
                  boxShadow: `
                    0 0 20px rgba(0,255,255,0.3),
                    0 0 40px rgba(0,255,255,0.1),
                    inset 0 0 60px rgba(0,255,255,0.05)
                  `,
                  transform: "perspective(1000px) rotateX(2deg)",
                }}
              >
                {/* Scanline Effect */}
                <div
                  className="pointer-events-none absolute inset-0 overflow-hidden rounded-xl opacity-20"
                  style={{
                    background:
                      "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,255,255,0.1) 2px, rgba(0,255,255,0.1) 4px)",
                  }}
                />

                <div className="relative rounded-lg bg-black/90 p-5">
                  {/* Campaign Type Badge */}
                  <div className="mb-4 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Sparkles className="h-4 w-4 text-fuchsia-400" />
                      <span className="font-mono text-xs uppercase tracking-wider text-fuchsia-400">
                        {currentPromo?.campaign.type}
                      </span>
                    </div>
                    <span className="rounded-full bg-cyan-500/20 px-2 py-0.5 font-mono text-xs text-cyan-400">
                      {currentPromo?.campaign.network}
                    </span>
                  </div>

                  {/* Title with Holographic Effect */}
                  <h4
                    className="mb-2 font-mono text-xl font-bold"
                    style={{
                      background: "linear-gradient(90deg, #00ffff, #ff00ff, #00ffff)",
                      backgroundSize: "200% 100%",
                      WebkitBackgroundClip: "text",
                      WebkitTextFillColor: "transparent",
                      animation: "shimmer 3s linear infinite",
                    }}
                  >
                    {currentPromo?.campaign.title}
                  </h4>

                  {currentPromo?.campaign.subtitle && (
                    <p className="mb-3 font-mono text-sm text-white/60">{currentPromo.campaign.subtitle}</p>
                  )}

                  {/* Promo Text */}
                  <div className="mb-4 rounded-lg border border-white/10 bg-white/5 p-3">
                    <p className="whitespace-pre-line font-mono text-sm leading-relaxed text-white/80">
                      {currentPromo?.promoText}
                    </p>
                  </div>

                  {/* Hashtags */}
                  <div className="mb-4 flex flex-wrap gap-2">
                    {currentPromo?.hashtags.map((tag, i) => (
                      <span
                        key={i}
                        className="rounded-full bg-gradient-to-r from-cyan-500/20 to-fuchsia-500/20 px-2 py-0.5 font-mono text-xs text-cyan-300"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  {/* CTA */}
                  <div className="flex items-center justify-between">
                    <a
                      href={currentPromo?.campaign.ctaLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 font-mono text-sm text-cyan-400 transition-colors hover:text-cyan-300"
                    >
                      {currentPromo?.campaign.ctaText}
                      <ExternalLink className="h-3 w-3" />
                    </a>
                    {currentPromo?.campaign.creator && (
                      <span className="font-mono text-xs text-white/40">by {currentPromo.campaign.creator}</span>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        )}

        {/* Navigation */}
        {promos.length > 1 && (
          <div className="mt-6 flex items-center justify-center gap-4">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setCurrentIndex((prev) => (prev - 1 + promos.length) % promos.length)}
              className="border-cyan-500/30 bg-black/50 text-cyan-400 hover:bg-cyan-500/20"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="font-mono text-sm text-white/60">
              {currentIndex + 1} / {promos.length}
            </span>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setCurrentIndex((prev) => (prev + 1) % promos.length)}
              className="border-cyan-500/30 bg-black/50 text-cyan-400 hover:bg-cyan-500/20"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>

      {/* Action Bar */}
      <div className="relative border-t border-cyan-500/20 p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <Button
            onClick={regenerate}
            disabled={generating}
            className="gap-2 bg-gradient-to-r from-cyan-500 to-fuchsia-500 font-mono text-black hover:opacity-90"
          >
            {generating ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Zap className="h-4 w-4" />}
            Regenerate
          </Button>

          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={copyPromo}
              className="gap-2 border-cyan-500/30 bg-black/50 font-mono text-cyan-400 hover:bg-cyan-500/20"
            >
              <Copy className="h-4 w-4" />
              {copied ? "Copied!" : "Copy"}
            </Button>
            <Button onClick={shareToX} className="gap-2 bg-white font-mono text-black hover:bg-white/90">
              <Share2 className="h-4 w-4" />
              Share to X
            </Button>
          </div>
        </div>
      </div>

      {/* CSS for animations */}
      <style jsx global>{`
        @keyframes holoPulse {
          0%, 100% { opacity: 0.3; }
          50% { opacity: 0.5; }
        }
        @keyframes shimmer {
          0% { background-position: 200% 0; }
          100% { background-position: -200% 0; }
        }
      `}</style>
    </div>
  )
}
