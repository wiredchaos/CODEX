// Film3 Community Section for RUPTURE documentary
// Displays curated #Film3 voices from the movement
"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Heart, Repeat2, Radio, Video, FileText, ExternalLink, Hash, MessageCircle } from "lucide-react"
import type { Film3Post } from "@/app/api/film3-feed/route"

export function Film3CommunitySection() {
  const [posts, setPosts] = useState<Film3Post[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<"all" | "post" | "space" | "video" | "thread">("all")

  useEffect(() => {
    async function fetchFeed() {
      try {
        const res = await fetch("/api/film3-feed")
        const data = await res.json()
        setPosts(data.posts)
      } catch (error) {
        console.error("Failed to fetch Film3 feed:", error)
      } finally {
        setLoading(false)
      }
    }
    fetchFeed()
  }, [])

  const filteredPosts = filter === "all" ? posts : posts.filter((p) => p.type === filter)

  const typeIcons = {
    post: MessageCircle,
    space: Radio,
    video: Video,
    thread: FileText,
  }

  const typeColors = {
    post: "#00F0FF",
    space: "#FF003C",
    video: "#FFD700",
    thread: "#00FF88",
  }

  return (
    <section className="py-24 px-6 relative">
      <div className="max-w-6xl mx-auto">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <Hash
              className="w-8 h-8 text-[#00F0FF]"
              style={{ filter: "drop-shadow(0 0 10px rgba(0, 240, 255, 0.5))" }}
            />
            <h2
              className="text-4xl md:text-5xl font-bold text-white tracking-wider"
              style={{
                fontFamily: "Bebas Neue, sans-serif",
                textShadow: "0 0 30px rgba(0, 240, 255, 0.5)",
              }}
            >
              FILM3 COMMUNITY VOICES
            </h2>
          </div>
          <p className="text-white/60 max-w-2xl mx-auto mb-4">
            The revolution documented through the words of those who built it. Curated voices from the #Film3 movement
            on X.
          </p>
          <div className="w-24 h-1 bg-[#FF003C] mx-auto" style={{ boxShadow: "0 0 20px rgba(255, 0, 60, 0.8)" }} />
        </motion.div>

        {/* Filter tabs */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {(["all", "post", "space", "video", "thread"] as const).map((type) => (
            <button
              key={type}
              onClick={() => setFilter(type)}
              className={`px-5 py-2 rounded-full font-mono text-xs uppercase tracking-wider transition-all ${
                filter === type
                  ? "bg-[#00F0FF] text-black font-bold"
                  : "bg-white/5 text-white/60 hover:bg-white/10 hover:text-white border border-white/10"
              }`}
              style={filter === type ? { boxShadow: "0 0 20px rgba(0, 240, 255, 0.5)" } : {}}
            >
              {type}
            </button>
          ))}
        </div>

        {/* Loading state */}
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <div
              className="w-10 h-10 border-2 border-[#00F0FF] border-t-transparent rounded-full animate-spin"
              style={{ boxShadow: "0 0 20px rgba(0, 240, 255, 0.5)" }}
            />
          </div>
        ) : (
          /* Posts grid */
          <div className="grid md:grid-cols-2 gap-6">
            {filteredPosts.map((post, index) => {
              const TypeIcon = typeIcons[post.type]
              const typeColor = typeColors[post.type]

              return (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-black/40 border border-white/10 rounded-lg p-6 hover:border-[#00F0FF]/30 transition-all group backdrop-blur-sm"
                  style={{ boxShadow: "0 0 30px rgba(0, 0, 0, 0.5)" }}
                >
                  {/* Header */}
                  <div className="flex items-start gap-4 mb-4">
                    <div className="relative">
                      <div
                        className="w-14 h-14 rounded-full overflow-hidden border-2"
                        style={{ borderColor: typeColor, boxShadow: `0 0 15px ${typeColor}40` }}
                      >
                        <img
                          src={post.avatar || "/placeholder.svg"}
                          alt={post.author}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div
                        className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center"
                        style={{ backgroundColor: typeColor }}
                      >
                        <TypeIcon className="w-3 h-3 text-black" />
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-white">{post.author}</span>
                      </div>
                      <span className="text-white/40 text-sm font-mono">@{post.handle}</span>
                    </div>
                    <span className="text-white/30 text-xs font-mono whitespace-nowrap">
                      {new Date(post.timestamp).toLocaleDateString()}
                    </span>
                  </div>

                  {/* Content */}
                  <p className="text-white/80 leading-relaxed mb-5">{post.content}</p>

                  {/* Footer */}
                  <div className="flex items-center justify-between pt-4 border-t border-white/5">
                    <div className="flex items-center gap-6">
                      <span className="flex items-center gap-2 text-white/40 text-sm">
                        <Heart className="w-4 h-4" />
                        {post.likes.toLocaleString()}
                      </span>
                      <span className="flex items-center gap-2 text-white/40 text-sm">
                        <Repeat2 className="w-4 h-4" />
                        {post.retweets.toLocaleString()}
                      </span>
                    </div>
                    <a
                      href={`https://twitter.com/${post.handle}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 text-[#00F0FF]/60 hover:text-[#00F0FF] text-sm transition-colors"
                    >
                      <span className="font-mono">View on X</span>
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  </div>
                </motion.div>
              )
            })}
          </div>
        )}

        {/* Source attribution */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center pt-12"
        >
          <p className="text-white/30 font-mono text-xs">
            Curated from #Film3 community voices on X. No industry interviews. Just the builders.
          </p>
        </motion.div>
      </div>
    </section>
  )
}
