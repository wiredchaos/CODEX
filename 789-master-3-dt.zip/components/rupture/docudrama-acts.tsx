// RUPTURE Docudrama Acts - Seven act structure with expandable chapters
"use client"

import { motion } from "framer-motion"
import { useState } from "react"
import { ChevronDown, ChevronUp } from "lucide-react"

const acts = [
  {
    number: "I",
    title: "GENESIS",
    subtitle: "The Birth of an Idea",
    description:
      "Before FLINCH existed there was a vision. A belief that cinema could be owned differently. This act explores the origins of the concept and the creative minds who dared to imagine a new paradigm for film distribution and ownership.",
    chapters: ["The Spark", "Building the Foundation", "First Believers"],
  },
  {
    number: "II",
    title: "CREATION",
    subtitle: "Forging the Artifact",
    description:
      "The technical and artistic journey of bringing FLINCH to life. From smart contract development to visual design this act chronicles the painstaking process of creating something that had never existed before.",
    chapters: ["Code and Canvas", "The Minting Process", "Testing the Waters"],
  },
  {
    number: "III",
    title: "RUPTURE",
    subtitle: "Breaking Through",
    description:
      "The moment FLINCH entered the world and everything changed. This act captures the initial release the community reaction and the first signs that something unprecedented was happening.",
    chapters: ["Launch Day", "The First Collectors", "Viral Momentum"],
  },
  {
    number: "IV",
    title: "EXPANSION",
    subtitle: "The Movement Grows",
    description:
      "How FLINCH became more than an NFT. This act follows the organic growth of the Film3 movement as creators around the world began to see new possibilities for independent cinema.",
    chapters: ["Global Reach", "New Voices", "Building Infrastructure"],
  },
  {
    number: "V",
    title: "RESISTANCE",
    subtitle: "Challenges and Critics",
    description:
      "No revolution comes without opposition. This act examines the skeptics the technical challenges and the market volatility that threatened to derail the movement.",
    chapters: ["The Doubters", "Market Storms", "Holding the Line"],
  },
  {
    number: "VI",
    title: "EVOLUTION",
    subtitle: "Adapting and Growing",
    description:
      "How the Film3 community learned from setbacks and emerged stronger. This act showcases the innovations and adaptations that kept the movement alive and thriving.",
    chapters: ["Lessons Learned", "New Models", "Sustainable Growth"],
  },
  {
    number: "VII",
    title: "LEGACY",
    subtitle: "The Future of Film3",
    description:
      "Where do we go from here. This final act looks at the lasting impact of FLINCH and envisions the future of decentralized cinema in a world forever changed by the Film3 revolution.",
    chapters: ["Lasting Impact", "Next Generation", "The Road Ahead"],
  },
]

export function DocudramaActs() {
  const [expandedAct, setExpandedAct] = useState<number | null>(null)

  return (
    <section className="py-24 px-6 relative bg-gradient-to-b from-transparent via-[#FF003C]/5 to-transparent">
      <div className="max-w-4xl mx-auto">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2
            className="text-4xl md:text-5xl font-bold text-white mb-4 tracking-wider"
            style={{
              fontFamily: "Bebas Neue, sans-serif",
              textShadow: "0 0 30px rgba(255, 0, 60, 0.5)",
            }}
          >
            SEVEN ACTS
          </h2>
          <p className="text-white/60 text-lg" style={{ textShadow: "0 0 10px rgba(0, 240, 255, 0.3)" }}>
            The complete docudrama structure
          </p>
          <div
            className="w-24 h-1 bg-[#00F0FF] mx-auto mt-4"
            style={{ boxShadow: "0 0 20px rgba(0, 240, 255, 0.8)" }}
          />
        </motion.div>

        {/* Acts list */}
        <div className="space-y-4">
          {acts.map((act, index) => (
            <motion.div
              key={act.number}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 * index }}
            >
              <button
                onClick={() => setExpandedAct(expandedAct === index ? null : index)}
                className="w-full text-left bg-white/5 border border-white/10 rounded-lg p-6 hover:border-[#FF003C]/50 transition-all duration-300 group"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-6">
                    <span
                      className="text-3xl font-bold text-[#FF003C]"
                      style={{
                        fontFamily: "Bebas Neue, sans-serif",
                        textShadow: "0 0 20px rgba(255, 0, 60, 0.5)",
                      }}
                    >
                      ACT {act.number}
                    </span>
                    <div>
                      <h3
                        className="text-xl font-bold text-white tracking-wide"
                        style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.3)" }}
                      >
                        {act.title}
                      </h3>
                      <p className="text-white/50 text-sm" style={{ textShadow: "0 0 8px rgba(0, 240, 255, 0.2)" }}>
                        {act.subtitle}
                      </p>
                    </div>
                  </div>
                  {expandedAct === index ? (
                    <ChevronUp className="w-6 h-6 text-[#00F0FF]" />
                  ) : (
                    <ChevronDown className="w-6 h-6 text-white/50 group-hover:text-[#00F0FF] transition-colors" />
                  )}
                </div>

                {expandedAct === index && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-6 pt-6 border-t border-white/10"
                  >
                    <p
                      className="text-white/70 leading-relaxed mb-4"
                      style={{ textShadow: "0 0 8px rgba(0, 240, 255, 0.2)" }}
                    >
                      {act.description}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {act.chapters.map((chapter) => (
                        <span
                          key={chapter}
                          className="px-3 py-1 bg-[#00F0FF]/10 border border-[#00F0FF]/30 rounded-full text-[#00F0FF] text-sm"
                          style={{ textShadow: "0 0 8px rgba(0, 240, 255, 0.3)" }}
                        >
                          {chapter}
                        </span>
                      ))}
                    </div>
                  </motion.div>
                )}
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
