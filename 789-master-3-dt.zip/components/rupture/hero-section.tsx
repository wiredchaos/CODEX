// RUPTURE Hero Section - Opening title with glitch typography
"use client"

import { motion } from "framer-motion"

export function RuptureHeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background with cyber noir gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0A0A0F] via-[#0D0D12] to-[#0A0A0F]" />

      {/* Animated grid lines */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0, 240, 255, 0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 240, 255, 0.1) 1px, transparent 1px)
          `,
          backgroundSize: "50px 50px",
        }}
      />

      {/* Red accent glow */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#FF003C]/20 rounded-full blur-[150px]" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#00F0FF]/20 rounded-full blur-[150px]" />

      <div className="relative z-10 text-center px-6 max-w-5xl mx-auto">
        {/* Production tag */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-[#00F0FF] text-sm tracking-[0.3em] uppercase mb-8"
          style={{ textShadow: "0 0 20px rgba(0, 240, 255, 0.5)" }}
        >
          CHAOS PRODUCTIONS PRESENTS
        </motion.p>

        {/* Main title with glitch effect */}
        <motion.h1
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-7xl md:text-9xl font-bold tracking-wider mb-6 relative"
          style={{
            fontFamily: "Bebas Neue, sans-serif",
            textShadow: "0 0 40px rgba(255, 0, 60, 0.8), 0 0 80px rgba(255, 0, 60, 0.4)",
          }}
        >
          <span className="text-white">RUPTURE</span>
        </motion.h1>

        {/* Subtitle */}
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-2xl md:text-4xl text-white/90 tracking-wide mb-4"
          style={{
            fontFamily: "Bebas Neue, sans-serif",
            textShadow: "0 0 20px rgba(255, 255, 255, 0.3)",
          }}
        >
          THE FLINCH STORY
        </motion.h2>

        {/* Tagline */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="text-lg md:text-xl text-white/70 max-w-2xl mx-auto mb-12 leading-relaxed"
          style={{ textShadow: "0 0 10px rgba(0, 240, 255, 0.3)" }}
        >
          A documentary about the NFT that broke the mold and ignited the Film3 revolution
        </motion.p>

        {/* CTA buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <a
            href="#watch-trailer"
            className="px-8 py-4 bg-[#FF003C] text-white font-bold tracking-wider uppercase rounded-sm hover:bg-[#FF003C]/80 transition-all duration-300"
            style={{
              boxShadow: "0 0 30px rgba(255, 0, 60, 0.5)",
              textShadow: "0 0 10px rgba(255, 255, 255, 0.5)",
            }}
          >
            Watch Trailer
          </a>
          <a
            href="#overview"
            className="px-8 py-4 border border-[#00F0FF] text-[#00F0FF] font-bold tracking-wider uppercase rounded-sm hover:bg-[#00F0FF]/10 transition-all duration-300"
            style={{ boxShadow: "0 0 20px rgba(0, 240, 255, 0.3)" }}
          >
            Learn More
          </a>
        </motion.div>

        {/* Distribution badge */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 1 }}
          className="mt-16 text-white/50 text-sm tracking-widest uppercase"
        >
          Distributed by{" "}
          <span className="text-[#FFD700]" style={{ textShadow: "0 0 10px rgba(255, 215, 0, 0.5)" }}>
            789 Studios OTT
          </span>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1, y: [0, 10, 0] }}
        transition={{ duration: 1.5, delay: 1.2, repeat: Number.POSITIVE_INFINITY }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center pt-2">
          <div className="w-1.5 h-3 bg-[#00F0FF] rounded-full" />
        </div>
      </motion.div>
    </section>
  )
}
