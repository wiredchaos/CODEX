// RUPTURE Footer - Production credits
"use client"

import { motion } from "framer-motion"
import Link from "next/link"

export function RuptureFooter() {
  return (
    <footer className="py-16 px-6 border-t border-white/10">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center"
        >
          {/* Production credits */}
          <div className="mb-8">
            <p className="text-white/50 text-sm tracking-widest uppercase mb-2">A Production By</p>
            <p
              className="text-[#FF003C] text-xl font-bold tracking-wider"
              style={{ textShadow: "0 0 15px rgba(255, 0, 60, 0.5)" }}
            >
              CHAOS PRODUCTIONS
            </p>
          </div>

          <div className="mb-8">
            <p className="text-white/50 text-sm tracking-widest uppercase mb-2">Created By</p>
            <p
              className="text-[#00F0FF] text-xl font-bold tracking-wider"
              style={{ textShadow: "0 0 15px rgba(0, 240, 255, 0.5)" }}
            >
              NEURO META X
            </p>
          </div>

          <div className="mb-12">
            <p className="text-white/50 text-sm tracking-widest uppercase mb-2">Distributed By</p>
            <p
              className="text-[#FFD700] text-xl font-bold tracking-wider"
              style={{ textShadow: "0 0 15px rgba(255, 215, 0, 0.5)" }}
            >
              789 STUDIOS OTT
            </p>
          </div>

          {/* Navigation links */}
          <div className="flex flex-wrap justify-center gap-6 mb-8">
            <Link href="/" className="text-white/50 hover:text-white transition-colors text-sm">
              Home
            </Link>
            <Link href="/film3" className="text-white/50 hover:text-white transition-colors text-sm">
              Film3
            </Link>
            <Link href="/browse" className="text-white/50 hover:text-white transition-colors text-sm">
              Browse
            </Link>
            <Link href="/about-ott" className="text-white/50 hover:text-white transition-colors text-sm">
              About OTT
            </Link>
          </div>

          {/* Copyright */}
          <p className="text-white/30 text-xs">© 2025 CHAOS PRODUCTIONS × 789 STUDIOS. All rights reserved.</p>
          <p className="text-white/20 text-xs mt-2 max-w-2xl mx-auto">
            RUPTURE: The FLINCH Story is a documentary production. All trademarks and intellectual property belong to
            their respective owners. 789 Studios is a virtual studio and content network.
          </p>
        </motion.div>
      </div>
    </footer>
  )
}
