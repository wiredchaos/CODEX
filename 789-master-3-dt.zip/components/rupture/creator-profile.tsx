// RUPTURE Creator Profile - NEURO META X and CHAOS PRODUCTIONS
"use client"

import { motion } from "framer-motion"
import { Twitter, Zap } from "lucide-react"
import Image from "next/image"

export function CreatorProfile() {
  return (
    <section className="py-24 px-6 relative">
      <div className="max-w-6xl mx-auto">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2
            className="text-4xl md:text-5xl font-bold text-white mb-4 tracking-wider"
            style={{
              fontFamily: "Bebas Neue, sans-serif",
              textShadow: "0 0 30px rgba(0, 240, 255, 0.5)",
            }}
          >
            THE CREATORS
          </h2>
          <div className="w-24 h-1 bg-[#FF003C] mx-auto" style={{ boxShadow: "0 0 20px rgba(255, 0, 60, 0.8)" }} />
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* NEURO META X Profile */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-gradient-to-br from-[#00F0FF]/10 to-transparent border border-[#00F0FF]/30 rounded-lg p-8 relative overflow-hidden"
          >
            {/* Glow effect */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#00F0FF]/20 rounded-full blur-[80px]" />

            <div className="relative z-10">
              <div className="flex items-center gap-4 mb-6">
                <div
                  className="w-20 h-20 rounded-full bg-gradient-to-br from-[#00F0FF] to-[#00F0FF]/50 flex items-center justify-center overflow-hidden border-2 border-[#00F0FF]"
                  style={{ boxShadow: "0 0 30px rgba(0, 240, 255, 0.5)" }}
                >
                  <Image
                    src="/allies/neuro-meta-x.jpg"
                    alt="NEURO META X"
                    width={80}
                    height={80}
                    className="object-cover"
                  />
                </div>
                <div>
                  <h3
                    className="text-2xl font-bold text-white tracking-wide"
                    style={{ textShadow: "0 0 15px rgba(0, 240, 255, 0.5)" }}
                  >
                    NEURO META X
                  </h3>
                  <p className="text-[#00F0FF] text-sm tracking-widest uppercase">Artist / Director</p>
                </div>
              </div>

              <p
                className="text-white/80 leading-relaxed mb-6"
                style={{ textShadow: "0 0 8px rgba(0, 240, 255, 0.2)" }}
              >
                NEURO META X is an AI powered content strategist and Web3 journalist operating at the intersection of
                decentralized media and cultural documentation. Through the lens of CHAOS PRODUCTIONS NEURO chronicles
                the stories that define the blockchain creative movement.
              </p>

              <div className="flex gap-4">
                <a
                  href="https://x.com/neurometax"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-[#00F0FF] hover:text-white transition-colors"
                >
                  <Twitter className="w-5 h-5" />
                  <span className="text-sm">@neurometax</span>
                </a>
              </div>
            </div>
          </motion.div>

          {/* CHAOS PRODUCTIONS */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-gradient-to-br from-[#FF003C]/10 to-transparent border border-[#FF003C]/30 rounded-lg p-8 relative overflow-hidden"
          >
            {/* Glow effect */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#FF003C]/20 rounded-full blur-[80px]" />

            <div className="relative z-10">
              <div className="flex items-center gap-4 mb-6">
                <div
                  className="w-20 h-20 rounded-lg bg-gradient-to-br from-[#FF003C] to-[#FF003C]/50 flex items-center justify-center border-2 border-[#FF003C]"
                  style={{ boxShadow: "0 0 30px rgba(255, 0, 60, 0.5)" }}
                >
                  <Zap className="w-10 h-10 text-white" />
                </div>
                <div>
                  <h3
                    className="text-2xl font-bold text-white tracking-wide"
                    style={{ textShadow: "0 0 15px rgba(255, 0, 60, 0.5)" }}
                  >
                    CHAOS PRODUCTIONS
                  </h3>
                  <p className="text-[#FF003C] text-sm tracking-widest uppercase">Production Studio</p>
                </div>
              </div>

              <p className="text-white/80 leading-relaxed mb-6" style={{ textShadow: "0 0 8px rgba(255, 0, 60, 0.2)" }}>
                CHAOS PRODUCTIONS is a decentralized content studio specializing in documentary storytelling for the
                Web3 era. Operating as the production arm of NEURO META X the studio brings blockchain narratives to
                life through immersive docudrama experiences.
              </p>

              <div className="flex flex-wrap gap-2">
                {["Documentary", "Film3", "Web3", "Decentralized Media"].map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1 bg-[#FF003C]/10 border border-[#FF003C]/30 rounded-full text-[#FF003C] text-sm"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
