// RUPTURE Distribution - 789 Studios OTT integration
"use client"

import { motion } from "framer-motion"
import { Play, Tv, Globe, Users } from "lucide-react"
import Link from "next/link"

export function DistributionSection() {
  return (
    <section className="py-24 px-6 relative bg-gradient-to-b from-transparent via-[#FFD700]/5 to-transparent">
      <div className="max-w-6xl mx-auto">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2
            className="text-4xl md:text-5xl font-bold text-white mb-4 tracking-wider"
            style={{
              fontFamily: "Bebas Neue, sans-serif",
              textShadow: "0 0 30px rgba(255, 215, 0, 0.5)",
            }}
          >
            DISTRIBUTION
          </h2>
          <p className="text-white/60 text-lg mb-4" style={{ textShadow: "0 0 10px rgba(0, 240, 255, 0.3)" }}>
            Exclusively on 789 Studios OTT
          </p>
          <div className="w-24 h-1 bg-[#FFD700] mx-auto" style={{ boxShadow: "0 0 20px rgba(255, 215, 0, 0.8)" }} />
        </motion.div>

        {/* 789 Studios OTT Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-gradient-to-br from-[#FFD700]/10 to-[#00F0FF]/5 border border-[#FFD700]/30 rounded-lg p-8 mb-12"
        >
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="flex-shrink-0">
              <div
                className="w-32 h-32 rounded-lg bg-black flex items-center justify-center border-2 border-[#FFD700]"
                style={{ boxShadow: "0 0 40px rgba(255, 215, 0, 0.3)" }}
              >
                <span
                  className="text-4xl font-bold text-[#FFD700]"
                  style={{
                    fontFamily: "Bebas Neue, sans-serif",
                    textShadow: "0 0 20px rgba(255, 215, 0, 0.8)",
                  }}
                >
                  789
                </span>
              </div>
            </div>

            <div className="flex-1 text-center md:text-left">
              <h3
                className="text-2xl font-bold text-white mb-2 tracking-wide"
                style={{ textShadow: "0 0 15px rgba(255, 215, 0, 0.5)" }}
              >
                789 Studios OTT
              </h3>
              <p
                className="text-white/70 leading-relaxed mb-4"
                style={{ textShadow: "0 0 8px rgba(0, 240, 255, 0.2)" }}
              >
                The premiere destination for Web3 native content. RUPTURE will stream exclusively on 789 Studios OTT
                platform reaching a global audience of Film3 enthusiasts and blockchain believers.
              </p>
              <Link
                href="/about-ott"
                className="inline-flex items-center gap-2 px-6 py-3 bg-[#FFD700] text-black font-bold tracking-wider uppercase rounded-sm hover:bg-[#FFD700]/80 transition-all duration-300"
                style={{ boxShadow: "0 0 30px rgba(255, 215, 0, 0.5)" }}
              >
                <Play className="w-5 h-5" />
                Explore Platform
              </Link>
            </div>
          </div>
        </motion.div>

        {/* Distribution features */}
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { icon: Tv, title: "MULTI PLATFORM", desc: "Available on web mobile and smart TV applications worldwide" },
            { icon: Globe, title: "GLOBAL REACH", desc: "Distributed to Film3 communities across every continent" },
            { icon: Users, title: "TOKEN GATED", desc: "Exclusive access tiers for NFT holders and community members" },
          ].map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 * index }}
              className="bg-white/5 border border-white/10 rounded-lg p-6 text-center hover:border-[#FFD700]/50 transition-all duration-300"
            >
              <feature.icon
                className="w-10 h-10 text-[#FFD700] mx-auto mb-4"
                style={{ filter: "drop-shadow(0 0 10px rgba(255, 215, 0, 0.5))" }}
              />
              <h4
                className="text-white font-bold tracking-wide mb-2"
                style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.3)" }}
              >
                {feature.title}
              </h4>
              <p className="text-white/60 text-sm" style={{ textShadow: "0 0 8px rgba(0, 240, 255, 0.2)" }}>
                {feature.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
