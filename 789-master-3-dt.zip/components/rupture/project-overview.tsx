// RUPTURE Project Overview - Documentary synopsis and scope
"use client"

import { motion } from "framer-motion"
import { Film, Globe, Users, Sparkles } from "lucide-react"

export function ProjectOverview() {
  return (
    <section id="overview" className="py-24 px-6 relative">
      <div className="max-w-6xl mx-auto">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2
            className="text-4xl md:text-5xl font-bold text-white mb-4 tracking-wider"
            style={{
              fontFamily: "Bebas Neue, sans-serif",
              textShadow: "0 0 30px rgba(0, 240, 255, 0.5)",
            }}
          >
            PROJECT OVERVIEW
          </h2>
          <div className="w-24 h-1 bg-[#FF003C] mx-auto" style={{ boxShadow: "0 0 20px rgba(255, 0, 60, 0.8)" }} />
        </motion.div>

        {/* Synopsis */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="mb-16"
        >
          <div className="bg-white/5 border border-white/10 rounded-lg p-8 backdrop-blur-sm">
            <p
              className="text-white/80 text-lg leading-relaxed mb-6"
              style={{ textShadow: "0 0 10px rgba(0, 240, 255, 0.2)" }}
            >
              RUPTURE is a seven act docudrama chronicling the creation and cultural impact of FLINCH, the
              groundbreaking NFT that challenged everything we thought we knew about digital ownership, artistic
              expression, and the future of independent filmmaking.
            </p>
            <p
              className="text-white/80 text-lg leading-relaxed"
              style={{ textShadow: "0 0 10px rgba(0, 240, 255, 0.2)" }}
            >
              Through community voices sourced from #Film3, archival footage, and immersive recreations, RUPTURE traces
              the journey from concept to cultural phenomenon, revealing how one digital artifact became the spark that
              ignited the Film3 revolution.
            </p>
          </div>
        </motion.div>

        {/* Key pillars */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              icon: Film,
              title: "THE ARTIFACT",
              desc: "The story behind FLINCH and its creation as a boundary breaking NFT experiment",
            },
            {
              icon: Globe,
              title: "GLOBAL MOVEMENT",
              desc: "How Film3 spread across continents connecting creators and collectors worldwide",
            },
            {
              icon: Users,
              title: "THE COMMUNITY",
              desc: "Voices from the #Film3 movement, holders, hosts, and builders shaping decentralized cinema",
            },
            {
              icon: Sparkles,
              title: "THE FUTURE",
              desc: "Where Film3 goes from here and what it means for independent filmmakers",
            },
          ].map((pillar, index) => (
            <motion.div
              key={pillar.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 * index }}
              className="bg-gradient-to-b from-white/5 to-transparent border border-white/10 rounded-lg p-6 hover:border-[#00F0FF]/50 transition-all duration-300 group"
            >
              <pillar.icon
                className="w-10 h-10 text-[#00F0FF] mb-4 group-hover:scale-110 transition-transform"
                style={{ filter: "drop-shadow(0 0 10px rgba(0, 240, 255, 0.5))" }}
              />
              <h3
                className="text-white font-bold text-lg mb-2 tracking-wide"
                style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.3)" }}
              >
                {pillar.title}
              </h3>
              <p
                className="text-white/60 text-sm leading-relaxed"
                style={{ textShadow: "0 0 8px rgba(0, 240, 255, 0.2)" }}
              >
                {pillar.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
