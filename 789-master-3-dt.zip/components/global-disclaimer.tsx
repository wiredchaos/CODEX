"use client"

export function GlobalDisclaimer() {
  return (
    <footer className="border-t border-white/10 bg-black/80 backdrop-blur-sm mt-16 pb-24 sm:pb-8">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Short Banner Disclaimer */}
        <div className="glass-panel rounded-lg p-4 mb-6 border border-goldenrod/30">
          <p
            className="font-mono text-xs leading-relaxed text-center"
            style={{ color: "#ffd700", textShadow: "0 0 15px rgba(255, 215, 0, 0.5)" }}
          >
            <span className="font-bold">Disclaimer:</span> 789 Studios references third-party films and NFT collections
            for educational and creative purposes only. NFT ownership does not equal film IP ownership. All film and
            character rights remain with their original owners. No endorsement is implied.
          </p>
        </div>

        {/* Full IP/NFT Disclaimer */}
        <div className="space-y-4 text-center">
          <h4
            className="font-mono text-xs font-bold uppercase tracking-wider"
            style={{ color: "#00ffff", textShadow: "0 0 15px rgba(0, 255, 255, 0.7)" }}
          >
            Intellectual Property & NFT Ownership Notice
          </h4>
          <div className="max-w-4xl mx-auto space-y-3">
            <p
              className="font-mono text-xs leading-relaxed"
              style={{ color: "#ffffff", textShadow: "0 0 10px rgba(255, 255, 255, 0.3)" }}
            >
              789 Studios is a creative studio and virtual media hub that explores Web3, NFTs, film, and emerging
              technology. Throughout this application and its related materials, examples may reference third-party
              films, characters, projects, and NFT collections.
            </p>
            <p
              className="font-mono text-xs leading-relaxed"
              style={{ color: "#ffffff", textShadow: "0 0 10px rgba(255, 255, 255, 0.3)" }}
            >
              Unless expressly stated otherwise: 789 Studios does not own, control, or represent the underlying
              intellectual property of any referenced film or franchise. Ownership is limited to specific NFTs and
              digital collectibles held by the user or contributors, which do not by themselves grant rights to the
              underlying film IP, trademarks, or copyrighted works.
            </p>
            <p
              className="font-mono text-xs leading-relaxed"
              style={{ color: "#ffffff", textShadow: "0 0 10px rgba(255, 255, 255, 0.3)" }}
            >
              By using this application, you acknowledge that all third-party IP remains the exclusive property of its
              respective owners and that 789 Studios' role is limited to commentary, critique, curation, and Web3-native
              experimentation with lawful, properly licensed assets where applicable.
            </p>
          </div>
        </div>

        {/* Footer Links - Bright neon styling for all text */}
        <div className="flex flex-wrap justify-center gap-6 mt-8 pt-6 border-t border-white/10">
          <a
            href="https://x.com/789studiosonx"
            target="_blank"
            rel="noopener noreferrer"
            className="font-mono text-xs hover:opacity-80 transition-opacity"
            style={{ color: "#00ffff", textShadow: "0 0 15px rgba(0, 255, 255, 0.7)" }}
          >
            @789studiosonx
          </a>
          <a
            href="https://instagram.com/789.studios"
            target="_blank"
            rel="noopener noreferrer"
            className="font-mono text-xs hover:opacity-80 transition-opacity"
            style={{ color: "#ffd700", textShadow: "0 0 15px rgba(255, 215, 0, 0.7)" }}
          >
            @789.studios
          </a>
          <span
            className="font-mono text-xs font-bold"
            style={{ color: "#00ffff", textShadow: "0 0 20px rgba(0, 255, 255, 0.8)" }}
          >
            © 2025 789 Studios
          </span>
        </div>
      </div>
    </footer>
  )
}
