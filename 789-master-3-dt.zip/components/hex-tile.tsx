"use client"

import type React from "react"

import { useState, useMemo } from "react"
import { cn } from "@/lib/utils"
import { CREW_COLORS, type CrewType } from "@/lib/crew-config"

interface HexTileProps {
  crew?: CrewType
  size?: "sm" | "md" | "lg" | "xl"
  animated?: boolean
  interactive?: boolean
  label?: string
  icon?: React.ReactNode
  onClick?: () => void
  className?: string
  variant?: "solid" | "outline" | "glow"
}

const sizeMap = {
  sm: { width: 60, height: 69 },
  md: { width: 100, height: 115 },
  lg: { width: 150, height: 173 },
  xl: { width: 200, height: 231 },
}

export function HexTile({
  crew = "alpha",
  size = "md",
  animated = true,
  interactive = true,
  label,
  icon,
  onClick,
  className,
  variant = "glow",
}: HexTileProps) {
  const [isHovered, setIsHovered] = useState(false)
  const colors = CREW_COLORS[crew]
  const dimensions = sizeMap[size]

  const hexPath = useMemo(() => {
    const w = dimensions.width
    const h = dimensions.height
    return `M${w * 0.5},0 L${w},${h * 0.25} L${w},${h * 0.75} L${w * 0.5},${h} L0,${h * 0.75} L0,${h * 0.25} Z`
  }, [dimensions])

  return (
    <div
      className={cn(
        "relative cursor-pointer transition-all duration-300",
        interactive && "hover:scale-110",
        animated && "animate-float",
        className,
      )}
      style={{
        width: dimensions.width,
        height: dimensions.height,
        animationDelay: `${Math.random() * 2}s`,
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={onClick}
    >
      <svg
        width={dimensions.width}
        height={dimensions.height}
        viewBox={`0 0 ${dimensions.width} ${dimensions.height}`}
        className="absolute inset-0"
      >
        <defs>
          <linearGradient id={`hex-gradient-${crew}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={colors.primary} stopOpacity={variant === "solid" ? 1 : 0.3} />
            <stop offset="100%" stopColor={colors.secondary} stopOpacity={variant === "solid" ? 0.8 : 0.1} />
          </linearGradient>
          <filter id={`hex-glow-${crew}`}>
            <feGaussianBlur stdDeviation={isHovered ? 8 : 4} result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Background fill */}
        <path d={hexPath} fill={`url(#hex-gradient-${crew})`} className="transition-all duration-300" />

        {/* Glowing border */}
        <path
          d={hexPath}
          fill="none"
          stroke={colors.primary}
          strokeWidth={isHovered ? 3 : 2}
          filter={variant === "glow" ? `url(#hex-glow-${crew})` : undefined}
          className={cn("transition-all duration-300", animated && "animate-neon-pulse")}
          style={{ color: colors.primary }}
        />

        {/* Inner hexagon */}
        <path
          d={hexPath}
          fill="none"
          stroke={colors.secondary}
          strokeWidth={1}
          strokeOpacity={0.3}
          transform={`translate(${dimensions.width * 0.1}, ${dimensions.height * 0.1}) scale(0.8)`}
        />
      </svg>

      {/* Content overlay */}
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-2">
        {icon && (
          <div
            className="text-2xl mb-1 transition-transform duration-300"
            style={{
              filter: `drop-shadow(${colors.glow})`,
              transform: isHovered ? "scale(1.2)" : "scale(1)",
            }}
          >
            {icon}
          </div>
        )}
        {label && (
          <span
            className="text-xs font-mono font-bold uppercase tracking-wider"
            style={{
              color: colors.primary,
              textShadow: isHovered ? colors.glow : "none",
            }}
          >
            {label}
          </span>
        )}
      </div>
    </div>
  )
}
