"use client"

import { ShowCard } from "./show-card"
import type { OTTShow } from "@/types/ott"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { useRef } from "react"

interface ContentRailProps {
  title: string
  shows: OTTShow[]
  priority?: boolean
}

export function ContentRail({ title, shows, priority = false }: ContentRailProps) {
  const scrollRef = useRef<HTMLDivElement>(null)

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const scrollAmount = scrollRef.current.clientWidth * 0.8
      scrollRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      })
    }
  }

  if (shows.length === 0) return null

  return (
    <div className="space-y-4">
      {/* Rail Title */}
      <h2
        className="font-mono text-xl md:text-2xl font-bold uppercase tracking-wider text-white px-4 md:px-0"
        style={{ textShadow: "0 0 15px rgba(255, 215, 0, 0.5)" }}
      >
        {title}
      </h2>

      {/* Scrollable Rail */}
      <div className="relative group">
        {/* Left Arrow */}
        <button
          onClick={() => scroll("left")}
          className="hidden md:flex absolute left-0 top-1/2 -translate-y-1/2 z-10 w-12 h-full items-center justify-center bg-gradient-to-r from-black to-transparent opacity-0 group-hover:opacity-100 transition-opacity hover:from-black/90"
          aria-label="Scroll left"
        >
          <ChevronLeft
            className="w-8 h-8 text-white"
            style={{ filter: "drop-shadow(0 0 8px rgba(255,255,255,0.8))" }}
          />
        </button>

        {/* Content */}
        <div
          ref={scrollRef}
          className="flex gap-4 overflow-x-auto scrollbar-hide px-4 md:px-0 pb-4"
          style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
        >
          {shows.map((show) => (
            <div key={show.id} className="flex-shrink-0 w-64">
              <ShowCard show={show} priority={priority} />
            </div>
          ))}
        </div>

        {/* Right Arrow */}
        <button
          onClick={() => scroll("right")}
          className="hidden md:flex absolute right-0 top-1/2 -translate-y-1/2 z-10 w-12 h-full items-center justify-center bg-gradient-to-l from-black to-transparent opacity-0 group-hover:opacity-100 transition-opacity hover:from-black/90"
          aria-label="Scroll right"
        >
          <ChevronRight
            className="w-8 h-8 text-white"
            style={{ filter: "drop-shadow(0 0 8px rgba(255,255,255,0.8))" }}
          />
        </button>
      </div>
    </div>
  )
}
