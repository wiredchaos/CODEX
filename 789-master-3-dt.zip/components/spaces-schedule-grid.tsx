"use client"

import { SPACES_SCHEDULE, getCurrentHosts, CRYPTO_SPACES_NETWORK, DOGINAL_DOGS } from "@/lib/spaces-schedule"
import { getCrewColor } from "@/lib/crew-colors"
import { useEffect, useState } from "react"
import { Dialog, DialogContent } from "@/components/ui/dialog"

export function SpacesScheduleGrid() {
  const [liveHosts, setLiveHosts] = useState<string[]>([])
  const [selectedHost, setSelectedHost] = useState<(typeof SPACES_SCHEDULE)[0] | null>(null)
  const [animationOffsets, setAnimationOffsets] = useState<Record<string, number>>({})
  const [currentTime, setCurrentTime] = useState<string>("")

  useEffect(() => {
    const updateLiveHosts = () => {
      const current = getCurrentHosts()
      setLiveHosts(current.map((h) => h.name))

      const now = new Date()
      const estTime = new Date(now.toLocaleString("en-US", { timeZone: "America/New_York" }))
      setCurrentTime(estTime.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", hour12: true }))
    }

    updateLiveHosts()
    const interval = setInterval(updateLiveHosts, 60000)

    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    const offsets: Record<string, number> = {}
    SPACES_SCHEDULE.forEach((host) => {
      offsets[host.name] = Math.random() * 2
    })
    setAnimationOffsets(offsets)
  }, [])

  const selectedCrewColor = selectedHost ? getCrewColor(selectedHost.name) : null

  return (
    <section className="space-y-8">
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3 flex-wrap">
          <div className="px-3 py-1 rounded bg-[#ffd700]/20 border border-[#ffd700]/40">
            <span className="font-mono text-xs font-bold text-[#ffd700]">789 STUDIOS</span>
          </div>
          <span className="font-mono text-xs text-white/50">×</span>
          <div className="px-3 py-1 rounded bg-cyan-500/20 border border-cyan-500/40">
            <span className="font-mono text-xs font-bold text-cyan-400">CRYPTO SPACES NETWORK</span>
          </div>
        </div>

        <h2 className="font-mono text-2xl md:text-3xl font-bold text-white">24/7 LIVE SPACES SCHEDULE</h2>

        <p className="font-mono text-sm text-white/70 max-w-2xl mx-auto">
          Part of the Crypto Spaces Network powered by Doginal Dogs. {SPACES_SCHEDULE.length} unique hosts broadcasting
          live around the clock. All times in Eastern Standard Time.
        </p>

        <div className="flex items-center justify-center gap-3">
          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-red-500/20 border border-red-500/40">
            <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span className="font-mono text-xs font-bold text-red-400">LIVE 24/7</span>
          </div>
          <div className="px-4 py-2 rounded-full bg-white/5 border border-white/20">
            <span className="font-mono text-xs text-white/80">{currentTime} EST</span>
          </div>
        </div>

        <div className="h-1 w-full max-w-4xl mx-auto bg-gradient-to-r from-transparent via-[#ffd700] to-transparent" />
      </div>

      <div className="flex flex-wrap items-center justify-center gap-3">
        <a
          href={CRYPTO_SPACES_NETWORK.websiteUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-cyan-500/10 border border-cyan-500/30 hover:bg-cyan-500/20 transition-all"
        >
          <span className="font-mono text-xs text-cyan-400">cryptospaces.net</span>
          <span className="text-cyan-400">→</span>
        </a>
        <a
          href={DOGINAL_DOGS.links.main}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#ffd700]/10 border border-[#ffd700]/30 hover:bg-[#ffd700]/20 transition-all"
        >
          <span className="font-mono text-xs text-[#ffd700]">doginaldogs.com</span>
          <span className="text-[#ffd700]">→</span>
        </a>
        <a
          href={CRYPTO_SPACES_NETWORK.contactUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-500/10 border border-green-500/30 hover:bg-green-500/20 transition-all"
        >
          <span className="font-mono text-xs text-green-400">Get Listed</span>
          <span className="text-green-400">→</span>
        </a>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {SPACES_SCHEDULE.map((host) => {
          const isLive = liveHosts.includes(host.name)
          const crewColor = getCrewColor(host.name)
          const animOffset = animationOffsets[host.name] || 0

          return (
            <div
              key={`${host.name}-${host.startHour}`}
              className="host-card group relative rounded-lg p-3 flex flex-col items-center gap-2 text-center bg-black/40 border border-white/10 hover:border-white/30 transition-all"
              style={{
                borderColor: isLive ? crewColor.primary : undefined,
                boxShadow: isLive ? `0 0 20px ${crewColor.glow}40` : undefined,
              }}
            >
              {isLive && (
                <div className="absolute top-1 right-1 flex items-center gap-1 px-1.5 py-0.5 rounded bg-black/60">
                  <div
                    className="w-1.5 h-1.5 rounded-full animate-pulse"
                    style={{
                      background: crewColor.primary,
                      boxShadow: `0 0 6px ${crewColor.glow}`,
                    }}
                  />
                  <span className="font-mono text-[8px] font-bold" style={{ color: crewColor.primary }}>
                    LIVE
                  </span>
                </div>
              )}

              {host.showName && (
                <div className="absolute top-1 left-1 px-1.5 py-0.5 rounded bg-purple-500/20 border border-purple-500/40">
                  <span className="font-mono text-[7px] font-bold text-purple-400">{host.showName}</span>
                </div>
              )}

              <button
                onClick={() => setSelectedHost(host)}
                className="relative w-16 h-16 rounded-full overflow-visible cursor-pointer group/avatar"
                style={{
                  animation: `hologramFloat 3s ease-in-out infinite`,
                  animationDelay: `${animOffset}s`,
                }}
              >
                {/* Holographic rings */}
                <div
                  className="absolute inset-[-4px] rounded-full"
                  style={{
                    background: `conic-gradient(from 0deg, ${crewColor.primary}00, ${crewColor.primary}, ${crewColor.glow}, ${crewColor.primary}00)`,
                    animation: "spin 4s linear infinite",
                  }}
                />
                <div
                  className="absolute inset-[-8px] rounded-full opacity-40"
                  style={{
                    background: `conic-gradient(from 180deg, ${crewColor.glow}00, ${crewColor.glow}80, ${crewColor.primary}40, ${crewColor.glow}00)`,
                    animation: "spin 6s linear infinite reverse",
                  }}
                />

                {/* Avatar container */}
                <div
                  className="absolute inset-[2px] rounded-full overflow-hidden border-2 transition-all duration-500 group-hover/avatar:scale-105"
                  style={{
                    borderColor: isLive ? crewColor.primary : `${crewColor.primary}60`,
                    boxShadow: `0 0 15px ${crewColor.glow}50, inset 0 0 20px ${crewColor.glow}20`,
                  }}
                >
                  {/* Scanline effect */}
                  <div
                    className="absolute inset-0 z-10 pointer-events-none opacity-30"
                    style={{
                      background: `repeating-linear-gradient(0deg, transparent, transparent 2px, ${crewColor.primary}10 2px, ${crewColor.primary}10 4px)`,
                      animation: "scanMove 2s linear infinite",
                    }}
                  />
                  {/* Hologram sweep */}
                  <div
                    className="absolute inset-0 z-10 pointer-events-none"
                    style={{
                      background: `linear-gradient(180deg, ${crewColor.primary}00 0%, ${crewColor.primary}30 50%, ${crewColor.primary}00 100%)`,
                      animation: "hologramSweep 3s ease-in-out infinite",
                    }}
                  />
                  <img
                    src={host.imageUrl || "/placeholder.svg"}
                    alt={host.name}
                    className="w-full h-full object-cover"
                  />
                </div>
              </button>

              <div className="space-y-0.5">
                <h3
                  className="font-mono text-xs font-bold cursor-pointer hover:underline"
                  onClick={() => setSelectedHost(host)}
                  style={{
                    color: crewColor.primary,
                    textShadow: `0 0 8px ${crewColor.glow}`,
                  }}
                >
                  {host.name}
                </h3>
                <p className="font-mono text-[10px] text-white/70">{host.time}</p>
              </div>
            </div>
          )
        })}
      </div>

      <div className="mt-12 p-6 rounded-xl bg-gradient-to-b from-cyan-500/5 to-transparent border border-cyan-500/20">
        <div className="text-center mb-6">
          <h3 className="font-mono text-lg font-bold text-cyan-400 mb-2">CRYPTO SPACES NETWORK SERVICES</h3>
          <p className="font-mono text-xs text-white/60">{CRYPTO_SPACES_NETWORK.tagline}</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {CRYPTO_SPACES_NETWORK.services.map((service, idx) => (
            <div
              key={idx}
              className="p-4 rounded-lg bg-black/40 border border-cyan-500/10 hover:border-cyan-500/30 transition-all"
            >
              <h4 className="font-mono text-xs font-bold text-white mb-2">{service.title}</h4>
              <div className="flex flex-wrap gap-1">
                {service.tags.map((tag) => (
                  <span
                    key={tag}
                    className="font-mono text-[9px] px-1.5 py-0.5 rounded bg-cyan-500/10 text-cyan-400/80"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
        <div className="mt-6 text-center">
          <a
            href={CRYPTO_SPACES_NETWORK.contactUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-cyan-500 text-black font-mono text-sm font-bold hover:bg-cyan-400 transition-all"
          >
            Start Your Project
            <span>→</span>
          </a>
        </div>
      </div>

      <div className="p-6 rounded-xl bg-gradient-to-b from-[#ffd700]/5 to-transparent border border-[#ffd700]/20">
        <div className="text-center mb-6">
          <h3 className="font-mono text-lg font-bold text-[#ffd700] mb-2">POWERED BY DOGINAL DOGS</h3>
          <p className="font-mono text-sm text-white/70 max-w-xl mx-auto">{DOGINAL_DOGS.description}</p>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <a
            href={DOGINAL_DOGS.links.buy}
            target="_blank"
            rel="noopener noreferrer"
            className="p-3 rounded-lg bg-black/40 border border-[#ffd700]/20 hover:border-[#ffd700]/50 transition-all text-center"
          >
            <span className="font-mono text-xs font-bold text-[#ffd700]">Buy a Doginal</span>
          </a>
          <a
            href={DOGINAL_DOGS.links.community}
            target="_blank"
            rel="noopener noreferrer"
            className="p-3 rounded-lg bg-black/40 border border-[#ffd700]/20 hover:border-[#ffd700]/50 transition-all text-center"
          >
            <span className="font-mono text-xs font-bold text-[#ffd700]">Join Community</span>
          </a>
          <a
            href={DOGINAL_DOGS.links.contentGenerator}
            target="_blank"
            rel="noopener noreferrer"
            className="p-3 rounded-lg bg-black/40 border border-[#ffd700]/20 hover:border-[#ffd700]/50 transition-all text-center"
          >
            <span className="font-mono text-xs font-bold text-[#ffd700]">Content Generator</span>
          </a>
          <a
            href={DOGINAL_DOGS.links.mediaLibrary}
            target="_blank"
            rel="noopener noreferrer"
            className="p-3 rounded-lg bg-black/40 border border-[#ffd700]/20 hover:border-[#ffd700]/50 transition-all text-center"
          >
            <span className="font-mono text-xs font-bold text-[#ffd700]">Media Library</span>
          </a>
        </div>
      </div>

      {/* Modal Dialog */}
      <Dialog open={!!selectedHost} onOpenChange={(open) => !open && setSelectedHost(null)}>
        <DialogContent
          className="bg-black/98 border-2 p-0 overflow-hidden max-w-md"
          style={{
            borderColor: selectedCrewColor?.primary || "#fff",
            boxShadow: selectedCrewColor
              ? `0 0 50px ${selectedCrewColor.glow}60, 0 0 100px ${selectedCrewColor.glow}30`
              : undefined,
          }}
        >
          {selectedHost && selectedCrewColor && (
            <>
              <div
                className="h-2 w-full"
                style={{
                  background: `linear-gradient(90deg, transparent, ${selectedCrewColor.primary}, ${selectedCrewColor.glow}, ${selectedCrewColor.primary}, transparent)`,
                  animation: "hologramSweep 2s ease-in-out infinite",
                }}
              />
              <div
                className="absolute inset-0 pointer-events-none opacity-10 z-0"
                style={{
                  background: `repeating-linear-gradient(0deg, transparent, transparent 3px, ${selectedCrewColor.primary}30 3px, ${selectedCrewColor.primary}30 6px)`,
                }}
              />
              <div className="relative z-10 p-6">
                <div className="flex justify-center mb-6">
                  <div
                    className="relative w-28 h-28 rounded-full"
                    style={{ animation: "hologramFloat 3s ease-in-out infinite" }}
                  >
                    <div
                      className="absolute inset-[-8px] rounded-full"
                      style={{
                        background: `conic-gradient(from 0deg, ${selectedCrewColor.primary}00, ${selectedCrewColor.primary}, ${selectedCrewColor.glow}, ${selectedCrewColor.primary}00)`,
                        animation: "spin 3s linear infinite",
                      }}
                    />
                    <div
                      className="absolute inset-[-14px] rounded-full opacity-40"
                      style={{
                        background: `conic-gradient(from 90deg, ${selectedCrewColor.glow}00, ${selectedCrewColor.glow}, ${selectedCrewColor.primary}60, ${selectedCrewColor.glow}00)`,
                        animation: "spin 5s linear infinite reverse",
                      }}
                    />
                    <div
                      className="absolute inset-[4px] rounded-full overflow-hidden border-3"
                      style={{
                        borderColor: selectedCrewColor.primary,
                        borderWidth: "3px",
                        boxShadow: `0 0 40px ${selectedCrewColor.glow}80, inset 0 0 40px ${selectedCrewColor.glow}40`,
                      }}
                    >
                      <div
                        className="absolute inset-0 z-10 pointer-events-none opacity-30"
                        style={{
                          background: `repeating-linear-gradient(0deg, transparent, transparent 2px, ${selectedCrewColor.primary}20 2px, ${selectedCrewColor.primary}20 4px)`,
                          animation: "scanMove 1.5s linear infinite",
                        }}
                      />
                      <img
                        src={selectedHost.imageUrl || "/placeholder.svg"}
                        alt={selectedHost.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                </div>

                <div className="text-center mb-4">
                  {selectedHost.showName && (
                    <div className="inline-block px-3 py-1 rounded-full bg-purple-500/20 border border-purple-500/40 mb-2">
                      <span className="font-mono text-xs font-bold text-purple-400">{selectedHost.showName}</span>
                    </div>
                  )}
                  <h3
                    className="font-mono text-2xl font-bold mb-1"
                    style={{
                      color: selectedCrewColor.primary,
                      textShadow: `0 0 20px ${selectedCrewColor.glow}`,
                    }}
                  >
                    {selectedHost.name}
                  </h3>
                  <p className="font-mono text-sm text-white/60">{selectedHost.handle}</p>
                  <p className="font-mono text-xs mt-1" style={{ color: selectedCrewColor.primary }}>
                    {selectedHost.time}
                  </p>
                </div>

                <div
                  className="p-4 rounded-lg border mb-4"
                  style={{
                    borderColor: `${selectedCrewColor.primary}40`,
                    background: `linear-gradient(180deg, ${selectedCrewColor.primary}10, transparent)`,
                  }}
                >
                  <p className="font-mono text-sm text-white/90 leading-relaxed">{selectedHost.bio}</p>
                </div>

                <a
                  href={selectedHost.xUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 w-full py-3 rounded-lg font-mono text-sm font-bold uppercase tracking-wider transition-all hover:gap-4"
                  style={{
                    background: selectedCrewColor.primary,
                    color: "#000",
                    boxShadow: `0 0 20px ${selectedCrewColor.glow}60`,
                  }}
                >
                  <span>Follow on X</span>
                  <span>→</span>
                </a>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      <style jsx global>{`
        @keyframes hologramFloat {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-4px); }
        }
        @keyframes hologramSweep {
          0% { opacity: 0; transform: translateY(-100%); }
          50% { opacity: 0.3; }
          100% { opacity: 0; transform: translateY(100%); }
        }
        @keyframes scanMove {
          0% { background-position: 0 0; }
          100% { background-position: 0 20px; }
        }
      `}</style>
    </section>
  )
}
