"use client"

import type React from "react"

import { usePathname } from "next/navigation"
import { useState, useEffect } from "react"
import { Mic, Upload, Radio, Film, Home } from "lucide-react"
import Link from "next/link"

interface NavSection {
  id: string
  label: string
  path: string
  icon: React.ReactNode
  color: string
}

const NAV_SECTIONS: NavSection[] = [
  {
    id: "home",
    label: "Home",
    path: "/",
    icon: <Home className="w-5 h-5" />,
    color: "#ffd700",
  },
  {
    id: "creator",
    label: "Creator Hub",
    path: "/creator",
    icon: <Upload className="w-5 h-5" />,
    color: "#00ffff",
  },
  {
    id: "film3",
    label: "Film3",
    path: "/film3",
    icon: <Film className="w-5 h-5" />,
    color: "#daa520",
  },
  {
    id: "studios",
    label: "Recording Studios",
    path: "/pricing",
    icon: <Mic className="w-5 h-5" />,
    color: "#ffd700",
  },
  {
    id: "spaces",
    label: "Spaces Network",
    path: "/spaces",
    icon: <Radio className="w-5 h-5" />,
    color: "#00ffff",
  },
]

export function NavigationalAvatar() {
  const pathname = usePathname()
  const [activeSection, setActiveSection] = useState<NavSection | null>(null)
  const [isExpanded, setIsExpanded] = useState(false)

  useEffect(() => {
    const current = NAV_SECTIONS.find((section) => section.path === pathname)
    setActiveSection(current || NAV_SECTIONS[0])
  }, [pathname])

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Main Avatar Button */}
      <div className="relative">
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="w-16 h-16 rounded-full bg-black/90 backdrop-blur-lg border-2 flex items-center justify-center transition-all hover:scale-110 group"
          style={{
            borderColor: activeSection?.color || "#ffd700",
            boxShadow: `0 0 30px ${activeSection?.color || "#ffd700"}80`,
          }}
        >
          {activeSection?.icon}
          <div
            className="absolute inset-0 rounded-full animate-ping opacity-20"
            style={{ background: activeSection?.color }}
          />
        </button>

        {/* Section Label */}
        {activeSection && (
          <div
            className="absolute bottom-full mb-2 right-0 bg-black/95 backdrop-blur-sm border rounded px-3 py-1.5 whitespace-nowrap pointer-events-none"
            style={{ borderColor: `${activeSection.color}40` }}
          >
            <span className="font-mono text-xs font-bold" style={{ color: activeSection.color }}>
              {activeSection.label}
            </span>
          </div>
        )}

        {/* Navigation Menu */}
        {isExpanded && (
          <div className="absolute bottom-20 right-0 space-y-3 animate-in fade-in slide-in-from-bottom-4 duration-300">
            {NAV_SECTIONS.map((section) => (
              <Link
                key={section.id}
                href={section.path}
                onClick={() => setIsExpanded(false)}
                className="flex items-center gap-3 bg-black/95 backdrop-blur-lg border rounded-lg px-4 py-3 hover:scale-105 transition-all group"
                style={{
                  borderColor: `${section.color}40`,
                  boxShadow: pathname === section.path ? `0 0 20px ${section.color}60` : "none",
                }}
              >
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center border transition-all"
                  style={{
                    borderColor: section.color,
                    background: `${section.color}15`,
                    color: section.color,
                  }}
                >
                  {section.icon}
                </div>
                <span className="font-mono text-sm font-bold text-white">{section.label}</span>
                {pathname === section.path && (
                  <div className="w-2 h-2 rounded-full ml-auto" style={{ background: section.color }} />
                )}
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
