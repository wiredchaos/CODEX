"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronUp, ChevronDown, X } from "lucide-react"
import { FLOOR_REGISTRY } from "@/lib/trinity/logic"
import { useRouter, usePathname } from "next/navigation"
import { PersonaRouter } from "@/lib/kilo/persona-router"

export function ElevatorNav() {
  const router = useRouter()
  const pathname = usePathname()
  const [isOpen, setIsOpen] = useState(false)
  const [currentFloor, setCurrentFloor] = useState<string | null>(null)
  const [personaRouter] = useState(() => new PersonaRouter())

  useEffect(() => {
    const path = pathname === "/" ? "home" : pathname.slice(1).split("/")[0]
    const floor = FLOOR_REGISTRY.find((f) => f.id === path)
    setCurrentFloor(floor?.id || null)
  }, [pathname])

  function handleFloorSelect(floorId: string) {
    const floor = FLOOR_REGISTRY.find((f) => f.id === floorId)
    if (floor) {
      setIsOpen(false)
      router.push(floor.path)
    }
  }

  const currentFloorData = FLOOR_REGISTRY.find((f) => f.id === currentFloor)

  return (
    <>
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 left-6 z-40 w-16 h-16 rounded-full bg-black/90 backdrop-blur-lg border-2 border-gold flex items-center justify-center transition-all hover:scale-110 group"
        style={{
          boxShadow: "0 0 30px rgba(255, 215, 0, 0.6)",
        }}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
      >
        <div className="relative">
          <div className="absolute inset-0 rounded-full animate-ping opacity-20 bg-gold" />
          <div className="flex flex-col items-center gap-0.5">
            <ChevronUp className="w-4 h-4 text-gold" />
            <div className="w-6 h-0.5 bg-gold rounded-full" />
            <ChevronDown className="w-4 h-4 text-gold" />
          </div>
        </div>
      </motion.button>

      {currentFloorData && (
        <motion.div
          className="fixed bottom-24 left-6 z-40 bg-black/95 backdrop-blur-sm border rounded px-3 py-1.5 whitespace-nowrap pointer-events-none"
          style={{ borderColor: `${currentFloorData.color}40` }}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <span className="font-mono text-xs font-bold" style={{ color: currentFloorData.color }}>
            {currentFloorData.name}
          </span>
        </motion.div>
      )}

      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-45 bg-black/60 backdrop-blur-sm"
              onClick={() => setIsOpen(false)}
            />
            <motion.div
              initial={{ x: -300, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -300, opacity: 0 }}
              className="fixed left-6 bottom-28 z-50 w-80 bg-black/95 backdrop-blur-xl border-2 border-gold/50 rounded-xl shadow-2xl overflow-hidden"
              style={{ boxShadow: "0 0 40px rgba(255, 215, 0, 0.3)" }}
            >
              <div className="p-4 border-b border-gold/20 flex items-center justify-between">
                <div>
                  <h3 className="font-mono text-sm font-bold text-gold">ELEVATOR</h3>
                  <p className="text-xs text-white/60 font-mono">Select Floor</p>
                </div>
                <button onClick={() => setIsOpen(false)} className="p-1 rounded hover:bg-white/10 transition-colors">
                  <X className="w-4 h-4 text-white/60" />
                </button>
              </div>

              <div className="max-h-96 overflow-y-auto p-2 space-y-1">
                {FLOOR_REGISTRY.map((floor) => {
                  const isCurrentFloor = floor.id === currentFloor
                  return (
                    <button
                      key={floor.id}
                      onClick={() => handleFloorSelect(floor.id)}
                      className={`w-full p-3 rounded-lg text-left transition-all ${
                        isCurrentFloor
                          ? "bg-white/10 border border-white/20"
                          : "hover:bg-white/5 border border-transparent"
                      }`}
                      style={{
                        borderColor: isCurrentFloor ? floor.color : "transparent",
                        boxShadow: isCurrentFloor ? `0 0 20px ${floor.color}40` : "none",
                      }}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold border"
                          style={{
                            borderColor: floor.color,
                            background: `${floor.color}15`,
                            color: floor.color,
                          }}
                        >
                          {floor.id === "home" ? "L" : floor.name.charAt(0)}
                        </div>
                        <div className="flex-1">
                          <div className="font-mono text-sm font-bold text-white">{floor.name}</div>
                          <div className="text-xs text-white/50 line-clamp-1">{floor.tourScriptShort}</div>
                        </div>
                        {isCurrentFloor && <div className="w-2 h-2 rounded-full" style={{ background: floor.color }} />}
                      </div>
                    </button>
                  )
                })}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  )
}
