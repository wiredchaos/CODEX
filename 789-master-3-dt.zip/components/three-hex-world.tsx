"use client"

import { Canvas, useFrame } from "@react-three/fiber"
import { OrbitControls, Environment, Float, Text } from "@react-three/drei"
import { useRef, useState, useMemo } from "react"
import * as THREE from "three"

function HexagonMesh({
  position,
  color,
  glowColor,
  label,
  onClick,
}: {
  position: [number, number, number]
  color: string
  glowColor: string
  label?: string
  onClick?: () => void
}) {
  const meshRef = useRef<THREE.Mesh>(null)
  const [hovered, setHovered] = useState(false)

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.z += 0.002
      meshRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime + position[0]) * 0.1
    }
  })

  const hexShape = useMemo(() => {
    const shape = new THREE.Shape()
    const sides = 6
    const radius = 1
    for (let i = 0; i < sides; i++) {
      const angle = (i / sides) * Math.PI * 2 - Math.PI / 2
      const x = Math.cos(angle) * radius
      const y = Math.sin(angle) * radius
      if (i === 0) {
        shape.moveTo(x, y)
      } else {
        shape.lineTo(x, y)
      }
    }
    shape.closePath()
    return shape
  }, [])

  return (
    <Float speed={2} rotationIntensity={0.2} floatIntensity={0.3}>
      <group position={position}>
        <mesh
          ref={meshRef}
          onClick={onClick}
          onPointerOver={() => setHovered(true)}
          onPointerOut={() => setHovered(false)}
          scale={hovered ? 1.2 : 1}
        >
          <extrudeGeometry
            args={[hexShape, { depth: 0.2, bevelEnabled: true, bevelSize: 0.05, bevelThickness: 0.05 }]}
          />
          <meshStandardMaterial
            color={color}
            emissive={glowColor}
            emissiveIntensity={hovered ? 2 : 0.5}
            metalness={0.8}
            roughness={0.2}
          />
        </mesh>
        {label && (
          <Text
            position={[0, 0, 0.3]}
            fontSize={0.3}
            color="white"
            anchorX="center"
            anchorY="middle"
            font="/fonts/Geist-Bold.ttf"
          >
            {label}
          </Text>
        )}
      </group>
    </Float>
  )
}

function HexWorld({ onSelectSection }: { onSelectSection?: (id: string) => void }) {
  const sections = [
    {
      id: "hex-forge",
      label: "HEX",
      color: "#003333",
      glow: "#00ffff",
      position: [0, 0, 0] as [number, number, number],
    },
    {
      id: "game-forge",
      label: "GAME",
      color: "#330033",
      glow: "#ff00ff",
      position: [-2.5, 0, -1] as [number, number, number],
    },
    {
      id: "radio-33",
      label: "33.3",
      color: "#333300",
      glow: "#ffd700",
      position: [2.5, 0, -1] as [number, number, number],
    },
    {
      id: "npc-lab",
      label: "NPC",
      color: "#003322",
      glow: "#00ff88",
      position: [-1.5, 0, 1.5] as [number, number, number],
    },
    {
      id: "creator-hub",
      label: "CREATE",
      color: "#331100",
      glow: "#ff6600",
      position: [1.5, 0, 1.5] as [number, number, number],
    },
  ]

  return (
    <>
      <ambientLight intensity={0.2} />
      <pointLight position={[10, 10, 10]} intensity={1} color="#00ffff" />
      <pointLight position={[-10, -10, -10]} intensity={0.5} color="#ff00ff" />
      <spotLight position={[0, 10, 0]} intensity={1} color="#ffd700" angle={0.3} />

      {sections.map((section) => (
        <HexagonMesh
          key={section.id}
          position={section.position}
          color={section.color}
          glowColor={section.glow}
          label={section.label}
          onClick={() => onSelectSection?.(section.id)}
        />
      ))}

      <Environment preset="night" />
      <OrbitControls
        enableZoom={true}
        enablePan={false}
        minDistance={5}
        maxDistance={15}
        autoRotate
        autoRotateSpeed={0.5}
      />
    </>
  )
}

export function ThreeHexWorld({ onSelectSection }: { onSelectSection?: (id: string) => void }) {
  return (
    <div className="w-full h-[500px] rounded-xl overflow-hidden border border-[#00ffff]/20">
      <Canvas camera={{ position: [0, 5, 8], fov: 60 }}>
        <HexWorld onSelectSection={onSelectSection} />
      </Canvas>
    </div>
  )
}
