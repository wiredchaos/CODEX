"use client"

import { useState, useEffect } from "react"
import {
  getCurrentHosts,
  CRYPTO_SPACES_NETWORK,
  CSN_FOUNDERS,
  CSN_PRINCIPALS,
  type SpaceHost,
} from "@/lib/spaces-schedule"
import Image from "next/image"
import { ExternalLink, Radio, Users, Zap, Shield } from "lucide-react"

export function CSNLiveFeed() {
  const [currentHosts, setCurrentHosts] = useState<SpaceHost[]>([])
  const [currentTime, setCurrentTime] = useState<string>("")
  const [isLive, setIsLive] = useState(true)

  useEffect(() => {
    const updateTime = () => {
      const now = new Date()
      const estTime = new Date(now.toLocaleString("en-US", { timeZone: "America/New_York" }))
      setCurrentTime(
        estTime.toLocaleTimeString("en-US", {
          hour: "2-digit",
          minute: "2-digit",
          hour12: true,
        }) + " EST",
      )
      setCurrentHosts(getCurrentHosts())
    }

    updateTime()
    const interval = setInterval(updateTime, 30000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="space-y-6">
      {/* Live Status Banner */}
      <div className="relative overflow-hidden rounded-lg border border-cyan-500/30 bg-black/60 backdrop-blur-sm">
        {/* Animated background */}
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/5 via-transparent to-cyan-500/5 animate-pulse" />

        {/* Scanlines */}
        <div
          className="absolute inset-0 pointer-events-none opacity-20"
          style={{
            background:
              "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,255,255,0.03) 2px, rgba(0,255,255,0.03) 4px)",
          }}
        />

        <div className="relative p-4 md:p-6">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            {/* Live indicator */}
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                <div className="absolute inset-0 w-3 h-3 bg-red-500 rounded-full animate-ping" />
              </div>
              <span className="font-mono text-sm font-bold text-white">LIVE 24/7</span>
              <span className="font-mono text-xs text-white/50">{currentTime}</span>
            </div>

            {/* CSN branding */}
            <div className="flex items-center gap-2">
              <Radio className="w-4 h-4 text-cyan-400" />
              <span className="font-mono text-xs text-cyan-400">CRYPTO SPACES NETWORK</span>
            </div>
          </div>

          {/* Current hosts */}
          {currentHosts.length > 0 && (
            <div className="mt-4 pt-4 border-t border-white/10">
              <div className="flex items-center gap-2 mb-3">
                <Zap className="w-4 h-4 text-[#ffd700]" />
                <span className="font-mono text-xs text-white/70">NOW BROADCASTING</span>
              </div>
              <div className="flex flex-wrap gap-3">
                {currentHosts.map((host) => (
                  <a
                    key={host.handle}
                    href={host.xUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/5 border border-white/10 hover:border-cyan-500/50 transition-all group"
                  >
                    <div className="relative w-8 h-8 rounded-full overflow-hidden border border-cyan-500/50">
                      <Image
                        src={host.imageUrl || "/placeholder.svg"}
                        alt={host.name}
                        fill
                        className="object-cover"
                        unoptimized
                      />
                    </div>
                    <div>
                      <div className="flex items-center gap-1">
                        <span className="font-mono text-sm font-bold text-white group-hover:text-cyan-400 transition-colors">
                          {host.name}
                        </span>
                        {host.isFounder && (
                          <span className="px-1.5 py-0.5 rounded text-[8px] font-bold bg-[#ffd700]/20 text-[#ffd700] border border-[#ffd700]/30">
                            FOUNDER
                          </span>
                        )}
                      </div>
                      {host.showName && <span className="font-mono text-[10px] text-cyan-400/70">{host.showName}</span>}
                    </div>
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <div className="h-px flex-1 bg-gradient-to-r from-transparent to-[#ffd700]/50" />
          <span className="font-mono text-xs text-[#ffd700]/70 tracking-wider">FOUNDERS</span>
          <div className="h-px flex-1 bg-gradient-to-l from-transparent to-[#ffd700]/50" />
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          {CSN_FOUNDERS.map((founder) => (
            <div
              key={founder.handle}
              className="relative overflow-hidden rounded-lg border-2 border-[#ffd700]/40 bg-black/60 backdrop-blur-sm group hover:border-[#ffd700]/60 transition-all"
            >
              {/* Gold gradient background */}
              <div className="absolute inset-0 bg-gradient-to-br from-[#ffd700]/10 via-transparent to-[#ffd700]/5" />

              <div className="relative p-4 md:p-6">
                <div className="flex items-start gap-4">
                  {/* Avatar with founder ring */}
                  <div className="relative shrink-0">
                    <div
                      className="absolute -inset-1 rounded-full animate-spin-slow"
                      style={{
                        background:
                          "conic-gradient(from 0deg, transparent, #ffd700, transparent, #ffd700, transparent)",
                        animationDuration: "6s",
                      }}
                    />
                    <div className="relative w-16 h-16 md:w-20 md:h-20 rounded-full overflow-hidden border-2 border-[#ffd700]/60">
                      <Image
                        src={founder.imageUrl || "/placeholder.svg"}
                        alt={founder.name}
                        fill
                        className="object-cover"
                        unoptimized
                      />
                    </div>
                    <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full bg-black border border-[#ffd700] font-mono text-[8px] font-bold text-[#ffd700] whitespace-nowrap">
                      FOUNDER
                    </div>
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <h3
                      className="font-bold text-lg text-[#ffd700]"
                      style={{ textShadow: "0 0 10px rgba(255,215,0,0.5)" }}
                    >
                      {founder.name}
                    </h3>
                    <p className="font-mono text-xs text-[#ffd700]/80 italic">{founder.tagline}</p>
                    <p className="font-mono text-xs text-white/60">{founder.handle}</p>

                    {founder.showName && (
                      <div className="mt-2 flex items-center gap-2">
                        <span className="px-2 py-1 rounded bg-cyan-500/10 border border-cyan-500/30 font-mono text-[10px] text-cyan-400">
                          {founder.showName}
                        </span>
                        <span className="font-mono text-[10px] text-white/50">{founder.showTime}</span>
                      </div>
                    )}
                  </div>
                </div>

                <p className="mt-3 font-mono text-xs text-white/70 leading-relaxed line-clamp-2">{founder.bio}</p>

                <a
                  href={founder.xUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-3 inline-flex items-center gap-2 px-3 py-1.5 rounded border border-[#ffd700]/50 bg-[#ffd700]/10 font-mono text-xs font-bold text-[#ffd700] hover:bg-[#ffd700]/20 transition-all"
                >
                  FOLLOW ON X
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <div className="h-px flex-1 bg-gradient-to-r from-transparent to-cyan-500/50" />
          <span className="font-mono text-xs text-cyan-400/70 tracking-wider">GIGA VIP</span>
          <div className="h-px flex-1 bg-gradient-to-l from-transparent to-cyan-500/50" />
        </div>

        {CSN_PRINCIPALS.map((principal) => (
          <div
            key={principal.handle}
            className="relative overflow-hidden rounded-lg border-2 border-cyan-500/40 bg-black/60 backdrop-blur-sm group hover:border-cyan-500/60 transition-all"
          >
            {/* Cyan gradient background for GIGA VIP */}
            <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/10 via-transparent to-cyan-500/5" />

            {/* Shield pattern overlay */}
            <div
              className="absolute inset-0 opacity-5"
              style={{
                backgroundImage:
                  "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='60' height='60' viewBox='0 0 24 24' fill='none' stroke='%2300ffff' strokeWidth='1'%3E%3Cpath d='M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z'/%3E%3C/svg%3E\")",
                backgroundSize: "60px 60px",
              }}
            />

            <div className="relative p-4 md:p-6">
              <div className="flex items-start gap-4">
                {/* Avatar with GIGA VIP ring */}
                <div className="relative shrink-0">
                  <div
                    className="absolute -inset-1 rounded-full animate-spin-slow"
                    style={{
                      background: "conic-gradient(from 0deg, transparent, #00ffff, transparent, #00ffff, transparent)",
                      animationDuration: "4s",
                    }}
                  />
                  <div className="relative w-16 h-16 md:w-20 md:h-20 rounded-full overflow-hidden border-2 border-cyan-500/60">
                    <Image
                      src={principal.imageUrl || "/placeholder.svg"}
                      alt={principal.name}
                      fill
                      className="object-cover"
                      unoptimized
                    />
                  </div>
                  <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full bg-black border border-cyan-500 font-mono text-[8px] font-bold text-cyan-400 whitespace-nowrap flex items-center gap-1">
                    <Shield className="w-2 h-2" />
                    GIGA VIP
                  </div>
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <h3
                    className="font-bold text-lg text-cyan-400"
                    style={{ textShadow: "0 0 10px rgba(0,255,255,0.5)" }}
                  >
                    {principal.name}
                  </h3>
                  <p className="font-mono text-xs text-cyan-400/80 italic">{principal.tagline}</p>
                  <p className="font-mono text-xs text-white/60">{principal.handle}</p>
                </div>
              </div>

              <p className="mt-3 font-mono text-xs text-white/70 leading-relaxed">{principal.bio}</p>

              <a
                href={principal.xUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-3 inline-flex items-center gap-2 px-3 py-1.5 rounded border border-cyan-500/50 bg-cyan-500/10 font-mono text-xs font-bold text-cyan-400 hover:bg-cyan-500/20 transition-all"
              >
                FOLLOW ON X
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        ))}
      </div>

      {/* Services Ticker */}
      <div className="overflow-hidden rounded-lg border border-white/10 bg-black/40">
        <div className="flex items-center gap-2 px-4 py-2 border-b border-white/10 bg-white/5">
          <Users className="w-4 h-4 text-cyan-400" />
          <span className="font-mono text-xs text-white/70">CSN SERVICES</span>
        </div>
        <div className="relative overflow-hidden">
          <div className="flex animate-scroll-x py-3">
            {[...CRYPTO_SPACES_NETWORK.services, ...CRYPTO_SPACES_NETWORK.services].map((service, i) => (
              <div key={`${service.id}-${i}`} className="flex items-center gap-4 px-6 whitespace-nowrap">
                <span className="font-mono text-sm text-cyan-400 font-bold">{service.id}</span>
                <span className="font-mono text-sm text-white">{service.title}</span>
                <div className="flex gap-1">
                  {service.tags.slice(0, 3).map((tag) => (
                    <span
                      key={tag}
                      className="px-2 py-0.5 rounded text-[10px] bg-white/5 text-white/50 border border-white/10"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="text-center">
        <a
          href={CRYPTO_SPACES_NETWORK.contactUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-gradient-to-r from-cyan-500 to-cyan-600 font-mono text-sm font-bold text-black hover:from-cyan-400 hover:to-cyan-500 transition-all"
        >
          START YOUR PROJECT
          <ExternalLink className="w-4 h-4" />
        </a>
        <p className="mt-2 font-mono text-xs text-white/50 italic">"{CRYPTO_SPACES_NETWORK.motto}"</p>
      </div>
    </div>
  )
}
