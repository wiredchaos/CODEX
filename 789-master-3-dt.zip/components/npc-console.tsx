"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"

const NPC_RESPONSES = [
  "Initializing neural pathways...",
  "Scanning 789 databanks...",
  "HEX node synchronized.",
  "Processing your request through the Firewall...",
  "Connection established to the Game Forge.",
  "NPC personality matrix loaded.",
  "Ready to assist, Creator.",
]

export function NPCConsole() {
  const [input, setInput] = useState("")
  const [output, setOutput] = useState<string[]>([])
  const [isTyping, setIsTyping] = useState(false)

  useEffect(() => {
    // Initial boot sequence
    const bootMessages = ["> 789 NPC LAB v1.0", "> Neural Prompt Command System Online", "> Type your command below..."]

    bootMessages.forEach((msg, i) => {
      setTimeout(() => {
        setOutput((prev) => [...prev, msg])
      }, i * 500)
    })
  }, [])

  const handleSubmit = () => {
    if (!input.trim()) return

    setOutput((prev) => [...prev, `> USER: ${input}`])
    setIsTyping(true)
    setInput("")

    // Simulate NPC response
    setTimeout(
      () => {
        const response = NPC_RESPONSES[Math.floor(Math.random() * NPC_RESPONSES.length)]
        setOutput((prev) => [...prev, `> NPC: ${response}`])
        setIsTyping(false)
      },
      1000 + Math.random() * 1000,
    )
  }

  return (
    <div className="w-full max-w-2xl rounded-xl overflow-hidden border border-[#00ff88]/30 bg-card/50 backdrop-blur">
      {/* Header */}
      <div className="flex items-center gap-2 px-4 py-2 border-b border-[#00ff88]/30 bg-[#00ff88]/10">
        <div className="flex gap-2">
          <div className="w-3 h-3 rounded-full bg-[#ff0044]" />
          <div className="w-3 h-3 rounded-full bg-[#ffd700]" />
          <div className="w-3 h-3 rounded-full bg-[#00ff88]" />
        </div>
        <span className="font-mono text-sm text-[#00ff88]">NPC_LAB.exe</span>
      </div>

      {/* Output */}
      <div className="h-64 overflow-y-auto p-4 font-mono text-sm">
        {output.map((line, i) => (
          <div key={i} className={line.includes("NPC:") ? "neon-text-lime" : "text-muted-foreground"}>
            {line}
          </div>
        ))}
        {isTyping && <div className="neon-text-lime animate-pulse">{"> NPC: ..."}</div>}
      </div>

      {/* Input */}
      <div className="flex gap-2 p-4 border-t border-[#00ff88]/30">
        <Textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Enter your command..."
          className="min-h-[60px] font-mono text-sm bg-muted/30 border-[#00ff88]/30 focus:border-[#00ff88]"
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault()
              handleSubmit()
            }
          }}
        />
        <Button
          onClick={handleSubmit}
          className="px-6 bg-[#00ff88] text-background hover:bg-[#00ff88]/80 font-mono font-bold"
        >
          RUN
        </Button>
      </div>
    </div>
  )
}
