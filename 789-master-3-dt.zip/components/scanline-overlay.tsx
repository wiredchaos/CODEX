// CRT scanline effect overlay for cyber noir aesthetic
// Used across RUPTURE docudrama pages

export function ScanlineOverlay() {
  return (
    <div
      className="pointer-events-none fixed inset-0 z-50 opacity-[0.03]"
      style={{
        backgroundImage: `repeating-linear-gradient(
          0deg,
          transparent,
          transparent 2px,
          rgba(0, 240, 255, 0.1) 2px,
          rgba(0, 240, 255, 0.1) 4px
        )`,
        backgroundSize: "100% 4px",
      }}
      aria-hidden="true"
    />
  )
}
