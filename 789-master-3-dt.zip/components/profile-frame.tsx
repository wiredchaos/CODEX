"use client"

import { useState } from "react"
import { CREW_COLORS, type CrewType } from "@/lib/crew-config"

interface ProfileFrameProps {
  imageUrl?: string
  username?: string
  crew?: CrewType
  size?: "sm" | "md" | "lg"
}

const sizeMap = {
  sm: 80,
  md: 120,
  lg: 200,
}

export function ProfileFrame({
  imageUrl = "/cyberpunk-avatar-neon-portrait.jpg",
  username = "ANON_789",
  crew = "alpha",
  size = "md",
}: ProfileFrameProps) {
  const [hovered, setHovered] = useState(false)
  const colors = CREW_COLORS[crew]
  const dimension = sizeMap[size]

  return (
    <div
      className="relative group cursor-pointer"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{ width: dimension, height: dimension + 40 }}
    >
      {/* Hexagonal frame */}
      <svg width={dimension} height={dimension} viewBox="0 0 200 200" className="absolute top-0 left-0">
        <defs>
          <clipPath id={`hex-clip-${crew}`}>
            <polygon points="100,5 190,55 190,145 100,195 10,145 10,55" />
          </clipPath>
          <linearGradient id={`frame-gradient-${crew}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={colors.primary} />
            <stop offset="100%" stopColor={colors.secondary} />
          </linearGradient>
          <filter id={`frame-glow-${crew}`}>
            <feGaussianBlur stdDeviation={hovered ? 6 : 3} result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Background */}
        <polygon
          points="100,5 190,55 190,145 100,195 10,145 10,55"
          fill={`url(#frame-gradient-${crew})`}
          opacity={0.2}
        />

        {/* Profile image */}
        <image
          href={imageUrl}
          x="10"
          y="5"
          width="180"
          height="190"
          clipPath={`url(#hex-clip-${crew})`}
          preserveAspectRatio="xMidYMid slice"
        />

        {/* Frame border */}
        <polygon
          points="100,5 190,55 190,145 100,195 10,145 10,55"
          fill="none"
          stroke={`url(#frame-gradient-${crew})`}
          strokeWidth={hovered ? 4 : 3}
          filter={`url(#frame-glow-${crew})`}
          className="transition-all duration-300"
        />

        {/* Inner border */}
        <polygon
          points="100,15 180,60 180,140 100,185 20,140 20,60"
          fill="none"
          stroke={colors.secondary}
          strokeWidth={1}
          opacity={0.5}
        />
      </svg>

      {/* Username tag */}
      <div
        className="absolute bottom-0 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full font-mono text-xs font-bold uppercase tracking-wider"
        style={{
          backgroundColor: `${colors.primary}20`,
          color: colors.primary,
          border: `1px solid ${colors.primary}`,
          boxShadow: hovered ? colors.glow : "none",
        }}
      >
        {username}
      </div>
    </div>
  )
}
