"use client"

import { useState, useCallback, useRef } from "react"

// Door state machine
export type DoorState = "CLOSED" | "OPENING" | "OPEN" | "CLOSING"

export interface DoorEvents {
  onOpenStart?: () => void
  onOpenEnd?: () => void
  onCloseStart?: () => void
  onCloseEnd?: () => void
}

export interface DoorController {
  state: DoorState
  progress: number // 0 = closed, 1 = open
  isLocked: boolean
  open: () => void
  close: () => void
  toggle: () => void
  setLocked: (locked: boolean) => void
  update: (delta: number) => void
}

const DOOR_SPEED = 2.0 // Units per second
const AUTO_CLOSE_DELAY = 5000 // ms

export function useDoorController(events?: DoorEvents, autoClose = true): DoorController {
  const [state, setState] = useState<DoorState>("CLOSED")
  const [progress, setProgress] = useState(0)
  const [isLocked, setIsLocked] = useState(false)
  const autoCloseTimer = useRef<NodeJS.Timeout | null>(null)

  const clearAutoClose = () => {
    if (autoCloseTimer.current) {
      clearTimeout(autoCloseTimer.current)
      autoCloseTimer.current = null
    }
  }

  const startAutoClose = useCallback(() => {
    if (!autoClose) return
    clearAutoClose()
    autoCloseTimer.current = setTimeout(() => {
      setState((s) => {
        if (s === "OPEN" && !isLocked) {
          events?.onCloseStart?.()
          return "CLOSING"
        }
        return s
      })
    }, AUTO_CLOSE_DELAY)
  }, [autoClose, isLocked, events])

  const open = useCallback(() => {
    if (isLocked) return
    if (state === "CLOSED" || state === "CLOSING") {
      clearAutoClose()
      setState("OPENING")
      events?.onOpenStart?.()
    }
  }, [state, isLocked, events])

  const close = useCallback(() => {
    if (isLocked) return
    if (state === "OPEN" || state === "OPENING") {
      clearAutoClose()
      setState("CLOSING")
      events?.onCloseStart?.()
    }
  }, [state, isLocked, events])

  const toggle = useCallback(() => {
    if (state === "CLOSED" || state === "CLOSING") {
      open()
    } else {
      close()
    }
  }, [state, open, close])

  const setLockedState = useCallback((locked: boolean) => {
    setIsLocked(locked)
    if (locked) {
      clearAutoClose()
    }
  }, [])

  const update = useCallback(
    (delta: number) => {
      setProgress((prev) => {
        let newProgress = prev

        if (state === "OPENING") {
          newProgress = Math.min(1, prev + delta * DOOR_SPEED)
          if (newProgress >= 1) {
            setState("OPEN")
            events?.onOpenEnd?.()
            startAutoClose()
          }
        } else if (state === "CLOSING") {
          newProgress = Math.max(0, prev - delta * DOOR_SPEED)
          if (newProgress <= 0) {
            setState("CLOSED")
            events?.onCloseEnd?.()
          }
        }

        return newProgress
      })
    },
    [state, events, startAutoClose],
  )

  return {
    state,
    progress,
    isLocked,
    open,
    close,
    toggle,
    setLocked: setLockedState,
    update,
  }
}
