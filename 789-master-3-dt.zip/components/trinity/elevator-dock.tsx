"use client"

import { useState, useCallback } from "react"
import { useRouter } from "next/navigation"
import { DoorOpen, DoorClosed, ArrowUpDown, Bell, Lock, Unlock, ChevronUp, ChevronDown } from "lucide-react"
import { useDoorController, type DoorState } from "./use-door-controller"
import { FLOOR_REGISTRY } from "@/lib/trinity/logic"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface ElevatorDockProps {
  onStateChange?: (state: DoorState) => void
  onFloorSelect?: (floorId: string) => void
}

export function ElevatorDock({ onStateChange, onFloorSelect }: ElevatorDockProps) {
  const router = useRouter()
  const [showFloors, setShowFloors] = useState(false)
  const [selectedFloor, setSelectedFloor] = useState<string | null>(null)
  const [isNavigating, setIsNavigating] = useState(false)

  const controller = useDoorController({
    onOpenStart: () => onStateChange?.("OPENING"),
    onOpenEnd: () => onStateChange?.("OPEN"),
    onCloseStart: () => onStateChange?.("CLOSING"),
    onCloseEnd: () => {
      onStateChange?.("CLOSED")
      // Navigate after doors close
      if (selectedFloor && isNavigating) {
        const floor = FLOOR_REGISTRY.find((f) => f.id === selectedFloor)
        if (floor) {
          router.push(floor.path)
        }
        setIsNavigating(false)
        setSelectedFloor(null)
      }
    },
  })

  const handleCall = useCallback(() => {
    if (controller.state === "CLOSED") {
      controller.open()
      // Play ding sound stub
      console.log("[v0] Elevator ding!")
    } else {
      // Already open, just ding
      console.log("[v0] Elevator ding!")
    }
  }, [controller])

  const handleGoToFloor = useCallback(
    (floorId: string) => {
      if (controller.isLocked) return

      setSelectedFloor(floorId)
      setIsNavigating(true)
      setShowFloors(false)
      onFloorSelect?.(floorId)

      // Close doors first, navigation happens in onCloseEnd
      if (controller.state === "OPEN" || controller.state === "OPENING") {
        controller.close()
      } else {
        // Doors already closed, navigate immediately
        const floor = FLOOR_REGISTRY.find((f) => f.id === floorId)
        if (floor) {
          router.push(floor.path)
        }
        setIsNavigating(false)
        setSelectedFloor(null)
      }
    },
    [controller, router, onFloorSelect],
  )

  const getStateIcon = () => {
    switch (controller.state) {
      case "OPEN":
      case "OPENING":
        return <DoorOpen className="w-4 h-4" />
      default:
        return <DoorClosed className="w-4 h-4" />
    }
  }

  const getStateLabel = () => {
    if (isNavigating && selectedFloor) {
      const floor = FLOOR_REGISTRY.find((f) => f.id === selectedFloor)
      return `Going to ${floor?.name || selectedFloor}...`
    }
    return controller.state
  }

  return (
    <div className="fixed bottom-20 left-4 z-40 flex flex-col gap-2 md:bottom-4">
      {/* Floor selector panel */}
      {showFloors && (
        <div className="bg-black/90 backdrop-blur-xl border border-cyan-500/30 rounded-lg p-2 max-h-[60vh] overflow-y-auto w-64">
          <div className="text-xs font-mono text-cyan-400 px-2 py-1 border-b border-cyan-500/20 mb-2">SELECT FLOOR</div>
          <div className="flex flex-col gap-1">
            {FLOOR_REGISTRY.map((floor) => (
              <button
                key={floor.id}
                onClick={() => handleGoToFloor(floor.id)}
                disabled={controller.isLocked}
                className={cn(
                  "flex items-center gap-2 px-3 py-2 rounded text-left transition-all",
                  "hover:bg-cyan-500/20 text-white/80 hover:text-white",
                  controller.isLocked && "opacity-50 cursor-not-allowed",
                  selectedFloor === floor.id && "bg-cyan-500/30 text-cyan-400",
                )}
              >
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: floor.color }} />
                <span className="text-sm font-sans">{floor.name}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Control dock */}
      <div className="bg-black/90 backdrop-blur-xl border border-cyan-500/30 rounded-lg p-2">
        {/* Status bar */}
        <div className="flex items-center justify-between px-2 py-1 mb-2 border-b border-cyan-500/20">
          <div className="flex items-center gap-2">
            {getStateIcon()}
            <span className="text-xs font-mono text-cyan-400">{getStateLabel()}</span>
          </div>
          <div className="flex items-center gap-1">
            {/* Progress indicator */}
            <div className="w-16 h-1 bg-white/10 rounded-full overflow-hidden">
              <div
                className="h-full bg-cyan-400 transition-all duration-100"
                style={{ width: `${controller.progress * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* Control buttons */}
        <div className="grid grid-cols-4 gap-1">
          <Button
            variant="outline"
            size="sm"
            onClick={controller.open}
            disabled={controller.isLocked || controller.state === "OPEN" || controller.state === "OPENING"}
            className="bg-transparent border-cyan-500/30 hover:bg-cyan-500/20 text-cyan-400"
          >
            <ChevronUp className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={controller.close}
            disabled={controller.isLocked || controller.state === "CLOSED" || controller.state === "CLOSING"}
            className="bg-transparent border-cyan-500/30 hover:bg-cyan-500/20 text-cyan-400"
          >
            <ChevronDown className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowFloors(!showFloors)}
            className={cn(
              "bg-transparent border-cyan-500/30 hover:bg-cyan-500/20 text-cyan-400",
              showFloors && "bg-cyan-500/20",
            )}
          >
            <ArrowUpDown className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleCall}
            className="bg-transparent border-cyan-500/30 hover:bg-cyan-500/20 text-cyan-400"
          >
            <Bell className="w-4 h-4" />
          </Button>
        </div>

        {/* Lock toggle */}
        <div className="flex items-center justify-between mt-2 pt-2 border-t border-cyan-500/20">
          <span className="text-xs font-mono text-white/50">LOCK</span>
          <button
            onClick={() => controller.setLocked(!controller.isLocked)}
            className={cn(
              "p-1.5 rounded transition-colors",
              controller.isLocked ? "bg-red-500/20 text-red-400" : "bg-white/5 text-white/40 hover:text-white/60",
            )}
          >
            {controller.isLocked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>
    </div>
  )
}
