"use client"

import { useRef, useMemo } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { Environment, Text } from "@react-three/drei"
import * as THREE from "three"
import { useDoorController, type DoorState } from "./use-door-controller"

interface DoorPanelProps {
  side: "left" | "right"
  progress: number
  state: DoorState
}

function DoorPanel({ side, progress, state }: DoorPanelProps) {
  const meshRef = useRef<THREE.Mesh>(null)
  const direction = side === "left" ? -1 : 1
  const openOffset = 1.1 // How far doors slide open

  useFrame(() => {
    if (meshRef.current) {
      // Ease the door movement
      const targetX = direction * (0.55 + progress * openOffset)
      meshRef.current.position.x = THREE.MathUtils.lerp(meshRef.current.position.x, targetX, 0.15)
    }
  })

  const material = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: state === "OPEN" ? "#1a3a4a" : "#0a1a2a",
        metalness: 0.9,
        roughness: 0.2,
        emissive: state === "OPENING" || state === "CLOSING" ? "#00ffff" : "#003344",
        emissiveIntensity: state === "OPENING" || state === "CLOSING" ? 0.3 : 0.1,
      }),
    [state],
  )

  return (
    <mesh ref={meshRef} position={[direction * 0.55, 0, 0]} castShadow receiveShadow>
      <boxGeometry args={[1, 2.4, 0.08]} />
      <primitive object={material} attach="material" />
      {/* Door frame accent */}
      <mesh position={[side === "left" ? 0.48 : -0.48, 0, 0.05]}>
        <boxGeometry args={[0.04, 2.4, 0.02]} />
        <meshStandardMaterial color="#00ffff" emissive="#00ffff" emissiveIntensity={0.5} />
      </mesh>
      {/* Panel lines */}
      {[-0.6, 0, 0.6].map((y, i) => (
        <mesh key={i} position={[0, y, 0.045]}>
          <boxGeometry args={[0.9, 0.02, 0.01]} />
          <meshStandardMaterial color="#003344" metalness={0.8} roughness={0.3} />
        </mesh>
      ))}
    </mesh>
  )
}

interface DoorFrameProps {
  state: DoorState
}

function DoorFrame({ state }: DoorFrameProps) {
  const isActive = state === "OPENING" || state === "CLOSING"

  return (
    <group>
      {/* Top frame */}
      <mesh position={[0, 1.35, 0]}>
        <boxGeometry args={[2.4, 0.15, 0.15]} />
        <meshStandardMaterial
          color="#0a1520"
          metalness={0.95}
          roughness={0.1}
          emissive={isActive ? "#00ffff" : "#001122"}
          emissiveIntensity={isActive ? 0.4 : 0.1}
        />
      </mesh>
      {/* Left frame */}
      <mesh position={[-1.15, 0, 0]}>
        <boxGeometry args={[0.1, 2.7, 0.15]} />
        <meshStandardMaterial color="#0a1520" metalness={0.95} roughness={0.1} />
      </mesh>
      {/* Right frame */}
      <mesh position={[1.15, 0, 0]}>
        <boxGeometry args={[0.1, 2.7, 0.15]} />
        <meshStandardMaterial color="#0a1520" metalness={0.95} roughness={0.1} />
      </mesh>
      {/* Bottom frame */}
      <mesh position={[0, -1.25, 0]}>
        <boxGeometry args={[2.4, 0.1, 0.15]} />
        <meshStandardMaterial color="#0a1520" metalness={0.95} roughness={0.1} />
      </mesh>
      {/* Floor indicator light */}
      <mesh position={[0, 1.55, 0.1]}>
        <boxGeometry args={[0.8, 0.12, 0.02]} />
        <meshStandardMaterial
          color={isActive ? "#00ffff" : "#003344"}
          emissive={isActive ? "#00ffff" : "#001122"}
          emissiveIntensity={isActive ? 1 : 0.3}
        />
      </mesh>
    </group>
  )
}

interface FloorIndicatorProps {
  floor: string
  state: DoorState
}

function FloorIndicator({ floor, state }: FloorIndicatorProps) {
  return (
    <group position={[0, 1.7, 0.05]}>
      <Text
        fontSize={0.15}
        color={state === "OPEN" ? "#00ffff" : "#00aaaa"}
        anchorX="center"
        anchorY="middle"
        font="/fonts/Geist-Bold.ttf"
      >
        {floor.toUpperCase()}
      </Text>
    </group>
  )
}

interface ElevatorDoorsSceneProps {
  controller: ReturnType<typeof useDoorController>
  currentFloor: string
}

function ElevatorDoorsScene({ controller, currentFloor }: ElevatorDoorsSceneProps) {
  useFrame((_, delta) => {
    controller.update(delta)
  })

  return (
    <>
      <ambientLight intensity={0.3} />
      <pointLight position={[0, 2, 2]} intensity={1} color="#00ffff" />
      <pointLight position={[-2, 1, 1]} intensity={0.5} color="#0088ff" />
      <spotLight position={[0, 3, 1]} angle={0.5} penumbra={0.5} intensity={1} color="#ffffff" castShadow />

      <group position={[0, 0, -0.5]}>
        <DoorFrame state={controller.state} />
        <DoorPanel side="left" progress={controller.progress} state={controller.state} />
        <DoorPanel side="right" progress={controller.progress} state={controller.state} />
        <FloorIndicator floor={currentFloor} state={controller.state} />
      </group>

      {/* Back wall */}
      <mesh position={[0, 0, -1]} receiveShadow>
        <planeGeometry args={[4, 4]} />
        <meshStandardMaterial color="#050a10" metalness={0.5} roughness={0.8} />
      </mesh>

      {/* Floor */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.3, 0]} receiveShadow>
        <planeGeometry args={[4, 4]} />
        <meshStandardMaterial color="#0a1520" metalness={0.8} roughness={0.2} />
      </mesh>

      <Environment preset="city" />
    </>
  )
}

export interface ElevatorDoorsProps {
  currentFloor?: string
  onOpenStart?: () => void
  onOpenEnd?: () => void
  onCloseStart?: () => void
  onCloseEnd?: () => void
  onNavigate?: (floor: string) => void
  autoClose?: boolean
}

export function ElevatorDoors({
  currentFloor = "Lobby",
  onOpenStart,
  onOpenEnd,
  onCloseStart,
  onCloseEnd,
  autoClose = true,
}: ElevatorDoorsProps) {
  const controller = useDoorController(
    {
      onOpenStart,
      onOpenEnd,
      onCloseStart,
      onCloseEnd,
    },
    autoClose,
  )

  return (
    <div className="w-full h-full min-h-[300px]">
      <Canvas shadows camera={{ position: [0, 0, 3], fov: 50 }} gl={{ antialias: true }} dpr={[1, 2]}>
        <ElevatorDoorsScene controller={controller} currentFloor={currentFloor} />
      </Canvas>
    </div>
  )
}

// Export controller hook for external control
export { useDoorController }
export type { DoorState }
