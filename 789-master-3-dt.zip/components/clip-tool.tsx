"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Scissors, Play, Pause, Download, Copy, Twitter, ImageIcon, Film, Sparkles } from "lucide-react"
import Image from "next/image"

interface ClipToolProps {
  contentId: string
  contentTitle: string
  contentImage: string
  contentDuration: number // in seconds
  onClose: () => void
}

export function ClipTool({ contentId, contentTitle, contentImage, contentDuration, onClose }: ClipToolProps) {
  const [startTime, setStartTime] = useState(0)
  const [endTime, setEndTime] = useState(Math.min(30, contentDuration))
  const [isPlaying, setIsPlaying] = useState(false)
  const [clipFormat, setClipFormat] = useState<"mp4" | "gif" | "webm">("mp4")
  const [aspectRatio, setAspectRatio] = useState<"16:9" | "9:16" | "1:1">("16:9")
  const [includeWatermark, setIncludeWatermark] = useState(true)
  const [isGenerating, setIsGenerating] = useState(false)

  const clipDuration = endTime - startTime

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const handleGenerateClip = async () => {
    setIsGenerating(true)
    // Simulate clip generation
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setIsGenerating(false)
    // In production, this would call an API to generate the clip
  }

  const handleShare = (platform: "twitter" | "copy") => {
    const shareUrl = `https://789.studio/clip/${contentId}?start=${startTime}&end=${endTime}`

    if (platform === "twitter") {
      const text = encodeURIComponent(`Check out this clip from "${contentTitle}" on @789Studios! 🎬`)
      window.open(`https://twitter.com/intent/tweet?text=${text}&url=${encodeURIComponent(shareUrl)}`, "_blank")
    } else {
      navigator.clipboard.writeText(shareUrl)
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
      <Card className="bg-zinc-900 border-orange-500/30 w-full max-w-3xl max-h-[95vh] overflow-auto">
        {/* Header */}
        <div className="p-4 border-b border-zinc-800 flex items-center justify-between sticky top-0 bg-zinc-900 z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-orange-500/20 flex items-center justify-center">
              <Scissors className="w-5 h-5 text-orange-500" />
            </div>
            <div>
              <h2 className="font-bold text-white">Clip Studio</h2>
              <p className="text-xs text-white/60">Create shareable promo clips</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={onClose} className="text-white/60 hover:text-white">
            Close
          </Button>
        </div>

        <div className="p-6 space-y-6">
          {/* Preview */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-white">Preview</label>
            <div
              className={`relative bg-black rounded-lg overflow-hidden mx-auto ${
                aspectRatio === "16:9"
                  ? "aspect-video w-full"
                  : aspectRatio === "9:16"
                    ? "aspect-[9/16] max-h-[300px]"
                    : "aspect-square max-h-[300px]"
              }`}
            >
              <Image src={contentImage || "/placeholder.svg"} alt="Clip preview" fill className="object-cover" />
              {includeWatermark && (
                <div className="absolute bottom-2 right-2 bg-black/60 px-2 py-1 rounded text-xs text-white/80">
                  789 Studios
                </div>
              )}
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="absolute inset-0 flex items-center justify-center group"
              >
                <div className="w-14 h-14 rounded-full bg-orange-500/80 group-hover:bg-orange-500 flex items-center justify-center transition-colors">
                  {isPlaying ? (
                    <Pause className="w-6 h-6 text-white" />
                  ) : (
                    <Play className="w-6 h-6 text-white fill-current ml-1" />
                  )}
                </div>
              </button>
            </div>
          </div>

          {/* Timeline */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-white">Clip Range</label>
              <Badge className="bg-orange-500/20 text-orange-500 border-orange-500/30">{clipDuration}s clip</Badge>
            </div>

            {/* Visual Timeline */}
            <div className="h-16 bg-zinc-800 rounded-lg relative overflow-hidden">
              {/* Waveform visualization placeholder */}
              <div className="absolute inset-0 flex items-center px-2">
                {Array.from({ length: 50 }).map((_, i) => (
                  <div
                    key={i}
                    className="flex-1 mx-px bg-zinc-600 rounded-full"
                    style={{
                      height: `${20 + Math.random() * 60}%`,
                      opacity:
                        i >= (startTime / contentDuration) * 50 && i <= (endTime / contentDuration) * 50 ? 1 : 0.3,
                    }}
                  />
                ))}
              </div>

              {/* Selection overlay */}
              <div
                className="absolute top-0 bottom-0 bg-orange-500/20 border-x-2 border-orange-500"
                style={{
                  left: `${(startTime / contentDuration) * 100}%`,
                  right: `${100 - (endTime / contentDuration) * 100}%`,
                }}
              />
            </div>

            {/* Time inputs */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-xs text-white/60">Start Time</label>
                <div className="flex items-center gap-2">
                  <input
                    type="range"
                    min={0}
                    max={contentDuration - 1}
                    value={startTime}
                    onChange={(e) => {
                      const val = Number.parseInt(e.target.value)
                      if (val < endTime) setStartTime(val)
                    }}
                    className="flex-1 accent-orange-500"
                  />
                  <span className="text-sm text-white font-mono w-12">{formatTime(startTime)}</span>
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs text-white/60">End Time</label>
                <div className="flex items-center gap-2">
                  <input
                    type="range"
                    min={1}
                    max={contentDuration}
                    value={endTime}
                    onChange={(e) => {
                      const val = Number.parseInt(e.target.value)
                      if (val > startTime) setEndTime(val)
                    }}
                    className="flex-1 accent-orange-500"
                  />
                  <span className="text-sm text-white font-mono w-12">{formatTime(endTime)}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Settings */}
          <div className="grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-white">Format</label>
              <div className="flex gap-2">
                {(["mp4", "gif", "webm"] as const).map((format) => (
                  <button
                    key={format}
                    onClick={() => setClipFormat(format)}
                    className={`flex-1 px-3 py-2 rounded-lg text-xs font-medium uppercase transition-colors ${
                      clipFormat === format ? "bg-orange-500 text-white" : "bg-zinc-800 text-white/60 hover:bg-zinc-700"
                    }`}
                  >
                    {format}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-white">Aspect Ratio</label>
              <div className="flex gap-2">
                {(
                  [
                    { value: "16:9", icon: Film },
                    { value: "9:16", icon: ImageIcon },
                    { value: "1:1", icon: ImageIcon },
                  ] as const
                ).map(({ value, icon: Icon }) => (
                  <button
                    key={value}
                    onClick={() => setAspectRatio(value)}
                    className={`flex-1 px-3 py-2 rounded-lg text-xs font-medium transition-colors flex items-center justify-center gap-1 ${
                      aspectRatio === value ? "bg-orange-500 text-white" : "bg-zinc-800 text-white/60 hover:bg-zinc-700"
                    }`}
                  >
                    {value}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-white">Options</label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeWatermark}
                  onChange={(e) => setIncludeWatermark(e.target.checked)}
                  className="rounded bg-zinc-800 border-zinc-700 text-orange-500 focus:ring-orange-500"
                />
                <span className="text-sm text-white/80">Add watermark</span>
              </label>
            </div>
          </div>

          {/* Quick Presets */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-white">Quick Presets</label>
            <div className="flex flex-wrap gap-2">
              {[
                { name: "Story (15s)", duration: 15 },
                { name: "Reel (30s)", duration: 30 },
                { name: "Teaser (60s)", duration: 60 },
              ].map((preset) => (
                <Button
                  key={preset.name}
                  variant="outline"
                  size="sm"
                  className="border-zinc-700 text-white/70 hover:bg-zinc-800 text-xs bg-transparent"
                  onClick={() => {
                    setStartTime(0)
                    setEndTime(Math.min(preset.duration, contentDuration))
                  }}
                >
                  <Sparkles className="w-3 h-3 mr-1" />
                  {preset.name}
                </Button>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-zinc-800">
            <Button
              className="flex-1 bg-orange-500 hover:bg-orange-600 text-white font-bold gap-2"
              onClick={handleGenerateClip}
              disabled={isGenerating}
            >
              {isGenerating ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  Generate Clip
                </>
              )}
            </Button>
            <Button
              variant="outline"
              className="border-zinc-700 text-white hover:bg-zinc-800 gap-2 bg-transparent"
              onClick={() => handleShare("twitter")}
            >
              <Twitter className="w-4 h-4" />
              Share
            </Button>
            <Button
              variant="outline"
              className="border-zinc-700 text-white hover:bg-zinc-800 gap-2 bg-transparent"
              onClick={() => handleShare("copy")}
            >
              <Copy className="w-4 h-4" />
              Copy Link
            </Button>
          </div>
        </div>
      </Card>
    </div>
  )
}
