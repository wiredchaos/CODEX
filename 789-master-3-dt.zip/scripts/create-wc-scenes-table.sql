-- Create wc_scenes table for Trinity Field System compiled sets
CREATE TABLE IF NOT EXISTS wc_scenes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  scene_id TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  set_type TEXT NOT NULL,
  tag TEXT NOT NULL DEFAULT '789_set',
  runtime_profile TEXT NOT NULL DEFAULT 'cinematic',
  deployed_route TEXT NOT NULL,
  credits_used INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'compiling',
  metadata JSONB DEFAULT '{}',
  user_id UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Add RLS policies
ALTER TABLE wc_scenes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own scenes"
  ON wc_scenes FOR SELECT
  USING (auth.uid() = user_id OR user_id IS NULL);

CREATE POLICY "Users can insert own scenes"
  ON wc_scenes FOR INSERT
  WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

CREATE POLICY "Service role full access"
  ON wc_scenes FOR ALL
  USING (auth.jwt() ->> 'role' = 'service_role');

-- Create indexes
CREATE INDEX idx_wc_scenes_tag ON wc_scenes(tag);
CREATE INDEX idx_wc_scenes_user ON wc_scenes(user_id);
CREATE INDEX idx_wc_scenes_status ON wc_scenes(status);
