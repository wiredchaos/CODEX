export interface ObserverEvent {
  type: string
  timestamp: number
  floorId?: string
  metadata?: Record<string, any>
}

export class TrinityObserver {
  private events: ObserverEvent[] = []
  private sessionId: string
  private startTime: number

  constructor() {
    this.sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    this.startTime = Date.now()
  }

  track(type: string, metadata?: Record<string, any>): void {
    const event: ObserverEvent = {
      type,
      timestamp: Date.now(),
      metadata,
    }
    this.events.push(event)

    if (type === "floor_visit" && metadata?.floorId === "ott789:entry") {
      this.trackOTTSession(metadata)
    }

    if (typeof window !== "undefined") {
      try {
        const stored = JSON.parse(localStorage.getItem("789_journey") || "[]")
        stored.push(event)
        localStorage.setItem("789_journey", JSON.stringify(stored.slice(-50)))
      } catch (e) {
        console.error("Failed to store journey event", e)
      }
    }
  }

  private trackOTTSession(metadata: Record<string, any>): void {
    this.track("ott.session.start", {
      floorId: "ott789:entry",
      namespace: "OTT_789",
      sessionId: this.sessionId,
      ...metadata,
    })
  }

  trackFloorVisit(floorId: string, duration?: number): void {
    this.track("floor_visit", { floorId, duration })
  }

  trackTourComplete(completedFloors: string[], totalDuration: number): void {
    this.track("tour_complete", { completedFloors, totalDuration })
  }

  trackTourAbandoned(lastFloor: string, reason?: string): void {
    this.track("tour_abandoned", { lastFloor, reason })
  }

  trackAccessibilityPreference(preference: string, enabled: boolean): void {
    this.track("a11y_preference", { preference, enabled })
  }

  trackViewerVsCreator(role: "viewer" | "creator" | "producer"): void {
    this.track("viewer_vs_creator.detected", { role, timestamp: Date.now() })
  }

  trackElevatorEntered(fromFloor: string): void {
    this.track("elevator.entered", { fromFloor, timestamp: Date.now() })
  }

  getSessionSummary() {
    const duration = Date.now() - this.startTime
    const floorVisits = this.events.filter((e) => e.type === "floor_visit")
    const uniqueFloors = new Set(floorVisits.map((e) => e.metadata?.floorId).filter(Boolean))

    return {
      sessionId: this.sessionId,
      duration,
      totalEvents: this.events.length,
      floorsVisited: uniqueFloors.size,
      events: this.events,
    }
  }

  exportJourney(): string {
    return JSON.stringify(this.getSessionSummary(), null, 2)
  }
}
