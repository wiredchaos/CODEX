export interface TrinityState {
  currentFloor: string | null
  tourActive: boolean
  tourPlan: TourPlan | null
  visitedFloors: string[]
  preferences: UserPreferences
  progress: TourProgress
}

export interface TourPlan {
  floors: string[]
  order: string[]
  estimatedDuration: "quick" | "standard" | "deep"
  includesAkashic: boolean
}

export interface UserPreferences {
  safeMode: boolean
  reducedMotion: boolean
  highContrast: boolean
  skipAnimations: boolean
  audioDescriptions: boolean
}

export interface TourProgress {
  completedFloors: string[]
  currentIndex: number
  totalFloors: number
  startTime: number | null
  endTime: number | null
}

export interface FloorEligibility {
  canAccess: boolean
  reason?: string
  requiresAge?: number
  requiresToken?: string
  requiresRole?: string[]
}

export class TrinityLogic {
  private state: TrinityState

  constructor(initialState?: Partial<TrinityState>) {
    this.state = {
      currentFloor: null,
      tourActive: false,
      tourPlan: null,
      visitedFloors: [],
      preferences: {
        safeMode: false,
        reducedMotion: false,
        highContrast: false,
        skipAnimations: false,
        audioDescriptions: false,
      },
      progress: {
        completedFloors: [],
        currentIndex: 0,
        totalFloors: 0,
        startTime: null,
        endTime: null,
      },
      ...initialState,
    }
  }

  getState(): TrinityState {
    return { ...this.state }
  }

  setState(updates: Partial<TrinityState>): void {
    this.state = { ...this.state, ...updates }
  }

  checkFloorEligibility(floorId: string, userProfile?: any): FloorEligibility {
    const floor = FLOOR_REGISTRY.find((f) => f.id === floorId)
    if (!floor) {
      return { canAccess: false, reason: "Floor not found" }
    }

    if (floor.ageGate && (!userProfile?.age || userProfile.age < floor.ageGate)) {
      return { canAccess: false, reason: "Age restriction", requiresAge: floor.ageGate }
    }

    if (floor.tokenGate && !userProfile?.hasToken) {
      return { canAccess: false, reason: "Token required", requiresToken: floor.tokenGate }
    }

    if (floor.roleGate && !floor.roleGate.some((role) => userProfile?.roles?.includes(role))) {
      return { canAccess: false, reason: "Role required", requiresRole: floor.roleGate }
    }

    if (floor.firewallProfile === "media") {
      // Media firewall: Akashic floors hidden unless explicitly enabled
      if (floor.realm === "Akashic" && !userProfile?.akashicEnabled) {
        return { canAccess: false, reason: "Akashic content not enabled" }
      }
    }

    return { canAccess: true }
  }

  generateTourPlan(goals: string[], comfort: string, format: string): TourPlan {
    const floors: string[] = []

    // Map goals to floors
    if (goals.includes("learn")) {
      floors.push("film3", "creator")
    }
    if (goals.includes("build")) {
      floors.push("creator", "pricing")
    }
    if (goals.includes("watch")) {
      floors.push("browse", "lounge")
    }
    if (goals.includes("play")) {
      floors.push("lounge", "mint")
    }

    const estimatedDuration = format === "quick" ? "quick" : comfort === "advanced" ? "deep" : "standard"

    return {
      floors: [...new Set(floors)],
      order: floors,
      estimatedDuration,
      includesAkashic: goals.includes("akashic"),
    }
  }

  startTour(plan: TourPlan): void {
    this.state.tourActive = true
    this.state.tourPlan = plan
    this.state.progress = {
      completedFloors: [],
      currentIndex: 0,
      totalFloors: plan.floors.length,
      startTime: Date.now(),
      endTime: null,
    }
  }

  endTour(): void {
    if (this.state.progress.startTime) {
      this.state.progress.endTime = Date.now()
    }
    this.state.tourActive = false
  }

  moveToFloor(floorId: string): void {
    this.state.currentFloor = floorId
    if (!this.state.visitedFloors.includes(floorId)) {
      this.state.visitedFloors.push(floorId)
    }
    if (this.state.tourActive && this.state.tourPlan) {
      const floorIndex = this.state.tourPlan.floors.indexOf(floorId)
      if (floorIndex !== -1) {
        this.state.progress.currentIndex = floorIndex
        if (!this.state.progress.completedFloors.includes(floorId)) {
          this.state.progress.completedFloors.push(floorId)
        }
      }
    }
  }

  returnToElevator(): void {
    this.state.currentFloor = "elevator"
  }

  panicExit(): void {
    this.state.currentFloor = "lobby"
    this.state.tourActive = false
  }
}

export interface FloorMetadata {
  id: string
  name: string
  path: string
  guidePersonaId: string
  tourScriptShort: string
  tourScriptDeep: string
  actionsPrimary: string[]
  warnings?: string[]
  ageGate?: number
  tokenGate?: string
  roleGate?: string[]
  color: string
  icon: string
  realm?: "Business" | "Akashic" | "Neutral"
  namespace?: string
  registryKey?: string
  telemetryHooks?: string[]
  firewallProfile?: string
}

export const FLOOR_REGISTRY: FloorMetadata[] = [
  {
    id: "ott789:entry",
    name: "789 Studios Entry",
    path: "/browse",
    guidePersonaId: "neuro-uplink",
    tourScriptShort: "Welcome to 789 Studios OTT. Your gateway to Film3 content.",
    tourScriptDeep:
      "789 Studios Entry is the neutral media floor connecting viewers and creators to decentralized content.",
    actionsPrimary: ["Browse Content", "Become Creator", "Enter Elevator"],
    realm: "Neutral",
    namespace: "OTT_789",
    registryKey: "registry.ott789.entry",
    telemetryHooks: ["ott.session.start", "viewer_vs_creator.detected", "elevator.entered"],
    firewallProfile: "media",
    roleGate: ["viewer", "creator", "producer"],
    color: "#ff00ff",
    icon: "Tv",
  },
  {
    id: "home",
    name: "Lobby",
    path: "/",
    guidePersonaId: "neuro-concierge",
    tourScriptShort: "Welcome to 789 Studios. This is your starting point.",
    tourScriptDeep: "The Lobby is the central hub connecting all floors of the 789 ecosystem.",
    actionsPrimary: ["Start Tour", "Browse Floors", "Skip to Elevator"],
    realm: "Neutral",
    color: "#ffd700",
    icon: "Home",
  },
  {
    id: "creator",
    name: "Creator Hub",
    path: "/creator",
    guidePersonaId: "neuro-creator",
    tourScriptShort: "Publish to YouTube, X, Instagram, TikTok, and LinkedIn simultaneously.",
    tourScriptDeep:
      "The Creator Hub is your control center for multi-platform publishing with token-gated access and blockchain verification.",
    actionsPrimary: ["Upload Content", "View Analytics", "Manage Token Gates"],
    color: "#00ffff",
    icon: "Upload",
  },
  {
    id: "film3",
    name: "Film3 Network",
    path: "/film3",
    guidePersonaId: "neuro-film3",
    tourScriptShort: "Learn the Film3 revolution and decentralized filmmaking.",
    tourScriptDeep: "Film3 is the movement to decentralize cinema using blockchain, NFTs, and community governance.",
    actionsPrimary: ["Watch RUPTURE Documentary", "Take Film3 Course", "Join Community"],
    color: "#daa520",
    icon: "Film",
  },
  {
    id: "pricing",
    name: "Recording Studios",
    path: "/pricing",
    guidePersonaId: "neuro-studios",
    tourScriptShort: "Book professional recording studios for your podcast, music, or video content.",
    tourScriptDeep:
      "State of the art recording facilities with flexible pricing for demos, full productions, and unlimited access.",
    actionsPrimary: ["Book Starter Session", "Book Pro Package", "Book Unlimited Access"],
    color: "#ffd700",
    icon: "Mic",
  },
  {
    id: "spaces",
    name: "Crypto Spaces Network",
    path: "/spaces",
    guidePersonaId: "neuro-spaces",
    tourScriptShort: "24/7 live spaces schedule powered by Doginal Dogs.",
    tourScriptDeep:
      "The Crypto Spaces Network features 24 rotating hosts covering crypto, culture, and community building around the clock.",
    actionsPrimary: ["View Schedule", "Follow Hosts", "Join Live Space"],
    color: "#00ffff",
    icon: "Radio",
  },
  {
    id: "browse",
    name: "Content Library",
    path: "/browse",
    guidePersonaId: "neuro-ott",
    tourScriptShort: "Watch original series, documentaries, and creator content.",
    tourScriptDeep: "789 Studios OTT platform with exclusive Film3 content and Web3 storytelling.",
    actionsPrimary: ["Browse Shows", "Watch Featured", "Explore Channels"],
    color: "#ff00ff",
    icon: "Tv",
  },
  {
    id: "lounge",
    name: "Community Lounge",
    path: "/lounge",
    guidePersonaId: "neuro-community",
    tourScriptShort: "Connect with other creators, play games, and explore interactive experiences.",
    tourScriptDeep: "The Lounge is a social hub for the 789 community with games, chat, and collaborative features.",
    actionsPrimary: ["Join Chat", "Play Game", "View Events"],
    warnings: ["Community guidelines apply"],
    color: "#9d00ff",
    icon: "Users",
  },
  {
    id: "mint",
    name: "NFT Minting",
    path: "/mint",
    guidePersonaId: "neuro-blockchain",
    tourScriptShort: "Mint your content as NFTs on the blockchain.",
    tourScriptDeep: "Turn your films, music, and art into blockchain collectibles with smart contract royalties.",
    actionsPrimary: ["Mint NFT", "View Collection", "Learn About Blockchain"],
    color: "#00ff88",
    icon: "Coins",
  },
]
