// 789 STUDIOS CREW CONFIGURATION
// Single source of truth for all crew member data

export interface CrewMember {
  id: string
  name: string
  handle: string
  fullHandle: string
  doginalId: string
  time: string
  specialty: string
  avatar: string
  tagline: string
  bio: string
  role: string
  primaryColor: string
  secondaryColor: string
  glowColor: string
  socialLinks: {
    x?: string
    instagram?: string
    youtube?: string
    tiktok?: string
    threads?: string
    chirp?: string
  }
  achievements: string[]
  spaces: string[]
  projects: Array<{
    title: string
    description: string
    link: string
    type: string
  }>
  featureSection?: {
    title: string
    description: string
    features: string[]
    tagline: string
  }
  antiMoloch?: string
  hasContent: boolean
}

export const CREW_COLORS = {
  alpha: {
    primary: "#00ffff",
    secondary: "#0088ff",
    glow: "0 0 20px #00ffff, 0 0 40px #00ffff",
    name: "Cyber Cyan",
  },
  beta: {
    primary: "#ff00ff",
    secondary: "#9d00ff",
    glow: "0 0 20px #ff00ff, 0 0 40px #ff00ff",
    name: "Plasma Magenta",
  },
  gamma: {
    primary: "#ffd700",
    secondary: "#ff6600",
    glow: "0 0 20px #ffd700, 0 0 40px #ffd700",
    name: "Solar Gold",
  },
  delta: {
    primary: "#00ff88",
    secondary: "#00ffaa",
    glow: "0 0 20px #00ff88, 0 0 40px #00ff88",
    name: "Matrix Lime",
  },
  omega: {
    primary: "#ff6600",
    secondary: "#ff0044",
    glow: "0 0 20px #ff6600, 0 0 40px #ff6600",
    name: "Blaze Orange",
  },
} as const

export type CrewType = keyof typeof CREW_COLORS

export const CREW_MEMBERS: Record<string, CrewMember> = {
  vibes: {
    id: "vibes",
    name: "VIBES",
    handle: "vibesmetax",
    fullHandle: "VIBES | Energy Architect",
    doginalId: "DD#XXXX",
    time: "7 PM EST",
    specialty: "Energy & Positivity",
    role: "Host & Energy Catalyst",
    avatar: "https://i.postimg.cc/k5hMbFBS/8.png",
    primaryColor: "#ffd700",
    secondaryColor: "#ff6600",
    glowColor: "rgba(255, 215, 0, 0.5)",
    tagline: "Content Creator + Community Energy Catalyst · Bridging Web2 → Web3 · Reporting via 789 Studios",
    bio: "VIBES brings unmatched energy and positivity to the Crypto Spaces Network. Broadcasting daily at 7 PM EST, VIBES is the heartbeat of the 789 community, creating spaces where builders, creators, and visionaries connect. Known for turning conversations into movements.",
    socialLinks: {
      x: "https://x.com/vibesmetax",
    },
    achievements: [
      "Community Energy Catalyst",
      "7 PM EST Prime Time Host",
      "10K+ Daily Space Listeners",
      "3+ Years Daily Broadcasting",
      "789 Studios Co-Founder",
    ],
    spaces: ["Community Building", "Web3 Culture", "Creator Spotlights", "Positive Energy Sessions"],
    projects: [],
    hasContent: false,
  },
  neuro: {
    id: "neuro",
    name: "NEURO",
    handle: "neurometax",
    fullHandle: "MetaX | chirp™",
    doginalId: "DD#1787",
    time: "1 AM EST",
    specialty: "Tech & Innovation",
    role: "Host & AI Architect",
    avatar: "https://i.postimg.cc/0QMkdMw7/15.png",
    primaryColor: "#00ffff",
    secondaryColor: "#0088ff",
    glowColor: "rgba(0, 255, 255, 0.5)",
    tagline:
      "NEURO DD#1787 Content Creator + AI Ghostwriter Translator Bridging Web2 → Web3 · Reporting via Wired Chaos + BWB",
    bio: "Neuro MetaX has been active in Web3 since 2020, operating at the intersection of AI, NFTs, and narrative media. As a collector, content creator, and studio architect, Neuro uses Anti-Moloch principles to design systems where creators, collectors, and communities all participate in the upside of the work they build together.",
    socialLinks: {
      x: "https://x.com/neurometax",
      instagram: "https://instagram.com/neurometax",
      youtube: "https://youtube.com/@neurometax",
      tiktok: "https://tiktok.com/@neurometax",
      threads: "https://threads.net/@neurometax",
      chirp: "https://chirp.me/neurometa",
    },
    achievements: [
      "Film3 Pioneer & Educator",
      "Host of FLINCH Case Study Documentary Course",
      "5+ Years in Web3 Cinema",
      "AI Ghostwriter & Translator",
      "1 AM EST Night Shift Commander",
      "Anti-Moloch System Designer",
    ],
    spaces: ["Film3 Innovation", "AI & Tech Talks", "Blockchain Cinema", "Web3 Education", "Cultural Decode Sessions"],
    projects: [
      {
        title: "RUPTURE: The FLINCH Story",
        description:
          "A seven act docudrama chronicling the creation and cultural impact of FLINCH, the groundbreaking NFT that ignited the Film3 revolution. Produced by CHAOS PRODUCTIONS.",
        link: "/rupture",
        type: "documentary",
      },
      {
        title: "FLINCH: The First NFT Film Franchise",
        description: "Comprehensive documentary course on Cameron Van Hoy's revolutionary Film3 project",
        link: "/film3/flinch-case-study",
        type: "course",
      },
    ],
    featureSection: {
      title: "NeuroMetaX — Decode the Hidden Layers",
      description:
        "Welcome to NeuroMetaX — where neural networks meet metaphysics, media, and memory. Here we investigate the stories beneath the headlines — from black ops and government surveillance to cultural resistance, psychedelia, music history, and modern consciousness shifts.",
      features: [
        "Deep-dive documentaries",
        "Mind-expanding interviews",
        "Cultural decode sessions",
        "Retro media breakdowns",
      ],
      tagline:
        "If you're tracing the Hippie-to-Hip Hop pipeline, decoding media propaganda, or questioning the nexus between art and intelligence systems, you're in the right place.",
    },
    antiMoloch:
      "Neuro's work through 789 Studios and Wired Chaos is guided by Anti-Moloch design: systems that reduce extractive gatekeeping and reward aligned, cooperative creative work across Web2 and Web3.",
    hasContent: true,
  },
  gator: {
    id: "gator",
    name: "GATOR",
    handle: "gatormetax",
    fullHandle: "GATOR | Game Master",
    doginalId: "DD#XXXX",
    time: "9 PM EST",
    specialty: "Gaming",
    role: "Host & GameFi Expert",
    avatar: "https://i.postimg.cc/5tk9Cq6L/10.png",
    primaryColor: "#00ff88",
    secondaryColor: "#00ffaa",
    glowColor: "rgba(0, 255, 136, 0.5)",
    tagline: "Web3 Gaming Authority + GameFi Expert · Bridging Traditional Gaming → Blockchain",
    bio: "GATOR dominates the gaming sector of Web3 at 9 PM EST daily. From GameFi to esports, GATOR brings competitive gaming culture to the blockchain generation. Known for hosting legendary gaming tournaments and discovering emerging play-to-earn projects.",
    socialLinks: {
      x: "https://x.com/gatormetax",
    },
    achievements: [
      "Web3 Gaming Authority",
      "GameFi Tournament Host",
      "9 PM EST Gaming Prime Time",
      "100+ Gaming Projects Covered",
      "789 Studios Gaming Division Lead",
    ],
    spaces: ["GameFi Deep Dives", "Esports & Blockchain", "P2E Strategy Sessions", "Gaming Community Raids"],
    projects: [],
    hasContent: false,
  },
  wooki: {
    id: "wooki",
    name: "WOOKI",
    handle: "wookimeta",
    fullHandle: "WOOKI | The Strategist",
    doginalId: "DD#XXXX",
    time: "8 PM EST",
    specialty: "Strategy",
    role: "Host & Strategy Director",
    avatar: "https://i.postimg.cc/g0BcZqnR/9.png",
    primaryColor: "#ff00ff",
    secondaryColor: "#9d00ff",
    glowColor: "rgba(255, 0, 255, 0.5)",
    tagline: "Web3 Strategic Analyst + Tokenomics Expert · Market Navigation Specialist",
    bio: "WOOKI is the master strategist of the 789 crew, bringing calculated insights to Web3 at 8 PM EST. Known for breaking down complex tokenomics, project analysis, and helping communities navigate market cycles with wisdom and clarity.",
    socialLinks: {
      x: "https://x.com/wookimeta",
    },
    achievements: [
      "Web3 Strategic Analyst",
      "Tokenomics Breakdown Expert",
      "8 PM EST Strategy Hour Host",
      "200+ Project Reviews",
      "789 Studios Strategy Director",
    ],
    spaces: ["Market Analysis", "Tokenomics Deep Dives", "Project Due Diligence", "Web3 Strategy Sessions"],
    projects: [],
    hasContent: false,
  },
  jeep: {
    id: "jeep",
    name: "JEEP",
    handle: "jeepmeta",
    fullHandle: "JEEP | Culture Curator",
    doginalId: "DD#XXXX",
    time: "1 PM EST",
    specialty: "Hip-Hop Culture",
    role: "Host & Culture Director",
    avatar: "https://i.postimg.cc/6Q16vLyp/5.png",
    primaryColor: "#ff6600",
    secondaryColor: "#ff0044",
    glowColor: "rgba(255, 102, 0, 0.5)",
    tagline: "Hip-Hop x Web3 Pioneer + Music NFT Advocate · Bridging Streets → Blockchain",
    bio: "JEEP brings authentic hip-hop culture to Web3 daily at 1 PM EST. Connecting the streets to the blockchain, JEEP showcases how music, art, and culture intersect with decentralization. A true bridge between traditional hip-hop and the metaverse.",
    socialLinks: {
      x: "https://x.com/jeepmeta",
    },
    achievements: [
      "Hip-Hop x Web3 Pioneer",
      "Music NFT Advocate",
      "1 PM EST Afternoon Drive Host",
      "50+ Artist Collaborations",
      "789 Studios Culture Director",
    ],
    spaces: ["Hip-Hop in Web3", "Music NFT Showcases", "Street Culture Meets Blockchain", "Artist Spotlights"],
    projects: [],
    hasContent: false,
  },
  artsy: {
    id: "artsy",
    name: "ARTSY",
    handle: "artsymeta",
    fullHandle: "ARTSY | Creative Visionary",
    doginalId: "DD#XXXX",
    time: "2 AM EST",
    specialty: "Creative Direction",
    role: "Host & Creative Director",
    avatar: "https://i.postimg.cc/Y9GrfGWf/16.png",
    primaryColor: "#ff00ff",
    secondaryColor: "#9d00ff",
    glowColor: "rgba(255, 0, 255, 0.5)",
    tagline: "Digital Art Director + NFT Art Curator · Web3 Creative Innovation",
    bio: "ARTSY transforms the late night into an art gallery at 2 AM EST. The creative visionary behind 789's aesthetic direction, ARTSY explores digital art, NFT collections, and the future of creative expression on the blockchain. Every space is a masterclass in Web3 art.",
    socialLinks: {
      x: "https://x.com/artsymeta",
    },
    achievements: [
      "Digital Art Director",
      "NFT Art Curator",
      "2 AM EST Late Night Creative Sessions",
      "100+ Artists Featured",
      "789 Studios Creative Director",
    ],
    spaces: ["NFT Art Reviews", "Digital Creation Techniques", "Web3 Artist Spotlights", "Creative Innovation Labs"],
    projects: [],
    hasContent: false,
  },
}

export function getAllCrewMembers(): CrewMember[] {
  return Object.values(CREW_MEMBERS)
}

export function getCrewMember(id: string): CrewMember | undefined {
  return CREW_MEMBERS[id]
}

export const STUDIO_SECTIONS = [
  { id: "hex-forge", name: "HEX Forge", icon: "⬡", description: "3D Tile Generator" },
  { id: "game-forge", name: "Game Forge", icon: "🎮", description: "Interactive Worlds" },
  { id: "radio-33", name: "33.3 FM", icon: "📻", description: "Audio Station" },
  { id: "npc-lab", name: "NPC Lab", icon: "🤖", description: "AI Characters" },
  { id: "creator-hub", name: "Creator Hub", icon: "✨", description: "Profile Studio" },
] as const
