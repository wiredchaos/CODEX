export interface SpaceHost {
  name: string
  handle: string
  time: string
  startHour: number
  endHour: number
  imageUrl: string
  xUrl: string
  bio: string
  showName?: string
  isFounder?: boolean
}

export const SPACES_SCHEDULE: SpaceHost[] = [
  {
    name: "EDGE",
    handle: "@edgemeta",
    time: "4 AM to 5 AM EST",
    startHour: 4,
    endHour: 5,
    imageUrl: "https://unavatar.io/twitter/edgemeta",
    xUrl: "https://x.com/edgemeta",
    bio: "Dawn patrol commander. Edge holds the line at the edge of night and day, delivering intel when most of the world is still dreaming. First voice of the network.",
  },
  {
    name: "TENGU",
    handle: "@TenguXL",
    time: "4 AM to 5 AM EST",
    startHour: 4,
    endHour: 5,
    imageUrl: "https://unavatar.io/twitter/TenguXL",
    xUrl: "https://x.com/TenguXL",
    bio: "Mystic markets oracle. Tengu brings ancient wisdom to modern chains, reading patterns in the chaos that others overlook. Co pilot of the dawn shift.",
  },
  {
    name: "LEAH",
    handle: "@leahbluewater",
    time: "6 AM to 7 AM EST",
    startHour: 6,
    endHour: 7,
    imageUrl: "https://unavatar.io/twitter/leahbluewater",
    xUrl: "https://x.com/leahbluewater",
    bio: "Blue water philosopher. Leah brings calm clarity to the chaos of crypto, weaving community wisdom with the patience of someone who plays the long game.",
  },
  {
    name: "VEE",
    handle: "@veemeta",
    time: "7 AM to 9 AM EST",
    startHour: 7,
    endHour: 9,
    imageUrl: "https://unavatar.io/twitter/veemeta",
    xUrl: "https://x.com/veemeta",
    bio: "Morning momentum builder. Vee bridges the early hours with market opening energy, setting the pace for the day with sharp analysis and community check ins.",
  },
  {
    name: "MOUSE",
    handle: "@Mousemeta",
    time: "9 AM to 10 AM EST",
    startHour: 9,
    endHour: 10,
    imageUrl: "https://unavatar.io/twitter/Mousemeta",
    xUrl: "https://x.com/Mousemeta",
    bio: "Small but mighty. Mouse moves through the network quietly collecting intel, then surfaces with precision calls that hit harder than the size suggests.",
  },
  {
    name: "WEB",
    handle: "@web3smb",
    time: "9 AM to 10 AM EST",
    startHour: 9,
    endHour: 10,
    imageUrl: "https://unavatar.io/twitter/web3smb",
    xUrl: "https://x.com/web3smb",
    bio: "Small business builder in the decentralized economy. Web connects traditional hustle with blockchain opportunity, bridging real world grind with digital futures.",
  },
  {
    name: "SHIBO",
    handle: "@godsburnt",
    time: "10 AM to 12 PM EST",
    startHour: 10,
    endHour: 12,
    imageUrl: "https://unavatar.io/twitter/godsburnt",
    xUrl: "https://x.com/godsburnt",
    bio: "Co-Founder of Crypto Spaces Network. SHIBO delivers raw unfiltered commentary on chain movements and cultural shifts. Host of The Crypto Show, speaking truth when the market needs to hear it.",
    showName: "The Crypto Show",
    isFounder: true,
  },
  {
    name: "ANT",
    handle: "@KingAnt",
    time: "12 PM to 2 PM EST",
    startHour: 12,
    endHour: 14,
    imageUrl: "https://unavatar.io/twitter/KingAnt",
    xUrl: "https://x.com/KingAnt",
    bio: "Colony commander. Ant builds with the strength of collective intelligence, organizing the midday swarm with leadership that lifts the entire network.",
  },
  {
    name: "DEFI",
    handle: "@lil_defi",
    time: "12 PM to 2 PM EST",
    startHour: 12,
    endHour: 14,
    imageUrl: "https://unavatar.io/twitter/lil_defi",
    xUrl: "https://x.com/lil_defi",
    bio: "Protocol whisperer. Defi speaks the language of smart contracts and yield strategies, translating complex mechanisms into actionable community knowledge.",
  },
  {
    name: "PAWS",
    handle: "@PawsMeta",
    time: "1 PM to 3 PM EST",
    startHour: 13,
    endHour: 15,
    imageUrl: "https://unavatar.io/twitter/PawsMeta",
    xUrl: "https://x.com/PawsMeta",
    bio: "Gentle giant of the feed. Paws carries the afternoon with warmth and consistency, creating space where newcomers feel welcome and veterans stay engaged.",
  },
  {
    name: "SHIELD",
    handle: "@Shieldmetax",
    time: "2 PM to 3 PM EST",
    startHour: 14,
    endHour: 15,
    imageUrl: "https://unavatar.io/twitter/Shieldmetax",
    xUrl: "https://x.com/Shieldmetax",
    bio: "The protector protocol. Shield brings defensive strategy and risk awareness, teaching the community how to guard their gains and survive the volatility.",
  },
  {
    name: "ORDER",
    handle: "@orderup",
    time: "3 PM to 5 PM EST",
    startHour: 15,
    endHour: 17,
    imageUrl: "https://unavatar.io/twitter/orderup",
    xUrl: "https://x.com/orderup",
    bio: "Structure in the chaos. Order brings method to the madness, organizing information flows and keeping the afternoon broadcast running with precision.",
  },
  {
    name: "HIGH",
    handle: "@Hightv",
    time: "4 PM to 5 PM EST",
    startHour: 16,
    endHour: 17,
    imageUrl: "https://unavatar.io/twitter/Hightv",
    xUrl: "https://x.com/Hightv",
    bio: "Elevation specialist. High lifts the energy as the workday winds down, transitioning the feed from afternoon grind to evening momentum with style.",
  },
  {
    name: "BARK",
    handle: "@barkmeta",
    time: "5 PM to 7 PM EST",
    startHour: 17,
    endHour: 19,
    imageUrl: "https://unavatar.io/twitter/barkmeta",
    xUrl: "https://x.com/barkmeta",
    bio: "Co-Founder of Crypto Spaces Network. Bark hosts State of Crypto, amplifying the signal when the noise gets thick, rallying the pack with energy that cuts through market fatigue.",
    showName: "State of Crypto",
    isFounder: true,
  },
  {
    name: "VIBES",
    handle: "@Vibesmetax",
    time: "7 PM to 8 PM EST",
    startHour: 19,
    endHour: 20,
    imageUrl: "https://unavatar.io/twitter/Vibesmetax",
    xUrl: "https://x.com/Vibesmetax",
    bio: "Frequency curator. Vibes sets the tone for the evening shift with chill commentary and culture checks, turning spaces into a vibe you want to stay in.",
  },
  {
    name: "0xG",
    handle: "@0x_TOPG",
    time: "7 PM to 9 PM EST",
    startHour: 19,
    endHour: 21,
    imageUrl: "https://unavatar.io/twitter/0x_TOPG",
    xUrl: "https://x.com/0x_TOPG",
    bio: "Top G of the timeline. 0xG commands the evening slot with authority, delivering takes that move markets and building culture that lasts beyond the hype.",
  },
  {
    name: "TALL",
    handle: "@tall_data",
    time: "8 PM to 10 PM EST",
    startHour: 20,
    endHour: 22,
    imageUrl: "https://unavatar.io/twitter/tall_data",
    xUrl: "https://x.com/tall_data",
    bio: "Data tower. Tall stands above the noise with analytics and on chain intelligence, breaking down complex metrics into community actionable insights.",
  },
  {
    name: "GATOR",
    handle: "@gatormetaX",
    time: "9 PM to 10 PM EST",
    startHour: 21,
    endHour: 22,
    imageUrl: "https://unavatar.io/twitter/gatormetaX",
    xUrl: "https://x.com/gatormetaX",
    bio: "Swamp strategist. Gator lurks in the liquidity pools and surfaces with insights from the deep end, snapping on narratives before they hit the surface.",
  },
  {
    name: "RUS",
    handle: "@RusMetaX",
    time: "9 PM to 10 PM EST",
    startHour: 21,
    endHour: 22,
    imageUrl: "https://unavatar.io/twitter/RusMetaX",
    xUrl: "https://x.com/RusMetaX",
    bio: "Eastern front analyst. Rus brings global perspective to the late evening, connecting markets across time zones with insight that spans continents.",
  },
  {
    name: "RIV",
    handle: "@RivAuraX",
    time: "10 PM to 11 PM EST",
    startHour: 22,
    endHour: 23,
    imageUrl: "https://unavatar.io/twitter/RivAuraX",
    xUrl: "https://x.com/RivAuraX",
    bio: "River of consciousness. Riv flows through the late night with smooth transitions and deep thoughts, carrying the community toward midnight with intention.",
  },
  {
    name: "DREAM",
    handle: "@DreamMetaX",
    time: "11 PM to 1 AM EST",
    startHour: 23,
    endHour: 1,
    imageUrl: "https://unavatar.io/twitter/DreamMetaX",
    xUrl: "https://x.com/DreamMetaX",
    bio: "Late night visionary. Dream holds space for those still awake chasing something bigger, mixing manifesting energy with real market psychology.",
  },
  {
    name: "LUIS",
    handle: "@luismetax",
    time: "12 AM to 1 AM EST",
    startHour: 0,
    endHour: 1,
    imageUrl: "https://unavatar.io/twitter/luismetax",
    xUrl: "https://x.com/luismetax",
    bio: "Midnight architect. Luis builds through the quietest hours, laying foundation when the timeline sleeps and opportunities emerge for those paying attention.",
  },
  {
    name: "LAMB",
    handle: "@LambMetaX",
    time: "1 AM to 3 AM EST",
    startHour: 1,
    endHour: 3,
    imageUrl: "https://unavatar.io/twitter/LambMetaX",
    xUrl: "https://x.com/LambMetaX",
    bio: "Gentle shepherd of the late shift. Lamb guides the overnight community with patience and care, keeping the flock together through the darkest hours.",
  },
]

export function getFounders(): SpaceHost[] {
  return SPACES_SCHEDULE.filter((host) => host.isFounder)
}

export function getCurrentHost(): SpaceHost | null {
  const now = new Date()
  const estTime = new Date(now.toLocaleString("en-US", { timeZone: "America/New_York" }))
  const currentHour = estTime.getHours()

  const activeHosts = SPACES_SCHEDULE.filter((host) => {
    if (host.endHour > host.startHour) {
      return currentHour >= host.startHour && currentHour < host.endHour
    } else {
      return currentHour >= host.startHour || currentHour < host.endHour
    }
  })

  return activeHosts[0] || null
}

export function getCurrentHosts(): SpaceHost[] {
  const now = new Date()
  const estTime = new Date(now.toLocaleString("en-US", { timeZone: "America/New_York" }))
  const currentHour = estTime.getHours()

  return SPACES_SCHEDULE.filter((host) => {
    if (host.endHour > host.startHour) {
      return currentHour >= host.startHour && currentHour < host.endHour
    } else {
      return currentHour >= host.startHour || currentHour < host.endHour
    }
  })
}

export const CRYPTO_SPACES_NETWORK = {
  name: "Crypto Spaces Network",
  tagline: "Doginal Dogs Creators Empowering Crypto Marketing",
  motto: "Alone you go fast, together we go far",
  services: [
    {
      id: 1,
      title: "Consultation & Advisory",
      tags: ["Web3 Strategy", "NFT Advisory", "Go To Market", "Blockchain Consulting", "Cryptocurrency Adoption"],
      description:
        "We guide projects from idea to execution. Whether you're launching a new protocol, NFT collection, or community initiative, our team provides strategic insight on positioning, branding, and go-to-market strategies.",
    },
    {
      id: 2,
      title: "Project Infrastructure",
      tags: ["Tokenomics", "Community Building", "Blockchain Infrastructure", "Tools", "Development", "Website"],
      description:
        "Every great project needs a solid foundation. We handle the technical and community setup so you can focus on building. From token design to community pipelines, we make sure your infrastructure is built to scale.",
    },
    {
      id: 3,
      title: "Art & Media Design",
      tags: ["NFT Collections", "Content Creation", "Branding", "Motion Graphics", "Graphic Design"],
      description:
        "Your visuals are your identity. Our creative team brings projects to life with full NFT collection design, branding packages, 3D animation, and promotional content that resonates with your community.",
    },
    {
      id: 4,
      title: "Press Release Campaigns",
      tags: ["Crypto PR", "SEO Optimization", "Marketing", "Community Building", "Strategy", "Growth"],
      description:
        "Get seen where it matters. We distribute your story across top-tier publications, tailored for both crypto-native and mainstream audiences with SEO and GEO optimization.",
    },
    {
      id: 5,
      title: "Reputational Consultations",
      tags: ["Trust Building", "Brand Awareness", "Brand Recognition", "Advising"],
      description:
        "Reputation is currency in crypto. We specialize in repairing online narratives, restoring trust, and ensuring your project is represented accurately across platforms.",
    },
  ],
  contactUrl: "https://forms.gle/sWkEMLLBc9bZVMH88",
  websiteUrl: "https://cryptospaces.net",
  xUrl: "https://x.com/CryptoSpacesNet",
}

export const DOGINAL_DOGS = {
  name: "Doginal Dogs",
  tagline: "10,000 pixel dogs digitally inscribed on Dogecoin",
  description: "In a world where everything feels disposable, we stand as proof that some things are meant to last.",
  links: {
    main: "https://doginaldogs.com",
    buy: "https://www.doginaldogs.com/how-to-buy-guide",
    community: "https://www.doginaldogs.com/join-the-community",
    docs: "https://www.doginaldogs.com/docs/doginal-docs",
    contentGenerator: "https://www.doginaldogs.com/content-generator",
    mediaLibrary: "https://www.doginaldogs.com/media-library",
  },
}

export const CSN_FOUNDERS = [
  {
    name: "BARK",
    fullName: "BARK META",
    handle: "@barkmeta",
    imageUrl: "https://unavatar.io/twitter/barkmeta",
    xUrl: "https://x.com/barkmeta",
    tagline: "#1 Alpha Caller",
    bio: "Co-Founder of Crypto Spaces Network. Host of State of Crypto. BARK amplifies the signal when the noise gets thick, rallying the pack with energy that cuts through market fatigue.",
    showName: "State of Crypto",
    showTime: "5 - 7 PM EST",
    role: "Co-Founder",
  },
  {
    name: "SHIBO",
    fullName: "GODSBURNT SHIBO",
    handle: "@godsburnt",
    imageUrl: "https://unavatar.io/twitter/godsburnt",
    xUrl: "https://x.com/godsburnt",
    tagline: "the CRACKED dev",
    bio: "Co-Founder of Crypto Spaces Network. Host of The Crypto Show. SHIBO delivers raw unfiltered commentary on chain movements and cultural shifts, speaking truth when the market needs to hear it.",
    showName: "The Crypto Show",
    showTime: "10 AM - 12 PM EST",
    role: "Co-Founder",
  },
]

export const CSN_PRINCIPALS = [
  {
    name: "SHIELD",
    fullName: "SHIELD META",
    handle: "@Shieldmetax",
    imageUrl: "https://unavatar.io/twitter/Shieldmetax",
    xUrl: "https://x.com/Shieldmetax",
    tagline: "GIGA VIP DD CFO",
    bio: "The protector protocol. Shield brings defensive strategy and risk awareness, teaching the community how to guard their gains and survive the volatility. GIGA VIP status for exceptional contributions to the network.",
    role: "GIGA VIP",
    badgeColor: "#00ffff", // cyan to differentiate from gold FOUNDER
  },
]

export const STUDIOS_789 = {
  name: "789 Studios",
  tagline: "Film3 Cinema. Blockchain Culture. Community Power.",
  description:
    "789 Studios is an independent Film3 production house operating as a distinct creative force. While we broadcast through the Crypto Spaces Network infrastructure, our mission is singular: decentralize cinema, empower creators, and build narrative systems that outlast the hype cycle.",
  websiteUrl: "https://789studios.xyz",
}

export interface Studios789Host {
  name: string
  handle: string
  imageUrl: string
  xUrl: string
  bio: string
  role: string
}

export const STUDIOS_789_TEAM: Studios789Host[] = [
  {
    name: "NEURO META X",
    handle: "@neurometax",
    imageUrl: "https://unavatar.io/twitter/neurometax",
    xUrl: "https://x.com/neurometax",
    bio: "789 Studios host, contributor, and NFT holder at producer and cast levels. A participant in the Film3 movement building alongside the community. NEURO brings the WIRED CHAOS perspective to decentralized cinema.",
    role: "Host & Contributor",
  },
]
