"use client"

import { cn } from "@/lib/utils"
import { GlassSurface } from "./glass-surface"
import { forwardRef, type HTMLAttributes } from "react"

export interface GlassNavDockProps extends HTMLAttributes<HTMLDivElement> {
  position?: "bottom" | "top" | "left" | "right"
  collapsed?: boolean
}

export const GlassNavDock = forwardRef<HTMLDivElement, GlassNavDockProps>(
  ({ children, className, position = "bottom", collapsed = false, ...props }, ref) => {
    const positionStyles = {
      bottom: "bottom-4 left-1/2 -translate-x-1/2 flex-row",
      top: "top-4 left-1/2 -translate-x-1/2 flex-row",
      left: "left-4 top-1/2 -translate-y-1/2 flex-col",
      right: "right-4 top-1/2 -translate-y-1/2 flex-col",
    }

    return (
      <GlassSurface
        ref={ref}
        blur="heavy"
        opacity="medium"
        border="accent"
        glow="subtle"
        className={cn(
          "fixed z-40 flex gap-2 p-2 transition-all duration-300",
          positionStyles[position],
          collapsed && "scale-90 opacity-80",
          className,
        )}
        {...props}
      >
        {children}
      </GlassSurface>
    )
  },
)
GlassNavDock.displayName = "GlassNavDock"
