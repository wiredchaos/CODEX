"use client"

import type React from "react"

import { cn } from "@/lib/utils"
import { GlassSurface, type GlassSurfaceProps } from "./glass-surface"
import { forwardRef } from "react"

export interface GlassPanelProps extends GlassSurfaceProps {
  header?: React.ReactNode
  footer?: React.ReactNode
  padding?: "none" | "sm" | "md" | "lg"
}

const paddingMap = {
  none: "",
  sm: "p-3",
  md: "p-4",
  lg: "p-6",
}

export const GlassPanel = forwardRef<HTMLDivElement, GlassPanelProps>(
  ({ children, header, footer, padding = "md", className, ...props }, ref) => {
    return (
      <GlassSurface ref={ref} className={cn("flex flex-col", className)} {...props}>
        {header && (
          <div className="px-4 py-3 border-b border-white/10 font-mono text-sm tracking-wider text-white/80">
            {header}
          </div>
        )}
        <div className={cn("flex-1", paddingMap[padding])}>{children}</div>
        {footer && <div className="px-4 py-3 border-t border-white/10">{footer}</div>}
      </GlassSurface>
    )
  },
)
GlassPanel.displayName = "GlassPanel"
