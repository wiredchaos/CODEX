"use client"

import { cn } from "@/lib/utils"
import { GLASS_TOKENS, type GlassBlur, type GlassOpacity, type GlassBorder, type GlassGlow } from "./glass-tokens"
import { forwardRef, type HTMLAttributes } from "react"

export interface GlassSurfaceProps extends HTMLAttributes<HTMLDivElement> {
  blur?: GlassBlur
  opacity?: GlassOpacity
  border?: GlassBorder
  glow?: GlassGlow
  accent?: "cyan" | "magenta" | "gold"
  interactive?: boolean
}

export const GlassSurface = forwardRef<HTMLDivElement, GlassSurfaceProps>(
  (
    {
      children,
      className,
      blur = "medium",
      opacity = "light",
      border = "light",
      glow = "none",
      accent = "cyan",
      interactive = false,
      ...props
    },
    ref,
  ) => {
    const accentColor = GLASS_TOKENS.colors[accent]

    return (
      <div
        ref={ref}
        className={cn(
          "relative rounded-xl overflow-hidden transition-all duration-300",
          interactive && "hover:scale-[1.02] cursor-pointer",
          className,
        )}
        style={{
          backdropFilter: `blur(${GLASS_TOKENS.blur[blur]})`,
          WebkitBackdropFilter: `blur(${GLASS_TOKENS.blur[blur]})`,
          backgroundColor: `rgba(10, 10, 15, ${GLASS_TOKENS.opacity[opacity]})`,
          border: GLASS_TOKENS.border[border],
          boxShadow: `${GLASS_TOKENS.glow[glow]}, ${GLASS_TOKENS.shadow.inset}`,
        }}
        {...props}
      >
        {/* Inner glow effect */}
        <div
          className="absolute inset-0 pointer-events-none opacity-30"
          style={{
            background: `radial-gradient(ellipse at top, ${accentColor.subtle}, transparent 70%)`,
          }}
        />
        <div className="relative z-10">{children}</div>
      </div>
    )
  },
)
GlassSurface.displayName = "GlassSurface"
