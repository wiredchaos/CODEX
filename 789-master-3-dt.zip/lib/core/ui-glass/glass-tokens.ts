// Glass UI Design Tokens - System-wide frosted/liquid-glass morphism
export const GLASS_TOKENS = {
  // Blur intensities
  blur: {
    none: "0px",
    subtle: "4px",
    light: "8px",
    medium: "12px",
    heavy: "20px",
    extreme: "32px",
  },

  // Background opacity levels
  opacity: {
    transparent: "0",
    whisper: "0.03",
    subtle: "0.05",
    light: "0.08",
    medium: "0.12",
    heavy: "0.18",
    solid: "0.25",
  },

  // Border styles
  border: {
    none: "none",
    subtle: "1px solid rgba(255, 255, 255, 0.05)",
    light: "1px solid rgba(255, 255, 255, 0.1)",
    medium: "1px solid rgba(255, 255, 255, 0.15)",
    accent: "1px solid rgba(0, 255, 255, 0.2)",
    glow: "1px solid rgba(0, 255, 255, 0.4)",
  },

  // Glow effects
  glow: {
    none: "none",
    subtle: "0 0 20px rgba(0, 255, 255, 0.1)",
    medium: "0 0 30px rgba(0, 255, 255, 0.15)",
    strong: "0 0 40px rgba(0, 255, 255, 0.2)",
    accent: "0 0 50px rgba(0, 255, 255, 0.3)",
  },

  // Shadows
  shadow: {
    none: "none",
    subtle: "0 4px 6px rgba(0, 0, 0, 0.1)",
    medium: "0 8px 16px rgba(0, 0, 0, 0.2)",
    heavy: "0 16px 32px rgba(0, 0, 0, 0.3)",
    inset: "inset 0 1px 0 rgba(255, 255, 255, 0.05)",
  },

  // Colors
  colors: {
    cyan: {
      primary: "#00ffff",
      glow: "rgba(0, 255, 255, 0.3)",
      subtle: "rgba(0, 255, 255, 0.1)",
    },
    magenta: {
      primary: "#ff00ff",
      glow: "rgba(255, 0, 255, 0.3)",
      subtle: "rgba(255, 0, 255, 0.1)",
    },
    gold: {
      primary: "#ffd700",
      glow: "rgba(255, 215, 0, 0.3)",
      subtle: "rgba(255, 215, 0, 0.1)",
    },
  },
} as const

export type GlassBlur = keyof typeof GLASS_TOKENS.blur
export type GlassOpacity = keyof typeof GLASS_TOKENS.opacity
export type GlassBorder = keyof typeof GLASS_TOKENS.border
export type GlassGlow = keyof typeof GLASS_TOKENS.glow
