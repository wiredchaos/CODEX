"use client"

import { useElevator } from "./elevator-provider"
import { GlassSurface } from "../ui-glass/glass-surface"
import { Home, Upload, Film, Mic, Radio, Tv, Users, Coins, Lock, type LucideIcon } from "lucide-react"

const iconMap: Record<string, LucideIcon> = {
  Home,
  Upload,
  Film,
  Mic,
  Radio,
  Tv,
  Users,
  Coins,
}

export function ElevatorButtons() {
  const { floors, currentFloor, targetFloor, selectFloor, travelToFloor } = useElevator()

  return (
    <div className="grid grid-cols-2 gap-3">
      {floors.map((floor) => {
        const Icon = iconMap[floor.icon] || Home
        const isCurrent = currentFloor === floor.id
        const isSelected = targetFloor === floor.id
        const isLocked = floor.roleGate && floor.roleGate.length > 0 && floor.id !== "ott789:entry"

        return (
          <button
            key={floor.id}
            onClick={() => {
              if (isLocked) return
              if (isSelected) {
                travelToFloor(floor.id)
              } else {
                selectFloor(floor.id)
              }
            }}
            disabled={isLocked}
            className="relative group"
          >
            <GlassSurface
              blur="light"
              opacity={isSelected ? "heavy" : "subtle"}
              border={isSelected ? "glow" : isCurrent ? "accent" : "light"}
              glow={isSelected ? "medium" : "none"}
              className={`p-4 transition-all ${isLocked ? "opacity-50 cursor-not-allowed" : "cursor-pointer hover:scale-[1.02]"}`}
            >
              <div className="flex items-center gap-3">
                <div
                  className="w-10 h-10 rounded-lg flex items-center justify-center"
                  style={{
                    backgroundColor: `${floor.color}20`,
                    boxShadow: isSelected ? `0 0 20px ${floor.color}40` : "none",
                  }}
                >
                  {isLocked ? (
                    <Lock className="w-5 h-5 text-white/40" />
                  ) : (
                    <Icon className="w-5 h-5" style={{ color: floor.color }} />
                  )}
                </div>
                <div className="text-left">
                  <p className="font-sans text-sm font-medium text-white">{floor.name}</p>
                  <p className="font-mono text-xs text-white/40">
                    {isCurrent ? "Current" : isSelected ? "Tap to go" : floor.path}
                  </p>
                </div>
              </div>

              {/* Current floor indicator */}
              {isCurrent && (
                <div
                  className="absolute top-2 right-2 w-2 h-2 rounded-full animate-pulse"
                  style={{ backgroundColor: floor.color }}
                />
              )}
            </GlassSurface>
          </button>
        )
      })}
    </div>
  )
}
