"use client"

import { useElevator } from "./elevator-provider"
import { ElevatorButtons } from "./elevator-buttons"
import { GlassSurface } from "../ui-glass/glass-surface"
import { X, ArrowUp, Loader2 } from "lucide-react"
import { Elevator3DVectors } from "@/components/elevator-3d-vectors"

export function ElevatorOverlay() {
  const { isOpen, state, closeElevator, currentFloor, targetFloor, getFloorById } = useElevator()

  if (!isOpen) return null

  const current = currentFloor ? getFloorById(currentFloor) : null
  const target = targetFloor ? getFloorById(targetFloor) : null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-md"
        onClick={state === "selecting" ? closeElevator : undefined}
      />

      <Elevator3DVectors />

      {/* Elevator Panel */}
      <GlassSurface blur="extreme" opacity="heavy" border="glow" glow="accent" className="relative w-full max-w-lg">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-500/20 to-cyan-500/5 flex items-center justify-center">
              <ArrowUp className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <h2 className="font-sans text-lg font-semibold text-white">789 Elevator</h2>
              <p className="font-mono text-xs text-white/50">
                {state === "traveling" ? "TRAVELING..." : state === "arrived" ? "ARRIVED" : "SELECT FLOOR"}
              </p>
            </div>
          </div>
          {state === "selecting" && (
            <button
              onClick={closeElevator}
              className="p-2 rounded-lg hover:bg-white/10 transition-colors text-white/60 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Floor Indicator */}
        <div className="p-4 border-b border-white/10 bg-black/20">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-mono text-xs text-white/40 uppercase tracking-wider">Current Floor</p>
              <p className="font-sans text-white">{current?.name || "Lobby"}</p>
            </div>
            {state === "traveling" && (
              <div className="flex items-center gap-2 text-cyan-400">
                <Loader2 className="w-5 h-5 animate-spin" />
                <span className="font-mono text-sm">En route to {target?.name}</span>
              </div>
            )}
          </div>
        </div>

        {/* Floor Buttons */}
        <div className="p-4 max-h-[60vh] overflow-y-auto">
          {state === "traveling" ? (
            <div className="flex flex-col items-center justify-center py-12">
              <div className="relative w-24 h-24">
                <div className="absolute inset-0 rounded-full border-2 border-cyan-500/30 animate-ping" />
                <div className="absolute inset-2 rounded-full border-2 border-cyan-500/50 animate-pulse" />
                <div className="absolute inset-4 rounded-full bg-gradient-to-br from-cyan-500/20 to-transparent flex items-center justify-center">
                  <ArrowUp className="w-8 h-8 text-cyan-400 animate-bounce" />
                </div>
              </div>
              <p className="mt-4 font-mono text-sm text-white/60">Traveling to {target?.name}...</p>
            </div>
          ) : (
            <ElevatorButtons />
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-white/10 bg-black/20">
          <p className="font-mono text-xs text-center text-white/30">Press ESC or click outside to close</p>
        </div>
      </GlassSurface>
    </div>
  )
}
