"use client"

import { createContext, useContext, useState, useCallback, type ReactNode } from "react"
import { FLOOR_REGISTRY, type FloorMetadata } from "@/lib/trinity/logic"
import { useTrinity } from "../trinity-3d/trinity-provider"
import { useRouter } from "next/navigation"

export type ElevatorState = "idle" | "selecting" | "traveling" | "arrived"

export interface ElevatorContextValue {
  state: ElevatorState
  isOpen: boolean
  currentFloor: string | null
  targetFloor: string | null
  floors: FloorMetadata[]
  openElevator: () => void
  closeElevator: () => void
  selectFloor: (floorId: string) => void
  travelToFloor: (floorId: string) => Promise<void>
  getFloorById: (id: string) => FloorMetadata | undefined
}

const ElevatorContext = createContext<ElevatorContextValue | null>(null)

export function ElevatorProvider({ children }: { children: ReactNode }) {
  const router = useRouter()
  const trinity = useTrinity()
  const [state, setState] = useState<ElevatorState>("idle")
  const [isOpen, setIsOpen] = useState(false)
  const [currentFloor, setCurrentFloor] = useState<string | null>("home")
  const [targetFloor, setTargetFloor] = useState<string | null>(null)

  const floors = FLOOR_REGISTRY

  const openElevator = useCallback(() => {
    setIsOpen(true)
    setState("selecting")
  }, [])

  const closeElevator = useCallback(() => {
    setIsOpen(false)
    setState("idle")
    setTargetFloor(null)
  }, [])

  const selectFloor = useCallback((floorId: string) => {
    setTargetFloor(floorId)
  }, [])

  const travelToFloor = useCallback(
    async (floorId: string) => {
      const floor = floors.find((f) => f.id === floorId)
      if (!floor) return

      setState("traveling")
      trinity.setTraveling(true)
      trinity.setDestinationFloor(floorId)

      // Travel animation duration
      await new Promise((resolve) => setTimeout(resolve, trinity.reducedMotion ? 500 : 1500))

      trinity.setTraveling(false)
      setState("arrived")
      setCurrentFloor(floorId)

      // Navigate to the floor
      router.push(floor.path)

      // Reset after arrival
      setTimeout(() => {
        closeElevator()
      }, 500)
    },
    [floors, trinity, router, closeElevator],
  )

  const getFloorById = useCallback(
    (id: string) => {
      return floors.find((f) => f.id === id)
    },
    [floors],
  )

  return (
    <ElevatorContext.Provider
      value={{
        state,
        isOpen,
        currentFloor,
        targetFloor,
        floors,
        openElevator,
        closeElevator,
        selectFloor,
        travelToFloor,
        getFloorById,
      }}
    >
      {children}
    </ElevatorContext.Provider>
  )
}

export function useElevator() {
  const context = useContext(ElevatorContext)
  if (!context) {
    throw new Error("useElevator must be used within ElevatorProvider")
  }
  return context
}
