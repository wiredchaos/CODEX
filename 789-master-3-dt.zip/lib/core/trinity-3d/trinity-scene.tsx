"use client"

import { useRef, useEffect, useState } from "react"
import { useTrinity } from "./trinity-provider"

// CSS-based 3D background scene (no Three.js dependency for performance)
export function TrinityScene() {
  const { enabled, realm, reducedMotion, traveling, destinationFloor } = useTrinity()
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [mounted, setMounted] = useState(false)
  const animationRef = useRef<number>()

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (!enabled || !mounted || !canvasRef.current) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const resize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }
    resize()
    window.addEventListener("resize", resize)

    // Particle system
    const particles: Array<{
      x: number
      y: number
      z: number
      vx: number
      vy: number
      size: number
      alpha: number
    }> = []

    const particleCount = reducedMotion ? 30 : 80

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        z: Math.random() * 1000,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        size: Math.random() * 2 + 1,
        alpha: Math.random() * 0.5 + 0.2,
      })
    }

    let time = 0
    const speed = reducedMotion ? 0.002 : 0.005

    const getRealmColors = () => {
      switch (realm) {
        case "akashic":
          return { primary: "#ff00ff", secondary: "#9d00ff" }
        case "split":
          return { primary: "#00ffff", secondary: "#ff00ff" }
        default:
          return { primary: "#00ffff", secondary: "#0088ff" }
      }
    }

    const animate = () => {
      time += speed
      const colors = getRealmColors()

      // Clear with fade
      ctx.fillStyle = "rgba(10, 10, 15, 0.1)"
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Draw particles
      particles.forEach((p) => {
        // Update position
        p.x += p.vx + (traveling ? 2 : 0)
        p.y += p.vy
        p.z -= traveling ? 10 : 1

        // Wrap around
        if (p.x < 0) p.x = canvas.width
        if (p.x > canvas.width) p.x = 0
        if (p.y < 0) p.y = canvas.height
        if (p.y > canvas.height) p.y = 0
        if (p.z < 0) p.z = 1000

        // Calculate perspective
        const scale = 1000 / (1000 + p.z)
        const screenX = canvas.width / 2 + (p.x - canvas.width / 2) * scale
        const screenY = canvas.height / 2 + (p.y - canvas.height / 2) * scale
        const screenSize = p.size * scale

        // Draw particle
        ctx.beginPath()
        ctx.arc(screenX, screenY, screenSize, 0, Math.PI * 2)
        ctx.fillStyle = `${colors.primary}${Math.floor(p.alpha * 255)
          .toString(16)
          .padStart(2, "0")}`
        ctx.fill()

        // Draw glow
        const gradient = ctx.createRadialGradient(screenX, screenY, 0, screenX, screenY, screenSize * 3)
        gradient.addColorStop(0, `${colors.primary}20`)
        gradient.addColorStop(1, "transparent")
        ctx.beginPath()
        ctx.arc(screenX, screenY, screenSize * 3, 0, Math.PI * 2)
        ctx.fillStyle = gradient
        ctx.fill()
      })

      // Draw grid lines
      ctx.strokeStyle = `${colors.secondary}10`
      ctx.lineWidth = 1
      const gridSize = 100
      const offsetX = (time * 50) % gridSize

      for (let x = -gridSize + offsetX; x < canvas.width + gridSize; x += gridSize) {
        ctx.beginPath()
        ctx.moveTo(x, 0)
        ctx.lineTo(x, canvas.height)
        ctx.stroke()
      }

      // Central glow
      const centerGradient = ctx.createRadialGradient(
        canvas.width / 2,
        canvas.height / 2,
        0,
        canvas.width / 2,
        canvas.height / 2,
        canvas.width / 2,
      )
      centerGradient.addColorStop(0, `${colors.primary}08`)
      centerGradient.addColorStop(0.5, `${colors.secondary}04`)
      centerGradient.addColorStop(1, "transparent")
      ctx.fillStyle = centerGradient
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      animationRef.current = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener("resize", resize)
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [enabled, mounted, realm, reducedMotion, traveling])

  if (!enabled || !mounted) return null

  return <canvas ref={canvasRef} className="fixed inset-0 z-0 pointer-events-none" style={{ opacity: 0.6 }} />
}
