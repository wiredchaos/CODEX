"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

export type TrinityRealm = "business" | "akashic" | "split"
export type TrinityQuality = "auto" | "low" | "medium" | "high"

export interface TrinityContextValue {
  enabled: boolean
  setEnabled: (enabled: boolean) => void
  realm: TrinityRealm
  setRealm: (realm: TrinityRealm) => void
  quality: TrinityQuality
  setQuality: (quality: TrinityQuality) => void
  reducedMotion: boolean
  traveling: boolean
  setTraveling: (traveling: boolean) => void
  destinationFloor: string | null
  setDestinationFloor: (floor: string | null) => void
}

const TrinityContext = createContext<TrinityContextValue | null>(null)

export function TrinityProvider({ children }: { children: ReactNode }) {
  const [enabled, setEnabled] = useState(true)
  const [realm, setRealm] = useState<TrinityRealm>("business")
  const [quality, setQuality] = useState<TrinityQuality>("auto")
  const [reducedMotion, setReducedMotion] = useState(false)
  const [traveling, setTraveling] = useState(false)
  const [destinationFloor, setDestinationFloor] = useState<string | null>(null)

  // Detect reduced motion preference
  useEffect(() => {
    const mediaQuery = window.matchMedia("(prefers-reduced-motion: reduce)")
    setReducedMotion(mediaQuery.matches)

    const handler = (e: MediaQueryListEvent) => setReducedMotion(e.matches)
    mediaQuery.addEventListener("change", handler)
    return () => mediaQuery.removeEventListener("change", handler)
  }, [])

  // Auto quality detection based on device
  useEffect(() => {
    if (quality === "auto") {
      const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent)
      const isLowPower = navigator.hardwareConcurrency <= 4
      if (isMobile || isLowPower) {
        // Will render at lower quality
      }
    }
  }, [quality])

  return (
    <TrinityContext.Provider
      value={{
        enabled,
        setEnabled,
        realm,
        setRealm,
        quality,
        setQuality,
        reducedMotion,
        traveling,
        setTraveling,
        destinationFloor,
        setDestinationFloor,
      }}
    >
      {children}
    </TrinityContext.Provider>
  )
}

export function useTrinity() {
  const context = useContext(TrinityContext)
  if (!context) {
    throw new Error("useTrinity must be used within TrinityProvider")
  }
  return context
}
