// Lurky Campaign Crawler
// Crawls 789 Studios app for campaigns and generates promo data

import { OTT_SHOWS, OTT_CHANNELS } from "@/data/ott-content"
import { SPACES_SCHEDULE, CRYPTO_SPACES_NETWORK } from "@/lib/spaces-schedule"

export interface Campaign {
  id: string
  type: "show" | "space" | "ally" | "event" | "nft" | "documentary"
  title: string
  subtitle?: string
  description: string
  image?: string
  tags: string[]
  ctaText: string
  ctaLink: string
  priority: "featured" | "high" | "normal"
  creator?: string
  network?: string
  launchDate?: string
  metrics?: {
    views?: number
    engagement?: number
    mentions?: number
  }
}

export interface PromoCard {
  campaign: Campaign
  promoText: string
  hashtags: string[]
  mediaUrl?: string
  scheduleTime?: Date
}

// Allies data for campaign generation
const ALLIES_DATA = [
  {
    id: "type-media",
    name: "TYPE Media",
    tagline: "The engine behind a growing movement of creators, culture, and innovation",
    website: "https://typebrand.xyz",
    x: "https://x.com/typemedia",
  },
  {
    id: "beanies-on-business",
    name: "Beanies on Business",
    tagline: "A community of builders, creators, and innovators",
    website: "https://beaniesonbusiness.com",
    x: "https://x.com/BeanieDaoX",
  },
  {
    id: "bowmafia",
    name: "BowMafia DAO",
    tagline: "BowMafiaDAO, a community powered Doginal Dogs collective",
    website: "https://bowmafia.xyz",
    x: "https://x.com/BowDAOMeta",
  },
  {
    id: "dogwarts",
    name: "Dogwarts DAO",
    tagline: "Where paws meet potions and tails wag through magic and mischief",
    website: "https://dogwartsdao.com",
  },
  {
    id: "otf-media",
    name: "OTF Media",
    tagline: "Building culture, loyalty, and legacy across all communities",
    x: "https://x.com/OTFMediaX",
  },
  {
    id: "yellow-dao",
    name: "Yellow DAO",
    tagline: "Discover the yellow revolution. Not your regular DAO",
    website: "https://yellowdao.xyz",
  },
  {
    id: "kennel-dao",
    name: "KennelDAO",
    tagline: "Creating a revenue generating DAO in the Doginal Dogs ecosystem",
    website: "https://kennel.market",
    x: "https://x.com/KennelDAO",
  },
]

export function crawlCampaigns(): Campaign[] {
  const campaigns: Campaign[] = []

  // Crawl OTT Shows
  OTT_SHOWS.forEach((show) => {
    const channel = OTT_CHANNELS.find((c) => c.id === show.channelId)
    campaigns.push({
      id: `show-${show.id}`,
      type: show.id.includes("rupture") ? "documentary" : "show",
      title: show.title,
      subtitle: channel?.name,
      description: show.description,
      image: show.heroArt,
      tags: show.tags,
      ctaText: "Watch Now",
      ctaLink: `/${show.slug}`,
      priority: show.id === "rupture-documentary" ? "featured" : "high",
      creator: show.creator,
      network: "789 Studios OTT",
    })
  })

  // Crawl Allies
  ALLIES_DATA.forEach((ally) => {
    campaigns.push({
      id: `ally-${ally.id}`,
      type: "ally",
      title: ally.name,
      description: ally.tagline,
      tags: ["DAO", "Web3", "Community"],
      ctaText: "Join Alliance",
      ctaLink: ally.website || ally.x || "/allies",
      priority: "normal",
      network: "789 Network",
    })
  })

  // Crawl Space Hosts as mini campaigns
  SPACES_SCHEDULE.slice(0, 5).forEach((host) => {
    campaigns.push({
      id: `space-${host.name.toLowerCase()}`,
      type: "space",
      title: `${host.name} Live`,
      subtitle: host.showName || "Crypto Spaces Network",
      description: host.bio,
      image: host.imageUrl,
      tags: ["Spaces", "Crypto", "CSN"],
      ctaText: "Tune In",
      ctaLink: host.xUrl,
      priority: "normal",
      creator: host.name,
      network: "CSN",
    })
  })

  // Crawl CSN Services as event campaigns
  CRYPTO_SPACES_NETWORK.services.forEach((service, index) => {
    campaigns.push({
      id: `service-${index}`,
      type: "event",
      title: service.title,
      description: `Professional ${service.title.toLowerCase()} services powered by Crypto Spaces Network`,
      tags: service.tags,
      ctaText: "Learn More",
      ctaLink: CRYPTO_SPACES_NETWORK.websiteUrl,
      priority: "normal",
      network: "CSN",
    })
  })

  return campaigns
}

export function generatePromoCard(campaign: Campaign): PromoCard {
  const hashtags = generateHashtags(campaign)
  const promoText = generatePromoText(campaign)

  return {
    campaign,
    promoText,
    hashtags,
  }
}

function generateHashtags(campaign: Campaign): string[] {
  const baseHashtags = ["#789Studios", "#Web3"]

  switch (campaign.type) {
    case "documentary":
      return [...baseHashtags, "#Film3", "#RUPTURE", "#Docudrama", "#NFTCinema"]
    case "show":
      return [...baseHashtags, "#OTT", "#Streaming", "#Web3Content"]
    case "space":
      return [...baseHashtags, "#CryptoSpaces", "#XSpaces", "#CSN"]
    case "ally":
      return [...baseHashtags, "#DAO", "#Community", "#DoginalDogs"]
    case "event":
      return [...baseHashtags, "#CryptoMarketing", "#Web3Services"]
    default:
      return baseHashtags
  }
}

function generatePromoText(campaign: Campaign): string {
  const templates = {
    documentary: `SIGNAL DETECTED: ${campaign.title}\n\n${campaign.description}\n\nStream now on 789 Studios OTT`,
    show: `NOW STREAMING: ${campaign.title}\n\n${campaign.description}\n\nWatch on 789 Studios`,
    space: `LIVE ON AIR: ${campaign.title}\n\n${campaign.description}\n\nJoin the conversation`,
    ally: `ALLIANCE SPOTLIGHT: ${campaign.title}\n\n${campaign.description}\n\nPart of the 789 Network`,
    event: `SERVICE ALERT: ${campaign.title}\n\n${campaign.description}\n\nPowered by CSN`,
    nft: `NFT DROP: ${campaign.title}\n\n${campaign.description}\n\nMint on 789 Studios`,
  }

  return templates[campaign.type] || `${campaign.title}\n\n${campaign.description}`
}

export function getFeaturedCampaigns(): Campaign[] {
  return crawlCampaigns().filter((c) => c.priority === "featured" || c.priority === "high")
}

export function getCampaignsByType(type: Campaign["type"]): Campaign[] {
  return crawlCampaigns().filter((c) => c.type === type)
}

export function getCampaignById(id: string): Campaign | undefined {
  return crawlCampaigns().find((c) => c.id === id)
}
