export interface SetTemplate {
  id: string
  name: string
  description: string
  promptTemplate: string
  previewImage: string
  category: "audio" | "video" | "broadcast"
}

export const SET_TEMPLATES: SetTemplate[] = [
  {
    id: "podcast",
    name: "Podcast Studio",
    description: "Professional podcast recording environment with acoustic treatment and broadcast-quality equipment",
    promptTemplate: `Create a cinematic podcast studio set with:
- Warm, professional lighting with practical desk lamps
- Acoustic foam panels on walls in a tasteful pattern
- Professional broadcast microphones on boom arms
- Comfortable seating with ergonomic desk setup
- Background shelving with books and tech equipment
- Subtle neon accent lighting in 789 Studios orange
- Modern, minimalist aesthetic
- Depth of field with bokeh effect
- Color grading: warm tones with cyan highlights`,
    previewImage: "/sets/podcast-studio.jpg",
    category: "audio",
  },
  {
    id: "recording_booth",
    name: "Recording Booth",
    description: "Intimate vocal recording booth with professional sound isolation",
    promptTemplate: `Create a cinematic recording booth set with:
- Compact, intimate space with professional sound dampening
- Vintage-style ribbon microphone as centerpiece
- Warm indirect lighting from hidden LED strips
- Textured acoustic panels with geometric patterns
- Small monitor displaying waveforms
- Pop filter and shock mount visible
- Shallow depth of field focusing on mic
- Color grading: moody with warm highlights
- Cinematic noir aesthetic`,
    previewImage: "/sets/recording-booth.jpg",
    category: "audio",
  },
  {
    id: "newsroom",
    name: "Newsroom Set",
    description: "Modern broadcast newsroom with multiple screens and professional lighting",
    promptTemplate: `Create a cinematic newsroom broadcast set with:
- Large curved video wall displaying crypto charts and news tickers
- Professional anchor desk with integrated monitors
- Cool blue and cyan lighting scheme
- Multiple camera angles suggested by lighting setup
- Professional broadcast monitors showing live feeds
- Modern, high-tech aesthetic
- Dynamic lighting with practical screen glow
- Clean, corporate environment with 789 Studios branding
- Color grading: cool tones with high contrast`,
    previewImage: "/sets/newsroom.jpg",
    category: "broadcast",
  },
  {
    id: "film_set",
    name: "Film Set (Generic)",
    description: "Versatile cinematic environment suitable for narrative content",
    promptTemplate: `Create a cinematic film set with:
- Dramatic three-point lighting setup
- Flexible background with adjustable lighting
- Professional cinema camera on tripod visible in frame
- Director's monitor showing composition
- Practical lights creating depth and atmosphere
- Film noir aesthetic with venetian blind shadows
- Smoke/haze for atmospheric depth
- Color grading: cinematic with lifted blacks
- 2.39:1 aspect ratio composition
- Moody, dramatic atmosphere suitable for storytelling`,
    previewImage: "/sets/film-set.jpg",
    category: "video",
  },
]

export function getTemplateById(id: string): SetTemplate | undefined {
  return SET_TEMPLATES.find((t) => t.id === id)
}

export function getTemplatesByCategory(category: SetTemplate["category"]): SetTemplate[] {
  return SET_TEMPLATES.filter((t) => t.category === category)
}
