export type TourState = "idle" | "intake" | "planning" | "traveling" | "exploring" | "paused" | "completed"

export type TourEvent =
  | { type: "START_TOUR" }
  | { type: "SUBMIT_INTAKE"; payload: any }
  | { type: "CONFIRM_PLAN" }
  | { type: "MOVE_TO_FLOOR"; floorId: string }
  | { type: "CONTINUE_TOUR" }
  | { type: "PAUSE_TOUR" }
  | { type: "SKIP_TOUR" }
  | { type: "END_TOUR" }
  | { type: "PANIC_EXIT" }

export interface TourContext {
  state: TourState
  currentFloor: string | null
  floorQueue: string[]
  visitedFloors: string[]
  intakeData: any | null
}

export class TourStateMachine {
  private context: TourContext

  constructor() {
    this.context = {
      state: "idle",
      currentFloor: null,
      floorQueue: [],
      visitedFloors: [],
      intakeData: null,
    }
  }

  getContext(): TourContext {
    return { ...this.context }
  }

  dispatch(event: TourEvent): TourContext {
    switch (event.type) {
      case "START_TOUR":
        this.context.state = "intake"
        break

      case "SUBMIT_INTAKE":
        this.context.state = "planning"
        this.context.intakeData = event.payload
        break

      case "CONFIRM_PLAN":
        this.context.state = "traveling"
        break

      case "MOVE_TO_FLOOR":
        this.context.state = "exploring"
        this.context.currentFloor = event.floorId
        if (!this.context.visitedFloors.includes(event.floorId)) {
          this.context.visitedFloors.push(event.floorId)
        }
        break

      case "CONTINUE_TOUR":
        this.context.state = "traveling"
        this.context.currentFloor = null
        break

      case "PAUSE_TOUR":
        this.context.state = "paused"
        break

      case "SKIP_TOUR":
        this.context.state = "idle"
        this.context.currentFloor = "elevator"
        break

      case "END_TOUR":
        this.context.state = "completed"
        break

      case "PANIC_EXIT":
        this.context.state = "idle"
        this.context.currentFloor = "lobby"
        break
    }

    return this.getContext()
  }

  canSkip(): boolean {
    return ["intake", "planning", "traveling", "exploring"].includes(this.context.state)
  }

  canPause(): boolean {
    return this.context.state === "exploring"
  }
}
