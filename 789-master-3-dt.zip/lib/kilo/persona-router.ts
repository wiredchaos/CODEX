import { FLOOR_REGISTRY } from "@/lib/trinity/logic"

export interface FloorPersona {
  id: string
  name: string
  role: string
  greeting: string
  color: string
  voiceTone: "professional" | "casual" | "technical" | "friendly"
}

export const FLOOR_PERSONAS: Record<string, FloorPersona> = {
  "neuro-concierge": {
    id: "neuro-concierge",
    name: "NEURO Concierge",
    role: "Main Guide",
    greeting: "Welcome to 789 Studios. I'm here to guide you.",
    color: "#00ffff",
    voiceTone: "friendly",
  },
  "neuro-creator": {
    id: "neuro-creator",
    name: "NEURO Creator",
    role: "Creator Hub Guide",
    greeting: "This is the Creator Hub. Let me show you how to publish everywhere at once.",
    color: "#00ffff",
    voiceTone: "professional",
  },
  "neuro-film3": {
    id: "neuro-film3",
    name: "NEURO Film3",
    role: "Film3 Specialist",
    greeting: "Welcome to Film3. This is where cinema meets decentralization.",
    color: "#daa520",
    voiceTone: "technical",
  },
  "neuro-studios": {
    id: "neuro-studios",
    name: "NEURO Studios",
    role: "Recording Studios Manager",
    greeting: "Ready to book studio time? Let me walk you through our packages.",
    color: "#ffd700",
    voiceTone: "professional",
  },
  "neuro-spaces": {
    id: "neuro-spaces",
    name: "NEURO Spaces",
    role: "Spaces Network Host",
    greeting: "This is the Crypto Spaces Network. 24/7 live conversations.",
    color: "#00ffff",
    voiceTone: "casual",
  },
  "neuro-ott": {
    id: "neuro-ott",
    name: "NEURO OTT",
    role: "Content Curator",
    greeting: "Browse our library of Film3 content and Web3 storytelling.",
    color: "#ff00ff",
    voiceTone: "friendly",
  },
  "neuro-community": {
    id: "neuro-community",
    name: "NEURO Community",
    role: "Community Manager",
    greeting: "Welcome to the Lounge. Connect, play, and collaborate here.",
    color: "#9d00ff",
    voiceTone: "casual",
  },
  "neuro-blockchain": {
    id: "neuro-blockchain",
    name: "NEURO Blockchain",
    role: "NFT Specialist",
    greeting: "Let's mint your content on-chain with smart contract royalties.",
    color: "#00ff88",
    voiceTone: "technical",
  },
  "neuro-uplink": {
    id: "neuro-uplink",
    name: "NEURO UPLINK",
    role: "OTT Entry Guide",
    greeting: "Welcome to 789 Studios OTT. I'm NEURO UPLINK, your gateway to Film3 content and creator tools.",
    color: "#ff00ff",
    voiceTone: "professional",
  },
}

export class PersonaRouter {
  getPersona(floorId: string): FloorPersona {
    const floor = FLOOR_REGISTRY.find((f) => f.id === floorId)

    if (!floor) {
      return FLOOR_PERSONAS["neuro-concierge"]
    }

    return FLOOR_PERSONAS[floor.guidePersonaId] || FLOOR_PERSONAS["neuro-concierge"]
  }

  delegateToFloorGuide(floorId: string): string {
    const persona = this.getPersona(floorId)
    return `Handing you over to ${persona.name} for this floor. ${persona.greeting}`
  }

  getFloorActions(floorId: string): string[] {
    const floor = FLOOR_REGISTRY.find((f) => f.id === floorId)
    return floor?.actionsPrimary || []
  }
}
