import { FLOOR_REGISTRY } from "@/lib/trinity/logic"

export interface IntakeQuestion {
  id: string
  question: string
  options: string[]
  type: "single" | "multiple"
}

export interface IntakeResponse {
  questionId: string
  answers: string[]
}

export const INTAKE_QUESTIONS: IntakeQuestion[] = [
  {
    id: "goal",
    question: "What brings you to 789 Studios today?",
    options: ["Learn about Film3", "Build content", "Watch shows", "Play & explore", "Research ecosystem"],
    type: "multiple",
  },
  {
    id: "industry",
    question: "Which area interests you most?",
    options: ["Filmmaking", "Music", "Podcasting", "Blockchain", "Community", "All of the above"],
    type: "single",
  },
  {
    id: "comfort",
    question: "How would you describe your Web3 experience?",
    options: ["New to Web3", "Some experience", "Advanced user"],
    type: "single",
  },
  {
    id: "format",
    question: "How do you prefer to explore?",
    options: ["Quick overview", "Guided walkthrough", "Deep dive", "Let me explore freely"],
    type: "single",
  },
]

export class NeuroConcierge {
  async generateGreeting(userName?: string): Promise<string> {
    const name = userName || "friend"

    const prompts = [
      `Welcome to 789 Studios, ${name}. I'm NEURO, your guide through this Web3 creator ecosystem. Ready to explore?`,
      `Hey ${name}, NEURO here. This is 789 Studios — where Film3 meets creator sovereignty. Want a tour or jumping straight to the elevator?`,
      `${name}, welcome. I'm NEURO META X, and this is 789 Studios. Let's get you oriented. Tour or elevator?`,
    ]

    return prompts[Math.floor(Math.random() * prompts.length)]
  }

  async generateTourIntro(responses: IntakeResponse[]): Promise<string> {
    const goals = responses.find((r) => r.questionId === "goal")?.answers || []
    const comfort = responses.find((r) => r.questionId === "comfort")?.answers[0] || "intermediate"

    return `Based on your interests in ${goals.join(" and ")}, I've mapped out a ${comfort === "New to Web3" ? "beginner-friendly" : "comprehensive"} tour. We'll visit ${goals.length + 2} key floors. This should take about ${goals.length * 2} minutes. Ready to board the elevator?`
  }

  generateFloorIntro(floorId: string, isDeepTour: boolean): string {
    const floor = FLOOR_REGISTRY.find((f) => f.id === floorId)

    if (!floor) return "Floor not found."

    return isDeepTour ? floor.tourScriptDeep : floor.tourScriptShort
  }

  async handleAkashicTrigger(): Promise<{ offerTour: boolean; message: string }> {
    return {
      offerTour: true,
      message:
        "I sense you're interested in the Akashic layer. This is where the spiritual, metaphysical, and esoteric content lives — completely firewalled from business operations. Want to explore it?",
    }
  }
}
