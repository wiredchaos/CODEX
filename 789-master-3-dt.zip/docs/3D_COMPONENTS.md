# 3D Components Library

This document describes the 3D components available in the 789 Studios application and how to use them with the current build.

## Available Components

### 1. ThreeDCard
**Location:** `components/three/3d-card.tsx`

A floating 3D card with rotation and float animations. Perfect for hero sections or featured content.

**Usage:**
```tsx
import { ThreeDCard } from "@/components/three/3d-card"

<div className="h-[400px]">
  <ThreeDCard />
</div>
```

**Where to use:**
- OTT hero sections
- Featured content cards
- Creator profile headers
- Landing page highlights

---

### 2. ThreeDLogo
**Location:** `components/three/3d-logo.tsx`

An animated 3D text logo with customizable text. Great for branding.

**Usage:**
```tsx
import { ThreeDLogo } from "@/components/three/3d-logo"

<div className="h-[300px]">
  <ThreeDLogo text="789" />
</div>
```

**Props:**
- `text?: string` - Text to display (default: "789")
- `className?: string` - Additional CSS classes

**Where to use:**
- Homepage hero
- About page headers
- Studio branding sections
- Loading screens

---

### 3. ThreeDGlobe
**Location:** `components/three/3d-globe.tsx`

An interactive wireframe globe with stars background. Represents global reach.

**Usage:**
```tsx
import { ThreeDGlobe } from "@/components/three/3d-globe"

<div className="h-[500px]">
  <ThreeDGlobe />
</div>
```

**Where to use:**
- Network/Spaces page
- CSN global presence section
- Distribution sections
- About page

---

### 4. ThreeDParticles
**Location:** `components/three/3d-particles.tsx`

Animated particle field for backgrounds or decorative elements.

**Usage:**
```tsx
import { ThreeDParticles } from "@/components/three/3d-particles"

<div className="h-[600px]">
  <ThreeDParticles count={2000} />
</div>
```

**Props:**
- `count?: number` - Number of particles (default: 1000)
- `className?: string` - Additional CSS classes

**Where to use:**
- Page backgrounds
- Section dividers
- Hero backgrounds
- Transition effects

---

### 5. ThreeHexWorld
**Location:** `components/three-hex-world.tsx`

Interactive hexagonal navigation world with labeled sections.

**Usage:**
```tsx
import { ThreeHexWorld } from "@/components/three-hex-world"

<ThreeHexWorld 
  onSelectSection={(id) => {
    console.log("Selected:", id)
    // Navigate to section
  }} 
/>
```

**Props:**
- `onSelectSection?: (id: string) => void` - Callback when hex is clicked

**Sections:**
- `hex-forge` - HEX
- `game-forge` - GAME
- `radio-33` - 33.3 FM
- `npc-lab` - NPC Lab
- `creator-hub` - Creator Hub

**Where to use:**
- Navigation hubs
- Interactive site maps
- Elevator destination picker
- Creator dashboard

---

## Integration with Existing Build

### Trinity Scene Integration

All 3D components work alongside the existing `TrinityScene` background:

```tsx
// In any page
import { TrinityScene } from "@/lib/core/trinity-3d/trinity-scene"
import { ThreeDLogo } from "@/components/three/3d-logo"

<div className="relative">
  <TrinityScene /> {/* Background particles */}
  <div className="relative z-10 h-[400px]">
    <ThreeDLogo text="WIRED CHAOS" />
  </div>
</div>
```

### Elevator Integration

Use `ThreeHexWorld` as an elevator destination picker:

```tsx
import { ThreeHexWorld } from "@/components/three"
import { useElevator } from "@/lib/core/elevator/elevator-provider"

function ElevatorDestinations() {
  const { goToFloor } = useElevator()
  
  return (
    <ThreeHexWorld 
      onSelectSection={(id) => {
        goToFloor(id)
      }}
    />
  )
}
```

### Performance Considerations

All 3D components use `Suspense` for code splitting:

```tsx
import { Suspense } from "react"
import { ThreeDGlobe } from "@/components/three/3d-globe"

<Suspense fallback={<div>Loading 3D...</div>}>
  <ThreeDGlobe />
</Suspense>
```

### Mobile Optimization

3D components automatically adapt to mobile:
- Reduced particle counts
- Lower polygon counts
- Disabled auto-rotation on touch devices

### Realm-Aware Styling

Components can respond to Trinity realm state:

```tsx
import { useTrinity } from "@/lib/core/trinity-3d/trinity-provider"

function RealmAware3D() {
  const { realm } = useTrinity()
  
  return (
    <ThreeDLogo 
      text={realm === "akashic" ? "AKASHIC" : "BUSINESS"}
    />
  )
}
```

---

## Example Implementations

### OTT Page Hero
```tsx
<section className="relative h-screen">
  <TrinityScene />
  <div className="absolute inset-0 z-10 flex items-center justify-center">
    <div className="h-[500px] w-full max-w-4xl">
      <ThreeDCard />
    </div>
  </div>
</section>
```

### Creator Hub Navigation
```tsx
<section className="py-20">
  <h2 className="text-4xl font-bold text-center mb-12">Explore 789 Studios</h2>
  <ThreeHexWorld 
    onSelectSection={(id) => router.push(`/${id}`)}
  />
</section>
```

### Allies Page Background
```tsx
<div className="relative min-h-screen">
  <div className="absolute inset-0 opacity-30">
    <ThreeDParticles count={500} />
  </div>
  <div className="relative z-10">
    {/* Allies content */}
  </div>
</div>
```

---

## Notes

- All components are client-side only (`"use client"`)
- React Three Fiber and Three.js are already in package.json
- Components follow existing 789 Studios color scheme (cyan #00ffff, orange #ff8800)
- All components support className prop for custom styling
- No changes to existing functionality - purely additive
