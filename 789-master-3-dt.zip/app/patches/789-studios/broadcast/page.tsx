"use client"

import { useEffect, useState } from "react"
import { TFSCompiler, type TFSScene } from "@/lib/tfs/compiler"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Film, ExternalLink, Loader2, Play } from "lucide-react"
import Link from "next/link"

export default function BroadcastPreview() {
  const [scenes, setScenes] = useState<TFSScene[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadScenes()
  }, [])

  const loadScenes = async () => {
    try {
      const data = await TFSCompiler.getScenes()
      setScenes(data)
    } catch (error) {
      console.error("[v0] Failed to load scenes:", error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-orange-500" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="border-b border-white/10 bg-gradient-to-b from-cyan-500/10 to-transparent">
        <div className="mx-auto max-w-7xl px-6 py-12">
          <Link href="/patches/789-studios" className="text-sm text-gray-400 hover:text-white mb-4 inline-block">
            ← Back to Studio
          </Link>
          <div className="flex items-center gap-3 mb-4">
            <div className="h-12 w-12 rounded-lg bg-gradient-to-br from-cyan-500 to-cyan-600 flex items-center justify-center">
              <Play className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Broadcast Preview</h1>
              <p className="text-sm text-gray-400">Compiled Sets & Deployed Scenes</p>
            </div>
          </div>
          <p className="text-gray-300 max-w-3xl">
            View all compiled cinematic sets from Trinity Field System. Each scene is ready for broadcast and can be
            deployed to your OTT platform.
          </p>
        </div>
      </div>

      {/* Scenes Grid */}
      <div className="mx-auto max-w-7xl px-6 py-12">
        {scenes.length === 0 ? (
          <Card className="bg-white/5 border-white/10 p-12 text-center">
            <Film className="h-12 w-12 text-gray-600 mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Compiled Sets Yet</h3>
            <p className="text-gray-400 mb-6">Compile your first cinematic set to see it here in broadcast preview.</p>
            <Link href="/patches/789-studios">
              <Button className="bg-orange-500 hover:bg-orange-600">Go to Studio</Button>
            </Link>
          </Card>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {scenes.map((scene) => (
              <Card
                key={scene.id}
                className="bg-white/5 border-white/10 overflow-hidden group hover:border-cyan-500/30 transition-colors"
              >
                {/* Preview Image */}
                <div className="aspect-video bg-gradient-to-br from-orange-500/20 to-cyan-500/20 flex items-center justify-center">
                  <Film className="h-12 w-12 text-white/40" />
                </div>

                {/* Content */}
                <div className="p-6">
                  <div className="flex items-start justify-between mb-3">
                    <h3 className="font-semibold">{scene.name}</h3>
                    <Badge
                      variant="outline"
                      className={
                        scene.status === "complete"
                          ? "bg-green-500/20 text-green-400 border-green-500/30"
                          : "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
                      }
                    >
                      {scene.status}
                    </Badge>
                  </div>

                  <div className="space-y-2 text-sm mb-4">
                    <div className="flex justify-between text-gray-400">
                      <span>Runtime</span>
                      <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30 text-xs">Cinematic</Badge>
                    </div>
                    <div className="flex justify-between text-gray-400">
                      <span>Credits Used</span>
                      <span className="font-mono text-orange-500">{scene.creditsUsed}</span>
                    </div>
                    <div className="flex justify-between text-gray-400">
                      <span>Scene ID</span>
                      <span className="font-mono text-xs truncate ml-2 max-w-[120px]">{scene.id}</span>
                    </div>
                  </div>

                  {scene.status === "complete" && (
                    <Link href={scene.deployedRoute} target="_blank">
                      <Button
                        variant="outline"
                        className="w-full border-white/20 hover:bg-white/10 hover:border-cyan-500/50 transition-all bg-transparent"
                      >
                        <ExternalLink className="mr-2 h-4 w-4" />
                        View in Trinity Viewer
                      </Button>
                    </Link>
                  )}
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* Stats */}
        {scenes.length > 0 && (
          <div className="mt-12 grid gap-4 md:grid-cols-3">
            <Card className="bg-white/5 border-white/10 p-6">
              <div className="text-sm text-gray-400 mb-1">Total Sets Compiled</div>
              <div className="text-3xl font-bold text-orange-500">{scenes.length}</div>
            </Card>
            <Card className="bg-white/5 border-white/10 p-6">
              <div className="text-sm text-gray-400 mb-1">Total Credits Used</div>
              <div className="text-3xl font-bold text-cyan-500">
                {scenes.reduce((sum, s) => sum + s.creditsUsed, 0)}
              </div>
            </Card>
            <Card className="bg-white/5 border-white/10 p-6">
              <div className="text-sm text-gray-400 mb-1">Active Scenes</div>
              <div className="text-3xl font-bold text-green-500">
                {scenes.filter((s) => s.status === "complete").length}
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
