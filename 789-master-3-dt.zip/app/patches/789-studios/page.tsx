"use client"

import { useState } from "react"
import { SET_TEMPLATES, type SetTemplate } from "@/lib/tfs/set-templates"
import { TFSCompiler, type TFSCompileResponse } from "@/lib/tfs/compiler"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Film, Mic, Radio, Sparkles, Loader2 } from "lucide-react"
import Link from "next/link"

export default function Patch789Studios() {
  const [compiling, setCompiling] = useState<Record<string, boolean>>({})
  const [compiledSets, setCompiledSets] = useState<Record<string, TFSCompileResponse>>({})

  const handleCompile = async (template: SetTemplate) => {
    setCompiling((prev) => ({ ...prev, [template.id]: true }))

    try {
      const response = await TFSCompiler.compile({
        setType: template.id as any,
        promptTemplate: template.promptTemplate,
        runtimeProfile: "cinematic",
        metadata: {
          templateName: template.name,
          category: template.category,
        },
      })

      setCompiledSets((prev) => ({ ...prev, [template.id]: response }))

      // Simulate compilation progress
      setTimeout(() => {
        setCompiledSets((prev) => ({
          ...prev,
          [template.id]: {
            ...response,
            status: "complete",
            progress: 100,
          },
        }))
      }, 3000)
    } catch (error) {
      console.error("[v0] TFS compilation error:", error)
    } finally {
      setCompiling((prev) => ({ ...prev, [template.id]: false }))
    }
  }

  const getCategoryIcon = (category: SetTemplate["category"]) => {
    switch (category) {
      case "audio":
        return <Mic className="h-5 w-5" />
      case "video":
        return <Film className="h-5 w-5" />
      case "broadcast":
        return <Radio className="h-5 w-5" />
    }
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="border-b border-white/10 bg-gradient-to-b from-orange-500/10 to-transparent">
        <div className="mx-auto max-w-7xl px-6 py-12">
          <div className="flex items-center gap-3 mb-4">
            <div className="h-12 w-12 rounded-lg bg-gradient-to-br from-orange-500 to-orange-600 flex items-center justify-center">
              <Film className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">789 Studios</h1>
              <p className="text-sm text-gray-400">Cinematic Set Compiler</p>
            </div>
          </div>
          <p className="text-gray-300 max-w-3xl">
            Professional broadcast and recording sets powered by Trinity Field System. Compile cinematic environments
            with one click and deploy to your OTT platform.
          </p>
        </div>
      </div>

      {/* Set Types Grid */}
      <div className="mx-auto max-w-7xl px-6 py-12">
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-2">Available Set Types</h2>
          <p className="text-gray-400">Choose a set template and compile with TFS cinematic runtime</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {SET_TEMPLATES.map((template) => {
            const isCompiling = compiling[template.id]
            const compiled = compiledSets[template.id]
            const credits = TFSCompiler.calculateCredits(template.id as any)

            return (
              <Card key={template.id} className="bg-white/5 border-white/10 p-6 hover:bg-white/10 transition-colors">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-lg bg-orange-500/20 flex items-center justify-center text-orange-500">
                      {getCategoryIcon(template.category)}
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">{template.name}</h3>
                      <Badge variant="outline" className="mt-1 text-xs">
                        {template.category}
                      </Badge>
                    </div>
                  </div>
                </div>

                <p className="text-sm text-gray-400 mb-4">{template.description}</p>

                {/* Fee Breakdown */}
                <div className="rounded-lg bg-black/40 border border-white/10 p-4 mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-gray-400">Runtime Profile</span>
                    <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">Cinematic</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-400">Credits Required</span>
                    <span className="text-sm font-mono font-semibold text-orange-500">{credits} credits</span>
                  </div>
                  <div className="text-xs text-gray-500 mt-2">Base: {credits / 1.5} • Cinematic: +50%</div>
                </div>

                {/* Compile Button */}
                {!compiled && (
                  <Button
                    onClick={() => handleCompile(template)}
                    disabled={isCompiling}
                    className="w-full bg-orange-500 hover:bg-orange-600 text-white"
                  >
                    {isCompiling ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Compiling Set...
                      </>
                    ) : (
                      <>
                        <Sparkles className="mr-2 h-4 w-4" />
                        Compile Set
                      </>
                    )}
                  </Button>
                )}

                {/* Compilation Status */}
                {compiled && (
                  <div className="space-y-3">
                    <div className="rounded-lg bg-green-500/10 border border-green-500/30 p-3">
                      <div className="flex items-center gap-2 text-sm text-green-400">
                        <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
                        {compiled.status === "complete" ? "Compilation Complete" : "Compiling..."}
                      </div>
                      <div className="text-xs text-gray-400 mt-1">Scene ID: {compiled.sceneId}</div>
                    </div>

                    {compiled.status === "complete" && (
                      <Link href="/patches/789-studios/broadcast">
                        <Button variant="outline" className="w-full border-white/20 hover:bg-white/10 bg-transparent">
                          View in Broadcast Preview
                        </Button>
                      </Link>
                    )}
                  </div>
                )}
              </Card>
            )
          })}
        </div>

        {/* Info Box */}
        <div className="mt-12 rounded-lg border border-cyan-500/30 bg-cyan-500/5 p-6">
          <h3 className="font-semibold mb-2 text-cyan-400">About Trinity Field System (TFS)</h3>
          <p className="text-sm text-gray-300">
            TFS is the cinematic rendering engine that compiles your broadcast sets with professional lighting, camera
            work, and atmospheric effects. All sets are tagged with <code className="text-orange-500">789_set</code> and
            stored in the wc_scenes registry for deployment to your OTT platform.
          </p>
        </div>
      </div>
    </div>
  )
}
