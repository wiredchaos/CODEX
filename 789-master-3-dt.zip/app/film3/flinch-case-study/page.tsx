"use client"

import { VirtualSoundstage } from "@/components/virtual-soundstage"
import { NavigationalAvatar } from "@/components/navigational-avatar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Play, Lock, Film, Coins, CheckCircle } from "lucide-react"
import { BackButton } from "@/components/ui/back-button"

export default function FlinchCaseStudyPage() {
  return (
    <VirtualSoundstage>
      <NavigationalAvatar />

      {/* Top Navigation */}
      <div className="border-b border-border/30 bg-black/40 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <BackButton fallbackHref="/film3" />
            <Link href="/" className="font-mono text-xs font-bold neon-text-gold">
              789
            </Link>
            <nav className="hidden md:flex items-center gap-4">
              <Link href="/" className="font-mono text-xs text-white/70 hover:text-white transition-colors">
                Home
              </Link>
              <Link href="/film3" className="font-mono text-xs text-white/70 hover:text-white transition-colors">
                Film3
              </Link>
              <Link href="/film3/flinch-case-study" className="font-mono text-xs text-white font-bold">
                FLINCH Case Study
              </Link>
            </nav>
          </div>
          <Button
            size="sm"
            className="font-mono font-bold uppercase tracking-wider text-white hover:opacity-90"
            style={{ background: "#00ffff", boxShadow: "0 0 20px rgba(0, 255, 255, 0.5)" }}
          >
            Connect Wallet
          </Button>
        </div>
      </div>

      {/* Hero Section */}
      <section className="relative py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center gap-3 mb-6">
            <Badge className="bg-[#00ffff]/10 border-[#00ffff]/30 text-[#00ffff] font-mono text-xs">
              NEURO PRESENTS
            </Badge>
            <Badge className="bg-[#daa520]/10 border-[#daa520]/30 text-[#daa520] font-mono text-xs">
              FILM3 MASTERCLASS
            </Badge>
          </div>

          <h1 className="text-4xl md:text-6xl font-bold text-balance mb-6">
            <span className="neon-text-cyan">FLINCH:</span>
            <br />
            <span className="chrome-text">THE FIRST NFT FILM FRANCHISE</span>
          </h1>

          <p className="font-mono text-lg text-white/90 max-w-3xl mb-8">
            A comprehensive documentary course exploring how FLINCH revolutionized cinema through Web3, NFTs, and
            community ownership. Learn the blueprint for launching your own Film3 project.
          </p>

          <div className="glass-panel rounded-lg p-6 border border-[#daa520]/30 mb-8">
            <div className="flex items-start gap-4">
              <Film className="w-6 h-6 text-[#daa520] flex-shrink-0 mt-1" />
              <div className="space-y-2">
                <h3 className="font-mono text-sm font-bold text-white">FLINCH (2021)</h3>
                <p className="font-mono text-xs text-white/80">
                  <strong className="text-[#daa520]">Director, Writer & Producer:</strong> Cameron Van Hoy
                </p>
                <p className="font-mono text-xs text-white/80">
                  <strong className="text-[#daa520]">Cast:</strong> Daniel Zovatto, Tilda Cobham-Hervey, Cathy Moriarty,
                  Tom Segura, Buddy Duress
                </p>
                <p className="font-mono text-xs text-white/80">
                  <strong className="text-[#daa520]">Synopsis:</strong> A young hitman falls for a girl who witnesses a
                  murder he commits. He takes her home and discovers there is more to her than meets the eye.
                </p>
                <p className="font-mono text-xs text-white/70 pt-2">
                  The first indie film released and franchised via NFTs, creating a community-owned cinematic franchise
                  on the blockchain.
                </p>
              </div>
            </div>
          </div>

          {/* Video Player */}
          <div className="relative aspect-video rounded-lg overflow-hidden border border-[#00ffff]/30 mb-8">
            <img src="/flinch-nft-movie-poster.jpg" alt="FLINCH NFT Movie" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center">
              <Button
                size="lg"
                className="font-mono font-bold uppercase tracking-wider text-white hover:opacity-90 gap-3"
                style={{ background: "#00ffff", boxShadow: "0 0 30px rgba(0, 255, 255, 0.6)" }}
              >
                <Play className="w-6 h-6" fill="currentColor" />
                Watch Trailer
              </Button>
            </div>
          </div>

          {/* FLINCH YouTube video embeds for security audit and behind-the-scenes */}
          <div className="space-y-6 mb-8">
            <h3 className="font-mono text-xl font-bold text-white">FLINCH DEEP DIVE VIDEOS</h3>

            {/* Security Audit Video */}
            <div className="rounded-xl p-4 border border-[#daa520]/40 bg-black/40 backdrop-blur-sm">
              <h4 className="font-mono text-sm font-bold text-[#daa520] mb-3">
                Flinch NFT Token - Smart Contracts Security Audit Report
              </h4>
              <div className="relative w-full" style={{ paddingBottom: "56.25%" }}>
                <iframe
                  className="absolute top-0 left-0 w-full h-full rounded-lg"
                  src="https://www.youtube.com/embed/SERiyOxTddQ"
                  title="Flinch NFT Token - Smart Contracts Security Audit Report"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  referrerPolicy="strict-origin-when-cross-origin"
                  allowFullScreen
                />
              </div>
            </div>

            {/* FLINCH Feature Film */}
            <div className="rounded-xl p-4 border border-[#00ffff]/40 bg-black/40 backdrop-blur-sm">
              <h4 className="font-mono text-sm font-bold text-[#00ffff] mb-3">FLINCH - Official Film</h4>
              <div className="relative w-full" style={{ paddingBottom: "56.25%" }}>
                <iframe
                  className="absolute top-0 left-0 w-full h-full rounded-lg"
                  src="https://www.youtube.com/embed/72N7Uq6wAQ0"
                  title="FLINCH - Official Film"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  referrerPolicy="strict-origin-when-cross-origin"
                  allowFullScreen
                />
              </div>
            </div>
          </div>

          {/* Pricing Card */}
          <Card className="glass-panel-enhanced border-2 border-[#ffd700]/30 p-8">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div className="space-y-2">
                <h3 className="font-mono text-2xl font-bold neon-text-gold">GET FULL ACCESS</h3>
                <p className="font-mono text-sm text-white/80">
                  Lifetime access • 12 episodes • Behind-the-scenes • Industry interviews • Blockchain templates
                </p>
              </div>
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
                <div className="text-right">
                  <div className="font-mono text-4xl font-bold neon-text-gold">$149</div>
                  <div className="font-mono text-xs text-white/60">or 0.5 ETH</div>
                </div>
                <Button
                  size="lg"
                  className="font-mono font-bold uppercase tracking-wider text-white hover:opacity-90 hover:scale-105 transition-all"
                  style={{ background: "#ffd700", boxShadow: "0 0 30px rgba(255, 215, 0, 0.5)" }}
                >
                  <Lock className="w-5 h-5 mr-2" />
                  Purchase Course
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* Course Modules */}
      <section className="max-w-6xl mx-auto px-4 py-16 space-y-8">
        <h2 className="font-mono text-3xl font-bold chrome-text">COURSE MODULES</h2>

        {/* Module 1 */}
        <Card className="studio-bay p-6 space-y-4">
          <div className="flex items-start justify-between">
            <div className="space-y-2">
              <Badge className="bg-[#00ffff]/10 border-[#00ffff]/30 text-[#00ffff] font-mono text-xs">MODULE 01</Badge>
              <h3 className="font-mono text-xl font-bold text-white">Introduction to FLINCH</h3>
              <p className="font-mono text-sm text-white/70">
                The origin story of the first NFT movie franchise and its groundbreaking approach to cinema
              </p>
            </div>
            <Button variant="ghost" size="sm" className="text-[#00ffff]">
              <Play className="w-4 h-4" />
            </Button>
          </div>
          <div className="grid md:grid-cols-3 gap-4 pt-4 border-t border-border/20">
            <div className="space-y-1">
              <div className="font-mono text-xs text-white/50">RUNTIME</div>
              <div className="font-mono text-sm text-white">18:42</div>
            </div>
            <div className="space-y-1">
              <div className="font-mono text-xs text-white/50">LESSONS</div>
              <div className="font-mono text-sm text-white">3</div>
            </div>
            <div className="space-y-1">
              <div className="font-mono text-xs text-white/50">STATUS</div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-[#00ff88]" />
                <span className="font-mono text-sm text-[#00ff88]">Completed</span>
              </div>
            </div>
          </div>
        </Card>

        {/* Module 2 */}
        <Card className="studio-bay p-6 space-y-4">
          <div className="flex items-start justify-between">
            <div className="space-y-2">
              <Badge className="bg-[#daa520]/10 border-[#daa520]/30 text-[#daa520] font-mono text-xs">MODULE 02</Badge>
              <h3 className="font-mono text-xl font-bold text-white">Film3 History & Key Players</h3>
              <p className="font-mono text-sm text-white/70">
                Roman Coppola, Decentralized Pictures, Gala Films, and the pioneers who built Film3
              </p>
            </div>
            <Button variant="ghost" size="sm" className="text-[#daa520]">
              <Play className="w-4 h-4" />
            </Button>
          </div>
          <div className="grid md:grid-cols-3 gap-4 pt-4 border-t border-border/20">
            <div className="space-y-1">
              <div className="font-mono text-xs text-white/50">RUNTIME</div>
              <div className="font-mono text-sm text-white">34:15</div>
            </div>
            <div className="space-y-1">
              <div className="font-mono text-xs text-white/50">LESSONS</div>
              <div className="font-mono text-sm text-white">5</div>
            </div>
            <div className="space-y-1">
              <div className="font-mono text-xs text-white/50">COMMUNITY VOICES</div>
              <div className="font-mono text-sm text-white">#Film3 Movement</div>
            </div>
          </div>
        </Card>

        {/* Module 3 */}
        <Card className="studio-bay p-6 space-y-4">
          <div className="flex items-start justify-between">
            <div className="space-y-2">
              <Badge className="bg-[#ffd700]/10 border-[#ffd700]/30 text-[#ffd700] font-mono text-xs">MODULE 03</Badge>
              <h3 className="font-mono text-xl font-bold text-white">The FLINCH Business Model</h3>
              <p className="font-mono text-sm text-white/70">
                How FLINCH used NFT character sales, decentralized cinema, and community ownership to fund sequels
              </p>
            </div>
            <Button variant="ghost" size="sm" className="text-[#ffd700]">
              <Play className="w-4 h-4" />
            </Button>
          </div>
          <div className="grid md:grid-cols-3 gap-4 pt-4 border-t border-border/20">
            <div className="space-y-1">
              <div className="font-mono text-xs text-white/50">RUNTIME</div>
              <div className="font-mono text-sm text-white">42:08</div>
            </div>
            <div className="space-y-1">
              <div className="font-mono text-xs text-white/50">LESSONS</div>
              <div className="font-mono text-sm text-white">6</div>
            </div>
            <div className="space-y-1">
              <div className="font-mono text-xs text-white/50">REVENUE</div>
              <div className="font-mono text-sm text-white">58 ETH Total Volume</div>
            </div>
          </div>
        </Card>

        {/* Module 4 */}
        <Card className="studio-bay p-6 space-y-4">
          <div className="flex items-start justify-between">
            <div className="space-y-2">
              <Badge className="bg-[#00ffff]/10 border-[#00ffff]/30 text-[#00ffff] font-mono text-xs">MODULE 04</Badge>
              <h3 className="font-mono text-xl font-bold text-white">NFT Character Collection Deep Dive</h3>
              <p className="font-mono text-sm text-white/70">
                How FLINCH turned characters, weapons, and vehicles into tradeable NFTs on Ethereum
              </p>
            </div>
            <Button variant="ghost" size="sm" className="text-[#00ffff]">
              <Play className="w-4 h-4" />
            </Button>
          </div>
          <div className="grid md:grid-cols-3 gap-4 pt-4 border-t border-border/20">
            <div className="space-y-1">
              <div className="font-mono text-xs text-white/50">RUNTIME</div>
              <div className="font-mono text-sm text-white">28:33</div>
            </div>
            <div className="space-y-1">
              <div className="font-mono text-xs text-white/50">LESSONS</div>
              <div className="font-mono text-sm text-white">4</div>
            </div>
            <div className="space-y-1">
              <div className="font-mono text-xs text-white/50">COLLECTION</div>
              <div className="font-mono text-sm text-white">OpenSea Verified</div>
            </div>
          </div>
        </Card>

        {/* Module 5 */}
        <Card className="studio-bay p-6 space-y-4">
          <div className="flex items-start justify-between">
            <div className="space-y-2">
              <Badge className="bg-[#daa520]/10 border-[#daa520]/30 text-[#daa520] font-mono text-xs">MODULE 05</Badge>
              <h3 className="font-mono text-xl font-bold text-white">Decentralized Cinema Platform</h3>
              <p className="font-mono text-sm text-white/70">
                Building a pay-per-view cinema on Polygon where wallet holders watch with MATIC
              </p>
            </div>
            <Button variant="ghost" size="sm" className="text-[#daa520]">
              <Play className="w-4 h-4" />
            </Button>
          </div>
        </Card>

        {/* Module 6 */}
        <Card className="studio-bay p-6 space-y-4">
          <div className="flex items-start justify-between">
            <div className="space-y-2">
              <Badge className="bg-[#ffd700]/10 border-[#ffd700]/30 text-[#ffd700] font-mono text-xs">MODULE 06</Badge>
              <h3 className="font-mono text-xl font-bold text-white">Community as Studio: The DAO Model</h3>
              <p className="font-mono text-sm text-white/70">
                How NFT holders replace traditional studios, make creative decisions, and share franchise revenue
              </p>
            </div>
            <Button variant="ghost" size="sm" className="text-[#ffd700]">
              <Lock className="w-4 h-4" />
            </Button>
          </div>
        </Card>

        {/* Remaining modules locked */}
        {[
          {
            module: "07",
            title: "Cold Wallet, RZR & Other Film3 Projects",
            color: "#00ffff",
          },
          { module: "08", title: "Smart Contracts for Film Distribution", color: "#daa520" },
          { module: "09", title: "Building Your Film3 Project on 789", color: "#ffd700" },
          { module: "10", title: "Marketing Your NFT Film Collection", color: "#00ffff" },
          { module: "11", title: "Legal & Rights Management in Film3", color: "#daa520" },
          {
            module: "12",
            title: "Launch Strategy: From Mint to Premiere",
            color: "#ffd700",
          },
        ].map((item) => (
          <Card key={item.module} className="studio-bay p-6 space-y-4 opacity-60">
            <div className="flex items-start justify-between">
              <div className="space-y-2">
                <Badge
                  className="font-mono text-xs"
                  style={{
                    background: `${item.color}10`,
                    borderColor: `${item.color}30`,
                    color: item.color,
                  }}
                >
                  MODULE {item.module}
                </Badge>
                <h3 className="font-mono text-xl font-bold text-white">{item.title}</h3>
              </div>
              <Lock className="w-5 h-5 text-white/30" />
            </div>
          </Card>
        ))}
      </section>

      {/* What You'll Learn */}
      <section className="max-w-6xl mx-auto px-4 py-16 space-y-8">
        <h2 className="font-mono text-3xl font-bold chrome-text">WHAT YOU'LL LEARN</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {[
            "How FLINCH became the first NFT movie franchise",
            "Film3 history from Decentralized Pictures to Gala Films",
            "NFT character collection strategy and smart contract design",
            "Building decentralized cinema platforms with crypto payments",
            "Community ownership models that replace traditional studios",
            "Revenue sharing through blockchain and NFT royalties",
            "Marketing and launching your Film3 project",
            "Legal frameworks for Web3 filmmaking",
            "Case studies: Cold Wallet, RZR, and Emmy-nominated projects",
            "How to use 789 Studios for Film3 production and distribution",
          ].map((item, index) => (
            <div key={index} className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-[#00ff88] mt-0.5 flex-shrink-0" />
              <span className="font-mono text-sm text-white/90">{item}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Instructor Section */}
      <section className="max-w-6xl mx-auto px-4 py-16">
        <Card className="glass-panel-enhanced border-2 border-[#00ffff]/30 p-8 md:p-12">
          <div className="flex flex-col md:flex-row gap-8 items-start">
            <div className="w-32 h-32 rounded-full bg-gradient-to-br from-[#00ffff] to-[#daa520] p-1 flex-shrink-0">
              <div className="w-full h-full rounded-full bg-black flex items-center justify-center">
                <span className="font-mono text-4xl font-bold neon-text-cyan">N</span>
              </div>
            </div>
            <div className="space-y-4 flex-1">
              <div>
                <h3 className="font-mono text-2xl font-bold neon-text-cyan mb-2">NEURO</h3>
                <p className="font-mono text-sm text-[#daa520]">Film3 Participant • NFT Holder • 789 Studios Host</p>
              </div>
              <p className="font-mono text-sm text-white/80 leading-relaxed">
                NEURO is a Film3 participant, NFT holder at producer and cast levels, and the 789 Studios host on the
                Crypto Spaces Network. Building alongside the Web3 filmmaking community, NEURO helps bridge traditional
                filmmakers and blockchain distribution. This documentary course represents thousands of hours of
                research, community voices from the #Film3 movement, and practical implementation knowledge.
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4">
                <div>
                  <div className="font-mono text-2xl font-bold neon-text-gold">5+</div>
                  <div className="font-mono text-xs text-white/60">Years Film3</div>
                </div>
                <div>
                  <div className="font-mono text-2xl font-bold neon-text-gold">50K+</div>
                  <div className="font-mono text-xs text-white/60">Community</div>
                </div>
                <div>
                  <div className="font-mono text-2xl font-bold neon-text-gold">12</div>
                  <div className="font-mono text-xs text-white/60">Projects Advised</div>
                </div>
                <div>
                  <div className="font-mono text-2xl font-bold neon-text-gold">4.9</div>
                  <div className="font-mono text-xs text-white/60">Instructor Rating</div>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </section>

      {/* CTA */}
      <section className="max-w-5xl mx-auto px-4 py-20">
        <div className="glass-panel-enhanced rounded-lg p-12 border-2 border-[#ffd700]/30 text-center space-y-6">
          <h2 className="font-mono text-3xl font-bold chrome-text">READY TO MASTER FILM3?</h2>
          <p className="font-mono text-base text-white/90 max-w-2xl mx-auto">
            Get lifetime access to the most comprehensive Film3 education available. Learn from real case studies,
            industry pioneers, and practical blockchain implementation.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <Button
              size="lg"
              className="font-mono font-bold uppercase tracking-wider text-white hover:opacity-90 hover:scale-105 transition-all gap-2"
              style={{ background: "#ffd700", boxShadow: "0 0 30px rgba(255, 215, 0, 0.5)" }}
            >
              <Coins className="w-5 h-5" />
              Purchase for $149
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="font-mono font-bold uppercase tracking-wider border-[#00ffff]/50 hover:bg-[#00ffff]/10 bg-transparent text-[#00ffff]"
            >
              Watch Free Preview
            </Button>
          </div>
        </div>
      </section>
    </VirtualSoundstage>
  )
}
