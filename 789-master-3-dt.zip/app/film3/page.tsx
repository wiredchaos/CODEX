"use client"

import { VirtualSoundstage } from "@/components/virtual-soundstage"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { NavigationalAvatar } from "@/components/navigational-avatar"
import { Film, Upload, Lock, Coins, Users, Globe } from "lucide-react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { BackButton } from "@/components/ui/back-button"

export default function Film3Page() {
  return (
    <VirtualSoundstage>
      <NavigationalAvatar />

      {/* Top Navigation */}
      <div className="border-b border-border/30 bg-black/40 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <BackButton fallbackHref="/" />
            <Link href="/" className="font-mono text-xs font-bold neon-text-gold">
              789
            </Link>
            <nav className="hidden md:flex items-center gap-4">
              <Link href="/" className="font-mono text-xs text-white/70 hover:text-white transition-colors">
                Home
              </Link>
              <Link href="/creator" className="font-mono text-xs text-white/70 hover:text-white transition-colors">
                Creator Hub
              </Link>
              <Link href="/film3" className="font-mono text-xs text-white font-bold">
                Film3
              </Link>
              <Link href="/mint" className="font-mono text-xs text-white/70 hover:text-white transition-colors">
                Mint Film
              </Link>
              <Link href="/spaces" className="font-mono text-xs text-white/70 hover:text-white transition-colors">
                Spaces Network
              </Link>
            </nav>
          </div>
          <Button
            size="sm"
            className="font-mono font-bold uppercase tracking-wider text-white hover:opacity-90"
            style={{ background: "#daa520", boxShadow: "0 0 20px rgba(218, 165, 32, 0.5)" }}
          >
            Connect Wallet
          </Button>
        </div>
      </div>

      {/* Hero Section */}
      <section className="relative py-20 px-4 text-center">
        <div className="max-w-5xl mx-auto space-y-8">
          <div className="inline-flex items-center gap-3 bg-[#daa520]/10 border border-[#daa520]/30 rounded-full px-6 py-2">
            <Film className="w-5 h-5 text-[#daa520]" />
            <span className="font-mono text-sm font-bold text-[#daa520]">#FILM3: DECENTRALIZED CINEMA</span>
          </div>

          <h1 className="text-4xl md:text-6xl font-bold text-balance">
            <span className="chrome-text">WEB2 FILMMAKERS</span>
            <br />
            <span className="neon-text-goldenrod">MEET WEB3</span>
          </h1>

          <p className="font-mono text-base md:text-lg text-white/90 max-w-3xl mx-auto text-pretty">
            Join the #FILM3 movement. Bypass Hollywood gatekeepers. Token-gate your films. Build direct relationships
            with your audience. Keep 90% of revenue.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <Button
              size="lg"
              className="font-mono font-bold uppercase tracking-wider text-white hover:opacity-90"
              style={{ background: "#daa520", boxShadow: "0 0 20px rgba(218, 165, 32, 0.5)" }}
              asChild
            >
              <Link href="/mint">Start Your Film3 Journey</Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="font-mono font-bold uppercase tracking-wider border-[#daa520]/50 hover:bg-[#daa520]/10 bg-transparent text-white"
              style={{ textShadow: "0 0 8px rgba(255, 255, 255, 0.5)" }}
              asChild
            >
              <Link href="/rupture">Watch Documentary</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Film3 Demo Video Section */}
      {/* Removed as per update */}

      {/* Film3 Educational Videos Section */}
      <section className="max-w-7xl mx-auto px-4 py-16 space-y-12">
        <div className="text-center space-y-4">
          <h2 className="font-mono text-3xl font-bold chrome-text">FILM3 EDUCATION</h2>
          <p className="font-mono text-sm text-white/80 max-w-2xl mx-auto">
            Watch real Film3 projects and learn from the pioneers who are building decentralized cinema
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* FLINCH Official Film */}
          <Card className="glass-panel-enhanced border-[#00ffff]/20 overflow-hidden">
            <div className="p-4 bg-black/60 border-b border-[#00ffff]/20">
              <h3
                className="font-mono text-lg font-bold text-white"
                style={{ textShadow: "0 0 8px rgba(255, 255, 255, 0.5)" }}
              >
                FLINCH - The First NFT Film
              </h3>
              <p className="font-mono text-xs text-white/60 mt-1">Directed by Cameron Van Hoy • 2021 • 58 ETH Volume</p>
            </div>
            <div className="relative aspect-video bg-black">
              <iframe
                className="absolute top-0 left-0 w-full h-full"
                src="https://www.youtube.com/embed/72N7Uq6wAQ0"
                title="FLINCH - Official Film"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                referrerPolicy="strict-origin-when-cross-origin"
                allowFullScreen
              />
            </div>
            <div className="p-4 bg-black/40">
              <p className="font-mono text-xs text-white/70">
                The groundbreaking indie thriller that pioneered NFT-based film franchising, creating a community-owned
                cinematic universe on the blockchain.
              </p>
            </div>
          </Card>

          {/* FLINCH Smart Contract Security Audit */}
          <Card className="glass-panel-enhanced border-[#daa520]/20 overflow-hidden">
            <div className="p-4 bg-black/60 border-b border-[#daa520]/20">
              <h3
                className="font-mono text-lg font-bold text-white"
                style={{ textShadow: "0 0 8px rgba(255, 255, 255, 0.5)" }}
              >
                FLINCH Technical Deep Dive
              </h3>
              <p className="font-mono text-xs text-white/60 mt-1">Smart Contract Security Audit • Ethereum NFTs</p>
            </div>
            <div className="relative aspect-video bg-black">
              <iframe
                className="absolute top-0 left-0 w-full h-full"
                src="https://www.youtube.com/embed/SERiyOxTddQ"
                title="Flinch NFT Token - Smart Contracts Security Audit Report"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                referrerPolicy="strict-origin-when-cross-origin"
                allowFullScreen
              />
            </div>
            <div className="p-4 bg-black/40">
              <p className="font-mono text-xs text-white/70">
                Technical breakdown of FLINCH's smart contract architecture, NFT implementation, and security audit
                results from industry experts.
              </p>
            </div>
          </Card>
        </div>
      </section>

      {/* Value Propositions */}
      <section className="max-w-7xl mx-auto px-4 py-16 space-y-12">
        <div className="text-center space-y-4">
          <h2 className="font-mono text-3xl font-bold chrome-text">WHY #FILM3?</h2>
          <p className="font-mono text-sm text-white/80 max-w-2xl mx-auto">
            Decentralized Pictures, Gala Film, and 60+ projects are revolutionizing cinema with blockchain, community
            voting, and cryptocurrency funding.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="glass-panel-enhanced border-[#daa520]/20 p-8 space-y-4">
            <div className="w-14 h-14 rounded-full bg-[#daa520]/10 border border-[#daa520]/30 flex items-center justify-center">
              <Coins className="w-7 h-7 text-[#daa520]" />
            </div>
            <h3 className="font-mono text-xl font-bold text-white">Keep 90% Revenue</h3>
            <p className="font-mono text-sm text-white/80">
              No middlemen. Direct payments via blockchain. You keep what you earn.
            </p>
          </Card>

          <Card className="glass-panel-enhanced border-[#daa520]/20 p-8 space-y-4">
            <div className="w-14 h-14 rounded-full bg-[#daa520]/10 border border-[#daa520]/30 flex items-center justify-center">
              <Lock className="w-7 h-7 text-[#daa520]" />
            </div>
            <h3 className="font-mono text-xl font-bold text-white">Token-Gated Access</h3>
            <p className="font-mono text-sm text-white/80">
              NFT holders get exclusive access. Early supporters get rewarded. Build true fans.
            </p>
          </Card>

          <Card className="glass-panel-enhanced border-[#daa520]/20 p-8 space-y-4">
            <div className="w-14 h-14 rounded-full bg-[#daa520]/10 border border-[#daa520]/30 flex items-center justify-center">
              <Users className="w-7 h-7 text-[#daa520]" />
            </div>
            <h3 className="font-mono text-xl font-bold text-white">Own Your Audience</h3>
            <p className="font-mono text-sm text-white/80">
              Direct relationship with viewers. No platform algorithms. Your community, your rules.
            </p>
          </Card>

          <Card className="glass-panel-enhanced border-[#daa520]/20 p-8 space-y-4">
            <div className="w-14 h-14 rounded-full bg-[#daa520]/10 border border-[#daa520]/30 flex items-center justify-center">
              <Upload className="w-7 h-7 text-[#daa520]" />
            </div>
            <h3 className="font-mono text-xl font-bold text-white">Easy Distribution</h3>
            <p className="font-mono text-sm text-white/80">
              Upload once, distribute everywhere. IPFS hosting. Decentralized storage. Forever.
            </p>
          </Card>

          <Card className="glass-panel-enhanced border-[#daa520]/20 p-8 space-y-4">
            <div className="w-14 h-14 rounded-full bg-[#daa520]/10 border border-[#daa520]/30 flex items-center justify-center">
              <Globe className="w-7 h-7 text-[#daa520]" />
            </div>
            <h3 className="font-mono text-xl font-bold text-white">Global Reach</h3>
            <p className="font-mono text-sm text-white/80">
              Instant worldwide distribution. Crypto payments accepted. No geo-restrictions.
            </p>
          </Card>

          <Card className="glass-panel-enhanced border-[#daa520]/20 p-8 space-y-4">
            <div className="w-14 h-14 rounded-full bg-[#daa520]/10 border border-[#daa520]/30 flex items-center justify-center">
              <Film className="w-7 h-7 text-[#daa520]" />
            </div>
            <h3 className="font-mono text-xl font-bold text-white">Full Production Support</h3>
            <p className="font-mono text-sm text-white/80">
              Access 789 Studios for recording, editing, mixing, mastering. Professional tools.
            </p>
          </Card>
        </div>
      </section>

      {/* How It Works */}
      <section className="max-w-7xl mx-auto px-4 py-16 space-y-12">
        <div className="text-center space-y-4">
          <h2 className="font-mono text-3xl font-bold chrome-text">HOW FILM3 WORKS</h2>
          <p className="font-mono text-sm text-white/80 max-w-2xl mx-auto">
            Four simple steps to bring your films to the blockchain
          </p>
        </div>

        <div className="grid md:grid-cols-4 gap-8">
          {[
            { step: "01", title: "Create Your Film", desc: "Use our professional studios or upload existing content" },
            {
              step: "02",
              title: "Mint as NFT",
              desc: "Create token-gated access for your film on Dogecoin blockchain",
            },
            {
              step: "03",
              title: "Set Pricing",
              desc: "Choose rental, purchase, or subscription models. You control pricing.",
            },
            { step: "04", title: "Earn Direct", desc: "Get paid instantly. 90% to you, 10% platform fee. No delays." },
          ].map((item) => (
            <div key={item.step} className="space-y-4">
              <div
                className="w-16 h-16 rounded-full flex items-center justify-center border-2 border-[#daa520] font-mono text-2xl font-bold"
                style={{ color: "#daa520" }}
              >
                {item.step}
              </div>
              <h3 className="font-mono text-lg font-bold text-white">{item.title}</h3>
              <p className="font-mono text-sm text-white/70">{item.desc}</p>
            </div>
          ))}
        </div>

        <div className="flex justify-center pt-8">
          <Button
            size="lg"
            className="font-mono font-bold uppercase tracking-wider text-white hover:opacity-90 hover:scale-105 transition-all"
            style={{
              background: "#daa520",
              boxShadow: "0 0 20px rgba(218, 165, 32, 0.5)",
            }}
            asChild
          >
            <Link href="/mint">Start Minting Your Film</Link>
          </Button>
        </div>
      </section>

      {/* FLINCH Case Study Section */}
      <section className="max-w-7xl mx-auto px-4 py-16 space-y-12">
        <div className="text-center space-y-4">
          <h2 className="font-mono text-3xl font-bold chrome-text">LEARN FROM THE BEST</h2>
          <p className="font-mono text-sm text-white/80 max-w-2xl mx-auto">
            Study real Film3 projects and learn how to launch your own
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* FLINCH Case Study Card */}
          <Link href="/film3/flinch-case-study">
            <Card className="studio-bay p-8 space-y-6 h-full">
              <Badge className="bg-[#00ffff]/10 border-[#00ffff]/30 text-[#00ffff] font-mono text-xs">
                FEATURED COURSE
              </Badge>
              <div className="space-y-4">
                <h3 className="font-mono text-2xl font-bold text-white">FLINCH: The First NFT Film Franchise</h3>
                <p className="font-mono text-sm text-white/80">
                  A comprehensive documentary by NEURO exploring how FLINCH revolutionized cinema through Web3. Learn
                  the blueprint, meet the pioneers, and discover Film3 history.
                </p>
                <div className="grid grid-cols-3 gap-4 pt-4 border-t border-border/20">
                  <div>
                    <div className="font-mono text-xl font-bold neon-text-cyan">12</div>
                    <div className="font-mono text-xs text-white/60">Episodes</div>
                  </div>
                  <div>
                    <div className="font-mono text-xl font-bold neon-text-gold">6hrs</div>
                    <div className="font-mono text-xs text-white/60">Runtime</div>
                  </div>
                  <div>
                    <div className="font-mono text-xl font-bold neon-text-goldenrod">$149</div>
                    <div className="font-mono text-xs text-white/60">Lifetime</div>
                  </div>
                </div>
              </div>
              <Button
                size="lg"
                className="w-full font-mono font-bold uppercase tracking-wider text-white hover:opacity-90"
                style={{ background: "#00ffff", boxShadow: "0 0 20px rgba(0, 255, 255, 0.5)" }}
              >
                Enroll Now
              </Button>
            </Card>
          </Link>

          {/* Film3 Blueprint Card */}
          <Card className="studio-bay p-8 space-y-6 h-full">
            <Badge className="bg-[#daa520]/10 border-[#daa520]/30 text-[#daa520] font-mono text-xs">COMING SOON</Badge>
            <div className="space-y-4">
              <h3 className="font-mono text-2xl font-bold text-white">Film3 Launch Blueprint</h3>
              <p className="font-mono text-sm text-white/80">
                Step-by-step guide to launching your film project on blockchain. Smart contracts, NFT design, marketing
                strategy, and distribution.
              </p>
              <div className="grid grid-cols-3 gap-4 pt-4 border-t border-border/20">
                <div>
                  <div className="font-mono text-xl font-bold neon-text-goldenrod">8</div>
                  <div className="font-mono text-xs text-white/60">Modules</div>
                </div>
                <div>
                  <div className="font-mono text-xl font-bold neon-text-goldenrod">4hrs</div>
                  <div className="font-mono text-xs text-white/60">Runtime</div>
                </div>
                <div>
                  <div className="font-mono text-xl font-bold neon-text-goldenrod">TBA</div>
                  <div className="font-mono text-xs text-white/60">Price</div>
                </div>
              </div>
            </div>
            <Button
              size="lg"
              variant="outline"
              className="w-full font-mono font-bold uppercase tracking-wider border-[#daa520]/50 bg-transparent text-[#daa520] opacity-60 cursor-not-allowed"
              disabled
            >
              Coming Q2 2025
            </Button>
          </Card>
        </div>
      </section>

      {/* Film3 Ecosystem Section */}
      <section className="max-w-7xl mx-auto px-4 py-16 space-y-12">
        <div className="text-center space-y-4">
          <h2 className="font-mono text-3xl font-bold chrome-text">#FILM3 ECOSYSTEM</h2>
          <p className="font-mono text-sm text-white/80 max-w-2xl mx-auto">
            Leading platforms, festivals, and projects building the future of decentralized cinema
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="glass-panel-enhanced border-[#00ffff]/20 p-8 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-mono text-xl font-bold text-white">Decentralized Pictures</h3>
              <Badge className="bg-[#00ffff]/10 border-[#00ffff]/30 text-[#00ffff] font-mono text-xs">ACTIVE</Badge>
            </div>
            <p className="font-mono text-sm text-white/80">
              501c(3) nonprofit democratic film fund co-founded by Roman Coppola and American Zoetrope. Community votes
              on project funding using $TALNT token on Base.
            </p>
            <div className="pt-4 border-t border-border/20 space-y-1">
              <p className="font-mono text-xs text-white/60">Projects: Cold Wallet, Calladita</p>
              <p className="font-mono text-xs text-white/60">Funded by: Steven Soderbergh</p>
              <p className="font-mono text-xs text-[#00ffff]">@DCP_FOUNDATION</p>
            </div>
          </Card>

          <Card className="glass-panel-enhanced border-[#daa520]/20 p-8 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-mono text-xl font-bold text-white">Gala Film</h3>
              <Badge className="bg-[#daa520]/10 border-[#daa520]/30 text-[#daa520] font-mono text-xs">LIVE</Badge>
            </div>
            <p className="font-mono text-sm text-white/80">
              Web3 streaming platform with $FILM token (launched Dec 2024). Decentralized Content Delivery Network
              powered by Theatre Nodes. Ad-free, creator-controlled.
            </p>
            <div className="pt-4 border-t border-border/20 space-y-1">
              <p className="font-mono text-xs text-white/60">Emmy-nominated: RZR (Mena Suvari)</p>
              <p className="font-mono text-xs text-white/60">60+ movies & TV series in dev</p>
            </div>
          </Card>

          <Card className="glass-panel-enhanced border-[#b8860b]/20 p-8 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-mono text-xl font-bold text-white">The Squad</h3>
              <Badge className="bg-[#b8860b]/10 border-[#b8860b]/30 text-[#b8860b] font-mono text-xs">
                FILM3 NATIVE
              </Badge>
            </div>
            <p className="font-mono text-sm text-white/80">
              Film3-Native Next-Gen IP Studio founded by Jordan Bayne. Originated the #Film3 movement. Pioneering the
              future of entertainment with creator-led innovation.
            </p>
            <div className="pt-4 border-t border-border/20 space-y-1">
              <p className="font-mono text-xs text-white/60">Partnership: Goldfinch + enGEN3</p>
              <p className="font-mono text-xs text-white/60">SquadPod: 700+ Twitter Spaces</p>
              <p className="font-mono text-xs text-[#b8860b]">filmsquad.io</p>
            </div>
          </Card>

          <Card className="glass-panel-enhanced border-[#00ffff]/20 p-8 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-mono text-xl font-bold text-white">FLINCH Franchise</h3>
              <Badge className="bg-[#00ffff]/10 border-[#00ffff]/30 text-[#00ffff] font-mono text-xs">PIONEER</Badge>
            </div>
            <p className="font-mono text-sm text-white/80">
              First NFT movie franchise by Cameron Van Hoy (2021). Community-owned cinematic franchise where NFT holders
              earn revenue and vote on creative decisions.
            </p>
            <div className="pt-4 border-t border-border/20 space-y-1">
              <p className="font-mono text-xs text-white/60">Cast: Daniel Zovatto, Tilda Cobham-Hervey</p>
              <p className="font-mono text-xs text-white/60">Collection: 58 ETH volume on OpenSea</p>
            </div>
          </Card>

          <Card className="glass-panel-enhanced border-[#daa520]/20 p-8 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-mono text-xl font-bold text-white">FFGCoin</h3>
              <Badge className="bg-[#daa520]/10 border-[#daa520]/30 text-[#daa520] font-mono text-xs">ERC-20</Badge>
            </div>
            <p className="font-mono text-sm text-white/80">
              Film Finance Group International's $FFG Token. Transparent, milestone-based film funding ecosystem on
              blockchain. Asset-backed token tied to real production deliverables.
            </p>
            <div className="pt-4 border-t border-border/20 space-y-1">
              <p className="font-mono text-xs text-white/60">Integrated governance mechanics</p>
              <p className="font-mono text-xs text-white/60">Vote on curated film projects</p>
              <p className="font-mono text-xs text-[#daa520]">@ffgcoin</p>
            </div>
          </Card>

          <Card className="glass-panel-enhanced border-[#b8860b]/20 p-8 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-mono text-xl font-bold text-white">Vox In / Coders Room</h3>
              <Badge className="bg-[#b8860b]/10 border-[#b8860b]/30 text-[#b8860b] font-mono text-xs">COLLECTIVE</Badge>
            </div>
            <p className="font-mono text-sm text-white/80">
              Global production collective founded by Luis Enrique Vanegas. Redefining collaboration in genre filmmaking
              with The Coders Room writers collective. Elena: First Latin American NFT film (2022).
            </p>
            <div className="pt-4 border-t border-border/20 space-y-1">
              <p className="font-mono text-xs text-white/60">Genre: Elevated Horror/Thriller</p>
              <p className="font-mono text-xs text-white/60">Film: El Círculo in production</p>
              <p className="font-mono text-xs text-[#b8860b]">voxin.xyz • @Coders_Room</p>
            </div>
          </Card>

          <Card className="glass-panel-enhanced border-[#00ffff]/20 p-8 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-mono text-xl font-bold text-white">AI Film 3 Awards</h3>
              <Badge className="bg-[#00ffff]/10 border-[#00ffff]/30 text-[#00ffff] font-mono text-xs">FESTIVAL</Badge>
            </div>
            <p className="font-mono text-sm text-white/80">
              Premier AI Film & Art Festival in Phoenix, Arizona. Celebrating AI-generated cinema, art, music, fashion,
              and gaming. Democratization of storytelling through technology.
            </p>
            <div className="pt-4 border-t border-border/20 space-y-1">
              <p className="font-mono text-xs text-white/60">2025 Winners: Echo Hunter, The Screenwriter</p>
              <p className="font-mono text-xs text-white/60">Prometheus Productions LLC</p>
              <p className="font-mono text-xs text-[#00ffff]">aifilm3.com • @AI_film_3</p>
            </div>
          </Card>

          <Card className="glass-panel-enhanced border-[#daa520]/20 p-8 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-mono text-xl font-bold text-white">WWCSFF</h3>
              <Badge className="bg-[#daa520]/10 border-[#daa520]/30 text-[#daa520] font-mono text-xs">
                UK FESTIVAL
              </Badge>
            </div>
            <p className="font-mono text-sm text-white/80">
              Worldwide Cineastes Film Festivals. UK NFT, New Media, Experimental Digital Arts. Supporting independent
              filmmakers and cutting-edge cinema.
            </p>
            <div className="pt-4 border-t border-border/20 space-y-1">
              <p className="font-mono text-xs text-white/60">Focus: Experimental Digital Arts</p>
              <p className="font-mono text-xs text-white/60">NFT Film Integration</p>
            </div>
          </Card>

          <Card className="glass-panel-enhanced border-[#b8860b]/20 p-8 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-mono text-xl font-bold text-white">MetaCannes Festival</h3>
              <Badge className="bg-[#b8860b]/10 border-[#b8860b]/30 text-[#b8860b] font-mono text-xs">ON-CHAIN</Badge>
            </div>
            <p className="font-mono text-sm text-white/80">
              First on-chain film festival. Founded 2023. First traditional festival to curate a GenAI Cinema program.
              Bridging Web2 and Web3 cinema communities.
            </p>
            <div className="pt-4 border-t border-border/20 space-y-1">
              <p className="font-mono text-xs text-white/60">GenAI Cinema Program Leader</p>
              <p className="font-mono text-xs text-white/60">Web3 + Traditional Cinema</p>
            </div>
          </Card>
        </div>

        <div className="text-center pt-8">
          <p className="font-mono text-sm text-white/70 mb-4">
            More Platforms: Bingeable • myco • Vabble • Mogul Productions • First Flights
          </p>
          <Button
            variant="outline"
            className="font-mono font-bold uppercase tracking-wider border-[#daa520]/50 bg-transparent text-[#daa520] hover:bg-[#daa520]/10"
          >
            Explore Full Ecosystem
          </Button>
        </div>
      </section>

      {/* Film3 Leaders Section */}
      <section className="max-w-7xl mx-auto px-4 py-16 space-y-12">
        <div className="text-center space-y-4">
          <h2 className="font-mono text-3xl font-bold chrome-text">#FILM3 PIONEERS</h2>
          <p className="font-mono text-sm text-white/80 max-w-2xl mx-auto">
            Filmmakers and leaders building the decentralized cinema movement
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="glass-panel-enhanced border-[#00ffff]/20 p-6 space-y-3">
            <div className="font-mono text-lg font-bold text-white">Roman Coppola</div>
            <p className="font-mono text-xs text-[#00ffff]">Co-founder, Decentralized Pictures</p>
            <p className="font-mono text-xs text-white/70">American Zoetrope. Building "the studio of the future"</p>
          </Card>

          <Card className="glass-panel-enhanced border-[#daa520]/20 p-6 space-y-3">
            <div className="font-mono text-lg font-bold text-white">Jordan Bayne</div>
            <p className="font-mono text-xs text-[#daa520]">Founder, The Squad</p>
            <p className="font-mono text-xs text-white/70">700+ Twitter Spaces. Originated #Film3. SquadPod creator</p>
          </Card>

          <Card className="glass-panel-enhanced border-[#b8860b]/20 p-6 space-y-3">
            <div className="font-mono text-lg font-bold text-white">Cameron Van Hoy</div>
            <p className="font-mono text-xs text-[#b8860b]">Director, Writer, Producer</p>
            <p className="font-mono text-xs text-white/70">FLINCH: First NFT movie franchise (2021)</p>
          </Card>

          <Card className="glass-panel-enhanced border-[#00ffff]/20 p-6 space-y-3">
            <div className="font-mono text-lg font-bold text-white">Stacy Spikes</div>
            <p className="font-mono text-xs text-[#00ffff]">MoviePass Co-founder</p>
            <p className="font-mono text-xs text-white/70">Coined "DeFiFi" (Decentralized Film Finance)</p>
          </Card>

          <Card className="glass-panel-enhanced border-[#daa520]/20 p-6 space-y-3">
            <div className="font-mono text-lg font-bold text-white">Luis Enrique Vanegas</div>
            <p className="font-mono text-xs text-[#daa520]">Founder, Vox In & Coders Room</p>
            <p className="font-mono text-xs text-white/70">Elena: First Latin American NFT film (2022)</p>
          </Card>

          <Card className="glass-panel-enhanced border-[#b8860b]/20 p-6 space-y-3">
            <div className="font-mono text-lg font-bold text-white">Cutter Hodierne</div>
            <p className="font-mono text-xs text-[#b8860b]">Director, Cold Wallet</p>
            <p className="font-mono text-xs text-white/70">Crypto thriller funded via Decentralized Pictures</p>
          </Card>

          <Card className="glass-panel-enhanced border-[#00ffff]/20 p-6 space-y-3">
            <div className="font-mono text-lg font-bold text-white">Julie Pacino</div>
            <p className="font-mono text-xs text-[#00ffff]">Director, I Live Here Now</p>
            <p className="font-mono text-xs text-white/70">NFT-funded feature (2022). Lynchian trauma exploration</p>
          </Card>

          <Card className="glass-panel-enhanced border-[#daa520]/20 p-6 space-y-3">
            <div className="font-mono text-lg font-bold text-white">Miguel Faus</div>
            <p className="font-mono text-xs text-[#daa520]">Director, Calladita</p>
            <p className="font-mono text-xs text-white/70">Goya-nominated. DCP completion fund by Soderbergh</p>
          </Card>

          <Card className="glass-panel-enhanced border-[#b8860b]/20 p-6 space-y-3">
            <div className="font-mono text-lg font-bold text-white">David Bianchi</div>
            <p className="font-mono text-xs text-[#b8860b]">Creator, RZR Series</p>
            <p className="font-mono text-xs text-white/70">Emmy-nominated (Mena Suvari). Exertion3 Films + Gala</p>
          </Card>

          <Card className="glass-panel-enhanced border-[#00ffff]/20 p-6 space-y-3">
            <div className="font-mono text-lg font-bold text-white">Sofia & Gia Coppola</div>
            <p className="font-mono text-xs text-[#00ffff]">American Zoetrope</p>
            <p className="font-mono text-xs text-white/70">Co-founders, Decentralized Pictures</p>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-5xl mx-auto px-4 py-20">
        <div className="glass-panel-enhanced rounded-lg p-12 border-2 border-[#daa520]/30 text-center space-y-6">
          <h2 className="font-mono text-3xl font-bold chrome-text">READY TO JOIN #FILM3?</h2>
          <p className="font-mono text-base text-white/90 max-w-2xl mx-auto">
            Join the decentralized cinema movement. No gatekeepers. No middlemen. Just you, your audience, and the
            blockchain.
          </p>
          <Button
            size="lg"
            className="font-mono font-bold uppercase tracking-wider text-white hover:opacity-90"
            style={{ background: "#daa520", boxShadow: "0 0 20px rgba(218, 165, 32, 0.5)" }}
          >
            Launch Your Film3 Project
          </Button>
        </div>
      </section>
    </VirtualSoundstage>
  )
}
