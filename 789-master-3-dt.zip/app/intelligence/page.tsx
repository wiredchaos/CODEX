import { Suspense } from "react"
import { SpacesIntelligencePanel } from "@/app/intelligence/components/spaces-intelligence-panel"
import { ApiKeySetup } from "@/app/intelligence/components/api-key-setup"
import { VirtualSoundstage } from "@/components/virtual-soundstage"
import { NavigationalAvatar } from "@/components/navigational-avatar"
import { BackButton } from "@/components/ui/back-button"
import Link from "next/link"

export const metadata = {
  title: "Spaces Intelligence | 789 Studios",
  description: "Real-time X Spaces analytics, coin sentiment tracking, and speaker insights powered by Lurky.app",
}

export default function IntelligencePage() {
  const hasApiKey = !!process.env.LURKY_API_KEY

  return (
    <VirtualSoundstage>
      <NavigationalAvatar />

      <div className="border-b border-border/30 bg-black/40 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <BackButton fallbackHref="/" />
            <Link
              href="/"
              className="font-mono text-xs font-bold"
              style={{ color: "#ffd700", textShadow: "0 0 10px rgba(255, 215, 0, 0.5)" }}
            >
              789
            </Link>
            <nav className="hidden md:flex items-center gap-4">
              <Link href="/" className="font-mono text-xs text-white/70 hover:text-white transition-colors">
                Home
              </Link>
              <Link href="/intelligence" className="font-mono text-xs text-white font-bold">
                Spaces Intel
              </Link>
            </nav>
          </div>
        </div>
      </div>

      <div className="min-h-screen px-4 py-8 md:px-8">
        <div className="mx-auto max-w-[1800px]">
          {/* Header */}
          <div className="mb-8 text-center">
            <h1
              className="mb-3 text-4xl font-bold text-white md:text-5xl"
              style={{ textShadow: "0 0 20px rgba(0,255,255,0.5), 0 0 40px rgba(0,255,255,0.3)" }}
            >
              Spaces Intelligence Panel
            </h1>
            <p className="text-lg text-white/70 md:text-xl" style={{ textShadow: "0 0 10px rgba(218,165,32,0.3)" }}>
              Real-time X Spaces analytics, coin sentiment radar, and speaker insights
            </p>
            <div className="mt-4 flex items-center justify-center gap-2">
              <div className="h-2 w-2 animate-pulse rounded-full bg-cyan-400" />
              <span className="text-sm text-cyan-400" style={{ textShadow: "0 0 10px rgba(0,255,255,0.5)" }}>
                Powered by Lurky.app
              </span>
            </div>
          </div>

          {!hasApiKey ? (
            <ApiKeySetup />
          ) : (
            <Suspense fallback={<LoadingSkeleton />}>
              <SpacesIntelligencePanel />
            </Suspense>
          )}
        </div>
      </div>
    </VirtualSoundstage>
  )
}

function LoadingSkeleton() {
  return (
    <div className="grid gap-6 lg:grid-cols-12">
      {/* Filters Skeleton */}
      <div className="lg:col-span-3">
        <div className="h-[600px] animate-pulse rounded-lg bg-white/5 backdrop-blur-md" />
      </div>

      {/* Table Skeleton */}
      <div className="lg:col-span-6">
        <div className="h-[600px] animate-pulse rounded-lg bg-white/5 backdrop-blur-md" />
      </div>

      {/* Sidebar Skeleton */}
      <div className="lg:col-span-3">
        <div className="h-[600px] animate-pulse rounded-lg bg-white/5 backdrop-blur-md" />
      </div>
    </div>
  )
}
