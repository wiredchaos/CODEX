"use client"

import { useEffect, useState } from "react"
import { Loader2, TrendingUp, TrendingDown, Info } from "lucide-react"
import Image from "next/image"

interface Coin {
  id: string
  symbol: string
  name: string
  image: string
  priceUsd: number
  priceChange24h: number
  marketCap: number
  mentions: {
    bullish: number
    neutral: number
    bearish: number
    total: number
    overallSentiment: string
  }
}

interface CoinsData {
  coins: Coin[]
  isDemo?: boolean
  message?: string
}

export function CoinSentimentPanel() {
  const [coins, setCoins] = useState<Coin[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [sortBy, setSortBy] = useState<"market_cap" | "mentions" | "sentiment">("mentions")
  const [isDemo, setIsDemo] = useState(false)

  useEffect(() => {
    const abortController = new AbortController()

    fetchCoins(abortController.signal)

    return () => {
      abortController.abort()
    }
  }, [sortBy])

  async function fetchCoins(signal?: AbortSignal) {
    setLoading(true)
    setError(null)
    try {
      const response = await fetch(`/api/lurky/coins-with-mentions?sort_by=${sortBy}&limit=8`, {
        signal,
      })
      if (!response.ok) {
        throw new Error(`API returned ${response.status}: ${response.statusText}`)
      }
      const data: CoinsData = await response.json()
      if (data && Array.isArray(data.coins)) {
        setCoins(data.coins)
        setIsDemo(data.isDemo || false)
      } else {
        console.error("[v0] Invalid coins data structure:", data)
        setCoins([])
        setError("Invalid data format received")
      }
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") {
        return
      }
      console.error("[v0] Failed to fetch coins:", error)
      setCoins([])
      setError(error instanceof Error ? error.message : "Failed to fetch coin data")
    } finally {
      setLoading(false)
    }
  }

  function handleRetry() {
    fetchCoins()
  }

  return (
    <div
      className="rounded-lg border border-goldenrod/20 bg-black/90 p-6 backdrop-blur-xl"
      style={{ boxShadow: "0 0 30px rgba(218,165,32,0.1)" }}
    >
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <h3 className="text-lg font-bold text-white" style={{ textShadow: "0 0 15px rgba(218,165,32,0.5)" }}>
            Coin Sentiment Radar
          </h3>
          {isDemo && (
            <div className="flex items-center gap-1 rounded-full border border-yellow-500/30 bg-yellow-500/10 px-2 py-0.5 text-[10px] text-yellow-400">
              <Info className="h-2.5 w-2.5" />
              <span>Demo</span>
            </div>
          )}
        </div>
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value as any)}
          className="rounded border border-white/20 bg-black/50 px-2 py-1 text-xs text-white"
        >
          <option value="market_cap">Market Cap</option>
          <option value="mentions">Mentions</option>
          <option value="sentiment">Sentiment</option>
        </select>
      </div>

      {loading ? (
        <div className="flex h-40 items-center justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-goldenrod" />
        </div>
      ) : error ? (
        <div className="flex h-40 flex-col items-center justify-center gap-3 text-center">
          <p className="text-sm text-red-400" style={{ textShadow: "0 0 10px rgba(255,0,0,0.3)" }}>
            {error}
          </p>
          <button
            onClick={handleRetry}
            className="rounded-lg border border-cyan-400/30 bg-cyan-400/10 px-4 py-2 text-sm text-cyan-400 transition-all hover:bg-cyan-400/20"
            style={{ textShadow: "0 0 10px rgba(0,255,255,0.5)" }}
          >
            Retry
          </button>
        </div>
      ) : coins.length === 0 ? (
        <div className="flex h-40 items-center justify-center">
          <p className="text-sm text-white/60" style={{ textShadow: "0 0 10px rgba(255,255,255,0.2)" }}>
            No coin mentions found
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {coins.map((coin) => (
            <div key={coin.id} className="rounded-lg border border-white/10 bg-white/5 p-3">
              <div className="mb-2 flex items-center gap-3">
                <Image
                  src={coin.image || "/placeholder.svg"}
                  alt={coin.name}
                  width={32}
                  height={32}
                  className="rounded-full"
                />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-white" style={{ textShadow: "0 0 10px rgba(218,165,32,0.5)" }}>
                      {coin.symbol}
                    </span>
                    <span className="text-xs text-white/60">{coin.name}</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-white/80">${coin.priceUsd.toFixed(4)}</span>
                    <span
                      className={`flex items-center gap-1 ${
                        coin.priceChange24h >= 0 ? "text-green-400" : "text-red-400"
                      }`}
                    >
                      {coin.priceChange24h >= 0 ? (
                        <TrendingUp className="h-3 w-3" />
                      ) : (
                        <TrendingDown className="h-3 w-3" />
                      )}
                      {Math.abs(coin.priceChange24h).toFixed(2)}%
                    </span>
                  </div>
                </div>
              </div>

              <div className="mb-2">
                <div className="mb-1 flex justify-between text-xs">
                  <span className="text-white/60">{coin.mentions.total} mentions</span>
                  <span className="capitalize text-cyan-400" style={{ textShadow: "0 0 5px rgba(0,255,255,0.5)" }}>
                    {coin.mentions.overallSentiment}
                  </span>
                </div>
                <div className="flex h-2 overflow-hidden rounded-full">
                  <div
                    className="bg-green-500"
                    style={{
                      width: `${(coin.mentions.bullish / coin.mentions.total) * 100}%`,
                    }}
                  />
                  <div
                    className="bg-gray-500"
                    style={{
                      width: `${(coin.mentions.neutral / coin.mentions.total) * 100}%`,
                    }}
                  />
                  <div
                    className="bg-red-500"
                    style={{
                      width: `${(coin.mentions.bearish / coin.mentions.total) * 100}%`,
                    }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
