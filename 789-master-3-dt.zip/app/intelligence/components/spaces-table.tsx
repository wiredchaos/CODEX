"use client"

import { useEffect, useState } from "react"
import { Loader2, ExternalLink, Info } from "lucide-react"
import { Button } from "@/components/ui/button"

interface Space {
  id: string
  title: string
  creatorHandle: string
  startedAt?: number
  endedAt?: number
  participantCount?: number
  categories?: string[]
  state: string
  summary?: string
}

interface SpacesData {
  spaces: Space[]
  isDemo?: boolean
  message?: string
}

export function SpacesTable({ filters }: { filters: any }) {
  const [spaces, setSpaces] = useState<Space[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedSpace, setSelectedSpace] = useState<Space | null>(null)
  const [page, setPage] = useState(0)
  const [limit, setLimit] = useState(10)
  const [isDemo, setIsDemo] = useState(false)

  useEffect(() => {
    const abortController = new AbortController()

    fetchSpaces(abortController.signal)

    return () => {
      abortController.abort()
    }
  }, [filters, page, limit])

  async function fetchSpaces(signal?: AbortSignal) {
    setLoading(true)
    setError(null)

    try {
      const params = new URLSearchParams({
        state: filters.states.join(","),
        categories: filters.categories.join(","),
        page: page.toString(),
        limit: limit.toString(),
      })

      const response = await fetch(`/api/lurky/spaces?${params}`, {
        signal,
      })
      const data: SpacesData = await response.json()

      if (!response.ok) {
        throw new Error((data as any).error || "Failed to load spaces")
      }

      setSpaces(data.spaces || [])
      setIsDemo(data.isDemo || false)
    } catch (err: any) {
      if (err.name === "AbortError") {
        return
      }
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  function handleRetry() {
    fetchSpaces()
  }

  if (loading) {
    return (
      <div
        className="flex h-[600px] items-center justify-center rounded-lg border border-cyan-500/20 bg-black/90 backdrop-blur-xl"
        style={{ boxShadow: "0 0 30px rgba(0,255,255,0.1)" }}
      >
        <Loader2 className="h-8 w-8 animate-spin text-cyan-400" />
      </div>
    )
  }

  if (error) {
    return (
      <div
        className="flex h-[600px] items-center justify-center rounded-lg border border-red-500/20 bg-black/90 p-6 text-center backdrop-blur-xl"
        style={{ boxShadow: "0 0 30px rgba(255,0,0,0.1)" }}
      >
        <div>
          <p className="text-red-400" style={{ textShadow: "0 0 10px rgba(255,0,0,0.5)" }}>
            {error}
          </p>
          <Button onClick={handleRetry} className="mt-4 bg-transparent" variant="outline">
            Retry
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div
      className="rounded-lg border border-cyan-500/20 bg-black/90 backdrop-blur-xl"
      style={{ boxShadow: "0 0 30px rgba(0,255,255,0.1)" }}
    >
      <div className="p-6">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-xl font-bold text-white" style={{ textShadow: "0 0 15px rgba(0,255,255,0.5)" }}>
            X Spaces ({spaces.length})
          </h3>
          {isDemo && (
            <div className="flex items-center gap-2 rounded-full border border-yellow-500/30 bg-yellow-500/10 px-3 py-1 text-xs text-yellow-400">
              <Info className="h-3 w-3" />
              <span style={{ textShadow: "0 0 5px rgba(218,165,32,0.5)" }}>Demo Data</span>
            </div>
          )}
        </div>

        <div className="space-y-3">
          {spaces.map((space) => (
            <button
              key={space.id}
              onClick={() => setSelectedSpace(space)}
              className="w-full rounded-lg border border-white/10 bg-white/5 p-4 text-left transition-all hover:border-cyan-500/30 hover:bg-white/10"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <h4 className="mb-2 font-semibold text-white" style={{ textShadow: "0 0 10px rgba(218,165,32,0.5)" }}>
                    {space.title}
                  </h4>
                  <div className="mb-2 flex flex-wrap items-center gap-2 text-xs text-white/60">
                    <span style={{ textShadow: "0 0 5px rgba(0,255,255,0.3)" }}>@{space.creatorHandle}</span>
                    <span>•</span>
                    <span>{space.participantCount || 0} participants</span>
                    <span>•</span>
                    <span className="capitalize">{space.state}</span>
                  </div>
                  {space.categories && space.categories.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {space.categories.map((cat) => (
                        <span
                          key={cat}
                          className="rounded-full bg-cyan-500/20 px-2 py-1 text-xs text-cyan-400"
                          style={{ textShadow: "0 0 5px rgba(0,255,255,0.5)" }}
                        >
                          {cat}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <ExternalLink className="h-4 w-4 flex-shrink-0 text-white/40" />
              </div>
            </button>
          ))}
        </div>

        {/* Pagination */}
        <div className="mt-6 flex items-center justify-between border-t border-white/10 pt-4">
          <Button
            onClick={() => setPage(Math.max(0, page - 1))}
            disabled={page === 0}
            variant="outline"
            size="sm"
            className="border-white/20 text-white hover:bg-white/10"
          >
            Previous
          </Button>
          <span className="text-sm text-white/60" style={{ textShadow: "0 0 5px rgba(0,255,255,0.3)" }}>
            Page {page + 1}
          </span>
          <Button
            onClick={() => setPage(page + 1)}
            disabled={spaces.length < limit}
            variant="outline"
            size="sm"
            className="border-white/20 text-white hover:bg-white/10"
          >
            Next
          </Button>
        </div>
      </div>

      {/* Space Detail Drawer */}
      {selectedSpace && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
          <div
            className="max-h-[80vh] w-full max-w-2xl overflow-y-auto rounded-lg border border-cyan-500/30 bg-black/95 p-8 backdrop-blur-xl"
            style={{ boxShadow: "0 0 50px rgba(0,255,255,0.2)" }}
          >
            <div className="mb-6 flex items-start justify-between">
              <h3 className="text-2xl font-bold text-white" style={{ textShadow: "0 0 20px rgba(218,165,32,0.5)" }}>
                {selectedSpace.title}
              </h3>
              <button onClick={() => setSelectedSpace(null)} className="text-white/60 hover:text-white">
                ✕
              </button>
            </div>

            {selectedSpace.summary && (
              <div
                className="prose prose-invert mb-6 text-white/80"
                style={{ textShadow: "0 0 5px rgba(0,255,255,0.2)" }}
              >
                <p>{selectedSpace.summary}</p>
              </div>
            )}

            <div className="flex flex-wrap gap-4 text-sm text-white/60">
              <span style={{ textShadow: "0 0 5px rgba(0,255,255,0.3)" }}>@{selectedSpace.creatorHandle}</span>
              <span>•</span>
              <span>{selectedSpace.participantCount || 0} participants</span>
              <span>•</span>
              <span className="capitalize">{selectedSpace.state}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
