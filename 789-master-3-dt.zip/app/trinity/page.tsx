"use client"

import { useState, useCallback } from "react"
import dynamic from "next/dynamic"
import type { DoorState } from "@/components/trinity/use-door-controller"
import { ElevatorDock } from "@/components/trinity/elevator-dock"
import { FLOOR_REGISTRY } from "@/lib/trinity/logic"
import { GlassSurface } from "@/lib/core/ui-glass/glass-surface"

// Dynamic import for 3D component (no SSR)
const ElevatorDoors = dynamic(() => import("@/components/trinity/elevator-doors").then((mod) => mod.ElevatorDoors), {
  ssr: false,
})

export default function TrinityPage() {
  const [doorState, setDoorState] = useState<DoorState>("CLOSED")
  const [currentFloor, setCurrentFloor] = useState("Lobby")
  const [eventLog, setEventLog] = useState<string[]>([])

  const logEvent = useCallback((event: string) => {
    setEventLog((prev) => [...prev.slice(-9), `${new Date().toLocaleTimeString()}: ${event}`])
  }, [])

  const handleOpenStart = useCallback(() => {
    logEvent("Doors opening...")
    // Stub: play open.wav
  }, [logEvent])

  const handleOpenEnd = useCallback(() => {
    logEvent("Doors open")
  }, [logEvent])

  const handleCloseStart = useCallback(() => {
    logEvent("Doors closing...")
    // Stub: play close.wav
  }, [logEvent])

  const handleCloseEnd = useCallback(() => {
    logEvent("Doors closed")
  }, [logEvent])

  const handleFloorSelect = useCallback(
    (floorId: string) => {
      const floor = FLOOR_REGISTRY.find((f) => f.id === floorId)
      if (floor) {
        setCurrentFloor(floor.name)
        logEvent(`Selected: ${floor.name}`)
        // Stub: play ding.wav
      }
    },
    [logEvent],
  )

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-gray-900 to-black">
      {/* Header */}
      <div className="fixed top-0 left-0 right-0 z-50 p-4">
        <GlassSurface blur="heavy" opacity="medium" className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between p-4">
            <div>
              <h1 className="text-2xl font-bold text-white">Trinity Elevator System</h1>
              <p className="text-sm text-white/60 font-mono">3D Door Controller Demo</p>
            </div>
            <div className="text-right">
              <div className="text-xs font-mono text-cyan-400">CURRENT FLOOR</div>
              <div className="text-lg font-bold text-white">{currentFloor}</div>
            </div>
          </div>
        </GlassSurface>
      </div>

      {/* 3D Elevator View */}
      <div className="pt-24 pb-8 px-4">
        <div className="max-w-4xl mx-auto">
          <GlassSurface blur="heavy" opacity="medium" border="glow" glow="accent">
            <div className="aspect-video">
              <ElevatorDoors
                currentFloor={currentFloor}
                onOpenStart={handleOpenStart}
                onOpenEnd={handleOpenEnd}
                onCloseStart={handleCloseStart}
                onCloseEnd={handleCloseEnd}
                autoClose={true}
              />
            </div>
          </GlassSurface>
        </div>
      </div>

      {/* Event Log */}
      <div className="px-4 pb-32">
        <div className="max-w-4xl mx-auto">
          <GlassSurface blur="medium" opacity="light">
            <div className="p-4">
              <h2 className="text-sm font-mono text-cyan-400 mb-2">EVENT LOG</h2>
              <div className="space-y-1 font-mono text-xs">
                {eventLog.length === 0 ? (
                  <p className="text-white/30">No events yet. Use the dock to control doors.</p>
                ) : (
                  eventLog.map((event, i) => (
                    <div key={i} className="text-white/70">
                      {event}
                    </div>
                  ))
                )}
              </div>
            </div>
          </GlassSurface>
        </div>
      </div>

      {/* Elevator Control Dock */}
      <ElevatorDock onStateChange={setDoorState} onFloorSelect={handleFloorSelect} />
    </div>
  )
}
