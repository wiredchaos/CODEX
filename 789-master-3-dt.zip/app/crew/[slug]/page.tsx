"use client"

import { VirtualSoundstage } from "@/components/virtual-soundstage"
import { NavigationalAvatar } from "@/components/navigational-avatar"
import { GlobalDisclaimer } from "@/components/global-disclaimer"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { getCrewColor } from "@/lib/crew-colors"
import { getCrewMember } from "@/lib/crew-config"
import Link from "next/link"
import { Radio, Calendar, Users, Sparkles, ExternalLink, Instagram, Youtube, MessageCircle } from "lucide-react"
import { useParams } from "next/navigation"
import { BackButton } from "@/components/ui/back-button"
import { notFound } from "next/navigation"

export default function CrewMemberPage() {
  const params = useParams()
  const slug = params.slug as string

  const member = getCrewMember(slug)

  if (!member) {
    notFound()
  }

  const crewColor = getCrewColor(member.name)

  return (
    <VirtualSoundstage>
      <NavigationalAvatar />

      {/* Navigation */}
      <div className="border-b border-border/30 bg-black/40 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <BackButton fallbackHref="/crew" />
            <Link
              href="/"
              className="font-mono text-xs font-bold"
              style={{ color: "#ffd700", textShadow: "0 0 10px rgba(255, 215, 0, 0.5)" }}
            >
              789
            </Link>
            <nav className="hidden md:flex items-center gap-4">
              <Link href="/" className="font-mono text-xs text-white/70 hover:text-white transition-colors">
                Home
              </Link>
              <Link href="/crew" className="font-mono text-xs text-white/70 hover:text-white transition-colors">
                Crew
              </Link>
              <Link href={`/crew/${slug}`} className="font-mono text-xs text-white font-bold">
                {member.name}
              </Link>
            </nav>
          </div>
        </div>
      </div>

      {/* Hero Section - Chirp Style */}
      <section className="relative py-12 px-4">
        <div className="max-w-2xl mx-auto text-center">
          {/* Avatar */}
          <div
            className="w-32 h-32 mx-auto rounded-full border-4 overflow-hidden relative mb-6"
            style={{
              borderColor: crewColor.primary,
              boxShadow: `0 0 40px ${crewColor.glow}`,
            }}
          >
            <img src={member.avatar || "/placeholder.svg"} alt={member.name} className="w-full h-full object-cover" />
            <div className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-[#ffd700] border-2 border-black flex items-center justify-center">
              <span className="text-sm">🐕</span>
            </div>
          </div>

          {/* Handle & Tagline */}
          <h1
            className="text-3xl font-bold mb-2"
            style={{ color: crewColor.primary, textShadow: `0 0 20px ${crewColor.glow}` }}
          >
            {member.handle}
          </h1>

          <p
            className="font-mono text-sm text-white/90 mb-6 leading-relaxed"
            style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.3)" }}
          >
            {member.tagline}
          </p>

          {/* Social Links Row - Chirp Style */}
          <div className="flex flex-wrap justify-center gap-3 mb-8">
            {member.socialLinks.instagram && (
              <Button
                className="font-mono text-xs"
                style={{
                  background: "linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888)",
                  color: "white",
                  textShadow: "0 0 5px rgba(255, 255, 255, 0.5)",
                }}
                asChild
              >
                <a href={member.socialLinks.instagram} target="_blank" rel="noopener noreferrer">
                  <Instagram className="w-4 h-4 mr-2" />
                  Dive in Instagram content!
                </a>
              </Button>
            )}

            {member.socialLinks.tiktok && (
              <Button
                className="font-mono text-xs bg-black border border-white/30 text-white hover:bg-white/10"
                asChild
              >
                <a href={member.socialLinks.tiktok} target="_blank" rel="noopener noreferrer">
                  Find out more on TikTok
                </a>
              </Button>
            )}

            {member.socialLinks.x && (
              <Button
                className="font-mono text-xs bg-black border border-cyan/50 text-cyan hover:bg-cyan/10"
                style={{ textShadow: "0 0 10px rgba(0, 255, 255, 0.5)" }}
                asChild
              >
                <a href={member.socialLinks.x} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  See more on X
                </a>
              </Button>
            )}

            {member.socialLinks.youtube && (
              <Button className="font-mono text-xs bg-red-600 text-white hover:bg-red-700" asChild>
                <a href={member.socialLinks.youtube} target="_blank" rel="noopener noreferrer">
                  <Youtube className="w-4 h-4 mr-2" />
                  Must-see YouTube!
                </a>
              </Button>
            )}

            {member.socialLinks.threads && (
              <Button
                className="font-mono text-xs bg-black border border-white/30 text-white hover:bg-white/10"
                asChild
              >
                <a href={member.socialLinks.threads} target="_blank" rel="noopener noreferrer">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Don't miss my Threads!
                </a>
              </Button>
            )}

            {member.socialLinks.chirp && (
              <Button
                className="font-mono text-xs"
                style={{
                  background: crewColor.primary,
                  color: "#000",
                  boxShadow: `0 0 15px ${crewColor.glow}`,
                }}
                asChild
              >
                <a href={member.socialLinks.chirp} target="_blank" rel="noopener noreferrer">
                  View Chirp Profile
                </a>
              </Button>
            )}
          </div>

          {/* Coming Soon for non-content creators */}
          {!member.hasContent && (
            <div className="glass-panel rounded-lg p-6 border border-goldenrod/30 mb-8">
              <p
                className="font-mono text-sm text-goldenrod"
                style={{ textShadow: "0 0 10px rgba(218, 165, 32, 0.5)" }}
              >
                Content Coming Soon — {member.name} will be creating content on 789 Studios
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Feature Section - For NEURO */}
      {member.featureSection && (
        <section className="max-w-3xl mx-auto px-4 py-8">
          <Card className="glass-panel-enhanced border-2 p-8" style={{ borderColor: `${crewColor.primary}40` }}>
            <h2
              className="font-mono text-2xl font-bold mb-4"
              style={{ color: crewColor.primary, textShadow: `0 0 15px ${crewColor.glow}` }}
            >
              {member.featureSection.title}
            </h2>
            <p
              className="font-mono text-sm text-white/80 mb-6 leading-relaxed"
              style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
            >
              {member.featureSection.description}
            </p>

            <div className="mb-6">
              <p
                className="font-mono text-xs text-white/60 mb-3"
                style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
              >
                Weekly drops include:
              </p>
              <ul className="space-y-2">
                {member.featureSection.features.map((feature: string, index: number) => (
                  <li key={index} className="flex items-center gap-3">
                    <div
                      className="w-2 h-2 rounded-full"
                      style={{
                        background: crewColor.primary,
                        boxShadow: `0 0 10px ${crewColor.glow}`,
                      }}
                    />
                    <span
                      className="font-mono text-sm text-white/90"
                      style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
                    >
                      {feature}
                    </span>
                  </li>
                ))}
              </ul>
            </div>

            <p
              className="font-mono text-xs text-white/70 italic"
              style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
            >
              {member.featureSection.tagline}
            </p>
          </Card>
        </section>
      )}

      {/* Anti-Moloch Section */}
      {member.antiMoloch && (
        <section className="max-w-3xl mx-auto px-4 py-4">
          <Card className="glass-panel border border-goldenrod/30 p-6">
            <h3
              className="font-mono text-sm font-bold text-goldenrod mb-2"
              style={{ textShadow: "0 0 10px rgba(218, 165, 32, 0.5)" }}
            >
              Anti-Moloch Design Philosophy
            </h3>
            <p
              className="font-mono text-xs text-white/80 leading-relaxed"
              style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
            >
              {member.antiMoloch}
            </p>
          </Card>
        </section>
      )}

      {/* Bio Section */}
      <section className="max-w-3xl mx-auto px-4 py-8">
        <Card className="glass-panel-enhanced border-2 p-8" style={{ borderColor: `${crewColor.primary}40` }}>
          <div className="flex items-center gap-3 mb-4">
            <Badge
              className="font-mono text-xs uppercase"
              style={{
                background: `${crewColor.primary}20`,
                color: crewColor.primary,
                borderColor: `${crewColor.primary}50`,
                textShadow: `0 0 10px ${crewColor.glow}`,
              }}
            >
              <Radio className="w-3 h-3 mr-1" />
              789 CREW · {member.time}
            </Badge>
          </div>
          <p
            className="font-mono text-sm text-white/80 leading-relaxed"
            style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
          >
            {member.bio}
          </p>
        </Card>
      </section>

      {/* Achievements */}
      <section className="max-w-3xl mx-auto px-4 py-8">
        <Card className="glass-panel-enhanced border-2 p-8" style={{ borderColor: `${crewColor.primary}40` }}>
          <div className="flex items-center gap-3 mb-6">
            <Sparkles className="w-6 h-6" style={{ color: crewColor.primary }} />
            <h2
              className="font-mono text-xl font-bold text-white"
              style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.3)" }}
            >
              ACHIEVEMENTS
            </h2>
          </div>
          <ul className="space-y-3">
            {member.achievements.map((achievement: string, index: number) => (
              <li key={index} className="flex items-start gap-3">
                <div
                  className="w-2 h-2 rounded-full mt-2 flex-shrink-0"
                  style={{
                    background: crewColor.primary,
                    boxShadow: `0 0 10px ${crewColor.glow}`,
                  }}
                />
                <span
                  className="font-mono text-sm text-white/90"
                  style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
                >
                  {achievement}
                </span>
              </li>
            ))}
          </ul>
        </Card>
      </section>

      {/* Space Topics */}
      <section className="max-w-3xl mx-auto px-4 py-8">
        <Card className="glass-panel-enhanced border-2 p-8" style={{ borderColor: `${crewColor.primary}40` }}>
          <div className="flex items-center gap-3 mb-6">
            <Calendar className="w-6 h-6" style={{ color: crewColor.primary }} />
            <h2
              className="font-mono text-xl font-bold text-white"
              style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.3)" }}
            >
              SPACE TOPICS
            </h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {member.spaces.map((topic: string, index: number) => (
              <Badge
                key={index}
                className="font-mono text-xs"
                style={{
                  background: `${crewColor.primary}20`,
                  color: crewColor.primary,
                  borderColor: `${crewColor.primary}50`,
                  textShadow: `0 0 5px ${crewColor.glow}`,
                }}
              >
                {topic}
              </Badge>
            ))}
          </div>
        </Card>
      </section>

      {/* Projects */}
      {member.projects && member.projects.length > 0 && (
        <section className="max-w-3xl mx-auto px-4 py-8">
          <Card className="glass-panel-enhanced border-2 p-8" style={{ borderColor: `${crewColor.primary}40` }}>
            <div className="flex items-center gap-3 mb-6">
              <Users className="w-6 h-6" style={{ color: crewColor.primary }} />
              <h2
                className="font-mono text-xl font-bold text-white"
                style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.3)" }}
              >
                FEATURED PROJECTS
              </h2>
            </div>
            <div className="space-y-4">
              {member.projects.map((project: any, index: number) => (
                <Card
                  key={index}
                  className="glass-panel p-6 space-y-3 border"
                  style={{ borderColor: `${crewColor.primary}40` }}
                >
                  <h3
                    className="font-mono text-lg font-bold text-white"
                    style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.3)" }}
                  >
                    {project.title}
                  </h3>
                  <p
                    className="font-mono text-sm text-white/80"
                    style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
                  >
                    {project.description}
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    className="font-mono bg-transparent"
                    style={{
                      borderColor: crewColor.primary,
                      color: crewColor.primary,
                      textShadow: `0 0 5px ${crewColor.glow}`,
                    }}
                    asChild
                  >
                    <Link href={project.link}>View Project →</Link>
                  </Button>
                </Card>
              ))}
            </div>
          </Card>
        </section>
      )}

      {/* Action Panel */}
      <section className="max-w-3xl mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 gap-4">
          <Button
            size="lg"
            className="font-mono font-bold uppercase tracking-wider w-full"
            style={{
              background: crewColor.primary,
              color: "#000",
              boxShadow: `0 0 20px ${crewColor.glow}`,
            }}
            asChild
          >
            <a href={member.socialLinks.x} target="_blank" rel="noopener noreferrer">
              Join My X Spaces
            </a>
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="font-mono font-bold uppercase tracking-wider w-full bg-transparent"
            style={{
              borderColor: crewColor.primary,
              color: crewColor.primary,
              textShadow: `0 0 5px ${crewColor.glow}`,
            }}
            asChild
          >
            <Link href="/pricing">Book Studio Time / Collab</Link>
          </Button>
        </div>
      </section>

      <GlobalDisclaimer />
    </VirtualSoundstage>
  )
}
