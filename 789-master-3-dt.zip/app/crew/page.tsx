"use client"

import { VirtualSoundstage } from "@/components/virtual-soundstage"
import { NavigationalAvatar } from "@/components/navigational-avatar"
import { CrewShowcase } from "@/components/crew-showcase"
import { LurkyIntegration } from "@/components/lurky-integration"
import { GlobalDisclaimer } from "@/components/global-disclaimer"
import Link from "next/link"
import { Users, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import { BackButton } from "@/components/ui/back-button"

export default function CrewPage() {
  return (
    <VirtualSoundstage>
      <NavigationalAvatar />

      {/* Navigation */}
      <div className="border-b border-border/30 bg-black/40 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <BackButton fallbackHref="/" />
            <Link
              href="/"
              className="font-mono text-xs font-bold"
              style={{ color: "#ffd700", textShadow: "0 0 10px rgba(255, 215, 0, 0.5)" }}
            >
              789
            </Link>
            <nav className="hidden md:flex items-center gap-4">
              <Link
                href="/"
                className="font-mono text-xs text-white/70 hover:text-white transition-colors"
                style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.3)" }}
              >
                Home
              </Link>
              <Link
                href="/crew"
                className="font-mono text-xs text-white font-bold"
                style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.5)" }}
              >
                Crew
              </Link>
              <Link
                href="/allies"
                className="font-mono text-xs text-white/70 hover:text-white transition-colors"
                style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.3)" }}
              >
                Allies & DAOs
              </Link>
              <Link
                href="/spaces"
                className="font-mono text-xs text-white/70 hover:text-white transition-colors"
                style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.3)" }}
              >
                Spaces Network
              </Link>
            </nav>
          </div>
          <Button
            size="sm"
            className="font-mono text-xs font-bold bg-cyan text-white hover:bg-cyan/80"
            style={{ boxShadow: "0 0 15px rgba(0, 255, 255, 0.5)" }}
            asChild
          >
            <a href="https://x.com/789studiosonx" target="_blank" rel="noopener noreferrer">
              <ExternalLink className="w-3 h-3 mr-1" />
              @789studiosonx
            </a>
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-12">
          <h1
            className="text-4xl md:text-6xl font-bold text-white mb-4"
            style={{ textShadow: "0 0 20px rgba(255, 255, 255, 0.3)" }}
          >
            789 CREW
          </h1>
          <p
            className="font-mono text-lg text-white/80 max-w-2xl mx-auto mb-6"
            style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.2)" }}
          >
            Meet the creators, producers, hosts, and builders who power 789 Studios. Each profile is a live link-in-bio
            hub for their Web3, content, and studio work.
          </p>

          {/* Link to Allies */}
          <Link
            href="/allies"
            className="inline-flex items-center gap-2 font-mono text-sm text-goldenrod hover:text-white transition-colors"
            style={{ textShadow: "0 0 10px rgba(218, 165, 32, 0.5)" }}
          >
            <Users className="w-4 h-4" />
            View Allies & Partner DAOs →
          </Link>
        </div>

        <CrewShowcase />

        {/* Lurky integration section */}
        <div className="mt-16">
          <LurkyIntegration />
        </div>
      </div>

      <GlobalDisclaimer />
    </VirtualSoundstage>
  )
}
