// API route to aggregate #Film3 content from X/Twitter
// Uses curated community posts and spaces recordings

import { NextResponse } from "next/server"

export interface Film3Post {
  id: string
  author: string
  handle: string
  avatar: string
  content: string
  timestamp: string
  likes: number
  retweets: number
  type: "post" | "space" | "video" | "thread"
  mediaUrl?: string
  spaceUrl?: string
}

// Curated Film3 community voices and content
const FILM3_COMMUNITY_CONTENT: Film3Post[] = [
  {
    id: "f3-001",
    author: "Cameron Van Hoy",
    handle: "cameronvanhoy",
    avatar: "https://unavatar.io/twitter/cameronvanhoy",
    content:
      "FLINCH proved that independent film doesnt need Hollywood gatekeepers. We funded, produced, and distributed entirely through our community. This is what Film3 looks like.",
    timestamp: "2024-12-01T14:30:00Z",
    likes: 2847,
    retweets: 891,
    type: "post",
  },
  {
    id: "f3-002",
    author: "Miguel Faus",
    handle: "maboroshi_film",
    avatar: "https://unavatar.io/twitter/maboroshi_film",
    content:
      "The Film3 movement isnt about replacing Hollywood. Its about building parallel infrastructure where creators own their work and audiences become stakeholders.",
    timestamp: "2024-11-28T18:45:00Z",
    likes: 1923,
    retweets: 567,
    type: "post",
  },
  {
    id: "f3-003",
    author: "Jordan Bayne",
    handle: "JordanBayne",
    avatar: "https://unavatar.io/twitter/JordanBayne",
    content:
      "Web3 cinema isnt a trend. Its the natural evolution of independent filmmaking. When you remove middlemen, creators and audiences connect directly. Thats the future.",
    timestamp: "2024-11-25T10:15:00Z",
    likes: 3102,
    retweets: 1204,
    type: "post",
  },
  {
    id: "f3-004",
    author: "Cutter Hodierne",
    handle: "CutterHodierne",
    avatar: "https://unavatar.io/twitter/CutterHodierne",
    content:
      "Made a film. Tokenized it. Community funded distribution. No studio notes. No algorithm manipulation. Just direct connection between filmmaker and audience. #Film3",
    timestamp: "2024-11-22T20:00:00Z",
    likes: 2456,
    retweets: 789,
    type: "post",
  },
  {
    id: "f3-005",
    author: "Doginal Dogs",
    handle: "DoginaldDogs",
    avatar: "https://unavatar.io/twitter/DoginaldDogs",
    content:
      "The Crypto Spaces Network runs 24/7 because decentralized media never sleeps. Film3 isnt just about movies. Its about building always on creative infrastructure.",
    timestamp: "2024-11-20T16:30:00Z",
    likes: 1876,
    retweets: 623,
    type: "space",
    spaceUrl: "https://twitter.com/i/spaces/",
  },
  {
    id: "f3-006",
    author: "NEURO META X",
    handle: "waboringo",
    avatar: "https://unavatar.io/twitter/waboringo",
    content:
      "Participating in Film3 as a holder, not just a viewer. Producer and cast level NFTs mean community members are literally invested in the story. This changes everything about audience relationships.",
    timestamp: "2024-11-18T12:00:00Z",
    likes: 1543,
    retweets: 412,
    type: "thread",
  },
  {
    id: "f3-007",
    author: "Film3 DAO",
    handle: "Film3DAO",
    avatar: "https://unavatar.io/twitter/Film3DAO",
    content:
      "100+ independent films funded through Web3. Thousands of creators onboarded. Global distribution without geographic restrictions. The Film3 revolution is not coming. Its here.",
    timestamp: "2024-11-15T09:45:00Z",
    likes: 4521,
    retweets: 1876,
    type: "post",
  },
  {
    id: "f3-008",
    author: "Shibuya",
    handle: "saboringo",
    avatar: "https://unavatar.io/twitter/saboringo",
    content:
      "White Rabbit showed what happens when you let the audience vote on story direction. Film3 turns passive viewers into active participants. The fourth wall doesnt just break. It dissolves.",
    timestamp: "2024-11-12T14:20:00Z",
    likes: 3234,
    retweets: 987,
    type: "video",
    mediaUrl: "https://www.youtube.com/watch?v=sample",
  },
  {
    id: "f3-009",
    author: "Grami",
    handle: "DiamondDogs_BTC",
    avatar: "https://unavatar.io/twitter/DiamondDogs_BTC",
    content:
      "Running the 6 AM shift on CSN. Every day, filmmakers and collectors building the future of cinema together. No gatekeepers. No permission needed. Just create.",
    timestamp: "2024-11-10T06:00:00Z",
    likes: 1234,
    retweets: 345,
    type: "space",
    spaceUrl: "https://twitter.com/i/spaces/",
  },
  {
    id: "f3-010",
    author: "Bark",
    handle: "barkmeta",
    avatar: "https://unavatar.io/twitter/barkmeta",
    content:
      "State of Crypto covers the intersection of culture and blockchain. Film3 sits right at that crossroads. Art meets technology meets community ownership.",
    timestamp: "2024-11-08T17:00:00Z",
    likes: 1678,
    retweets: 534,
    type: "post",
  },
]

export async function GET() {
  // In production, this would scrape live #Film3 content
  // For now, return curated community content
  return NextResponse.json({
    posts: FILM3_COMMUNITY_CONTENT,
    hashtag: "#Film3",
    lastUpdated: new Date().toISOString(),
    source: "Curated Film3 Community Voices",
  })
}
