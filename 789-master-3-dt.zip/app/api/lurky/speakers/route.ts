import { type NextRequest, NextResponse } from "next/server"

export const runtime = "edge"

const FEATURED_SPEAKERS = [
  {
    twitterId: "1",
    handle: "789Vibes",
    name: "VIBES",
    image: "/crew/vibes-avatar.png",
    description: "789 Studios Co-Founder & Creative Director",
    verified: true,
    verifiedType: "blue" as const,
    followersCount: 15000,
    role: "Host",
  },
  {
    twitterId: "2",
    handle: "WookiDoginal",
    name: "WOOKI",
    image: "/crew/wooki-avatar.png",
    description: "Doginal Dogs Founder & Web3 Advisor",
    verified: true,
    verifiedType: "blue" as const,
    followersCount: 25000,
    role: "Co-Host",
  },
  {
    twitterId: "3",
    handle: "NeuroMetaX",
    name: "NEURO",
    image: "/crew/neuro-avatar.png",
    description: "AI Content & Web3 Journalism via Wired Chaos",
    verified: true,
    verifiedType: "blue" as const,
    followersCount: 12000,
    role: "Speaker",
  },
  {
    twitterId: "4",
    handle: "GatorBTC",
    name: "GATOR",
    image: "/crew/gator-avatar.png",
    description: "Bitcoin Ordinals & DeFi Specialist",
    verified: false,
    verifiedType: null,
    followersCount: 8500,
    role: "Speaker",
  },
  {
    twitterId: "5",
    handle: "ArtsyNFT",
    name: "ARTSY",
    image: "/crew/artsy-avatar.png",
    description: "Visual Artist & NFT Creative Director",
    verified: false,
    verifiedType: null,
    followersCount: 6000,
    role: "Speaker",
  },
  {
    twitterId: "6",
    handle: "JeepDAO",
    name: "JEEP",
    image: "/crew/jeep-avatar.png",
    description: "DAO Governance & Community Lead",
    verified: false,
    verifiedType: null,
    followersCount: 4500,
    role: "Speaker",
  },
]

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)

    const page = searchParams.get("page") ? Number(searchParams.get("page")) : 0
    const limit = searchParams.get("limit") ? Number(searchParams.get("limit")) : 10

    // Return featured 789 Studios speakers (no external API call needed)
    const speakers = FEATURED_SPEAKERS.slice(page * limit, (page + 1) * limit)

    return NextResponse.json({
      speakers,
      page,
      limit,
      source: "789_studios_featured",
    })
  } catch (error: any) {
    console.error("[Speakers API Error]", error)
    return NextResponse.json(
      {
        speakers: [],
        page: 0,
        limit: 10,
        error: "Failed to load speakers",
      },
      { status: 200 },
    )
  }
}
