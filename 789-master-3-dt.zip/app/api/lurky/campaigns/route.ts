import { NextResponse } from "next/server"
import {
  crawlCampaigns,
  generatePromoCard,
  getFeaturedCampaigns,
  getCampaignsByType,
} from "@/lib/lurky/campaign-crawler"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const type = searchParams.get("type")
  const featured = searchParams.get("featured")
  const generatePromo = searchParams.get("promo")
  const campaignId = searchParams.get("id")

  try {
    let campaigns

    if (campaignId) {
      const allCampaigns = crawlCampaigns()
      const campaign = allCampaigns.find((c) => c.id === campaignId)
      if (!campaign) {
        return NextResponse.json({ error: "Campaign not found" }, { status: 404 })
      }

      if (generatePromo === "true") {
        return NextResponse.json({ promo: generatePromoCard(campaign) })
      }

      return NextResponse.json({ campaign })
    }

    if (featured === "true") {
      campaigns = getFeaturedCampaigns()
    } else if (type) {
      campaigns = getCampaignsByType(type as any)
    } else {
      campaigns = crawlCampaigns()
    }

    if (generatePromo === "true") {
      const promos = campaigns.map((c) => generatePromoCard(c))
      return NextResponse.json({ promos, total: promos.length })
    }

    return NextResponse.json({ campaigns, total: campaigns.length })
  } catch (error) {
    console.error("[Lurky Campaigns API Error]", error)
    return NextResponse.json({ error: "Failed to crawl campaigns" }, { status: 500 })
  }
}
