import { type NextRequest, NextResponse } from "next/server"
import { getLurkyClient } from "@/lib/lurky/client"
import { DEMO_COINS } from "@/lib/lurky/demo-data"

export const runtime = "edge"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)

    const params = {
      chains: searchParams.get("chains") || undefined,
      min_rank: searchParams.get("min_rank") ? Number(searchParams.get("min_rank")) : undefined,
      max_rank: searchParams.get("max_rank") ? Number(searchParams.get("max_rank")) : undefined,
      sort_by: searchParams.get("sort_by") || "market_cap",
      sort_dir: searchParams.get("sort_dir") || "desc",
      page: searchParams.get("page") ? Number(searchParams.get("page")) : 0,
      limit: searchParams.get("limit") ? Number(searchParams.get("limit")) : 10,
      mentioned: true,
    }

    try {
      const client = getLurkyClient()
      const data = await client.listCoinsWithMentions(params)

      const normalized = {
        coins: data.coins.map((coin: any) => ({
          id: coin.id,
          symbol: coin.symbol,
          name: coin.name,
          chain: coin.chain,
          image: coin.image,
          link: coin.link,
          externalLink: coin.externalLink,
          priceUsd: coin.priceUsd,
          priceChange24h: coin.priceChange24h,
          marketCap: coin.marketCap,
          marketCapRank: coin.marketCapRank,
          categories: coin.categories,
          mentions: {
            bullish: coin.mentions.bullish,
            neutral: coin.mentions.neutral,
            bearish: coin.mentions.bearish,
            total: coin.mentions.total,
            overallSentiment: coin.mentions.overallSentiment,
          },
        })),
        page: data.page,
        limit: data.limit,
        isDemo: false,
      }

      return NextResponse.json(normalized)
    } catch (apiError: any) {
      console.warn("[Lurky Coins] API unavailable, using demo data:", apiError.message)

      // Sort demo coins
      const sortedCoins = [...DEMO_COINS]
      const sortBy = params.sort_by || "market_cap"
      const sortDir = params.sort_dir || "desc"

      sortedCoins.sort((a, b) => {
        let aVal: number, bVal: number
        if (sortBy === "mentions") {
          aVal = a.mentions.total
          bVal = b.mentions.total
        } else if (sortBy === "price") {
          aVal = a.priceUsd
          bVal = b.priceUsd
        } else {
          aVal = a.marketCap
          bVal = b.marketCap
        }
        return sortDir === "desc" ? bVal - aVal : aVal - bVal
      })

      const page = params.page || 0
      const limit = params.limit || 10
      const paginatedCoins = sortedCoins.slice(page * limit, (page + 1) * limit)

      return NextResponse.json({
        coins: paginatedCoins,
        page,
        limit,
        isDemo: true,
        message: "Using demo data - Lurky API unavailable",
      })
    }
  } catch (error: any) {
    console.error("[Lurky Coins API Error]", error)
    return NextResponse.json({ error: error.message || "Failed to fetch coin sentiment data" }, { status: 500 })
  }
}
