import { type NextRequest, NextResponse } from "next/server"
import { getLurkyClient } from "@/lib/lurky/client"
import { DEMO_SPACES } from "@/lib/lurky/demo-data"

export const runtime = "edge"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)

    const params = {
      creator_ids: searchParams.get("creator_ids") || undefined,
      state: searchParams.get("state") || "analyzed",
      started_after: searchParams.get("started_after") ? Number(searchParams.get("started_after")) : undefined,
      started_before: searchParams.get("started_before") ? Number(searchParams.get("started_before")) : undefined,
      categories: searchParams.get("categories") || undefined,
      page: searchParams.get("page") ? Number(searchParams.get("page")) : 0,
      limit: searchParams.get("limit") ? Number(searchParams.get("limit")) : 10,
    }

    try {
      const client = getLurkyClient()
      const data = await client.listSpaces(params)

      const normalized = {
        spaces: data.spaces.map((space: any) => ({
          id: space.id,
          title: space.title,
          creatorHandle: space.creatorHandle,
          createdAt: space.createdAt,
          startedAt: space.startedAt,
          endedAt: space.endedAt,
          participantCount: space.participantCount,
          categories: space.categories || [],
          summary: space.summary,
          minimizedSummary: space.minimizedSummary,
          state: space.state,
        })),
        page: data.page,
        limit: data.limit,
        isDemo: false,
      }

      return NextResponse.json(normalized)
    } catch (apiError: any) {
      console.warn("[Lurky Spaces] API unavailable, using demo data:", apiError.message)

      // Filter demo spaces by state if provided
      const stateFilter = params.state?.split(",") || ["analyzed"]
      const filteredSpaces = DEMO_SPACES.filter((space) => stateFilter.includes(space.state))

      const page = params.page || 0
      const limit = params.limit || 10
      const paginatedSpaces = filteredSpaces.slice(page * limit, (page + 1) * limit)

      return NextResponse.json({
        spaces: paginatedSpaces,
        page,
        limit,
        isDemo: true,
        message: "Using demo data - Lurky API unavailable",
      })
    }
  } catch (error: any) {
    console.error("[Lurky Spaces API Error]", error)
    return NextResponse.json({ error: error.message || "Failed to fetch spaces data" }, { status: 500 })
  }
}
