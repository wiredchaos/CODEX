import { BackButton } from "@/components/ui/back-button"
import { OTT_SHOWS, OTT_CHANNELS } from "@/data/ott-content"
import { ShowCard } from "@/components/ott/show-card"

export const metadata = {
  title: "Browse Content - 789 Studios",
  description: "Explore Web3-native shows, films, and live content from 789 Studios",
}

export default function BrowsePage() {
  return (
    <div className="min-h-screen bg-black">
      {/* Navigation */}
      <div className="border-b border-border/30 bg-black/40 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-4">
          <BackButton fallbackHref="/" />
          <h1
            className="font-mono text-xl font-bold uppercase tracking-wider text-white"
            style={{ textShadow: "0 0 15px rgba(255, 215, 0, 0.5)" }}
          >
            Browse All Content
          </h1>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12 space-y-16">
        {/* By Channel */}
        {OTT_CHANNELS.map((channel) => {
          const channelShows = OTT_SHOWS.filter((show) => show.channelId === channel.id)
          if (channelShows.length === 0) return null

          return (
            <section key={channel.id} className="space-y-6">
              <div className="space-y-2">
                <h2
                  className="font-mono text-2xl font-bold uppercase tracking-wider"
                  style={{ color: channel.color, textShadow: `0 0 15px ${channel.color}80` }}
                >
                  {channel.name}
                </h2>
                <p
                  className="font-mono text-sm text-white/80"
                  style={{ textShadow: "0 0 8px rgba(255, 255, 255, 0.2)" }}
                >
                  {channel.description}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {channelShows.map((show) => (
                  <ShowCard key={show.id} show={show} />
                ))}
              </div>
            </section>
          )
        })}
      </div>
    </div>
  )
}
