"use client"

import { VirtualSoundstage } from "@/components/virtual-soundstage"
import { NeonLogo } from "@/components/neon-logo"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { PlatformHeroVideo } from "@/components/platform-hero-video"
import { CreatorContentFeed } from "@/components/creator-content-feed"
import { NavigationalAvatar } from "@/components/navigational-avatar"
import { SEOSchema } from "@/components/seo-schema"
import { CrewShowcase } from "@/components/crew-showcase"
import { GlobalDisclaimer } from "@/components/global-disclaimer"
import Link from "next/link"
import { Mic, Upload, Lock, Radio, Film, Wallet, Sparkles, Users } from "lucide-react"
import { ContentRail } from "@/components/ott/content-rail"
import { HeroBanner } from "@/components/ott/hero-banner"
import { getFeaturedShow, getShowsByChannel } from "@/data/ott-content"
import { NeuroConciergeModal } from "@/components/neuro-concierge"
import { ElevatorNav } from "@/components/elevator-nav"

export default function HomePage() {
  const featuredShow = getFeaturedShow()
  const originals = getShowsByChannel("789-originals")
  const film3Content = getShowsByChannel("film3-network")

  return (
    <>
      <SEOSchema />
      <NeuroConciergeModal />
      <ElevatorNav />

      <VirtualSoundstage>
        <NavigationalAvatar />

        {/* Top Navigation Bar */}
        <div className="border-b border-border/30 bg-black/40 backdrop-blur-sm sticky top-0 z-40">
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-6">
              <div
                className="font-mono text-xs font-bold"
                style={{ color: "#ffd700", textShadow: "0 0 10px rgba(255, 215, 0, 0.5)" }}
              >
                789
              </div>
              <nav className="hidden md:flex items-center gap-4">
                <Link
                  href="/"
                  className="font-mono text-xs text-white font-bold"
                  style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.5)" }}
                >
                  Home
                </Link>
                <Link
                  href="/browse"
                  className="font-mono text-xs text-white/70 hover:text-white transition-colors"
                  style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.3)" }}
                >
                  Browse
                </Link>
                <Link
                  href="/creator"
                  className="font-mono text-xs text-white/70 hover:text-white transition-colors"
                  style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.3)" }}
                >
                  Creator Hub
                </Link>
                <Link
                  href="/crew"
                  className="font-mono text-xs text-white/70 hover:text-white transition-colors"
                  style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.3)" }}
                >
                  789 Crew
                </Link>
                <Link
                  href="/allies"
                  className="font-mono text-xs text-white/70 hover:text-white transition-colors"
                  style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.3)" }}
                >
                  Allies
                </Link>
                <Link
                  href="/intelligence"
                  className="font-mono text-xs text-white/70 hover:text-cyan transition-colors flex items-center gap-1"
                  style={{ textShadow: "0 0 5px rgba(0, 255, 255, 0.3)" }}
                >
                  Intelligence
                  <span className="text-[10px] px-1 py-0.5 rounded bg-cyan/20 text-cyan border border-cyan/50">AI</span>
                </Link>
                <Link
                  href="/film3"
                  className="font-mono text-xs text-white/70 hover:text-white transition-colors"
                  style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.3)" }}
                >
                  Film3
                </Link>
                <Link
                  href="/mint"
                  className="font-mono text-xs text-white/70 hover:text-white transition-colors"
                  style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.3)" }}
                >
                  Mint Film
                </Link>
                <Link
                  href="/lounge"
                  className="font-mono text-xs text-white/70 hover:text-white transition-colors"
                  style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.3)" }}
                >
                  Lounge
                </Link>
                <Link
                  href="/spaces"
                  className="font-mono text-xs text-white/70 hover:text-white transition-colors"
                  style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.3)" }}
                >
                  Spaces
                </Link>
                <Link
                  href="/pricing"
                  className="font-mono text-xs text-white/70 hover:text-white transition-colors"
                  style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.3)" }}
                >
                  Studios
                </Link>
              </nav>
            </div>
            <div className="flex items-center gap-3">
              <Link
                href="https://x.com/789studiosonx"
                target="_blank"
                className="font-mono text-xs hover:text-[#00ffff] transition-colors hidden md:block"
                style={{ color: "#00ffff", textShadow: "0 0 10px rgba(0, 255, 255, 0.5)" }}
              >
                @789studiosonx
              </Link>
              <Button
                size="sm"
                className="font-mono font-bold uppercase tracking-wider hover:opacity-90 flex items-center gap-2"
                style={{
                  background: "#ffd700",
                  color: "#000",
                  boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
                }}
              >
                <Wallet className="w-4 h-4" />
                Connect Wallet
              </Button>
            </div>
          </div>
        </div>

        {/* Hero Header */}
        <header className="relative py-12 md:py-20 px-4 text-center">
          <div className="max-w-6xl mx-auto space-y-8">
            <div className="animate-float">
              <NeonLogo />
            </div>

            <div className="space-y-4">
              <h1
                className="text-2xl md:text-4xl font-bold text-balance text-white"
                style={{ textShadow: "0 0 20px rgba(218, 165, 32, 0.5)" }}
              >
                WEB3 CREATOR ECOSYSTEM
              </h1>
              <p
                className="font-mono text-sm md:text-base text-white/90 max-w-2xl mx-auto text-pretty"
                style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.3)" }}
              >
                Multi-platform publishing • Token-gated content • Professional recording studios • Blockchain verified •
                Film3 onboarding for filmmakers
              </p>
            </div>

            {/* Platform Intro Video */}
            <div className="max-w-4xl mx-auto">
              <PlatformHeroVideo />
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Button
                size="lg"
                className="font-mono font-bold uppercase tracking-wider hover:opacity-90 hover:scale-105 transition-all"
                style={{
                  background: "#ffd700",
                  color: "#000",
                  boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
                }}
                asChild
              >
                <Link href="/creator">Launch Creator Hub</Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="font-mono font-bold uppercase tracking-wider border-[#00ffff]/50 hover:bg-[#00ffff]/10 bg-transparent hover:scale-105 transition-all"
                style={{ color: "#00ffff", textShadow: "0 0 10px rgba(0, 255, 255, 0.5)" }}
              >
                Connect Wallet
              </Button>
            </div>

            {/* Platform Services Grid */}
            <section className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Link href="/creator" className="transform hover:scale-105 transition-transform">
                <Card className="glass-panel border-[#00ffff]/20 p-6 space-y-4 hover:border-[#00ffff] transition-all duration-300 cursor-pointer h-full">
                  <div className="w-12 h-12 rounded-full bg-[#00ffff]/10 border border-[#00ffff]/30 flex items-center justify-center">
                    <Upload className="w-6 h-6 text-[#00ffff]" />
                  </div>
                  <div className="space-y-2">
                    <h3
                      className="font-mono text-lg font-bold"
                      style={{ color: "#00ffff", textShadow: "0 0 10px rgba(0, 255, 255, 0.5)" }}
                    >
                      Creator Hub
                    </h3>
                    <p
                      className="font-mono text-xs text-white/80"
                      style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
                    >
                      Publish to YouTube, X, Instagram, TikTok, LinkedIn
                    </p>
                  </div>
                </Card>
              </Link>

              <Link href="/mint" className="transform hover:scale-105 transition-transform">
                <Card className="glass-panel border-[#ffd700]/20 p-6 space-y-4 hover:border-[#ffd700] transition-all duration-300 cursor-pointer h-full">
                  <div className="w-12 h-12 rounded-full bg-[#ffd700]/10 border border-[#ffd700]/30 flex items-center justify-center">
                    <Film className="w-6 h-6 text-[#ffd700]" />
                  </div>
                  <div className="space-y-2">
                    <h3
                      className="font-mono text-lg font-bold"
                      style={{ color: "#ffd700", textShadow: "0 0 10px rgba(255, 215, 0, 0.5)" }}
                    >
                      Mint Film
                    </h3>
                    <p
                      className="font-mono text-xs text-white/80"
                      style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
                    >
                      Transform your films into NFTs with 90% revenue
                    </p>
                  </div>
                </Card>
              </Link>

              <Link href="/film3" className="transform hover:scale-105 transition-transform">
                <Card className="glass-panel border-[#daa520]/20 p-6 space-y-4 hover:border-[#daa520] transition-all duration-300 cursor-pointer h-full">
                  <div className="w-12 h-12 rounded-full bg-[#daa520]/10 border border-[#daa520]/30 flex items-center justify-center">
                    <Film className="w-6 h-6 text-[#daa520]" />
                  </div>
                  <div className="space-y-2">
                    <h3
                      className="font-mono text-lg font-bold"
                      style={{ color: "#daa520", textShadow: "0 0 10px rgba(218, 165, 32, 0.5)" }}
                    >
                      Film3
                    </h3>
                    <p
                      className="font-mono text-xs text-white/80"
                      style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
                    >
                      Onboard Web2 filmmakers to blockchain cinema
                    </p>
                  </div>
                </Card>
              </Link>

              <Link href="/pricing" className="transform hover:scale-105 transition-transform">
                <Card className="glass-panel border-[#ffd700]/20 p-6 space-y-4 hover:border-[#ffd700] transition-all duration-300 cursor-pointer h-full">
                  <div className="w-12 h-12 rounded-full bg-[#ffd700]/10 border border-[#ffd700]/30 flex items-center justify-center">
                    <Mic className="w-6 h-6 text-[#ffd700]" />
                  </div>
                  <div className="space-y-2">
                    <h3
                      className="font-mono text-lg font-bold"
                      style={{ color: "#ffd700", textShadow: "0 0 10px rgba(255, 215, 0, 0.5)" }}
                    >
                      Recording Studios
                    </h3>
                    <p
                      className="font-mono text-xs text-white/80"
                      style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
                    >
                      Professional recording, mixing, mastering
                    </p>
                  </div>
                </Card>
              </Link>

              <Link href="/lounge" className="transform hover:scale-105 transition-transform">
                <Card className="glass-panel border-[#ff00ff]/20 p-6 space-y-4 hover:border-[#ff00ff] transition-all duration-300 cursor-pointer h-full">
                  <div className="w-12 h-12 rounded-full bg-[#ff00ff]/10 border border-[#ff00ff]/30 flex items-center justify-center">
                    <Sparkles className="w-6 h-6 text-[#ff00ff]" />
                  </div>
                  <div className="space-y-2">
                    <h3
                      className="font-mono text-lg font-bold"
                      style={{ color: "#ff00ff", textShadow: "0 0 10px rgba(255, 0, 255, 0.5)" }}
                    >
                      Level Up Lounge
                    </h3>
                    <p
                      className="font-mono text-xs text-white/80"
                      style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
                    >
                      Poetry slams, ciphers, concerts, community jams
                    </p>
                  </div>
                </Card>
              </Link>

              <Link href="/crew" className="transform hover:scale-105 transition-transform">
                <Card className="glass-panel border-[#00ffff]/20 p-6 space-y-4 hover:border-[#00ffff] transition-all duration-300 cursor-pointer h-full">
                  <div className="w-12 h-12 rounded-full bg-[#00ffff]/10 border border-[#00ffff]/30 flex items-center justify-center">
                    <Users className="w-6 h-6 text-[#00ffff]" />
                  </div>
                  <div className="space-y-2">
                    <h3
                      className="font-mono text-lg font-bold"
                      style={{ color: "#00ffff", textShadow: "0 0 10px rgba(0, 255, 255, 0.5)" }}
                    >
                      789 Crew
                    </h3>
                    <p
                      className="font-mono text-xs text-white/80"
                      style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
                    >
                      Meet the creators powering 789 Studios
                    </p>
                  </div>
                </Card>
              </Link>

              <Link href="/creator?tab=token-gate" className="transform hover:scale-105 transition-transform">
                <Card className="glass-panel border-[#daa520]/20 p-6 space-y-4 hover:border-[#daa520] transition-all duration-300 cursor-pointer h-full">
                  <div className="w-12 h-12 rounded-full bg-[#daa520]/10 border border-[#daa520]/30 flex items-center justify-center">
                    <Lock className="w-6 h-6 text-[#daa520]" />
                  </div>
                  <div className="space-y-2">
                    <h3
                      className="font-mono text-lg font-bold"
                      style={{ color: "#daa520", textShadow: "0 0 10px rgba(218, 165, 32, 0.5)" }}
                    >
                      Token-Gated
                    </h3>
                    <p
                      className="font-mono text-xs text-white/80"
                      style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
                    >
                      NFT and token-based exclusive content
                    </p>
                  </div>
                </Card>
              </Link>

              <Link href="/spaces" className="transform hover:scale-105 transition-transform">
                <Card className="glass-panel border-[#00ffff]/20 p-6 space-y-4 hover:border-[#00ffff] transition-all duration-300 cursor-pointer h-full">
                  <div className="w-12 h-12 rounded-full bg-[#00ffff]/10 border border-[#00ffff]/30 flex items-center justify-center">
                    <Radio className="w-6 h-6 text-[#00ffff]" />
                  </div>
                  <div className="space-y-2">
                    <h3
                      className="font-mono text-lg font-bold"
                      style={{ color: "#00ffff", textShadow: "0 0 10px rgba(0, 255, 255, 0.5)" }}
                    >
                      Spaces Network
                    </h3>
                    <p
                      className="font-mono text-xs text-white/80"
                      style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
                    >
                      24/7 live streaming with 15 unique hosts
                    </p>
                  </div>
                </Card>
              </Link>
            </section>
          </div>
        </header>

        {/* OTT Featured Content Section */}
        <section className="py-16">
          <HeroBanner show={featuredShow} />
        </section>

        {/* OTT Content Rails */}
        <section className="max-w-7xl mx-auto px-0 md:px-4 space-y-12 py-8">
          <ContentRail title="789 Originals" shows={originals} priority />
          <ContentRail title="Film3 Network" shows={film3Content} />
        </section>

        <section className="max-w-7xl mx-auto px-4 py-16">
          <CrewShowcase />
        </section>

        {/* Creator Content Feed - YouTube Style */}
        <section className="max-w-7xl mx-auto px-4 py-16">
          <CreatorContentFeed />
        </section>

        {/* Revenue Model Info */}
        <section className="max-w-7xl mx-auto px-4 py-16">
          <div className="glass-panel-enhanced rounded-lg p-8 md:p-12 border-2 border-[#ffd700]/20 text-center space-y-6">
            <h2
              className="font-mono text-2xl md:text-3xl font-bold text-white"
              style={{ textShadow: "0 0 15px rgba(218, 165, 32, 0.5)" }}
            >
              BLOCKCHAIN-POWERED REVENUE
            </h2>
            <p
              className="font-mono text-sm md:text-base text-white/90 max-w-3xl mx-auto"
              style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.2)" }}
            >
              Creators earn directly through token-gated content, NFT sales, subscriptions, and studio services. All
              transactions verified on Dogecoin blockchain. Keep 90% of revenue—we only take 10%.
            </p>
            <div className="pt-4">
              <Link href="/about-ott">
                <Button
                  variant="outline"
                  className="font-mono font-bold uppercase tracking-wider border-[#ffd700] hover:bg-[#ffd700]/10 bg-transparent text-[#ffd700]"
                >
                  Learn More About OTT
                </Button>
              </Link>
            </div>
            <div className="grid md:grid-cols-4 gap-6 pt-6">
              <div className="space-y-2">
                <div
                  className="font-mono text-3xl font-bold"
                  style={{ color: "#00ffff", textShadow: "0 0 15px rgba(0, 255, 255, 0.5)" }}
                >
                  90%
                </div>
                <div
                  className="font-mono text-xs text-white/80"
                  style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
                >
                  Creator Revenue Share
                </div>
              </div>
              <div className="space-y-2">
                <div
                  className="font-mono text-3xl font-bold"
                  style={{ color: "#ffd700", textShadow: "0 0 15px rgba(255, 215, 0, 0.5)" }}
                >
                  5+
                </div>
                <div
                  className="font-mono text-xs text-white/80"
                  style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
                >
                  Platform Distribution
                </div>
              </div>
              <div className="space-y-2">
                <div
                  className="font-mono text-3xl font-bold"
                  style={{ color: "#daa520", textShadow: "0 0 15px rgba(218, 165, 32, 0.5)" }}
                >
                  24/7
                </div>
                <div
                  className="font-mono text-xs text-white/80"
                  style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
                >
                  Studio Access Available
                </div>
              </div>
              <div className="space-y-2">
                <div
                  className="font-mono text-3xl font-bold"
                  style={{ color: "#00ffff", textShadow: "0 0 15px rgba(0, 255, 255, 0.5)" }}
                >
                  Web3
                </div>
                <div
                  className="font-mono text-xs text-white/80"
                  style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
                >
                  Blockchain Verified
                </div>
              </div>
            </div>
          </div>
        </section>

        <GlobalDisclaimer />
      </VirtualSoundstage>
    </>
  )
}
