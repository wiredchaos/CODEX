import { BackButton } from "@/components/ui/back-button"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { OTT_SHOWS } from "@/data/ott-content"
import { ChevronLeft, ChevronRight } from "lucide-react"
import Link from "next/link"

export default function WatchPage({ params }: { params: { id: string } }) {
  // Find the episode/show
  let episode = null
  let show = null

  for (const s of OTT_SHOWS) {
    const ep = s.episodes.find((e) => e.id === params.id)
    if (ep) {
      episode = ep
      show = s
      break
    }
  }

  if (!episode || !show) {
    return <div className="min-h-screen bg-black flex items-center justify-center text-white">Episode not found</div>
  }

  const currentIndex = show.episodes.findIndex((e) => e.id === episode.id)
  const previousEpisode = currentIndex > 0 ? show.episodes[currentIndex - 1] : null
  const nextEpisode = currentIndex < show.episodes.length - 1 ? show.episodes[currentIndex + 1] : null

  const isYouTubeEmbed = episode.videoUrl.includes("youtube.com/embed")

  return (
    <div className="min-h-screen bg-black">
      {/* Navigation */}
      <div className="border-b border-border/30 bg-black/90 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-4">
          <BackButton fallbackHref={`/title/${show.slug}`} />
          <div className="flex-1">
            <h1
              className="font-mono text-sm md:text-base font-bold text-white line-clamp-1"
              style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.5)" }}
            >
              {episode.title}
            </h1>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-0 md:px-4 py-0 md:py-8">
        {/* Video Player */}
        <div className="relative w-full bg-black">
          <div className="relative aspect-video">
            {isYouTubeEmbed ? (
              <iframe
                className="absolute top-0 left-0 w-full h-full"
                src={episode.videoUrl}
                title={episode.title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                referrerPolicy="strict-origin-when-cross-origin"
                allowFullScreen
              />
            ) : (
              <video
                controls
                autoPlay
                className="w-full h-full"
                poster={episode.thumbnail}
                style={{ maxHeight: "calc(100vh - 200px)" }}
              >
                <source src={episode.videoUrl} type="video/mp4" />
                Your browser does not support the video tag.
              </video>
            )}
          </div>
        </div>

        {/* Episode Info & Controls */}
        <div className="px-4 py-6 space-y-6">
          {/* Title & Description */}
          <div className="space-y-3">
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-2 flex-1">
                <Link
                  href={`/title/${show.slug}`}
                  className="font-mono text-sm text-[#00ffff] hover:underline"
                  style={{ textShadow: "0 0 8px rgba(0, 255, 255, 0.5)" }}
                >
                  {show.title}
                </Link>
                <h2
                  className="font-mono text-xl md:text-2xl font-bold text-white"
                  style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.5)" }}
                >
                  {episode.seasonNumber && episode.episodeNumber
                    ? `S${episode.seasonNumber} E${episode.episodeNumber}: ${episode.title}`
                    : episode.title}
                </h2>
                <p className="text-sm text-white/90" style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.3)" }}>
                  {episode.description}
                </p>
              </div>
            </div>
          </div>

          {/* Episode Navigation */}
          <div className="flex gap-3">
            {previousEpisode ? (
              <Button
                variant="outline"
                className="font-mono border-white/20 bg-black/40 hover:bg-white/10 text-white"
                style={{ textShadow: "0 0 8px rgba(255, 255, 255, 0.5)" }}
                asChild
              >
                <Link href={`/watch/${previousEpisode.id}`}>
                  <ChevronLeft className="w-4 h-4 mr-2" />
                  Previous Episode
                </Link>
              </Button>
            ) : null}

            {nextEpisode ? (
              <Button
                className="font-mono font-bold text-black"
                style={{
                  background: "#ffd700",
                  boxShadow: "0 0 15px rgba(255, 215, 0, 0.5)",
                }}
                asChild
              >
                <Link href={`/watch/${nextEpisode.id}`}>
                  Next Episode
                  <ChevronRight className="w-4 h-4 ml-2" />
                </Link>
              </Button>
            ) : null}
          </div>

          {/* All Episodes */}
          {show.episodes.length > 1 && (
            <div className="space-y-4 pt-6 border-t border-white/10">
              <h3
                className="font-mono text-lg font-bold uppercase tracking-wider text-white"
                style={{ textShadow: "0 0 10px rgba(255, 215, 0, 0.5)" }}
              >
                All Episodes
              </h3>
              <div className="grid gap-4">
                {show.episodes.map((ep) => (
                  <Link key={ep.id} href={`/watch/${ep.id}`}>
                    <Card
                      className={`flex gap-4 p-4 bg-black/40 border-white/10 hover:border-[#00ffff]/50 transition-all ${
                        ep.id === episode.id ? "border-[#ffd700]/50 bg-[#ffd700]/5" : ""
                      }`}
                    >
                      <img
                        src={ep.thumbnail || "/placeholder.svg"}
                        alt={ep.title}
                        className="w-32 h-20 object-cover rounded"
                      />
                      <div className="flex-1 space-y-1">
                        <div
                          className="font-mono text-xs text-white/70"
                          style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.3)" }}
                        >
                          {ep.seasonNumber && ep.episodeNumber ? `S${ep.seasonNumber} E${ep.episodeNumber}` : "Episode"}
                        </div>
                        <div
                          className="font-mono font-bold text-sm text-white"
                          style={{ textShadow: "0 0 8px rgba(255, 255, 255, 0.5)" }}
                        >
                          {ep.title}
                        </div>
                        <div
                          className="text-xs text-white/80 line-clamp-2"
                          style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.3)" }}
                        >
                          {ep.description}
                        </div>
                      </div>
                      <div
                        className="font-mono text-xs text-white/70"
                        style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.3)" }}
                      >
                        {Math.floor(ep.duration / 60)}min
                      </div>
                    </Card>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
