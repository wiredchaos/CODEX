"use client"

import { useState } from "react"
import { VirtualSoundstage } from "@/components/virtual-soundstage"
import { NavigationalAvatar } from "@/components/navigational-avatar"
import { GlobalDisclaimer } from "@/components/global-disclaimer"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { BackButton } from "@/components/ui/back-button"
import Link from "next/link"
import Image from "next/image"
import {
  Play,
  ChevronRight,
  Eye,
  Clock,
  Star,
  Scissors,
  Share2,
  Download,
  Tv,
  Sparkles,
  ChevronLeft,
} from "lucide-react"

// Extended content for OTT page sections
const HERO_CONTENT = [
  {
    id: "wired-chaos-meta",
    title: "WIRED CHAOS META: Quantum Heist",
    subtitle: "A cyber-thriller where the metaverse meets reality in explosive fashion",
    image: "/cyberpunk-quantum-heist-neon-city-thriller.jpg",
    views: "270,000",
    likes: "17,000",
    tags: ["Film3", "Thriller", "Web3"],
    duration: "1h 42m",
    year: 2025,
  },
  {
    id: "doginal-dogs-ep1",
    title: "Doginal Dogs: Episode 1 - The Pack Assembles",
    subtitle: "The legendary Doginals unite for their first on-chain adventure",
    image: "/animated-dogs-cartoon-adventure-colorful.jpg",
    views: "89,000",
    likes: "12,000",
    tags: ["Animation", "Doginal Dogs", "Original"],
    duration: "14 min",
    year: 2025,
  },
  {
    id: "rupture",
    title: "RUPTURE: The FLINCH Story",
    subtitle: "A seven act docudrama chronicling the creation of the Film3 revolution",
    image: "/documentary-film-noir-cinematic-dark.jpg",
    views: "125,000",
    likes: "8,600",
    tags: ["Documentary", "Film3", "NFT"],
    duration: "2h 15m",
    year: 2025,
  },
]

const TRENDING_NOW = [
  {
    id: "genesis",
    title: "Genesis Protocol: The First Block",
    image: "/blockchain-genesis-digital-art.jpg",
    views: "125K",
    rating: "8.8K",
    duration: "1h",
  },
  {
    id: "neon-nights",
    title: "Neon Nights: A Film3 Love Story",
    image: "/neon-romance-cyberpunk-love-story.jpg",
    views: "98K",
    rating: "7.2K",
    duration: "45m",
  },
  {
    id: "validator",
    title: "The Validator Chronicles",
    image: "/sci-fi-validator-node-network.jpg",
    views: "156K",
    rating: "12K",
    duration: "35m",
  },
  {
    id: "dao-rev",
    title: "Smart Contract Stories",
    image: "/smart-contract-code-digital.jpg",
    views: "67K",
    rating: "5.1K",
    duration: "28m",
  },
]

const FEATURED_FILMS = [
  {
    id: "neon-nights",
    title: "Neon Nights: A Film3 Love Story",
    description: "Romance blooms in a blockchain-powered world where every moment is minted",
    image: "/neon-romance-cyberpunk-love-story-cinematic.jpg",
    views: "178,000",
    rating: "13,600",
    duration: "52m",
  },
]

const SHOWS = [
  {
    id: "validator-chronicles",
    title: "The Validator Chronicles: Season 1 Premiere",
    description: "A thrilling series about node operators protecting the blockchain from dark forces",
    image: "/sci-fi-validator-blockchain-protection-dramatic.jpg",
    views: "86,000",
    rating: "7,800",
    episodes: "14+",
  },
]

const WEB3_SPECIALS = [
  {
    id: "dao-revolution",
    title: "Smart Contract Stories: The DAO Revolution",
    description: "Behind-the-scenes look at how DAOs are changing creative production",
    image: "/dao-revolution-digital-art-collaborative.jpg",
    views: "45,000",
    rating: "3,200",
    duration: "32m",
  },
]

const DOCUMENTARY_VAULT = [
  {
    id: "genesis-protocol",
    title: "Genesis Protocol: The First Block",
    description: "A groundbreaking Film3 documentary exploring the birth of decentralized cinema",
    image: "/genesis-blockchain-documentary-cinematic.jpg",
    views: "125,000",
    rating: "8,800",
    duration: "1h",
  },
]

const DOGINAL_ORIGINALS = [
  {
    id: "doginal-ep1",
    title: "Doginal Dogs: Episode 1 - The Pack Assembles",
    description: "The legendary Doginals unite for their first on-chain adventure",
    image: "/animated-dogs-cartoon-colorful-adventure-pack.jpg",
    views: "89,000",
    rating: "12,000",
    duration: "14m",
  },
]

export default function OTTPage() {
  const [heroIndex, setHeroIndex] = useState(0)
  const [showClipTool, setShowClipTool] = useState(false)
  const [selectedContent, setSelectedContent] = useState<string | null>(null)

  const currentHero = HERO_CONTENT[heroIndex]

  const nextHero = () => setHeroIndex((prev) => (prev + 1) % HERO_CONTENT.length)
  const prevHero = () => setHeroIndex((prev) => (prev - 1 + HERO_CONTENT.length) % HERO_CONTENT.length)

  return (
    <VirtualSoundstage>
      <NavigationalAvatar />

      {/* Header */}
      <div className="border-b border-border/30 bg-black/60 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <BackButton fallbackHref="/" />
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-orange-600 rounded flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div>
                <span className="font-bold text-orange-500 text-lg">789 STUDIOS</span>
                <p className="text-xs text-white/60">Film3 OTT Platform</p>
              </div>
            </div>
          </div>
          <Button className="bg-orange-500 hover:bg-orange-600 text-white font-bold px-4 py-2">Connect Wallet</Button>
        </div>
      </div>

      {/* Hero Carousel */}
      <section className="relative">
        <div className="relative h-[70vh] min-h-[500px] overflow-hidden">
          <Image
            src={currentHero.image || "/placeholder.svg"}
            alt={currentHero.title}
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-transparent to-transparent" />

          {/* Hero Content */}
          <div className="absolute bottom-0 left-0 right-0 p-6 md:p-12 space-y-4">
            <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold text-white max-w-3xl leading-tight">
              {currentHero.title}
            </h1>
            <p className="text-base md:text-lg text-white/80 max-w-2xl">{currentHero.subtitle}</p>
            <div className="flex items-center gap-4 text-sm text-white/60">
              <span className="flex items-center gap-1">
                <Eye className="w-4 h-4" />
                {currentHero.views} views
              </span>
              <span className="flex items-center gap-1">
                <Star className="w-4 h-4 text-orange-500" />
                {currentHero.likes}
              </span>
              <span className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                {currentHero.duration}
              </span>
            </div>
            <div className="flex flex-wrap gap-2">
              {currentHero.tags.map((tag) => (
                <Badge key={tag} className="bg-white/10 text-white border-white/20 text-xs">
                  {tag}
                </Badge>
              ))}
            </div>
            <div className="flex gap-3 pt-2">
              <Button className="bg-orange-500 hover:bg-orange-600 text-white font-bold gap-2">
                <Play className="w-4 h-4 fill-current" />
                Watch Now
              </Button>
              <Button
                variant="outline"
                className="border-white/30 text-white bg-white/10 hover:bg-white/20"
                onClick={() => {
                  setSelectedContent(currentHero.id)
                  setShowClipTool(true)
                }}
              >
                <Scissors className="w-4 h-4 mr-2" />
                Create Clip
              </Button>
            </div>
          </div>

          {/* Navigation Arrows */}
          <button
            onClick={prevHero}
            className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 hover:bg-black/70 flex items-center justify-center text-white transition-colors"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={nextHero}
            className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 hover:bg-black/70 flex items-center justify-center text-white transition-colors"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Dots */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
            {HERO_CONTENT.map((_, i) => (
              <button
                key={i}
                onClick={() => setHeroIndex(i)}
                className={`w-2 h-2 rounded-full transition-colors ${
                  i === heroIndex ? "bg-orange-500" : "bg-white/30"
                }`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Trending Now */}
      <section className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-bold text-white">Trending Now</h2>
            <p className="text-sm text-white/60">Most watched Film3 content</p>
          </div>
          <Link href="/ott/trending" className="flex items-center gap-1 text-sm text-orange-500 hover:text-orange-400">
            View All <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {TRENDING_NOW.map((item) => (
            <Link key={item.id} href={`/watch/${item.id}`}>
              <Card className="group bg-zinc-900/50 border-zinc-800 overflow-hidden hover:border-orange-500/50 transition-colors">
                <div className="relative aspect-[2/3]">
                  <Image src={item.image || "/placeholder.svg"} alt={item.title} fill className="object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-3">
                    <h3 className="text-sm font-bold text-white line-clamp-2">{item.title}</h3>
                    <div className="flex items-center gap-2 mt-1 text-xs text-white/60">
                      <span className="flex items-center gap-1">
                        <Eye className="w-3 h-3" />
                        {item.views}
                      </span>
                      <span className="flex items-center gap-1">
                        <Star className="w-3 h-3 text-orange-500" />
                        {item.rating}
                      </span>
                      <span>{item.duration}</span>
                    </div>
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                    <div className="w-12 h-12 rounded-full bg-orange-500 flex items-center justify-center">
                      <Play className="w-6 h-6 text-white fill-current" />
                    </div>
                  </div>
                </div>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured Films */}
      <section className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-bold text-white">Featured Films</h2>
            <p className="text-sm text-white/60">Explore 1 video</p>
          </div>
          <Link href="/ott/films" className="flex items-center gap-1 text-sm text-orange-500 hover:text-orange-400">
            View All <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
        {FEATURED_FILMS.map((film) => (
          <Link key={film.id} href={`/watch/${film.id}`}>
            <Card className="group bg-zinc-900/50 border-zinc-800 overflow-hidden hover:border-orange-500/50 transition-colors">
              <div className="md:flex">
                <div className="relative md:w-1/2 aspect-video">
                  <Image src={film.image || "/placeholder.svg"} alt={film.title} fill className="object-cover" />
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                    <div className="w-16 h-16 rounded-full bg-orange-500 flex items-center justify-center">
                      <Play className="w-8 h-8 text-white fill-current" />
                    </div>
                  </div>
                </div>
                <div className="p-6 md:w-1/2 flex flex-col justify-center">
                  <h3 className="text-xl font-bold text-white mb-2">{film.title}</h3>
                  <p className="text-sm text-white/70 mb-4">{film.description}</p>
                  <div className="flex items-center gap-4 text-sm text-white/60">
                    <span className="flex items-center gap-1">
                      <Eye className="w-4 h-4" />
                      {film.views}
                    </span>
                    <span className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-orange-500" />
                      {film.rating}
                    </span>
                    <span>{film.duration}</span>
                  </div>
                </div>
              </div>
            </Card>
          </Link>
        ))}
      </section>

      {/* Shows */}
      <section className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-bold text-white">Shows</h2>
            <p className="text-sm text-white/60">Explore 1 video</p>
          </div>
          <Link href="/ott/shows" className="flex items-center gap-1 text-sm text-orange-500 hover:text-orange-400">
            View All <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
        {SHOWS.map((show) => (
          <Link key={show.id} href={`/watch/${show.id}`}>
            <Card className="group bg-zinc-900/50 border-zinc-800 overflow-hidden hover:border-orange-500/50 transition-colors">
              <div className="md:flex">
                <div className="relative md:w-2/5 aspect-video md:aspect-auto md:h-48">
                  <Image src={show.image || "/placeholder.svg"} alt={show.title} fill className="object-cover" />
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                    <div className="w-14 h-14 rounded-full bg-orange-500 flex items-center justify-center">
                      <Play className="w-7 h-7 text-white fill-current" />
                    </div>
                  </div>
                </div>
                <div className="p-5 md:w-3/5">
                  <h3 className="text-lg font-bold text-white mb-2">{show.title}</h3>
                  <p className="text-sm text-white/70 mb-3">{show.description}</p>
                  <div className="flex items-center gap-4 text-sm text-white/60">
                    <span className="flex items-center gap-1">
                      <Eye className="w-4 h-4" />
                      {show.views}
                    </span>
                    <span className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-orange-500" />
                      {show.rating}
                    </span>
                    <span className="flex items-center gap-1">
                      <Tv className="w-4 h-4" />
                      {show.episodes}
                    </span>
                  </div>
                </div>
              </div>
            </Card>
          </Link>
        ))}
      </section>

      {/* Web3 Specials */}
      <section className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-bold text-white">Web3 Specials</h2>
            <p className="text-sm text-white/60">Explore 1 video</p>
          </div>
          <Link href="/ott/specials" className="flex items-center gap-1 text-sm text-orange-500 hover:text-orange-400">
            View All <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
        {WEB3_SPECIALS.map((special) => (
          <Link key={special.id} href={`/watch/${special.id}`}>
            <Card className="group bg-zinc-900/50 border-zinc-800 overflow-hidden hover:border-orange-500/50 transition-colors">
              <div className="md:flex">
                <div className="relative md:w-2/5 aspect-video md:aspect-auto md:h-48">
                  <Image src={special.image || "/placeholder.svg"} alt={special.title} fill className="object-cover" />
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                    <div className="w-14 h-14 rounded-full bg-orange-500 flex items-center justify-center">
                      <Play className="w-7 h-7 text-white fill-current" />
                    </div>
                  </div>
                </div>
                <div className="p-5 md:w-3/5">
                  <h3 className="text-lg font-bold text-white mb-2">{special.title}</h3>
                  <p className="text-sm text-white/70 mb-3">{special.description}</p>
                  <div className="flex items-center gap-4 text-sm text-white/60">
                    <span className="flex items-center gap-1">
                      <Eye className="w-4 h-4" />
                      {special.views}
                    </span>
                    <span className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-orange-500" />
                      {special.rating}
                    </span>
                    <span>{special.duration}</span>
                  </div>
                </div>
              </div>
            </Card>
          </Link>
        ))}
      </section>

      {/* Documentary Vault */}
      <section className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-bold text-white">Documentary Vault</h2>
            <p className="text-sm text-white/60">Explore 1 video</p>
          </div>
          <Link
            href="/ott/documentaries"
            className="flex items-center gap-1 text-sm text-orange-500 hover:text-orange-400"
          >
            View All <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
        {DOCUMENTARY_VAULT.map((doc) => (
          <Link key={doc.id} href={`/watch/${doc.id}`}>
            <Card className="group bg-zinc-900/50 border-zinc-800 overflow-hidden hover:border-orange-500/50 transition-colors">
              <div className="md:flex">
                <div className="relative md:w-2/5 aspect-video md:aspect-auto md:h-48">
                  <Image src={doc.image || "/placeholder.svg"} alt={doc.title} fill className="object-cover" />
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                    <div className="w-14 h-14 rounded-full bg-orange-500 flex items-center justify-center">
                      <Play className="w-7 h-7 text-white fill-current" />
                    </div>
                  </div>
                </div>
                <div className="p-5 md:w-3/5">
                  <h3 className="text-lg font-bold text-white mb-2">{doc.title}</h3>
                  <p className="text-sm text-white/70 mb-3">{doc.description}</p>
                  <div className="flex items-center gap-4 text-sm text-white/60">
                    <span className="flex items-center gap-1">
                      <Eye className="w-4 h-4" />
                      {doc.views}
                    </span>
                    <span className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-orange-500" />
                      {doc.rating}
                    </span>
                    <span>{doc.duration}</span>
                  </div>
                </div>
              </div>
            </Card>
          </Link>
        ))}
      </section>

      {/* Doginal Dogs Originals */}
      <section className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-bold text-white">Doginal Dogs Originals</h2>
            <p className="text-sm text-white/60">Explore 1 video</p>
          </div>
          <Link href="/ott/doginals" className="flex items-center gap-1 text-sm text-orange-500 hover:text-orange-400">
            View All <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
        {DOGINAL_ORIGINALS.map((original) => (
          <Link key={original.id} href={`/watch/${original.id}`}>
            <Card className="group bg-zinc-900/50 border-zinc-800 overflow-hidden hover:border-orange-500/50 transition-colors">
              <div className="md:flex">
                <div className="relative md:w-1/2 aspect-video">
                  <Image
                    src={original.image || "/placeholder.svg"}
                    alt={original.title}
                    fill
                    className="object-cover"
                  />
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                    <div className="w-16 h-16 rounded-full bg-orange-500 flex items-center justify-center">
                      <Play className="w-8 h-8 text-white fill-current" />
                    </div>
                  </div>
                </div>
                <div className="p-6 md:w-1/2 flex flex-col justify-center">
                  <h3 className="text-xl font-bold text-white mb-2">{original.title}</h3>
                  <p className="text-sm text-white/70 mb-4">{original.description}</p>
                  <div className="flex items-center gap-4 text-sm text-white/60">
                    <span className="flex items-center gap-1">
                      <Eye className="w-4 h-4" />
                      {original.views}
                    </span>
                    <span className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-orange-500" />
                      {original.rating}
                    </span>
                    <span>{original.duration}</span>
                  </div>
                </div>
              </div>
            </Card>
          </Link>
        ))}
      </section>

      {/* WIRED CHAOS META */}
      <section className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-bold text-white">WIRED CHAOS META</h2>
            <p className="text-sm text-white/60">Explore 1 video</p>
          </div>
          <Link
            href="/ott/wired-chaos"
            className="flex items-center gap-1 text-sm text-orange-500 hover:text-orange-400"
          >
            View All <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
        <Link href="/watch/wired-chaos-meta">
          <Card className="group bg-zinc-900/50 border-zinc-800 overflow-hidden hover:border-orange-500/50 transition-colors">
            <div className="md:flex">
              <div className="relative md:w-1/2 aspect-video">
                <Image src="/wired-chaos-meta-cyberpunk-thriller-neon.jpg" alt="WIRED CHAOS META" fill className="object-cover" />
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                  <div className="w-16 h-16 rounded-full bg-orange-500 flex items-center justify-center">
                    <Play className="w-8 h-8 text-white fill-current" />
                  </div>
                </div>
              </div>
              <div className="p-6 md:w-1/2 flex flex-col justify-center">
                <h3 className="text-xl font-bold text-white mb-2">WIRED CHAOS META: Quantum Heist</h3>
                <p className="text-sm text-white/70 mb-4">
                  A cyber-thriller where the metaverse meets reality in explosive fashion
                </p>
                <div className="flex items-center gap-4 text-sm text-white/60">
                  <span className="flex items-center gap-1">
                    <Eye className="w-4 h-4" />
                    270,000
                  </span>
                  <span className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-orange-500" />
                    18,600
                  </span>
                  <span>1h 42m</span>
                </div>
              </div>
            </div>
          </Card>
        </Link>
      </section>

      {/* Creator Program CTA */}
      <section className="max-w-7xl mx-auto px-4 py-12">
        <Card className="bg-gradient-to-r from-zinc-900 to-zinc-800 border-orange-500/30 p-8 md:p-12">
          <div className="md:flex items-center justify-between gap-8">
            <div className="space-y-4 mb-6 md:mb-0">
              <h2 className="text-2xl md:text-3xl font-bold text-white">Join 789 Studios Creator Program</h2>
              <p className="text-white/70 max-w-xl">
                Launch your Film3 content with blockchain-powered tools, token-gated episodes, and instant crypto
                payments
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <Button className="bg-orange-500 hover:bg-orange-600 text-white font-bold">Start Creating</Button>
              <Button
                variant="outline"
                className="border-orange-500/50 text-orange-500 hover:bg-orange-500/10 bg-transparent"
              >
                Become an Affiliate
              </Button>
            </div>
          </div>
        </Card>
      </section>

      {/* Clipping Tool Modal */}
      {showClipTool && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <Card className="bg-zinc-900 border-orange-500/30 w-full max-w-2xl max-h-[90vh] overflow-auto">
            <div className="p-6 border-b border-zinc-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Scissors className="w-6 h-6 text-orange-500" />
                <h2 className="text-xl font-bold text-white">Create Promo Clip</h2>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowClipTool(false)}
                className="text-white/60 hover:text-white"
              >
                Close
              </Button>
            </div>
            <div className="p-6 space-y-6">
              {/* Preview */}
              <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
                <Image
                  src={HERO_CONTENT.find((h) => h.id === selectedContent)?.image || HERO_CONTENT[0].image}
                  alt="Clip preview"
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-16 h-16 rounded-full bg-orange-500/80 flex items-center justify-center">
                    <Play className="w-8 h-8 text-white fill-current" />
                  </div>
                </div>
              </div>

              {/* Timeline */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-white">Clip Range</label>
                <div className="h-12 bg-zinc-800 rounded-lg relative">
                  <div className="absolute left-[10%] right-[30%] top-1 bottom-1 bg-orange-500/30 border-2 border-orange-500 rounded" />
                  <div className="absolute inset-x-0 bottom-0 h-1 bg-zinc-700">
                    <div className="absolute left-0 right-[70%] h-full bg-orange-500" />
                  </div>
                </div>
                <div className="flex justify-between text-xs text-white/60">
                  <span>0:00</span>
                  <span>Start: 0:15</span>
                  <span>End: 0:45</span>
                  <span>1:42:00</span>
                </div>
              </div>

              {/* Clip Settings */}
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-white">Clip Duration</label>
                  <select className="w-full bg-zinc-800 border-zinc-700 rounded-lg px-3 py-2 text-white text-sm">
                    <option>15 seconds</option>
                    <option>30 seconds</option>
                    <option>60 seconds</option>
                    <option>Custom</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-white">Output Format</label>
                  <select className="w-full bg-zinc-800 border-zinc-700 rounded-lg px-3 py-2 text-white text-sm">
                    <option>MP4 (Social)</option>
                    <option>GIF</option>
                    <option>WebM</option>
                  </select>
                </div>
              </div>

              {/* Watermark */}
              <div className="flex items-center gap-3">
                <input type="checkbox" id="watermark" defaultChecked className="rounded bg-zinc-800 border-zinc-700" />
                <label htmlFor="watermark" className="text-sm text-white/80">
                  Add 789 Studios watermark
                </label>
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-4">
                <Button className="flex-1 bg-orange-500 hover:bg-orange-600 text-white font-bold gap-2">
                  <Download className="w-4 h-4" />
                  Generate Clip
                </Button>
                <Button variant="outline" className="border-zinc-700 text-white hover:bg-zinc-800 gap-2 bg-transparent">
                  <Share2 className="w-4 h-4" />
                  Share
                </Button>
              </div>
            </div>
          </Card>
        </div>
      )}

      <GlobalDisclaimer />
    </VirtualSoundstage>
  )
}
