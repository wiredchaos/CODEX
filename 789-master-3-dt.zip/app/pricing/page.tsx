"use client"

import { VirtualSoundstage } from "@/components/virtual-soundstage"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BackButton } from "@/components/ui/back-button"

export default function PricingPage() {
  return (
    <VirtualSoundstage>
      {/* Top Navigation Bar */}
      <div className="border-b border-border/30 bg-black/40 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <BackButton fallbackHref="/" />
            <Link href="/" className="text-sm font-bold neon-text-gold">
              789
            </Link>
            <nav className="hidden md:flex items-center gap-4">
              <Link href="/" className="text-sm text-white/70 hover:text-white transition-colors">
                Studios
              </Link>
              <Link href="/spaces" className="text-sm text-white/70 hover:text-white transition-colors">
                Spaces Network
              </Link>
              <Link href="/pricing" className="text-sm text-foreground font-semibold">
                Pricing
              </Link>
            </nav>
          </div>
          <Button
            size="sm"
            className="font-semibold uppercase tracking-wide text-black hover:opacity-90"
            style={{
              background: "#ffd700",
              boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
            }}
          >
            Book Session
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12 space-y-12">
        {/* Header */}
        <header className="text-center space-y-4">
          <h1 className="text-3xl md:text-5xl font-bold tracking-tight chrome-text">Studio Pricing</h1>
          <p className="text-base md:text-lg text-white/80 max-w-2xl mx-auto leading-relaxed">
            Flexible pricing options for artists, producers, and content creators
          </p>
        </header>

        {/* Pricing Tiers */}
        <div className="grid md:grid-cols-3 gap-8">
          {/* STARTER */}
          <div className="glass-panel rounded-lg p-8 border-2 border-[#daa520]/30 hover:border-[#daa520]/60 transition-all space-y-6">
            <div className="space-y-2">
              <h3 className="label-ui neon-text-goldenrod">Starter</h3>
              <div className="flex items-baseline gap-2">
                <span className="font-mono text-4xl font-bold neon-text-gold">$75</span>
                <span className="text-sm text-white/80">/hour</span>
              </div>
              <p className="text-sm text-white/70">Perfect for demos and quick sessions</p>
            </div>

            <div className="space-y-3">
              {[
                "Basic recording setup",
                "Engineer assistance included",
                "Standard microphone selection",
                "Mixed stems delivery",
                "2-day turnaround",
              ].map((feature) => (
                <div key={feature} className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-[#daa520] mt-1.5" style={{ boxShadow: "0 0 8px #daa520" }} />
                  <span className="text-sm text-foreground">{feature}</span>
                </div>
              ))}
            </div>

            <Button
              variant="outline"
              className="w-full font-semibold uppercase tracking-wide border-[#daa520] hover:bg-[#daa520]/10 bg-transparent text-[#daa520]"
            >
              Book Starter
            </Button>
          </div>

          {/* PRO */}
          <div className="glass-panel rounded-lg p-8 border-2 border-[#ffd700] hover:border-[#ffd700] transition-all space-y-6 relative">
            <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
              <span className="label-ui px-3 py-1 bg-[#ffd700] text-black rounded">Most Popular</span>
            </div>

            <div className="space-y-2">
              <h3 className="label-ui neon-text-gold">Pro</h3>
              <div className="flex items-baseline gap-2">
                <span className="font-mono text-4xl font-bold neon-text-gold">$150</span>
                <span className="text-sm text-white/80">/hour</span>
              </div>
              <p className="text-sm text-white/70">Full production suite for serious projects</p>
            </div>

            <div className="space-y-3">
              {[
                "SSL console + premium plugins",
                "Expert engineer + producer",
                "Premium mic locker access",
                "Mixing + mastering included",
                "24-hour turnaround",
                "Unlimited revisions",
              ].map((feature) => (
                <div key={feature} className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-[#ffd700] mt-1.5" style={{ boxShadow: "0 0 8px #ffd700" }} />
                  <span className="text-sm text-foreground">{feature}</span>
                </div>
              ))}
            </div>

            <Button
              className="w-full font-semibold uppercase tracking-wide text-black hover:opacity-90"
              style={{
                background: "#ffd700",
                boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
              }}
            >
              Book Pro
            </Button>
          </div>

          {/* UNLIMITED */}
          <div className="glass-panel rounded-lg p-8 border-2 border-[#00ffff]/30 hover:border-[#00ffff]/60 transition-all space-y-6">
            <div className="space-y-2">
              <h3 className="label-ui neon-text-cyan">Unlimited</h3>
              <div className="flex items-baseline gap-2">
                <span className="font-mono text-4xl font-bold neon-text-cyan">$2K</span>
                <span className="text-sm text-white/80">/month</span>
              </div>
              <p className="text-sm text-white/70">24/7 access for power users</p>
            </div>

            <div className="space-y-3">
              {[
                "Unlimited studio time",
                "Priority booking + 24/7 access",
                "Remote collaboration tools",
                "Dedicated engineer",
                "Cloud storage + project backups",
                "Livestream capability",
              ].map((feature) => (
                <div key={feature} className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-[#00ffff] mt-1.5" style={{ boxShadow: "0 0 8px #00ffff" }} />
                  <span className="text-sm text-foreground">{feature}</span>
                </div>
              ))}
            </div>

            <Button
              variant="outline"
              className="w-full font-semibold uppercase tracking-wide border-[#00ffff] hover:bg-[#00ffff]/10 bg-transparent text-[#00ffff]"
            >
              Book Unlimited
            </Button>
          </div>
        </div>

        {/* Additional Services */}
        <section className="glass-panel rounded-lg p-8 md:p-12 border-2 border-border/30 space-y-6">
          <h2 className="text-2xl font-bold chrome-text text-center">Additional Services</h2>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-3 p-6 rounded bg-background/50 border border-border/30">
              <h4 className="label-ui neon-text-gold">Project-Based Packages</h4>
              <div className="space-y-2">
                {[
                  { name: "Single Track (Mix + Master)", price: "$300" },
                  { name: "EP Package (5 tracks)", price: "$1,200" },
                  { name: "Album Package (10+ tracks)", price: "$2,500" },
                ].map((item) => (
                  <div key={item.name} className="flex justify-between items-center">
                    <span className="text-sm text-foreground">{item.name}</span>
                    <span className="font-mono text-sm text-[#ffd700]">{item.price}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-3 p-6 rounded bg-background/50 border border-border/30">
              <h4 className="label-ui neon-text-cyan">Content Creation</h4>
              <div className="space-y-2">
                {[
                  { name: "Podcast Recording (2 hrs)", price: "$200" },
                  { name: "Video Production Session", price: "$500" },
                  { name: "Livestream Setup + Support", price: "$400" },
                ].map((item) => (
                  <div key={item.name} className="flex justify-between items-center">
                    <span className="text-sm text-foreground">{item.name}</span>
                    <span className="font-mono text-sm text-[#00ffff]">{item.price}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Revenue Model Overview */}
        <section className="glass-panel rounded-lg p-8 md:p-12 border-2 border-[#ffd700]/20 space-y-6">
          <h2 className="text-2xl font-bold neon-text-gold text-center">789 Revenue Engine</h2>
          <p className="text-base text-white/80 text-center max-w-3xl mx-auto leading-relaxed">
            Multiple revenue streams ensure sustainable operations and continuous infrastructure improvements
          </p>

          <div className="grid md:grid-cols-3 gap-6 pt-6">
            {[
              {
                icon: "$",
                title: "Hourly Bookings",
                desc: "Pay-per-use studio access with tiered pricing",
                color: "#ffd700",
              },
              {
                icon: "∞",
                title: "Subscriptions",
                desc: "Recurring monthly revenue from unlimited members",
                color: "#00ffff",
              },
              {
                icon: "⬡",
                title: "Project Packages",
                desc: "Fixed-price deliverables for complete projects",
                color: "#daa520",
              },
            ].map((item) => (
              <div key={item.title} className="text-center space-y-3">
                <div
                  className="w-16 h-16 rounded-full flex items-center justify-center mx-auto"
                  style={{
                    background: `${item.color}15`,
                    border: `2px solid ${item.color}`,
                  }}
                >
                  <span className="text-2xl font-bold" style={{ color: item.color }}>
                    {item.icon}
                  </span>
                </div>
                <h4 className="text-base font-semibold chrome-text">{item.title}</h4>
                <p className="text-sm text-white/70">{item.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* CTA */}
        <div className="text-center space-y-4">
          <h3 className="text-xl font-bold chrome-text">Ready to Start?</h3>
          <Button
            size="lg"
            className="font-semibold uppercase tracking-wide text-black hover:opacity-90"
            style={{
              background: "#ffd700",
              boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
            }}
          >
            Book Your First Session
          </Button>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-border/30 mt-16 py-8 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <span className="text-sm text-white/70">789 Studios © 2025 · Virtual Production System</span>
            <Link href="/" className="text-sm text-white/70 hover:text-[#ffd700] transition-colors">
              ← Back to Home
            </Link>
          </div>
        </div>
      </footer>
    </VirtualSoundstage>
  )
}
