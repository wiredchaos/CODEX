import type { Metadata } from "next"
import { LurkyCampaignBot } from "@/components/lurky-campaign-bot"
import { Bot, Sparkles, Radio, Film, Users } from "lucide-react"

export const metadata: Metadata = {
  title: "Campaign Bot | 789 Studios",
  description: "Autonomous campaign promo generator powered by Lurky intelligence",
}

export default function CampaignsPage() {
  return (
    <main className="min-h-screen bg-black">
      {/* Hero Section */}
      <section className="relative overflow-hidden border-b border-cyan-500/20 py-20">
        <div className="absolute inset-0 bg-gradient-to-b from-cyan-950/30 via-black to-black" />
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: "radial-gradient(circle at 50% 50%, rgba(0,255,255,0.3) 0%, transparent 50%)",
          }}
        />

        <div className="relative mx-auto max-w-6xl px-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="rounded-full bg-cyan-500/20 p-2">
              <Bot className="h-6 w-6 text-cyan-400" />
            </div>
            <span className="font-mono text-sm uppercase tracking-wider text-cyan-400">Lurky Intelligence</span>
          </div>

          <h1 className="mb-4 font-mono text-4xl font-bold md:text-5xl">
            <span className="text-white">CAMPAIGN</span>{" "}
            <span
              style={{
                background: "linear-gradient(90deg, #00ffff, #ff00ff)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              BOT
            </span>
          </h1>

          <p className="max-w-2xl font-mono text-lg text-white/60">
            Autonomous promo generator that crawls 789 Studios for campaigns, shows, spaces, and allies. Generate
            holographic 3D promo cards ready for X deployment.
          </p>

          {/* Stats */}
          <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-4">
            {[
              { icon: Film, label: "Shows", value: "6+" },
              { icon: Radio, label: "Spaces", value: "24/7" },
              { icon: Users, label: "Allies", value: "8+" },
              { icon: Sparkles, label: "Promos", value: "∞" },
            ].map((stat, i) => (
              <div key={i} className="rounded-lg border border-cyan-500/20 bg-black/50 p-4 backdrop-blur">
                <stat.icon className="mb-2 h-5 w-5 text-cyan-400" />
                <div className="font-mono text-2xl font-bold text-white">{stat.value}</div>
                <div className="font-mono text-xs text-white/50">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Bot Section */}
      <section className="py-12">
        <div className="mx-auto max-w-4xl px-4">
          <LurkyCampaignBot />
        </div>
      </section>

      {/* How It Works */}
      <section className="border-t border-cyan-500/20 py-16">
        <div className="mx-auto max-w-6xl px-4">
          <h2 className="mb-8 font-mono text-2xl font-bold text-white">How It Works</h2>

          <div className="grid gap-6 md:grid-cols-3">
            {[
              {
                step: "01",
                title: "Crawl",
                description:
                  "Lurky scans the entire 789 Studios ecosystem for active campaigns, shows, spaces, and ally networks.",
              },
              {
                step: "02",
                title: "Generate",
                description:
                  "AI powered promo text is generated with optimized hashtags and calls to action for maximum engagement.",
              },
              {
                step: "03",
                title: "Deploy",
                description: "One click sharing to X with holographic 3D promo cards that stand out in the timeline.",
              },
            ].map((item, i) => (
              <div
                key={i}
                className="group relative overflow-hidden rounded-xl border border-cyan-500/20 bg-black/50 p-6 transition-all hover:border-cyan-500/50"
              >
                <div className="absolute -right-4 -top-4 font-mono text-6xl font-bold text-cyan-500/10">
                  {item.step}
                </div>
                <h3 className="mb-2 font-mono text-lg font-bold text-cyan-400">{item.title}</h3>
                <p className="font-mono text-sm text-white/60">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-cyan-500/20 py-8">
        <div className="mx-auto max-w-6xl px-4 text-center">
          <p className="font-mono text-sm text-white/40">Powered by Lurky Intelligence and 789 Studios</p>
        </div>
      </footer>
    </main>
  )
}
