"use client"

import { VirtualSoundstage } from "@/components/virtual-soundstage"
import { NavigationalAvatar } from "@/components/navigational-avatar"
import { GlobalDisclaimer } from "@/components/global-disclaimer"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Users, Shield, Globe, Twitter } from "lucide-react"
import Image from "next/image"
import { BackButton } from "@/components/ui/back-button"

const ALLIES = [
  {
    name: "NEURO META X",
    tagline: "AI-powered content creation and Web3 journalism by NEURO.",
    description:
      "NEURO META X is NEURO's flagship platform for AI-assisted content creation, Web3 journalism, and decoding the hidden layers of technology, metaphysics, and media. Bridging Web2 to Web3 through Wired Chaos reporting, NeuroMetaX empowers creators with AI ghostwriting, translation services, and next-gen storytelling tools.",
    pillars: ["AI Content Creation", "Web3 Journalism", "Wired Chaos", "Meta Analysis"],
    focus: ["AI ghostwriting", "Web2 → Web3 translation", "Neural networks", "Media history"],
    links: { website: "", x: "https://x.com/neurometax" },
    color: "#00ffff",
    image: "/neuro-meta-x-ai-brain-digital-cyan.jpg",
    role: "Host & Contributor",
  },
  {
    name: "TYPE / TYPE MEDIA",
    tagline: "The engine behind a growing movement of creators, culture, and innovation.",
    description:
      "TYPE is a next-generation brand ecosystem built around creators, culture, and scalable innovation. Rooted in community and designed for growth, TYPE spans content, products, and experiences under a unified brand architecture.",
    pillars: ["TYPE Media", "TYPE DAO", "TYPE Shop", "TYPE Growth"],
    focus: ["Creator-centric media", "DAO participation", "Merch & collectibles", "Growth strategy"],
    links: { website: "https://typebrand.xyz", x: "https://x.com/typemedia" },
    color: "#00ffff",
    image: "/type-media-brand-modern-logo-cyan.jpg",
    role: "Media Partner",
  },
  {
    name: "Beanies on Business",
    tagline: "A community of builders, creators, and innovators.",
    description:
      "Beanies on Business is a community and DAO ecosystem centered on builders, creators, and innovators working together under a shared vision. The group emphasizes long-term construction over hype.",
    pillars: ["20 Founding Members", "250+ Community", "Crypto Sauce Show", "Beanie DAO"],
    focus: ["Community-led business", "Web3 culture", "Educational spaces", "Builder coordination"],
    links: { website: "https://beaniesonbusiness.com", x: "https://x.com/BeanieDaoX" },
    color: "#ffd700",
    image: "/placeholder.svg?height=300&width=400",
    role: "DAO Partner",
  },
  {
    name: "BowMafia / BowDAO",
    tagline: "BowMafiaDAO — a community-powered Doginal Dogs collective.",
    description:
      "BowMafia represents the BowDAO wing of the Doginal Dogs ecosystem, operating as a DAO around a distinct 'bow' aesthetic and cultural identity within the broader Doginal Dogs landscape.",
    pillars: ["BowMafia Identity", "Silk & Bows", "DAO Coordination", "Cross-DAO Participation"],
    focus: ["BowMafia-branded Doginals", "Collective decision-making", "Ecosystem collaborations"],
    links: { website: "https://bowmafia.xyz", x: "https://x.com/BowDAOMeta" },
    color: "#ff69b4",
    image: "/placeholder.svg?height=300&width=400",
    role: "DAO Partner",
  },
  {
    name: "Dogwarts DAO",
    tagline: "Where paws meet potions and tails wag through magic and mischief.",
    description:
      "Dogwarts is a whimsical digital universe and DAO designed for dog lovers, fantasy fans, and blockchain adventurers. The School of Woofcraft and Wizardry functions as a themed Web3 world.",
    pillars: ["The Order of 86", "Magical Packs", "Market Place", "Schedule Events"],
    focus: ["Gamified Web3 experience", "Community events", "Themed collectibles", "Lore-rich universe"],
    links: { website: "https://dogwartsdao.com", x: "" },
    color: "#9945ff",
    image: "/placeholder.svg?height=300&width=400",
    role: "DAO Partner",
  },
  {
    name: "OTF Media",
    tagline: "Building culture, loyalty, and legacy across all communities.",
    description:
      "OTF Media (Only The Family) is described as a 'community of communities,' focused on culture, loyalty, and legacy with strong presence in the Doginal Dogs ecosystem and X Spaces.",
    pillars: ["Only The Family", "Media Amplification", "Cross-Community Support", "Loyalty Culture"],
    focus: ["Presence amplification", "Brand signals", "Community loyalty", "Family values"],
    links: { website: "", x: "https://x.com/OTFMediaX" },
    color: "#ff4500",
    image: "/placeholder.svg?height=300&width=400",
    role: "Media Partner",
  },
  {
    name: "Yellow DAO",
    tagline: "Discover the yellow revolution. Not your regular DAO.",
    description:
      "Yellow DAO (YDAO) is a Doginal Dogs–centric DAO branded as 'the #1 Doginal Dogs DAO,' blending bold yellow aesthetics with culture, collectibles, and community-driven treasury management.",
    pillars: ["#1 Doginal Dogs DAO", "Treasury Wallet", "Reserve Assets", "Community Assets"],
    focus: ["DAO operations", "Lifestyle branding", "Ecosystem partnerships", "Maximum bark per byte"],
    links: { website: "https://yellowdao.xyz", x: "" },
    color: "#ffff00",
    image: "/placeholder.svg?height=300&width=400",
    role: "DAO Partner",
  },
  {
    name: "KennelDAO / Kennel Market",
    tagline: "Creating a revenue-generating DAO in the Doginal Dogs ecosystem.",
    description:
      "KennelDAO (KDAO) is positioned as a DAO dedicated to establishing a revenue-generating structure within the Doginal Dogs ecosystem, closely tied to Kennel Market.",
    pillars: ["Revenue DAO", "Kennel Market", "Doginal Assets", "Yield Mechanics"],
    focus: ["Revenue-oriented mechanics", "Marketplace liquidity", "Community coordination", "Sustainability"],
    links: { website: "https://kennel.market", x: "https://x.com/KennelDAO" },
    color: "#32cd32",
    image: "/placeholder.svg?height=300&width=400",
    role: "DAO Partner",
  },
]

export default function AlliesPage() {
  return (
    <VirtualSoundstage>
      <NavigationalAvatar />

      {/* Header */}
      <div className="border-b border-border/30 bg-black/60 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <BackButton fallbackHref="/" />
            <Link
              href="/"
              className="text-lg font-bold"
              style={{ color: "#ffd700", textShadow: "0 0 10px rgba(255, 215, 0, 0.5)" }}
            >
              789
            </Link>
            <nav className="hidden md:flex items-center gap-4">
              <Link href="/" className="text-sm text-white/70 hover:text-white transition-colors">
                Home
              </Link>
              <Link href="/crew" className="text-sm text-white/70 hover:text-white transition-colors">
                Crew
              </Link>
              <Link href="/allies" className="text-sm text-white font-bold">
                Allies & DAOs
              </Link>
              <Link href="/ott" className="text-sm text-white/70 hover:text-white transition-colors">
                OTT
              </Link>
            </nav>
          </div>
        </div>
      </div>

      {/* Hero */}
      <section className="py-16 px-4 text-center">
        <Badge className="mb-4 bg-[#ffd700]/20 text-[#ffd700] border-[#ffd700]/50">
          <Users className="w-3 h-3 mr-1" />
          789 ECOSYSTEM
        </Badge>
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">ALLIES & DAOs</h1>
        <p className="text-lg text-white/80 max-w-2xl mx-auto">
          The 789 Studios ecosystem connects with leading DAOs, communities, and builders across the Doginal Dogs
          universe and beyond.
        </p>
      </section>

      {/* Stats */}
      <section className="max-w-7xl mx-auto px-4 pb-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-zinc-900/50 border-zinc-800 p-6 text-center">
            <div className="text-3xl font-bold text-[#ffd700] mb-1">8+</div>
            <div className="text-sm text-white/60">Allied DAOs</div>
          </Card>
          <Card className="bg-zinc-900/50 border-zinc-800 p-6 text-center">
            <div className="text-3xl font-bold text-[#00ffff] mb-1">5K+</div>
            <div className="text-sm text-white/60">Combined Members</div>
          </Card>
          <Card className="bg-zinc-900/50 border-zinc-800 p-6 text-center">
            <div className="text-3xl font-bold text-[#ff69b4] mb-1">12+</div>
            <div className="text-sm text-white/60">Active Projects</div>
          </Card>
          <Card className="bg-zinc-900/50 border-zinc-800 p-6 text-center">
            <div className="text-3xl font-bold text-[#32cd32] mb-1">$2M+</div>
            <div className="text-sm text-white/60">Combined Treasury</div>
          </Card>
        </div>
      </section>

      {/* Allies Grid */}
      <section className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 gap-6">
          {ALLIES.map((ally, index) => (
            <Card
              key={index}
              className="bg-zinc-900/50 border-zinc-800 overflow-hidden hover:border-opacity-100 transition-all duration-300 group"
              style={{ borderColor: `${ally.color}40` }}
            >
              {/* Image Header */}
              <div className="relative h-48 overflow-hidden">
                <Image
                  src={ally.image || "/placeholder.svg"}
                  alt={`${ally.name} logo`}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-zinc-900/50 to-transparent" />
                <Badge
                  className="absolute top-4 right-4 text-xs"
                  style={{
                    backgroundColor: `${ally.color}20`,
                    color: ally.color,
                    borderColor: `${ally.color}50`,
                  }}
                >
                  {ally.role}
                </Badge>
              </div>

              <div className="p-6 space-y-4">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-xl font-bold mb-1" style={{ color: ally.color }}>
                      {ally.name}
                    </h3>
                    <p className="text-sm text-white/60 italic">"{ally.tagline}"</p>
                  </div>
                  <div
                    className="w-3 h-3 rounded-full animate-pulse"
                    style={{ background: ally.color, boxShadow: `0 0 15px ${ally.color}` }}
                  />
                </div>

                <p className="text-sm text-white/80 leading-relaxed line-clamp-3">{ally.description}</p>

                {/* Pillars */}
                <div className="flex flex-wrap gap-2">
                  {ally.pillars.slice(0, 3).map((pillar, i) => (
                    <Badge
                      key={i}
                      variant="outline"
                      className="text-xs"
                      style={{
                        backgroundColor: `${ally.color}10`,
                        color: ally.color,
                        borderColor: `${ally.color}30`,
                      }}
                    >
                      {pillar}
                    </Badge>
                  ))}
                  {ally.pillars.length > 3 && (
                    <Badge variant="outline" className="text-xs text-white/50 border-white/20">
                      +{ally.pillars.length - 3}
                    </Badge>
                  )}
                </div>

                {/* Links */}
                <div className="flex gap-3 pt-2">
                  {ally.links.website && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-xs bg-transparent"
                      style={{
                        borderColor: ally.color,
                        color: ally.color,
                      }}
                      asChild
                    >
                      <a href={ally.links.website} target="_blank" rel="noopener noreferrer">
                        <Globe className="w-3 h-3 mr-1" />
                        Website
                      </a>
                    </Button>
                  )}
                  {ally.links.x && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-xs border-white/30 text-white bg-transparent hover:bg-white/10"
                      asChild
                    >
                      <a href={ally.links.x} target="_blank" rel="noopener noreferrer">
                        <Twitter className="w-3 h-3 mr-1" />
                        Follow
                      </a>
                    </Button>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </section>

      {/* Join CTA */}
      <section className="max-w-5xl mx-auto px-4 py-12">
        <Card className="bg-gradient-to-r from-zinc-900 to-zinc-800 border-[#ffd700]/30 p-8 md:p-12 text-center">
          <Shield className="w-12 h-12 text-[#ffd700] mx-auto mb-4" />
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">Become an Ally</h2>
          <p className="text-white/70 max-w-xl mx-auto mb-6">
            Partner with 789 Studios and the Crypto Spaces Network. Join the ecosystem of builders, creators, and DAOs
            shaping the future of decentralized media.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button className="bg-[#ffd700] hover:bg-[#ffd700]/90 text-black font-bold">Apply for Partnership</Button>
            <Button variant="outline" className="border-white/30 text-white hover:bg-white/10 bg-transparent">
              Learn More
            </Button>
          </div>
        </Card>
      </section>

      {/* Disclaimer */}
      <section className="max-w-4xl mx-auto px-4 py-8">
        <Card className="bg-zinc-900/30 border-[#ffd700]/20 p-6">
          <p className="text-xs text-white/50 text-center leading-relaxed">
            <span className="text-[#ffd700] font-bold">Note:</span> All descriptions above are based on publicly
            available information from the projects' own sites and social channels. 789 Studios does not claim ownership
            of, or formal partnership with, any third-party brands, DAOs, or protocols listed here unless explicitly
            stated elsewhere. All trademarks, graphics, and intellectual property remain the exclusive property of their
            respective owners.
          </p>
        </Card>
      </section>

      <GlobalDisclaimer />
    </VirtualSoundstage>
  )
}
