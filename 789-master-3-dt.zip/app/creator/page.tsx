"use client"

import { useState } from "react"
import { VirtualSoundstage } from "@/components/virtual-soundstage"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ClipTool } from "@/components/clip-tool"
import Link from "next/link"
import { Upload, Lock, Video, ImageIcon, FileText, BarChart3, Film, Scissors } from "lucide-react"

export default function CreatorPage() {
  const [showClipTool, setShowClipTool] = useState(false)
  const [selectedContent, setSelectedContent] = useState<{
    id: string
    title: string
    image: string
    duration: number
  } | null>(null)

  const handleOpenClipTool = (content: { id: string; title: string; image: string; duration: number }) => {
    setSelectedContent(content)
    setShowClipTool(true)
  }

  return (
    <VirtualSoundstage>
      {/* Top Navigation Bar */}
      <div className="border-b border-border/30 bg-black/40 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <Link href="/" className="text-sm font-bold neon-text-gold">
              789
            </Link>
            <nav className="hidden md:flex items-center gap-4">
              <Link href="/" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Studios
              </Link>
              <Link href="/creator" className="text-sm text-foreground font-semibold">
                Creator Hub
              </Link>
              <Link href="/mint" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Mint Film
              </Link>
              <Link href="/spaces" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Spaces Network
              </Link>
            </nav>
          </div>
          <Button
            size="sm"
            className="font-semibold uppercase tracking-wide text-black hover:opacity-90"
            style={{
              background: "#ffd700",
              boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
            }}
          >
            Connect Wallet
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12 space-y-12">
        {/* Hero Header */}
        <header className="text-center space-y-4">
          <h1
            className="text-3xl md:text-5xl font-bold tracking-tight chrome-text"
            style={{ textShadow: "0 0 20px rgba(0, 255, 255, 0.6)" }}
          >
            Creator Hub
          </h1>
          <p className="text-base md:text-lg text-white/80 max-w-2xl mx-auto leading-relaxed">
            Multi-platform content publishing, token-gated access, blockchain verified Web3 creator tools
          </p>
        </header>

        {/* Main Content Area */}
        <Tabs defaultValue="publish" className="w-full">
          <TabsList className="grid w-full grid-cols-5 glass-panel">
            <TabsTrigger value="publish" className="text-sm text-white data-[state=active]:text-[#ffd700]">
              Publish
            </TabsTrigger>
            <TabsTrigger value="clips" className="text-sm text-white data-[state=active]:text-[#ffd700]">
              Clip Studio
            </TabsTrigger>
            <TabsTrigger value="content" className="text-sm text-white data-[state=active]:text-[#ffd700]">
              My Content
            </TabsTrigger>
            <TabsTrigger value="analytics" className="text-sm text-white data-[state=active]:text-[#ffd700]">
              Analytics
            </TabsTrigger>
            <TabsTrigger value="token-gate" className="text-sm text-white data-[state=active]:text-[#ffd700]">
              Token Gate
            </TabsTrigger>
          </TabsList>

          {/* Publish Tab */}
          <TabsContent value="publish" className="space-y-6">
            <Card className="glass-panel border-[#ffd700]/20 p-6 space-y-6">
              <div className="space-y-2">
                <h2 className="text-xl font-bold neon-text-gold">Multi-Platform Publisher</h2>
                <p className="text-sm text-white/80">
                  Post to YouTube, X, Instagram, TikTok, and LinkedIn simultaneously
                </p>
              </div>

              <div className="glass-panel-enhanced rounded-lg p-4 border border-[#daa520]/30 bg-[#daa520]/5">
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <Film className="w-8 h-8 text-[#daa520]" />
                    <div>
                      <h3 className="text-sm font-bold text-white">Got a film? Mint it as an NFT</h3>
                      <p className="text-sm text-white/70">Earn 90% revenue, set your own pricing, token-gate access</p>
                    </div>
                  </div>
                  <Button
                    className="font-semibold uppercase tracking-wide text-black hover:opacity-90 shrink-0"
                    style={{
                      background: "#daa520",
                      boxShadow: "0 0 20px rgba(218, 165, 32, 0.5)",
                    }}
                    asChild
                  >
                    <Link href="/mint">Mint Film</Link>
                  </Button>
                </div>
              </div>

              {/* Content Type Selector */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <button className="glass-panel p-4 rounded-lg border border-[#00ffff]/30 hover:border-[#00ffff] transition-colors flex flex-col items-center gap-2 group">
                  <Video className="w-8 h-8 text-[#00ffff] group-hover:drop-shadow-[0_0_10px_rgba(0,255,255,0.8)]" />
                  <span className="text-sm text-white">Video</span>
                </button>
                <button className="glass-panel p-4 rounded-lg border border-[#ffd700]/30 hover:border-[#ffd700] transition-colors flex flex-col items-center gap-2 group">
                  <ImageIcon className="w-8 h-8 text-[#ffd700] group-hover:drop-shadow-[0_0_10px_rgba(255,215,0,0.8)]" />
                  <span className="text-sm text-white">Image</span>
                </button>
                <button className="glass-panel p-4 rounded-lg border border-[#daa520]/30 hover:border-[#daa520] transition-colors flex flex-col items-center gap-2 group">
                  <FileText className="w-8 h-8 text-[#daa520] group-hover:drop-shadow-[0_0_10px_rgba(218,165,32,0.8)]" />
                  <span className="text-sm text-white">Text</span>
                </button>
                <button className="glass-panel p-4 rounded-lg border border-[#00ffff]/30 hover:border-[#00ffff] transition-colors flex flex-col items-center gap-2 group">
                  <Upload className="w-8 h-8 text-[#00ffff] group-hover:drop-shadow-[0_0_10px_rgba(0,255,255,0.8)]" />
                  <span className="text-sm text-white">Upload</span>
                </button>
              </div>

              {/* Platform Selector */}
              <div className="space-y-3">
                <label className="label-ui text-white/90">Publish To</label>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                  {[
                    { name: "YouTube", color: "#ff0000", enabled: true },
                    { name: "X (Twitter)", color: "#1da1f2", enabled: true },
                    { name: "Instagram", color: "#e4405f", enabled: true },
                    { name: "TikTok", color: "#00f2ea", enabled: true },
                    { name: "LinkedIn", color: "#0077b5", enabled: true },
                  ].map((platform) => (
                    <label
                      key={platform.name}
                      className="glass-panel p-3 rounded-lg border border-border/30 hover:border-[#ffd700]/50 cursor-pointer transition-colors flex items-center gap-2"
                    >
                      <input type="checkbox" className="w-4 h-4" defaultChecked={platform.enabled} />
                      <span className="text-sm text-white">{platform.name}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Content Input */}
              <div className="space-y-3">
                <label className="label-ui text-white/90">Content</label>
                <textarea
                  className="w-full h-32 glass-panel rounded-lg p-4 text-sm text-white placeholder:text-white/40 border border-border/30 focus:border-[#ffd700]/50 focus:outline-none resize-none"
                  placeholder="Write your post content here..."
                />
              </div>

              {/* Token-Gate Option */}
              <div className="glass-panel-enhanced rounded-lg p-4 border border-[#ffd700]/20 flex items-start gap-3">
                <Lock className="w-5 h-5 text-[#ffd700] mt-1 flex-shrink-0" />
                <div className="flex-1 space-y-2">
                  <div className="flex items-center gap-2">
                    <input type="checkbox" id="token-gate" className="w-4 h-4" />
                    <label htmlFor="token-gate" className="text-sm font-bold text-[#ffd700]">
                      Token-Gate This Content
                    </label>
                  </div>
                  <p className="text-sm text-white/70">
                    Require NFT or token ownership to access this content. Supports ERC-721, ERC-1155, and SPL tokens.
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3">
                <Button
                  size="lg"
                  className="flex-1 font-semibold uppercase tracking-wide text-black hover:opacity-90"
                  style={{
                    background: "#ffd700",
                    boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
                  }}
                >
                  Publish Now
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="font-semibold uppercase tracking-wide border-[#00ffff] hover:bg-[#00ffff]/10 bg-transparent text-[#00ffff]"
                >
                  Schedule
                </Button>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="clips" className="space-y-6">
            <Card className="glass-panel border-[#ff6b00]/20 p-6 space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-lg bg-[#ff6b00]/20 border border-[#ff6b00]/30 flex items-center justify-center">
                  <Scissors className="w-6 h-6 text-[#ff6b00]" />
                </div>
                <div>
                  <h2 className="text-xl font-bold" style={{ color: "#ff6b00" }}>
                    Clip Studio
                  </h2>
                  <p className="text-sm text-white/70">Create shareable promo clips from your content</p>
                </div>
              </div>

              <p className="text-sm text-white/80 leading-relaxed">
                Turn your long-form content into viral clips. Set start and end points, choose aspect ratios for
                different platforms, and export in multiple formats. Perfect for creating Stories, Reels, TikToks, and
                teasers.
              </p>

              {/* Recent Content to Clip */}
              <div className="space-y-4">
                <h3 className="text-sm font-bold text-white">Select Content to Clip</h3>
                <div className="grid gap-4">
                  {[
                    {
                      id: "wired-chaos",
                      title: "WIRED CHAOS META: Quantum Heist",
                      image: "/cyberpunk-quantum-heist.jpg",
                      duration: 3600,
                    },
                    {
                      id: "doginal-ep1",
                      title: "Doginal Dogs: Episode 1 - The Pack Assembles",
                      image: "/animated-dogs-cartoon.jpg",
                      duration: 840,
                    },
                    {
                      id: "genesis",
                      title: "Genesis Protocol: The First Block",
                      image: "/blockchain-documentary.jpg",
                      duration: 5400,
                    },
                  ].map((content) => (
                    <div
                      key={content.id}
                      className="flex items-center gap-4 p-4 rounded-lg bg-white/5 border border-white/10 hover:border-[#ff6b00]/50 transition-all cursor-pointer group"
                      onClick={() => handleOpenClipTool(content)}
                    >
                      <div className="relative w-24 h-16 rounded overflow-hidden bg-black/40 shrink-0">
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Video className="w-8 h-8 text-white/30" />
                        </div>
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-bold text-white group-hover:text-[#ff6b00] transition-colors truncate">
                          {content.title}
                        </h4>
                        <p className="text-xs text-white/50">
                          Duration: {Math.floor(content.duration / 60)}:
                          {(content.duration % 60).toString().padStart(2, "0")}
                        </p>
                      </div>
                      <Button
                        size="sm"
                        className="shrink-0 bg-[#ff6b00] hover:bg-[#ff6b00]/80 text-white font-bold gap-2"
                      >
                        <Scissors className="w-4 h-4" />
                        Clip
                      </Button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Clip Features */}
              <div className="grid md:grid-cols-3 gap-4 pt-4 border-t border-white/10">
                <div className="p-4 rounded-lg bg-white/5 border border-white/10">
                  <h4 className="text-sm font-bold text-[#ff6b00] mb-2">Multiple Formats</h4>
                  <p className="text-xs text-white/70">Export as MP4, GIF, or WebM for any platform</p>
                </div>
                <div className="p-4 rounded-lg bg-white/5 border border-white/10">
                  <h4 className="text-sm font-bold text-[#ff6b00] mb-2">Aspect Ratios</h4>
                  <p className="text-xs text-white/70">16:9 for YouTube, 9:16 for Stories/Reels, 1:1 for feeds</p>
                </div>
                <div className="p-4 rounded-lg bg-white/5 border border-white/10">
                  <h4 className="text-sm font-bold text-[#ff6b00] mb-2">Quick Presets</h4>
                  <p className="text-xs text-white/70">Story (15s), Reel (30s), Teaser (60s) one-click presets</p>
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* My Content Tab */}
          <TabsContent value="content" className="space-y-6">
            <div className="grid gap-4">
              {[1, 2, 3].map((item) => (
                <Card
                  key={item}
                  className="glass-panel border-border/30 p-6 hover:border-[#ffd700]/30 transition-colors"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-24 h-24 rounded bg-muted/20 flex items-center justify-center">
                      <Video className="w-10 h-10 text-muted-foreground" />
                    </div>
                    <div className="flex-1 space-y-2">
                      <h3 className="text-base font-semibold text-white">Sample Content Post {item}</h3>
                      <p className="text-sm text-white/60">Published to 5 platforms · 12,543 views · Token-gated</p>
                      <div className="flex gap-2 pt-2">
                        <span className="px-2 py-1 rounded-full bg-[#00ffff]/10 border border-[#00ffff]/30 text-xs text-[#00ffff]">
                          YouTube
                        </span>
                        <span className="px-2 py-1 rounded-full bg-[#ffd700]/10 border border-[#ffd700]/30 text-xs text-[#ffd700]">
                          X
                        </span>
                        <span className="px-2 py-1 rounded-full bg-[#daa520]/10 border border-[#daa520]/30 text-xs text-[#daa520]">
                          Instagram
                        </span>
                        <button
                          onClick={() =>
                            handleOpenClipTool({
                              id: `content-${item}`,
                              title: `Sample Content Post ${item}`,
                              image: "/placeholder.svg",
                              duration: 300,
                            })
                          }
                          className="px-2 py-1 rounded-full bg-[#ff6b00]/10 border border-[#ff6b00]/30 text-xs text-[#ff6b00] hover:bg-[#ff6b00]/20 transition-colors flex items-center gap-1"
                        >
                          <Scissors className="w-3 h-3" />
                          Clip
                        </button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid md:grid-cols-3 gap-4">
              {[
                { label: "Total Views", value: "125.4K", color: "#00ffff" },
                { label: "Engagement", value: "8.2%", color: "#ffd700" },
                { label: "Token-Gated", value: "42", color: "#daa520" },
              ].map((stat) => (
                <Card key={stat.label} className="glass-panel border-border/30 p-6 text-center space-y-2">
                  <BarChart3
                    className="w-8 h-8 mx-auto"
                    style={{
                      color: stat.color,
                      filter: `drop-shadow(0 0 10px ${stat.color}80)`,
                    }}
                  />
                  <div className="font-mono text-2xl font-bold" style={{ color: stat.color }}>
                    {stat.value}
                  </div>
                  <div className="text-sm text-white/70">{stat.label}</div>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Token Gate Tab */}
          <TabsContent value="token-gate" className="space-y-6">
            <Card className="glass-panel border-[#ffd700]/20 p-6 space-y-6">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Lock className="w-6 h-6 text-[#ffd700]" />
                  <h2 className="text-xl font-bold neon-text-gold">Token-Gated Access</h2>
                </div>
                <p className="text-sm text-white/70">Control access to your content with NFT or token requirements</p>
              </div>

              <div className="space-y-4">
                <div className="glass-panel-enhanced rounded-lg p-4 space-y-3">
                  <label className="label-ui text-[#00ffff]">Blockchain</label>
                  <select className="w-full glass-panel rounded p-3 text-sm text-white border border-border/30 focus:border-[#00ffff]/50 focus:outline-none bg-black/60">
                    <option className="bg-black text-white">Ethereum</option>
                    <option className="bg-black text-white">Solana</option>
                    <option className="bg-black text-white">Polygon</option>
                    <option className="bg-black text-white">Base</option>
                  </select>
                </div>

                <div className="glass-panel-enhanced rounded-lg p-4 space-y-3">
                  <label className="label-ui text-[#00ffff]">Token Contract Address</label>
                  <input
                    type="text"
                    className="w-full glass-panel rounded p-3 text-sm text-white placeholder:text-white/40 border border-border/30 focus:border-[#00ffff]/50 focus:outline-none bg-black/60"
                    placeholder="0x..."
                  />
                </div>

                <div className="glass-panel-enhanced rounded-lg p-4 space-y-3">
                  <label className="label-ui text-[#00ffff]">Minimum Balance</label>
                  <input
                    type="number"
                    className="w-full glass-panel rounded p-3 text-sm text-white placeholder:text-white/40 border border-border/30 focus:border-[#00ffff]/50 focus:outline-none bg-black/60"
                    placeholder="1"
                  />
                </div>
              </div>

              <Button
                size="lg"
                className="w-full font-semibold uppercase tracking-wide text-black hover:opacity-90"
                style={{
                  background: "#ffd700",
                  boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
                }}
              >
                Save Access Rules
              </Button>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Platform Features */}
        <section className="grid md:grid-cols-4 gap-6">
          <Card className="glass-panel border-[#00ffff]/20 p-6 space-y-3">
            <div className="w-12 h-12 rounded-full bg-[#00ffff]/10 border border-[#00ffff]/30 flex items-center justify-center">
              <Upload className="w-6 h-6 text-[#00ffff]" />
            </div>
            <h3 className="text-lg font-bold neon-text-cyan">Multi-Platform Publishing</h3>
            <p className="text-sm text-white/70 leading-relaxed">
              Publish once to all major platforms. YouTube, X, Instagram, TikTok, and LinkedIn all from one dashboard.
            </p>
          </Card>

          <Card className="glass-panel border-[#ff6b00]/20 p-6 space-y-3">
            <div className="w-12 h-12 rounded-full bg-[#ff6b00]/10 border border-[#ff6b00]/30 flex items-center justify-center">
              <Scissors className="w-6 h-6 text-[#ff6b00]" />
            </div>
            <h3 className="text-lg font-bold" style={{ color: "#ff6b00" }}>
              Clip Studio
            </h3>
            <p className="text-sm text-white/70 leading-relaxed">
              Create viral clips from your content. Multiple formats, aspect ratios, and one-click presets for any
              platform.
            </p>
          </Card>

          <Card className="glass-panel border-[#ffd700]/20 p-6 space-y-3">
            <div className="w-12 h-12 rounded-full bg-[#ffd700]/10 border border-[#ffd700]/30 flex items-center justify-center">
              <Lock className="w-6 h-6 text-[#ffd700]" />
            </div>
            <h3 className="text-lg font-bold neon-text-gold">Token-Gated Access</h3>
            <p className="text-sm text-white/70 leading-relaxed">
              Monetize your content with NFT and token requirements. Full control over who can access your exclusive
              content.
            </p>
          </Card>

          <Card className="glass-panel border-[#daa520]/20 p-6 space-y-3">
            <div className="w-12 h-12 rounded-full bg-[#daa520]/10 border border-[#daa520]/30 flex items-center justify-center">
              <BarChart3 className="w-6 h-6 text-[#daa520]" />
            </div>
            <h3 className="text-lg font-bold neon-text-goldenrod">Analytics Dashboard</h3>
            <p className="text-sm text-white/70 leading-relaxed">
              Track your content performance across all platforms. Real-time engagement metrics and audience insights.
            </p>
          </Card>
        </section>
      </div>

      {/* Footer */}
      <footer className="border-t border-border/30 mt-16 py-8 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <span className="text-sm text-white/70">789 Studios © 2025 · Virtual Production System</span>
            <Link href="/" className="text-sm text-white/70 hover:text-[#ffd700] transition-colors">
              ← Back to Home
            </Link>
          </div>
        </div>
      </footer>

      {showClipTool && selectedContent && (
        <ClipTool
          contentId={selectedContent.id}
          contentTitle={selectedContent.title}
          contentImage={selectedContent.image}
          contentDuration={selectedContent.duration}
          onClose={() => {
            setShowClipTool(false)
            setSelectedContent(null)
          }}
        />
      )}
    </VirtualSoundstage>
  )
}
