"use client"

import { VirtualSoundstage } from "@/components/virtual-soundstage"
import { SpacesScheduleGrid } from "@/components/spaces-schedule-grid"
import { DoginalDogsBanner } from "@/components/doginal-dogs-banner"
import { BroadcastTicker } from "@/components/broadcast-ticker"
import { CSNLiveFeed } from "@/components/csn-live-feed"
import { CRYPTO_SPACES_NETWORK, STUDIOS_789, STUDIOS_789_TEAM } from "@/lib/spaces-schedule"
import Link from "next/link"
import Image from "next/image"
import { BackButton } from "@/components/ui/back-button"
import { ExternalLink } from "lucide-react"

export default function SpacesPage() {
  return (
    <VirtualSoundstage>
      {/* Top Navigation Bar */}
      <div className="border-b border-border/30 bg-black/40 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <BackButton fallbackHref="/" />
            <a
              href={CRYPTO_SPACES_NETWORK.websiteUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="font-mono text-xs font-bold text-cyan-400"
              style={{ textShadow: "0 0 8px rgba(0,255,255,0.5)" }}
            >
              CSN
            </a>
            <nav className="hidden md:flex items-center gap-4">
              <Link href="/" className="font-mono text-xs text-white/70 hover:text-white transition-colors">
                789 Studios
              </Link>
              <Link href="/spaces" className="font-mono text-xs text-cyan-400 font-bold">
                Network
              </Link>
            </nav>
          </div>
          <div className="flex items-center gap-2">
            <a
              href={CRYPTO_SPACES_NETWORK.websiteUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded font-mono text-[10px] font-bold uppercase tracking-wider border border-cyan-500/50 hover:bg-cyan-500/10 transition-colors text-cyan-400"
            >
              cryptospaces.net
            </a>
            <a
              href="https://doginaldogs.com"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded font-mono text-[10px] font-bold uppercase tracking-wider border border-[#ffd700]/50 hover:bg-[#ffd700]/10 transition-colors text-[#ffd700]"
            >
              Doginal Dogs
            </a>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
        {/* ========================================
            TIER 1: NETWORK LAYER (CSN - PRIMARY)
            ======================================== */}
        <header className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-cyan-500/30 bg-cyan-500/5">
            <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" />
            <span className="font-mono text-xs text-cyan-400 tracking-wider">NETWORK</span>
          </div>

          <h1
            className="text-4xl md:text-6xl font-bold tracking-tight"
            style={{
              background: "linear-gradient(135deg, #00ffff 0%, #ffffff 50%, #00ffff 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              textShadow: "0 0 40px rgba(0,255,255,0.3)",
            }}
          >
            CRYPTO SPACES NETWORK
          </h1>

          <p className="text-lg md:text-xl text-cyan-400 font-medium">{CRYPTO_SPACES_NETWORK.tagline}</p>

          <p className="font-mono text-sm text-white/60 max-w-2xl mx-auto italic">"{CRYPTO_SPACES_NETWORK.motto}"</p>

          <div className="flex items-center justify-center gap-4 pt-2">
            <a
              href={CRYPTO_SPACES_NETWORK.websiteUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 rounded border border-cyan-500/50 bg-cyan-500/10 font-mono text-xs text-cyan-400 hover:bg-cyan-500/20 transition-all"
            >
              cryptospaces.net
              <ExternalLink className="w-3 h-3" />
            </a>
            <a
              href={CRYPTO_SPACES_NETWORK.xUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 rounded border border-white/20 bg-white/5 font-mono text-xs text-white/70 hover:bg-white/10 transition-all"
            >
              @CryptoSpacesNet
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </header>

        {/* ========================================
            TIER 2: FOUNDERS (BARK META & GODSBURNT SHIBO)
            ======================================== */}
        {/* CSN Live Feed contains FOUNDER profiles for BARK and SHIBO */}
        <CSNLiveFeed />

        {/* Doginal Dogs Banner (community layer) */}
        <DoginalDogsBanner />

        {/* Broadcast Ticker */}
        <BroadcastTicker />

        {/* ========================================
            TIER 3: HOST SCHEDULE (All CSN Hosts)
            ======================================== */}
        <div className="text-center space-y-2">
          <h2 className="font-mono text-xl font-bold text-cyan-400">CSN HOST SCHEDULE</h2>
          <p className="font-mono text-xs text-white/50">24/7 Crypto Spaces Network Rotation</p>
        </div>

        <SpacesScheduleGrid />

        {/* ========================================
            TIER 4: STUDIO LAYER (789 Studios)
            ======================================== */}
        <section className="glass-panel rounded-lg p-6 md:p-8 border border-[#ffd700]/30">
          <div className="flex items-center gap-2 mb-6">
            <div className="h-px flex-1 bg-gradient-to-r from-transparent to-[#ffd700]/50" />
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-[#ffd700]/30 bg-[#ffd700]/5">
              <span className="font-mono text-[10px] text-[#ffd700]/70 tracking-wider">STUDIO</span>
            </div>
            <h2 className="font-mono text-lg font-bold text-[#ffd700] tracking-wider">789 STUDIOS</h2>
            <div className="h-px flex-1 bg-gradient-to-l from-transparent to-[#ffd700]/50" />
          </div>

          <p className="text-center text-sm text-white/70 max-w-2xl mx-auto mb-6">{STUDIOS_789.description}</p>

          {/* ========================================
              TIER 5: TALENT LAYER (Hosts, Contributors - NO FOUNDER BADGE)
              ======================================== */}
          <div className="border-t border-white/10 pt-6 mt-6">
            <div className="flex items-center justify-center gap-2 mb-4">
              <span className="font-mono text-[10px] text-white/50 tracking-wider">STUDIO TALENT</span>
            </div>

            <div className="flex flex-wrap justify-center gap-4">
              {STUDIOS_789_TEAM.map((member) => (
                <a
                  key={member.handle}
                  href={member.xUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 px-4 py-3 rounded-lg bg-white/5 border border-white/10 hover:border-[#ffd700]/30 transition-all group"
                >
                  <div className="relative w-10 h-10 rounded-full overflow-hidden border border-white/20">
                    <Image
                      src={member.imageUrl || "/placeholder.svg"}
                      alt={member.name}
                      fill
                      className="object-cover"
                      unoptimized
                    />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm font-bold text-white group-hover:text-[#ffd700] transition-colors">
                        {member.name}
                      </span>
                      <span className="px-1.5 py-0.5 rounded text-[8px] bg-white/10 text-white/60 border border-white/20">
                        {member.role}
                      </span>
                    </div>
                    <p className="font-mono text-[10px] text-white/50">{member.handle}</p>
                  </div>
                </a>
              ))}
            </div>
          </div>
        </section>

        {/* About Section */}
        <section className="glass-panel rounded-lg p-8 md:p-12 border border-white/10 space-y-6">
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-cyan-400">ABOUT CRYPTO SPACES NETWORK</h3>
              <p className="text-sm text-white/80 leading-relaxed">
                The Crypto Spaces Network is a 24 hour streaming schedule featuring unique hosts building web3 culture
                through daily presence, trust, and community. We partner with top hosts and leverage our distribution
                power to spotlight projects where the Web3 world is already tuned in.
              </p>
              <p className="text-sm text-white/60">
                Founded by <span className="text-[#ffd700] font-bold">SHIBO</span> and{" "}
                <span className="text-[#ffd700] font-bold">BARK</span>, CSN has grown into a powerhouse marketing agency
                serving the crypto ecosystem. 789 Studios broadcasts through the CSN infrastructure while maintaining
                its own distinct identity as a Film3 production house.
              </p>
            </div>
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-[#ffd700]">ABOUT DOGINAL DOGS</h3>
              <p className="text-sm text-white/80 leading-relaxed">
                Doginal Dogs are 10,000 pixel dogs digitally inscribed on Dogecoin. In a world where everything feels
                disposable, we stand as proof that some things are meant to last. The creators behind Doginal Dogs power
                the entire Crypto Spaces Network.
              </p>
              <div className="flex flex-wrap gap-2 pt-2">
                <a
                  href="https://doginaldogs.com/docs/doginal-docs"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-mono text-xs px-3 py-1.5 rounded border border-[#ffd700]/30 text-[#ffd700]/80 hover:bg-[#ffd700]/10 transition-all"
                >
                  Read the Docs
                </a>
                <a
                  href="https://doginaldogs.com/join-the-community"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-mono text-xs px-3 py-1.5 rounded border border-[#ffd700]/30 text-[#ffd700]/80 hover:bg-[#ffd700]/10 transition-all"
                >
                  Join Community
                </a>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* Footer */}
      <footer className="border-t border-border/30 mt-16 py-8 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="font-mono text-xs text-cyan-400/70">CRYPTO SPACES NETWORK</span>
              <span className="font-mono text-xs text-white/40">×</span>
              <span className="font-mono text-xs text-[#ffd700]/70">789 STUDIOS</span>
              <span className="font-mono text-xs text-white/40">© 2025</span>
            </div>
            <div className="flex items-center gap-4">
              <a
                href={CRYPTO_SPACES_NETWORK.websiteUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="font-mono text-xs text-cyan-400/70 hover:text-cyan-400 transition-colors"
              >
                cryptospaces.net
              </a>
              <a
                href="https://doginaldogs.com"
                target="_blank"
                rel="noopener noreferrer"
                className="font-mono text-xs text-[#ffd700]/70 hover:text-[#ffd700] transition-colors"
              >
                doginaldogs.com
              </a>
            </div>
          </div>
        </div>
      </footer>
    </VirtualSoundstage>
  )
}
