"use client"

import { VirtualSoundstage } from "@/components/virtual-soundstage"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BackButton } from "@/components/ui/back-button"
import { Play, DollarSign, Users, Zap, Shield, Globe } from "lucide-react"

export default function AboutOTTPage() {
  return (
    <VirtualSoundstage>
      {/* Top Navigation Bar */}
      <div className="border-b border-border/30 bg-black/40 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <BackButton fallbackHref="/" />
            <Link href="/" className="font-mono text-xs font-bold neon-text-gold">
              789
            </Link>
            <nav className="hidden md:flex items-center gap-4">
              <Link
                href="/"
                className="font-mono text-xs text-white/70 hover:text-white transition-colors"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
              >
                Home
              </Link>
              <Link
                href="/browse"
                className="font-mono text-xs text-white/70 hover:text-white transition-colors"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
              >
                Browse
              </Link>
              <Link
                href="/about-ott"
                className="font-mono text-xs text-white font-bold"
                style={{ textShadow: "0 0 10px rgba(255, 215, 0, 0.5)" }}
              >
                About OTT
              </Link>
            </nav>
          </div>
          <Link href="/pricing">
            <Button
              size="sm"
              className="font-mono font-bold uppercase tracking-wider text-white hover:opacity-90"
              style={{
                background: "#ffd700",
                boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
              }}
            >
              Get Started
            </Button>
          </Link>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12 space-y-16">
        {/* Hero Section */}
        <section className="text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#ffd700]/10 border border-[#ffd700]/30">
            <Play className="w-4 h-4 text-[#ffd700]" />
            <span className="font-mono text-xs font-bold neon-text-gold">OTT STREAMING PLATFORM</span>
          </div>
          <h1
            className="text-4xl md:text-6xl font-bold text-white"
            style={{ textShadow: "0 0 20px rgba(218, 165, 32, 0.5)" }}
          >
            WELCOME TO 789 STUDIOS OTT
          </h1>
          <p
            className="font-mono text-base md:text-lg text-white/90 max-w-3xl mx-auto leading-relaxed"
            style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.2)" }}
          >
            A next-generation Over-The-Top streaming platform built on blockchain technology. Create, distribute, and
            monetize Web3-native content through our Roku-style interface powered by Dogecoin infrastructure.
          </p>
        </section>

        {/* What is OTT */}
        <section className="glass-panel-enhanced rounded-lg p-8 md:p-12 border-2 border-[#ffd700]/30 space-y-6">
          <h2
            className="font-mono text-2xl md:text-3xl font-bold text-white text-center"
            style={{ textShadow: "0 0 15px rgba(218, 165, 32, 0.5)" }}
          >
            WHAT IS OTT?
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <h3 className="font-mono text-lg font-bold neon-text-gold">Over-The-Top Streaming</h3>
              <p
                className="font-mono text-sm text-white/80 leading-relaxed"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
              >
                OTT refers to streaming media services offered directly to viewers via the internet, bypassing
                traditional cable, broadcast, and satellite television platforms. Think Netflix, Hulu, or Roku—but built
                for the Web3 era.
              </p>
              <p
                className="font-mono text-sm text-white/80 leading-relaxed"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
              >
                789 Studios OTT combines the familiar Roku-style browsing experience with blockchain-powered content
                ownership, creator royalties, and token-gated access.
              </p>
            </div>
            <div className="space-y-4">
              <h3 className="font-mono text-lg font-bold neon-text-cyan">Why 789 OTT is Different</h3>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-[#00ffff] mt-2" style={{ boxShadow: "0 0 8px #00ffff" }} />
                  <span
                    className="font-mono text-sm text-white/80"
                    style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                  >
                    Blockchain-verified content ownership and royalties
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-[#00ffff] mt-2" style={{ boxShadow: "0 0 8px #00ffff" }} />
                  <span
                    className="font-mono text-sm text-white/80"
                    style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                  >
                    NFT-based access control and token-gated content
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-[#00ffff] mt-2" style={{ boxShadow: "0 0 8px #00ffff" }} />
                  <span
                    className="font-mono text-sm text-white/80"
                    style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                  >
                    Direct creator-to-audience monetization with 90% revenue share
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-[#00ffff] mt-2" style={{ boxShadow: "0 0 8px #00ffff" }} />
                  <span
                    className="font-mono text-sm text-white/80"
                    style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                  >
                    Cross-platform distribution to 5+ OTT networks
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </section>

        {/* Revenue Model */}
        <section className="space-y-8">
          <div className="text-center space-y-4">
            <h2
              className="font-mono text-2xl md:text-3xl font-bold text-white"
              style={{ textShadow: "0 0 15px rgba(218, 165, 32, 0.5)" }}
            >
              BLOCKCHAIN-POWERED REVENUE MODEL
            </h2>
            <p
              className="font-mono text-sm md:text-base text-white/80 max-w-3xl mx-auto"
              style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
            >
              Multiple revenue streams powered by Dogecoin blockchain infrastructure ensure sustainable operations and
              fair creator compensation
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Creator Revenue Share */}
            <div className="glass-panel rounded-lg p-6 border-2 border-[#ffd700]/30 hover:border-[#ffd700]/60 transition-all space-y-4">
              <div className="w-12 h-12 rounded-full bg-[#ffd700]/20 border-2 border-[#ffd700] flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-[#ffd700]" />
              </div>
              <h3 className="font-mono text-lg font-bold neon-text-gold">CREATOR REVENUE SHARE</h3>
              <div className="space-y-2">
                <div
                  className="text-4xl font-bold neon-text-gold"
                  style={{ textShadow: "0 0 15px rgba(255, 215, 0, 0.5)" }}
                >
                  90%
                </div>
                <p
                  className="font-mono text-sm text-white/80 leading-relaxed"
                  style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                >
                  Creators keep 90% of all revenue generated through their content—token-gated access, NFT sales,
                  subscriptions, and tips.
                </p>
              </div>
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#ffd700]" />
                  <span
                    className="font-mono text-xs text-white/70"
                    style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                  >
                    Direct wallet-to-wallet payments
                  </span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#ffd700]" />
                  <span
                    className="font-mono text-xs text-white/70"
                    style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                  >
                    Instant settlement on blockchain
                  </span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#ffd700]" />
                  <span
                    className="font-mono text-xs text-white/70"
                    style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                  >
                    No payment processor fees
                  </span>
                </li>
              </ul>
            </div>

            {/* Platform Fee */}
            <div className="glass-panel rounded-lg p-6 border-2 border-[#00ffff]/30 hover:border-[#00ffff]/60 transition-all space-y-4">
              <div className="w-12 h-12 rounded-full bg-[#00ffff]/20 border-2 border-[#00ffff] flex items-center justify-center">
                <Shield className="w-6 h-6 text-[#00ffff]" />
              </div>
              <h3 className="font-mono text-lg font-bold neon-text-cyan">PLATFORM FEE (10%)</h3>
              <div className="space-y-2">
                <div
                  className="text-4xl font-bold neon-text-cyan"
                  style={{ textShadow: "0 0 15px rgba(0, 255, 255, 0.5)" }}
                >
                  10%
                </div>
                <p
                  className="font-mono text-sm text-white/80 leading-relaxed"
                  style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                >
                  Our 10% platform fee covers infrastructure, blockchain gas fees, CDN costs, and continuous platform
                  development.
                </p>
              </div>
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#00ffff]" />
                  <span
                    className="font-mono text-xs text-white/70"
                    style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                  >
                    Global CDN & streaming infrastructure
                  </span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#00ffff]" />
                  <span
                    className="font-mono text-xs text-white/70"
                    style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                  >
                    Blockchain transaction costs
                  </span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#00ffff]" />
                  <span
                    className="font-mono text-xs text-white/70"
                    style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                  >
                    Platform maintenance & upgrades
                  </span>
                </li>
              </ul>
            </div>

            {/* Additional Revenue Streams */}
            <div className="glass-panel rounded-lg p-6 border-2 border-[#daa520]/30 hover:border-[#daa520]/60 transition-all space-y-4">
              <div className="w-12 h-12 rounded-full bg-[#daa520]/20 border-2 border-[#daa520] flex items-center justify-center">
                <Zap className="w-6 h-6 text-[#daa520]" />
              </div>
              <h3 className="font-mono text-lg font-bold neon-text-goldenrod">ADDITIONAL STREAMS</h3>
              <div className="space-y-2">
                <p
                  className="font-mono text-sm text-white/80 leading-relaxed"
                  style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                >
                  Multiple monetization options beyond platform fees to ensure sustainable operations.
                </p>
              </div>
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#daa520]" />
                  <span
                    className="font-mono text-xs text-white/70"
                    style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                  >
                    Studio booking fees ($75-$150/hr)
                  </span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#daa520]" />
                  <span
                    className="font-mono text-xs text-white/70"
                    style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                  >
                    Premium creator subscriptions
                  </span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#daa520]" />
                  <span
                    className="font-mono text-xs text-white/70"
                    style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                  >
                    NFT marketplace transaction fees
                  </span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#daa520]" />
                  <span
                    className="font-mono text-xs text-white/70"
                    style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                  >
                    Distribution partnerships
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </section>

        {/* How It Works */}
        <section className="glass-panel-enhanced rounded-lg p-8 md:p-12 border-2 border-border/30 space-y-8">
          <h2
            className="font-mono text-2xl md:text-3xl font-bold text-white text-center"
            style={{ textShadow: "0 0 15px rgba(218, 165, 32, 0.5)" }}
          >
            HOW 789 OTT WORKS
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="space-y-4 text-center">
              <div
                className="w-16 h-16 rounded-full bg-gradient-to-br from-[#ffd700]/20 to-[#daa520]/20 border-2 border-[#ffd700] flex items-center justify-center mx-auto"
                style={{ boxShadow: "0 0 20px rgba(255, 215, 0, 0.3)" }}
              >
                <span className="text-2xl font-bold neon-text-gold">1</span>
              </div>
              <h3 className="font-mono text-lg font-bold chrome-text">CREATE & MINT</h3>
              <p
                className="font-mono text-sm text-white/80 leading-relaxed"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
              >
                Upload your content to our Creator Hub and mint it as an NFT on the Dogecoin blockchain. Set your
                pricing, access rules, and royalty structure.
              </p>
            </div>

            <div className="space-y-4 text-center">
              <div
                className="w-16 h-16 rounded-full bg-gradient-to-br from-[#00ffff]/20 to-[#0088cc]/20 border-2 border-[#00ffff] flex items-center justify-center mx-auto"
                style={{ boxShadow: "0 0 20px rgba(0, 255, 255, 0.3)" }}
              >
                <span className="text-2xl font-bold neon-text-cyan">2</span>
              </div>
              <h3 className="font-mono text-lg font-bold chrome-text">DISTRIBUTE</h3>
              <p
                className="font-mono text-sm text-white/80 leading-relaxed"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
              >
                Your content automatically distributes to our OTT interface plus 5+ partner platforms including Roku,
                Apple TV, and Web3 streaming networks.
              </p>
            </div>

            <div className="space-y-4 text-center">
              <div
                className="w-16 h-16 rounded-full bg-gradient-to-br from-[#daa520]/20 to-[#b8860b]/20 border-2 border-[#daa520] flex items-center justify-center mx-auto"
                style={{ boxShadow: "0 0 20px rgba(218, 165, 32, 0.3)" }}
              >
                <span className="text-2xl font-bold neon-text-goldenrod">3</span>
              </div>
              <h3 className="font-mono text-lg font-bold chrome-text">EARN REVENUE</h3>
              <p
                className="font-mono text-sm text-white/80 leading-relaxed"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
              >
                Get paid instantly when viewers purchase access, subscribe, or tip. All transactions verified on-chain
                with 90% going directly to your wallet.
              </p>
            </div>
          </div>
        </section>

        {/* Key Features */}
        <section className="space-y-8">
          <h2
            className="font-mono text-2xl md:text-3xl font-bold text-white text-center"
            style={{ textShadow: "0 0 15px rgba(218, 165, 32, 0.5)" }}
          >
            KEY FEATURES
          </h2>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="glass-panel rounded-lg p-6 border-2 border-border/30 space-y-3">
              <div className="flex items-center gap-3">
                <Users className="w-6 h-6 text-[#ffd700]" />
                <h3 className="font-mono text-base font-bold neon-text-gold">TOKEN-GATED CONTENT</h3>
              </div>
              <p
                className="font-mono text-sm text-white/80 leading-relaxed"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
              >
                Control access to your content with NFTs, wallet-based subscriptions, and token holdings. Fans connect
                their wallets to unlock exclusive shows and episodes.
              </p>
            </div>

            <div className="glass-panel rounded-lg p-6 border-2 border-border/30 space-y-3">
              <div className="flex items-center gap-3">
                <Globe className="w-6 h-6 text-[#00ffff]" />
                <h3 className="font-mono text-base font-bold neon-text-cyan">CROSS-PLATFORM DISTRIBUTION</h3>
              </div>
              <p
                className="font-mono text-sm text-white/80 leading-relaxed"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
              >
                One upload reaches multiple platforms—our web OTT interface, Roku, Apple TV, Fire TV, and emerging Web3
                streaming networks. Maximum reach, minimum effort.
              </p>
            </div>

            <div className="glass-panel rounded-lg p-6 border-2 border-border/30 space-y-3">
              <div className="flex items-center gap-3">
                <Shield className="w-6 h-6 text-[#daa520]" />
                <h3 className="font-mono text-base font-bold neon-text-goldenrod">BLOCKCHAIN VERIFICATION</h3>
              </div>
              <p
                className="font-mono text-sm text-white/80 leading-relaxed"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
              >
                Every transaction, every view count, every revenue split is recorded on Dogecoin blockchain. Full
                transparency and immutable proof of ownership and earnings.
              </p>
            </div>

            <div className="glass-panel rounded-lg p-6 border-2 border-border/30 space-y-3">
              <div className="flex items-center gap-3">
                <Play className="w-6 h-6 text-[#ffd700]" />
                <h3 className="font-mono text-base font-bold neon-text-gold">ROKU-STYLE INTERFACE</h3>
              </div>
              <p
                className="font-mono text-sm text-white/80 leading-relaxed"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
              >
                Familiar horizontal rail browsing experience with featured content, continue watching, categories, and
                personalized recommendations—all with blockchain benefits.
              </p>
            </div>
          </div>
        </section>

        {/* Stats Overview */}
        <section className="glass-panel-enhanced rounded-lg p-8 md:p-12 border-2 border-[#ffd700]/20 space-y-6">
          <h2
            className="font-mono text-2xl md:text-3xl font-bold text-white text-center"
            style={{ textShadow: "0 0 15px rgba(218, 165, 32, 0.5)" }}
          >
            PLATFORM OVERVIEW
          </h2>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 pt-6">
            <div className="text-center space-y-2">
              <div
                className="font-mono text-3xl md:text-4xl font-bold"
                style={{ color: "#00ffff", textShadow: "0 0 15px rgba(0, 255, 255, 0.5)" }}
              >
                90%
              </div>
              <div
                className="font-mono text-xs text-white/80"
                style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
              >
                Creator Revenue Share
              </div>
            </div>

            <div className="text-center space-y-2">
              <div
                className="font-mono text-3xl md:text-4xl font-bold"
                style={{ color: "#ffd700", textShadow: "0 0 15px rgba(255, 215, 0, 0.5)" }}
              >
                5+
              </div>
              <div
                className="font-mono text-xs text-white/80"
                style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
              >
                Distribution Platforms
              </div>
            </div>

            <div className="text-center space-y-2">
              <div
                className="font-mono text-3xl md:text-4xl font-bold"
                style={{ color: "#daa520", textShadow: "0 0 15px rgba(218, 165, 32, 0.5)" }}
              >
                24/7
              </div>
              <div
                className="font-mono text-xs text-white/80"
                style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
              >
                Global Streaming
              </div>
            </div>

            <div className="text-center space-y-2">
              <div
                className="font-mono text-3xl md:text-4xl font-bold"
                style={{ color: "#00ffff", textShadow: "0 0 15px rgba(0, 255, 255, 0.5)" }}
              >
                100%
              </div>
              <div
                className="font-mono text-xs text-white/80"
                style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
              >
                Blockchain Verified
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="text-center space-y-6">
          <h2
            className="font-mono text-2xl md:text-3xl font-bold text-white"
            style={{ textShadow: "0 0 15px rgba(218, 165, 32, 0.5)" }}
          >
            READY TO START STREAMING?
          </h2>
          <p
            className="font-mono text-sm md:text-base text-white/80 max-w-2xl mx-auto"
            style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
          >
            Join 789 Studios OTT and start earning from your content with the fairest revenue model in streaming.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/creator">
              <Button
                size="lg"
                className="font-mono font-bold uppercase tracking-wider text-white hover:opacity-90 min-w-[200px]"
                style={{
                  background: "#ffd700",
                  boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
                }}
              >
                Start Creating
              </Button>
            </Link>
            <Link href="/browse">
              <Button
                size="lg"
                variant="outline"
                className="font-mono font-bold uppercase tracking-wider border-[#00ffff] hover:bg-[#00ffff]/10 bg-transparent text-[#00ffff] min-w-[200px]"
              >
                Browse Content
              </Button>
            </Link>
          </div>
        </section>
      </div>

      {/* Footer */}
      <footer className="border-t border-border/30 mt-16 py-8 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <span className="font-mono text-xs text-white/70" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
              789 STUDIOS OTT © 2025 • BLOCKCHAIN-POWERED STREAMING
            </span>
            <div className="flex items-center gap-4">
              <Link
                href="/pricing"
                className="font-mono text-xs text-white/70 hover:text-[#ffd700] transition-colors"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
              >
                Pricing
              </Link>
              <Link
                href="/"
                className="font-mono text-xs text-white/70 hover:text-[#ffd700] transition-colors"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
              >
                Home
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </VirtualSoundstage>
  )
}
