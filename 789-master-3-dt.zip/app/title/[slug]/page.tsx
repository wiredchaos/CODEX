import { BackButton } from "@/components/ui/back-button"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { getShowBySlug, OTT_SHOWS } from "@/data/ott-content"
import { Play, Plus } from "lucide-react"
import Link from "next/link"
import { notFound } from "next/navigation"

export default function TitlePage({ params }: { params: { slug: string } }) {
  const show = getShowBySlug(params.slug)

  if (!show) {
    notFound()
  }

  // Get similar shows from same channel or genre
  const similarShows = OTT_SHOWS.filter(
    (s) => s.id !== show.id && (s.channelId === show.channelId || s.genres.some((g) => show.genres.includes(g))),
  ).slice(0, 4)

  return (
    <div className="min-h-screen bg-black">
      {/* Navigation */}
      <div className="border-b border-border/30 bg-black/40 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-4">
          <BackButton fallbackHref="/browse" />
          <h1
            className="font-mono text-base md:text-xl font-bold uppercase tracking-wider text-white"
            style={{ textShadow: "0 0 15px rgba(255, 215, 0, 0.5)" }}
          >
            {show.title}
          </h1>
        </div>
      </div>

      {/* Hero Section */}
      <div className="relative">
        <div
          className="h-[50vh] bg-cover bg-center"
          style={{
            backgroundImage: `url(${show.heroArt})`,
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
        </div>

        <div className="max-w-7xl mx-auto px-4 -mt-32 relative z-10">
          <div className="grid md:grid-cols-[300px,1fr] gap-8">
            {/* Poster */}
            <div className="hidden md:block">
              <img
                src={show.thumbnail || "/placeholder.svg"}
                alt={show.title}
                className="w-full rounded-lg shadow-2xl border border-white/10"
              />
            </div>

            {/* Info */}
            <div className="space-y-6">
              <div className="space-y-4">
                <h1
                  className="text-3xl md:text-5xl font-bold text-white"
                  style={{ textShadow: "0 0 20px rgba(255, 215, 0, 0.5)" }}
                >
                  {show.title}
                </h1>

                <div className="flex flex-wrap gap-3 items-center">
                  {show.year && (
                    <span
                      className="font-mono text-sm text-white/90"
                      style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.3)" }}
                    >
                      {show.year}
                    </span>
                  )}
                  {show.genres.map((genre) => (
                    <span
                      key={genre}
                      className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-black/50 backdrop-blur-sm border border-white/20 text-[#00ffff]"
                      style={{ textShadow: "0 0 8px rgba(0, 255, 255, 0.5)" }}
                    >
                      {genre}
                    </span>
                  ))}
                </div>

                <p
                  className="text-lg text-white/90 max-w-3xl"
                  style={{ textShadow: "0 0 8px rgba(255, 255, 255, 0.3)" }}
                >
                  {show.description}
                </p>

                <div className="flex flex-wrap gap-4 pt-4">
                  <Button
                    size="lg"
                    className="font-mono font-bold uppercase tracking-wider text-black"
                    style={{
                      background: "#ffd700",
                      boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
                    }}
                    asChild
                  >
                    <Link href={`/watch/${show.episodes[0]?.id || show.id}`}>
                      <Play className="w-5 h-5 mr-2" />
                      Play
                    </Link>
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    className="font-mono font-bold uppercase tracking-wider border-white/50 bg-black/50 backdrop-blur-sm hover:bg-white/10 text-white"
                    style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.5)" }}
                  >
                    <Plus className="w-5 h-5 mr-2" />
                    My List
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Episodes & More */}
      <div className="max-w-7xl mx-auto px-4 py-12 space-y-12">
        {/* Episodes */}
        {show.episodes.length > 0 && (
          <section className="space-y-6">
            <h2
              className="font-mono text-2xl font-bold uppercase tracking-wider text-white"
              style={{ textShadow: "0 0 15px rgba(255, 215, 0, 0.5)" }}
            >
              Episodes
            </h2>
            <div className="grid gap-4">
              {show.episodes.map((episode) => (
                <Link key={episode.id} href={`/watch/${episode.id}`}>
                  <Card className="flex flex-col md:flex-row gap-4 p-4 bg-black/40 border-white/10 hover:border-[#00ffff]/50 transition-all hover:scale-[1.02]">
                    <img
                      src={episode.thumbnail || "/placeholder.svg"}
                      alt={episode.title}
                      className="w-full md:w-48 h-32 object-cover rounded"
                    />
                    <div className="flex-1 space-y-2">
                      <div className="flex items-start justify-between gap-4">
                        <div className="space-y-1 flex-1">
                          <div
                            className="font-mono text-xs text-white/70"
                            style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.3)" }}
                          >
                            {episode.seasonNumber && episode.episodeNumber
                              ? `S${episode.seasonNumber} E${episode.episodeNumber}`
                              : "Episode"}
                          </div>
                          <div
                            className="font-mono font-bold text-base text-white"
                            style={{ textShadow: "0 0 8px rgba(255, 255, 255, 0.5)" }}
                          >
                            {episode.title}
                          </div>
                        </div>
                        <div
                          className="font-mono text-sm text-white/70 whitespace-nowrap"
                          style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.3)" }}
                        >
                          {Math.floor(episode.duration / 60)}min
                        </div>
                      </div>
                      <p
                        className="text-sm text-white/90 line-clamp-2"
                        style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.3)" }}
                      >
                        {episode.description}
                      </p>
                    </div>
                  </Card>
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* More Like This */}
        {similarShows.length > 0 && (
          <section className="space-y-6">
            <h2
              className="font-mono text-2xl font-bold uppercase tracking-wider text-white"
              style={{ textShadow: "0 0 15px rgba(255, 215, 0, 0.5)" }}
            >
              More Like This
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {similarShows.map((s) => (
                <Link key={s.id} href={`/title/${s.slug}`}>
                  <Card className="bg-black/40 border-white/10 hover:border-[#00ffff]/50 transition-all overflow-hidden hover:scale-105">
                    <img
                      src={s.thumbnail || "/placeholder.svg"}
                      alt={s.title}
                      className="w-full aspect-video object-cover"
                    />
                    <div className="p-3">
                      <div
                        className="font-mono text-sm font-bold text-white line-clamp-1"
                        style={{ textShadow: "0 0 8px rgba(255, 255, 255, 0.5)" }}
                      >
                        {s.title}
                      </div>
                    </div>
                  </Card>
                </Link>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  )
}
