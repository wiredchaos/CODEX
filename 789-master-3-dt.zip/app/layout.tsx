import type React from "react"
import type { Metadata, Viewport } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"

import { TrinityProvider } from "@/lib/core/trinity-3d/trinity-provider"
import { TrinityScene } from "@/lib/core/trinity-3d/trinity-scene"
import { ElevatorProvider } from "@/lib/core/elevator/elevator-provider"
import { ElevatorOverlay } from "@/lib/core/elevator/elevator-overlay"
import { ElevatorTrigger } from "@/components/elevator-trigger"

const _geist = Geist({ subsets: ["latin"] })
const _geistMono = Geist_Mono({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "789 Studios | Web3 Creator Ecosystem & Virtual Production Platform",
  description:
    "Multi-platform publishing, token-gated content, professional recording studios, Film3 onboarding for filmmakers with NEURO Concierge guided tours. 90% creator revenue share on blockchain.",
  keywords: [
    "web3 creator platform",
    "blockchain content",
    "token-gated",
    "film3",
    "recording studio",
    "NFT filmmaking",
    "crypto spaces network",
    "dogecoin",
    "creator economy",
  ],
  authors: [{ name: "789 Studios" }],
  openGraph: {
    title: "789 Studios | Web3 Creator Ecosystem",
    description: "Professional recording studios, Film3 onboarding, multi-platform publishing with 90% revenue share",
    type: "website",
    siteName: "789 Studios",
  },
  twitter: {
    card: "summary_large_image",
    title: "789 Studios | Web3 Creator Ecosystem",
    description: "Professional recording studios, Film3 onboarding, multi-platform publishing",
  },
  generator: "789 Studios",
  robots: {
    index: true,
    follow: true,
  },
}

export const viewport: Viewport = {
  themeColor: "#000000",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark">
      <body className="font-sans antialiased">
        <TrinityProvider>
          <ElevatorProvider>
            {/* Z-index 0: 3D background scene */}
            <TrinityScene />

            {/* Z-index 10: Main content with glass UI */}
            <div className="relative z-10">{children}</div>

            {/* Z-index 40: Elevator trigger button */}
            <ElevatorTrigger />

            {/* Z-index 50: Elevator overlay when open */}
            <ElevatorOverlay />

            <Analytics />
          </ElevatorProvider>
        </TrinityProvider>
      </body>
    </html>
  )
}
