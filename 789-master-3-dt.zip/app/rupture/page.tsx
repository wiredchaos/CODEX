// RUPTURE: The FLINCH Story - Main documentary page
// A docudrama about FLINCH and the Film3 revolution
// Production: CHAOS PRODUCTIONS | Artist: NEURO META X | Distribution: 789 Studios OTT

import type { Metadata } from "next"
import { ScanlineOverlay } from "@/components/scanline-overlay"
import { RuptureHeroSection } from "@/components/rupture/hero-section"
import { ProjectOverview } from "@/components/rupture/project-overview"
import { DocudramaActs } from "@/components/rupture/docudrama-acts"
import { CreatorProfile } from "@/components/rupture/creator-profile"
import { DistributionSection } from "@/components/rupture/distribution-section"
import { RuptureFooter } from "@/components/rupture/footer"
import { BackButton } from "@/components/ui/back-button"
import { Film3CommunitySection } from "@/components/rupture/film3-community-section"

export const metadata: Metadata = {
  title: "RUPTURE: The FLINCH Story | 789 Studios",
  description:
    "A seven act docudrama chronicling the creation and cultural impact of FLINCH, the groundbreaking NFT that ignited the Film3 revolution. Produced by CHAOS PRODUCTIONS, created by NEURO META X, distributed by 789 Studios OTT.",
  openGraph: {
    title: "RUPTURE: The FLINCH Story",
    description: "A documentary about the NFT that broke the mold and ignited the Film3 revolution",
    type: "video.movie",
  },
}

export default function RupturePage() {
  return (
    <main className="min-h-screen bg-[#0A0A0F] text-white relative overflow-hidden">
      {/* Scanline overlay for cyber noir aesthetic */}
      <ScanlineOverlay />

      {/* Fixed navigation */}
      <nav className="fixed top-0 left-0 right-0 z-40 bg-[#0A0A0F]/80 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <BackButton fallbackUrl="/" />
            <span
              className="text-2xl font-bold text-[#FF003C] tracking-wider"
              style={{
                fontFamily: "Bebas Neue, sans-serif",
                textShadow: "0 0 20px rgba(255, 0, 60, 0.5)",
              }}
            >
              RUPTURE
            </span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <a
              href="#overview"
              className="text-white/70 hover:text-white transition-colors text-sm tracking-wider uppercase"
            >
              Overview
            </a>
            <a
              href="#acts"
              className="text-white/70 hover:text-white transition-colors text-sm tracking-wider uppercase"
            >
              Acts
            </a>
            <a
              href="#community"
              className="text-white/70 hover:text-white transition-colors text-sm tracking-wider uppercase"
            >
              Community
            </a>
            <a
              href="#creators"
              className="text-white/70 hover:text-white transition-colors text-sm tracking-wider uppercase"
            >
              Creators
            </a>
            <a
              href="#distribution"
              className="text-white/70 hover:text-white transition-colors text-sm tracking-wider uppercase"
            >
              Distribution
            </a>
          </div>
        </div>
      </nav>

      {/* Page sections */}
      <RuptureHeroSection />

      <div id="overview">
        <ProjectOverview />
      </div>

      <div id="acts">
        <DocudramaActs />
      </div>

      <div id="community">
        <Film3CommunitySection />
      </div>

      <div id="creators">
        <CreatorProfile />
      </div>

      <div id="distribution">
        <DistributionSection />
      </div>

      <RuptureFooter />
    </main>
  )
}
