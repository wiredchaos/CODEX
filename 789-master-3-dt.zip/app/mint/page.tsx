"use client"

import { VirtualSoundstage } from "@/components/virtual-soundstage"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"
import { Upload, Film, Lock, DollarSign, Check, TrendingUp } from "lucide-react"
import { useState } from "react"
import { BackButton } from "@/components/ui/back-button"

export default function MintPage() {
  const [mintStep, setMintStep] = useState(1)
  const [blockchain, setBlockchain] = useState("dogecoin")

  return (
    <VirtualSoundstage>
      {/* Top Navigation Bar */}
      <div className="border-b border-border/30 bg-black/40 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <BackButton fallbackHref="/" />
            <Link href="/" className="font-mono text-xs font-bold neon-text-gold">
              789
            </Link>
            <nav className="hidden md:flex items-center gap-4">
              <Link
                href="/"
                className="font-mono text-xs text-white/70 hover:text-white transition-colors"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
              >
                Studios
              </Link>
              <Link
                href="/creator"
                className="font-mono text-xs text-white/70 hover:text-white transition-colors"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
              >
                Creator Hub
              </Link>
              <Link href="/mint" className="font-mono text-xs text-foreground font-bold">
                Mint Film
              </Link>
            </nav>
          </div>
          <Button
            size="sm"
            className="font-mono font-bold uppercase tracking-wider text-white hover:opacity-90"
            style={{
              background: "#ffd700",
              boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
            }}
          >
            Connect Wallet
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12 space-y-12">
        {/* Hero Header */}
        <header className="text-center space-y-4">
          <h1 className="text-3xl md:text-5xl font-bold chrome-text">MINT YOUR FILM</h1>
          <p
            className="font-mono text-sm md:text-base text-white/80 max-w-2xl mx-auto"
            style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
          >
            Transform your films into NFTs • Token-Gate Access • Set Royalties • Earn 90% Revenue
          </p>
        </header>

        {/* Progress Indicator */}
        <div className="glass-panel rounded-lg p-6">
          <div className="flex items-center justify-between">
            {[
              { step: 1, label: "Upload Film", icon: Upload },
              { step: 2, label: "Metadata", icon: Film },
              { step: 3, label: "Access & Pricing", icon: Lock },
              { step: 4, label: "Mint NFT", icon: Check },
            ].map((item, index) => (
              <div key={item.step} className="flex items-center flex-1">
                <div className="flex flex-col items-center flex-1">
                  <div
                    className={`w-12 h-12 rounded-full flex items-center justify-center border-2 transition-all ${
                      mintStep >= item.step ? "border-[#ffd700] bg-[#ffd700]/10" : "border-border/30 bg-transparent"
                    }`}
                  >
                    <item.icon className={`w-6 h-6 ${mintStep >= item.step ? "text-[#ffd700]" : "text-white/60"}`} />
                  </div>
                  <span
                    className={`font-mono text-xs mt-2 ${mintStep >= item.step ? "text-[#ffd700]" : "text-white/60"}`}
                    style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                  >
                    {item.label}
                  </span>
                </div>
                {index < 3 && (
                  <div className={`h-0.5 flex-1 mx-2 ${mintStep > item.step ? "bg-[#ffd700]" : "bg-border/30"}`} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Main Minting Interface */}
        <Tabs value={`step-${mintStep}`} className="w-full">
          <TabsList className="hidden">
            <TabsTrigger value="step-1">Step 1</TabsTrigger>
            <TabsTrigger value="step-2">Step 2</TabsTrigger>
            <TabsTrigger value="step-3">Step 3</TabsTrigger>
            <TabsTrigger value="step-4">Step 4</TabsTrigger>
          </TabsList>

          {/* Step 1: Upload Film */}
          <TabsContent value="step-1" className="space-y-6">
            <Card className="glass-panel border-[#ffd700]/20 p-8 space-y-6">
              <div className="space-y-2">
                <h2 className="font-mono text-2xl font-bold neon-text-gold">UPLOAD YOUR FILM</h2>
                <p className="font-mono text-sm text-white/80" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
                  Supported formats: MP4, MOV, AVI, MKV • Max size: 10GB
                </p>
              </div>

              {/* Upload Area */}
              <div className="border-2 border-dashed border-[#ffd700]/30 rounded-lg p-12 hover:border-[#ffd700] transition-colors cursor-pointer group">
                <div className="flex flex-col items-center gap-4 text-center">
                  <div className="w-24 h-24 rounded-full bg-[#ffd700]/10 border border-[#ffd700]/30 flex items-center justify-center group-hover:border-[#ffd700] transition-colors">
                    <Upload className="w-12 h-12 text-[#ffd700]" />
                  </div>
                  <div>
                    <h3 className="font-mono text-lg font-bold text-white mb-2">
                      Drop your film here or click to browse
                    </h3>
                    <p
                      className="font-mono text-xs text-white/70"
                      style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                    >
                      High-quality films get better engagement
                    </p>
                  </div>
                  <Button
                    className="font-mono font-bold uppercase tracking-wider text-white"
                    style={{
                      background: "#ffd700",
                      boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
                    }}
                  >
                    Select File
                  </Button>
                </div>
              </div>

              {/* Alternative: URL Input */}
              <div className="glass-panel-enhanced rounded-lg p-4 space-y-3">
                <label className="font-mono text-xs font-bold text-[#00ffff]">OR PASTE VIDEO URL</label>
                <input
                  type="url"
                  className="w-full glass-panel rounded p-3 font-mono text-sm border border-border/30 focus:border-[#00ffff]/50 focus:outline-none"
                  placeholder="https://vimeo.com/... or YouTube link"
                />
                <p className="font-mono text-xs text-white/80" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
                  Support for Vimeo, YouTube, and direct video URLs
                </p>
              </div>
            </Card>

            <div className="flex justify-end">
              <Button
                onClick={() => setMintStep(2)}
                size="lg"
                className="font-mono font-bold uppercase tracking-wider text-white hover:opacity-90"
                style={{
                  background: "#ffd700",
                  boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
                }}
              >
                Next: Add Metadata
              </Button>
            </div>
          </TabsContent>

          {/* Step 2: Metadata */}
          <TabsContent value="step-2" className="space-y-6">
            <Card className="glass-panel border-[#ffd700]/20 p-8 space-y-6">
              <div className="space-y-2">
                <h2 className="font-mono text-2xl font-bold neon-text-gold">FILM METADATA</h2>
                <p className="font-mono text-sm text-white/80" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
                  Add details to help viewers discover your film
                </p>
              </div>

              <div className="grid gap-6">
                {/* Film Title */}
                <div className="glass-panel-enhanced rounded-lg p-4 space-y-3">
                  <label className="font-mono text-xs font-bold text-[#00ffff]">FILM TITLE *</label>
                  <input
                    type="text"
                    className="w-full glass-panel rounded p-3 font-mono text-sm border border-border/30 focus:border-[#00ffff]/50 focus:outline-none"
                    placeholder="Enter film title"
                  />
                </div>

                {/* Description */}
                <div className="glass-panel-enhanced rounded-lg p-4 space-y-3">
                  <label className="font-mono text-xs font-bold text-[#00ffff]">DESCRIPTION *</label>
                  <textarea
                    className="w-full h-32 glass-panel rounded p-3 font-mono text-sm border border-border/30 focus:border-[#00ffff]/50 focus:outline-none resize-none"
                    placeholder="Describe your film, cast, crew, and storyline"
                  />
                </div>

                {/* Genre & Runtime */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="glass-panel-enhanced rounded-lg p-4 space-y-3">
                    <label className="font-mono text-xs font-bold text-[#00ffff]">GENRE</label>
                    <select className="w-full glass-panel rounded p-3 font-mono text-sm border border-border/30 focus:border-[#00ffff]/50 focus:outline-none">
                      <option>Drama</option>
                      <option>Thriller</option>
                      <option>Documentary</option>
                      <option>Action</option>
                      <option>Comedy</option>
                      <option>Horror</option>
                      <option>Sci-Fi</option>
                      <option>Experimental</option>
                    </select>
                  </div>
                  <div className="glass-panel-enhanced rounded-lg p-4 space-y-3">
                    <label className="font-mono text-xs font-bold text-[#00ffff]">RUNTIME (MINUTES)</label>
                    <input
                      type="number"
                      className="w-full glass-panel rounded p-3 font-mono text-sm border border-border/30 focus:border-[#00ffff]/50 focus:outline-none"
                      placeholder="90"
                    />
                  </div>
                </div>

                {/* Thumbnail */}
                <div className="glass-panel-enhanced rounded-lg p-4 space-y-3">
                  <label className="font-mono text-xs font-bold text-[#00ffff]">THUMBNAIL / POSTER</label>
                  <div className="border-2 border-dashed border-[#00ffff]/30 rounded-lg p-8 hover:border-[#00ffff] transition-colors cursor-pointer">
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 rounded bg-[#00ffff]/10 border border-[#00ffff]/30 flex items-center justify-center">
                        <Film className="w-8 h-8 text-[#00ffff]" />
                      </div>
                      <div>
                        <p className="font-mono text-sm text-white">Upload poster image</p>
                        <p
                          className="font-mono text-xs text-white/70"
                          style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                        >
                          JPG, PNG • 1920x1080 recommended
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Cast & Crew */}
                <div className="glass-panel-enhanced rounded-lg p-4 space-y-3">
                  <label className="font-mono text-xs font-bold text-[#00ffff]">CAST & CREW</label>
                  <textarea
                    className="w-full h-24 glass-panel rounded p-3 font-mono text-sm border border-border/30 focus:border-[#00ffff]/50 focus:outline-none resize-none"
                    placeholder="Director: Your Name&#10;Cast: Actor 1, Actor 2&#10;Producer: Producer Name"
                  />
                </div>
              </div>
            </Card>

            <div className="flex justify-between">
              <Button
                onClick={() => setMintStep(1)}
                variant="outline"
                size="lg"
                className="font-mono font-bold uppercase tracking-wider border-[#00ffff] hover:bg-[#00ffff]/10 bg-transparent text-[#00ffff]"
              >
                Back
              </Button>
              <Button
                onClick={() => setMintStep(3)}
                size="lg"
                className="font-mono font-bold uppercase tracking-wider text-white hover:opacity-90"
                style={{
                  background: "#ffd700",
                  boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
                }}
              >
                Next: Set Pricing
              </Button>
            </div>
          </TabsContent>

          {/* Step 3: Access & Pricing */}
          <TabsContent value="step-3" className="space-y-6">
            <Card className="glass-panel border-[#ffd700]/20 p-8 space-y-6">
              <div className="space-y-2">
                <h2 className="font-mono text-2xl font-bold neon-text-gold">ACCESS & PRICING</h2>
                <p className="font-mono text-sm text-white/80" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
                  Control how viewers access and pay for your film
                </p>
              </div>

              {/* Blockchain Selection */}
              <div className="glass-panel-enhanced rounded-lg p-4 space-y-3">
                <label className="font-mono text-xs font-bold text-[#00ffff]">BLOCKCHAIN *</label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    { id: "dogecoin", name: "Dogecoin", color: "#daa520" },
                    { id: "ethereum", name: "Ethereum", color: "#627eea" },
                    { id: "solana", name: "Solana", color: "#00ffff" },
                    { id: "base", name: "Base", color: "#0052ff" },
                  ].map((chain) => (
                    <button
                      key={chain.id}
                      onClick={() => setBlockchain(chain.id)}
                      className={`glass-panel p-4 rounded-lg border transition-colors ${
                        blockchain === chain.id
                          ? "border-[#ffd700] bg-[#ffd700]/10"
                          : "border-border/30 hover:border-border/50"
                      }`}
                    >
                      <span className="font-mono text-sm">{chain.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Access Model */}
              <div className="space-y-4">
                <label className="font-mono text-xs font-bold text-[#00ffff]">ACCESS MODEL *</label>
                <div className="grid gap-4">
                  {[
                    {
                      id: "rental",
                      title: "Rental",
                      desc: "24-hour or 7-day access",
                      icon: DollarSign,
                    },
                    {
                      id: "purchase",
                      title: "Purchase",
                      desc: "Lifetime ownership",
                      icon: Lock,
                    },
                    {
                      id: "subscription",
                      title: "Subscription",
                      desc: "Monthly/Annual access",
                      icon: TrendingUp,
                    },
                  ].map((model) => (
                    <label
                      key={model.id}
                      className="glass-panel-enhanced rounded-lg p-6 border border-border/30 hover:border-[#ffd700]/50 cursor-pointer transition-colors flex items-start gap-4"
                    >
                      <input type="radio" name="access-model" className="mt-1" />
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <model.icon className="w-5 h-5 text-[#ffd700]" />
                          <h3 className="font-mono text-base font-bold text-white">{model.title}</h3>
                        </div>
                        <p
                          className="font-mono text-xs text-white/70"
                          style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                        >
                          {model.desc}
                        </p>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              {/* Pricing */}
              <div className="grid md:grid-cols-2 gap-4">
                <div className="glass-panel-enhanced rounded-lg p-4 space-y-3">
                  <label className="font-mono text-xs font-bold text-[#00ffff]">PRICE (USD)</label>
                  <div className="relative">
                    <span
                      className="absolute left-3 top-1/2 -translate-y-1/2 font-mono text-sm text-white/70"
                      style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                    >
                      $
                    </span>
                    <input
                      type="number"
                      className="w-full glass-panel rounded p-3 pl-8 font-mono text-sm border border-border/30 focus:border-[#00ffff]/50 focus:outline-none"
                      placeholder="9.99"
                    />
                  </div>
                </div>
                <div className="glass-panel-enhanced rounded-lg p-4 space-y-3">
                  <label className="font-mono text-xs font-bold text-[#00ffff]">ROYALTY %</label>
                  <input
                    type="number"
                    className="w-full glass-panel rounded p-3 font-mono text-sm border border-border/30 focus:border-[#00ffff]/50 focus:outline-none"
                    placeholder="10"
                    max="50"
                  />
                  <p className="font-mono text-xs text-white/70" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
                    Earn on secondary sales (max 50%)
                  </p>
                </div>
              </div>

              {/* Token-Gate Option */}
              <div className="glass-panel-enhanced rounded-lg p-6 border border-[#00ffff]/20 space-y-4">
                <div className="flex items-start gap-3">
                  <input type="checkbox" id="token-gate-film" className="mt-1" />
                  <div className="flex-1 space-y-2">
                    <label htmlFor="token-gate-film" className="font-mono text-sm font-bold text-[#ffd700]">
                      Token-Gate This Film
                    </label>
                    <p
                      className="font-mono text-xs text-white/70"
                      style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                    >
                      Require NFT ownership for access (in addition to payment)
                    </p>
                  </div>
                </div>
                <div className="space-y-3 pl-6">
                  <input
                    type="text"
                    className="w-full glass-panel rounded p-3 font-mono text-xs border border-border/30 focus:border-[#ffd700]/50 focus:outline-none"
                    placeholder="NFT Contract Address (optional)"
                  />
                </div>
              </div>

              {/* Revenue Split Preview */}
              <div className="glass-panel-enhanced rounded-lg p-6 border border-[#00ffff]/20 space-y-4">
                <h3 className="font-mono text-sm font-bold text-[#00ffff]">REVENUE SPLIT PREVIEW</h3>
                <div className="space-y-2">
                  <div className="flex justify-between font-mono text-sm">
                    <span className="text-white/80" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
                      Your Earnings:
                    </span>
                    <span className="text-[#ffd700] font-bold">90%</span>
                  </div>
                  <div className="flex justify-between font-mono text-sm">
                    <span className="text-white/80" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
                      Platform Fee:
                    </span>
                    <span className="text-white">10%</span>
                  </div>
                  <div className="pt-2 border-t border-border/30 flex justify-between font-mono text-sm">
                    <span className="text-white font-bold">You Receive:</span>
                    <span className="text-[#ffd700] font-bold">$8.99</span>
                  </div>
                </div>
              </div>
            </Card>

            <div className="flex justify-between">
              <Button
                onClick={() => setMintStep(2)}
                variant="outline"
                size="lg"
                className="font-mono font-bold uppercase tracking-wider border-[#00ffff] hover:bg-[#00ffff]/10 bg-transparent text-[#00ffff]"
              >
                Back
              </Button>
              <Button
                onClick={() => setMintStep(4)}
                size="lg"
                className="font-mono font-bold uppercase tracking-wider text-white hover:opacity-90"
                style={{
                  background: "#ffd700",
                  boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
                }}
              >
                Next: Review & Mint
              </Button>
            </div>
          </TabsContent>

          {/* Step 4: Mint */}
          <TabsContent value="step-4" className="space-y-6">
            <Card className="glass-panel border-[#ffd700]/20 p-8 space-y-6">
              <div className="text-center space-y-2">
                <div className="w-20 h-20 mx-auto rounded-full bg-[#ffd700]/10 border-2 border-[#ffd700] flex items-center justify-center mb-4">
                  <Check className="w-10 h-10 text-[#ffd700]" />
                </div>
                <h2 className="font-mono text-2xl font-bold neon-text-gold">READY TO MINT</h2>
                <p className="font-mono text-sm text-white/80" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
                  Review your film details before minting on the blockchain
                </p>
              </div>

              {/* Summary */}
              <div className="glass-panel-enhanced rounded-lg p-6 space-y-4">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <p className="font-mono text-xs text-[#00ffff] font-bold">FILM TITLE</p>
                    <p className="font-mono text-sm text-white">Your Film Title Here</p>
                  </div>
                  <div className="space-y-2">
                    <p className="font-mono text-xs text-[#00ffff] font-bold">BLOCKCHAIN</p>
                    <p className="font-mono text-sm text-white capitalize">{blockchain}</p>
                  </div>
                  <div className="space-y-2">
                    <p className="font-mono text-xs text-[#00ffff] font-bold">ACCESS MODEL</p>
                    <p className="font-mono text-sm text-white">Purchase (Lifetime)</p>
                  </div>
                  <div className="space-y-2">
                    <p className="font-mono text-xs text-[#00ffff] font-bold">PRICE</p>
                    <p className="font-mono text-sm text-[#ffd700]">$9.99</p>
                  </div>
                </div>
              </div>

              {/* Gas Fee Estimate */}
              <div className="glass-panel-enhanced rounded-lg p-6 border border-[#daa520]/20 space-y-3">
                <div className="flex items-center justify-between">
                  <span
                    className="font-mono text-sm text-white/80"
                    style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                  >
                    Estimated Minting Cost:
                  </span>
                  <span className="font-mono text-sm text-white font-bold">~$2.50</span>
                </div>
                <p className="font-mono text-xs text-white/70" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
                  Gas fees vary by network congestion
                </p>
              </div>

              {/* Terms */}
              <div className="glass-panel-enhanced rounded-lg p-6 space-y-3">
                <label className="flex items-start gap-3 cursor-pointer">
                  <input type="checkbox" className="mt-1" />
                  <span
                    className="font-mono text-xs text-white/70"
                    style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
                  >
                    I confirm that I own all rights to this film and agree to the{" "}
                    <Link href="/terms" className="text-[#00ffff] hover:underline">
                      Terms of Service
                    </Link>{" "}
                    and{" "}
                    <Link href="/creator-agreement" className="text-[#00ffff] hover:underline">
                      Creator Agreement
                    </Link>
                    .
                  </span>
                </label>
              </div>

              {/* Mint Button */}
              <Button
                size="lg"
                className="w-full font-mono font-bold uppercase tracking-wider text-white hover:opacity-90"
                style={{
                  background: "linear-gradient(135deg, #ffd700 0%, #daa520 100%)",
                  boxShadow: "0 0 30px rgba(255, 215, 0, 0.6)",
                }}
              >
                MINT FILM NFT
              </Button>

              <p
                className="text-center font-mono text-xs text-white/70"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
              >
                This will create your NFT and make your film available for purchase
              </p>
            </Card>

            <div className="flex justify-start">
              <Button
                onClick={() => setMintStep(3)}
                variant="outline"
                size="lg"
                className="font-mono font-bold uppercase tracking-wider border-[#00ffff] hover:bg-[#00ffff]/10 bg-transparent text-[#00ffff]"
              >
                Back
              </Button>
            </div>
          </TabsContent>
        </Tabs>

        {/* Why Mint on 789? */}
        <section className="glass-panel rounded-lg p-8 border border-[#00ffff]/20 space-y-6">
          <h2 className="font-mono text-2xl font-bold chrome-text text-center">WHY MINT ON 789 STUDIOS?</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="space-y-3 text-center">
              <div className="w-16 h-16 mx-auto rounded-full bg-[#ffd700]/10 border border-[#ffd700]/30 flex items-center justify-center">
                <DollarSign className="w-8 h-8 text-[#ffd700]" />
              </div>
              <h3 className="font-mono text-lg font-bold neon-text-gold">90% Revenue</h3>
              <p className="font-mono text-xs text-white/80" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
                Keep 90% of all sales. Lowest platform fee in Film3.
              </p>
            </div>
            <div className="space-y-3 text-center">
              <div className="w-16 h-16 mx-auto rounded-full bg-[#00ffff]/10 border border-[#00ffff]/30 flex items-center justify-center">
                <Lock className="w-8 h-8 text-[#00ffff]" />
              </div>
              <h3 className="font-mono text-lg font-bold neon-text-cyan">Token-Gating</h3>
              <p className="font-mono text-xs text-white/80" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
                Create exclusive access for your community holders.
              </p>
            </div>
            <div className="space-y-3 text-center">
              <div className="w-16 h-16 mx-auto rounded-full bg-[#daa520]/10 border border-[#daa520]/30 flex items-center justify-center">
                <TrendingUp className="w-8 h-8 text-[#daa520]" />
              </div>
              <h3 className="font-mono text-lg font-bold neon-text-goldenrod">Royalties Forever</h3>
              <p className="font-mono text-xs text-white/80" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
                Earn on every resale. Your work keeps paying you.
              </p>
            </div>
          </div>
        </section>
      </div>
    </VirtualSoundstage>
  )
}
