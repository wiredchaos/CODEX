"use client"

import { VirtualSoundstage } from "@/components/virtual-soundstage"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Mic2, Music, Users, Calendar, Radio, Sparkles } from "lucide-react"
import { useState } from "react"

const EVENTS = [
  {
    id: "poetry-slam",
    title: "Poetry Slam Night",
    host: "NEURO & GRAMI",
    time: "Every Friday 8PM EST",
    description: "Open mic poetry battles with live judging and community voting",
    color: "#00ffff",
    icon: Mic2,
  },
  {
    id: "cipher-sessions",
    title: "Cipher Sessions",
    host: "JEEP & VIBES",
    time: "Tuesdays & Thursdays 9PM EST",
    description: "Hip-hop freestyle ciphers, beatboxing, and live production",
    color: "#ffaa00",
    icon: Radio,
  },
  {
    id: "live-concerts",
    title: "Live Concerts",
    host: "WOOKI & VIBES",
    time: "Saturdays 10PM EST",
    description: "Full artist performances with 3D stage effects and interactive audience",
    color: "#ffd700",
    icon: Music,
  },
  {
    id: "community-jam",
    title: "Community Jam",
    host: "All 789 Crew",
    time: "Sunday 7PM EST",
    description: "Open jam sessions where the community collaborates in real-time",
    color: "#ff00ff",
    icon: Users,
  },
]

export default function LevelUpLoungePage() {
  const [selectedEvent, setSelectedEvent] = useState<string | null>(null)

  return (
    <VirtualSoundstage>
      {/* Top Navigation Bar */}
      <div className="border-b border-border/30 bg-black/40 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <Link href="/" className="font-mono text-xs font-bold neon-text-gold">
              789
            </Link>
            <nav className="hidden md:flex items-center gap-4">
              <Link href="/" className="font-mono text-xs text-white/70 hover:text-white transition-colors">
                Home
              </Link>
              <Link href="/lounge" className="font-mono text-xs text-white font-bold">
                Level Up Lounge
              </Link>
              <Link href="/spaces" className="font-mono text-xs text-white/70 hover:text-white transition-colors">
                Spaces Network
              </Link>
            </nav>
          </div>
        </div>
      </div>

      {/* 3D Spatial Environment Header */}
      <div className="relative h-[50vh] overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/50 to-black z-10" />

        {/* Floating 3D Stage Elements */}
        <div className="absolute inset-0 flex items-center justify-center perspective-1000">
          <div className="relative w-full max-w-6xl h-full">
            {/* Back Stage Lights */}
            <div className="absolute top-10 left-1/4 w-32 h-32 bg-[#00ffff]/20 rounded-full blur-3xl animate-pulse" />
            <div className="absolute top-10 right-1/4 w-32 h-32 bg-[#ffd700]/20 rounded-full blur-3xl animate-pulse delay-150" />
            <div className="absolute bottom-20 left-1/3 w-40 h-40 bg-[#ff00ff]/20 rounded-full blur-3xl animate-pulse delay-300" />

            {/* Stage Platform */}
            <div
              className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[90%] h-32 rounded-t-3xl border-t-4 border-x-4 border-[#ffd700]/30"
              style={{
                background: "linear-gradient(180deg, rgba(255,215,0,0.1) 0%, rgba(0,0,0,0.8) 100%)",
                transform: "translateX(-50%) rotateX(60deg)",
                transformStyle: "preserve-3d",
              }}
            />
          </div>
        </div>

        {/* Hero Content */}
        <div className="relative z-20 flex flex-col items-center justify-center h-full px-4 text-center">
          <Badge className="mb-4 font-mono text-xs uppercase bg-[#ffd700]/20 text-[#ffd700] border-[#ffd700]/50">
            <Sparkles className="w-3 h-3 mr-1" />
            Live Entertainment Venue
          </Badge>
          <h1 className="text-4xl md:text-7xl font-bold chrome-text mb-4 animate-float">LEVEL UP LOUNGE</h1>
          <p className="font-mono text-sm md:text-lg text-white/90 max-w-2xl">
            The 789 Crew hosts live poetry slams, freestyle ciphers, concerts, and community jam sessions in an
            immersive 3D spatial environment
          </p>
        </div>
      </div>

      {/* Events Grid */}
      <section className="max-w-7xl mx-auto px-4 py-16 space-y-12">
        <div className="text-center space-y-4">
          <h2 className="font-mono text-2xl md:text-4xl font-bold chrome-text">WEEKLY EVENTS</h2>
          <p className="font-mono text-sm text-white/80">
            Join the 789 crew for live performances, open mics, and community collaborations
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {EVENTS.map((event) => {
            const Icon = event.icon
            const isSelected = selectedEvent === event.id

            return (
              <Card
                key={event.id}
                className="glass-panel-enhanced border-2 p-8 space-y-6 cursor-pointer hover:scale-[1.02] transition-all duration-300"
                style={{
                  borderColor: isSelected ? event.color : `${event.color}40`,
                  boxShadow: isSelected ? `0 0 30px ${event.color}80` : "none",
                }}
                onClick={() => setSelectedEvent(event.id)}
              >
                <div className="flex items-start justify-between">
                  <div
                    className="w-16 h-16 rounded-full flex items-center justify-center border-2"
                    style={{
                      borderColor: event.color,
                      background: `${event.color}20`,
                      boxShadow: `0 0 20px ${event.color}60`,
                    }}
                  >
                    <Icon className="w-8 h-8" style={{ color: event.color }} />
                  </div>
                  <Badge
                    className="font-mono text-xs"
                    style={{
                      background: `${event.color}20`,
                      color: event.color,
                      borderColor: `${event.color}50`,
                    }}
                  >
                    <Calendar className="w-3 h-3 mr-1" />
                    {event.time}
                  </Badge>
                </div>

                <div className="space-y-3">
                  <h3 className="font-mono text-2xl font-bold text-white">{event.title}</h3>
                  <div className="flex items-center gap-2">
                    <span
                      className="font-mono text-xs text-white/80"
                      style={{ textShadow: "0 0 6px rgba(0,255,255,0.3)" }}
                    >
                      HOSTED BY
                    </span>
                    <span className="font-mono text-sm font-bold" style={{ color: event.color }}>
                      {event.host}
                    </span>
                  </div>
                  <p className="font-mono text-sm text-white/80 leading-relaxed">{event.description}</p>
                </div>

                <Button
                  size="lg"
                  className="w-full font-mono font-bold uppercase tracking-wider text-white hover:opacity-90"
                  style={{
                    background: event.color,
                    boxShadow: `0 0 20px ${event.color}80`,
                  }}
                >
                  Join Event
                </Button>
              </Card>
            )
          })}
        </div>
      </section>

      {/* 789 Community Section */}
      <section className="max-w-7xl mx-auto px-4 py-16">
        <Card className="glass-panel-enhanced border-2 border-[#00ffff]/30 p-8 md:p-12 space-y-8">
          <div className="text-center space-y-4">
            <h2 className="font-mono text-2xl md:text-4xl font-bold neon-text-cyan">789 COMMUNITY ON X</h2>
            <p className="font-mono text-sm text-white/80 max-w-2xl mx-auto">
              Follow the 789 crew, join the conversation, and stay updated on all Level Up Lounge events
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <Card className="glass-panel border-[#00ffff]/20 p-6 space-y-4 hover:border-[#00ffff] transition-all">
              <div className="flex items-center gap-3">
                <div
                  className="w-12 h-12 rounded-full bg-[#00ffff]/20 flex items-center justify-center text-xl font-bold"
                  style={{ color: "#00ffff" }}
                >
                  X
                </div>
                <div>
                  <div className="font-mono text-sm font-bold text-white">@789studiosonx</div>
                  <div
                    className="font-mono text-xs text-white/80"
                    style={{ textShadow: "0 0 6px rgba(0,255,255,0.3)" }}
                  >
                    Main Account
                  </div>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="w-full font-mono font-bold border-[#00ffff]/50 text-[#00ffff] hover:bg-[#00ffff]/10 bg-transparent"
                asChild
              >
                <a href="https://x.com/789studiosonx" target="_blank" rel="noopener noreferrer">
                  Follow
                </a>
              </Button>
            </Card>

            <Card className="glass-panel border-[#ffd700]/20 p-6 space-y-4 hover:border-[#ffd700] transition-all">
              <div className="flex items-center gap-3">
                <div
                  className="w-12 h-12 rounded-full bg-[#ffd700]/20 flex items-center justify-center text-xl font-bold"
                  style={{ color: "#ffd700" }}
                >
                  📷
                </div>
                <div>
                  <div className="font-mono text-sm font-bold text-white">@789.studios</div>
                  <div
                    className="font-mono text-xs text-white/80"
                    style={{ textShadow: "0 0 6px rgba(255,215,0,0.3)" }}
                  >
                    Instagram
                  </div>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="w-full font-mono font-bold border-[#ffd700]/50 text-[#ffd700] hover:bg-[#ffd700]/10 bg-transparent"
                asChild
              >
                <a href="https://instagram.com/789.studios" target="_blank" rel="noopener noreferrer">
                  Follow
                </a>
              </Button>
            </Card>

            <Card className="glass-panel border-[#ff00ff]/20 p-6 space-y-4 hover:border-[#ff00ff] transition-all">
              <div className="flex items-center gap-3">
                <div
                  className="w-12 h-12 rounded-full bg-[#ff00ff]/20 flex items-center justify-center text-xl font-bold"
                  style={{ color: "#ff00ff" }}
                >
                  🐕
                </div>
                <div>
                  <div className="font-mono text-sm font-bold text-white">Doginal Dogs</div>
                  <div
                    className="font-mono text-xs text-white/80"
                    style={{ textShadow: "0 0 6px rgba(255,0,255,0.3)" }}
                  >
                    Powered By
                  </div>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="w-full font-mono font-bold border-[#ff00ff]/50 text-[#ff00ff] hover:bg-[#ff00ff]/10 bg-transparent"
                asChild
              >
                <a href="https://doginaldogs.com" target="_blank" rel="noopener noreferrer">
                  Visit
                </a>
              </Button>
            </Card>
          </div>
        </Card>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/30 mt-16 py-8 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="flex gap-1">
                <div className="w-2 h-2 bg-[#ffd700] rounded-full" style={{ boxShadow: "0 0 8px #ffd700" }} />
                <div className="w-2 h-2 bg-[#00ffff] rounded-full" style={{ boxShadow: "0 0 8px #00ffff" }} />
                <div className="w-2 h-2 bg-[#ff00ff] rounded-full" style={{ boxShadow: "0 0 8px #ff00ff" }} />
              </div>
              <span className="font-mono text-xs text-white/80">789 STUDIOS © 2025 • LEVEL UP LOUNGE</span>
            </div>
            <div className="flex items-center gap-4 font-mono text-xs text-white/70">
              <Link href="/" className="hover:text-[#ffd700] transition-colors">
                HOME
              </Link>
              <Link href="/spaces" className="hover:text-[#00ffff] transition-colors">
                SPACES
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </VirtualSoundstage>
  )
}
