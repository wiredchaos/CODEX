# Trinity Core Consumer Integration Guide

## Overview

This patch is a **CONSUMER** of the WIRED CHAOS Trinity 3D Core. It does not generate new 3D infrastructure, timelines, or elevators. All spatial rendering is read-only.

## Architecture Constraints

### Read-Only Trinity Core
- ✓ Mounts existing spatial layer
- ✓ Does NOT create new 3D scenes
- ✓ Does NOT generate galaxies or universes
- ✓ Does NOT fork timelines

### Akira Codex Gating
- ✓ All timeline access governed by Akira Codex
- ✓ Respects canonical registry
- ✓ No local timeline modifications

### Firewall Rules
- ✓ Business realm data isolated
- ✓ Akashic realm data isolated
- ✓ No cross-realm contamination

## Usage

### Basic Mount

```tsx
import { EnvironmentRenderer } from "@/components/trinity/environment-renderer"

<EnvironmentRenderer 
  patchId="CLEAR" 
  kind="lobby" 
/>
```

### With Fallback

```tsx
<EnvironmentRenderer 
  patchId="CLEAR" 
  kind="lobby"
  fallback="video"  // video | static
  hotspots={true}
  hud={true}
/>
```

### Available Environment Kinds

- `lobby` - Main entrance environment
- `timeline` - Timeline visualization (NETERU, SIGNAL ERA, RVP)
- `floor` - Trinity floor mount
- `portal` - Portal transition space

## Trinity Core Integration Points

### Hotspots
Hotspots are supplied by Trinity Core. This consumer patch receives them via the spatial layer API.

### HUD
The heads-up display is rendered by Trinity Core. This patch can toggle visibility but cannot modify HUD elements.

### Camera Controls
Camera rig and controls are provided by Trinity Core. This patch consumes the existing control scheme.

## Hemisphere System

All patches exist within the WIRED CHAOS Hemisphere Mapping System:
- NETERU timeline door
- SIGNAL ERA timeline door
- RVP timeline door

Access is gated by Akira Codex. Consumer patches cannot modify timeline assignments.

## Deployment

This patch can be deployed as:
1. Standalone Next.js app
2. Module within larger monorepo
3. Embedded iframe within Trinity shell

All deployment modes maintain read-only consumer relationship with Trinity Core.

## Governance

- **Registry is canonical** - All patch definitions come from central registry
- **No local mutations** - Consumer patches cannot modify Trinity state
- **Telemetry flows up** - All events reported to Global Telemetry Bus
- **Anti-Moloch** - No competitive dynamics between patches
