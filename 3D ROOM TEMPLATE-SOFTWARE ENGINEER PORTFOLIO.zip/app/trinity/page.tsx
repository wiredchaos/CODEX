"use client"

import { EnvironmentRenderer } from "@/components/trinity/environment-renderer"

/**
 * TRINITY CORE CONSUMER DEMO PAGE
 * Demonstrates mounting to Trinity 3D Core infrastructure
 */
export default function TrinityPage() {
  return (
    <main className="h-screen w-full">
      <EnvironmentRenderer patchId="CLEAR" kind="lobby" fallback="video" hotspots={true} hud={true} />
    </main>
  )
}
