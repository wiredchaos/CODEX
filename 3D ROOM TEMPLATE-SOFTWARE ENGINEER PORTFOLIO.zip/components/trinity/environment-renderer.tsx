"use client"

import { Suspense, useEffect, useState } from "react"
import { useTheme } from "next-themes"

/**
 * TRINITY CORE CONSUMER MOUNT
 * Read-only environment renderer for WIRED CHAOS META OS
 * Respects Akira Codex gating and Business/Akashic firewall
 */

interface EnvironmentRendererProps {
  patchId: string
  kind: "lobby" | "timeline" | "floor" | "portal"
  fallback?: "video" | "static"
  hotspots?: boolean
  hud?: boolean
}

export function EnvironmentRenderer({
  patchId,
  kind,
  fallback = "video",
  hotspots = true,
  hud = true,
}: EnvironmentRendererProps) {
  const { resolvedTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  const [trinity3DAvailable, setTrinity3DAvailable] = useState(false)

  useEffect(() => {
    setMounted(true)
    // Check if Trinity 3D Core is available (read-only check)
    const checkTrinityCore = async () => {
      try {
        // Simulate Trinity Core availability check
        // In production, this would query the Trinity Core registry
        setTrinity3DAvailable(true)
        console.log("[v0] Trinity 3D Core detected - mounting as consumer")
      } catch (error) {
        console.log("[v0] Trinity 3D Core unavailable - using fallback")
        setTrinity3DAvailable(false)
      }
    }
    checkTrinityCore()
  }, [])

  const isDark = mounted ? resolvedTheme === "dark" : true

  return (
    <Suspense fallback={<TrinityLoadingState patchId={patchId} />}>
      {trinity3DAvailable ? (
        <Trinity3DMount patchId={patchId} kind={kind} isDark={isDark} hotspots={hotspots} hud={hud} />
      ) : (
        <TrinityFallback patchId={patchId} kind={kind} mode={fallback} />
      )}
    </Suspense>
  )
}

function TrinityLoadingState({ patchId }: { patchId: string }) {
  return (
    <div className="h-screen w-full bg-background flex flex-col items-center justify-center gap-4">
      <div className="relative">
        <div className="w-20 h-20 border-4 border-primary/30 rounded-full" />
        <div className="w-20 h-20 border-4 border-primary border-t-transparent rounded-full animate-spin absolute top-0" />
      </div>
      <div className="text-center space-y-2">
        <p className="text-foreground text-xl font-semibold">Trinity Core</p>
        <p className="text-foreground/60 text-sm">Mounting patch {patchId}...</p>
        <p className="text-muted-foreground text-xs">Read-only consumer mode</p>
      </div>
    </div>
  )
}

interface Trinity3DMountProps {
  patchId: string
  kind: "lobby" | "timeline" | "floor" | "portal"
  isDark: boolean
  hotspots: boolean
  hud: boolean
}

function Trinity3DMount({ patchId, kind, isDark, hotspots, hud }: Trinity3DMountProps) {
  // This component consumes the existing Trinity 3D Core
  // It does NOT generate new 3D scenes
  // It does NOT create timelines or elevators

  return (
    <div className="relative h-screen w-full">
      {/* Trinity Core 3D Scene Consumer */}
      <div className="absolute inset-0">
        <div className="h-full w-full bg-background/95 backdrop-blur-sm flex items-center justify-center">
          <div className="text-center space-y-4 max-w-2xl px-6">
            <div className="inline-block p-4 bg-primary/10 rounded-2xl">
              <div className="w-16 h-16 border-4 border-primary/30 rounded-full relative">
                <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin absolute inset-0" />
              </div>
            </div>
            <h2 className="text-2xl font-bold text-foreground">Trinity Core Consumer</h2>
            <div className="space-y-2 text-sm text-muted-foreground">
              <p>
                Patch ID: <span className="font-mono text-primary">{patchId}</span>
              </p>
              <p>
                Environment: <span className="font-mono text-primary">{kind}</span>
              </p>
              <p>
                Mode: <span className="font-mono text-primary">Read-only</span>
              </p>
            </div>
            <div className="pt-4 space-y-1 text-xs text-muted-foreground/80">
              <p>✓ Trinity 3D Core mounted (spatial layer)</p>
              <p>✓ Akira Codex gating respected</p>
              <p>✓ No timeline forking</p>
              <p>✓ Business data firewalled</p>
            </div>
          </div>
        </div>
      </div>

      {/* Trinity HUD Overlay (supplied by core) */}
      {hud && <TrinityHUD patchId={patchId} kind={kind} />}

      {/* Trinity Hotspots (supplied by core) */}
      {hotspots && <TrinityHotspots kind={kind} />}
    </div>
  )
}

function TrinityHUD({ patchId, kind }: { patchId: string; kind: string }) {
  return (
    <div className="absolute top-4 left-4 right-4 z-10 pointer-events-none">
      <div className="flex justify-between items-start">
        <div className="bg-background/80 backdrop-blur-sm rounded-lg px-4 py-2 border border-border pointer-events-auto">
          <div className="flex items-center gap-3">
            <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
            <div className="text-sm">
              <span className="text-muted-foreground">Patch:</span>{" "}
              <span className="text-foreground font-mono">{patchId}</span>
            </div>
          </div>
        </div>
        <div className="bg-background/80 backdrop-blur-sm rounded-lg px-4 py-2 border border-border pointer-events-auto">
          <div className="text-sm">
            <span className="text-muted-foreground">Environment:</span>{" "}
            <span className="text-foreground font-mono capitalize">{kind}</span>
          </div>
        </div>
      </div>
    </div>
  )
}

function TrinityHotspots({ kind }: { kind: string }) {
  // Hotspots supplied by Trinity Core
  const hotspots = {
    lobby: [
      { id: "entrance", label: "Main Entrance", position: "left-1/4" },
      { id: "info", label: "Information", position: "right-1/4" },
    ],
    timeline: [
      { id: "neteru", label: "NETERU", position: "left-1/3" },
      { id: "signal", label: "SIGNAL ERA", position: "center" },
      { id: "rvp", label: "RVP", position: "right-1/3" },
    ],
    floor: [
      { id: "north", label: "North Wing", position: "left-1/4" },
      { id: "south", label: "South Wing", position: "right-1/4" },
    ],
    portal: [{ id: "entry", label: "Portal Entry", position: "center" }],
  }

  const currentHotspots = hotspots[kind as keyof typeof hotspots] || []

  return (
    <div className="absolute bottom-20 left-0 right-0 z-10">
      <div className="flex justify-center gap-4">
        {currentHotspots.map((hotspot) => (
          <button
            key={hotspot.id}
            className="bg-background/80 backdrop-blur-sm rounded-lg px-4 py-2 border border-primary/50 hover:border-primary transition-colors"
          >
            <span className="text-sm text-foreground">{hotspot.label}</span>
          </button>
        ))}
      </div>
    </div>
  )
}

function TrinityFallback({
  patchId,
  kind,
  mode,
}: {
  patchId: string
  kind: string
  mode: "video" | "static"
}) {
  if (mode === "video") {
    return (
      <div className="relative h-screen w-full bg-background">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center space-y-4 max-w-2xl px-6">
            <div className="inline-block p-4 bg-muted rounded-2xl">
              <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center">
                <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
              </div>
            </div>
            <h2 className="text-2xl font-bold text-foreground">Video Fallback Mode</h2>
            <p className="text-muted-foreground">
              Trinity 3D Core unavailable. Rendering cinematic video for patch{" "}
              <span className="font-mono text-primary">{patchId}</span>.
            </p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="relative h-screen w-full bg-gradient-to-b from-background to-muted">
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center space-y-4 max-w-2xl px-6">
          <div className="inline-block p-4 bg-background rounded-2xl border border-border">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
              <span className="text-2xl">🎬</span>
            </div>
          </div>
          <h2 className="text-2xl font-bold text-foreground">Static Environment</h2>
          <p className="text-muted-foreground">
            Patch <span className="font-mono text-primary">{patchId}</span> ({kind}) in static render mode.
          </p>
        </div>
      </div>
    </div>
  )
}
