/**
 * TRINITY REGISTRY (READ-ONLY)
 * Canonical patch registry for WIRED CHAOS META OS
 * Consumer patches query this registry, never modify it
 */

import type { TrinityPatch } from "./types"

// Mock registry - in production this would be fetched from canonical source
export const TRINITY_REGISTRY: Record<string, TrinityPatch> = {
  CLEAR: {
    id: "CLEAR",
    name: "Clear Patch",
    realm: "Business",
    floor: 1,
    gating: {
      akiraCodex: true,
      hemisphereAccess: ["NETERU", "SIGNAL_ERA", "RVP"],
    },
  },
  // Additional patches would be defined here
}

export function getTrinityPatch(patchId: string): TrinityPatch | null {
  return TRINITY_REGISTRY[patchId] || null
}

export function validatePatchAccess(patchId: string, userId?: string): { allowed: boolean; reason?: string } {
  const patch = getTrinityPatch(patchId)

  if (!patch) {
    return { allowed: false, reason: "Patch not found in registry" }
  }

  // Akira Codex gating check
  if (patch.gating.akiraCodex) {
    console.log("[v0] Akira Codex gating active for patch:", patchId)
    // In production, this would check actual permissions
  }

  return { allowed: true }
}
