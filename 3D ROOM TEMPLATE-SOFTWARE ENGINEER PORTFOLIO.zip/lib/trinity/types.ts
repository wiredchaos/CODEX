/**
 * TRINITY CORE CONSUMER TYPES
 * Type definitions for WIRED CHAOS META OS integration
 */

export type PatchId = string

export type EnvironmentKind = "lobby" | "timeline" | "floor" | "portal"

export type RealmType = "Business" | "Akashic"

export interface TrinityPatch {
  id: PatchId
  name: string
  realm: RealmType
  floor?: number
  timeline?: string
  gating: {
    akiraCodex: boolean
    hemisphereAccess: string[]
  }
}

export interface TrinityHotspot {
  id: string
  label: string
  position: [number, number, number]
  action?: () => void
  gated?: boolean
}

export interface TrinityHUD {
  visible: boolean
  elements: {
    patchInfo: boolean
    telemetry: boolean
    navigation: boolean
  }
}

export interface TrinityMountConfig {
  patchId: PatchId
  kind: EnvironmentKind
  readOnly: true // Always true for consumer mounts
  firewall: {
    businessData: boolean
    akashicData: boolean
  }
}
