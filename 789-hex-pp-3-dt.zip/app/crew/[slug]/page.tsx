"use client"

import { VirtualSoundstage } from "@/components/virtual-soundstage"
import { NavigationalAvatar } from "@/components/navigational-avatar"
import { GlobalDisclaimer } from "@/components/global-disclaimer"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { getCrewColor } from "@/lib/crew-colors"
import Link from "next/link"
import { Radio, Calendar, Users, Sparkles, ExternalLink, Instagram, Youtube, MessageCircle } from "lucide-react"
import { use } from "react"
import { BackButton } from "@/components/ui/back-button"

const CREW_DATA: Record<string, any> = {
  vibes: {
    name: "VIBES",
    handle: "vibesmetax",
    fullHandle: "VIBES | Energy Architect",
    doginalId: "DD#XXXX",
    time: "7 PM EST",
    specialty: "Energy & Positivity",
    avatar: "https://i.postimg.cc/k5hMbFBS/8.png",
    tagline: "Content Creator + Community Energy Catalyst · Bridging Web2 → Web3 · Reporting via 789 Studios",
    bio: "VIBES brings unmatched energy and positivity to the Crypto Spaces Network. Broadcasting daily at 7 PM EST, VIBES is the heartbeat of the 789 community, creating spaces where builders, creators, and visionaries connect. Known for turning conversations into movements.",
    socialLinks: {
      x: "https://x.com/vibesmetax",
      instagram: "",
      youtube: "",
      tiktok: "",
      threads: "",
    },
    achievements: [
      "Community Energy Catalyst",
      "7 PM EST Prime Time Host",
      "10K+ Daily Space Listeners",
      "3+ Years Daily Broadcasting",
      "789 Studios Co-Founder",
    ],
    spaces: ["Community Building", "Web3 Culture", "Creator Spotlights", "Positive Energy Sessions"],
    projects: [],
    featureSection: null,
    hasContent: false,
  },
  neuro: {
    name: "NEURO",
    handle: "neurometax",
    fullHandle: "MetaX | chirp™",
    doginalId: "DD#1787",
    time: "1 AM EST",
    specialty: "Tech & Innovation",
    avatar: "https://i.postimg.cc/0QMkdMw7/15.png",
    tagline:
      "NEURO DD#1787 Content Creator + AI Ghostwriter Translator Bridging Web2 → Web3 · Reporting via Wired Chaos + BWB",
    bio: "Neuro MetaX has been active in Web3 since 2020, operating at the intersection of AI, NFTs, and narrative media. As a collector, content creator, and studio architect, Neuro uses Anti-Moloch principles to design systems where creators, collectors, and communities all participate in the upside of the work they build together.",
    socialLinks: {
      x: "https://x.com/neurometax",
      instagram: "https://instagram.com/neurometax",
      youtube: "https://youtube.com/@neurometax",
      tiktok: "https://tiktok.com/@neurometax",
      threads: "https://threads.net/@neurometax",
      chirp: "https://chirp.me/neurometa",
    },
    achievements: [
      "Film3 Pioneer & Educator",
      "Host of FLINCH Case Study Documentary Course",
      "5+ Years in Web3 Cinema",
      "AI Ghostwriter & Translator",
      "1 AM EST Night Shift Commander",
      "Anti-Moloch System Designer",
    ],
    spaces: ["Film3 Innovation", "AI & Tech Talks", "Blockchain Cinema", "Web3 Education", "Cultural Decode Sessions"],
    projects: [
      {
        title: "FLINCH: The First NFT Film Franchise",
        description: "Comprehensive documentary course on Cameron Van Hoy's revolutionary Film3 project",
        link: "/film3/flinch-case-study",
      },
    ],
    featureSection: {
      title: "NeuroMetaX — Decode the Hidden Layers",
      description:
        "Welcome to NeuroMetaX — where neural networks meet metaphysics, media, and memory. Here we investigate the stories beneath the headlines — from black ops and government surveillance to cultural resistance, psychedelia, music history, and modern consciousness shifts.",
      features: [
        "Deep-dive documentaries",
        "Mind-expanding interviews",
        "Cultural decode sessions",
        "Retro media breakdowns",
      ],
      tagline:
        "If you're tracing the Hippie-to-Hip Hop pipeline, decoding media propaganda, or questioning the nexus between art and intelligence systems, you're in the right place.",
    },
    antiMoloch:
      "Neuro's work through 789 Studios and Wired Chaos is guided by Anti-Moloch design: systems that reduce extractive gatekeeping and reward aligned, cooperative creative work across Web2 and Web3.",
    hasContent: true,
  },
  gator: {
    name: "GATOR",
    handle: "gatormetax",
    fullHandle: "GATOR | Game Master",
    doginalId: "DD#XXXX",
    time: "9 PM EST",
    specialty: "Gaming",
    avatar: "https://i.postimg.cc/5tk9Cq6L/10.png",
    tagline: "Web3 Gaming Authority + GameFi Expert · Bridging Traditional Gaming → Blockchain",
    bio: "GATOR dominates the gaming sector of Web3 at 9 PM EST daily. From GameFi to esports, GATOR brings competitive gaming culture to the blockchain generation. Known for hosting legendary gaming tournaments and discovering emerging play-to-earn projects.",
    socialLinks: {
      x: "https://x.com/gatormetax",
      instagram: "",
      youtube: "",
      tiktok: "",
      threads: "",
    },
    achievements: [
      "Web3 Gaming Authority",
      "GameFi Tournament Host",
      "9 PM EST Gaming Prime Time",
      "100+ Gaming Projects Covered",
      "789 Studios Gaming Division Lead",
    ],
    spaces: ["GameFi Deep Dives", "Esports & Blockchain", "P2E Strategy Sessions", "Gaming Community Raids"],
    projects: [],
    featureSection: null,
    hasContent: false,
  },
  wooki: {
    name: "WOOKI",
    handle: "wookimeta",
    fullHandle: "WOOKI | The Strategist",
    doginalId: "DD#XXXX",
    time: "8 PM EST",
    specialty: "Strategy",
    avatar: "https://i.postimg.cc/g0BcZqnR/9.png",
    tagline: "Web3 Strategic Analyst + Tokenomics Expert · Market Navigation Specialist",
    bio: "WOOKI is the master strategist of the 789 crew, bringing calculated insights to Web3 at 8 PM EST. Known for breaking down complex tokenomics, project analysis, and helping communities navigate market cycles with wisdom and clarity.",
    socialLinks: {
      x: "https://x.com/wookimeta",
      instagram: "",
      youtube: "",
      tiktok: "",
      threads: "",
    },
    achievements: [
      "Web3 Strategic Analyst",
      "Tokenomics Breakdown Expert",
      "8 PM EST Strategy Hour Host",
      "200+ Project Reviews",
      "789 Studios Strategy Director",
    ],
    spaces: ["Market Analysis", "Tokenomics Deep Dives", "Project Due Diligence", "Web3 Strategy Sessions"],
    projects: [],
    featureSection: null,
    hasContent: false,
  },
  jeep: {
    name: "JEEP",
    handle: "jeepmeta",
    fullHandle: "JEEP | Culture Curator",
    doginalId: "DD#XXXX",
    time: "1 PM EST",
    specialty: "Hip-Hop Culture",
    avatar: "https://i.postimg.cc/6Q16vLyp/5.png",
    tagline: "Hip-Hop x Web3 Pioneer + Music NFT Advocate · Bridging Streets → Blockchain",
    bio: "JEEP brings authentic hip-hop culture to Web3 daily at 1 PM EST. Connecting the streets to the blockchain, JEEP showcases how music, art, and culture intersect with decentralization. A true bridge between traditional hip-hop and the metaverse.",
    socialLinks: {
      x: "https://x.com/jeepmeta",
      instagram: "",
      youtube: "",
      tiktok: "",
      threads: "",
    },
    achievements: [
      "Hip-Hop x Web3 Pioneer",
      "Music NFT Advocate",
      "1 PM EST Afternoon Drive Host",
      "50+ Artist Collaborations",
      "789 Studios Culture Director",
    ],
    spaces: ["Hip-Hop in Web3", "Music NFT Showcases", "Street Culture Meets Blockchain", "Artist Spotlights"],
    projects: [],
    featureSection: null,
    hasContent: false,
  },
  artsy: {
    name: "ARTSY",
    handle: "artsymeta",
    fullHandle: "ARTSY | Creative Visionary",
    doginalId: "DD#XXXX",
    time: "2 AM EST",
    specialty: "Creative Direction",
    avatar: "https://i.postimg.cc/Y9GrfGWf/16.png",
    tagline: "Digital Art Director + NFT Art Curator · Web3 Creative Innovation",
    bio: "ARTSY transforms the late night into an art gallery at 2 AM EST. The creative visionary behind 789's aesthetic direction, ARTSY explores digital art, NFT collections, and the future of creative expression on the blockchain. Every space is a masterclass in Web3 art.",
    socialLinks: {
      x: "https://x.com/artsymeta",
      instagram: "",
      youtube: "",
      tiktok: "",
      threads: "",
    },
    achievements: [
      "Digital Art Director",
      "NFT Art Curator",
      "2 AM EST Late Night Creative Sessions",
      "100+ Artists Featured",
      "789 Studios Creative Director",
    ],
    spaces: ["NFT Art Reviews", "Digital Creation Techniques", "Web3 Artist Spotlights", "Creative Innovation Labs"],
    projects: [],
    featureSection: null,
    hasContent: false,
  },
}

export default function CrewMemberPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = use(params)
  const member = CREW_DATA[slug] || CREW_DATA.neuro

  const crewColor = getCrewColor(member.name)

  return (
    <VirtualSoundstage>
      <NavigationalAvatar />

      {/* Navigation */}
      <div className="border-b border-border/30 bg-black/40 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <BackButton fallbackHref="/crew" />
            <Link
              href="/"
              className="font-mono text-xs font-bold"
              style={{ color: "#ffd700", textShadow: "0 0 10px rgba(255, 215, 0, 0.5)" }}
            >
              789
            </Link>
            <nav className="hidden md:flex items-center gap-4">
              <Link href="/" className="font-mono text-xs text-white/70 hover:text-white transition-colors">
                Home
              </Link>
              <Link href="/crew" className="font-mono text-xs text-white/70 hover:text-white transition-colors">
                Crew
              </Link>
              <Link href={`/crew/${slug}`} className="font-mono text-xs text-white font-bold">
                {member.name}
              </Link>
            </nav>
          </div>
        </div>
      </div>

      {/* Hero Section - Chirp Style */}
      <section className="relative py-12 px-4">
        <div className="max-w-2xl mx-auto text-center">
          {/* Avatar */}
          <div
            className="w-32 h-32 mx-auto rounded-full border-4 overflow-hidden relative mb-6"
            style={{
              borderColor: crewColor.primary,
              boxShadow: `0 0 40px ${crewColor.glow}`,
            }}
          >
            <img src={member.avatar || "/placeholder.svg"} alt={member.name} className="w-full h-full object-cover" />
            <div className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-[#ffd700] border-2 border-black flex items-center justify-center">
              <span className="text-sm">🐕</span>
            </div>
          </div>

          {/* Handle & Tagline */}
          <h1
            className="text-3xl font-bold mb-2"
            style={{ color: crewColor.primary, textShadow: `0 0 20px ${crewColor.glow}` }}
          >
            {member.handle}
          </h1>

          <p
            className="font-mono text-sm text-white/90 mb-6 leading-relaxed"
            style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.3)" }}
          >
            {member.tagline}
          </p>

          {/* Social Links Row - Chirp Style */}
          <div className="flex flex-wrap justify-center gap-3 mb-8">
            {member.socialLinks.instagram && (
              <Button
                className="font-mono text-xs"
                style={{
                  background: "linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888)",
                  color: "white",
                  textShadow: "0 0 5px rgba(255, 255, 255, 0.5)",
                }}
                asChild
              >
                <a href={member.socialLinks.instagram} target="_blank" rel="noopener noreferrer">
                  <Instagram className="w-4 h-4 mr-2" />
                  Dive in Instagram content!
                </a>
              </Button>
            )}

            {member.socialLinks.tiktok && (
              <Button
                className="font-mono text-xs bg-black border border-white/30 text-white hover:bg-white/10"
                asChild
              >
                <a href={member.socialLinks.tiktok} target="_blank" rel="noopener noreferrer">
                  Find out more on TikTok
                </a>
              </Button>
            )}

            {member.socialLinks.x && (
              <Button
                className="font-mono text-xs bg-black border border-cyan/50 text-cyan hover:bg-cyan/10"
                style={{ textShadow: "0 0 10px rgba(0, 255, 255, 0.5)" }}
                asChild
              >
                <a href={member.socialLinks.x} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  See more on X
                </a>
              </Button>
            )}

            {member.socialLinks.youtube && (
              <Button className="font-mono text-xs bg-red-600 text-white hover:bg-red-700" asChild>
                <a href={member.socialLinks.youtube} target="_blank" rel="noopener noreferrer">
                  <Youtube className="w-4 h-4 mr-2" />
                  Must-see YouTube!
                </a>
              </Button>
            )}

            {member.socialLinks.threads && (
              <Button
                className="font-mono text-xs bg-black border border-white/30 text-white hover:bg-white/10"
                asChild
              >
                <a href={member.socialLinks.threads} target="_blank" rel="noopener noreferrer">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Don't miss my Threads!
                </a>
              </Button>
            )}

            {member.socialLinks.chirp && (
              <Button
                className="font-mono text-xs"
                style={{
                  background: crewColor.primary,
                  color: "#000",
                  boxShadow: `0 0 15px ${crewColor.glow}`,
                }}
                asChild
              >
                <a href={member.socialLinks.chirp} target="_blank" rel="noopener noreferrer">
                  View Chirp Profile
                </a>
              </Button>
            )}
          </div>

          {/* Coming Soon for non-content creators */}
          {!member.hasContent && (
            <div className="glass-panel rounded-lg p-6 border border-goldenrod/30 mb-8">
              <p
                className="font-mono text-sm text-goldenrod"
                style={{ textShadow: "0 0 10px rgba(218, 165, 32, 0.5)" }}
              >
                Content Coming Soon — {member.name} will be creating content on 789 Studios
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Feature Section - For NEURO */}
      {member.featureSection && (
        <section className="max-w-3xl mx-auto px-4 py-8">
          <Card className="glass-panel-enhanced border-2 p-8" style={{ borderColor: `${crewColor.primary}40` }}>
            <h2
              className="font-mono text-2xl font-bold mb-4"
              style={{ color: crewColor.primary, textShadow: `0 0 15px ${crewColor.glow}` }}
            >
              {member.featureSection.title}
            </h2>
            <p
              className="font-mono text-sm text-white/80 mb-6 leading-relaxed"
              style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
            >
              {member.featureSection.description}
            </p>

            <div className="mb-6">
              <p
                className="font-mono text-xs text-white/60 mb-3"
                style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
              >
                Weekly drops include:
              </p>
              <ul className="space-y-2">
                {member.featureSection.features.map((feature: string, index: number) => (
                  <li key={index} className="flex items-center gap-3">
                    <div
                      className="w-2 h-2 rounded-full"
                      style={{
                        background: crewColor.primary,
                        boxShadow: `0 0 10px ${crewColor.glow}`,
                      }}
                    />
                    <span
                      className="font-mono text-sm text-white/90"
                      style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
                    >
                      {feature}
                    </span>
                  </li>
                ))}
              </ul>
            </div>

            <p
              className="font-mono text-xs text-white/70 italic"
              style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
            >
              {member.featureSection.tagline}
            </p>
          </Card>
        </section>
      )}

      {/* Anti-Moloch Section */}
      {member.antiMoloch && (
        <section className="max-w-3xl mx-auto px-4 py-4">
          <Card className="glass-panel border border-goldenrod/30 p-6">
            <h3
              className="font-mono text-sm font-bold text-goldenrod mb-2"
              style={{ textShadow: "0 0 10px rgba(218, 165, 32, 0.5)" }}
            >
              Anti-Moloch Design Philosophy
            </h3>
            <p
              className="font-mono text-xs text-white/80 leading-relaxed"
              style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
            >
              {member.antiMoloch}
            </p>
          </Card>
        </section>
      )}

      {/* Bio Section */}
      <section className="max-w-3xl mx-auto px-4 py-8">
        <Card className="glass-panel-enhanced border-2 p-8" style={{ borderColor: `${crewColor.primary}40` }}>
          <div className="flex items-center gap-3 mb-4">
            <Badge
              className="font-mono text-xs uppercase"
              style={{
                background: `${crewColor.primary}20`,
                color: crewColor.primary,
                borderColor: `${crewColor.primary}50`,
                textShadow: `0 0 10px ${crewColor.glow}`,
              }}
            >
              <Radio className="w-3 h-3 mr-1" />
              789 CREW · {member.time}
            </Badge>
          </div>
          <p
            className="font-mono text-sm text-white/80 leading-relaxed"
            style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
          >
            {member.bio}
          </p>
        </Card>
      </section>

      {/* Achievements */}
      <section className="max-w-3xl mx-auto px-4 py-8">
        <Card className="glass-panel-enhanced border-2 p-8" style={{ borderColor: `${crewColor.primary}40` }}>
          <div className="flex items-center gap-3 mb-6">
            <Sparkles className="w-6 h-6" style={{ color: crewColor.primary }} />
            <h2
              className="font-mono text-xl font-bold text-white"
              style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.3)" }}
            >
              ACHIEVEMENTS
            </h2>
          </div>
          <ul className="space-y-3">
            {member.achievements.map((achievement: string, index: number) => (
              <li key={index} className="flex items-start gap-3">
                <div
                  className="w-2 h-2 rounded-full mt-2 flex-shrink-0"
                  style={{
                    background: crewColor.primary,
                    boxShadow: `0 0 10px ${crewColor.glow}`,
                  }}
                />
                <span
                  className="font-mono text-sm text-white/90"
                  style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
                >
                  {achievement}
                </span>
              </li>
            ))}
          </ul>
        </Card>
      </section>

      {/* Space Topics */}
      <section className="max-w-3xl mx-auto px-4 py-8">
        <Card className="glass-panel-enhanced border-2 p-8" style={{ borderColor: `${crewColor.primary}40` }}>
          <div className="flex items-center gap-3 mb-6">
            <Calendar className="w-6 h-6" style={{ color: crewColor.primary }} />
            <h2
              className="font-mono text-xl font-bold text-white"
              style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.3)" }}
            >
              SPACE TOPICS
            </h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {member.spaces.map((topic: string, index: number) => (
              <Badge
                key={index}
                className="font-mono text-xs"
                style={{
                  background: `${crewColor.primary}20`,
                  color: crewColor.primary,
                  borderColor: `${crewColor.primary}50`,
                  textShadow: `0 0 5px ${crewColor.glow}`,
                }}
              >
                {topic}
              </Badge>
            ))}
          </div>
        </Card>
      </section>

      {/* Projects */}
      {member.projects && member.projects.length > 0 && (
        <section className="max-w-3xl mx-auto px-4 py-8">
          <Card className="glass-panel-enhanced border-2 p-8" style={{ borderColor: `${crewColor.primary}40` }}>
            <div className="flex items-center gap-3 mb-6">
              <Users className="w-6 h-6" style={{ color: crewColor.primary }} />
              <h2
                className="font-mono text-xl font-bold text-white"
                style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.3)" }}
              >
                FEATURED PROJECTS
              </h2>
            </div>
            <div className="space-y-4">
              {member.projects.map((project: any, index: number) => (
                <Card
                  key={index}
                  className="glass-panel p-6 space-y-3 border"
                  style={{ borderColor: `${crewColor.primary}40` }}
                >
                  <h3
                    className="font-mono text-lg font-bold text-white"
                    style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.3)" }}
                  >
                    {project.title}
                  </h3>
                  <p
                    className="font-mono text-sm text-white/80"
                    style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
                  >
                    {project.description}
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    className="font-mono bg-transparent"
                    style={{
                      borderColor: crewColor.primary,
                      color: crewColor.primary,
                      textShadow: `0 0 5px ${crewColor.glow}`,
                    }}
                    asChild
                  >
                    <Link href={project.link}>View Project →</Link>
                  </Button>
                </Card>
              ))}
            </div>
          </Card>
        </section>
      )}

      {/* Action Panel */}
      <section className="max-w-3xl mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 gap-4">
          <Button
            size="lg"
            className="font-mono font-bold uppercase tracking-wider w-full"
            style={{
              background: crewColor.primary,
              color: "#000",
              boxShadow: `0 0 20px ${crewColor.glow}`,
            }}
            asChild
          >
            <a href={member.socialLinks.x} target="_blank" rel="noopener noreferrer">
              Join My X Spaces
            </a>
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="font-mono font-bold uppercase tracking-wider w-full bg-transparent"
            style={{
              borderColor: crewColor.primary,
              color: crewColor.primary,
              textShadow: `0 0 5px ${crewColor.glow}`,
            }}
            asChild
          >
            <Link href="/pricing">Book Studio Time / Collab</Link>
          </Button>
        </div>
      </section>

      <GlobalDisclaimer />
    </VirtualSoundstage>
  )
}
