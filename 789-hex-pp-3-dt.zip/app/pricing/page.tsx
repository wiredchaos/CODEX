"use client"

import { VirtualSoundstage } from "@/components/virtual-soundstage"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BackButton } from "@/components/ui/back-button"

export default function PricingPage() {
  return (
    <VirtualSoundstage>
      {/* Top Navigation Bar */}
      <div className="border-b border-border/30 bg-black/40 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <BackButton fallbackHref="/" />
            <Link href="/" className="font-mono text-xs font-bold neon-text-gold">
              789
            </Link>
            <nav className="hidden md:flex items-center gap-4">
              <Link
                href="/"
                className="font-mono text-xs text-white/70 hover:text-white transition-colors"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
              >
                Studios
              </Link>
              <Link
                href="/spaces"
                className="font-mono text-xs text-white/70 hover:text-white transition-colors"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
              >
                Spaces Network
              </Link>
              <Link href="/pricing" className="font-mono text-xs text-foreground font-bold">
                Pricing
              </Link>
            </nav>
          </div>
          <Button
            size="sm"
            className="font-mono font-bold uppercase tracking-wider text-white hover:opacity-90"
            style={{
              background: "#ffd700",
              boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
            }}
          >
            Book Session
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12 space-y-12">
        {/* Header */}
        <header className="text-center space-y-4">
          <h1 className="text-3xl md:text-5xl font-bold chrome-text">STUDIO PRICING</h1>
          <p
            className="font-mono text-sm md:text-base text-white/80 max-w-2xl mx-auto"
            style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
          >
            Flexible pricing options for artists, producers, and content creators
          </p>
        </header>

        {/* Pricing Tiers */}
        <div className="grid md:grid-cols-3 gap-8">
          {/* STARTER */}
          <div className="glass-panel rounded-lg p-8 border-2 border-[#daa520]/30 hover:border-[#daa520]/60 transition-all space-y-6">
            <div className="space-y-2">
              <h3 className="font-mono text-sm font-bold neon-text-goldenrod">STARTER</h3>
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-bold neon-text-gold">$75</span>
                <span className="font-mono text-sm text-white/80" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
                  /hour
                </span>
              </div>
              <p className="font-mono text-xs text-white/70" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
                Perfect for demos and quick sessions
              </p>
            </div>

            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#daa520] mt-1.5" style={{ boxShadow: "0 0 8px #daa520" }} />
                <span className="font-mono text-sm text-foreground">Basic recording setup</span>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#daa520] mt-1.5" style={{ boxShadow: "0 0 8px #daa520" }} />
                <span className="font-mono text-sm text-foreground">Engineer assistance included</span>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#daa520] mt-1.5" style={{ boxShadow: "0 0 8px #daa520" }} />
                <span className="font-mono text-sm text-foreground">Standard microphone selection</span>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#daa520] mt-1.5" style={{ boxShadow: "0 0 8px #daa520" }} />
                <span className="font-mono text-sm text-foreground">Mixed stems delivery</span>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#daa520] mt-1.5" style={{ boxShadow: "0 0 8px #daa520" }} />
                <span className="font-mono text-sm text-foreground">2-day turnaround</span>
              </div>
            </div>

            <Button
              variant="outline"
              className="w-full font-mono font-bold uppercase tracking-wider border-[#daa520] hover:bg-[#daa520]/10 bg-transparent text-[#daa520]"
            >
              Book Starter
            </Button>
          </div>

          {/* PRO */}
          <div className="glass-panel rounded-lg p-8 border-2 border-[#ffd700] hover:border-[#ffd700] transition-all space-y-6 relative">
            <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
              <span className="font-mono text-xs font-bold px-3 py-1 bg-[#ffd700] text-white rounded">
                MOST POPULAR
              </span>
            </div>

            <div className="space-y-2">
              <h3 className="font-mono text-sm font-bold neon-text-gold">PRO</h3>
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-bold neon-text-gold">$150</span>
                <span className="font-mono text-sm text-white/80" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
                  /hour
                </span>
              </div>
              <p className="font-mono text-xs text-white/70" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
                Full production suite for serious projects
              </p>
            </div>

            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#ffd700] mt-1.5" style={{ boxShadow: "0 0 8px #ffd700" }} />
                <span className="font-mono text-sm text-foreground">SSL console + premium plugins</span>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#ffd700] mt-1.5" style={{ boxShadow: "0 0 8px #ffd700" }} />
                <span className="font-mono text-sm text-foreground">Expert engineer + producer</span>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#ffd700] mt-1.5" style={{ boxShadow: "0 0 8px #ffd700" }} />
                <span className="font-mono text-sm text-foreground">Premium mic locker access</span>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#ffd700] mt-1.5" style={{ boxShadow: "0 0 8px #ffd700" }} />
                <span className="font-mono text-sm text-foreground">Mixing + mastering included</span>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#ffd700] mt-1.5" style={{ boxShadow: "0 0 8px #ffd700" }} />
                <span className="font-mono text-sm text-foreground">24-hour turnaround</span>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#ffd700] mt-1.5" style={{ boxShadow: "0 0 8px #ffd700" }} />
                <span className="font-mono text-sm text-foreground">Unlimited revisions</span>
              </div>
            </div>

            <Button
              className="w-full font-mono font-bold uppercase tracking-wider text-white hover:opacity-90"
              style={{
                background: "#ffd700",
                boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
              }}
            >
              Book Pro
            </Button>
          </div>

          {/* UNLIMITED */}
          <div className="glass-panel rounded-lg p-8 border-2 border-[#00ffff]/30 hover:border-[#00ffff]/60 transition-all space-y-6">
            <div className="space-y-2">
              <h3 className="font-mono text-sm font-bold neon-text-cyan">UNLIMITED</h3>
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-bold neon-text-cyan">$2K</span>
                <span className="font-mono text-sm text-white/80" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
                  /month
                </span>
              </div>
              <p className="font-mono text-xs text-white/70" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
                24/7 access for power users
              </p>
            </div>

            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#00ffff] mt-1.5" style={{ boxShadow: "0 0 8px #00ffff" }} />
                <span className="font-mono text-sm text-foreground">Unlimited studio time</span>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#00ffff] mt-1.5" style={{ boxShadow: "0 0 8px #00ffff" }} />
                <span className="font-mono text-sm text-foreground">Priority booking + 24/7 access</span>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#00ffff] mt-1.5" style={{ boxShadow: "0 0 8px #00ffff" }} />
                <span className="font-mono text-sm text-foreground">Remote collaboration tools</span>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#00ffff] mt-1.5" style={{ boxShadow: "0 0 8px #00ffff" }} />
                <span className="font-mono text-sm text-foreground">Dedicated engineer</span>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#00ffff] mt-1.5" style={{ boxShadow: "0 0 8px #00ffff" }} />
                <span className="font-mono text-sm text-foreground">Cloud storage + project backups</span>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#00ffff] mt-1.5" style={{ boxShadow: "0 0 8px #00ffff" }} />
                <span className="font-mono text-sm text-foreground">Livestream capability</span>
              </div>
            </div>

            <Button
              variant="outline"
              className="w-full font-mono font-bold uppercase tracking-wider border-[#00ffff] hover:bg-[#00ffff]/10 bg-transparent text-[#00ffff]"
            >
              Book Unlimited
            </Button>
          </div>
        </div>

        {/* Additional Services */}
        <section className="glass-panel rounded-lg p-8 md:p-12 border-2 border-border/30 space-y-6">
          <h2 className="font-mono text-2xl font-bold chrome-text text-center">ADDITIONAL SERVICES</h2>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-3 p-6 rounded bg-background/50 border border-border/30">
              <h4 className="font-mono text-sm font-bold neon-text-gold">PROJECT-BASED PACKAGES</h4>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-mono text-xs text-foreground">Single Track (Mix + Master)</span>
                  <span className="font-mono text-xs text-[#ffd700]">$300</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-mono text-xs text-foreground">EP Package (5 tracks)</span>
                  <span className="font-mono text-xs text-[#ffd700]">$1,200</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-mono text-xs text-foreground">Album Package (10+ tracks)</span>
                  <span className="font-mono text-xs text-[#ffd700]">$2,500</span>
                </div>
              </div>
            </div>

            <div className="space-y-3 p-6 rounded bg-background/50 border border-border/30">
              <h4 className="font-mono text-sm font-bold neon-text-cyan">CONTENT CREATION</h4>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-mono text-xs text-foreground">Podcast Recording (2 hrs)</span>
                  <span className="font-mono text-xs text-[#00ffff]">$200</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-mono text-xs text-foreground">Video Production Session</span>
                  <span className="font-mono text-xs text-[#00ffff]">$500</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-mono text-xs text-foreground">Livestream Setup + Support</span>
                  <span className="font-mono text-xs text-[#00ffff]">$400</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Revenue Model Overview */}
        <section className="glass-panel rounded-lg p-8 md:p-12 border-2 border-[#ffd700]/20 space-y-6">
          <h2 className="font-mono text-2xl font-bold neon-text-gold text-center">789 REVENUE ENGINE</h2>
          <p
            className="font-mono text-sm text-white/80 text-center max-w-3xl mx-auto"
            style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
          >
            Multiple revenue streams ensure sustainable operations and continuous infrastructure improvements
          </p>

          <div className="grid md:grid-cols-3 gap-6 pt-6">
            <div className="text-center space-y-3">
              <div className="w-16 h-16 rounded-full bg-[#ffd700]/10 border-2 border-[#ffd700] flex items-center justify-center mx-auto">
                <span className="text-2xl font-bold neon-text-gold">$</span>
              </div>
              <h4 className="font-mono text-sm font-bold chrome-text">HOURLY BOOKINGS</h4>
              <p className="font-mono text-xs text-white/70" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
                Pay-per-use studio access with tiered pricing
              </p>
            </div>

            <div className="text-center space-y-3">
              <div className="w-16 h-16 rounded-full bg-[#00ffff]/10 border-2 border-[#00ffff] flex items-center justify-center mx-auto">
                <span className="text-2xl font-bold neon-text-cyan">∞</span>
              </div>
              <h4 className="font-mono text-sm font-bold chrome-text">SUBSCRIPTIONS</h4>
              <p className="font-mono text-xs text-white/70" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
                Recurring monthly revenue from unlimited members
              </p>
            </div>

            <div className="text-center space-y-3">
              <div className="w-16 h-16 rounded-full bg-[#daa520]/10 border-2 border-[#daa520] flex items-center justify-center mx-auto">
                <span className="text-2xl font-bold neon-text-goldenrod">⬡</span>
              </div>
              <h4 className="font-mono text-sm font-bold chrome-text">PROJECT PACKAGES</h4>
              <p className="font-mono text-xs text-white/70" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
                Fixed-price deliverables for complete projects
              </p>
            </div>
          </div>
        </section>

        {/* CTA */}
        <div className="text-center space-y-4">
          <h3 className="font-mono text-xl font-bold chrome-text">READY TO START?</h3>
          <Button
            size="lg"
            className="font-mono font-bold uppercase tracking-wider text-white hover:opacity-90"
            style={{
              background: "#ffd700",
              boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
            }}
          >
            Book Your First Session
          </Button>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-border/30 mt-16 py-8 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <span className="font-mono text-xs text-white/70" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
              789 STUDIOS © 2025 • VIRTUAL PRODUCTION SYSTEM
            </span>
            <Link
              href="/"
              className="font-mono text-xs text-white/70 hover:text-[#ffd700] transition-colors"
              style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
            >
              ← BACK TO HOME
            </Link>
          </div>
        </div>
      </footer>
    </VirtualSoundstage>
  )
}
