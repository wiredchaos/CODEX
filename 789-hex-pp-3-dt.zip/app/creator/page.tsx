"use client"

import { VirtualSoundstage } from "@/components/virtual-soundstage"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"
import { Upload, Lock, Video, ImageIcon, FileText, BarChart3, Film } from "lucide-react"

export default function CreatorPage() {
  return (
    <VirtualSoundstage>
      {/* Top Navigation Bar */}
      <div className="border-b border-border/30 bg-black/40 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <Link href="/" className="font-mono text-xs font-bold neon-text-gold">
              789
            </Link>
            <nav className="hidden md:flex items-center gap-4">
              <Link
                href="/"
                className="font-mono text-xs text-muted-foreground hover:text-foreground transition-colors"
              >
                Studios
              </Link>
              <Link href="/creator" className="font-mono text-xs text-foreground font-bold">
                Creator Hub
              </Link>
              <Link
                href="/mint"
                className="font-mono text-xs text-muted-foreground hover:text-foreground transition-colors"
              >
                Mint Film
              </Link>
              <Link
                href="/spaces"
                className="font-mono text-xs text-muted-foreground hover:text-foreground transition-colors"
              >
                Spaces Network
              </Link>
            </nav>
          </div>
          <Button
            size="sm"
            className="font-mono font-bold uppercase tracking-wider text-white hover:opacity-90"
            style={{
              background: "#ffd700",
              boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
            }}
          >
            Connect Wallet
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12 space-y-12">
        {/* Hero Header */}
        <header className="text-center space-y-4">
          <h1
            className="text-3xl md:text-5xl font-bold chrome-text"
            style={{ textShadow: "0 0 20px rgba(0, 255, 255, 0.6)" }}
          >
            CREATOR HUB
          </h1>
          <p
            className="font-mono text-sm md:text-base text-white/90 max-w-2xl mx-auto"
            style={{ textShadow: "0 0 10px rgba(0, 255, 255, 0.3)" }}
          >
            Multi-Platform Content Publishing • Token-Gated Access • Blockchain Verified • Web3 Creator Tools
          </p>
        </header>

        {/* Main Content Area */}
        <Tabs defaultValue="publish" className="w-full">
          <TabsList className="grid w-full grid-cols-4 glass-panel">
            <TabsTrigger value="publish" className="font-mono text-xs text-white data-[state=active]:text-[#ffd700]">
              Publish
            </TabsTrigger>
            <TabsTrigger value="content" className="font-mono text-xs text-white data-[state=active]:text-[#ffd700]">
              My Content
            </TabsTrigger>
            <TabsTrigger value="analytics" className="font-mono text-xs text-white data-[state=active]:text-[#ffd700]">
              Analytics
            </TabsTrigger>
            <TabsTrigger value="token-gate" className="font-mono text-xs text-white data-[state=active]:text-[#ffd700]">
              Token Gate
            </TabsTrigger>
          </TabsList>

          {/* Publish Tab */}
          <TabsContent value="publish" className="space-y-6">
            <Card className="glass-panel border-[#ffd700]/20 p-6 space-y-6">
              <div className="space-y-2">
                <h2
                  className="font-mono text-xl font-bold neon-text-gold"
                  style={{ textShadow: "0 0 15px rgba(255, 215, 0, 0.8)" }}
                >
                  MULTI-PLATFORM PUBLISHER
                </h2>
                <p className="font-mono text-xs text-white/80" style={{ textShadow: "0 0 8px rgba(0, 255, 255, 0.3)" }}>
                  Post to YouTube, X, Instagram, TikTok, and LinkedIn simultaneously
                </p>
              </div>

              <div className="glass-panel-enhanced rounded-lg p-4 border border-[#daa520]/30 bg-[#daa520]/5">
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <Film className="w-8 h-8 text-[#daa520]" />
                    <div>
                      <h3
                        className="font-mono text-sm font-bold text-white"
                        style={{ textShadow: "0 0 10px rgba(255, 215, 0, 0.5)" }}
                      >
                        Got a film? Mint it as an NFT
                      </h3>
                      <p
                        className="font-mono text-xs text-white/70"
                        style={{ textShadow: "0 0 8px rgba(255, 215, 0, 0.3)" }}
                      >
                        Earn 90% revenue, set your own pricing, token-gate access
                      </p>
                    </div>
                  </div>
                  <Button
                    className="font-mono font-bold uppercase tracking-wider text-white hover:opacity-90 shrink-0"
                    style={{
                      background: "#daa520",
                      boxShadow: "0 0 20px rgba(218, 165, 32, 0.5)",
                    }}
                    asChild
                  >
                    <Link href="/mint">Mint Film</Link>
                  </Button>
                </div>
              </div>

              {/* Content Type Selector */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <button className="glass-panel p-4 rounded-lg border border-[#00ffff]/30 hover:border-[#00ffff] transition-colors flex flex-col items-center gap-2 group">
                  <Video className="w-8 h-8 text-[#00ffff] group-hover:drop-shadow-[0_0_10px_rgba(0,255,255,0.8)]" />
                  <span
                    className="font-mono text-xs text-white"
                    style={{ textShadow: "0 0 8px rgba(0, 255, 255, 0.4)" }}
                  >
                    Video
                  </span>
                </button>
                <button className="glass-panel p-4 rounded-lg border border-[#ffd700]/30 hover:border-[#ffd700] transition-colors flex flex-col items-center gap-2 group">
                  <ImageIcon className="w-8 h-8 text-[#ffd700] group-hover:drop-shadow-[0_0_10px_rgba(255,215,0,0.8)]" />
                  <span
                    className="font-mono text-xs text-white"
                    style={{ textShadow: "0 0 8px rgba(0, 255, 255, 0.4)" }}
                  >
                    Image
                  </span>
                </button>
                <button className="glass-panel p-4 rounded-lg border border-[#daa520]/30 hover:border-[#daa520] transition-colors flex flex-col items-center gap-2 group">
                  <FileText className="w-8 h-8 text-[#daa520] group-hover:drop-shadow-[0_0_10px_rgba(218,165,32,0.8)]" />
                  <span
                    className="font-mono text-xs text-white"
                    style={{ textShadow: "0 0 8px rgba(0, 255, 255, 0.4)" }}
                  >
                    Text
                  </span>
                </button>
                <button className="glass-panel p-4 rounded-lg border border-[#00ffff]/30 hover:border-[#00ffff] transition-colors flex flex-col items-center gap-2 group">
                  <Upload className="w-8 h-8 text-[#00ffff] group-hover:drop-shadow-[0_0_10px_rgba(0,255,255,0.8)]" />
                  <span
                    className="font-mono text-xs text-white"
                    style={{ textShadow: "0 0 8px rgba(0, 255, 255, 0.4)" }}
                  >
                    Upload
                  </span>
                </button>
              </div>

              {/* Platform Selector */}
              <div className="space-y-3">
                <label
                  className="font-mono text-xs text-white font-semibold"
                  style={{ textShadow: "0 0 10px rgba(0, 255, 255, 0.4)" }}
                >
                  PUBLISH TO:
                </label>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                  {[
                    { name: "YouTube", color: "#ff0000", enabled: true },
                    { name: "X (Twitter)", color: "#1da1f2", enabled: true },
                    { name: "Instagram", color: "#e4405f", enabled: true },
                    { name: "TikTok", color: "#00f2ea", enabled: true },
                    { name: "LinkedIn", color: "#0077b5", enabled: true },
                  ].map((platform) => (
                    <label
                      key={platform.name}
                      className="glass-panel p-3 rounded-lg border border-border/30 hover:border-[#ffd700]/50 cursor-pointer transition-colors flex items-center gap-2"
                    >
                      <input type="checkbox" className="w-4 h-4" defaultChecked={platform.enabled} />
                      <span
                        className="font-mono text-xs text-white"
                        style={{ textShadow: "0 0 8px rgba(0, 255, 255, 0.3)" }}
                      >
                        {platform.name}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Content Input */}
              <div className="space-y-3">
                <label
                  className="font-mono text-xs text-white font-semibold"
                  style={{ textShadow: "0 0 10px rgba(0, 255, 255, 0.4)" }}
                >
                  CONTENT:
                </label>
                <textarea
                  className="w-full h-32 glass-panel rounded-lg p-4 font-mono text-sm text-white placeholder:text-white/40 border border-border/30 focus:border-[#ffd700]/50 focus:outline-none resize-none"
                  placeholder="Write your post content here..."
                />
              </div>

              {/* Token-Gate Option */}
              <div className="glass-panel-enhanced rounded-lg p-4 border border-[#ffd700]/20 flex items-start gap-3">
                <Lock className="w-5 h-5 text-[#ffd700] mt-1 flex-shrink-0" />
                <div className="flex-1 space-y-2">
                  <div className="flex items-center gap-2">
                    <input type="checkbox" id="token-gate" className="w-4 h-4" />
                    <label
                      htmlFor="token-gate"
                      className="font-mono text-sm font-bold text-[#ffd700]"
                      style={{ textShadow: "0 0 12px rgba(255, 215, 0, 0.6)" }}
                    >
                      Token-Gate This Content
                    </label>
                  </div>
                  <p
                    className="font-mono text-xs text-white/70"
                    style={{ textShadow: "0 0 8px rgba(0, 255, 255, 0.25)" }}
                  >
                    Require NFT or token ownership to access this content. Supports ERC-721, ERC-1155, and SPL tokens.
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3">
                <Button
                  size="lg"
                  className="flex-1 font-mono font-bold uppercase tracking-wider text-white hover:opacity-90"
                  style={{
                    background: "#ffd700",
                    boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
                  }}
                >
                  Publish Now
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="font-mono font-bold uppercase tracking-wider border-[#00ffff] hover:bg-[#00ffff]/10 bg-transparent text-[#00ffff]"
                >
                  Schedule
                </Button>
              </div>
            </Card>
          </TabsContent>

          {/* My Content Tab */}
          <TabsContent value="content" className="space-y-6">
            <div className="grid gap-4">
              {[1, 2, 3].map((item) => (
                <Card
                  key={item}
                  className="glass-panel border-border/30 p-6 hover:border-[#ffd700]/30 transition-colors"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-24 h-24 rounded bg-muted/20 flex items-center justify-center">
                      <Video className="w-10 h-10 text-muted-foreground" />
                    </div>
                    <div className="flex-1 space-y-2">
                      <h3
                        className="font-mono text-sm font-bold text-white"
                        style={{ textShadow: "0 0 10px rgba(0, 255, 255, 0.4)" }}
                      >
                        Sample Content Post {item}
                      </h3>
                      <p
                        className="font-mono text-xs text-white/60"
                        style={{ textShadow: "0 0 8px rgba(0, 255, 255, 0.2)" }}
                      >
                        Published to 5 platforms • 12,543 views • Token-gated
                      </p>
                      <div className="flex gap-2 pt-2">
                        <span className="px-2 py-1 rounded-full bg-[#00ffff]/10 border border-[#00ffff]/30 font-mono text-xs text-[#00ffff]">
                          YouTube
                        </span>
                        <span className="px-2 py-1 rounded-full bg-[#ffd700]/10 border border-[#ffd700]/30 font-mono text-xs text-[#ffd700]">
                          X
                        </span>
                        <span className="px-2 py-1 rounded-full bg-[#daa520]/10 border border-[#daa520]/30 font-mono text-xs text-[#daa520]">
                          Instagram
                        </span>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid md:grid-cols-3 gap-4">
              {[
                { label: "Total Views", value: "125.4K", color: "#00ffff" },
                { label: "Engagement", value: "8.2%", color: "#ffd700" },
                { label: "Token-Gated", value: "42", color: "#daa520" },
              ].map((stat) => (
                <Card key={stat.label} className="glass-panel border-border/30 p-6 text-center space-y-2">
                  <BarChart3
                    className="w-8 h-8 mx-auto"
                    style={{
                      color: stat.color,
                      filter: `drop-shadow(0 0 10px ${stat.color}80)`,
                    }}
                  />
                  <div className="font-mono text-2xl font-bold" style={{ color: stat.color }}>
                    {stat.value}
                  </div>
                  <div
                    className="font-mono text-xs text-white/70"
                    style={{ textShadow: "0 0 8px rgba(0, 255, 255, 0.25)" }}
                  >
                    {stat.label}
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Token Gate Tab */}
          <TabsContent value="token-gate" className="space-y-6">
            <Card className="glass-panel border-[#ffd700]/20 p-6 space-y-6">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Lock className="w-6 h-6 text-[#ffd700]" />
                  <h2
                    className="font-mono text-xl font-bold neon-text-gold"
                    style={{ textShadow: "0 0 15px rgba(255, 215, 0, 0.8)" }}
                  >
                    TOKEN-GATED ACCESS
                  </h2>
                </div>
                <p
                  className="font-mono text-xs text-white/70"
                  style={{ textShadow: "0 0 8px rgba(0, 255, 255, 0.25)" }}
                >
                  Control access to your content with NFT or token requirements
                </p>
              </div>

              <div className="space-y-4">
                <div className="glass-panel-enhanced rounded-lg p-4 space-y-3">
                  <label
                    className="font-mono text-xs font-bold text-[#00ffff]"
                    style={{ textShadow: "0 0 12px rgba(0, 255, 255, 0.6)" }}
                  >
                    BLOCKCHAIN
                  </label>
                  <select className="w-full glass-panel rounded p-3 font-mono text-sm text-white border border-border/30 focus:border-[#00ffff]/50 focus:outline-none bg-black/60">
                    <option className="bg-black text-white">Ethereum</option>
                    <option className="bg-black text-white">Solana</option>
                    <option className="bg-black text-white">Polygon</option>
                    <option className="bg-black text-white">Base</option>
                  </select>
                </div>

                <div className="glass-panel-enhanced rounded-lg p-4 space-y-3">
                  <label
                    className="font-mono text-xs font-bold text-[#00ffff]"
                    style={{ textShadow: "0 0 12px rgba(0, 255, 255, 0.6)" }}
                  >
                    TOKEN CONTRACT ADDRESS
                  </label>
                  <input
                    type="text"
                    className="w-full glass-panel rounded p-3 font-mono text-sm text-white placeholder:text-white/40 border border-border/30 focus:border-[#00ffff]/50 focus:outline-none bg-black/60"
                    placeholder="0x..."
                  />
                </div>

                <div className="glass-panel-enhanced rounded-lg p-4 space-y-3">
                  <label
                    className="font-mono text-xs font-bold text-[#00ffff]"
                    style={{ textShadow: "0 0 12px rgba(0, 255, 255, 0.6)" }}
                  >
                    MINIMUM BALANCE
                  </label>
                  <input
                    type="number"
                    className="w-full glass-panel rounded p-3 font-mono text-sm text-white placeholder:text-white/40 border border-border/30 focus:border-[#00ffff]/50 focus:outline-none bg-black/60"
                    placeholder="1"
                  />
                </div>
              </div>

              <Button
                size="lg"
                className="w-full font-mono font-bold uppercase tracking-wider text-white hover:opacity-90"
                style={{
                  background: "#ffd700",
                  boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
                }}
              >
                Save Access Rules
              </Button>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Platform Features */}
        <section className="grid md:grid-cols-3 gap-6">
          <Card className="glass-panel border-[#00ffff]/20 p-6 space-y-3">
            <div className="w-12 h-12 rounded-full bg-[#00ffff]/10 border border-[#00ffff]/30 flex items-center justify-center">
              <Upload className="w-6 h-6 text-[#00ffff]" />
            </div>
            <h3 className="font-mono text-lg font-bold neon-text-cyan">Multi-Platform Publishing</h3>
            <p className="font-mono text-xs text-white/70" style={{ textShadow: "0 0 8px rgba(0, 255, 255, 0.25)" }}>
              Post to YouTube, X, Instagram, TikTok, and LinkedIn from one interface
            </p>
          </Card>

          <Card className="glass-panel border-[#ffd700]/20 p-6 space-y-3">
            <div className="w-12 h-12 rounded-full bg-[#ffd700]/10 border border-[#ffd700]/30 flex items-center justify-center">
              <Lock className="w-6 h-6 text-[#ffd700]" />
            </div>
            <h3 className="font-mono text-lg font-bold neon-text-gold">Token-Gated Content</h3>
            <p className="font-mono text-xs text-white/70" style={{ textShadow: "0 0 8px rgba(0, 255, 255, 0.25)" }}>
              Require NFT or token ownership for exclusive content access
            </p>
          </Card>

          <Card className="glass-panel border-[#daa520]/20 p-6 space-y-3">
            <div className="w-12 h-12 rounded-full bg-[#daa520]/10 border border-[#daa520]/30 flex items-center justify-center">
              <BarChart3 className="w-6 h-6 text-[#daa520]" />
            </div>
            <h3 className="font-mono text-lg font-bold neon-text-goldenrod">Blockchain Verified</h3>
            <p className="font-mono text-xs text-white/70" style={{ textShadow: "0 0 8px rgba(0, 255, 255, 0.25)" }}>
              All content is cryptographically signed and verifiable on-chain
            </p>
          </Card>
        </section>
      </div>
    </VirtualSoundstage>
  )
}
