import { type NextRequest, NextResponse } from "next/server"
import { getLurkyClient } from "@/lib/lurky/client"

export const runtime = "edge"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)

    const params = {
      min_followers: searchParams.get("min_followers") ? Number(searchParams.get("min_followers")) : undefined,
      max_followers: searchParams.get("max_followers") ? Number(searchParams.get("max_followers")) : undefined,
      page: searchParams.get("page") ? Number(searchParams.get("page")) : 0,
      limit: searchParams.get("limit") ? Number(searchParams.get("limit")) : 20,
    }

    const client = getLurkyClient()
    const data = await client.listSpeakers(params)

    if (!data || !Array.isArray(data.speakers)) {
      console.error("[Lurky Speakers API] Invalid data format:", data)
      return NextResponse.json(
        {
          speakers: [],
          page: params.page,
          limit: params.limit,
        },
        { status: 200 },
      )
    }

    const normalized = {
      speakers: data.speakers.map((speaker) => ({
        twitterId: speaker.twitterId,
        handle: speaker.handle,
        name: speaker.name,
        image: speaker.image,
        description: speaker.description,
        verified: speaker.verified,
        verifiedType: speaker.verifiedType,
        followersCount: speaker.followersCount,
      })),
      page: data.page,
      limit: data.limit,
    }

    return NextResponse.json(normalized)
  } catch (error: any) {
    if (error.message.includes("Rate limit")) {
      return NextResponse.json({ error: "API cool-down in effect. Please try again in a moment." }, { status: 429 })
    }

    console.error("[Lurky Speakers API Error]", error)
    return NextResponse.json({ error: error.message || "Failed to fetch speakers data" }, { status: 500 })
  }
}
