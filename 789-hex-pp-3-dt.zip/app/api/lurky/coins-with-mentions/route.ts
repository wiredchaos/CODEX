import { type NextRequest, NextResponse } from "next/server"
import { getLurkyClient } from "@/lib/lurky/client"

export const runtime = "edge"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)

    const params = {
      chains: searchParams.get("chains") || undefined,
      min_rank: searchParams.get("min_rank") ? Number(searchParams.get("min_rank")) : undefined,
      max_rank: searchParams.get("max_rank") ? Number(searchParams.get("max_rank")) : undefined,
      sort_by: searchParams.get("sort_by") || "market_cap",
      sort_dir: searchParams.get("sort_dir") || "desc",
      page: searchParams.get("page") ? Number(searchParams.get("page")) : 0,
      limit: searchParams.get("limit") ? Number(searchParams.get("limit")) : 10,
      mentioned: true,
    }

    const client = getLurkyClient()
    const data = await client.listCoinsWithMentions(params)

    const normalized = {
      coins: data.coins.map((coin) => ({
        id: coin.id,
        symbol: coin.symbol,
        name: coin.name,
        chain: coin.chain,
        image: coin.image,
        link: coin.link,
        externalLink: coin.externalLink,
        priceUsd: coin.priceUsd,
        priceChange24h: coin.priceChange24h,
        marketCap: coin.marketCap,
        marketCapRank: coin.marketCapRank,
        categories: coin.categories,
        mentions: {
          bullish: coin.mentions.bullish,
          neutral: coin.mentions.neutral,
          bearish: coin.mentions.bearish,
          total: coin.mentions.total,
          overallSentiment: coin.mentions.overallSentiment,
        },
      })),
      page: data.page,
      limit: data.limit,
    }

    return NextResponse.json(normalized)
  } catch (error: any) {
    if (error.message.includes("Rate limit")) {
      return NextResponse.json({ error: "API cool-down in effect. Please try again in a moment." }, { status: 429 })
    }

    console.error("[Lurky Coins API Error]", error)
    return NextResponse.json({ error: error.message || "Failed to fetch coin sentiment data" }, { status: 500 })
  }
}
