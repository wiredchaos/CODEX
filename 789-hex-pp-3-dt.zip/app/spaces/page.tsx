"use client"

import { VirtualSoundstage } from "@/components/virtual-soundstage"
import { SpacesScheduleGrid } from "@/components/spaces-schedule-grid"
import { DoginalDogsBanner } from "@/components/doginal-dogs-banner"
import { BroadcastTicker } from "@/components/broadcast-ticker"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BackButton } from "@/components/ui/back-button"

export default function SpacesPage() {
  return (
    <VirtualSoundstage>
      {/* Top Navigation Bar */}
      <div className="border-b border-border/30 bg-black/40 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <BackButton fallbackHref="/" />
            <Link href="/" className="font-mono text-xs font-bold neon-text-gold">
              789
            </Link>
            <nav className="hidden md:flex items-center gap-4">
              <Link
                href="/"
                className="font-mono text-xs text-white/70 hover:text-white transition-colors"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
              >
                Studios
              </Link>
              <Link href="/spaces" className="font-mono text-xs text-white font-bold">
                Spaces Network
              </Link>
            </nav>
          </div>
          <a
            href="https://doginaldogs.com"
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-1.5 rounded font-mono text-xs font-bold uppercase tracking-wider border-2 border-[#ffd700] hover:bg-[#ffd700]/10 transition-colors text-[#ffd700]"
          >
            Join the Doginal Dogs
          </a>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12 space-y-12">
        {/* Header */}
        <header className="text-center space-y-4">
          <h1 className="text-3xl md:text-5xl font-bold chrome-text">CRYPTO SPACES NETWORK</h1>
          <p
            className="font-mono text-sm md:text-base text-white/80 max-w-2xl mx-auto"
            style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
          >
            24/7 Live Streaming • 15 Unique Hosts • Powered by Doginal Dogs
          </p>
        </header>

        {/* Doginal Dogs Banner */}
        <DoginalDogsBanner />

        {/* Broadcast Ticker */}
        <BroadcastTicker />

        {/* Spaces Schedule */}
        <section className="space-y-6">
          <div className="text-center">
            <h2 className="font-mono text-2xl font-bold chrome-text mb-2">DAILY SCHEDULE</h2>
            <p className="font-mono text-xs text-white/70" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
              The engines of culture • Daily presence • Trust-based community
            </p>
          </div>
          <SpacesScheduleGrid />
        </section>

        {/* About Section */}
        <section className="glass-panel rounded-lg p-8 md:p-12 border-2 border-[#ffd700]/20 space-y-4">
          <h3 className="font-mono text-xl md:text-2xl font-bold neon-text-gold text-center">
            POWERED BY DOGINAL DOGS
          </h3>
          <p
            className="font-mono text-sm text-white/80 text-center max-w-2xl mx-auto"
            style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}
          >
            The Crypto Spaces Network is a 24-hour streaming schedule featuring 15 unique hosts building web3 culture
            through daily presence, trust, and community. Every host brings their unique perspective powered by $DOGE.
          </p>
          <div className="flex justify-center pt-4">
            <Button
              size="lg"
              variant="outline"
              className="font-mono font-bold uppercase tracking-wider border-[#ffd700] hover:bg-[#ffd700]/10 bg-transparent text-[#ffd700]"
              asChild
            >
              <a href="https://doginaldogs.com" target="_blank" rel="noopener noreferrer">
                Learn More
              </a>
            </Button>
          </div>
        </section>
      </div>

      {/* Footer */}
      <footer className="border-t border-border/30 mt-16 py-8 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="font-mono text-xs text-white/70" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
                789 STUDIOS © 2025 • CRYPTO SPACES NETWORK
              </span>
            </div>
            <div className="font-mono text-xs text-white/80" style={{ textShadow: "0 0 8px rgba(255,215,0,0.4)" }}>
              POWERED BY DOGINAL DOGS • FUELED BY $DOGE
            </div>
          </div>
        </div>
      </footer>
    </VirtualSoundstage>
  )
}
