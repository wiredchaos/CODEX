"use client"

import { useEffect, useState } from "react"
import { Loader2, BadgeCheck, AlertCircle } from "lucide-react"
import Image from "next/image"
import { Button } from "@/components/ui/button"

interface Speaker {
  twitterId: string
  handle: string
  name: string
  image?: string
  verified?: boolean
  verifiedType?: "blue" | "business" | null
  followersCount?: number
}

export function SpeakersList() {
  const [speakers, setSpeakers] = useState<Speaker[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const abortController = new AbortController()

    fetchSpeakers(abortController.signal)

    return () => {
      abortController.abort()
    }
  }, [])

  async function fetchSpeakers(signal?: AbortSignal) {
    setLoading(true)
    setError(null)
    try {
      const response = await fetch(`/api/lurky/speakers?limit=10`, {
        signal,
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const data = await response.json()

      if (data && Array.isArray(data.speakers)) {
        setSpeakers(data.speakers)
      } else {
        console.error("Invalid speakers data format:", data)
        setSpeakers([])
        setError("Invalid data format received")
      }
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") {
        return
      }
      console.error("Failed to fetch speakers:", error)
      setSpeakers([])
      setError(error instanceof Error ? error.message : "Failed to load speakers")
    } finally {
      setLoading(false)
    }
  }

  function handleRetry() {
    fetchSpeakers()
  }

  return (
    <div
      className="rounded-lg border border-purple-500/20 bg-black/90 p-6 backdrop-blur-xl"
      style={{ boxShadow: "0 0 30px rgba(128,0,128,0.1)" }}
    >
      <h3 className="mb-4 text-lg font-bold text-white" style={{ textShadow: "0 0 15px rgba(138,43,226,0.5)" }}>
        Speakers to Watch
      </h3>

      {loading ? (
        <div className="flex h-40 items-center justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-purple-400" />
        </div>
      ) : error ? (
        <div className="flex h-40 flex-col items-center justify-center gap-3 text-center">
          <AlertCircle className="h-8 w-8 text-red-400" />
          <p className="text-sm text-white/60" style={{ textShadow: "0 0 10px rgba(255,0,0,0.3)" }}>
            {error}
          </p>
          <Button
            onClick={handleRetry}
            variant="outline"
            size="sm"
            className="border-purple-500/30 bg-purple-500/10 text-white hover:bg-purple-500/20"
          >
            Retry
          </Button>
        </div>
      ) : speakers.length === 0 ? (
        <div className="flex h-40 items-center justify-center">
          <p className="text-sm text-white/60" style={{ textShadow: "0 0 10px rgba(138,43,226,0.3)" }}>
            No speakers available
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {speakers.map((speaker) => (
            <div
              key={speaker.twitterId}
              className="flex items-center gap-3 rounded-lg border border-white/10 bg-white/5 p-3"
            >
              {speaker.image ? (
                <Image
                  src={speaker.image || "/placeholder.svg"}
                  alt={speaker.name}
                  width={40}
                  height={40}
                  className="rounded-full"
                />
              ) : (
                <div className="h-10 w-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500" />
              )}
              <div className="flex-1">
                <div className="flex items-center gap-1">
                  <span className="font-semibold text-white" style={{ textShadow: "0 0 10px rgba(138,43,226,0.5)" }}>
                    {speaker.name}
                  </span>
                  {speaker.verified && <BadgeCheck className="h-4 w-4 text-blue-400" />}
                </div>
                <div className="flex items-center gap-2 text-xs text-white/60">
                  <span style={{ textShadow: "0 0 5px rgba(0,255,255,0.3)" }}>@{speaker.handle}</span>
                  {speaker.followersCount && (
                    <>
                      <span>•</span>
                      <span>{(speaker.followersCount / 1000).toFixed(1)}K followers</span>
                    </>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
