"use client"

import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"

interface FiltersSidebarProps {
  filters: {
    dateRange: string
    states: string[]
    categories: string[]
    minParticipants: number
  }
  onFiltersChange: (filters: any) => void
}

export function FiltersSidebar({ filters, onFiltersChange }: FiltersSidebarProps) {
  const dateRanges = [
    { value: "24h", label: "Last 24 Hours" },
    { value: "7d", label: "Last 7 Days" },
    { value: "30d", label: "Last 30 Days" },
  ]

  const states = ["live", "scheduled", "analyzed"]
  const categories = ["AI", "NFTs", "Meme Coins", "Stablecoins", "DeFi", "Macro"]

  return (
    <div
      className="rounded-lg border border-cyan-500/20 bg-black/90 p-6 backdrop-blur-xl"
      style={{ boxShadow: "0 0 30px rgba(0,255,255,0.1)" }}
    >
      <h3 className="mb-6 text-xl font-bold text-white" style={{ textShadow: "0 0 15px rgba(0,255,255,0.5)" }}>
        Filters
      </h3>

      {/* Date Range */}
      <div className="mb-6">
        <Label className="mb-3 block text-white" style={{ textShadow: "0 0 10px rgba(218,165,32,0.5)" }}>
          Date Range
        </Label>
        <div className="space-y-2">
          {dateRanges.map((range) => (
            <button
              key={range.value}
              onClick={() => onFiltersChange({ ...filters, dateRange: range.value })}
              className={`w-full rounded px-4 py-2 text-left text-sm transition-all ${
                filters.dateRange === range.value
                  ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/50"
                  : "bg-white/5 text-white/70 hover:bg-white/10"
              }`}
              style={{
                textShadow: filters.dateRange === range.value ? "0 0 10px rgba(0,255,255,0.5)" : "none",
              }}
            >
              {range.label}
            </button>
          ))}
        </div>
      </div>

      {/* States */}
      <div className="mb-6">
        <Label className="mb-3 block text-white" style={{ textShadow: "0 0 10px rgba(218,165,32,0.5)" }}>
          State
        </Label>
        <div className="space-y-2">
          {states.map((state) => (
            <label key={state} className="flex cursor-pointer items-center gap-2">
              <input
                type="checkbox"
                checked={filters.states.includes(state)}
                onChange={(e) => {
                  const newStates = e.target.checked
                    ? [...filters.states, state]
                    : filters.states.filter((s) => s !== state)
                  onFiltersChange({ ...filters, states: newStates })
                }}
                className="h-4 w-4 rounded border-cyan-500/30 bg-black/50 text-cyan-400"
              />
              <span className="text-sm capitalize text-white/80" style={{ textShadow: "0 0 5px rgba(0,255,255,0.3)" }}>
                {state}
              </span>
            </label>
          ))}
        </div>
      </div>

      {/* Categories */}
      <div className="mb-6">
        <Label className="mb-3 block text-white" style={{ textShadow: "0 0 10px rgba(218,165,32,0.5)" }}>
          Categories
        </Label>
        <div className="space-y-2">
          {categories.map((category) => (
            <label key={category} className="flex cursor-pointer items-center gap-2">
              <input
                type="checkbox"
                checked={filters.categories.includes(category)}
                onChange={(e) => {
                  const newCategories = e.target.checked
                    ? [...filters.categories, category]
                    : filters.categories.filter((c) => c !== category)
                  onFiltersChange({ ...filters, categories: newCategories })
                }}
                className="h-4 w-4 rounded border-cyan-500/30 bg-black/50 text-cyan-400"
              />
              <span className="text-sm text-white/80" style={{ textShadow: "0 0 5px rgba(0,255,255,0.3)" }}>
                {category}
              </span>
            </label>
          ))}
        </div>
      </div>

      {/* Min Participants */}
      <div className="mb-6">
        <Label className="mb-3 block text-white" style={{ textShadow: "0 0 10px rgba(218,165,32,0.5)" }}>
          Min Participants: {filters.minParticipants}
        </Label>
        <Slider
          value={[filters.minParticipants]}
          onValueChange={([value]) => onFiltersChange({ ...filters, minParticipants: value })}
          max={1000}
          step={10}
          className="w-full"
        />
      </div>

      {/* Actions */}
      <div className="flex gap-2">
        <Button
          onClick={() => {}}
          className="flex-1 bg-gradient-to-r from-cyan-500 to-cyan-600 text-white hover:from-cyan-600 hover:to-cyan-700"
          style={{ textShadow: "0 0 10px rgba(0,255,255,0.5)" }}
        >
          Apply
        </Button>
        <Button
          onClick={() =>
            onFiltersChange({
              dateRange: "24h",
              states: ["analyzed"],
              categories: [],
              minParticipants: 0,
            })
          }
          variant="outline"
          className="border-white/20 text-white hover:bg-white/10"
        >
          Reset
        </Button>
      </div>
    </div>
  )
}
