"use client"

import { AlertCircle, Key, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export function ApiKeySetup() {
  return (
    <div className="mx-auto max-w-3xl rounded-lg border border-yellow-500/30 bg-black/60 p-8 backdrop-blur-md">
      <div className="mb-6 flex items-center gap-3">
        <div className="rounded-full bg-yellow-500/20 p-3">
          <Key className="h-8 w-8 text-yellow-500" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-white" style={{ textShadow: "0 0 15px rgba(255,215,0,0.5)" }}>
            Lurky API Key Required
          </h2>
          <p className="text-sm text-white/60">Configure your API key to access Spaces Intelligence</p>
        </div>
      </div>

      <div className="mb-6 rounded-lg bg-white/5 p-4">
        <div className="mb-3 flex items-start gap-2">
          <AlertCircle className="mt-0.5 h-5 w-5 text-cyan-400" />
          <div>
            <p className="mb-2 text-white" style={{ textShadow: "0 0 8px rgba(0,255,255,0.3)" }}>
              The Lurky.app API key is missing from your environment variables.
            </p>
            <p className="text-sm text-white/70">
              To use the Spaces Intelligence Panel, you need to add your Lurky API key to access real-time X Spaces
              data, coin sentiment tracking, and speaker analytics.
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <h3 className="mb-2 text-lg font-semibold text-white" style={{ textShadow: "0 0 10px rgba(0,255,255,0.3)" }}>
            Setup Instructions
          </h3>
          <ol className="space-y-3 text-sm text-white/80">
            <li className="flex gap-3">
              <span
                className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-cyan-500/20 text-xs font-bold text-cyan-400"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.5)" }}
              >
                1
              </span>
              <span>
                Get your API key from{" "}
                <a
                  href="https://lurky.app"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-cyan-400 underline hover:text-cyan-300"
                  style={{ textShadow: "0 0 8px rgba(0,255,255,0.5)" }}
                >
                  Lurky.app
                  <ExternalLink className="h-3 w-3" />
                </a>
              </span>
            </li>
            <li className="flex gap-3">
              <span
                className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-cyan-500/20 text-xs font-bold text-cyan-400"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.5)" }}
              >
                2
              </span>
              <span>Add the API key to your Vercel project environment variables</span>
            </li>
            <li className="flex gap-3">
              <span
                className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-cyan-500/20 text-xs font-bold text-cyan-400"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.5)" }}
              >
                3
              </span>
              <div className="flex-1">
                <p className="mb-2">In your Vercel project settings, add:</p>
                <div className="rounded bg-black/40 p-3 font-mono text-xs text-cyan-400">
                  <div>LURKY_API_KEY=your_api_key_here</div>
                  <div className="text-white/40">LURKY_API_BASE_URL=https://api.lurky.app</div>
                  <div className="text-white/40">LURKY_MAX_RPM=50</div>
                </div>
              </div>
            </li>
            <li className="flex gap-3">
              <span
                className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-cyan-500/20 text-xs font-bold text-cyan-400"
                style={{ textShadow: "0 0 8px rgba(0,255,255,0.5)" }}
              >
                4
              </span>
              <span>Redeploy your application for the changes to take effect</span>
            </li>
          </ol>
        </div>

        <div className="flex gap-3 pt-4">
          <Button
            asChild
            className="bg-yellow-500 text-white hover:bg-yellow-400"
            style={{ textShadow: "0 0 10px rgba(0,0,0,0.5)" }}
          >
            <a href="https://lurky.app" target="_blank" rel="noopener noreferrer">
              Get API Key
            </a>
          </Button>
          <Button
            asChild
            variant="outline"
            className="border-cyan-500/30 text-white hover:bg-cyan-500/10 bg-transparent"
          >
            <Link href="/">Return Home</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
