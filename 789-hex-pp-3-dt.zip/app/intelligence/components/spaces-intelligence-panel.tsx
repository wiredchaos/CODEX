"use client"

import { useState } from "react"
import { FiltersSidebar } from "./filters-sidebar"
import { SpacesTable } from "./spaces-table"
import { CoinSentimentPanel } from "./coin-sentiment-panel"
import { SpeakersList } from "./speakers-list"

export function SpacesIntelligencePanel() {
  const [filters, setFilters] = useState({
    dateRange: "24h",
    states: ["analyzed"],
    categories: [] as string[],
    minParticipants: 0,
  })

  return (
    <div className="grid gap-6 lg:grid-cols-12">
      {/* Left: Filters */}
      <div className="lg:col-span-3">
        <FiltersSidebar filters={filters} onFiltersChange={setFilters} />
      </div>

      {/* Center: Spaces Table */}
      <div className="lg:col-span-6">
        <SpacesTable filters={filters} />
      </div>

      {/* Right: Sentiment + Speakers */}
      <div className="space-y-6 lg:col-span-3">
        <CoinSentimentPanel />
        <SpeakersList />
      </div>
    </div>
  )
}
