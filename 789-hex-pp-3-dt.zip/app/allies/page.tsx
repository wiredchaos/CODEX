"use client"

import { VirtualSoundstage } from "@/components/virtual-soundstage"
import { NavigationalAvatar } from "@/components/navigational-avatar"
import { GlobalDisclaimer } from "@/components/global-disclaimer"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { ExternalLink, Users } from "lucide-react"
import Image from "next/image"
import { BackButton } from "@/components/ui/back-button"

const ALLIES = [
  {
    name: "NEURO META X",
    tagline: "AI-powered content creation and Web3 journalism by NEURO.",
    description:
      "NEURO META X is NEURO's flagship platform for AI-assisted content creation, Web3 journalism, and decoding the hidden layers of technology, metaphysics, and media. Bridging Web2 to Web3 through Wired Chaos reporting, NeuroMetaX empowers creators with AI ghostwriting, translation services, and next-gen storytelling tools.",
    pillars: ["AI Content Creation", "Web3 Journalism", "Wired Chaos", "Meta Analysis"],
    focus: ["AI ghostwriting", "Web2 → Web3 translation", "Neural networks", "Media history"],
    links: { website: "", x: "https://x.com/neurometax" },
    color: "#00ffff",
    image: "/allies/neuro-meta-x.jpg",
  },
  {
    name: "TYPE / TYPE MEDIA",
    tagline: "The engine behind a growing movement of creators, culture, and innovation.",
    description:
      "TYPE is a next-generation brand ecosystem built around creators, culture, and scalable innovation. Rooted in community and designed for growth, TYPE spans content, products, and experiences under a unified brand architecture.",
    pillars: ["TYPE Media", "TYPE DAO", "TYPE Shop", "TYPE Growth"],
    focus: ["Creator-centric media", "DAO participation", "Merch & collectibles", "Growth strategy"],
    links: { website: "https://typebrand.xyz", x: "https://x.com/typemedia" },
    color: "#00ffff",
    image: "/allies/type-media-logo.jpg",
  },
  {
    name: "Beanies on Business",
    tagline: "A community of builders, creators, and innovators.",
    description:
      "Beanies on Business is a community and DAO ecosystem centered on builders, creators, and innovators working together under a shared vision. The group emphasizes long-term construction over hype.",
    pillars: ["20 Founding Members", "250+ Community", "Crypto Sauce Show", "Beanie DAO"],
    focus: ["Community-led business", "Web3 culture", "Educational spaces", "Builder coordination"],
    links: { website: "https://beaniesonbusiness.com", x: "https://x.com/BeanieDaoX" },
    color: "#ffd700",
    image: "/allies/beanies-community.jpg",
  },
  {
    name: "BowMafia / BowDAO",
    tagline: "BowMafiaDAO — a community-powered Doginal Dogs collective.",
    description:
      "BowMafia represents the BowDAO wing of the Doginal Dogs ecosystem, operating as a DAO around a distinct 'bow' aesthetic and cultural identity within the broader Doginal Dogs landscape.",
    pillars: ["BowMafia Identity", "Silk & Bows", "DAO Coordination", "Cross-DAO Participation"],
    focus: ["BowMafia-branded Doginals", "Collective decision-making", "Ecosystem collaborations"],
    links: { website: "https://bowmafia.xyz", x: "https://x.com/BowDAOMeta" },
    color: "#ff69b4",
    image: "/allies/bow-mafia-aesthetic.jpg",
  },
  {
    name: "Dogwarts DAO",
    tagline: "Where paws meet potions and tails wag through magic and mischief.",
    description:
      "Dogwarts is a whimsical digital universe and DAO designed for dog lovers, fantasy fans, and blockchain adventurers. The School of Woofcraft and Wizardry functions as a themed Web3 world.",
    pillars: ["The Order of 86", "Magical Packs", "Market Place", "Schedule Events"],
    focus: ["Gamified Web3 experience", "Community events", "Themed collectibles", "Lore-rich universe"],
    links: { website: "https://dogwartsdao.com", x: "" },
    color: "#9945ff",
    image: "/allies/dogwarts-dao-logo.jpg",
  },
  {
    name: "OTF Media",
    tagline: "Building culture, loyalty, and legacy across all communities.",
    description:
      "OTF Media (Only The Family) is described as a 'community of communities,' focused on culture, loyalty, and legacy with strong presence in the Doginal Dogs ecosystem and X Spaces.",
    pillars: ["Only The Family", "Media Amplification", "Cross-Community Support", "Loyalty Culture"],
    focus: ["Presence amplification", "Brand signals", "Community loyalty", "Family values"],
    links: { website: "", x: "https://x.com/OTFMediaX" },
    color: "#ff4500",
    image: "/allies/otf-media-branding.jpg",
  },
  {
    name: "Yellow DAO",
    tagline: "Discover the yellow revolution. Not your regular DAO.",
    description:
      "Yellow DAO (YDAO) is a Doginal Dogs–centric DAO branded as 'the #1 Doginal Dogs DAO,' blending bold yellow aesthetics with culture, collectibles, and community-driven treasury management.",
    pillars: ["#1 Doginal Dogs DAO", "Treasury Wallet", "Reserve Assets", "Community Assets"],
    focus: ["DAO operations", "Lifestyle branding", "Ecosystem partnerships", "Maximum bark per byte"],
    links: { website: "https://yellowdao.xyz", x: "" },
    color: "#ffff00",
    image: "/allies/yellow-dao-logo.jpg",
  },
  {
    name: "KennelDAO / Kennel Market",
    tagline: "Creating a revenue-generating DAO in the Doginal Dogs ecosystem.",
    description:
      "KennelDAO (KDAO) is positioned as a DAO dedicated to establishing a revenue-generating structure within the Doginal Dogs ecosystem, closely tied to Kennel Market.",
    pillars: ["Revenue DAO", "Kennel Market", "Doginal Assets", "Yield Mechanics"],
    focus: ["Revenue-oriented mechanics", "Marketplace liquidity", "Community coordination", "Sustainability"],
    links: { website: "https://kennel.market", x: "https://x.com/KennelDAO" },
    color: "#32cd32",
    image: "/allies/kennel-dao-market.jpg",
  },
]

export default function AlliesPage() {
  return (
    <VirtualSoundstage>
      <NavigationalAvatar />

      {/* Navigation */}
      <div className="border-b border-border/30 bg-black/40 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <BackButton fallbackHref="/" />
            <Link
              href="/"
              className="font-mono text-xs font-bold"
              style={{ color: "#ffd700", textShadow: "0 0 10px rgba(255, 215, 0, 0.5)" }}
            >
              789
            </Link>
            <nav className="hidden md:flex items-center gap-4">
              <Link href="/" className="font-mono text-xs text-white/70 hover:text-white transition-colors">
                Home
              </Link>
              <Link href="/crew" className="font-mono text-xs text-white/70 hover:text-white transition-colors">
                Crew
              </Link>
              <Link href="/allies" className="font-mono text-xs text-white font-bold">
                Allies & DAOs
              </Link>
            </nav>
          </div>
        </div>
      </div>

      {/* Hero */}
      <section className="py-16 px-4 text-center">
        <Badge
          className="mb-4 bg-goldenrod/20 text-goldenrod border-goldenrod/50 font-mono"
          style={{ textShadow: "0 0 10px rgba(218, 165, 32, 0.5)" }}
        >
          <Users className="w-3 h-3 mr-1" />
          789 ECOSYSTEM
        </Badge>
        <h1
          className="text-4xl md:text-6xl font-bold text-white mb-4"
          style={{ textShadow: "0 0 20px rgba(255, 255, 255, 0.3)" }}
        >
          ALLIES & DAOs
        </h1>
        <p
          className="font-mono text-lg text-white/80 max-w-2xl mx-auto"
          style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.2)" }}
        >
          The 789 Studios ecosystem connects with leading DAOs, communities, and builders across the Doginal Dogs
          universe and beyond.
        </p>
      </section>

      {/* Allies Grid */}
      <section className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 gap-6">
          {ALLIES.map((ally, index) => (
            <Card
              key={index}
              className="glass-panel-enhanced border-2 p-6 hover:scale-[1.02] transition-transform"
              style={{ borderColor: `${ally.color}40` }}
            >
              <div className="space-y-4">
                <div className="relative w-full h-48 rounded-lg overflow-hidden mb-4">
                  <Image
                    src={ally.image || "/placeholder.svg"}
                    alt={`${ally.name} logo`}
                    fill
                    className="object-cover"
                    style={{ filter: `drop-shadow(0 0 20px ${ally.color}80)` }}
                  />
                </div>

                <div className="flex items-start justify-between">
                  <div>
                    <h3
                      className="font-mono text-xl font-bold mb-1"
                      style={{ color: ally.color, textShadow: `0 0 15px ${ally.color}80` }}
                    >
                      {ally.name}
                    </h3>
                    <p
                      className="font-mono text-xs text-white/70 italic"
                      style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
                    >
                      "{ally.tagline}"
                    </p>
                  </div>
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ background: ally.color, boxShadow: `0 0 15px ${ally.color}` }}
                  />
                </div>

                <p
                  className="font-mono text-sm text-white/80 leading-relaxed"
                  style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
                >
                  {ally.description}
                </p>

                {/* Pillars */}
                <div className="flex flex-wrap gap-2">
                  {ally.pillars.map((pillar, i) => (
                    <Badge
                      key={i}
                      className="font-mono text-xs"
                      style={{
                        background: `${ally.color}15`,
                        color: ally.color,
                        borderColor: `${ally.color}40`,
                        textShadow: `0 0 5px ${ally.color}80`,
                      }}
                    >
                      {pillar}
                    </Badge>
                  ))}
                </div>

                {/* Links */}
                <div className="flex gap-3 pt-2">
                  {ally.links.website && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="font-mono text-xs bg-transparent"
                      style={{
                        borderColor: ally.color,
                        color: ally.color,
                        textShadow: `0 0 5px ${ally.color}80`,
                      }}
                      asChild
                    >
                      <a href={ally.links.website} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="w-3 h-3 mr-1" />
                        Website
                      </a>
                    </Button>
                  )}
                  {ally.links.x && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="font-mono text-xs border-cyan/50 text-white bg-transparent"
                      style={{ textShadow: "0 0 5px rgba(0, 255, 255, 0.5)" }}
                      asChild
                    >
                      <a href={ally.links.x} target="_blank" rel="noopener noreferrer">
                        Follow on X
                      </a>
                    </Button>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </section>

      {/* Disclaimer Banner */}
      <section className="max-w-4xl mx-auto px-4 py-8">
        <Card className="glass-panel border border-goldenrod/30 p-6">
          <p
            className="font-mono text-xs text-white/60 text-center leading-relaxed"
            style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
          >
            <span className="text-goldenrod font-bold">Note:</span> All descriptions above are based on publicly
            available information from the projects' own sites and social channels. 789 Studios does not claim ownership
            of, or formal partnership with, any third-party brands, DAOs, or protocols listed here unless explicitly
            stated elsewhere. All trademarks, graphics, and intellectual property remain the exclusive property of their
            respective owners.
          </p>
        </Card>
      </section>

      <GlobalDisclaimer />
    </VirtualSoundstage>
  )
}
