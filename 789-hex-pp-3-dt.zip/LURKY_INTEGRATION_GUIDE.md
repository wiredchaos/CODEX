# Lurky.app Integration Guide for 789 Studios

## Overview
This integration connects 789 Studios with Lurky.app's X Spaces Intelligence API, providing real-time analytics on crypto conversations, coin sentiment tracking, and speaker insights.

## Setup Instructions

### 1. Get Lurky API Key
1. Visit [lurky.app](https://lurky.app)
2. Sign up or log in
3. Navigate to API settings
4. Generate your API key

### 2. Configure Environment Variables
Copy `.env.example` to `.env.local`:
```bash
cp .env.example .env.local
```

Add your Lurky API key:
```
LURKY_API_KEY="your_api_key_here"
```

### 3. Rate Limits
- **Free Tier**: 50 requests per minute (default)
- **Developer Tier**: 200 requests per minute
- **Enterprise Tier**: Custom limits

Adjust `LURKY_MAX_RPM` in `.env.local` based on your tier.

## Features

### Spaces Intelligence Panel (`/intelligence`)
- **Filters**: Date range, state, categories, participant count
- **Spaces Table**: View all analyzed X Spaces with summaries
- **Coin Sentiment Radar**: Real-time crypto mentions with bullish/bearish/neutral sentiment
- **Speaker Network**: Top speakers and hosts in the crypto space

### API Routes
All Lurky calls go through internal proxy routes for security:
- `/api/lurky/spaces` - List and filter X Spaces
- `/api/lurky/coins-with-mentions` - Coin sentiment data
- `/api/lurky/speakers` - Speaker analytics

### Client Architecture
```
lib/lurky/client.ts          → Core API client with rate limiting
app/api/lurky/*               → Next.js API routes (proxy layer)
app/intelligence/             → Front-end dashboard
  ├── page.tsx                → Main intelligence page
  └── components/             → UI components
      ├── filters-sidebar.tsx
      ├── spaces-table.tsx
      ├── coin-sentiment-panel.tsx
      └── speakers-list.tsx
```

## Usage Examples

### Fetching Spaces
```typescript
// Client-side
const response = await fetch('/api/lurky/spaces?state=analyzed&limit=20')
const data = await response.json()
```

### Getting Coin Sentiment
```typescript
const response = await fetch('/api/lurky/coins-with-mentions?sort_by=mentions&limit=10')
const { coins } = await response.json()
```

## Navigation
The Spaces Intelligence panel is accessible from:
- Control Deck → "Spaces Intelligence" button (with AI badge)
- Direct URL: `/intelligence`

## Troubleshooting

### Rate Limit Errors
If you see "API cool-down" messages:
1. Check your current tier limits
2. Adjust `LURKY_MAX_RPM` to match your tier
3. Implement client-side caching with SWR for better performance

### Missing API Key
Error: "LURKY_API_KEY environment variable is required"
- Ensure `.env.local` exists with valid `LURKY_API_KEY`
- Restart your Next.js dev server after adding env vars

### CORS Issues
All API calls go through `/api/lurky/*` routes - never call Lurky directly from the browser.

## Performance Optimization
- Server-side rate limiting prevents exceeding Lurky limits
- Edge runtime for low-latency API responses
- Pagination support for large datasets
- Shareable filter URLs via query parameters

## Security
- API key stored server-side only
- Never exposed to client
- All requests authenticated via `x-lurky-api-key` header
- Soft rate limiting prevents abuse

## Support
For Lurky API issues, contact: [lurky.app/support](https://lurky.app/support)
For 789 Studios integration help: @789studiosonx
```

```tsx file="" isHidden
