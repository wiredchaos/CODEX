"use client"

import { Button } from "@/components/ui/button"
import { Play, Info } from "lucide-react"
import Link from "next/link"
import type { OTTShow } from "@/types/ott"

interface HeroBannerProps {
  show: OTTShow
}

export function HeroBanner({ show }: HeroBannerProps) {
  return (
    <div className="relative h-[70vh] min-h-[500px] w-full overflow-hidden">
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${show.heroArt})`,
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 h-full flex items-center px-4 md:px-12 max-w-7xl mx-auto">
        <div className="max-w-2xl space-y-6">
          {/* Tags */}
          <div className="flex flex-wrap gap-2">
            {show.tags.map((tag) => (
              <span
                key={tag}
                className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-black/50 backdrop-blur-sm border border-white/20"
                style={{ color: "#00ffff", textShadow: "0 0 10px rgba(0, 255, 255, 0.5)" }}
              >
                {tag}
              </span>
            ))}
          </div>

          {/* Title */}
          <h1
            className="text-4xl md:text-6xl font-bold text-white"
            style={{ textShadow: "0 0 20px rgba(255, 215, 0, 0.5)" }}
          >
            {show.title}
          </h1>

          {/* Description */}
          <p
            className="text-lg md:text-xl text-white/90 max-w-xl"
            style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.3)" }}
          >
            {show.description}
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-wrap gap-4 pt-4">
            <Button
              size="lg"
              className="font-mono font-bold uppercase tracking-wider hover:scale-105 transition-all"
              style={{
                background: "#ffd700",
                color: "#000",
                boxShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
              }}
              asChild
            >
              <Link href={`/watch/${show.episodes[0]?.id || show.id}`}>
                <Play className="w-5 h-5 mr-2" />
                Play
              </Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="font-mono font-bold uppercase tracking-wider border-white/50 bg-black/50 backdrop-blur-sm hover:bg-white/10 hover:scale-105 transition-all"
              style={{ color: "#fff", textShadow: "0 0 10px rgba(255, 255, 255, 0.5)" }}
              asChild
            >
              <Link href={`/title/${show.slug}`}>
                <Info className="w-5 h-5 mr-2" />
                More Info
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
