"use client"

import { Card } from "@/components/ui/card"
import Link from "next/link"
import type { OTTShow } from "@/types/ott"

interface ShowCardProps {
  show: OTTShow
  priority?: boolean
}

export function ShowCard({ show, priority = false }: ShowCardProps) {
  return (
    <Link href={`/title/${show.slug}`} className="block group">
      <Card className="relative overflow-hidden bg-black/40 border-white/10 hover:border-[#00ffff]/50 transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-[#00ffff]/20">
        {/* Thumbnail */}
        <div className="relative aspect-video overflow-hidden">
          <img
            src={show.thumbnail || "/placeholder.svg"}
            alt={show.title}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
            loading={priority ? "eager" : "lazy"}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
        </div>

        {/* Info */}
        <div className="p-4 space-y-2">
          <h3
            className="font-mono font-bold text-sm text-white line-clamp-1"
            style={{ textShadow: "0 0 8px rgba(255, 255, 255, 0.3)" }}
          >
            {show.title}
          </h3>
          <div className="flex flex-wrap gap-2">
            {show.genres.slice(0, 2).map((genre) => (
              <span
                key={genre}
                className="text-xs font-mono px-2 py-0.5 rounded bg-black/50 border border-white/20"
                style={{ color: "#00ffff", textShadow: "0 0 5px rgba(0, 255, 255, 0.3)" }}
              >
                {genre}
              </span>
            ))}
          </div>
        </div>
      </Card>
    </Link>
  )
}
