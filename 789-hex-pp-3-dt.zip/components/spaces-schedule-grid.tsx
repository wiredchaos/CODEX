"use client"

import { SPACES_SCHEDULE, getCurrentHost } from "@/lib/spaces-schedule"
import { getCrewColor } from "@/lib/crew-colors"
import { useEffect, useState } from "react"

export function SpacesScheduleGrid() {
  const [liveHost, setLiveHost] = useState<string | null>(null)

  useEffect(() => {
    const updateLiveHost = () => {
      const current = getCurrentHost()
      setLiveHost(current?.name || null)
    }

    updateLiveHost()
    const interval = setInterval(updateLiveHost, 60000)

    return () => clearInterval(interval)
  }, [])

  return (
    <section className="space-y-6">
      <div className="text-center space-y-3">
        <div className="flex items-center justify-center gap-2">
          <img
            src="https://primary.jwwb.nl/public/m/p/h/temp-mbsodlgfubdqwvlyhdbk/csn-white-no-bg-standard.png"
            alt="Crypto Spaces Network"
            className="h-8 object-contain"
          />
        </div>
        <h2 className="font-mono text-xl md:text-2xl font-bold text-white">24/7 CRYPTO SPACES NETWORK SCHEDULE</h2>
        <p className="font-mono text-sm text-white/80 max-w-2xl mx-auto">
          15 unique hosts broadcasting live spaces around the clock. Each crew member has their own signature color.
        </p>
        <div className="h-1 w-full max-w-3xl mx-auto bg-gradient-to-r from-transparent via-[#ffd700] to-transparent" />
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
        {SPACES_SCHEDULE.map((host) => {
          const isLive = host.name === liveHost
          const crewColor = getCrewColor(host.name)

          return (
            <a
              key={host.name}
              href={host.xUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="group relative studio-bay rounded-lg p-4 flex flex-col items-center gap-3 text-center hover:cursor-pointer"
              style={{
                borderColor: isLive ? crewColor.primary : `${crewColor.primary}40`,
              }}
            >
              {/* Live indicator */}
              {isLive && (
                <div className="absolute top-2 right-2 flex items-center gap-1">
                  <span
                    className="font-mono text-[10px] font-bold"
                    style={{
                      color: crewColor.primary,
                      textShadow: `0 0 10px ${crewColor.glow}`,
                    }}
                  >
                    LIVE
                  </span>
                  <div
                    className="w-2 h-2 rounded-full animate-pulse"
                    style={{
                      background: crewColor.primary,
                      boxShadow: `0 0 10px ${crewColor.glow}`,
                    }}
                  />
                </div>
              )}

              {/* Host avatar with crew color border */}
              <div
                className="relative w-16 h-16 rounded-full overflow-hidden border-2 transition-all duration-300"
                style={{
                  borderColor: isLive ? crewColor.primary : `${crewColor.primary}60`,
                  boxShadow: isLive ? `0 0 20px ${crewColor.glow}` : "none",
                }}
              >
                <img src={host.imageUrl || "/placeholder.svg"} alt={host.name} className="w-full h-full object-cover" />
                {/* Doginal Dog badge overlay */}
                <div className="absolute bottom-0 right-0 w-5 h-5 rounded-full bg-[#ffd700] border-2 border-black flex items-center justify-center">
                  <span className="text-[8px]">🐕</span>
                </div>
              </div>

              {/* Host info */}
              <div className="space-y-1">
                <h3
                  className="font-mono text-sm font-bold"
                  style={{
                    color: crewColor.primary,
                    textShadow: `0 0 10px ${crewColor.glow}`,
                  }}
                >
                  {host.name}
                </h3>
                <p className="font-mono text-xs text-white/90">{host.time}</p>
                <p className="font-mono text-[10px]" style={{ color: crewColor.primary, opacity: 0.8 }}>
                  {crewColor.name}
                </p>
              </div>
            </a>
          )
        })}
      </div>
    </section>
  )
}
