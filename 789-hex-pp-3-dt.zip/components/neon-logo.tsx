"use client"

import { useState, useEffect } from "react"

export function NeonLogo() {
  const [pulsePhase, setPulsePhase] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setPulsePhase((p) => (p + 1) % 360)
    }, 50)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="relative space-y-4">
      <div className="relative">
        <h1
          className="font-black text-5xl md:text-7xl lg:text-8xl text-center tracking-wider"
          style={{
            color: "#ffd700",
            textShadow: `
              0 0 10px rgba(255, 215, 0, 0.8),
              0 0 20px rgba(255, 215, 0, 0.6),
              0 0 40px rgba(255, 215, 0, 0.4),
              0 0 80px rgba(255, 215, 0, 0.2),
              0 5px 0 rgba(0, 0, 0, 0.5),
              0 10px 0 rgba(0, 0, 0, 0.3),
              0 15px 0 rgba(0, 0, 0, 0.2),
              0 20px 30px rgba(0, 0, 0, 0.8)
            `,
            WebkitTextStroke: "2px rgba(255, 215, 0, 0.3)",
            letterSpacing: "0.15em",
          }}
        >
          789 STUDIOS
        </h1>

        {/* Gold reflection effect */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: "linear-gradient(180deg, transparent 50%, rgba(255, 215, 0, 0.1) 100%)",
            transform: "scaleY(-1)",
            opacity: 0.3,
            filter: "blur(8px)",
          }}
        >
          <h1
            className="font-black text-5xl md:text-7xl lg:text-8xl text-center tracking-wider"
            style={{
              color: "#ffd700",
              letterSpacing: "0.15em",
            }}
          >
            789 STUDIOS
          </h1>
        </div>
      </div>

      <p className="text-center font-mono text-sm md:text-base tracking-widest" style={{ color: "#ffd700" }}>
        VIRTUAL PRODUCTION SYSTEM
      </p>
      <p className="text-center font-mono text-xs md:text-sm text-white/60">
        Professional Recording • Mixing • Mastering
      </p>
    </div>
  )
}
