"use client"

import { useEffect, useState } from "react"

const TICKER_MESSAGES = [
  "789 STUDIOS • VIRTUAL PRODUCTION SYSTEM • PROFESSIONAL RECORDING & MIXING",
  "BOOK STUDIO TIME • REMOTE COLLABORATION • PREMIUM PRODUCTION SERVICES",
  "NEW: UNLIMITED MEMBERSHIP • 24/7 STUDIO ACCESS • $2K/MONTH",
  "PRO ENGINEERS • SSL CONSOLE • REFERENCE-GRADE MONITORING",
  "PODCAST STUDIO • VIDEO PRODUCTION • CONTENT CREATION HUB",
  "JOIN THE 789 CREATOR NETWORK • APPLY TODAY",
]

export function BroadcastTicker() {
  const [currentIndex, setCurrentIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % TICKER_MESSAGES.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="broadcast-bar">
      <div className="scanline-overlay" />
      <div className="px-6 py-3 overflow-hidden">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 flex-shrink-0">
            <div className="led-indicator live" />
            <span className="font-mono text-xs font-bold neon-text-gold">BROADCAST</span>
          </div>
          <div className="font-mono text-xs tracking-wider text-white/80 animate-pulse">
            {TICKER_MESSAGES[currentIndex]}
          </div>
        </div>
      </div>
    </div>
  )
}
