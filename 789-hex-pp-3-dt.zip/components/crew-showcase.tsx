"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { getCrewColor } from "@/lib/crew-colors"
import { Radio } from "lucide-react"
import Link from "next/link"

const CORE_789_CREW = [
  {
    name: "VIBES",
    time: "7 PM",
    specialty: "Energy & Positivity",
    handle: "vibesmetax",
    avatar: "https://i.postimg.cc/k5hMbFBS/8.png",
    slug: "vibes",
  },
  {
    name: "NEURO",
    time: "1 AM",
    specialty: "Tech & Innovation",
    handle: "neurometax",
    avatar: "https://i.postimg.cc/0QMkdMw7/15.png",
    slug: "neuro",
  },
  {
    name: "GATOR",
    time: "9 PM",
    specialty: "Gaming",
    handle: "gatormetax",
    avatar: "https://i.postimg.cc/5tk9Cq6L/10.png",
    slug: "gator",
  },
  {
    name: "WOOKI",
    time: "8 PM",
    specialty: "Strategy",
    handle: "wookimeta",
    avatar: "https://i.postimg.cc/g0BcZqnR/9.png",
    slug: "wooki",
  },
  {
    name: "JEEP",
    time: "1 PM",
    specialty: "Hip-Hop Culture",
    handle: "jeepmeta",
    avatar: "https://i.postimg.cc/6Q16vLyp/5.png",
    slug: "jeep",
  },
  {
    name: "ARTSY",
    time: "2 AM",
    specialty: "Creative Direction",
    handle: "artsymeta",
    avatar: "https://i.postimg.cc/Y9GrfGWf/16.png",
    slug: "artsy",
  },
]

export function CrewShowcase() {
  return (
    <section className="space-y-8">
      <div className="text-center space-y-4">
        <h2 className="font-mono text-2xl md:text-4xl font-bold chrome-text">THE 789 CREW</h2>
        <p className="font-mono text-sm text-white/80 max-w-2xl mx-auto">
          The core 6 founders bringing culture, creativity, and community to web3
        </p>
        <Link
          href="https://x.com/789studiosonx"
          target="_blank"
          className="inline-flex items-center gap-2 font-mono text-sm text-cyan-400 hover:text-cyan-300 transition-colors"
        >
          Follow @789studiosonx on X →
        </Link>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {CORE_789_CREW.map((member) => {
          const crewColor = getCrewColor(member.name)

          return (
            <Link key={member.name} href={`/crew/${member.slug}`}>
              <Card
                className="glass-panel border-2 p-4 space-y-3 hover:scale-105 transition-all duration-300 cursor-pointer"
                style={{
                  borderColor: `${crewColor.primary}40`,
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = crewColor.primary
                  e.currentTarget.style.boxShadow = `0 0 20px ${crewColor.glow}`
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = `${crewColor.primary}40`
                  e.currentTarget.style.boxShadow = "none"
                }}
              >
                <div className="flex items-center justify-between">
                  <Badge
                    className="font-mono text-[10px] uppercase"
                    style={{
                      background: `${crewColor.primary}20`,
                      color: crewColor.primary,
                      borderColor: `${crewColor.primary}50`,
                    }}
                  >
                    <Radio className="w-2 h-2 mr-1" />
                    LIVE
                  </Badge>
                </div>

                <div
                  className="w-full aspect-square rounded-lg border-2 flex items-center justify-center overflow-hidden"
                  style={{
                    borderColor: crewColor.primary,
                    background: `${crewColor.primary}10`,
                    boxShadow: `inset 0 0 20px ${crewColor.glow}`,
                  }}
                >
                  <img
                    src={member.avatar || "/placeholder.svg"}
                    alt={member.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="space-y-1">
                  <div className="font-mono text-sm font-bold text-white">{member.name}</div>
                  <div className="font-mono text-[10px] text-white/60">{member.time}</div>
                  <div className="font-mono text-[10px] text-white/80">{member.specialty}</div>
                  <div className="font-mono text-[9px] text-white/50">@{member.handle}</div>
                </div>
              </Card>
            </Link>
          )
        })}
      </div>

      <div className="text-center">
        <Link
          href="/spaces"
          className="inline-block font-mono text-sm text-white/70 hover:text-white transition-colors border border-white/20 px-6 py-3 rounded-lg hover:border-white/40"
        >
          View Full Crypto Spaces Network Schedule (15 Hosts) →
        </Link>
      </div>
    </section>
  )
}
