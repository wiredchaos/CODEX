"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Play, Pause, Volume2, VolumeX, Maximize2, Film } from "lucide-react"

export function Film3DemoVideo() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(true)

  return (
    <Card className="glass-panel-enhanced border-2 border-cyan/30 overflow-hidden">
      {/* Video Header */}
      <div className="bg-black/60 backdrop-blur-sm p-4 border-b border-cyan/20">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-cyan/20 flex items-center justify-center">
              <Film className="w-5 h-5 text-cyan" style={{ filter: "drop-shadow(0 0 8px rgba(0, 255, 255, 0.6))" }} />
            </div>
            <div>
              <h3
                className="font-mono text-lg font-bold text-white"
                style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.5)" }}
              >
                Film3: The Future of Independent Cinema
              </h3>
              <p className="font-mono text-xs text-white/60" style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}>
                How blockchain, NFTs, and decentralized distribution empower filmmakers
              </p>
            </div>
          </div>
          <Badge
            className="bg-cyan/20 text-cyan border-cyan/50 font-mono"
            style={{ textShadow: "0 0 8px rgba(0, 255, 255, 0.5)" }}
          >
            FILM3 INTRO
          </Badge>
        </div>
      </div>

      {/* Video Player Container */}
      <div className="relative aspect-video bg-black">
        <iframe
          className="absolute top-0 left-0 w-full h-full"
          src="https://www.youtube.com/embed/72N7Uq6wAQ0"
          title="FLINCH - Official Film3 Documentary"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          referrerPolicy="strict-origin-when-cross-origin"
          allowFullScreen
        />
      </div>

      {/* Video Controls */}
      <div className="absolute bottom-0 left-0 right-0 bg-black/80 backdrop-blur-sm p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setIsPlaying(!isPlaying)}
              className="text-white hover:text-cyan"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setIsMuted(!isMuted)}
              className="text-white hover:text-cyan"
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </Button>
            <span
              className="font-mono text-xs text-white/60"
              style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.2)" }}
            >
              0:00 / 2:34
            </span>
          </div>
          <Button size="sm" variant="ghost" className="text-white hover:text-cyan">
            <Maximize2 className="w-4 h-4" />
          </Button>
        </div>

        {/* Progress Bar */}
        <div className="mt-3 h-1 bg-white/20 rounded-full overflow-hidden">
          <div
            className="h-full bg-cyan transition-all duration-300"
            style={{
              width: isPlaying ? "100%" : "0%",
              transition: "width 150s linear",
              boxShadow: "0 0 10px rgba(0, 255, 255, 0.8)",
            }}
          />
        </div>
      </div>

      {/* Video Footer */}
      <div className="bg-black/60 backdrop-blur-sm p-4 border-t border-cyan/20">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <p className="font-mono text-xs text-white/80" style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.3)" }}>
            Watch the complete FLINCH documentary to understand how the first NFT film franchise revolutionized
            independent cinema through Web3 technology and community ownership.
          </p>
        </div>
      </div>
    </Card>
  )
}
