"use client"

import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

interface BackButtonProps {
  fallbackHref?: string
  className?: string
  variant?: "default" | "ghost" | "outline"
}

export function BackButton({ fallbackHref = "/", className = "", variant = "ghost" }: BackButtonProps) {
  const router = useRouter()

  const handleBack = () => {
    // Check if there's history to go back to
    if (window.history.length > 1) {
      router.back()
    } else {
      // Fallback to provided href if no history
      router.push(fallbackHref)
    }
  }

  return (
    <Button
      variant={variant}
      size="sm"
      onClick={handleBack}
      className={`font-mono text-xs text-white/70 hover:text-white transition-colors ${className}`}
      style={{ textShadow: "0 0 10px rgba(255, 255, 255, 0.3)" }}
    >
      <ArrowLeft className="w-4 h-4 mr-2" />
      Back
    </Button>
  )
}
