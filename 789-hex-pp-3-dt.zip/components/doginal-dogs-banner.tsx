"use client"

export function DoginalDogsBanner() {
  return (
    <a
      href="https://doginaldogs.com"
      target="_blank"
      rel="noopener noreferrer"
      className="block group hover:scale-105 transition-transform duration-300"
    >
      <div className="glass-panel rounded-lg p-6 text-center space-y-3 border-2 border-[#ffd700]/20 hover:border-[#ffd700]/60 transition-colors">
        <img
          src="https://primary.jwwb.nl/public/m/p/h/temp-mbsodlgfubdqwvlyhdbk/dd-logo-white-standard.png"
          alt="Doginal Dogs - The engines of culture that power web3"
          className="h-16 mx-auto object-contain"
        />
        <p
          className="font-mono text-xs text-white/80 max-w-md mx-auto"
          style={{ textShadow: "0 0 8px rgba(255,215,0,0.3)" }}
        >
          The official engines of culture that power web3 through trust, community, and daily presence.
        </p>
        <div className="flex items-center justify-center gap-2">
          <span className="font-mono text-xs font-bold neon-text-gold">JOIN THE PACK</span>
          <svg
            className="w-4 h-4 text-[#ffd700] group-hover:translate-x-1 transition-transform"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
          </svg>
        </div>
      </div>
    </a>
  )
}
