"use client"

import type { ReactNode } from "react"

interface VirtualSoundstageProps {
  children: ReactNode
}

export function VirtualSoundstage({ children }: VirtualSoundstageProps) {
  return (
    <div className="min-h-screen relative bg-black">
      {/* Scanline effect */}
      <div className="scanline-overlay" />

      {/* Subtle ambient light effects only - pure black base */}
      <div className="fixed inset-0 pointer-events-none opacity-10">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-[#00ffff] blur-[200px] rounded-full" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-[#ffd700] blur-[200px] rounded-full" />
      </div>

      {/* Content */}
      <div className="relative z-10">{children}</div>
    </div>
  )
}
