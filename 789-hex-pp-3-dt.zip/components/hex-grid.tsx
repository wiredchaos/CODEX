"use client"

import { HexTile } from "./hex-tile"
import { STUDIO_SECTIONS, type CrewType } from "@/lib/crew-config"

interface HexGridProps {
  onSelect?: (sectionId: string) => void
}

const crewAssignments: CrewType[] = ["alpha", "beta", "gamma", "delta", "omega"]

export function HexGrid({ onSelect }: HexGridProps) {
  return (
    <div className="relative flex flex-wrap justify-center items-center gap-4 py-8">
      {STUDIO_SECTIONS.map((section, index) => (
        <HexTile
          key={section.id}
          crew={crewAssignments[index % crewAssignments.length]}
          size="lg"
          label={section.name}
          icon={<span className="text-3xl">{section.icon}</span>}
          onClick={() => onSelect?.(section.id)}
          animated
          interactive
          className="m-2"
        />
      ))}
    </div>
  )
}
