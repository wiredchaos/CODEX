"use client"

import { useState } from "react"
import { Play, Pause, Volume2, VolumeX } from "lucide-react"

export function PlatformHeroVideo() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(true)

  return (
    <div className="relative rounded-lg overflow-hidden border border-[#ffd700]/30 bg-black">
      {/* Placeholder video area */}
      <div className="relative aspect-video bg-gradient-to-br from-black via-[#0a0a0a] to-black">
        {/* Video will go here - using placeholder for now */}
        <video className="w-full h-full object-cover" poster="/789-studios-virtual-production-platform.jpg" muted={isMuted} loop>
          <source src="/placeholder-video.mp4" type="video/mp4" />
        </video>

        {/* Animated overlay grid */}
        <div className="absolute inset-0 cyber-grid opacity-20 pointer-events-none" />

        {/* Video controls overlay */}
        <div className="absolute inset-0 flex items-center justify-center bg-black/40 group hover:bg-black/20 transition-all">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="w-20 h-20 rounded-full bg-[#ffd700]/20 backdrop-blur-sm border-2 border-[#ffd700] flex items-center justify-center hover:bg-[#ffd700]/40 transition-all hover:scale-110"
            style={{ boxShadow: "0 0 30px rgba(255, 215, 0, 0.5)" }}
          >
            {isPlaying ? (
              <Pause className="w-10 h-10 text-[#ffd700]" fill="#ffd700" />
            ) : (
              <Play className="w-10 h-10 text-[#ffd700] ml-1" fill="#ffd700" />
            )}
          </button>
        </div>

        {/* Bottom controls */}
        <div className="absolute bottom-4 right-4 flex items-center gap-2">
          <button
            onClick={() => setIsMuted(!isMuted)}
            className="w-10 h-10 rounded-full bg-black/60 backdrop-blur-sm border border-[#00ffff]/30 flex items-center justify-center hover:border-[#00ffff] transition-all"
          >
            {isMuted ? <VolumeX className="w-5 h-5 text-white" /> : <Volume2 className="w-5 h-5 text-[#00ffff]" />}
          </button>
        </div>

        {/* Top label */}
        <div className="absolute top-4 left-4">
          <div className="flex items-center gap-2 bg-black/80 backdrop-blur-sm border border-[#ffd700]/30 rounded px-3 py-1.5">
            <div className="w-2 h-2 bg-[#00ffff] rounded-full animate-pulse" />
            <span className="font-mono text-xs text-white font-bold">PLATFORM OVERVIEW</span>
          </div>
        </div>
      </div>

      {/* Video info */}
      <div className="p-4 bg-black/90 backdrop-blur-sm border-t border-[#ffd700]/20">
        <h3 className="font-mono text-sm font-bold text-white mb-1">789 Studios Platform Tour</h3>
        <p className="font-mono text-xs text-white/70">
          Discover how creators publish to 5+ platforms, token-gate content, and record in professional studios
        </p>
      </div>
    </div>
  )
}
