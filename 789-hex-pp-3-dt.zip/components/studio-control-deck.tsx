"use client"

import { useState } from "react"

interface StudioTab {
  id: string
  label: string
  badge?: string
  href?: string
}

const STUDIO_TABS: StudioTab[] = [
  { id: "services", label: "Services" },
  { id: "browse", label: "Browse Content", href: "/browse" },
  { id: "live-booth", label: "Live Booth", badge: "LIVE" },
  { id: "booking", label: "Booking" },
  { id: "crew", label: "789 Crew", href: "/crew" },
  { id: "allies", label: "Allies & DAOs", href: "/allies" },
  { id: "intelligence", label: "Spaces Intelligence", href: "/intelligence", badge: "AI" },
  { id: "mint", label: "Mint Film", href: "/mint" },
  { id: "film3", label: "Film3", href: "/film3" },
  { id: "spaces", label: "Spaces Network", href: "/spaces" },
  { id: "about-ott", label: "About OTT", href: "/about-ott" },
]

interface StudioControlDeckProps {
  activeTab?: string
  onTabChange?: (tabId: string) => void
}

export function StudioControlDeck({ activeTab = "services", onTabChange }: StudioControlDeckProps) {
  const [currentTab, setCurrentTab] = useState(activeTab)

  const handleTabClick = (tabId: string, href?: string) => {
    setCurrentTab(tabId)
    onTabChange?.(tabId)
    if (href) {
      window.location.href = href
    }
  }

  return (
    <div className="control-deck rounded-lg overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-border/50">
        <div className="flex items-center gap-3">
          <div className="led-indicator live" />
          <h1
            className="font-mono text-sm font-bold tracking-wider text-white"
            style={{ textShadow: "0 0 10px rgba(218, 165, 32, 0.5)" }}
          >
            CONTROL DECK: 789 MAIN STUDIO
          </h1>
        </div>
        <div className="flex items-center gap-2">
          <span className="font-mono text-xs text-white/70" style={{ textShadow: "0 0 5px rgba(255, 255, 255, 0.3)" }}>
            SYS ONLINE
          </span>
          <div className="w-2 h-2 bg-[#00ffff] rounded-full" style={{ boxShadow: "0 0 10px #00ffff" }} />
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex flex-wrap gap-2 p-4 bg-black/50">
        {STUDIO_TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => handleTabClick(tab.id, tab.href)}
            className={`control-button rounded font-mono text-xs px-3 py-2 transition-all ${
              currentTab === tab.id
                ? "bg-goldenrod/20 text-goldenrod border border-goldenrod/50"
                : "bg-black/40 text-white/80 border border-white/20 hover:border-cyan/50 hover:text-cyan"
            }`}
            style={{
              textShadow:
                currentTab === tab.id ? "0 0 10px rgba(218, 165, 32, 0.5)" : "0 0 5px rgba(255, 255, 255, 0.3)",
            }}
          >
            {tab.badge && (
              <span className="inline-flex items-center gap-1 mr-2">
                <span className="w-1.5 h-1.5 bg-[#00ffff] rounded-full animate-pulse" />
                <span className="text-[10px] text-[#00ffff]">{tab.badge}</span>
              </span>
            )}
            {tab.label}
          </button>
        ))}
      </div>
    </div>
  )
}
