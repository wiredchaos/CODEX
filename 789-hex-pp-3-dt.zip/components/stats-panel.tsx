"use client"

import { CREW_COLORS, type CrewType } from "@/lib/crew-config"

interface StatItem {
  label: string
  value: string | number
  crew: CrewType
}

const mockStats: StatItem[] = [
  { label: "HEX Nodes", value: "789", crew: "alpha" },
  { label: "Creators", value: "33.3K", crew: "beta" },
  { label: "Worlds Built", value: "156", crew: "gamma" },
  { label: "NPCs Active", value: "42", crew: "delta" },
]

export function StatsPanel() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {mockStats.map((stat) => {
        const colors = CREW_COLORS[stat.crew]
        return (
          <div
            key={stat.label}
            className="relative p-4 rounded-xl bg-card/50 backdrop-blur border border-muted overflow-hidden group hover:border-transparent transition-all duration-300"
            style={{
              boxShadow: `inset 0 0 30px ${colors.primary}10`,
            }}
          >
            {/* Glow effect on hover */}
            <div
              className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
              style={{
                boxShadow: `inset 0 0 30px ${colors.primary}30, 0 0 20px ${colors.primary}20`,
              }}
            />

            <div className="relative">
              <div className="text-3xl font-mono font-black" style={{ color: colors.primary }}>
                {stat.value}
              </div>
              <div className="text-sm text-muted-foreground font-mono uppercase tracking-wider">{stat.label}</div>
            </div>
          </div>
        )
      })}
    </div>
  )
}
