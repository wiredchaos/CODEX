"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"
import { STUDIO_SECTIONS, CREW_COLORS } from "@/lib/crew-config"

interface NavPanelProps {
  activeSection?: string
  onSelect: (sectionId: string) => void
}

export function NavPanel({ activeSection, onSelect }: NavPanelProps) {
  const [hoveredItem, setHoveredItem] = useState<string | null>(null)

  const crewOrder = ["alpha", "beta", "gamma", "delta", "omega"] as const

  return (
    <nav className="fixed left-4 top-1/2 -translate-y-1/2 z-50">
      <div className="flex flex-col gap-3 p-3 rounded-xl bg-background/40 backdrop-blur-xl border border-[#00ffff]/20">
        {STUDIO_SECTIONS.map((section, index) => {
          const crew = crewOrder[index % crewOrder.length]
          const colors = CREW_COLORS[crew]
          const isActive = activeSection === section.id
          const isHovered = hoveredItem === section.id

          return (
            <button
              key={section.id}
              onClick={() => onSelect(section.id)}
              onMouseEnter={() => setHoveredItem(section.id)}
              onMouseLeave={() => setHoveredItem(null)}
              className={cn(
                "group relative flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-300",
                "hover:bg-muted/50",
                isActive && "bg-muted/80",
              )}
              style={{
                boxShadow: isActive || isHovered ? colors.glow : "none",
                borderLeft: `3px solid ${isActive ? colors.primary : "transparent"}`,
              }}
            >
              <span
                className="text-xl transition-transform duration-300 group-hover:scale-125"
                style={{
                  filter: isActive || isHovered ? `drop-shadow(${colors.glow})` : "none",
                }}
              >
                {section.icon}
              </span>
              <div className="flex flex-col items-start">
                <span
                  className="text-sm font-mono font-bold uppercase tracking-wider"
                  style={{ color: isActive || isHovered ? colors.primary : "inherit" }}
                >
                  {section.name}
                </span>
                <span className="text-xs text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity">
                  {section.description}
                </span>
              </div>
            </button>
          )
        })}
      </div>
    </nav>
  )
}
