# 🎬 789 STUDIOS OTT STREAMING INTERFACE - ROKU-STYLE BUILD

**PASTE THIS INTO V0 TO RECREATE THE COMPLETE OTT STREAMING EXPERIENCE**

---

## 🎯 PROJECT OVERVIEW

Build a Netflix/Roku-style OTT streaming web application for **789 Studios** using Next.js 14 App Router, TypeScript, and Tailwind CSS. This is a standalone streaming interface with horizontal content rails, featured hero banners, show detail pages, and video watch pages.

---

## 🎨 VISUAL DESIGN SYSTEM

### Color Palette
- **Background**: Pure black (#000000) and deep charcoal (#0a0a0a)
- **Primary Accent**: Gold (#ffd700) with golden glow
- **Secondary Accent**: Cyan (#00ffff) with cyan glow
- **Text**: White (#ffffff) with subtle glows for visibility
- **Glass Cards**: Black/40 with white/10 borders

### Typography
- **Section Titles**: Font-mono, bold, uppercase, tracking-wider, gold glow
- **Show Titles**: Font-mono, bold, white with white glow
- **Body Text**: Font-sans, white/80 with subtle cyan glow
- **Tags/Badges**: Font-mono, text-xs, cyan with cyan glow

### Visual Effects
- **Text Shadow**: `0 0 15px rgba(255, 215, 0, 0.5)` for gold headers
- **Text Shadow**: `0 0 8px rgba(0, 255, 255, 0.3)` for cyan tags
- **Box Shadow**: `0 0 20px rgba(255, 215, 0, 0.5)` for gold buttons
- **Hover Effects**: Scale(1.05) with smooth transitions
- **Glass Morphism**: `bg-black/40 backdrop-blur-sm border border-white/10`

---

## 📁 FILE STRUCTURE

```
app/
├── page.tsx                    # OTT Homepage with hero + rails
├── browse/page.tsx            # Grid view of all content
├── title/[slug]/page.tsx      # Show detail page
├── watch/[id]/page.tsx        # Video player page
└── channel/[slug]/page.tsx    # Channel hub page

components/ott/
├── hero-banner.tsx            # Featured show hero component
├── content-rail.tsx           # Horizontal scrolling rail
├── show-card.tsx              # Individual show card
├── episode-list.tsx           # Episode listing component
└── video-player.tsx           # Video player wrapper

data/
└── ott-content.ts             # Shows, channels, episodes data

types/
└── ott.ts                     # TypeScript interfaces
```

---

## 🏗️ DATA STRUCTURE

### Types (types/ott.ts)

```typescript
export interface OTTChannel {
  id: string
  name: string
  slug: string
  description: string
  logo?: string
  heroArt?: string
  color: string
}

export interface OTTEpisode {
  id: string
  showId: string
  title: string
  slug: string
  description: string
  duration: number // seconds
  thumbnail: string
  videoUrl: string
  episodeNumber?: number
  seasonNumber?: number
}

export interface OTTShow {
  id: string
  title: string
  slug: string
  channelId: string
  description: string
  tags: string[]
  genres: string[]
  heroArt: string
  thumbnail: string
  trailerId?: string
  episodes: OTTEpisode[]
  year?: number
  rating?: string
}
```

### Sample Content Data

**Channels:**
- 789 Originals (gold)
- Film3 Network (gold)
- Crypto Spaces Live (cyan)

**Shows:**
- NEURO META X: Decoded (AI/Web3/Philosophy documentary)
- FLINCH: Behind the Scenes (Film3/NFT/Independent Film)
- Crypto Spaces Daily (Talk Show/News)
- Level Up Lounge Sessions (Music/Poetry/Performance)
- 789 Crew Chronicles (Documentary/Creators)

---

## 🎬 COMPONENT SPECIFICATIONS

### 1. HERO BANNER (components/ott/hero-banner.tsx)

**Visual Design:**
- **Height**: 70vh, min-height 500px
- **Background**: Full-width hero image with overlay gradients
  - `bg-gradient-to-r from-black via-black/80 to-transparent`
  - `bg-gradient-to-t from-black via-transparent to-transparent`
- **Content Area**: Max-width 2xl, left-aligned
- **Tags**: Cyan rounded pills with `bg-black/50 backdrop-blur-sm border border-white/20`
- **Title**: 4xl-6xl bold white with gold glow
- **Description**: xl-2xl white/90 with white glow
- **CTA Buttons**:
  - Primary "Play": Gold bg, black text, gold shadow, hover scale(1.05)
  - Secondary "More Info": White outline, white text, glass bg, hover scale(1.05)

**Props:**
```typescript
interface HeroBannerProps {
  show: OTTShow
}
```

**Responsive:**
- Mobile: Stack vertically, smaller text sizes
- Desktop: Horizontal layout with content left, image right

---

### 2. CONTENT RAIL (components/ott/content-rail.tsx)

**Visual Design:**
- **Title**: Font-mono, 2xl, uppercase, bold, gold glow
- **Scroll Container**: Horizontal overflow with hidden scrollbar
- **Arrow Navigation**: Appear on hover (desktop only)
  - Left/Right chevrons with white glow
  - Gradient overlays: `from-black to-transparent`
- **Card Spacing**: Gap-4, flex-shrink-0, width 64 (256px)
- **Hover State**: Entire rail shows arrows with opacity transition

**Props:**
```typescript
interface ContentRailProps {
  title: string
  shows: OTTShow[]
  priority?: boolean
}
```

**Behavior:**
- Smooth scroll on arrow click (80% of viewport width)
- Touch-friendly horizontal scroll on mobile
- Hides scrollbar with `scrollbar-hide` class

---

### 3. SHOW CARD (components/ott/show-card.tsx)

**Visual Design:**
- **Container**: `bg-black/40 border-white/10` glass card
- **Aspect Ratio**: 16:9 video thumbnail
- **Hover Effects**:
  - Border changes to cyan/50
  - Scale(1.05) transform
  - Cyan shadow: `shadow-[#00ffff]/20`
  - Image scale(1.1) inside container
  - Gradient overlay from bottom
- **Info Section**: Padding-4
  - Title: Font-mono bold, white with glow, line-clamp-1
  - Genre badges: Cyan text, glass bg, max 2 visible

**Props:**
```typescript
interface ShowCardProps {
  show: OTTShow
  priority?: boolean
}
```

**Responsive:**
- Fixed width in rails (256px)
- Full width in grid layouts
- Touch-optimized hover states on mobile

---

### 4. HOMEPAGE LAYOUT (app/page.tsx)

**Structure:**
```
1. Hero Banner (Featured Show)
2. Content Rail: "789 Originals"
3. Content Rail: "Film3 Network"  
4. Content Rail: "Crypto Spaces Live"
5. Content Rail: "Continue Watching" (mocked)
6. Content Rail: "Documentary Genre"
7. Content Rail: "Talk Shows Genre"
```

**Code Pattern:**
```tsx
import { HeroBanner } from "@/components/ott/hero-banner"
import { ContentRail } from "@/components/ott/content-rail"
import { OTT_SHOWS, OTT_CHANNELS, getFeaturedShow } from "@/data/ott-content"

export default function OTTHomePage() {
  const featured = getFeaturedShow()
  
  return (
    <div className="bg-black min-h-screen">
      <HeroBanner show={featured} />
      
      <div className="space-y-12 py-12">
        <ContentRail 
          title="789 Originals" 
          shows={OTT_SHOWS.filter(s => s.channelId === "789-originals")}
          priority
        />
        {/* More rails... */}
      </div>
    </div>
  )
}
```

---

### 5. TITLE DETAIL PAGE (app/title/[slug]/page.tsx)

**Visual Layout:**
```
┌─────────────────────────────────────────┐
│  Hero Section (similar to hero banner)  │
│  - Poster left (desktop) / top (mobile) │
│  - Title, description, tags, buttons    │
└─────────────────────────────────────────┘
┌─────────────────────────────────────────┐
│  Episodes Section                        │
│  - Grid of episode cards (3 cols)       │
│  - Each: thumbnail, title, duration     │
└─────────────────────────────────────────┘
┌─────────────────────────────────────────┐
│  More Like This Rail                     │
└─────────────────────────────────────────┘
```

**Episode Card Design:**
- Glass card with white/10 border
- 16:9 thumbnail
- Episode number badge (gold bg, black text)
- Title: white with glow
- Duration: white/70 with cyan glow
- Hover: cyan border, scale(1.02)

---

### 6. WATCH PAGE (app/watch/[id]/page.tsx)

**Layout:**
```
┌─────────────────────────────────────────┐
│  Video Player (16:9, max-width-5xl)     │
│  - HTML5 <video> element                │
│  - Controls: play, pause, seek, volume  │
└─────────────────────────────────────────┘
┌─────────────────────────────────────────┐
│  Episode Info                            │
│  - Title, show name, description        │
│  - Prev Episode | Next Episode buttons  │
└─────────────────────────────────────────┘
┌─────────────────────────────────────────┐
│  Up Next Rail (same show episodes)      │
└─────────────────────────────────────────┘
```

**Video Player Styling:**
- Black background
- Rounded-lg container
- Gold play button overlay (before playing)
- Custom controls with gold/cyan accents
- Fullscreen support

---

### 7. BROWSE PAGE (app/browse/page.tsx)

**Layout:**
```
┌─────────────────────────────────────────┐
│  Filter Bar (sticky)                     │
│  - Genre, Channel, Year dropdowns       │
│  - Search input                          │
└─────────────────────────────────────────┘
┌─────────────────────────────────────────┐
│  Results Grid (3-4 cols)                │
│  - Show cards in responsive grid        │
│  - Infinite scroll or pagination        │
└─────────────────────────────────────────┘
```

**Filter Design:**
- Glass morphism bar: `bg-black/80 backdrop-blur-md`
- Dropdowns: White/10 border, cyan accent on active
- Search: Gold focus ring
- Sticky position with z-index

---

### 8. CHANNEL PAGE (app/channel/[slug]/page.tsx)

**Layout:**
```
┌─────────────────────────────────────────┐
│  Channel Header                          │
│  - Logo, name, description              │
│  - Channel color accent                 │
└─────────────────────────────────────────┘
┌─────────────────────────────────────────┐
│  Featured from Channel (Hero)            │
└─────────────────────────────────────────┘
┌─────────────────────────────────────────┐
│  All Shows Rail                          │
└─────────────────────────────────────────┘
```

**Channel Color Theming:**
- Use `OTTChannel.color` for accent highlights
- Apply to: header glow, button background, borders
- Examples: Gold for 789 Originals, Cyan for Crypto Spaces

---

## 🎨 IMAGE GENERATION PROMPTS

Use these prompts with `/placeholder.svg?query=` or image generation:

**Hero Arts:**
1. "Neural network visualization with glowing nodes and connections, dark cyberpunk aesthetic"
2. "Film production set with NFT hologram displays, cinematic lighting"
3. "Crypto trading screens and charts with gold and cyan accents, dark background"
4. "Poetry slam microphone with spotlight and abstract light rays"
5. "Content creator studio with multiple screens, futuristic setup"

**Thumbnails:**
1. "Digital consciousness abstract art with neural pathways"
2. "Independent film camera with NFT blockchain overlay"
3. "Cryptocurrency market analysis dashboard"
4. "Freestyle rap cipher with microphone closeup"
5. "AI ghostwriter typing at holographic keyboard"

**Episode Thumbnails:**
- Use 16:9 ratio
- Dark backgrounds with gold/cyan highlights
- Clear focal point (face, object, or visual metaphor)
- Cinematic color grading

---

## 📱 RESPONSIVE BREAKPOINTS

**Mobile (< 768px):**
- Single column stacks
- Full-width cards
- Vertical rails (no horizontal scroll)
- Larger touch targets (min 44px)
- Hero text: 4xl

**Tablet (768px - 1024px):**
- 2 column grids
- Horizontal rails with scroll
- Hero text: 5xl

**Desktop (> 1024px):**
- 3-4 column grids
- Full horizontal rails with arrow navigation
- Hover effects enabled
- Hero text: 6xl

---

## 🚀 IMPLEMENTATION CHECKLIST

### Phase 1: Data & Types
- [ ] Create `types/ott.ts` with interfaces
- [ ] Create `data/ott-content.ts` with sample shows
- [ ] Add helper functions (getShowBySlug, etc.)

### Phase 2: Core Components
- [ ] Build HeroBanner component
- [ ] Build ShowCard component
- [ ] Build ContentRail component

### Phase 3: Pages
- [ ] Homepage with hero + multiple rails
- [ ] Title detail page with episodes
- [ ] Watch page with video player
- [ ] Browse page with filters
- [ ] Channel page

### Phase 4: Polish
- [ ] Add loading skeletons
- [ ] Add error states
- [ ] Test mobile responsiveness
- [ ] Add keyboard navigation
- [ ] Optimize images

---

## 🎯 SUCCESS CRITERIA

✅ **Hero banner displays featured show with Play/More Info buttons**  
✅ **Multiple horizontal content rails scroll smoothly**  
✅ **Show cards have hover effects and link to detail pages**  
✅ **Title pages show episodes and "More Like This" rail**  
✅ **Watch pages have functional video player**  
✅ **Browse page filters work and display grid**  
✅ **Channel pages group shows by channel**  
✅ **All text is visible with glows on black background**  
✅ **Mobile: stacks vertically, touch-friendly**  
✅ **Desktop: horizontal rails with arrow navigation**

---

## 🎨 DESIGN TOKENS REFERENCE

```css
/* In globals.css */
:root {
  --ott-gold: #ffd700;
  --ott-cyan: #00ffff;
  --ott-black: #000000;
  --ott-charcoal: #0a0a0a;
  --ott-white: #ffffff;
  
  --glow-gold: 0 0 15px rgba(255, 215, 0, 0.5);
  --glow-cyan: 0 0 8px rgba(0, 255, 255, 0.3);
  --glow-white: 0 0 8px rgba(255, 255, 255, 0.3);
}
```

---

## 📦 READY-TO-PASTE COMPONENT EXAMPLES

### Show Card Component

```tsx
"use client"

import { Card } from "@/components/ui/card"
import Link from "next/link"
import type { OTTShow } from "@/types/ott"

interface ShowCardProps {
  show: OTTShow
  priority?: boolean
}

export function ShowCard({ show, priority = false }: ShowCardProps) {
  return (
    <Link href={`/title/${show.slug}`} className="block group">
      <Card className="relative overflow-hidden bg-black/40 border-white/10 hover:border-[#00ffff]/50 transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-[#00ffff]/20">
        {/* Thumbnail */}
        <div className="relative aspect-video overflow-hidden">
          <img
            src={show.thumbnail || "/placeholder.svg"}
            alt={show.title}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
            loading={priority ? "eager" : "lazy"}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
        </div>

        {/* Info */}
        <div className="p-4 space-y-2">
          <h3
            className="font-mono font-bold text-sm text-white line-clamp-1"
            style={{ textShadow: "0 0 8px rgba(255, 255, 255, 0.3)" }}
          >
            {show.title}
          </h3>
          <div className="flex flex-wrap gap-2">
            {show.genres.slice(0, 2).map((genre) => (
              <span
                key={genre}
                className="text-xs font-mono px-2 py-0.5 rounded bg-black/50 border border-white/20"
                style={{ color: "#00ffff", textShadow: "0 0 5px rgba(0, 255, 255, 0.3)" }}
              >
                {genre}
              </span>
            ))}
          </div>
        </div>
      </Card>
    </Link>
  )
}
```

### Content Rail Component

```tsx
"use client"

import { ShowCard } from "./show-card"
import type { OTTShow } from "@/types/ott"
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { useRef } from "react"

interface ContentRailProps {
  title: string
  shows: OTTShow[]
  priority?: boolean
}

export function ContentRail({ title, shows, priority = false }: ContentRailProps) {
  const scrollRef = useRef<HTMLDivElement>(null)

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const scrollAmount = scrollRef.current.clientWidth * 0.8
      scrollRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      })
    }
  }

  if (shows.length === 0) return null

  return (
    <div className="space-y-4">
      {/* Rail Title */}
      <h2
        className="font-mono text-xl md:text-2xl font-bold uppercase tracking-wider text-white px-4 md:px-0"
        style={{ textShadow: "0 0 15px rgba(255, 215, 0, 0.5)" }}
      >
        {title}
      </h2>

      {/* Scrollable Rail */}
      <div className="relative group">
        {/* Left Arrow - Desktop Only */}
        <button
          onClick={() => scroll("left")}
          className="hidden md:flex absolute left-0 top-1/2 -translate-y-1/2 z-10 w-12 h-full items-center justify-center bg-gradient-to-r from-black to-transparent opacity-0 group-hover:opacity-100 transition-opacity"
          aria-label="Scroll left"
        >
          <ChevronLeft className="w-8 h-8 text-white" style={{ filter: "drop-shadow(0 0 8px rgba(255,255,255,0.8))" }} />
        </button>

        {/* Content */}
        <div
          ref={scrollRef}
          className="flex gap-4 overflow-x-auto scrollbar-hide px-4 md:px-0 pb-4"
        >
          {shows.map((show) => (
            <div key={show.id} className="flex-shrink-0 w-64">
              <ShowCard show={show} priority={priority} />
            </div>
          ))}
        </div>

        {/* Right Arrow - Desktop Only */}
        <button
          onClick={() => scroll("right")}
          className="hidden md:flex absolute right-0 top-1/2 -translate-y-1/2 z-10 w-12 h-full items-center justify-center bg-gradient-to-l from-black to-transparent opacity-0 group-hover:opacity-100 transition-opacity"
          aria-label="Scroll right"
        >
          <ChevronRight className="w-8 h-8 text-white" style={{ filter: "drop-shadow(0 0 8px rgba(255,255,255,0.8))" }} />
        </button>
      </div>
    </div>
  )
}
```

---

## 🎬 FINAL NOTES

- **Dark Theme Only**: Pure black backgrounds, no light mode
- **Gold & Cyan**: Primary accent colors throughout
- **Text Glows**: All text must have glows for visibility
- **Glass Morphism**: Cards use `bg-black/40 backdrop-blur-sm`
- **Hover Animations**: Scale transforms on all interactive elements
- **Mobile First**: Design for mobile, enhance for desktop
- **Accessible**: WCAG AA contrast, keyboard navigation, ARIA labels

**This prompt is ready to paste into v0.dev to generate the complete OTT streaming interface!**
