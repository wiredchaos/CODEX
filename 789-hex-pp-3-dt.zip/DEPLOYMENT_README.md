# 789 Studios - Deployment Guide

## Project Overview
789 Studios is a comprehensive Web3 Virtual Studio Platform built with Next.js 16, featuring:
- Multi-platform creator publishing (YouTube, X, Instagram, TikTok, LinkedIn)
- Film3 onboarding for Web2 filmmakers
- Professional recording studios with booking system
- Token-gated content and NFT minting
- Crypto Spaces Network (24/7 schedule)
- Level Up Lounge for community events
- Lurky.app Spaces Intelligence integration
- Ally DAO ecosystem

## Tech Stack
- **Framework**: Next.js 16 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS v4
- **UI Components**: shadcn/ui
- **Animations**: Framer Motion
- **Icons**: Lucide React
- **API Integration**: Lurky.app

## Environment Variables Required

Create a `.env.local` file in the root directory:

```bash
# Lurky API (Spaces Intelligence)
LURKY_API_KEY="your_lurky_api_key_here"
LURKY_API_BASE_URL="https://api.lurky.app"
LURKY_MAX_RPM="50"

# Next.js
NEXT_PUBLIC_SITE_URL="https://789studios.com"
```

## Installation

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Start production server
npm start
```

## Key Routes

| Route | Description |
|-------|-------------|
| `/` | Homepage with creator feed |
| `/creator` | Multi-platform Creator Hub |
| `/crew` | 789 Crew member profiles |
| `/crew/[slug]` | Individual crew member pages |
| `/allies` | Partner DAOs and ecosystem |
| `/intelligence` | Lurky Spaces Intelligence Panel |
| `/film3` | Film3 ecosystem and resources |
| `/film3/flinch-case-study` | FLINCH NFT case study course |
| `/mint` | Film minting interface |
| `/pricing` | Studio rental pricing |
| `/lounge` | Level Up Lounge events |
| `/spaces` | Crypto Spaces Network schedule |

## Design System

### Color Palette
- **Primary**: Cyan (#00ffff)
- **Secondary**: Gold/Goldenrod (#ffd700, #daa520)
- **Accent**: Purple (#8a2be2)
- **Background**: Pure Black (#000000)

### Typography
- **Headings**: Bold with cyan/gold glow effects
- **Body**: White with 60-80% opacity
- **Monospace**: Used for technical UI elements

### ADA Compliance
- All text has glow effects (text-shadow) for visibility
- WCAG AA contrast ratios maintained
- Semantic HTML throughout
- Keyboard navigation support

## 789 Crew Members
1. **NEURO** - Cyan (@neurometax)
2. **VIBES** - Gold
3. **GATOR** - Green
4. **WOOKI** - Orange
5. **JEEP** - Blue
6. **ARTSY** - Purple

## Integrations

### Lurky.app
- Real-time X Spaces analytics
- Coin sentiment tracking
- Speaker network insights
- Rate-limited API proxy

### Film3 Ecosystem
- Decentralized Pictures
- Gala Film
- The Squad (Jordan Bayne)
- AI Film 3 Awards
- FFGCoin
- Vox In / The Coders Room
- WWCSFF
- MetaCannes

### Ally DAOs
- NEURO META X
- TYPE Media
- Beanies on Business
- BowMafia/BowDAO
- Dogwarts DAO
- OTF Media
- Yellow DAO
- KennelDAO

## Deployment to Vercel

1. **Connect Repository**
   - Import project from GitHub
   - Select Next.js framework preset

2. **Configure Environment Variables**
   - Add `LURKY_API_KEY` in Vercel dashboard
   - Add other env vars from `.env.local`

3. **Build Settings**
   - Build Command: `npm run build`
   - Output Directory: `.next`
   - Install Command: `npm install`

4. **Deploy**
   - Click "Deploy"
   - Vercel will auto-deploy on git push

## Performance Optimization
- Edge runtime for API routes
- Image optimization with Next.js Image
- Server components by default
- Client components only where needed
- Lazy loading for heavy components

## Security
- API keys server-side only
- Rate limiting on Lurky endpoints
- CORS protection
- Environment variable validation

## Support & Contact
- X: @789studiosonx
- Instagram: @789.studios
- Website: https://789studios.com

## License
All rights reserved © 789 Studios
