import type { OTTChannel, OTTShow } from "@/types/ott"

export const OTT_CHANNELS: OTTChannel[] = [
  {
    id: "789-originals",
    name: "789 Originals",
    slug: "789-originals",
    description: "Exclusive Web3-native content from 789 Studios creators",
    color: "#ffd700",
  },
  {
    id: "film3-network",
    name: "Film3 Network",
    slug: "film3-network",
    description: "Decentralized cinema and blockchain filmmaking",
    color: "#daa520",
  },
  {
    id: "crypto-spaces",
    name: "Crypto Spaces Live",
    slug: "crypto-spaces",
    description: "24/7 X Spaces recordings and crypto conversations",
    color: "#00ffff",
  },
]

export const OTT_SHOWS: OTTShow[] = [
  {
    id: "neuro-meta-decoded",
    title: "NEURO META X: Decoded",
    slug: "neuro-meta-decoded",
    channelId: "789-originals",
    description: "Decode the hidden layers of neural networks, metaphysics, and media history with NEURO",
    tags: ["AI", "Web3", "Philosophy"],
    genres: ["Documentary", "Educational"],
    heroArt: "/neural-network-metaphysics-documentary.jpg",
    thumbnail: "/neuro-meta-x-documentary.jpg",
    year: 2025,
    episodes: [
      {
        id: "nmd-e01",
        showId: "neuro-meta-decoded",
        title: "The Language of Neural Networks",
        slug: "language-of-neural-networks",
        description: "Exploring how AI systems communicate and process information",
        duration: 1800,
        thumbnail: "/neural-network-visualization.png",
        videoUrl: "/videos/sample.mp4",
        episodeNumber: 1,
        seasonNumber: 1,
      },
      {
        id: "nmd-e02",
        showId: "neuro-meta-decoded",
        title: "Consciousness and Code",
        slug: "consciousness-and-code",
        description: "Where does consciousness end and code begin?",
        duration: 2100,
        thumbnail: "/consciousness-digital-code.jpg",
        videoUrl: "/videos/sample.mp4",
        episodeNumber: 2,
        seasonNumber: 1,
      },
    ],
  },
  {
    id: "flinch-series",
    title: "FLINCH: Behind the Scenes",
    slug: "flinch-series",
    channelId: "film3-network",
    description: "Go behind the scenes of the first NFT film franchise with creator Cameron Van Hoy",
    tags: ["Film3", "NFT", "Independent Film"],
    genres: ["Documentary", "Behind the Scenes"],
    heroArt: "/film-production-nft-cinema.jpg",
    thumbnail: "/flinch-nft-film.jpg",
    year: 2024,
    episodes: [
      {
        id: "flinch-e01",
        showId: "flinch-series",
        title: "FLINCH - The Official Film",
        slug: "flinch-official-film",
        description: "The complete FLINCH feature film - the first NFT-funded cinematic franchise",
        duration: 5400,
        thumbnail: "/flinch-nft-film.jpg",
        videoUrl: "https://www.youtube.com/embed/72N7Uq6wAQ0",
        episodeNumber: 1,
        seasonNumber: 1,
      },
      {
        id: "flinch-e02",
        showId: "flinch-series",
        title: "Smart Contract Security Audit",
        slug: "flinch-security-audit",
        description: "Technical breakdown of FLINCH NFT smart contracts and security implementation",
        duration: 1800,
        thumbnail: "/flinch-nft-origin.jpg",
        videoUrl: "https://www.youtube.com/embed/SERiyOxTddQ",
        episodeNumber: 2,
        seasonNumber: 1,
      },
    ],
  },
  {
    id: "crypto-spaces-daily",
    title: "Crypto Spaces Daily",
    slug: "crypto-spaces-daily",
    channelId: "crypto-spaces",
    description: "Daily highlights from the most important crypto X Spaces conversations",
    tags: ["Crypto", "News", "Community"],
    genres: ["Talk Show", "News"],
    heroArt: "/crypto-trading-discussion.jpg",
    thumbnail: "/crypto-spaces-conversation.jpg",
    year: 2025,
    episodes: [
      {
        id: "csd-e01",
        showId: "crypto-spaces-daily",
        title: "Market Analysis with Top Traders",
        slug: "market-analysis-traders",
        description: "Leading crypto traders discuss current market conditions",
        duration: 3600,
        thumbnail: "/crypto-market-analysis.png",
        videoUrl: "/videos/sample.mp4",
        episodeNumber: 1,
        seasonNumber: 1,
      },
    ],
  },
  {
    id: "level-up-lounge-sessions",
    title: "Level Up Lounge Sessions",
    slug: "level-up-lounge-sessions",
    channelId: "789-originals",
    description: "Poetry slams, ciphers, and live performances from the Level Up Lounge",
    tags: ["Music", "Poetry", "Performance"],
    genres: ["Music", "Performance"],
    heroArt: "/poetry-slam-performance.jpg",
    thumbnail: "/poetry-slam-mic.jpg",
    year: 2025,
    episodes: [
      {
        id: "lul-e01",
        showId: "level-up-lounge-sessions",
        title: "Cipher Night: Vol 1",
        slug: "cipher-night-vol-1",
        description: "Raw freestyle ciphers from emerging artists",
        duration: 2400,
        thumbnail: "/freestyle-cipher-mic.jpg",
        videoUrl: "/videos/sample.mp4",
        episodeNumber: 1,
        seasonNumber: 1,
      },
    ],
  },
  {
    id: "789-crew-chronicles",
    title: "789 Crew Chronicles",
    slug: "789-crew-chronicles",
    channelId: "789-originals",
    description: "Meet the creators behind 789 Studios",
    tags: ["Documentary", "Creators"],
    genres: ["Documentary"],
    heroArt: "/content-creator-studio.png",
    thumbnail: "/content-creators-group.jpg",
    year: 2025,
    episodes: [
      {
        id: "crew-e01",
        showId: "789-crew-chronicles",
        title: "NEURO: The AI Ghostwriter",
        slug: "neuro-ai-ghostwriter",
        description: "How NEURO bridges Web2 and Web3 content creation",
        duration: 1200,
        thumbnail: "/ai-content-creator.jpg",
        videoUrl: "/videos/sample.mp4",
        episodeNumber: 1,
        seasonNumber: 1,
      },
    ],
  },
]

export function getShowsByChannel(channelId: string) {
  return OTT_SHOWS.filter((show) => show.channelId === channelId)
}

export function getShowBySlug(slug: string) {
  return OTT_SHOWS.find((show) => show.slug === slug)
}

export function getChannelBySlug(slug: string) {
  return OTT_CHANNELS.find((channel) => channel.slug === slug)
}

export function getFeaturedShow() {
  return OTT_SHOWS[0]
}
