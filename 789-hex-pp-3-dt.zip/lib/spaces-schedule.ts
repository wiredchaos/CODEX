export interface SpaceHost {
  name: string
  handle: string
  time: string
  hour: number
  imageUrl: string
  xUrl: string
}

export const SPACES_SCHEDULE: SpaceHost[] = [
  {
    name: "GRAMI",
    handle: "@gramixmeta",
    time: "6 AM",
    hour: 6,
    imageUrl: "https://i.postimg.cc/pd1VFYpd/2.png",
    xUrl: "https://x.com/gramixmeta",
  },
  {
    name: "LEAH",
    handle: "@leahbluewater",
    time: "6 AM",
    hour: 6,
    imageUrl: "https://i.postimg.cc/6Q16vLy3/3.png",
    xUrl: "https://x.com/leahbluewater",
  },
  {
    name: "SHIBO",
    handle: "@godsburnt",
    time: "10 AM",
    hour: 10,
    imageUrl: "https://i.postimg.cc/nLwVDYCC/4.png",
    xUrl: "https://x.com/godsburnt",
  },
  {
    name: "JEEP",
    handle: "@jeepmeta",
    time: "1 PM",
    hour: 13,
    imageUrl: "https://i.postimg.cc/6Q16vLyp/5.png",
    xUrl: "https://x.com/jeepmeta",
  },
  {
    name: "SHIELD",
    handle: "@shieldmetax",
    time: "2 PM",
    hour: 14,
    imageUrl: "https://i.postimg.cc/g0BcZqnX/6.png",
    xUrl: "https://x.com/shieldmetax",
  },
  {
    name: "BARK",
    handle: "@barkmeta",
    time: "5 PM",
    hour: 17,
    imageUrl: "https://i.postimg.cc/TPH2DqpD/7.png",
    xUrl: "https://x.com/barkmeta",
  },
  {
    name: "VIBES",
    handle: "@vibesmetax",
    time: "7 PM",
    hour: 19,
    imageUrl: "https://i.postimg.cc/k5hMbFBS/8.png",
    xUrl: "https://x.com/vibesmetax",
  },
  {
    name: "WOOKI",
    handle: "@wookimeta",
    time: "8 PM",
    hour: 20,
    imageUrl: "https://i.postimg.cc/g0BcZqnR/9.png",
    xUrl: "https://x.com/wookimeta",
  },
  {
    name: "GATOR",
    handle: "@gatormetax",
    time: "9 PM",
    hour: 21,
    imageUrl: "https://i.postimg.cc/5tk9Cq6L/10.png",
    xUrl: "https://x.com/gatormetax",
  },
  {
    name: "DREAM",
    handle: "@dreammetax",
    time: "11 PM",
    hour: 23,
    imageUrl: "https://i.postimg.cc/6Q16vLyY/13.png",
    xUrl: "https://x.com/dreammetax",
  },
  {
    name: "GROW",
    handle: "@growxmeta",
    time: "MIDNIGHT",
    hour: 0,
    imageUrl: "https://i.postimg.cc/k5hMbFBT/14.png",
    xUrl: "https://x.com/growxmeta",
  },
  {
    name: "NEURO",
    handle: "@neurometax",
    time: "1 AM",
    hour: 1,
    imageUrl: "https://i.postimg.cc/0QMkdMw7/15.png",
    xUrl: "https://x.com/neurometax",
  },
  {
    name: "ARTSY",
    handle: "@artsymeta",
    time: "2 AM",
    hour: 2,
    imageUrl: "https://i.postimg.cc/Y9GrfGWf/16.png",
    xUrl: "https://x.com/artsymeta",
  },
  {
    name: "TRUCK",
    handle: "@truckmeta",
    time: "3 AM",
    hour: 3,
    imageUrl: "https://i.postimg.cc/nL9BSYxc/Truck-3-am.png",
    xUrl: "https://x.com/truckmeta",
  },
]

// Get current live host based on time
export function getCurrentHost(): SpaceHost | null {
  const now = new Date()
  const currentHour = now.getHours()

  // Find host matching current hour
  return SPACES_SCHEDULE.find((host) => host.hour === currentHour) || null
}
