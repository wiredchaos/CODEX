// 789 STUDIOS CREW COLOR CONFIGURATION
// Each crew member has a unique neon signature

export interface CrewMember {
  id: string
  name: string
  role: string
  primaryColor: string
  secondaryColor: string
  glowColor: string
  doginal?: string
}

export const CREW_COLORS = {
  alpha: {
    primary: "#00ffff",
    secondary: "#0088ff",
    glow: "0 0 20px #00ffff, 0 0 40px #00ffff",
    name: "Cyber Cyan",
  },
  beta: {
    primary: "#ff00ff",
    secondary: "#9d00ff",
    glow: "0 0 20px #ff00ff, 0 0 40px #ff00ff",
    name: "Plasma Magenta",
  },
  gamma: {
    primary: "#ffd700",
    secondary: "#ff6600",
    glow: "0 0 20px #ffd700, 0 0 40px #ffd700",
    name: "Solar Gold",
  },
  delta: {
    primary: "#00ff88",
    secondary: "#00ffaa",
    glow: "0 0 20px #00ff88, 0 0 40px #00ff88",
    name: "Matrix Lime",
  },
  omega: {
    primary: "#ff6600",
    secondary: "#ff0044",
    glow: "0 0 20px #ff6600, 0 0 40px #ff6600",
    name: "Blaze Orange",
  },
} as const

export type CrewType = keyof typeof CREW_COLORS

export const STUDIO_SECTIONS = [
  { id: "hex-forge", name: "HEX Forge", icon: "⬡", description: "3D Tile Generator" },
  { id: "game-forge", name: "Game Forge", icon: "🎮", description: "Interactive Worlds" },
  { id: "radio-33", name: "33.3 FM", icon: "📻", description: "Audio Station" },
  { id: "npc-lab", name: "NPC Lab", icon: "🤖", description: "AI Characters" },
  { id: "creator-hub", name: "Creator Hub", icon: "✨", description: "Profile Studio" },
] as const
