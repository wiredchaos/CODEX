// Lurky API Client for 789 Studios
// Handles authentication, rate limiting, and typed API calls

interface LurkySpace {
  id: string
  title: string
  creatorHandle: string
  createdAt: number
  startedAt?: number
  endedAt?: number
  participantCount?: number
  categories?: string[]
  summary?: string
  minimizedSummary?: string
  state: string
}

interface LurkyCoin {
  id: string
  symbol: string
  name: string
  chain: string
  image: string
  link: string
  externalLink: string
  priceUsd: number
  priceChange24h: number
  marketCap: number
  marketCapRank?: number
  categories: string[]
  mentions: {
    bullish: number
    neutral: number
    bearish: number
    total: number
    overallSentiment: string
  }
}

interface LurkySpeaker {
  twitterId: string
  handle: string
  name: string
  image?: string
  description?: string
  verified?: boolean
  verifiedType?: "blue" | "business" | null
  followersCount?: number
}

// Rate limiting tracker
const rateLimitTracker = {
  requests: [] as number[],
  maxRPM: Number.parseInt(process.env.LURKY_MAX_RPM || "50"),
}

function checkRateLimit(): boolean {
  const now = Date.now()
  const oneMinuteAgo = now - 60000

  // Clean old requests
  rateLimitTracker.requests = rateLimitTracker.requests.filter((time) => time > oneMinuteAgo)

  return rateLimitTracker.requests.length < rateLimitTracker.maxRPM
}

function recordRequest(): void {
  rateLimitTracker.requests.push(Date.now())
}

export function getLurkyClient() {
  const apiKey = process.env.LURKY_API_KEY
  const baseURL = process.env.LURKY_API_BASE_URL || "https://api.lurky.app"

  if (!apiKey && process.env.NODE_ENV !== "test") {
    throw new Error("LURKY_API_KEY environment variable is required. Please add it to your .env file.")
  }

  async function makeRequest<T>(endpoint: string, params?: Record<string, any>): Promise<T> {
    if (!checkRateLimit()) {
      throw new Error("Rate limit exceeded. Please try again in a moment.")
    }

    const url = new URL(endpoint, baseURL)
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          url.searchParams.append(key, String(value))
        }
      })
    }

    recordRequest()

    const response = await fetch(url.toString(), {
      headers: {
        "x-lurky-api-key": apiKey!,
        "Content-Type": "application/json",
      },
    })

    if (!response.ok) {
      const error = await response.text()
      throw new Error(`Lurky API error (${response.status}): ${error}`)
    }

    return response.json()
  }

  return {
    async listSpaces(params?: {
      creator_ids?: string
      state?: string
      started_after?: number
      started_before?: number
      categories?: string
      page?: number
      limit?: number
    }): Promise<{ spaces: LurkySpace[]; page: number; limit: number }> {
      return makeRequest("/v1/spaces", params)
    },

    async getSpaceById(id: string): Promise<LurkySpace> {
      return makeRequest(`/v1/spaces/${id}`)
    },

    async listCoinsWithMentions(params?: {
      chains?: string
      min_rank?: number
      max_rank?: number
      sort_by?: string
      sort_dir?: string
      page?: number
      limit?: number
      mentioned?: boolean
    }): Promise<{ coins: LurkyCoin[]; page: number; limit: number }> {
      return makeRequest("/v1/coins", { ...params, mentioned: true })
    },

    async listSpeakers(params?: {
      min_followers?: number
      max_followers?: number
      page?: number
      limit?: number
    }): Promise<{ speakers: LurkySpeaker[]; page: number; limit: number }> {
      return makeRequest("/v1/speakers", params)
    },
  }
}

export type { LurkySpace, LurkyCoin, LurkySpeaker }
