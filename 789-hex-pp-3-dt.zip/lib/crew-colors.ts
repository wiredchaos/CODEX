export const CREW_COLORS = {
  GRAMI: {
    primary: "#00ff88",
    glow: "rgba(0, 255, 136, 0.6)",
    name: "Lime",
  },
  LEAH: {
    primary: "#33ccff",
    glow: "rgba(51, 204, 255, 0.6)",
    name: "Sky Blue",
  },
  SHIBO: {
    primary: "#ff6b9d",
    glow: "rgba(255, 107, 157, 0.6)",
    name: "Rose",
  },
  JEEP: {
    primary: "#ffaa00",
    glow: "rgba(255, 170, 0, 0.6)",
    name: "Amber",
  },
  SHIELD: {
    primary: "#9d00ff",
    glow: "rgba(157, 0, 255, 0.6)",
    name: "Violet",
  },
  BARK: {
    primary: "#00ffff",
    glow: "rgba(0, 255, 255, 0.6)",
    name: "Cyan",
  },
  VIBES: {
    primary: "#ff00ff",
    glow: "rgba(255, 0, 255, 0.6)",
    name: "Magenta",
  },
  WOOKI: {
    primary: "#ffd700",
    glow: "rgba(255, 215, 0, 0.6)",
    name: "Gold",
  },
  GATOR: {
    primary: "#00ff00",
    glow: "rgba(0, 255, 0, 0.6)",
    name: "Green",
  },
  DREAM: {
    primary: "#cc66ff",
    glow: "rgba(204, 102, 255, 0.6)",
    name: "Lavender",
  },
  GROW: {
    primary: "#66ff66",
    glow: "rgba(102, 255, 102, 0.6)",
    name: "Spring Green",
  },
  NEURO: {
    primary: "#00ffff",
    glow: "rgba(0, 255, 255, 0.8)",
    name: "Cyan",
  },
  ARTSY: {
    primary: "#ff6699",
    glow: "rgba(255, 102, 153, 0.6)",
    name: "Pink",
  },
  TRUCK: {
    primary: "#0099ff",
    glow: "rgba(0, 153, 255, 0.6)",
    name: "Azure",
  },
} as const

export function getCrewColor(name: string) {
  const normalizedName = name.toUpperCase() as keyof typeof CREW_COLORS
  return CREW_COLORS[normalizedName] || CREW_COLORS.NEURO
}
