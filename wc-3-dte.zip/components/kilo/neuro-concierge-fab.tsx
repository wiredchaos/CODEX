"use client"

import { useState, useEffect } from "react"
import { useRouter, usePathname } from "next/navigation"
import {
  X,
  ChevronUp,
  ChevronDown,
  Building2,
  Radio,
  ShoppingBag,
  CreditCard,
  Landmark,
  Bot,
  Tv,
  GraduationCap,
  Sparkles,
  AlertTriangle,
} from "lucide-react"
import { cn } from "@/lib/utils"
import Image from "next/image"
import { MinimalistCard, MinimalistCardGrid } from "@/components/ui/minimalist-card"

const COLORS = {
  primary: "#00FFF7",
  secondary: "#FF6B35",
  akashic: "#A020F0",
  dark: "#000000",
}

const FLOORS = [
  { id: "lby", abbr: "LBY", name: "WIRED CHAOS META", route: "/", icon: Building2, realm: "both" },
  { id: "789", abbr: "789", name: "STUDIOS / OTT", route: "/789", icon: Tv, realm: "business" },
  { id: "333", abbr: "333", name: "SIGNAL STATION", route: "/333", icon: Radio, realm: "business" },
  { id: "mll", abbr: "MLL", name: "CHAOS STORE", route: "/mall", icon: ShoppingBag, realm: "business" },
  { id: "crd", abbr: "CRD", name: "CREDIT REPAIR", route: "/credit-repair", icon: CreditCard, realm: "business" },
  { id: "nra", abbr: "NRA", name: "LEGACY ARCH", route: "/neura", icon: Landmark, realm: "business" },
  { id: "npc", abbr: "NPC", name: "NPC ENGINE", route: "/npc", icon: Bot, realm: "business" },
  { id: "csn", abbr: "CSN", name: "CHAOS NET", route: "/watch", icon: Tv, realm: "business" },
  { id: "uni", abbr: "UNI", name: "UNIVERSITY", route: "/hrm", icon: GraduationCap, realm: "business" },
  { id: "fen", abbr: "FEN", name: "FEN REALM", route: "/fen", icon: Sparkles, realm: "akashic" },
  { id: "v33", abbr: "V33", name: "VAULT 33", route: "/vault33", icon: Landmark, realm: "akashic" },
]

export function NeuroConceirgeFAB() {
  const router = useRouter()
  const pathname = usePathname()
  const [isOpen, setIsOpen] = useState(false)
  const [activeRealm, setActiveRealm] = useState<"business" | "akashic">("business")
  const [currentFloorIndex, setCurrentFloorIndex] = useState(0)

  useEffect(() => {
    const index = FLOORS.findIndex((f) => f.route === pathname || (pathname.startsWith(f.route) && f.route !== "/"))
    if (index >= 0) setCurrentFloorIndex(index)
  }, [pathname])

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "/") {
        e.preventDefault()
        setIsOpen((prev) => !prev)
      }
      // Emergency exit with Escape
      if (e.key === "Escape" && isOpen) {
        setIsOpen(false)
      }
    }
    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [isOpen])

  const currentFloor = FLOORS[currentFloorIndex]
  const filteredFloors = FLOORS.filter((f) => f.realm === activeRealm || f.realm === "both")
  const accentColor = activeRealm === "akashic" ? COLORS.akashic : COLORS.primary

  const navigateFloor = (direction: "up" | "down") => {
    const newIndex =
      direction === "up" ? Math.max(0, currentFloorIndex - 1) : Math.min(FLOORS.length - 1, currentFloorIndex + 1)
    setCurrentFloorIndex(newIndex)
  }

  const goToFloor = (floor: (typeof FLOORS)[0]) => {
    router.push(floor.route)
    setIsOpen(false)
  }

  const panicExit = () => {
    setIsOpen(false)
    router.push("/")
  }

  return (
    <>
      {/* FAB Button */}
      <button
        onClick={() => setIsOpen(true)}
        className={cn(
          "fixed z-50 w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 overflow-hidden",
          "hover:scale-110 active:scale-95",
          "bottom-6 right-6 md:bottom-8 md:right-8",
          isOpen && "scale-0 opacity-0",
        )}
        style={{
          boxShadow: `0 0 20px ${COLORS.primary}50, 0 4px 20px rgba(0,0,0,0.3)`,
        }}
        aria-label="Open NEURO assistant"
      >
        <Image src="/images/neuro-avatar.jpg" alt="NEURO" width={56} height={56} className="object-cover" />
        <div
          className="absolute inset-0 border-2 rounded-full animate-spin pointer-events-none"
          style={{
            borderColor: COLORS.primary,
            borderTopColor: "transparent",
            borderBottomColor: "transparent",
            animationDuration: "3s",
          }}
        />
      </button>

      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center p-4 md:p-8">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setIsOpen(false)} />

          <div
            className="relative w-full max-w-md rounded-2xl overflow-hidden animate-in slide-in-from-bottom-4 duration-300"
            style={{
              background: "rgba(10, 12, 16, 0.98)",
              border: `1px solid ${accentColor}40`,
              boxShadow: `0 0 60px ${accentColor}20`,
            }}
          >
            {/* Emergency Exit - Always visible */}
            <button
              onClick={panicExit}
              className="absolute top-4 left-4 z-10 flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-mono uppercase bg-red-900/50 text-red-400 hover:bg-red-800/70 hover:text-red-300 transition-all border border-red-800"
              aria-label="Emergency Exit"
            >
              <AlertTriangle className="w-3 h-3" />
              EXIT
            </button>

            {/* Close button */}
            <button
              onClick={() => setIsOpen(false)}
              className="absolute top-4 right-4 z-10 w-8 h-8 rounded-full flex items-center justify-center text-neutral-400 hover:text-white hover:bg-white/10 transition-colors"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Realm Tabs */}
            <div className="flex border-b pt-2" style={{ borderColor: `${accentColor}30` }}>
              <button
                onClick={() => setActiveRealm("business")}
                className={cn(
                  "flex-1 py-3 font-mono text-sm uppercase tracking-wider transition-all",
                  activeRealm === "business" ? "border-b-2" : "text-neutral-500",
                )}
                style={{
                  color: activeRealm === "business" ? COLORS.primary : undefined,
                  borderColor: activeRealm === "business" ? COLORS.primary : "transparent",
                }}
              >
                BUSINESS
              </button>
              <button
                onClick={() => setActiveRealm("akashic")}
                className={cn(
                  "flex-1 py-3 font-mono text-sm uppercase tracking-wider transition-all",
                  activeRealm === "akashic" ? "border-b-2" : "text-neutral-500",
                )}
                style={{
                  color: activeRealm === "akashic" ? COLORS.akashic : undefined,
                  borderColor: activeRealm === "akashic" ? COLORS.akashic : "transparent",
                }}
              >
                FEN
              </button>
            </div>

            {/* Current Floor Display */}
            <div className="flex items-center justify-between p-4 border-b" style={{ borderColor: `${accentColor}20` }}>
              <div className="flex items-center gap-4">
                <span
                  className="text-4xl font-display font-bold"
                  style={{ color: accentColor, textShadow: `0 0 20px ${accentColor}60` }}
                >
                  {currentFloor.abbr}
                </span>
                <div>
                  <p className="text-neutral-500 text-xs font-mono uppercase">CURRENT FLOOR</p>
                  <p style={{ color: accentColor }} className="font-mono text-sm">
                    {currentFloor.name}
                  </p>
                </div>
              </div>
              <div className="flex flex-col gap-1">
                <button
                  onClick={() => navigateFloor("up")}
                  disabled={currentFloorIndex === 0}
                  className="w-8 h-8 rounded flex items-center justify-center text-neutral-500 hover:text-white hover:bg-white/10 disabled:opacity-30 transition-all"
                >
                  <ChevronUp className="w-5 h-5" />
                </button>
                <button
                  onClick={() => navigateFloor("down")}
                  disabled={currentFloorIndex === FLOORS.length - 1}
                  className="w-8 h-8 rounded flex items-center justify-center text-neutral-500 hover:text-white hover:bg-white/10 disabled:opacity-30 transition-all"
                >
                  <ChevronDown className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Floor Icon Display */}
            <div
              className="flex flex-col items-center justify-center py-8"
              style={{ borderBottom: `1px solid ${accentColor}20` }}
            >
              <div
                className="w-16 h-16 rounded-xl flex items-center justify-center mb-4"
                style={{
                  background: `${accentColor}10`,
                  border: `1px solid ${accentColor}40`,
                }}
              >
                <currentFloor.icon className="w-8 h-8" style={{ color: accentColor }} />
              </div>
              <span
                className="text-2xl font-display font-bold"
                style={{ color: accentColor, textShadow: `0 0 20px ${accentColor}60` }}
              >
                {currentFloor.abbr}
              </span>
              <span className="text-neutral-400 font-mono text-sm mt-1">{currentFloor.name}</span>
            </div>

            {/* Floor Grid - Using MinimalistCard */}
            <div className="p-4">
              <MinimalistCardGrid columns={3}>
                {filteredFloors.map((floor) => {
                  const isActive = floor.route === pathname || (pathname.startsWith(floor.route) && floor.route !== "/")
                  return (
                    <MinimalistCard
                      key={floor.id}
                      variant="floor"
                      abbr={floor.abbr}
                      title={floor.name}
                      subtitle={floor.name.split(" ")[0]}
                      icon={floor.icon}
                      isActive={isActive}
                      accentColor={accentColor}
                      onClick={() => goToFloor(floor)}
                    />
                  )
                })}
              </MinimalistCardGrid>
            </div>

            {/* Footer */}
            <div className="p-4 border-t flex items-center justify-between" style={{ borderColor: `${accentColor}20` }}>
              <p className="text-neutral-600 text-xs font-mono">ESC to exit</p>
              <button
                onClick={() => {
                  router.push("/tour")
                  setIsOpen(false)
                }}
                className="text-xs font-mono uppercase tracking-wider transition-all hover:opacity-80"
                style={{ color: accentColor }}
              >
                Start Tour →
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
