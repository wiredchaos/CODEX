"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ChevronUp, ChevronDown, DoorOpen } from "lucide-react"
import { ElevatorPanel } from "./elevator-panel"

const COLORS = {
  cyan: "#00FFF7",
  gold: "#FFD700",
  dark: "#02030A",
}

interface ElevatorPOVProps {
  initialFloor?: string
}

export function ElevatorPOV({ initialFloor = "lobby" }: ElevatorPOVProps) {
  const router = useRouter()
  const [currentFloor, setCurrentFloor] = useState(initialFloor)
  const [doorsOpen, setDoorsOpen] = useState(true)
  const [isMoving, setIsMoving] = useState(false)
  const [direction, setDirection] = useState<"up" | "down" | null>(null)

  const handleFloorSelect = (floorId: string) => {
    if (isMoving || floorId === currentFloor) return

    setDoorsOpen(false)
    setIsMoving(true)
    setDirection(floorId > currentFloor ? "up" : "down")

    setTimeout(() => {
      setCurrentFloor(floorId)
      setTimeout(() => {
        setIsMoving(false)
        setDoorsOpen(true)
        setDirection(null)
      }, 1000)
    }, 500)
  }

  return (
    <div
      className="relative w-full max-w-lg mx-auto aspect-[3/4] rounded-2xl overflow-hidden"
      style={{ background: "#0a0a0a" }}
    >
      {/* Ceiling */}
      <div className="absolute top-0 left-0 right-0 h-12 bg-gradient-to-b from-neutral-800 to-transparent" />
      <div className="absolute top-2 left-1/2 -translate-x-1/2 w-2/3 h-1 rounded-full bg-white/20" />

      {/* Floor Indicator */}
      <div className="absolute top-6 left-1/2 -translate-x-1/2 z-10">
        <div
          className="px-6 py-3 rounded-lg text-center"
          style={{
            background: "rgba(0,0,0,0.9)",
            border: `2px solid ${COLORS.cyan}`,
            boxShadow: `0 0 20px ${COLORS.cyan}30`,
          }}
        >
          <div className="flex items-center justify-center gap-3">
            {direction === "up" && <ChevronUp className="w-5 h-5 animate-bounce" style={{ color: COLORS.cyan }} />}
            {direction === "down" && <ChevronDown className="w-5 h-5 animate-bounce" style={{ color: COLORS.cyan }} />}
            <span
              className="font-mono text-2xl font-bold"
              style={{
                color: COLORS.cyan,
                textShadow: `0 0 10px ${COLORS.cyan}`,
              }}
            >
              {currentFloor.toUpperCase()}
            </span>
            {direction && (
              <span className="text-neutral-500 text-xs animate-pulse">
                {direction === "up" ? "ASCENDING" : "DESCENDING"}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Side Panel */}
      <div className="absolute right-4 top-1/2 -translate-y-1/2 z-10">
        <ElevatorPanel currentFloor={currentFloor} onFloorSelect={handleFloorSelect} compact />
      </div>

      {/* Elevator Doors */}
      <div className="absolute inset-x-0 bottom-0 h-3/4 flex pointer-events-none">
        {/* Left Door */}
        <div
          className="flex-1 transition-all duration-700 ease-in-out"
          style={{
            background: "linear-gradient(90deg, #2a2a2a 0%, #3a3a3a 50%, #2a2a2a 100%)",
            borderRight: `2px solid ${COLORS.cyan}40`,
            transform: doorsOpen ? "translateX(-95%)" : "translateX(0)",
          }}
        >
          <div className="h-full flex flex-col justify-evenly px-4">
            {[...Array(10)].map((_, i) => (
              <div key={i} className="h-px bg-white/5" />
            ))}
          </div>
        </div>

        {/* Right Door */}
        <div
          className="flex-1 transition-all duration-700 ease-in-out"
          style={{
            background: "linear-gradient(270deg, #2a2a2a 0%, #3a3a3a 50%, #2a2a2a 100%)",
            borderLeft: `2px solid ${COLORS.cyan}40`,
            transform: doorsOpen ? "translateX(95%)" : "translateX(0)",
          }}
        >
          <div className="h-full flex flex-col justify-evenly px-4">
            {[...Array(10)].map((_, i) => (
              <div key={i} className="h-px bg-white/5" />
            ))}
          </div>
        </div>
      </div>

      {/* Door Status */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-10">
        <div className="flex items-center gap-2 text-xs font-mono">
          <DoorOpen className="w-4 h-4" style={{ color: doorsOpen ? COLORS.cyan : "#666" }} />
          <span style={{ color: doorsOpen ? COLORS.cyan : "#666" }}>{doorsOpen ? "DOORS OPEN" : "DOORS CLOSED"}</span>
        </div>
      </div>

      {/* Floor reflection when doors open */}
      {doorsOpen && (
        <div
          className="absolute bottom-0 left-0 right-0 h-24 pointer-events-none"
          style={{
            background: `linear-gradient(to top, ${COLORS.cyan}20, transparent)`,
          }}
        />
      )}
    </div>
  )
}
