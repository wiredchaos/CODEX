"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  Film,
  Radio,
  ShoppingBag,
  CreditCard,
  Cpu,
  BookOpen,
  Sparkles,
  GraduationCap,
  Building2,
  Globe,
  BarChart3,
  Gamepad2,
  Brain,
} from "lucide-react"

const COLORS = {
  cyan: "#00FFF7",
  gold: "#FFD700",
  purple: "#A020F0",
  green: "#00FF88",
}

const FLOORS = [
  { id: "lobby", label: "L", name: "Lobby", route: "/", icon: Building2, color: COLORS.cyan },
  { id: "789", label: "1", name: "789 Studios", route: "/789", icon: Film, color: COLORS.gold },
  { id: "333", label: "2", name: "33.3FM", route: "/333", icon: Radio, color: COLORS.cyan },
  { id: "npc", label: "3", name: "NPC Engine", route: "/npc", icon: Cpu, color: COLORS.green },
  { id: "hrm", label: "4", name: "HRM Training", route: "/hrm", icon: Gamepad2, color: COLORS.green },
  { id: "mall", label: "5", name: "Chaos Store", route: "/mall", icon: ShoppingBag, color: COLORS.cyan },
  { id: "credit", label: "6", name: "Credit Repair", route: "/credit-repair", icon: CreditCard, color: COLORS.cyan },
  { id: "university", label: "7", name: "WC Academy", route: "/university", icon: GraduationCap, color: COLORS.cyan },
  { id: "hemisphere", label: "8", name: "Hemisphere", route: "/hemisphere", icon: BarChart3, color: COLORS.green },
  { id: "globe", label: "9", name: "Globe Explorer", route: "/globe", icon: Globe, color: COLORS.green },
  { id: "chaos-os", label: "10", name: "CHAOS OS", route: "/chaos-os", icon: Brain, color: COLORS.purple },
  { id: "fen", label: "F", name: "FEN Realm", route: "/fen", icon: Sparkles, color: COLORS.purple },
  { id: "vault33", label: "V", name: "Vault 33", route: "/vault33", icon: BookOpen, color: COLORS.purple },
]

interface ElevatorPanelProps {
  currentFloor?: string
  onFloorSelect?: (floorId: string) => void
  compact?: boolean
}

export function ElevatorPanel({ currentFloor = "lobby", onFloorSelect, compact = false }: ElevatorPanelProps) {
  const router = useRouter()
  const [selectedFloor, setSelectedFloor] = useState<string | null>(null)

  const handleSelect = (floor: (typeof FLOORS)[0]) => {
    setSelectedFloor(floor.id)
    if (onFloorSelect) {
      onFloorSelect(floor.id)
    } else {
      setTimeout(() => {
        router.push(floor.route)
      }, 300)
    }
  }

  if (compact) {
    return (
      <div className="grid grid-cols-4 gap-2">
        {FLOORS.map((floor) => {
          const isActive = currentFloor === floor.id
          const isSelected = selectedFloor === floor.id

          return (
            <button
              key={floor.id}
              onClick={() => handleSelect(floor)}
              className="w-10 h-10 rounded-lg flex items-center justify-center font-mono text-sm font-bold transition-all hover:scale-105"
              style={{
                background: isActive ? floor.color : isSelected ? `${floor.color}40` : "rgba(255,255,255,0.1)",
                color: isActive ? "#000" : floor.color,
                boxShadow: isActive || isSelected ? `0 0 15px ${floor.color}50` : "none",
              }}
              title={floor.name}
            >
              {floor.label}
            </button>
          )
        })}
      </div>
    )
  }

  return (
    <div
      className="p-4 rounded-xl"
      style={{
        background: "rgba(0,0,0,0.8)",
        border: `1px solid ${COLORS.cyan}30`,
      }}
    >
      <div className="grid grid-cols-3 gap-3">
        {FLOORS.map((floor) => {
          const Icon = floor.icon
          const isActive = currentFloor === floor.id
          const isSelected = selectedFloor === floor.id

          return (
            <button
              key={floor.id}
              onClick={() => handleSelect(floor)}
              className="p-3 rounded-lg text-left transition-all hover:scale-[1.02] group"
              style={{
                background: isActive ? `${floor.color}20` : "rgba(255,255,255,0.03)",
                border: `1px solid ${isActive || isSelected ? floor.color : "transparent"}`,
              }}
            >
              <div className="flex items-center gap-2">
                <div
                  className="w-8 h-8 rounded flex items-center justify-center font-mono text-sm font-bold"
                  style={{
                    background: `${floor.color}20`,
                    color: floor.color,
                  }}
                >
                  {floor.label}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white text-xs font-medium truncate">{floor.name}</p>
                </div>
              </div>
            </button>
          )
        })}
      </div>
    </div>
  )
}
