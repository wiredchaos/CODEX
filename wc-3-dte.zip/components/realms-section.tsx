"use client"

import type React from "react"

import { useRef, useState, useEffect } from "react"
import { cn } from "@/lib/utils"
import { useRealm, type RealmType } from "@/contexts/realm-context"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"

gsap.registerPlugin(ScrollTrigger)

const realms = [
  {
    id: "neuralis" as RealmType,
    title: "NEURALIS",
    subtitle: "Business Realm",
    frequency: "432 Hz",
    description:
      "The structured dimension of commerce, systems, and operational logic. Credit repair, healthcare, education patches operate here.",
    color: "#00FFF7", // Neon Cyan
    locked: false,
  },
  {
    id: "chaosphere" as RealmType,
    title: "CHAOSPHERE",
    subtitle: "Akashic Realm",
    frequency: "589 Hz",
    description:
      "The mystical dimension of lore, prophecy, and cosmic truth. VAULT 33, Gas Sigil Arcana, and Neteru Apinaya exist here.",
    color: "#FF1A1A", // Chaos Red
    locked: false,
  },
  {
    id: "underground" as RealmType,
    title: "UNDERGROUND",
    subtitle: "Hidden Realm",
    frequency: "33 Hz",
    description:
      "The shadow network. Undernet Syndicates, encrypted protocols, and forbidden knowledge. Access restricted.",
    color: "#A020F0", // Glitch Purple
    locked: true,
  },
]

export function RealmsSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const headerRef = useRef<HTMLDivElement>(null)
  const cardsRef = useRef<HTMLDivElement>(null)
  const { activeRealm, realmColors } = useRealm()

  useEffect(() => {
    if (!sectionRef.current || !headerRef.current || !cardsRef.current) return

    const ctx = gsap.context(() => {
      gsap.fromTo(
        headerRef.current,
        { x: -60, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 1,
          ease: "power3.out",
          scrollTrigger: {
            trigger: headerRef.current,
            start: "top 85%",
            toggleActions: "play none none reverse",
          },
        },
      )

      const cards = cardsRef.current?.querySelectorAll("article")
      if (cards) {
        gsap.fromTo(
          cards,
          { y: 60, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.8,
            stagger: 0.2,
            ease: "power3.out",
            scrollTrigger: {
              trigger: cardsRef.current,
              start: "top 90%",
              toggleActions: "play none none reverse",
            },
          },
        )
      }
    }, sectionRef)

    return () => ctx.revert()
  }, [])

  return (
    <section
      id="realms"
      ref={sectionRef}
      className="relative py-20 md:py-32 px-6 md:pl-28 md:pr-12"
      aria-labelledby="realms-heading"
    >
      <div
        className="liquid-blob w-64 md:w-96 h-64 md:h-96 -top-20 -left-20"
        style={{ backgroundColor: `${realmColors.primary}30` }}
        aria-hidden="true"
      />
      <div
        className="liquid-blob w-48 md:w-64 h-48 md:h-64 bg-[#A020F0]/20 bottom-20 right-10"
        style={{ animationDelay: "-5s" }}
        aria-hidden="true"
      />

      {/* Section header */}
      <div ref={headerRef} className="mb-12 md:mb-16 relative z-10">
        <span
          className="font-mono text-xs uppercase tracking-[0.3em] realm-transition neon-text-bright"
          style={{
            color: realmColors.primary,
            textShadow: `0 0 5px ${realmColors.primary}, 0 0 10px ${realmColors.primary}`,
          }}
        >
          01 / Dual Architecture
        </span>
        <h2
          id="realms-heading"
          className="mt-4 font-[var(--font-bebas)] text-4xl md:text-5xl lg:text-7xl tracking-tight text-white"
          style={{
            textShadow: `0 0 20px ${realmColors.glow}, 0 0 40px ${realmColors.glow}`,
          }}
        >
          THE REALMS
        </h2>
        <p className="mt-4 max-w-xl font-mono text-sm md:text-base text-muted-foreground leading-relaxed">
          All systems exist in mirrored versions across Business and Akashic realms. Strict firewalling prevents
          cross-contamination.{" "}
          <span
            className="font-medium neon-text-bright"
            style={{
              color: realmColors.primary,
              textShadow: `0 0 5px ${realmColors.primary}`,
            }}
          >
            <span className="hidden sm:inline">Click a realm to shift the interface aesthetic.</span>
            <span className="sm:hidden">Tap a realm to shift aesthetic.</span>
          </span>
        </p>
      </div>

      <div
        ref={cardsRef}
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 relative z-10"
        role="list"
      >
        {realms.map((realm, index) => (
          <RealmCard key={realm.id} realm={realm} index={index} isActive={activeRealm === realm.id} />
        ))}
      </div>

      {/* Active realm indicator */}
      {activeRealm && (
        <div className="mt-6 md:mt-8 flex items-center gap-4 relative z-10" role="status" aria-live="polite">
          <div
            className="h-px flex-1 realm-transition"
            style={{
              background: `linear-gradient(to right, transparent, ${realmColors.primary}60, transparent)`,
              boxShadow: `0 0 10px ${realmColors.glow}`,
            }}
            aria-hidden="true"
          />
          <span
            className="font-mono text-xs md:text-sm uppercase tracking-widest realm-transition neon-text-bright"
            style={{
              color: realmColors.primary,
              textShadow: `0 0 10px ${realmColors.primary}, 0 0 20px ${realmColors.primary}`,
            }}
          >
            {activeRealm} Mode Active
          </span>
          <div
            className="h-px flex-1 realm-transition"
            style={{
              background: `linear-gradient(to left, transparent, ${realmColors.primary}60, transparent)`,
              boxShadow: `0 0 10px ${realmColors.glow}`,
            }}
            aria-hidden="true"
          />
        </div>
      )}
    </section>
  )
}

function RealmCard({
  realm,
  index,
  isActive,
}: {
  realm: (typeof realms)[number]
  index: number
  isActive: boolean
}) {
  const [isHovered, setIsHovered] = useState(false)
  const { setActiveRealm } = useRealm()

  const handleClick = () => {
    if (!realm.locked) {
      setActiveRealm(realm.id)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault()
      handleClick()
    }
  }

  const glowIntensity = isActive ? "0.5" : isHovered ? "0.3" : "0.15"

  return (
    <article
      role="listitem"
      tabIndex={realm.locked ? -1 : 0}
      aria-pressed={isActive}
      aria-disabled={realm.locked}
      className={cn(
        "group relative glass-strong p-6 md:p-8 transition-all duration-500 cursor-pointer overflow-hidden rounded-lg",
        realm.locked && "opacity-60 cursor-not-allowed",
      )}
      style={{
        borderColor: isActive || isHovered ? realm.color : `${realm.color}40`,
        boxShadow:
          isActive || isHovered
            ? `0 0 30px ${realm.color}${glowIntensity === "0.5" ? "80" : "50"}, 0 0 60px ${realm.color}40, inset 0 0 30px ${realm.color}20`
            : `0 0 10px ${realm.color}20, inset 0 0 20px rgba(0,0,0,0.5)`,
        border: `1px solid ${isActive || isHovered ? realm.color : `${realm.color}40`}`,
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={handleClick}
      onKeyDown={handleKeyDown}
    >
      {/* Active indicator pulse */}
      {isActive && (
        <div className="absolute inset-0 pointer-events-none" aria-hidden="true">
          <div className="absolute inset-0 animate-pulse opacity-10" style={{ backgroundColor: realm.color }} />
        </div>
      )}

      {/* Realm identifier */}
      <div className="flex items-baseline justify-between mb-4 md:mb-6">
        <span
          className="font-mono text-[10px] md:text-xs uppercase tracking-[0.3em]"
          style={{
            color: realm.color,
            textShadow: `0 0 5px ${realm.color}, 0 0 10px ${realm.color}`,
          }}
        >
          Realm {String(index + 1).padStart(2, "0")}
        </span>
        <span
          className="font-mono text-[10px] md:text-xs"
          style={{
            color: realm.color,
            textShadow: `0 0 5px ${realm.color}`,
          }}
        >
          {realm.frequency}
        </span>
      </div>

      <h3
        className="font-[var(--font-bebas)] text-3xl md:text-4xl lg:text-5xl tracking-tight mb-2 transition-colors duration-300"
        style={{
          color: isHovered || isActive ? realm.color : "#ffffff",
          textShadow:
            isHovered || isActive
              ? `0 0 10px ${realm.color}, 0 0 20px ${realm.color}, 0 0 40px ${realm.color}`
              : `0 0 10px ${realm.color}40`,
        }}
      >
        {realm.title}
      </h3>

      <span className="font-mono text-xs md:text-sm" style={{ color: `${realm.color}aa` }}>
        {realm.subtitle}
      </span>

      {/* Divider */}
      <div
        className="h-px mt-4 md:mt-6 mb-4 md:mb-6 transition-all duration-500"
        style={{
          width: isHovered || isActive ? "100%" : "48px",
          backgroundColor: realm.color,
          boxShadow: `0 0 10px ${realm.color}`,
        }}
        aria-hidden="true"
      />

      <p className="font-mono text-xs md:text-sm text-muted-foreground leading-relaxed">{realm.description}</p>

      {/* Lock indicator */}
      {realm.locked && (
        <div className="absolute top-4 right-4">
          <span
            className="font-mono text-xs uppercase tracking-wider"
            style={{
              color: realm.color,
              textShadow: `0 0 5px ${realm.color}`,
            }}
          >
            [LOCKED]
          </span>
        </div>
      )}

      {/* Active indicator badge */}
      {isActive && (
        <div className="absolute top-4 right-4">
          <span
            className="font-mono text-xs md:text-sm uppercase tracking-wider animate-pulse"
            style={{
              color: realm.color,
              textShadow: `0 0 10px ${realm.color}, 0 0 20px ${realm.color}`,
            }}
          >
            [ACTIVE]
          </span>
        </div>
      )}

      {/* Corner accent with neon glow */}
      <div
        className={cn(
          "absolute bottom-0 right-0 w-16 h-16 transition-opacity duration-500",
          isHovered || isActive ? "opacity-100" : "opacity-0",
        )}
        aria-hidden="true"
      >
        <div
          className="absolute bottom-0 right-0 w-full h-[2px]"
          style={{
            backgroundColor: realm.color,
            boxShadow: `0 0 10px ${realm.color}, 0 0 20px ${realm.color}`,
          }}
        />
        <div
          className="absolute bottom-0 right-0 w-[2px] h-full"
          style={{
            backgroundColor: realm.color,
            boxShadow: `0 0 10px ${realm.color}, 0 0 20px ${realm.color}`,
          }}
        />
      </div>
    </article>
  )
}
