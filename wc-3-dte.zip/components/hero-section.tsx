"use client"

import { useEffect, useRef } from "react"
import { ScrambleTextOnHover } from "@/components/scramble-text"
import { SplitFlapText, SplitFlapMuteToggle, SplitFlapAudioProvider } from "@/components/split-flap-text"
import { AnimatedNoise } from "@/components/animated-noise"
import { BitmapChevron } from "@/components/bitmap-chevron"
import { FrequencyIndicator } from "@/components/frequency-indicator"
import { useRealm } from "@/contexts/realm-context"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"

gsap.registerPlugin(ScrollTrigger)

export function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const contentRef = useRef<HTMLDivElement>(null)
  const { activeRealm, realmColors } = useRealm()

  useEffect(() => {
    if (!sectionRef.current || !contentRef.current) return

    const ctx = gsap.context(() => {
      gsap.to(contentRef.current, {
        y: -100,
        opacity: 0,
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top top",
          end: "bottom top",
          scrub: 1,
        },
      })
    }, sectionRef)

    return () => ctx.revert()
  }, [])

  const getSubtitle = () => {
    switch (activeRealm) {
      case "neuralis":
        return "META OS — Neuralis Business Architecture"
      case "chaosphere":
        return "META OS — Chaosphere Akashic Architecture"
      case "underground":
        return "META OS — Underground Shadow Architecture"
      default:
        return "META OS — Neuralis × Chaosphere Architecture"
    }
  }

  return (
    <section
      ref={sectionRef}
      id="hero"
      className="relative min-h-screen flex items-center px-6 md:pl-28 md:pr-12"
      aria-labelledby="hero-title"
    >
      <AnimatedNoise opacity={0.02} />

      {/* Left vertical labels - hidden on mobile */}
      <div className="hidden md:block absolute left-4 md:left-6 top-1/2 -translate-y-1/2">
        <span
          className="font-mono text-xs uppercase tracking-[0.3em] -rotate-90 origin-left block whitespace-nowrap neon-text-bright"
          style={{
            color: "#00FFF7",
            textShadow: "0 0 10px #00FFF7, 0 0 20px #00FFF7, 0 0 40px #00FFF7",
          }}
        >
          {activeRealm ? `${activeRealm.toUpperCase()} NODE` : "TRINITY NODE"}
        </span>
      </div>

      {/* Main content */}
      <div ref={contentRef} className="flex-1 w-full relative z-10">
        <SplitFlapAudioProvider>
          <div className="relative">
            <h1 id="hero-title" className="sr-only">
              WIRED CHAOS
            </h1>
            <div className="glitch-flicker">
              <SplitFlapText text="WIRED CHAOS" speed={80} />
            </div>
            <div className="mt-4">
              <SplitFlapMuteToggle />
            </div>
          </div>
        </SplitFlapAudioProvider>

        <h2
          className="font-[var(--font-bebas)] text-[clamp(1rem,3vw,2rem)] mt-4 tracking-wide neon-text-bright"
          style={{
            color: "#00FFF7",
            textShadow: "0 0 5px #00FFF7, 0 0 10px #00FFF7, 0 0 20px #00FFF7, 0 0 40px #00FFF7",
          }}
        >
          {getSubtitle()}
        </h2>

        <FrequencyIndicator />

        <p className="mt-8 max-w-lg font-mono text-sm md:text-base text-muted-foreground leading-relaxed">
          The operating system for conscious self-authorship. Navigate between realms, unlock Akashic frequencies, and
          interface with the 33 shards of the First Cipher. Welcome to the NEURO Era.
        </p>

        <div className="mt-8 md:mt-12 flex flex-col sm:flex-row items-start sm:items-center gap-4 sm:gap-8">
          <a
            href="#realms"
            className="group inline-flex items-center gap-3 glass-strong neon-touch px-6 py-4 font-mono text-xs sm:text-sm uppercase tracking-widest text-foreground transition-all duration-200 rounded-lg w-full sm:w-auto justify-center sm:justify-start"
            style={{
              borderColor: "rgba(0, 255, 247, 0.3)",
              boxShadow: "0 0 20px rgba(0, 255, 247, 0.2), inset 0 0 20px rgba(0,0,0,0.5)",
            }}
          >
            <ScrambleTextOnHover text="Enter The Realms" as="span" duration={0.6} />
            <BitmapChevron className="transition-transform duration-[400ms] ease-in-out group-hover:rotate-45" />
          </a>
          <a
            href="#timeline"
            className="font-mono text-xs sm:text-sm uppercase tracking-widest transition-colors duration-200 focus-visible:ring-2 focus-visible:ring-accent rounded-sm p-2 w-full sm:w-auto text-center sm:text-left neon-text-bright"
            style={{
              color: "#00FFF7",
              textShadow: "0 0 5px #00FFF7, 0 0 10px #00FFF7, 0 0 20px #00FFF7",
            }}
          >
            Master Timeline
          </a>
        </div>
      </div>

      <div className="absolute bottom-6 right-6 md:bottom-12 md:right-12">
        <div
          className="glass-strong neon-touch px-3 py-2 md:px-4 md:py-3 font-mono text-[10px] md:text-xs uppercase tracking-widest rounded-lg"
          style={{
            borderColor: "rgba(0, 255, 247, 0.3)",
            color: "#00FFF7",
            textShadow: "0 0 5px #00FFF7, 0 0 10px #00FFF7",
            boxShadow: "0 0 15px rgba(0, 255, 247, 0.2), inset 0 0 10px rgba(0,0,0,0.5)",
          }}
        >
          <span className="hidden sm:inline">v.589 / Black Ledger Year 2025.X</span>
          <span className="sm:hidden">v.589 / 2025.X</span>
        </div>
      </div>
    </section>
  )
}
