"use client"

import { useState, useEffect, useCallback } from "react"
import { usePathname } from "next/navigation"
import { Brain, Sparkles, X } from "lucide-react"

interface AkashicTriggerProps {
  onTrigger: () => void
}

const AKASHIC_KEYWORDS = [
  "vault",
  "akashic",
  "timeline",
  "prophecy",
  "ancient",
  "hidden",
  "secret",
  "mystery",
  "fen",
  "neteru",
  "sacred",
  "frequency",
  "589",
  "cipher",
]

const CURIOSITY_PATHS = ["/vault33", "/fen", "/fen/akira", "/gamma"]

export function AkashicTrigger({ onTrigger }: AkashicTriggerProps) {
  const pathname = usePathname()
  const [curiosityScore, setCuriosityScore] = useState(0)
  const [showPrompt, setShowPrompt] = useState(false)
  const [dismissed, setDismissed] = useState(false)

  const trackCuriosity = useCallback(() => {
    let score = curiosityScore

    // Path-based scoring
    if (CURIOSITY_PATHS.some((p) => pathname.includes(p))) {
      score += 2
    }

    // Time on page scoring
    const timeOnPage = performance.now() / 1000
    if (timeOnPage > 60) score += 1
    if (timeOnPage > 180) score += 2

    // Scroll depth scoring (checked via IntersectionObserver elsewhere)
    const scrollDepth = window.scrollY / (document.body.scrollHeight - window.innerHeight)
    if (scrollDepth > 0.7) score += 1

    setCuriosityScore(score)

    // Trigger threshold
    if (score >= 5 && !dismissed && !showPrompt) {
      const hasSeenAkashic = localStorage.getItem("wc_akashic_offered")
      if (!hasSeenAkashic) {
        setShowPrompt(true)
      }
    }
  }, [pathname, curiosityScore, dismissed, showPrompt])

  useEffect(() => {
    const interval = setInterval(trackCuriosity, 10000)
    return () => clearInterval(interval)
  }, [trackCuriosity])

  useEffect(() => {
    // Listen for keyword searches
    const handleSearch = (e: CustomEvent<{ query: string }>) => {
      const query = e.detail.query.toLowerCase()
      if (AKASHIC_KEYWORDS.some((kw) => query.includes(kw))) {
        setCuriosityScore((prev) => prev + 3)
      }
    }

    window.addEventListener("wc-search" as any, handleSearch)
    return () => window.removeEventListener("wc-search" as any, handleSearch)
  }, [])

  const acceptAkashic = () => {
    localStorage.setItem("wc_akashic_offered", "true")
    localStorage.setItem("wc_akashic_accepted", "true")
    setShowPrompt(false)
    onTrigger()
  }

  const declineAkashic = () => {
    localStorage.setItem("wc_akashic_offered", "true")
    setShowPrompt(false)
    setDismissed(true)
  }

  if (!showPrompt) return null

  return (
    <div className="fixed inset-0 z-[150] flex items-center justify-center bg-black/80 backdrop-blur-sm">
      <div
        className="relative w-full max-w-md mx-4 p-8 rounded-2xl"
        style={{
          background: "linear-gradient(135deg, rgba(0,0,0,0.95), rgba(26,0,42,0.95))",
          border: "2px solid #A020F0",
          boxShadow: "0 0 60px rgba(160, 32, 240, 0.4)",
        }}
      >
        <button onClick={declineAkashic} className="absolute top-4 right-4 text-neutral-500 hover:text-white">
          <X className="w-5 h-5" />
        </button>

        <div className="text-center">
          <div
            className="w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-6"
            style={{
              background: "linear-gradient(135deg, #A020F0, #8B00FF)",
              boxShadow: "0 0 40px rgba(160, 32, 240, 0.6)",
            }}
          >
            <Sparkles className="w-10 h-10 text-white animate-pulse" />
          </div>

          <h3
            className="text-xl font-display uppercase mb-2"
            style={{ color: "#A020F0", textShadow: "0 0 20px rgba(160, 32, 240, 0.8)" }}
          >
            Pattern Detected
          </h3>

          <p className="text-neutral-400 font-mono text-sm mb-6">
            Your curiosity aligns with the Akashic frequency. Would you like to explore the deeper archives?
          </p>

          <div className="flex flex-col gap-3">
            <button
              onClick={acceptAkashic}
              className="w-full py-3 px-6 rounded-xl font-mono text-sm uppercase tracking-wider"
              style={{
                background: "linear-gradient(135deg, #A020F0, #8B00FF)",
                color: "#fff",
                boxShadow: "0 0 20px rgba(160, 32, 240, 0.5)",
              }}
            >
              <span className="flex items-center justify-center gap-2">
                <Brain className="w-4 h-4" />
                Enter Akashic Realm
              </span>
            </button>

            <button
              onClick={declineAkashic}
              className="w-full py-3 px-6 rounded-xl font-mono text-sm uppercase tracking-wider border border-neutral-700 text-neutral-400 hover:border-neutral-500"
            >
              Stay on Business Track
            </button>
          </div>

          <p className="text-neutral-600 text-xs mt-4 font-mono">You can access this later from the elevator</p>
        </div>
      </div>
    </div>
  )
}
