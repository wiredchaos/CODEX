"use client"

import { useRef, useMemo, useState } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { Points, PointMaterial, OrbitControls, Html, Line } from "@react-three/drei"
import * as THREE from "three"

// Sacred sites for lei lines
const SACRED_SITES = [
  { name: "Great Pyramid", lat: 29.9792, lng: 31.1342, type: "portal" },
  { name: "Stonehenge", lat: 51.1789, lng: -1.8262, type: "node" },
  { name: "Machu Picchu", lat: -13.1631, lng: -72.545, type: "portal" },
  { name: "Easter Island", lat: -27.1127, lng: -109.3497, type: "node" },
  { name: "Angkor Wat", lat: 13.4125, lng: 103.867, type: "portal" },
  { name: "Nazca Lines", lat: -14.7391, lng: -75.1299, type: "node" },
  { name: "Bermuda Triangle", lat: 25.0, lng: -71.0, type: "anomaly" },
  { name: "Devils Sea", lat: 25.0, lng: 137.0, type: "anomaly" },
  { name: "Sedona", lat: 34.8697, lng: -111.761, type: "vortex" },
  { name: "Mount Shasta", lat: 41.4092, lng: -122.1949, type: "vortex" },
  { name: "Uluru", lat: -25.3444, lng: 131.0369, type: "portal" },
  { name: "Tibet", lat: 29.6516, lng: 91.1721, type: "node" },
]

// Convert lat/lng to 3D coordinates
function latLngToVector3(lat: number, lng: number, radius: number): THREE.Vector3 {
  const phi = (90 - lat) * (Math.PI / 180)
  const theta = (lng + 180) * (Math.PI / 180)
  const x = -(radius * Math.sin(phi) * Math.cos(theta))
  const z = radius * Math.sin(phi) * Math.sin(theta)
  const y = radius * Math.cos(phi)
  return new THREE.Vector3(x, y, z)
}

// Generate lei line connections
function generateLeiLines(sites: typeof SACRED_SITES, radius: number) {
  const connections: Array<[THREE.Vector3, THREE.Vector3]> = []

  // Create connections between nearby sites
  for (let i = 0; i < sites.length; i++) {
    for (let j = i + 1; j < sites.length; j++) {
      const p1 = latLngToVector3(sites[i].lat, sites[i].lng, radius)
      const p2 = latLngToVector3(sites[j].lat, sites[j].lng, radius)
      const distance = p1.distanceTo(p2)

      // Connect sites within certain distance threshold
      if (distance < 3.5) {
        connections.push([p1, p2])
      }
    }
  }

  return connections
}

// Standard Globe Model
function StandardGlobe({ showLabels }: { showLabels: boolean }) {
  const globeRef = useRef<THREE.Group>(null)
  const leiLinesRef = useRef<THREE.Group>(null)
  const radius = 2

  // Generate earth surface points
  const earthPositions = useMemo(() => {
    const positions = []
    const count = 8000
    for (let i = 0; i < count; i++) {
      const phi = Math.acos(-1 + (2 * i) / count)
      const theta = Math.sqrt(count * Math.PI) * phi
      const r = radius + (Math.random() - 0.5) * 0.02
      positions.push(r * Math.cos(theta) * Math.sin(phi), r * Math.sin(theta) * Math.sin(phi), r * Math.cos(phi))
    }
    return new Float32Array(positions)
  }, [])

  // Sacred site positions
  const sitePositions = useMemo(() => {
    return SACRED_SITES.map((site) => ({
      ...site,
      position: latLngToVector3(site.lat, site.lng, radius + 0.05),
    }))
  }, [])

  // Lei lines
  const leiLines = useMemo(() => generateLeiLines(SACRED_SITES, radius + 0.02), [])

  useFrame((state) => {
    const time = state.clock.getElapsedTime()
    if (globeRef.current) {
      globeRef.current.rotation.y = time * 0.05
    }
  })

  return (
    <group ref={globeRef}>
      {/* Earth surface */}
      <Points positions={earthPositions} stride={3} frustumCulled={false}>
        <PointMaterial
          transparent
          color="#1a1a2e"
          size={0.015}
          sizeAttenuation={true}
          depthWrite={false}
          opacity={0.8}
        />
      </Points>

      {/* Core sphere */}
      <mesh>
        <sphereGeometry args={[radius * 0.98, 64, 64]} />
        <meshStandardMaterial color="#0a0a15" roughness={0.9} metalness={0.1} />
      </mesh>

      {/* Atmosphere glow */}
      <mesh>
        <sphereGeometry args={[radius * 1.05, 32, 32]} />
        <meshBasicMaterial color="#00FFF7" transparent opacity={0.05} side={THREE.BackSide} />
      </mesh>

      {/* Lei Lines */}
      <group ref={leiLinesRef}>
        {leiLines.map((line, i) => (
          <Line key={i} points={[line[0], line[1]]} color="#00FFF7" lineWidth={1.5} transparent opacity={0.6} />
        ))}
      </group>

      {/* Sacred Sites / Portals */}
      {sitePositions.map((site, i) => (
        <group key={i} position={site.position}>
          <mesh>
            <sphereGeometry args={[0.04, 16, 16]} />
            <meshBasicMaterial
              color={
                site.type === "portal"
                  ? "#FF4500"
                  : site.type === "anomaly"
                    ? "#A020F0"
                    : site.type === "vortex"
                      ? "#FFD700"
                      : "#00FFF7"
              }
              transparent
              opacity={0.9}
            />
          </mesh>
          {/* Glow */}
          <mesh>
            <sphereGeometry args={[0.08, 16, 16]} />
            <meshBasicMaterial
              color={
                site.type === "portal"
                  ? "#FF4500"
                  : site.type === "anomaly"
                    ? "#A020F0"
                    : site.type === "vortex"
                      ? "#FFD700"
                      : "#00FFF7"
              }
              transparent
              opacity={0.3}
            />
          </mesh>
          {showLabels && (
            <Html position={[0, 0.15, 0]} center>
              <div className="whitespace-nowrap text-xs font-mono px-2 py-1 rounded bg-black/80 text-cyan-400 border border-cyan-500/30">
                {site.name}
              </div>
            </Html>
          )}
        </group>
      ))}
    </group>
  )
}

// Flat Earth Model
function FlatEarthModel({ showLabels }: { showLabels: boolean }) {
  const discRef = useRef<THREE.Group>(null)
  const radius = 2.5

  // Disc surface points
  const discPositions = useMemo(() => {
    const positions = []
    for (let r = 0; r < radius; r += 0.08) {
      const points = Math.floor(2 * Math.PI * r * 15)
      for (let i = 0; i < points; i++) {
        const angle = (i / points) * Math.PI * 2
        positions.push(Math.cos(angle) * r, 0, Math.sin(angle) * r)
      }
    }
    return new Float32Array(positions)
  }, [])

  // Ice wall points
  const iceWallPositions = useMemo(() => {
    const positions = []
    const wallHeight = 0.5
    const segments = 200
    for (let i = 0; i < segments; i++) {
      const angle = (i / segments) * Math.PI * 2
      for (let h = 0; h < wallHeight; h += 0.05) {
        positions.push(Math.cos(angle) * radius, h, Math.sin(angle) * radius)
      }
    }
    return new Float32Array(positions)
  }, [])

  // Dome positions
  const domePositions = useMemo(() => {
    const positions = []
    const domeRadius = radius
    const segments = 100
    for (let lat = 0; lat < Math.PI / 2; lat += 0.1) {
      const r = domeRadius * Math.cos(lat)
      const y = domeRadius * Math.sin(lat) * 0.8
      for (let i = 0; i < segments; i++) {
        const angle = (i / segments) * Math.PI * 2
        positions.push(Math.cos(angle) * r, y, Math.sin(angle) * r)
      }
    }
    return new Float32Array(positions)
  }, [])

  useFrame((state) => {
    const time = state.clock.getElapsedTime()
    if (discRef.current) {
      discRef.current.rotation.y = time * 0.02
    }
  })

  return (
    <group ref={discRef}>
      {/* Disc surface */}
      <Points positions={discPositions} stride={3} frustumCulled={false}>
        <PointMaterial
          transparent
          color="#1a1a2e"
          size={0.02}
          sizeAttenuation={true}
          depthWrite={false}
          opacity={0.9}
        />
      </Points>

      {/* Disc base */}
      <mesh rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[radius, 64]} />
        <meshStandardMaterial color="#0a0a15" roughness={0.9} />
      </mesh>

      {/* Ice Wall */}
      <Points positions={iceWallPositions} stride={3} frustumCulled={false}>
        <PointMaterial
          transparent
          color="#E8E8E8"
          size={0.025}
          sizeAttenuation={true}
          depthWrite={false}
          opacity={0.8}
        />
      </Points>

      {/* Dome (Firmament) */}
      <Points positions={domePositions} stride={3} frustumCulled={false}>
        <PointMaterial
          transparent
          color="#00FFF7"
          size={0.015}
          sizeAttenuation={true}
          depthWrite={false}
          opacity={0.3}
          blending={THREE.AdditiveBlending}
        />
      </Points>

      {/* Sun orbit path */}
      <mesh position={[0, 1.2, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[1.2, 0.02, 8, 64]} />
        <meshBasicMaterial color="#FFD700" transparent opacity={0.5} />
      </mesh>

      {/* Sun */}
      <mesh position={[1.2, 1.2, 0]}>
        <sphereGeometry args={[0.12, 32, 32]} />
        <meshBasicMaterial color="#FFD700" />
      </mesh>

      {/* Moon orbit path */}
      <mesh position={[0, 1.0, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.9, 0.015, 8, 64]} />
        <meshBasicMaterial color="#E8E8E8" transparent opacity={0.3} />
      </mesh>

      {/* Moon */}
      <mesh position={[-0.9, 1.0, 0]}>
        <sphereGeometry args={[0.08, 32, 32]} />
        <meshBasicMaterial color="#E8E8E8" />
      </mesh>

      {showLabels && (
        <>
          <Html position={[0, 0.3, 0]} center>
            <div className="whitespace-nowrap text-sm font-mono px-3 py-1 rounded bg-black/80 text-cyan-400 border border-cyan-500/30">
              EARTH DISC
            </div>
          </Html>
          <Html position={[0, 2.2, 0]} center>
            <div className="whitespace-nowrap text-xs font-mono px-2 py-1 rounded bg-black/80 text-cyan-400/60 border border-cyan-500/20">
              FIRMAMENT DOME
            </div>
          </Html>
          <Html position={[radius + 0.3, 0.25, 0]} center>
            <div className="whitespace-nowrap text-xs font-mono px-2 py-1 rounded bg-black/80 text-white/60 border border-white/20">
              ICE WALL
            </div>
          </Html>
        </>
      )}
    </group>
  )
}

// Hollow Earth / Inner Earth Model
function InnerEarthModel({ showLabels }: { showLabels: boolean }) {
  const earthRef = useRef<THREE.Group>(null)
  const radius = 2

  // Outer shell points
  const shellPositions = useMemo(() => {
    const positions = []
    const count = 6000
    for (let i = 0; i < count; i++) {
      const phi = Math.acos(-1 + (2 * i) / count)
      const theta = Math.sqrt(count * Math.PI) * phi
      const r = radius
      positions.push(r * Math.cos(theta) * Math.sin(phi), r * Math.sin(theta) * Math.sin(phi), r * Math.cos(phi))
    }
    return new Float32Array(positions)
  }, [])

  // Inner world surface (inverted)
  const innerPositions = useMemo(() => {
    const positions = []
    const count = 3000
    const innerRadius = radius * 0.6
    for (let i = 0; i < count; i++) {
      const phi = Math.acos(-1 + (2 * i) / count)
      const theta = Math.sqrt(count * Math.PI) * phi
      positions.push(
        innerRadius * Math.cos(theta) * Math.sin(phi),
        innerRadius * Math.sin(theta) * Math.sin(phi),
        innerRadius * Math.cos(phi),
      )
    }
    return new Float32Array(positions)
  }, [])

  // Pole openings
  const northPoleOpening = useMemo(() => {
    const positions = []
    const openingRadius = 0.4
    for (let i = 0; i < 100; i++) {
      const angle = (i / 100) * Math.PI * 2
      positions.push(Math.cos(angle) * openingRadius, radius * 0.98, Math.sin(angle) * openingRadius)
    }
    return new Float32Array(positions)
  }, [])

  useFrame((state) => {
    const time = state.clock.getElapsedTime()
    if (earthRef.current) {
      earthRef.current.rotation.y = time * 0.03
    }
  })

  return (
    <group ref={earthRef}>
      {/* Outer shell (semi-transparent) */}
      <Points positions={shellPositions} stride={3} frustumCulled={false}>
        <PointMaterial
          transparent
          color="#1a1a2e"
          size={0.012}
          sizeAttenuation={true}
          depthWrite={false}
          opacity={0.4}
        />
      </Points>

      {/* Wireframe outer sphere */}
      <mesh>
        <sphereGeometry args={[radius, 32, 32]} />
        <meshBasicMaterial color="#00FFF7" wireframe transparent opacity={0.15} />
      </mesh>

      {/* Inner world surface */}
      <Points positions={innerPositions} stride={3} frustumCulled={false}>
        <PointMaterial
          transparent
          color="#00FF88"
          size={0.02}
          sizeAttenuation={true}
          depthWrite={false}
          opacity={0.7}
          blending={THREE.AdditiveBlending}
        />
      </Points>

      {/* Inner Sun (Agartha) */}
      <mesh position={[0, 0, 0]}>
        <sphereGeometry args={[0.25, 32, 32]} />
        <meshBasicMaterial color="#FFD700" />
      </mesh>
      <mesh position={[0, 0, 0]}>
        <sphereGeometry args={[0.35, 32, 32]} />
        <meshBasicMaterial color="#FFD700" transparent opacity={0.3} />
      </mesh>

      {/* North Pole Opening */}
      <Points positions={northPoleOpening} stride={3} frustumCulled={false}>
        <PointMaterial
          transparent
          color="#FF4500"
          size={0.03}
          sizeAttenuation={true}
          depthWrite={false}
          opacity={0.9}
          blending={THREE.AdditiveBlending}
        />
      </Points>

      {/* South Pole Opening indicator */}
      <mesh position={[0, -radius * 0.98, 0]} rotation={[Math.PI, 0, 0]}>
        <ringGeometry args={[0.3, 0.4, 32]} />
        <meshBasicMaterial color="#FF4500" transparent opacity={0.8} side={THREE.DoubleSide} />
      </mesh>

      {/* Cross-section plane indicator */}
      <mesh rotation={[0, 0, Math.PI / 4]}>
        <planeGeometry args={[radius * 2.5, radius * 2.5]} />
        <meshBasicMaterial color="#00FFF7" transparent opacity={0.02} side={THREE.DoubleSide} />
      </mesh>

      {showLabels && (
        <>
          <Html position={[0, 0.5, 0]} center>
            <div className="whitespace-nowrap text-xs font-mono px-2 py-1 rounded bg-black/80 text-yellow-400 border border-yellow-500/30">
              INNER SUN
            </div>
          </Html>
          <Html position={[0, radius + 0.2, 0]} center>
            <div className="whitespace-nowrap text-xs font-mono px-2 py-1 rounded bg-black/80 text-orange-400 border border-orange-500/30">
              NORTH ENTRANCE
            </div>
          </Html>
          <Html position={[radius * 0.8, 0, 0]} center>
            <div className="whitespace-nowrap text-xs font-mono px-2 py-1 rounded bg-black/80 text-green-400/60 border border-green-500/20">
              AGARTHA
            </div>
          </Html>
        </>
      )}
    </group>
  )
}

function GlobeScene({
  variant,
  showLabels,
}: {
  variant: "standard" | "flat" | "inner"
  showLabels: boolean
}) {
  return (
    <>
      <ambientLight intensity={0.2} />
      <pointLight position={[10, 10, 10]} intensity={0.5} color="#00FFF7" />
      <pointLight position={[-10, -10, -10]} intensity={0.3} color="#FF4500" />

      {variant === "standard" && <StandardGlobe showLabels={showLabels} />}
      {variant === "flat" && <FlatEarthModel showLabels={showLabels} />}
      {variant === "inner" && <InnerEarthModel showLabels={showLabels} />}

      <OrbitControls
        enableZoom={true}
        enablePan={false}
        autoRotate={variant !== "flat"}
        autoRotateSpeed={0.3}
        minDistance={3}
        maxDistance={10}
        minPolarAngle={Math.PI * 0.1}
        maxPolarAngle={Math.PI * 0.9}
      />
    </>
  )
}

interface GlobeModelsProps {
  variant?: "standard" | "flat" | "inner"
  showLabels?: boolean
  showControls?: boolean
  className?: string
}

export function GlobeModels({
  variant: initialVariant = "standard",
  showLabels: initialShowLabels = false,
  showControls = true,
  className = "",
}: GlobeModelsProps) {
  const [variant, setVariant] = useState<"standard" | "flat" | "inner">(initialVariant)
  const [showLabels, setShowLabels] = useState(initialShowLabels)

  return (
    <div className={`relative ${className}`}>
      {showControls && (
        <div className="absolute top-4 left-4 z-10 flex flex-col gap-2">
          <div className="flex gap-2">
            {(["standard", "flat", "inner"] as const).map((v) => (
              <button
                key={v}
                onClick={() => setVariant(v)}
                className="px-3 py-1.5 rounded-lg font-mono text-xs uppercase transition-all"
                style={{
                  background: variant === v ? "rgba(0, 255, 247, 0.2)" : "rgba(0, 0, 0, 0.6)",
                  border: `1px solid ${variant === v ? "#00FFF7" : "rgba(255,255,255,0.1)"}`,
                  color: variant === v ? "#00FFF7" : "#888",
                }}
              >
                {v === "standard" ? "Globe" : v === "flat" ? "Flat" : "Hollow"}
              </button>
            ))}
          </div>
          <button
            onClick={() => setShowLabels(!showLabels)}
            className="px-3 py-1.5 rounded-lg font-mono text-xs uppercase transition-all"
            style={{
              background: showLabels ? "rgba(255, 69, 0, 0.2)" : "rgba(0, 0, 0, 0.6)",
              border: `1px solid ${showLabels ? "#FF4500" : "rgba(255,255,255,0.1)"}`,
              color: showLabels ? "#FF4500" : "#888",
            }}
          >
            {showLabels ? "Hide Labels" : "Show Labels"}
          </button>
        </div>
      )}

      <Canvas camera={{ position: [0, 2, 6], fov: 45 }} gl={{ antialias: true, alpha: true }}>
        <GlobeScene variant={variant} showLabels={showLabels} />
      </Canvas>

      {/* Legend */}
      {showControls && variant === "standard" && (
        <div
          className="absolute bottom-4 right-4 p-3 rounded-lg"
          style={{
            background: "rgba(0, 0, 0, 0.8)",
            border: "1px solid rgba(0, 255, 247, 0.2)",
          }}
        >
          <div className="font-mono text-xs text-neutral-400 uppercase mb-2">Legend</div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-orange-500" />
              <span className="font-mono text-xs text-neutral-300">Portal</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-cyan-400" />
              <span className="font-mono text-xs text-neutral-300">Node</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-purple-500" />
              <span className="font-mono text-xs text-neutral-300">Anomaly</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-yellow-400" />
              <span className="font-mono text-xs text-neutral-300">Vortex</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-0.5 bg-cyan-400" />
              <span className="font-mono text-xs text-neutral-300">Lei Line</span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
