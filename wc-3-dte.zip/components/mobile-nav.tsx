"use client"

import { useState } from "react"
import { Menu, X } from "lucide-react"
import { useRealm } from "@/contexts/realm-context"
import { ElevatorOverlay } from "./elevator-overlay"

const navItems = [
  { id: "hero", label: "Index" },
  { id: "realms", label: "Realms" },
  { id: "timeline", label: "Timeline" },
  { id: "factions", label: "Factions" },
  { id: "patches", label: "Patches" },
  { id: "xr-gallery", label: "XR Assets" },
  { id: "colophon", label: "Colophon" },
]

export function MobileNav() {
  const [isOpen, setIsOpen] = useState(false)
  const [elevatorOpen, setElevatorOpen] = useState(false)
  const { realmColors } = useRealm()

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
      setIsOpen(false)
    }
  }

  return (
    <>
      {/* Mobile Menu Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed top-4 left-4 z-50 md:hidden p-3 rounded-lg transition-all duration-300 neon-touch"
        style={{
          background: "rgba(0, 0, 0, 0.9)",
          border: `1px solid ${realmColors.primary}40`,
          boxShadow: `0 0 20px ${realmColors.primary}20`,
        }}
        aria-label={isOpen ? "Close menu" : "Open menu"}
        aria-expanded={isOpen}
      >
        {isOpen ? (
          <X className="w-5 h-5" style={{ color: realmColors.primary }} />
        ) : (
          <Menu className="w-5 h-5" style={{ color: realmColors.primary }} />
        )}
      </button>

      {/* Mobile Menu Overlay */}
      {isOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="absolute inset-0 bg-black/95 backdrop-blur-xl" onClick={() => setIsOpen(false)} />

          <nav
            className="absolute left-0 top-0 h-full w-64 p-6 pt-20"
            style={{
              background: "linear-gradient(135deg, rgba(0,0,0,0.98), rgba(10,10,10,0.98))",
              borderRight: `1px solid ${realmColors.primary}30`,
              boxShadow: `0 0 40px ${realmColors.primary}10`,
            }}
          >
            {/* Section Links */}
            <div className="space-y-2 mb-8">
              {navItems.map(({ id, label }) => (
                <button
                  key={id}
                  onClick={() => scrollToSection(id)}
                  className="w-full text-left px-4 py-3 rounded-lg font-mono text-sm uppercase tracking-widest transition-all duration-300 hover:bg-white/5 neon-touch"
                  style={{ color: realmColors.primary }}
                >
                  {label}
                </button>
              ))}
            </div>

            {/* NEURO Concierge / Elevator Access */}
            <div className="pt-6 border-t border-neutral-800">
              <p
                className="px-4 mb-3 font-mono text-xs uppercase tracking-widest"
                style={{ color: realmColors.primary }}
              >
                NEURO Concierge
              </p>
              <button
                onClick={() => {
                  setIsOpen(false)
                  setElevatorOpen(true)
                }}
                className="w-full flex items-center gap-4 px-4 py-4 rounded-lg transition-all duration-300 hover:scale-[1.02] neon-touch"
                style={{
                  background: "linear-gradient(135deg, rgba(0,255,247,0.1), rgba(0,191,255,0.05))",
                  border: "1px solid rgba(0, 255, 247, 0.3)",
                  boxShadow: "0 0 20px rgba(0, 255, 247, 0.1)",
                }}
              >
                {/* Elevator Icon */}
                <div className="relative w-8 h-10 border-2 border-cyan-400 rounded-sm overflow-hidden">
                  <div className="absolute inset-0 flex">
                    <div className="w-1/2 h-full border-r border-cyan-400/30" />
                    <div className="w-1/2 h-full" />
                  </div>
                  <div
                    className="absolute top-1 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full animate-pulse"
                    style={{ backgroundColor: "#00FFF7", boxShadow: "0 0 8px #00FFF7" }}
                  />
                </div>
                <div>
                  <span
                    className="block font-mono text-sm font-bold uppercase"
                    style={{ color: "#00FFF7", textShadow: "0 0 10px #00FFF7" }}
                  >
                    Access Floors
                  </span>
                  <span className="text-xs text-neutral-500">Building Nav</span>
                </div>
              </button>
            </div>
          </nav>
        </div>
      )}

      <ElevatorOverlay isOpen={elevatorOpen} onClose={() => setElevatorOpen(false)} />
    </>
  )
}
