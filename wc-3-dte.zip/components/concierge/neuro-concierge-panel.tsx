"use client"

import { X, MapPin, ArrowRight, Zap, Home } from "lucide-react"
import { useShell } from "@/components/shell/wcmstr-shell"
import { getFloor } from "@/lib/registry/floors"
import { getSuite } from "@/lib/registry/suites"
import { getGalaxy } from "@/lib/registry/galaxies"
import { Button } from "@/components/ui/button"

export function NeuroConciergePanel() {
  const { mode, currentFloor, currentSuiteId, isConciergeOpen, toggleConcierge, toggleElevator, setFloor } = useShell()

  if (!isConciergeOpen) return null

  const galaxy = getGalaxy(mode)
  const floor = getFloor(currentFloor)
  const suite = currentSuiteId ? getSuite(currentSuiteId) : null

  // Floor guidance (low cognitive load)
  const floorGuidance: Record<number, string> = {
    0: "Start here. Explore what's possible.",
    1: "Public access. Browse freely.",
    2: "Games and training. Level up.",
    3: "Advanced tools. Builder territory.",
    4: "Deep signal. Akashic realm.",
  }

  return (
    <div className="fixed right-4 top-20 bottom-20 w-80 z-50 bg-black/90 border border-cyan-500/30 rounded-2xl backdrop-blur-xl overflow-hidden flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-cyan-500/20 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-cyan-500/20 flex items-center justify-center">
            <Zap className="w-4 h-4 text-cyan-400" />
          </div>
          <span className="font-bold text-cyan-400">NEURO</span>
        </div>
        <button onClick={toggleConcierge} className="text-gray-400 hover:text-white">
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* You Are Here */}
      <div className="p-4 border-b border-cyan-500/20">
        <div className="flex items-center gap-2 text-sm text-gray-400 mb-2">
          <MapPin className="w-4 h-4" />
          <span>You are here</span>
        </div>
        <div className="space-y-1">
          <p className="text-cyan-400 font-medium">{galaxy?.title || "WIRED CHAOS"}</p>
          <p className="text-white">
            Floor {currentFloor}: {floor?.name || "UNKNOWN"}
          </p>
          {suite && <p className="text-gray-400 text-sm">{suite.title}</p>}
        </div>
      </div>

      {/* Guidance */}
      <div className="p-4 flex-1">
        <p className="text-gray-300 text-sm leading-relaxed">{floorGuidance[currentFloor] || "Explore this space."}</p>

        {/* Quick context for investor mode */}
        {mode === "investor" && (
          <div className="mt-4 p-3 bg-purple-500/10 border border-purple-500/30 rounded-lg">
            <p className="text-purple-400 text-sm">Investor Express: No lore. Just proof. 60 seconds to understand.</p>
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="p-4 border-t border-cyan-500/20 space-y-2">
        <Button
          onClick={toggleElevator}
          className="w-full flex items-center justify-center gap-2 bg-cyan-600 hover:bg-cyan-700"
        >
          <ArrowRight className="w-4 h-4" />
          Open Elevator
        </Button>
        <Button
          onClick={() => setFloor(0)}
          variant="outline"
          className="w-full flex items-center justify-center gap-2 border-cyan-500/30 text-cyan-400"
        >
          <Home className="w-4 h-4" />
          Back to Lobby
        </Button>
        {mode !== "investor" && (
          <Button variant="ghost" className="w-full text-purple-400 hover:text-purple-300" onClick={() => {}}>
            <Zap className="w-4 h-4 mr-2" />
            Investor Express
          </Button>
        )}
      </div>
    </div>
  )
}
