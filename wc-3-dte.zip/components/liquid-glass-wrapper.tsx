"use client"

import type { ReactNode } from "react"

interface LiquidGlassWrapperProps {
  children: ReactNode
  className?: string
  variant?: "default" | "card" | "panel" | "overlay"
  glow?: "cyan" | "purple" | "red" | "gold" | "blue" | "none"
}

export function LiquidGlassWrapper({
  children,
  className = "",
  variant = "default",
  glow = "cyan",
}: LiquidGlassWrapperProps) {
  const baseStyles = "relative overflow-hidden"

  const variantStyles = {
    default: "bg-black/40 backdrop-blur-xl border border-white/10 rounded-xl",
    card: "bg-black/60 backdrop-blur-2xl border border-white/20 rounded-2xl shadow-2xl",
    panel:
      "bg-gradient-to-br from-black/70 via-black/50 to-black/70 backdrop-blur-3xl border border-white/10 rounded-3xl",
    overlay: "bg-black/80 backdrop-blur-3xl border border-white/5 rounded-xl",
  }

  const glowStyles = {
    cyan: "before:absolute before:inset-0 before:bg-gradient-to-br before:from-cyan-500/10 before:via-transparent before:to-cyan-500/5 before:[border-radius:inherit] before:pointer-events-none",
    purple:
      "before:absolute before:inset-0 before:bg-gradient-to-br before:from-purple-500/10 before:via-transparent before:to-purple-500/5 before:[border-radius:inherit] before:pointer-events-none",
    red: "before:absolute before:inset-0 before:bg-gradient-to-br before:from-red-500/10 before:via-transparent before:to-red-500/5 before:[border-radius:inherit] before:pointer-events-none",
    gold: "before:absolute before:inset-0 before:bg-gradient-to-br before:from-amber-500/10 before:via-transparent before:to-amber-500/5 before:[border-radius:inherit] before:pointer-events-none",
    blue: "before:absolute before:inset-0 before:bg-gradient-to-br before:from-blue-500/10 before:via-transparent before:to-blue-500/5 before:[border-radius:inherit] before:pointer-events-none",
    none: "",
  }

  return (
    <div className={`${baseStyles} ${variantStyles[variant]} ${glowStyles[glow]} ${className}`}>
      {/* Glass reflection effect */}
      <div className="absolute inset-0 bg-gradient-to-b from-white/5 via-transparent to-transparent pointer-events-none [border-radius:inherit]" />

      {/* Content */}
      <div className="relative z-10">{children}</div>

      {/* Bottom shine */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent pointer-events-none" />
    </div>
  )
}

export default LiquidGlassWrapper
