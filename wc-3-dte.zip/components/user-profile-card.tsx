"use client"

import { MinimalistCard } from "@/components/ui/minimalist-card"

interface UserProfile {
  id: string
  name: string
  handle?: string
  avatar?: string
  role?: string
  status?: "online" | "offline" | "busy" | "away"
  realm?: "business" | "akashic"
  badge?: string
}

interface UserProfileCardProps {
  user: UserProfile
  variant?: "full" | "compact"
  isActive?: boolean
  onClick?: () => void
}

export function UserProfileCard({ user, variant = "full", isActive = false, onClick }: UserProfileCardProps) {
  const accentColor = user.realm === "akashic" ? "#A020F0" : "#00FFF7"

  if (variant === "compact") {
    return (
      <MinimalistCard
        variant="compact"
        abbr={user.name.substring(0, 3).toUpperCase()}
        title={user.name}
        image={user.avatar}
        isActive={isActive}
        accentColor={accentColor}
        onClick={onClick}
      />
    )
  }

  return (
    <MinimalistCard
      variant="profile"
      abbr={user.name.substring(0, 2).toUpperCase()}
      title={user.name}
      subtitle={user.handle || user.role}
      image={user.avatar}
      isActive={isActive}
      accentColor={accentColor}
      status={user.status}
      badge={user.badge}
      onClick={onClick}
    />
  )
}

// Cross-system user list component
export function UserProfileList({
  users,
  onSelect,
  selectedId,
}: {
  users: UserProfile[]
  onSelect?: (user: UserProfile) => void
  selectedId?: string
}) {
  return (
    <div className="space-y-3">
      {users.map((user) => (
        <UserProfileCard key={user.id} user={user} isActive={user.id === selectedId} onClick={() => onSelect?.(user)} />
      ))}
    </div>
  )
}
