"use client"

import { useRef, useEffect } from "react"
import { HighlightText } from "@/components/highlight-text"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"

gsap.registerPlugin(ScrollTrigger)

export function PatchesSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const headerRef = useRef<HTMLDivElement>(null)
  const principlesRef = useRef<HTMLDivElement>(null)

  const patches = [
    {
      number: "01",
      titleParts: [
        { text: "CREDIT ", highlight: false },
        { text: "REPAIR", highlight: true },
      ],
      description:
        "Business realm financial restoration. Dispute protocols, credit optimization, and debt restructuring systems.",
      realm: "Neuralis",
      align: "left",
    },
    {
      number: "02",
      titleParts: [
        { text: "HEALTHCARE", highlight: true },
        { text: " MATRIX", highlight: false },
      ],
      description:
        "Holistic wellness integration across traditional and alternative modalities. Biometric tracking and optimization.",
      realm: "Neuralis",
      align: "right",
    },
    {
      number: "03",
      titleParts: [
        { text: "EDUCATION ", highlight: false },
        { text: "PROTOCOL", highlight: true },
      ],
      description:
        "Homeschool systems, curriculum design, and knowledge transmission frameworks. Akashic learning paths.",
      realm: "Chaosphere",
      align: "left",
    },
    {
      number: "04",
      titleParts: [
        { text: "BLOCKCHAIN", highlight: true },
        { text: " IDENTITY", highlight: false },
      ],
      description:
        "Decentralized identity verification. NFT credentials, digital sovereignty, and trustless authentication.",
      realm: "Both",
      align: "right",
    },
  ]

  useEffect(() => {
    if (!sectionRef.current || !headerRef.current || !principlesRef.current) return

    const ctx = gsap.context(() => {
      gsap.from(headerRef.current, {
        x: -60,
        opacity: 0,
        duration: 1,
        ease: "power3.out",
        scrollTrigger: {
          trigger: headerRef.current,
          start: "top 85%",
          toggleActions: "play none none reverse",
        },
      })

      const articles = principlesRef.current?.querySelectorAll("article")
      articles?.forEach((article, index) => {
        const isRight = patches[index].align === "right"
        gsap.from(article, {
          x: isRight ? 80 : -80,
          opacity: 0,
          duration: 1,
          ease: "power3.out",
          scrollTrigger: {
            trigger: article,
            start: "top 85%",
            toggleActions: "play none none reverse",
          },
        })
      })
    }, sectionRef)

    return () => ctx.revert()
  }, [])

  return (
    <section
      ref={sectionRef}
      id="patches"
      className="relative py-20 md:py-32 px-6 md:pl-28 md:pr-12"
      aria-labelledby="patches-heading"
    >
      <div
        className="liquid-blob w-72 md:w-96 h-72 md:h-96 bg-purple-500/15 top-1/4 -right-20"
        style={{ animationDelay: "-4s" }}
        aria-hidden="true"
      />

      {/* Section header */}
      <div ref={headerRef} className="mb-16 md:mb-24 relative z-10">
        <span className="font-mono text-xs uppercase tracking-[0.3em] text-accent">04 / Ecosystem</span>
        <h2
          id="patches-heading"
          className="mt-4 font-[var(--font-bebas)] text-4xl md:text-5xl lg:text-7xl tracking-tight"
        >
          NETERU APINAYA PATCHES
        </h2>
        <p className="mt-4 max-w-xl font-mono text-sm md:text-base text-muted-foreground leading-relaxed">
          Modular systems deployed across realms. Each patch maintains Business and Akashic versions with strict
          firewall separation.
        </p>
      </div>

      <div ref={principlesRef} className="space-y-16 md:space-y-24 lg:space-y-32 relative z-10">
        {patches.map((patch, index) => (
          <article
            key={index}
            className={`flex flex-col items-start text-left neon-touch md:${patch.align === "right" ? "items-end text-right" : "items-start text-left"}`}
          >
            {/* Annotation label */}
            <div className="flex flex-wrap items-center gap-3 mb-4">
              <span className="font-mono text-[10px] md:text-xs uppercase tracking-[0.3em] text-muted-foreground">
                {patch.number} / {patch.realm}
              </span>
              <span
                className={`font-mono text-[10px] md:text-xs px-2 md:px-3 py-1 glass-subtle rounded ${
                  patch.realm === "Neuralis"
                    ? "border-cyan-500/40 text-cyan-400"
                    : patch.realm === "Chaosphere"
                      ? "border-orange-500/40 text-orange-400"
                      : "border-purple-500/40 text-purple-400"
                }`}
              >
                {patch.realm.toUpperCase()}
              </span>
            </div>

            <h3 className="font-[var(--font-bebas)] text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-8xl tracking-tight leading-none neon-text">
              {patch.titleParts.map((part, i) =>
                part.highlight ? (
                  <HighlightText key={i} parallaxSpeed={0.6}>
                    {part.text}
                  </HighlightText>
                ) : (
                  <span key={i}>{part.text}</span>
                ),
              )}
            </h3>

            <p className="mt-4 md:mt-6 max-w-md font-mono text-xs md:text-sm lg:text-base text-muted-foreground leading-relaxed">
              {patch.description}
            </p>

            {/* Decorative line */}
            <div
              className={`mt-6 md:mt-8 h-[1px] bg-border w-16 md:w-24 lg:w-48 ml-0 md:${patch.align === "right" ? "mr-0" : "ml-0"}`}
              aria-hidden="true"
            />
          </article>
        ))}
      </div>
    </section>
  )
}
