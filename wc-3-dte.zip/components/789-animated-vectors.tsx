"use client"

import { useEffect, useRef } from "react"

const STUDIO_COLORS = {
  primary: "#FFD700",
  secondary: "#FFA500",
  accent: "#FF6B00",
  glow: "rgba(255, 215, 0, 0.5)",
}

export function AnimatedVectors789() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let animationId: number
    let time = 0

    const resize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }
    resize()
    window.addEventListener("resize", resize)

    // Film reel particles
    const filmReels: { x: number; y: number; rotation: number; speed: number; size: number }[] = []
    for (let i = 0; i < 8; i++) {
      filmReels.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        rotation: Math.random() * Math.PI * 2,
        speed: 0.5 + Math.random() * 1.5,
        size: 20 + Math.random() * 30,
      })
    }

    // Blockchain cubes
    const blockchainCubes: { x: number; y: number; z: number; rotX: number; rotY: number }[] = []
    for (let i = 0; i < 6; i++) {
      blockchainCubes.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        z: Math.random() * 100,
        rotX: Math.random() * Math.PI * 2,
        rotY: Math.random() * Math.PI * 2,
      })
    }

    // Network nodes
    const nodes: { x: number; y: number; pulse: number }[] = []
    for (let i = 0; i < 12; i++) {
      nodes.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        pulse: Math.random() * Math.PI * 2,
      })
    }

    const drawFilmReel = (x: number, y: number, size: number, rotation: number) => {
      ctx.save()
      ctx.translate(x, y)
      ctx.rotate(rotation)

      // Outer ring
      ctx.strokeStyle = STUDIO_COLORS.primary
      ctx.lineWidth = 2
      ctx.shadowColor = STUDIO_COLORS.primary
      ctx.shadowBlur = 10
      ctx.beginPath()
      ctx.arc(0, 0, size, 0, Math.PI * 2)
      ctx.stroke()

      // Inner ring
      ctx.beginPath()
      ctx.arc(0, 0, size * 0.6, 0, Math.PI * 2)
      ctx.stroke()

      // Sprocket holes
      for (let i = 0; i < 8; i++) {
        const angle = (i / 8) * Math.PI * 2
        const hx = Math.cos(angle) * size * 0.8
        const hy = Math.sin(angle) * size * 0.8
        ctx.beginPath()
        ctx.arc(hx, hy, size * 0.1, 0, Math.PI * 2)
        ctx.stroke()
      }

      // Center hub
      ctx.fillStyle = STUDIO_COLORS.primary + "40"
      ctx.beginPath()
      ctx.arc(0, 0, size * 0.3, 0, Math.PI * 2)
      ctx.fill()

      ctx.restore()
    }

    const drawBlockchainCube = (x: number, y: number, size: number, rotX: number, rotY: number) => {
      ctx.save()
      ctx.translate(x, y)

      const s = size * 0.5
      const cos = Math.cos(rotY)
      const sin = Math.sin(rotY)

      ctx.strokeStyle = STUDIO_COLORS.secondary
      ctx.lineWidth = 1.5
      ctx.shadowColor = STUDIO_COLORS.secondary
      ctx.shadowBlur = 8

      // Front face
      ctx.beginPath()
      ctx.moveTo(-s * cos, -s + s * sin * 0.3)
      ctx.lineTo(s * cos, -s - s * sin * 0.3)
      ctx.lineTo(s * cos, s - s * sin * 0.3)
      ctx.lineTo(-s * cos, s + s * sin * 0.3)
      ctx.closePath()
      ctx.stroke()

      // Top face
      ctx.beginPath()
      ctx.moveTo(-s * cos, -s + s * sin * 0.3)
      ctx.lineTo(0, -s * 1.3)
      ctx.lineTo(s * cos, -s - s * sin * 0.3)
      ctx.stroke()

      // Connection lines (blockchain links)
      ctx.strokeStyle = STUDIO_COLORS.primary + "60"
      ctx.setLineDash([5, 5])
      ctx.beginPath()
      ctx.moveTo(s * 1.5, 0)
      ctx.lineTo(s * 3, 0)
      ctx.stroke()
      ctx.setLineDash([])

      ctx.restore()
    }

    const drawClapperboard = (x: number, y: number, size: number, clapAngle: number) => {
      ctx.save()
      ctx.translate(x, y)

      ctx.strokeStyle = STUDIO_COLORS.primary
      ctx.lineWidth = 2
      ctx.shadowColor = STUDIO_COLORS.primary
      ctx.shadowBlur = 10

      // Board base
      ctx.fillStyle = STUDIO_COLORS.dark || "#0D0800"
      ctx.fillRect(-size, -size * 0.3, size * 2, size * 0.8)
      ctx.strokeRect(-size, -size * 0.3, size * 2, size * 0.8)

      // Clapper (animated)
      ctx.save()
      ctx.translate(-size, -size * 0.3)
      ctx.rotate(-clapAngle)
      ctx.fillStyle = STUDIO_COLORS.primary + "40"
      ctx.fillRect(0, -size * 0.15, size * 2, size * 0.15)
      ctx.strokeRect(0, -size * 0.15, size * 2, size * 0.15)

      // Stripes on clapper
      ctx.fillStyle = STUDIO_COLORS.primary
      for (let i = 0; i < 5; i++) {
        ctx.fillRect(i * size * 0.4, -size * 0.15, size * 0.2, size * 0.15)
      }
      ctx.restore()

      ctx.restore()
    }

    const animate = () => {
      time += 0.016
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Draw film reels
      filmReels.forEach((reel, i) => {
        reel.rotation += reel.speed * 0.02
        reel.y += Math.sin(time + i) * 0.3
        drawFilmReel(reel.x, reel.y, reel.size, reel.rotation)
      })

      // Draw blockchain cubes
      blockchainCubes.forEach((cube, i) => {
        cube.rotX += 0.01
        cube.rotY += 0.015
        cube.y += Math.sin(time * 0.5 + i) * 0.5
        drawBlockchainCube(cube.x, cube.y, 30, cube.rotX, cube.rotY)
      })

      // Draw clapperboard
      const clapAngle = Math.abs(Math.sin(time * 2)) * 0.5
      drawClapperboard(canvas.width * 0.85, canvas.height * 0.2, 40, clapAngle)

      // Draw network connections between nodes
      ctx.strokeStyle = STUDIO_COLORS.primary + "20"
      ctx.lineWidth = 1
      nodes.forEach((node, i) => {
        nodes.forEach((otherNode, j) => {
          if (i < j) {
            const dist = Math.hypot(node.x - otherNode.x, node.y - otherNode.y)
            if (dist < 200) {
              ctx.beginPath()
              ctx.moveTo(node.x, node.y)
              ctx.lineTo(otherNode.x, otherNode.y)
              ctx.stroke()
            }
          }
        })
      })

      // Draw pulsing nodes
      nodes.forEach((node) => {
        node.pulse += 0.05
        const pulseSize = 3 + Math.sin(node.pulse) * 2

        ctx.fillStyle = STUDIO_COLORS.primary
        ctx.shadowColor = STUDIO_COLORS.primary
        ctx.shadowBlur = 15
        ctx.beginPath()
        ctx.arc(node.x, node.y, pulseSize, 0, Math.PI * 2)
        ctx.fill()
      })

      // Draw data packets traveling along connections
      const packetProgress = (time * 0.3) % 1
      ctx.fillStyle = STUDIO_COLORS.secondary
      ctx.shadowColor = STUDIO_COLORS.secondary
      ctx.shadowBlur = 10
      nodes.slice(0, 4).forEach((node, i) => {
        const nextNode = nodes[(i + 1) % nodes.length]
        const px = node.x + (nextNode.x - node.x) * packetProgress
        const py = node.y + (nextNode.y - node.y) * packetProgress
        ctx.beginPath()
        ctx.arc(px, py, 4, 0, Math.PI * 2)
        ctx.fill()
      })

      animationId = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener("resize", resize)
      cancelAnimationFrame(animationId)
    }
  }, [])

  return <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-0 opacity-40" aria-hidden="true" />
}
