"use client"

import { useState } from "react"
import { Brain } from "lucide-react"
import { ElevatorOverlay } from "./elevator-overlay"

export function ElevatorButton() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="group fixed bottom-6 right-6 md:bottom-8 md:right-8 z-50 flex items-center gap-3 px-4 py-3 md:px-6 md:py-4 rounded-lg font-mono text-xs uppercase tracking-widest transition-all duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-500 focus-visible:ring-offset-2 focus-visible:ring-offset-black"
        style={{
          background: "linear-gradient(135deg, rgba(0,0,0,0.9), rgba(20,20,20,0.9))",
          border: "2px solid rgba(0, 255, 247, 0.5)",
          boxShadow: "0 0 20px rgba(0, 255, 247, 0.3), 0 0 40px rgba(0, 255, 247, 0.1), inset 0 0 20px rgba(0,0,0,0.5)",
        }}
        aria-label="Open NEURO Concierge building navigation"
      >
        <div
          className="relative w-8 h-8 rounded-full flex items-center justify-center"
          style={{
            background: "linear-gradient(135deg, #00FFF7, #00BFFF)",
            boxShadow: "0 0 15px rgba(0, 255, 247, 0.6)",
          }}
        >
          <Brain className="w-5 h-5 text-black" />
        </div>

        <span
          className="hidden sm:inline"
          style={{
            color: "#00FFF7",
            textShadow: "0 0 10px #00FFF7, 0 0 20px #00FFF7",
          }}
        >
          NEURO
        </span>
      </button>

      <ElevatorOverlay isOpen={isOpen} onClose={() => setIsOpen(false)} />
    </>
  )
}
