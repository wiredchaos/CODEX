"use client"

import { useEffect, useRef } from "react"
import { useRealm } from "@/contexts/realm-context"

export function LiveCircuitry() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const { realmColors } = useRealm()
  const resizeTimeoutRef = useRef<NodeJS.Timeout>()

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const resize = () => {
      if (resizeTimeoutRef.current) {
        clearTimeout(resizeTimeoutRef.current)
      }

      resizeTimeoutRef.current = setTimeout(() => {
        requestAnimationFrame(() => {
          canvas.width = window.innerWidth
          canvas.height = window.innerHeight
        })
      }, 100)
    }

    // Initial size
    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    window.addEventListener("resize", resize, { passive: true })

    interface DataPacket {
      x: number
      y: number
      vx: number
      vy: number
      size: number
      life: number
      maxLife: number
      type: "horizontal" | "vertical"
      color: "cyan" | "red"
    }

    const packets: DataPacket[] = []
    const gridSize = 80

    const colors = {
      cyan: { primary: "#00FFF7", glow: "rgba(0, 255, 247, 0.4)" },
      red: { primary: "#FF1A1A", glow: "rgba(255, 26, 26, 0.4)" },
    }

    const spawnPacket = () => {
      const isHorizontal = Math.random() > 0.5
      const packetColor: "cyan" | "red" = Math.random() < 0.8 ? "cyan" : "red"

      packets.push({
        x: isHorizontal ? -20 : Math.floor(Math.random() * (canvas.width / gridSize)) * gridSize + gridSize / 2,
        y: isHorizontal ? Math.floor(Math.random() * (canvas.height / gridSize)) * gridSize + gridSize / 2 : -20,
        vx: isHorizontal ? 3 + Math.random() * 2 : 0,
        vy: isHorizontal ? 0 : 3 + Math.random() * 2,
        size: 2 + Math.random() * 2,
        life: 0,
        maxLife: 400,
        type: isHorizontal ? "horizontal" : "vertical",
        color: packetColor,
      })
    }

    const drawTronGrid = () => {
      ctx.globalAlpha = 0.08
      ctx.strokeStyle = "#00FFF7"
      ctx.lineWidth = 0.5

      // Vertical lines
      for (let x = 0; x < canvas.width; x += gridSize) {
        ctx.beginPath()
        ctx.moveTo(x, 0)
        ctx.lineTo(x, canvas.height)
        ctx.stroke()
      }

      // Horizontal lines
      for (let y = 0; y < canvas.height; y += gridSize) {
        ctx.beginPath()
        ctx.moveTo(0, y)
        ctx.lineTo(canvas.width, y)
        ctx.stroke()
      }

      ctx.globalAlpha = 0.15
      ctx.fillStyle = "#00FFF7"
      for (let x = 0; x < canvas.width; x += gridSize) {
        for (let y = 0; y < canvas.height; y += gridSize) {
          ctx.beginPath()
          ctx.arc(x, y, 1.5, 0, Math.PI * 2)
          ctx.fill()
        }
      }
      ctx.globalAlpha = 1
    }

    let frameCount = 0
    const animate = () => {
      ctx.fillStyle = "#000000"
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Draw subtle TRON grid
      drawTronGrid()

      frameCount++
      if (frameCount % 40 === 0 && packets.length < 15) {
        spawnPacket()
      }

      // Draw data packets
      for (let i = packets.length - 1; i >= 0; i--) {
        const p = packets[i]
        p.x += p.vx
        p.y += p.vy
        p.life++

        const alpha = Math.min(1, p.life / 30) * Math.max(0, 1 - p.life / p.maxLife)
        const colorSet = colors[p.color]

        // Outer glow
        const gradient = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size * 6)
        gradient.addColorStop(0, colorSet.primary)
        gradient.addColorStop(0.4, colorSet.glow)
        gradient.addColorStop(1, "transparent")

        ctx.globalAlpha = alpha * 0.5
        ctx.fillStyle = gradient
        ctx.beginPath()
        ctx.arc(p.x, p.y, p.size * 6, 0, Math.PI * 2)
        ctx.fill()

        // Core
        ctx.globalAlpha = alpha
        ctx.fillStyle = colorSet.primary
        ctx.shadowColor = colorSet.primary
        ctx.shadowBlur = 20
        ctx.beginPath()
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2)
        ctx.fill()
        ctx.shadowBlur = 0

        // Trail line
        ctx.globalAlpha = alpha * 0.4
        ctx.strokeStyle = colorSet.primary
        ctx.lineWidth = 1.5
        ctx.lineCap = "round"
        ctx.beginPath()
        if (p.type === "horizontal") {
          ctx.moveTo(p.x - 60, p.y)
          ctx.lineTo(p.x, p.y)
        } else {
          ctx.moveTo(p.x, p.y - 60)
          ctx.lineTo(p.x, p.y)
        }
        ctx.stroke()

        // Remove dead packets
        if (p.life > p.maxLife || p.x > canvas.width + 50 || p.y > canvas.height + 50) {
          packets.splice(i, 1)
        }
      }

      ctx.globalAlpha = 1
      requestAnimationFrame(animate)
    }

    const animationId = requestAnimationFrame(animate)

    return () => {
      window.removeEventListener("resize", resize)
      if (resizeTimeoutRef.current) {
        clearTimeout(resizeTimeoutRef.current)
      }
      cancelAnimationFrame(animationId)
    }
  }, [realmColors])

  return <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-[1]" aria-hidden="true" />
}
