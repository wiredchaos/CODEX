"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import {
  ArrowLeft,
  Brain,
  Flame,
  Activity,
  TrendingUp,
  TrendingDown,
  Minus,
  Shield,
  Sword,
  Users,
  Clock,
  BarChart3,
  PieChart,
} from "lucide-react"
import { LiveCircuitry } from "@/components/live-circuitry"

const HEMISPHERE_COLORS = {
  neuralis: "#00FFF7",
  chaosphere: "#FF4500",
  balanced: "#FFD700",
  dark: "#000000",
  success: "#00FF88",
  accent: "#A020F0",
}

interface HemisphereProfile {
  id: string
  user_id: string
  neuralis_index: number
  chaosphere_index: number
  hemisphere: string
  stability_trend: string
  convergence_score: number
  neuralis_7d_avg: number
  chaosphere_7d_avg: number
  neuralis_30d_avg: number
  chaosphere_30d_avg: number
  business_affinity: number
  akashic_affinity: number
  trend_velocity: number
  last_computed_at: string
}

interface HemisphereHistory {
  id: string
  user_id: string
  neuralis_index: number
  chaosphere_index: number
  hemisphere: string
  stability_trend: string
  computed_at: string
}

interface TelemetryEvent {
  id: string
  user_id: string
  event_type: string
  patch: string
  care_score: number
  risk_score: number
  reflection_score: number
  collab_score: number
  rule_score: number
  complexity_score: number
  created_at: string
}

interface RoleData {
  user_id: string
  role: string
  hemisphere: string
  hero_score: number
  npc_score: number
  disruptor_score: number
}

interface Props {
  userId: string
  hemisphereProfile: HemisphereProfile | null
  hemisphereHistory: HemisphereHistory[]
  telemetryEvents: TelemetryEvent[]
  roleData: RoleData | null
}

export function HemisphereDashboardClient({
  userId,
  hemisphereProfile,
  hemisphereHistory,
  telemetryEvents,
  roleData,
}: Props) {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<"overview" | "history" | "telemetry">("overview")

  const neuralisValue = hemisphereProfile?.neuralis_index || 50
  const chaosphereValue = hemisphereProfile?.chaosphere_index || 50
  const dominantHemisphere = hemisphereProfile?.hemisphere || "balanced"
  const stabilityTrend = hemisphereProfile?.stability_trend || "stable"

  const getTrendIcon = (trend: string) => {
    switch (trend?.toLowerCase()) {
      case "rising":
      case "ascending":
        return <TrendingUp className="w-4 h-4" />
      case "falling":
      case "descending":
        return <TrendingDown className="w-4 h-4" />
      default:
        return <Minus className="w-4 h-4" />
    }
  }

  const getHemisphereColor = (hemisphere: string) => {
    switch (hemisphere?.toLowerCase()) {
      case "neuralis":
        return HEMISPHERE_COLORS.neuralis
      case "chaosphere":
        return HEMISPHERE_COLORS.chaosphere
      default:
        return HEMISPHERE_COLORS.balanced
    }
  }

  const getRoleIcon = (role: string) => {
    switch (role?.toLowerCase()) {
      case "hero":
        return <Shield className="w-5 h-5" />
      case "disruptor":
        return <Sword className="w-5 h-5" />
      default:
        return <Users className="w-5 h-5" />
    }
  }

  // Calculate average scores from telemetry
  const avgScores =
    telemetryEvents.length > 0
      ? {
          care: Math.round(telemetryEvents.reduce((a, b) => a + (b.care_score || 0), 0) / telemetryEvents.length),
          risk: Math.round(telemetryEvents.reduce((a, b) => a + (b.risk_score || 0), 0) / telemetryEvents.length),
          reflection: Math.round(
            telemetryEvents.reduce((a, b) => a + (b.reflection_score || 0), 0) / telemetryEvents.length,
          ),
          collab: Math.round(telemetryEvents.reduce((a, b) => a + (b.collab_score || 0), 0) / telemetryEvents.length),
          rule: Math.round(telemetryEvents.reduce((a, b) => a + (b.rule_score || 0), 0) / telemetryEvents.length),
          complexity: Math.round(
            telemetryEvents.reduce((a, b) => a + (b.complexity_score || 0), 0) / telemetryEvents.length,
          ),
        }
      : { care: 0, risk: 0, reflection: 0, collab: 0, rule: 0, complexity: 0 }

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: HEMISPHERE_COLORS.dark }}>
      <LiveCircuitry />

      {/* Grid Background */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${HEMISPHERE_COLORS.neuralis}15 1px, transparent 1px),
            linear-gradient(to bottom, ${HEMISPHERE_COLORS.neuralis}15 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Header */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(0, 0, 0, 0.9)",
          borderColor: `${HEMISPHERE_COLORS.neuralis}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link
                href="/dashboard"
                className="flex items-center gap-2 transition-colors hover:opacity-80"
                style={{ color: HEMISPHERE_COLORS.neuralis }}
              >
                <ArrowLeft className="w-5 h-5" />
                <span className="font-mono text-sm uppercase hidden sm:inline">Dashboard</span>
              </Link>
              <div className="w-px h-6" style={{ background: `${HEMISPHERE_COLORS.neuralis}30` }} />
              <div className="flex items-center gap-2">
                <Brain className="w-6 h-6" style={{ color: HEMISPHERE_COLORS.neuralis }} />
                <h1
                  className="font-display text-xl uppercase tracking-wider"
                  style={{ color: HEMISPHERE_COLORS.neuralis }}
                >
                  Hemisphere Map
                </h1>
              </div>
            </div>
            <div className="text-xs font-mono text-neutral-500">GLOBAL TELEMETRY BUS</div>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Main Hemisphere Visualization */}
        <div
          className="p-6 rounded-2xl mb-8"
          style={{
            background: "rgba(0, 0, 0, 0.6)",
            border: `1px solid ${getHemisphereColor(dominantHemisphere)}30`,
          }}
        >
          <div className="flex flex-col lg:flex-row items-center gap-8">
            {/* Hemisphere Gauge */}
            <div className="relative w-64 h-64">
              {/* Outer ring */}
              <svg className="w-full h-full" viewBox="0 0 200 200">
                {/* Background circle */}
                <circle cx="100" cy="100" r="90" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="12" />

                {/* Neuralis arc (left half) */}
                <circle
                  cx="100"
                  cy="100"
                  r="90"
                  fill="none"
                  stroke={HEMISPHERE_COLORS.neuralis}
                  strokeWidth="12"
                  strokeDasharray={`${(neuralisValue / 100) * 141.3} 282.6`}
                  strokeDashoffset="0"
                  transform="rotate(-90 100 100)"
                  style={{ filter: `drop-shadow(0 0 10px ${HEMISPHERE_COLORS.neuralis})` }}
                />

                {/* Chaosphere arc (right half) */}
                <circle
                  cx="100"
                  cy="100"
                  r="90"
                  fill="none"
                  stroke={HEMISPHERE_COLORS.chaosphere}
                  strokeWidth="12"
                  strokeDasharray={`${(chaosphereValue / 100) * 141.3} 282.6`}
                  strokeDashoffset={`-${141.3 + (neuralisValue / 100) * 141.3}`}
                  transform="rotate(-90 100 100)"
                  style={{ filter: `drop-shadow(0 0 10px ${HEMISPHERE_COLORS.chaosphere})` }}
                />
              </svg>

              {/* Center content */}
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <div className="flex items-center gap-2 mb-2">
                  {dominantHemisphere === "neuralis" ? (
                    <Brain className="w-8 h-8" style={{ color: HEMISPHERE_COLORS.neuralis }} />
                  ) : dominantHemisphere === "chaosphere" ? (
                    <Flame className="w-8 h-8" style={{ color: HEMISPHERE_COLORS.chaosphere }} />
                  ) : (
                    <Activity className="w-8 h-8" style={{ color: HEMISPHERE_COLORS.balanced }} />
                  )}
                </div>
                <div
                  className="font-display text-2xl uppercase"
                  style={{ color: getHemisphereColor(dominantHemisphere) }}
                >
                  {dominantHemisphere}
                </div>
                <div className="flex items-center gap-1 mt-2 text-neutral-400">
                  {getTrendIcon(stabilityTrend)}
                  <span className="font-mono text-xs uppercase">{stabilityTrend}</span>
                </div>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="flex-1 grid grid-cols-2 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl" style={{ background: `${HEMISPHERE_COLORS.neuralis}10` }}>
                <div className="text-3xl font-display" style={{ color: HEMISPHERE_COLORS.neuralis }}>
                  {Math.round(neuralisValue)}
                </div>
                <div className="text-xs font-mono text-neutral-500 uppercase">Neuralis Index</div>
              </div>
              <div className="p-4 rounded-xl" style={{ background: `${HEMISPHERE_COLORS.chaosphere}10` }}>
                <div className="text-3xl font-display" style={{ color: HEMISPHERE_COLORS.chaosphere }}>
                  {Math.round(chaosphereValue)}
                </div>
                <div className="text-xs font-mono text-neutral-500 uppercase">Chaosphere Index</div>
              </div>
              <div className="p-4 rounded-xl" style={{ background: `${HEMISPHERE_COLORS.balanced}10` }}>
                <div className="text-3xl font-display" style={{ color: HEMISPHERE_COLORS.balanced }}>
                  {hemisphereProfile?.convergence_score || 0}
                </div>
                <div className="text-xs font-mono text-neutral-500 uppercase">Convergence</div>
              </div>
              <div className="p-4 rounded-xl" style={{ background: `${HEMISPHERE_COLORS.neuralis}10` }}>
                <div className="text-2xl font-display" style={{ color: HEMISPHERE_COLORS.neuralis }}>
                  {hemisphereProfile?.business_affinity || 0}%
                </div>
                <div className="text-xs font-mono text-neutral-500 uppercase">Business Affinity</div>
              </div>
              <div className="p-4 rounded-xl" style={{ background: `${HEMISPHERE_COLORS.accent}10` }}>
                <div className="text-2xl font-display" style={{ color: HEMISPHERE_COLORS.accent }}>
                  {hemisphereProfile?.akashic_affinity || 0}%
                </div>
                <div className="text-xs font-mono text-neutral-500 uppercase">Akashic Affinity</div>
              </div>
              <div className="p-4 rounded-xl" style={{ background: "rgba(255,255,255,0.05)" }}>
                <div className="text-2xl font-display text-white">{hemisphereProfile?.trend_velocity || 0}</div>
                <div className="text-xs font-mono text-neutral-500 uppercase">Trend Velocity</div>
              </div>
            </div>
          </div>
        </div>

        {/* Role Engine Card */}
        {roleData && (
          <div
            className="p-6 rounded-2xl mb-8"
            style={{
              background: "rgba(0, 0, 0, 0.6)",
              border: `1px solid ${HEMISPHERE_COLORS.success}30`,
            }}
          >
            <h3
              className="font-mono text-sm uppercase tracking-wider mb-4"
              style={{ color: HEMISPHERE_COLORS.success }}
            >
              Role Engine
            </h3>
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
              <div
                className="w-16 h-16 rounded-xl flex items-center justify-center"
                style={{ background: `${HEMISPHERE_COLORS.success}20` }}
              >
                {getRoleIcon(roleData.role)}
              </div>
              <div className="flex-1">
                <div className="font-display text-2xl text-white uppercase mb-2">{roleData.role || "NPC"}</div>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <div className="text-lg font-mono" style={{ color: HEMISPHERE_COLORS.success }}>
                      {Math.round(roleData.hero_score || 0)}
                    </div>
                    <div className="text-xs font-mono text-neutral-500">Hero</div>
                  </div>
                  <div>
                    <div className="text-lg font-mono" style={{ color: HEMISPHERE_COLORS.chaosphere }}>
                      {Math.round(roleData.disruptor_score || 0)}
                    </div>
                    <div className="text-xs font-mono text-neutral-500">Disruptor</div>
                  </div>
                  <div>
                    <div className="text-lg font-mono" style={{ color: HEMISPHERE_COLORS.neuralis }}>
                      {Math.round(roleData.npc_score || 0)}
                    </div>
                    <div className="text-xs font-mono text-neutral-500">NPC</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          {(["overview", "history", "telemetry"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className="px-4 py-2 rounded-lg font-mono text-sm uppercase transition-all"
              style={{
                background: activeTab === tab ? `${HEMISPHERE_COLORS.neuralis}20` : "rgba(0,0,0,0.4)",
                border: `1px solid ${activeTab === tab ? HEMISPHERE_COLORS.neuralis : "rgba(255,255,255,0.1)"}`,
                color: activeTab === tab ? HEMISPHERE_COLORS.neuralis : "#888",
              }}
            >
              {tab === "overview" && <BarChart3 className="w-4 h-4 inline mr-2" />}
              {tab === "history" && <Clock className="w-4 h-4 inline mr-2" />}
              {tab === "telemetry" && <PieChart className="w-4 h-4 inline mr-2" />}
              {tab}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        {activeTab === "overview" && (
          <div
            className="p-6 rounded-2xl"
            style={{
              background: "rgba(0, 0, 0, 0.6)",
              border: `1px solid ${HEMISPHERE_COLORS.neuralis}30`,
            }}
          >
            <h3
              className="font-mono text-sm uppercase tracking-wider mb-4"
              style={{ color: HEMISPHERE_COLORS.neuralis }}
            >
              Telemetry Scores
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
              {[
                { label: "Care", value: avgScores.care, color: HEMISPHERE_COLORS.success },
                { label: "Risk", value: avgScores.risk, color: HEMISPHERE_COLORS.chaosphere },
                { label: "Reflection", value: avgScores.reflection, color: HEMISPHERE_COLORS.neuralis },
                { label: "Collab", value: avgScores.collab, color: HEMISPHERE_COLORS.balanced },
                { label: "Rule", value: avgScores.rule, color: HEMISPHERE_COLORS.accent },
                { label: "Complexity", value: avgScores.complexity, color: "#888" },
              ].map((score) => (
                <div key={score.label} className="text-center">
                  <div className="relative w-16 h-16 mx-auto mb-2">
                    <svg className="w-full h-full" viewBox="0 0 36 36">
                      <circle cx="18" cy="18" r="16" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="3" />
                      <circle
                        cx="18"
                        cy="18"
                        r="16"
                        fill="none"
                        stroke={score.color}
                        strokeWidth="3"
                        strokeDasharray={`${score.value} 100`}
                        strokeLinecap="round"
                        transform="rotate(-90 18 18)"
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="font-mono text-sm" style={{ color: score.color }}>
                        {score.value}
                      </span>
                    </div>
                  </div>
                  <div className="text-xs font-mono text-neutral-500 uppercase">{score.label}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "history" && (
          <div
            className="p-6 rounded-2xl"
            style={{
              background: "rgba(0, 0, 0, 0.6)",
              border: `1px solid ${HEMISPHERE_COLORS.neuralis}30`,
            }}
          >
            <h3
              className="font-mono text-sm uppercase tracking-wider mb-4"
              style={{ color: HEMISPHERE_COLORS.neuralis }}
            >
              Hemisphere History
            </h3>
            {hemisphereHistory.length > 0 ? (
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {hemisphereHistory.map((entry) => (
                  <div
                    key={entry.id}
                    className="flex items-center justify-between p-3 rounded-lg"
                    style={{ background: "rgba(255,255,255,0.03)" }}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="w-2 h-2 rounded-full"
                        style={{ background: getHemisphereColor(entry.hemisphere) }}
                      />
                      <span className="font-mono text-sm text-white capitalize">{entry.hemisphere}</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="font-mono text-xs" style={{ color: HEMISPHERE_COLORS.neuralis }}>
                        N: {Math.round(entry.neuralis_index)}
                      </span>
                      <span className="font-mono text-xs" style={{ color: HEMISPHERE_COLORS.chaosphere }}>
                        C: {Math.round(entry.chaosphere_index)}
                      </span>
                      <span className="font-mono text-xs text-neutral-500">
                        {new Date(entry.computed_at).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-neutral-500 font-mono text-sm">No history data available</p>
            )}
          </div>
        )}

        {activeTab === "telemetry" && (
          <div
            className="p-6 rounded-2xl"
            style={{
              background: "rgba(0, 0, 0, 0.6)",
              border: `1px solid ${HEMISPHERE_COLORS.neuralis}30`,
            }}
          >
            <h3
              className="font-mono text-sm uppercase tracking-wider mb-4"
              style={{ color: HEMISPHERE_COLORS.neuralis }}
            >
              Recent Events ({telemetryEvents.length})
            </h3>
            {telemetryEvents.length > 0 ? (
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {telemetryEvents.slice(0, 20).map((event) => (
                  <div
                    key={event.id}
                    className="flex items-center justify-between p-3 rounded-lg"
                    style={{ background: "rgba(255,255,255,0.03)" }}
                  >
                    <div>
                      <span className="font-mono text-sm text-white">{event.event_type}</span>
                      <span className="font-mono text-xs text-neutral-500 ml-2">{event.patch}</span>
                    </div>
                    <span className="font-mono text-xs text-neutral-500">
                      {new Date(event.created_at).toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-neutral-500 font-mono text-sm">No telemetry events recorded</p>
            )}
          </div>
        )}
      </main>
    </div>
  )
}
