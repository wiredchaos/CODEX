import type React from "react"
import { cn } from "@/lib/utils"

interface NeonBorderProps {
  children: React.ReactNode
  color?: "cyan" | "orange" | "purple" | "red"
  className?: string
}

export function NeonBorder({ children, color = "cyan", className }: NeonBorderProps) {
  const colorClasses = {
    cyan: "border-cyan-500/60 shadow-[0_0_10px_rgba(6,182,212,0.3)] hover:shadow-[0_0_20px_rgba(6,182,212,0.5)]",
    orange: "border-orange-500/60 shadow-[0_0_10px_rgba(249,115,22,0.3)] hover:shadow-[0_0_20px_rgba(249,115,22,0.5)]",
    purple: "border-purple-500/60 shadow-[0_0_10px_rgba(168,85,247,0.3)] hover:shadow-[0_0_20px_rgba(168,85,247,0.5)]",
    red: "border-red-500/60 shadow-[0_0_10px_rgba(239,68,68,0.3)] hover:shadow-[0_0_20px_rgba(239,68,68,0.5)]",
  }

  return (
    <div
      className={cn(
        "border-2 rounded-lg transition-all duration-300 bg-background/20 backdrop-blur-sm",
        colorClasses[color],
        className,
      )}
    >
      {children}
    </div>
  )
}
