"use client"

import { useState, useCallback, useEffect } from "react"
import { useRouter } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronDown, AlertTriangle, X } from "lucide-react"
import type { RouteCard } from "@/types/elevator"

interface ElevatorTravelProps {
  currentFloor: string
  onExitPatch?: () => void
  routeCard?: RouteCard | null
  reducedMotion?: boolean
}

export function ElevatorTravel({ currentFloor, onExitPatch, routeCard, reducedMotion = false }: ElevatorTravelProps) {
  const router = useRouter()
  const [isTransitioning, setIsTransitioning] = useState(false)
  const [phase, setPhase] = useState<"idle" | "seal" | "doors" | "travel">("idle")

  // Panic exit - immediate, no animation
  const panicExit = useCallback(() => {
    if (onExitPatch) onExitPatch()
    router.push("/")
  }, [router, onExitPatch])

  // Full POV travel sequence
  const initiateReturn = useCallback(async () => {
    if (isTransitioning) return
    setIsTransitioning(true)

    // Phase A: Wrap & Seal
    setPhase("seal")
    if (!reducedMotion) {
      await new Promise((r) => setTimeout(r, 800))
    }

    // Call onExitPatch lifecycle
    if (onExitPatch) {
      await Promise.resolve(onExitPatch())
    }

    // Phase B: Doors
    setPhase("doors")
    if (!reducedMotion) {
      await new Promise((r) => setTimeout(r, 1200))
    }

    // Phase C: Travel
    setPhase("travel")
    if (!reducedMotion) {
      await new Promise((r) => setTimeout(r, 600))
    }

    // Navigate
    router.push("/")
  }, [isTransitioning, reducedMotion, onExitPatch, router])

  // Keyboard accessibility
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        panicExit()
      }
    }
    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [panicExit])

  return (
    <>
      {/* Return to Elevator Button - Always Visible */}
      <button
        onClick={initiateReturn}
        disabled={isTransitioning}
        className="fixed bottom-6 right-6 md:bottom-8 md:right-8 z-50 flex items-center gap-3 px-4 py-3 md:px-6 md:py-4 rounded-lg font-mono text-xs uppercase tracking-widest transition-all duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-500 focus-visible:ring-offset-2 focus-visible:ring-offset-black group disabled:opacity-50"
        style={{
          background: "linear-gradient(135deg, rgba(0,0,0,0.95), rgba(10,10,10,0.95))",
          border: "2px solid rgba(0, 255, 247, 0.6)",
          boxShadow: "0 0 20px rgba(0, 255, 247, 0.3), 0 0 40px rgba(0, 255, 247, 0.1), inset 0 0 20px rgba(0,0,0,0.5)",
        }}
        aria-label="Return to Elevator"
      >
        <ChevronDown className="w-5 h-5 transition-transform group-hover:translate-y-1" style={{ color: "#00FFF7" }} />
        <span
          className="hidden sm:inline"
          style={{
            color: "#00FFF7",
            textShadow: "0 0 10px #00FFF7, 0 0 20px #00FFF7",
          }}
        >
          Return to Elevator
        </span>
        <span
          className="absolute -top-2 -right-2 px-2 py-0.5 rounded-full text-[10px] font-bold animate-pulse"
          style={{
            background: "linear-gradient(135deg, #00FFF7, #0088aa)",
            color: "#000",
            boxShadow: "0 0 10px #00FFF7",
          }}
        >
          🛗
        </span>
      </button>

      {/* Panic Exit - ADA First */}
      <button
        onClick={panicExit}
        className="fixed bottom-6 left-6 md:bottom-8 md:left-8 z-50 p-3 rounded-full transition-all duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-red-500"
        style={{
          background: "rgba(255, 0, 0, 0.2)",
          border: "1px solid rgba(255, 0, 0, 0.5)",
        }}
        aria-label="Panic Exit - Instant Return"
        title="Skip Animation (ESC)"
      >
        <AlertTriangle className="w-5 h-5 text-red-500" />
      </button>

      {/* Transition Overlay */}
      <AnimatePresence>
        {isTransitioning && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center"
            style={{ background: "rgba(0,0,0,0.95)" }}
          >
            {/* Skip Animation Button */}
            <button
              onClick={panicExit}
              className="absolute top-4 right-4 p-2 text-gray-500 hover:text-white transition-colors"
              aria-label="Skip Animation"
            >
              <X className="w-6 h-6" />
            </button>

            {/* Phase A: Seal */}
            {phase === "seal" && (
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="text-center"
              >
                <div className="text-cyan-400 font-mono text-sm mb-4">PLAN SEALED</div>
                <div className="text-white text-lg">Re-entering elevator...</div>
                {routeCard && (
                  <motion.div
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.3 }}
                    className="mt-4 p-4 rounded-lg border border-cyan-500/30 bg-cyan-500/10"
                  >
                    <div className="text-xs text-cyan-400 uppercase tracking-wider">Route Card</div>
                    <div className="text-white mt-1">{routeCard.recommendedFloors.length} floors queued</div>
                  </motion.div>
                )}
              </motion.div>
            )}

            {/* Phase B: Doors */}
            {phase === "doors" && (
              <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
                {/* Left Door */}
                <motion.div
                  initial={{ x: 0 }}
                  animate={{ x: "-100%" }}
                  transition={{ duration: 1, ease: "easeInOut" }}
                  className="absolute left-0 top-0 w-1/2 h-full"
                  style={{
                    background: "linear-gradient(90deg, #111 0%, #222 100%)",
                    borderRight: "2px solid #00FFF7",
                  }}
                />
                {/* Right Door */}
                <motion.div
                  initial={{ x: 0 }}
                  animate={{ x: "100%" }}
                  transition={{ duration: 1, ease: "easeInOut" }}
                  className="absolute right-0 top-0 w-1/2 h-full"
                  style={{
                    background: "linear-gradient(270deg, #111 0%, #222 100%)",
                    borderLeft: "2px solid #00FFF7",
                  }}
                />
                {/* Chime indicator */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0, 1, 0] }}
                  transition={{ duration: 0.5, delay: 0.5 }}
                  className="absolute top-8 text-cyan-400 font-mono text-sm"
                >
                  ◆ DING ◆
                </motion.div>
              </div>
            )}

            {/* Phase C: Travel */}
            {phase === "travel" && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center">
                <motion.div
                  animate={{ y: [0, -10, 0] }}
                  transition={{ repeat: Number.POSITIVE_INFINITY, duration: 0.5 }}
                  className="text-6xl mb-4"
                >
                  🛗
                </motion.div>
                <div className="text-cyan-400 font-mono text-sm">{currentFloor.toUpperCase()} → LOBBY</div>
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}

// Hook for patch lifecycle
export function usePatchLifecycle(patchId: string) {
  const [hasEntered, setHasEntered] = useState(false)

  const onEnterPatch = useCallback(() => {
    console.log(`[PATCH] Entering ${patchId}`)
    setHasEntered(true)
    // Telemetry event would fire here
  }, [patchId])

  const onExitPatch = useCallback(() => {
    console.log(`[PATCH] Exiting ${patchId}`)
    // Cleanup, save state, etc.
  }, [patchId])

  const panicExit = useCallback(() => {
    console.log(`[PATCH] PANIC EXIT from ${patchId}`)
    // Immediate cleanup, no animations
  }, [patchId])

  useEffect(() => {
    if (!hasEntered) {
      onEnterPatch()
    }
  }, [hasEntered, onEnterPatch])

  return { onEnterPatch, onExitPatch, panicExit }
}
