"use client"

import { useRealm } from "@/contexts/realm-context"
import { useState, useRef, useEffect } from "react"
import { Expand, RotateCcw, Box, Smartphone, Loader2 } from "lucide-react"

interface WiredModelViewerProps {
  glbUrl: string
  usdzUrl?: string
  title?: string
  description?: string
  realmOverride?: "neuralis" | "chaosphere" | "underground"
  showControls?: boolean
  autoRotate?: boolean
  className?: string
}

export function WiredModelViewer({
  glbUrl,
  usdzUrl,
  title,
  description,
  realmOverride,
  showControls = true,
  autoRotate = true,
  className = "",
}: WiredModelViewerProps) {
  const { realmColors, activeRealm } = useRealm()
  const [isLoading, setIsLoading] = useState(true)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [viewMode, setViewMode] = useState<"3d" | "ar">("3d")
  const containerRef = useRef<HTMLDivElement>(null)
  const modelViewerRef = useRef<HTMLElement>(null)

  // Use realm override or active realm colors
  const effectiveRealm = realmOverride || activeRealm
  const colors = effectiveRealm
    ? {
        neuralis: { primary: "#22d3ee", glow: "rgba(34, 211, 238, 0.4)" },
        chaosphere: { primary: "#f97316", glow: "rgba(249, 115, 22, 0.4)" },
        underground: { primary: "#a855f7", glow: "rgba(168, 85, 247, 0.4)" },
      }[effectiveRealm]
    : { primary: realmColors.primary, glow: realmColors.glow }

  useEffect(() => {
    // Load model-viewer script if not already loaded
    if (!customElements.get("model-viewer")) {
      const script = document.createElement("script")
      script.type = "module"
      script.src = "https://ajax.googleapis.com/ajax/libs/model-viewer/3.4.0/model-viewer.min.js"
      document.head.appendChild(script)
    }
  }, [])

  const handleFullscreen = () => {
    if (containerRef.current) {
      if (!isFullscreen) {
        containerRef.current.requestFullscreen?.()
      } else {
        document.exitFullscreen?.()
      }
      setIsFullscreen(!isFullscreen)
    }
  }

  const handleReset = () => {
    if (modelViewerRef.current) {
      // @ts-ignore - model-viewer methods
      modelViewerRef.current.cameraOrbit = "auto auto auto"
      // @ts-ignore
      modelViewerRef.current.fieldOfView = "auto"
    }
  }

  return (
    <div
      ref={containerRef}
      className={`relative group rounded-xl overflow-hidden ${className}`}
      style={{
        background: "var(--glass-bg)",
        backdropFilter: "blur(var(--glass-blur))",
        border: `1px solid ${colors.primary}33`,
      }}
    >
      {/* Neon border glow effect */}
      <div
        className="absolute inset-0 rounded-xl pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-500"
        style={{
          boxShadow: `0 0 20px ${colors.glow}, 0 0 40px ${colors.glow}, inset 0 0 20px ${colors.glow}`,
          border: `2px solid ${colors.primary}`,
        }}
        aria-hidden="true"
      />

      {/* Animated corner accents */}
      <div
        className="absolute top-0 left-0 w-8 h-8 border-l-2 border-t-2 rounded-tl-xl opacity-60 group-hover:opacity-100 transition-opacity"
        style={{ borderColor: colors.primary }}
        aria-hidden="true"
      />
      <div
        className="absolute top-0 right-0 w-8 h-8 border-r-2 border-t-2 rounded-tr-xl opacity-60 group-hover:opacity-100 transition-opacity"
        style={{ borderColor: colors.primary }}
        aria-hidden="true"
      />
      <div
        className="absolute bottom-0 left-0 w-8 h-8 border-l-2 border-b-2 rounded-bl-xl opacity-60 group-hover:opacity-100 transition-opacity"
        style={{ borderColor: colors.primary }}
        aria-hidden="true"
      />
      <div
        className="absolute bottom-0 right-0 w-8 h-8 border-r-2 border-b-2 rounded-br-xl opacity-60 group-hover:opacity-100 transition-opacity"
        style={{ borderColor: colors.primary }}
        aria-hidden="true"
      />

      {/* Loading state */}
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center z-10 bg-background/80">
          <div className="flex flex-col items-center gap-3">
            <Loader2 className="w-8 h-8 animate-spin" style={{ color: colors.primary }} aria-label="Loading 3D model" />
            <span className="text-sm font-mono" style={{ color: colors.primary }}>
              LOADING ASSET...
            </span>
          </div>
        </div>
      )}

      {/* Model Viewer */}
      <model-viewer
        ref={modelViewerRef as any}
        src={glbUrl}
        ios-src={usdzUrl}
        ar
        ar-modes="scene-viewer quick-look webxr"
        camera-controls
        auto-rotate={autoRotate}
        shadow-intensity="1"
        environment-image="neutral"
        exposure="1"
        onLoad={() => setIsLoading(false)}
        style={{
          width: "100%",
          height: "520px",
          background: "transparent",
          "--poster-color": "transparent",
        }}
        aria-label={title || "3D Model Viewer"}
      >
        {/* AR button slot */}
        <button
          slot="ar-button"
          className="absolute bottom-4 right-4 px-4 py-2 rounded-lg font-mono text-sm font-semibold flex items-center gap-2 neon-touch"
          style={{
            background: `${colors.primary}22`,
            border: `1px solid ${colors.primary}`,
            color: colors.primary,
          }}
          aria-label="View in Augmented Reality"
        >
          <Smartphone className="w-4 h-4" />
          VIEW IN AR
        </button>
      </model-viewer>

      {/* Controls overlay */}
      {showControls && (
        <div className="absolute top-4 left-4 right-4 flex items-start justify-between">
          {/* Title and description */}
          {(title || description) && (
            <div className="glass rounded-lg px-4 py-3 max-w-[60%]">
              {title && (
                <h3 className="font-mono text-base font-bold tracking-wide" style={{ color: colors.primary }}>
                  {title}
                </h3>
              )}
              {description && <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{description}</p>}
            </div>
          )}

          {/* Control buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleReset}
              className="p-3 rounded-lg glass neon-touch transition-all hover:scale-105"
              style={{ borderColor: `${colors.primary}44` }}
              aria-label="Reset camera view"
            >
              <RotateCcw className="w-5 h-5" style={{ color: colors.primary }} />
            </button>
            <button
              onClick={handleFullscreen}
              className="p-3 rounded-lg glass neon-touch transition-all hover:scale-105"
              style={{ borderColor: `${colors.primary}44` }}
              aria-label={isFullscreen ? "Exit fullscreen" : "Enter fullscreen"}
            >
              <Expand className="w-5 h-5" style={{ color: colors.primary }} />
            </button>
          </div>
        </div>
      )}

      {/* View mode indicator */}
      <div
        className="absolute bottom-4 left-4 flex items-center gap-2 px-3 py-2 rounded-lg glass"
        role="status"
        aria-live="polite"
      >
        <Box className="w-4 h-4" style={{ color: colors.primary }} aria-hidden="true" />
        <span className="font-mono text-xs tracking-wider" style={{ color: colors.primary }}>
          {viewMode === "3d" ? "3D PREVIEW" : "AR MODE"}
        </span>
        <div
          className="w-2 h-2 rounded-full animate-pulse"
          style={{ backgroundColor: colors.primary }}
          aria-hidden="true"
        />
      </div>

      {/* Scanline effect */}
      <div
        className="absolute inset-0 pointer-events-none opacity-[0.02]"
        style={{
          backgroundImage: `repeating-linear-gradient(
            0deg,
            transparent,
            transparent 2px,
            ${colors.primary}22 2px,
            ${colors.primary}22 4px
          )`,
        }}
        aria-hidden="true"
      />
    </div>
  )
}
