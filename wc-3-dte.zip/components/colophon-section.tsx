"use client"

import { useRef, useEffect } from "react"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"

gsap.registerPlugin(ScrollTrigger)

export function ColophonSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const headerRef = useRef<HTMLDivElement>(null)
  const gridRef = useRef<HTMLDivElement>(null)
  const footerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!sectionRef.current) return

    const ctx = gsap.context(() => {
      if (headerRef.current) {
        gsap.from(headerRef.current, {
          x: -60,
          opacity: 0,
          duration: 1,
          ease: "power3.out",
          scrollTrigger: {
            trigger: headerRef.current,
            start: "top 85%",
            toggleActions: "play none none reverse",
          },
        })
      }

      if (gridRef.current) {
        const columns = gridRef.current.querySelectorAll(":scope > div")
        gsap.from(columns, {
          y: 40,
          opacity: 0,
          duration: 0.8,
          stagger: 0.1,
          ease: "power3.out",
          scrollTrigger: {
            trigger: gridRef.current,
            start: "top 85%",
            toggleActions: "play none none reverse",
          },
        })
      }

      if (footerRef.current) {
        gsap.from(footerRef.current, {
          y: 20,
          opacity: 0,
          duration: 0.8,
          ease: "power3.out",
          scrollTrigger: {
            trigger: footerRef.current,
            start: "top 95%",
            toggleActions: "play none none reverse",
          },
        })
      }
    }, sectionRef)

    return () => ctx.revert()
  }, [])

  return (
    <section
      ref={sectionRef}
      id="colophon"
      className="relative py-32 pl-6 md:pl-28 pr-6 md:pr-12 border-t border-border/30"
      aria-labelledby="colophon-heading"
    >
      {/* Liquid blobs */}
      <div
        className="liquid-blob w-72 h-72 bg-cyan-500/10 top-20 right-1/4"
        style={{ animationDelay: "-6s" }}
        aria-hidden="true"
      />

      {/* Section header */}
      <div ref={headerRef} className="mb-16 relative z-10">
        <span className="font-mono text-xs uppercase tracking-[0.3em] text-accent">06 / Colophon</span>
        <h2 id="colophon-heading" className="mt-4 font-[var(--font-bebas)] text-5xl md:text-7xl tracking-tight">
          SYSTEM CREDITS
        </h2>
      </div>

      {/* Multi-column layout with glass cards */}
      <div ref={gridRef} className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 md:gap-8 relative z-10">
        {/* Architecture */}
        <div className="col-span-1 glass-subtle p-4 rounded-lg">
          <h4 className="font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4">Architecture</h4>
          <ul className="space-y-2">
            <li className="font-mono text-sm text-foreground/90">WIRED CHAOS META</li>
            <li className="font-mono text-sm text-foreground/90">NEURO META X | NMX</li>
          </ul>
        </div>

        {/* Realms */}
        <div className="col-span-1 glass-subtle p-4 rounded-lg">
          <h4 className="font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4">Realms</h4>
          <ul className="space-y-2">
            <li className="font-mono text-sm text-cyan-400">Neuralis</li>
            <li className="font-mono text-sm text-orange-400">Chaosphere</li>
            <li className="font-mono text-sm text-purple-400">Underground</li>
          </ul>
        </div>

        {/* Stack */}
        <div className="col-span-1 glass-subtle p-4 rounded-lg">
          <h4 className="font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4">Stack</h4>
          <ul className="space-y-2">
            <li className="font-mono text-sm text-foreground/90">Next.js 16</li>
            <li className="font-mono text-sm text-foreground/90">Three.js</li>
            <li className="font-mono text-sm text-foreground/90">Vercel</li>
          </ul>
        </div>

        {/* Frequencies */}
        <div className="col-span-1 glass-subtle p-4 rounded-lg">
          <h4 className="font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4">Frequencies</h4>
          <ul className="space-y-2">
            <li className="font-mono text-sm text-foreground/90">589 Hz — Core</li>
            <li className="font-mono text-sm text-foreground/90">432 Hz — Business</li>
            <li className="font-mono text-sm text-foreground/90">33 Hz — Underground</li>
          </ul>
        </div>

        {/* Timeline */}
        <div className="col-span-1 glass-subtle p-4 rounded-lg">
          <h4 className="font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4">Timeline</h4>
          <ul className="space-y-2">
            <li className="font-mono text-sm text-foreground/90">Age XI Active</li>
            <li className="font-mono text-sm text-foreground/90">Black Ledger 2025.X</li>
          </ul>
        </div>

        {/* Protocol */}
        <div className="col-span-1 glass-subtle p-4 rounded-lg">
          <h4 className="font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4">Protocol</h4>
          <ul className="space-y-2">
            <li className="font-mono text-sm text-foreground/90">Anti-Moloch Logic</li>
            <li className="font-mono text-sm text-foreground/90">No-Touch Infra</li>
          </ul>
        </div>
      </div>

      {/* Bottom copyright with glass effect */}
      <div
        ref={footerRef}
        className="mt-24 pt-8 border-t border-border/20 flex flex-col md:flex-row md:items-center md:justify-between gap-4 relative z-10"
      >
        <p className="font-mono text-xs text-muted-foreground uppercase tracking-widest">
          © 2025 WIRED CHAOS META. NEURO META X | NMX. All rights reserved.
        </p>
        <p className="font-mono text-xs text-muted-foreground">
          Built for the NEURO Era. 33 Shards. 589 Frequency. Infinite Timelines.
        </p>
      </div>
    </section>
  )
}
