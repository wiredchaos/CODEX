"use client"

import { useState, useEffect } from "react"
import { useRouter, usePathname } from "next/navigation"
import { Brain, ArrowRight, ArrowLeft, X, CheckCircle } from "lucide-react"

interface TourPlan {
  track: "business" | "akashic" | "both"
  depth: "quick" | "standard" | "deep"
  floors: string[]
}

export function TourGuide() {
  const router = useRouter()
  const pathname = usePathname()
  const [tourPlan, setTourPlan] = useState<TourPlan | null>(null)
  const [tourIndex, setTourIndex] = useState(0)
  const [isMinimized, setIsMinimized] = useState(false)
  const [isComplete, setIsComplete] = useState(false)

  useEffect(() => {
    const stored = localStorage.getItem("wc_tour_plan")
    const index = localStorage.getItem("wc_tour_index")
    if (stored) {
      setTourPlan(JSON.parse(stored))
      setTourIndex(index ? Number.parseInt(index) : 0)
    }
  }, [])

  useEffect(() => {
    if (tourPlan && tourPlan.floors[tourIndex] === pathname) {
      // User arrived at current tour stop
    }
  }, [pathname, tourPlan, tourIndex])

  const nextStop = () => {
    if (tourPlan && tourIndex < tourPlan.floors.length - 1) {
      const newIndex = tourIndex + 1
      setTourIndex(newIndex)
      localStorage.setItem("wc_tour_index", newIndex.toString())
      router.push(tourPlan.floors[newIndex])
    } else {
      setIsComplete(true)
      localStorage.removeItem("wc_tour_plan")
      localStorage.removeItem("wc_tour_index")
    }
  }

  const prevStop = () => {
    if (tourPlan && tourIndex > 0) {
      const newIndex = tourIndex - 1
      setTourIndex(newIndex)
      localStorage.setItem("wc_tour_index", newIndex.toString())
      router.push(tourPlan.floors[newIndex])
    }
  }

  const exitTour = () => {
    localStorage.removeItem("wc_tour_plan")
    localStorage.removeItem("wc_tour_index")
    setTourPlan(null)
  }

  if (!tourPlan || isComplete) return null

  const currentFloor = tourPlan.floors[tourIndex]
  const progress = ((tourIndex + 1) / tourPlan.floors.length) * 100
  const trackColor = tourPlan.track === "akashic" ? "#A020F0" : "#00FFF7"

  if (isMinimized) {
    return (
      <button
        onClick={() => setIsMinimized(false)}
        className="fixed bottom-20 right-4 z-[90] w-12 h-12 rounded-full flex items-center justify-center"
        style={{
          background: `linear-gradient(135deg, ${trackColor}, ${tourPlan.track === "akashic" ? "#8B00FF" : "#00BFFF"})`,
          boxShadow: `0 0 20px ${trackColor}60`,
        }}
      >
        <Brain className="w-6 h-6 text-black" />
      </button>
    )
  }

  return (
    <div
      className="fixed bottom-20 right-4 z-[90] w-72 rounded-xl overflow-hidden"
      style={{
        background: "rgba(0,0,0,0.95)",
        border: `1px solid ${trackColor}40`,
        boxShadow: `0 0 30px ${trackColor}20`,
      }}
    >
      {/* Header */}
      <div
        className="flex items-center justify-between px-4 py-2"
        style={{ background: `${trackColor}20`, borderBottom: `1px solid ${trackColor}30` }}
      >
        <div className="flex items-center gap-2">
          <Brain className="w-4 h-4" style={{ color: trackColor }} />
          <span className="font-mono text-xs uppercase" style={{ color: trackColor }}>
            NEURO Guide
          </span>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={() => setIsMinimized(true)} className="p-1 text-neutral-500 hover:text-white">
            <ArrowRight className="w-4 h-4" />
          </button>
          <button onClick={exitTour} className="p-1 text-neutral-500 hover:text-red-400">
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Progress */}
      <div className="h-1 bg-neutral-800">
        <div className="h-full transition-all duration-500" style={{ width: `${progress}%`, background: trackColor }} />
      </div>

      {/* Content */}
      <div className="p-4">
        <p className="text-neutral-500 text-xs font-mono mb-1">
          Stop {tourIndex + 1} of {tourPlan.floors.length}
        </p>
        <p className="text-white font-mono text-sm mb-4">{currentFloor.replace("/", "").toUpperCase() || "LOBBY"}</p>

        <div className="flex gap-2">
          <button
            onClick={prevStop}
            disabled={tourIndex === 0}
            className="flex-1 py-2 rounded-lg font-mono text-xs uppercase flex items-center justify-center gap-1 border border-neutral-700 text-neutral-400 disabled:opacity-30"
          >
            <ArrowLeft className="w-3 h-3" />
            Back
          </button>
          <button
            onClick={nextStop}
            className="flex-1 py-2 rounded-lg font-mono text-xs uppercase flex items-center justify-center gap-1"
            style={{
              background: trackColor,
              color: "#000",
            }}
          >
            {tourIndex === tourPlan.floors.length - 1 ? (
              <>
                <CheckCircle className="w-3 h-3" />
                Finish
              </>
            ) : (
              <>
                Next
                <ArrowRight className="w-3 h-3" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  )
}
