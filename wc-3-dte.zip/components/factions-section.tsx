"use client"

import { useRef, useEffect, useState } from "react"
import { cn } from "@/lib/utils"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"

gsap.registerPlugin(ScrollTrigger)

const factions = [
  {
    title: "Etherion Assembly",
    domain: "Cosmic Order",
    description: "Guardians of universal balance and celestial mechanics.",
    sigil: "◇",
  },
  {
    title: "First Cipher",
    domain: "Ancient Knowledge",
    description: "Keepers of the 33 shards scattered across reality.",
    sigil: "△",
  },
  {
    title: "Auron Pact",
    domain: "Golden Protocol",
    description: "Masters of economic alchemy and resource transmutation.",
    sigil: "○",
  },
  {
    title: "Eastern Directorate",
    domain: "Silent Operations",
    description: "Shadow network of intelligence and strategic control.",
    sigil: "□",
  },
  {
    title: "Legacy Houses",
    domain: "Bloodline Authority",
    description: "Ancient families preserving forbidden genealogies.",
    sigil: "⬡",
  },
  {
    title: "Undernet Syndicates",
    domain: "Underground Networks",
    description: "Decentralized resistance operating below the surface.",
    sigil: "◆",
  },
]

export function FactionsSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const headerRef = useRef<HTMLDivElement>(null)
  const gridRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!sectionRef.current || !headerRef.current || !gridRef.current) return

    const ctx = gsap.context(() => {
      gsap.fromTo(
        headerRef.current,
        { x: -60, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 1,
          ease: "power3.out",
          scrollTrigger: {
            trigger: headerRef.current,
            start: "top 90%",
            toggleActions: "play none none reverse",
          },
        },
      )

      const cards = gridRef.current?.querySelectorAll("article")
      if (cards && cards.length > 0) {
        gsap.set(cards, { y: 60, opacity: 0 })
        gsap.to(cards, {
          y: 0,
          opacity: 1,
          duration: 0.8,
          stagger: 0.1,
          ease: "power3.out",
          scrollTrigger: {
            trigger: gridRef.current,
            start: "top 90%",
            toggleActions: "play none none reverse",
          },
        })
      }
    }, sectionRef)

    return () => ctx.revert()
  }, [])

  return (
    <section
      ref={sectionRef}
      id="factions"
      className="relative py-20 md:py-32 px-6 md:pl-28 md:pr-12"
      aria-labelledby="factions-heading"
    >
      <div
        className="liquid-blob w-56 md:w-72 h-56 md:h-72 bg-cyan-500/15 -top-10 left-1/4"
        style={{ animationDelay: "-7s" }}
        aria-hidden="true"
      />
      <div
        className="liquid-blob w-40 md:w-56 h-40 md:h-56 bg-orange-500/15 bottom-20 right-1/4"
        style={{ animationDelay: "-12s" }}
        aria-hidden="true"
      />

      <div
        ref={headerRef}
        className="mb-12 md:mb-16 flex flex-col md:flex-row md:items-end justify-between gap-4 relative z-10"
      >
        <div>
          <span className="font-mono text-xs uppercase tracking-[0.3em] text-accent">03 / Core Factions</span>
          <h2
            id="factions-heading"
            className="mt-4 font-[var(--font-bebas)] text-4xl md:text-5xl lg:text-7xl tracking-tight"
          >
            THE SIX PILLARS
          </h2>
        </div>
        <p className="max-w-xs font-mono text-sm md:text-base text-muted-foreground leading-relaxed md:text-right">
          Power structures operating across both Neuralis and Chaosphere realms.
        </p>
      </div>

      <div
        ref={gridRef}
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4 relative z-10"
        role="list"
      >
        {factions.map((faction, index) => (
          <FactionCard key={faction.title} faction={faction} index={index} />
        ))}
      </div>
    </section>
  )
}

function FactionCard({
  faction,
  index,
}: {
  faction: (typeof factions)[number]
  index: number
}) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <article
      role="listitem"
      tabIndex={0}
      className={cn(
        "group relative glass-card neon-touch card-neon p-5 md:p-6 transition-all duration-500 cursor-pointer overflow-hidden",
        isHovered && "border-accent/60 bg-accent/5",
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onFocus={() => setIsHovered(true)}
      onBlur={() => setIsHovered(false)}
    >
      {/* Background layer */}
      <div
        className={cn(
          "absolute inset-0 bg-accent/5 transition-opacity duration-500",
          isHovered ? "opacity-100" : "opacity-0",
        )}
        aria-hidden="true"
      />

      {/* Content */}
      <div className="relative z-10">
        <div className="flex items-start justify-between mb-3 md:mb-4">
          <span className="font-mono text-[10px] md:text-xs uppercase tracking-widest text-muted-foreground">
            {faction.domain}
          </span>
          <span
            className={cn(
              "text-xl md:text-2xl transition-colors duration-300",
              isHovered ? "text-accent" : "text-muted-foreground/60",
            )}
            aria-hidden="true"
          >
            {faction.sigil}
          </span>
        </div>

        <h3
          className={cn(
            "font-[var(--font-bebas)] text-xl md:text-2xl lg:text-3xl tracking-tight transition-colors duration-300 neon-text",
            isHovered ? "text-accent" : "text-foreground",
          )}
        >
          {faction.title}
        </h3>
      </div>

      {/* Description - reveals on hover */}
      <div className="relative z-10 mt-3 md:mt-4">
        <p
          className={cn(
            "font-mono text-xs md:text-sm text-muted-foreground leading-relaxed transition-all duration-500",
            isHovered ? "opacity-100 translate-y-0" : "opacity-60 translate-y-0",
          )}
        >
          {faction.description}
        </p>
      </div>

      {/* Index marker */}
      <span
        className={cn(
          "absolute bottom-3 md:bottom-4 right-3 md:right-4 font-mono text-xs transition-colors duration-300",
          isHovered ? "text-accent" : "text-muted-foreground/60",
        )}
        aria-hidden="true"
      >
        {String(index + 1).padStart(2, "0")}
      </span>
    </article>
  )
}
