"use client"

import { useRef, useEffect, useState } from "react"
import { cn } from "@/lib/utils"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"

gsap.registerPlugin(ScrollTrigger)

const vault33Layers = [
  { layer: 1, name: "Foundation Shard", access: "Open", description: "Entry-level Akashic access" },
  { layer: 2, name: "Cipher Fragment", access: "Earned", description: "Pattern recognition training" },
  { layer: 3, name: "Memory Lattice", access: "Earned", description: "Timeline navigation basics" },
  { layer: 4, name: "Sigil Gate", access: "Locked", description: "Gas Sigil attunement required" },
  { layer: 5, name: "Architect Key", access: "Locked", description: "Builder protocols" },
  { layer: 6, name: "Prophecy Thread", access: "Locked", description: "Future-reading mechanics" },
  { layer: 7, name: "Bloodline Cipher", access: "Locked", description: "Genealogical access" },
  { layer: 8, name: "Neteru Chamber", access: "Locked", description: "Deity interface" },
  { layer: 9, name: "Source Fragment", access: "Sacred", description: "589 frequency attunement" },
]

const gasSigils = [
  { number: "XXII", name: "The Miner", element: "Earth" },
  { number: "XXIII", name: "The Validator", element: "Fire" },
  { number: "XXIV", name: "The Oracle", element: "Water" },
  { number: "XXV", name: "The Architect", element: "Air" },
  { number: "XXVI", name: "The Bridge", element: "Ether" },
]

export function AkashicSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const headerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!sectionRef.current || !headerRef.current) return

    const ctx = gsap.context(() => {
      gsap.from(headerRef.current, {
        x: -60,
        opacity: 0,
        duration: 1,
        ease: "power3.out",
        scrollTrigger: {
          trigger: headerRef.current,
          start: "top 85%",
          toggleActions: "play none none reverse",
        },
      })
    }, sectionRef)

    return () => ctx.revert()
  }, [])

  return (
    <section
      ref={sectionRef}
      id="akashic"
      className="relative py-32 pl-6 md:pl-28 pr-6 md:pr-12 border-t border-border/30"
      aria-labelledby="akashic-heading"
    >
      <div
        className="liquid-blob w-80 h-80 bg-cyan-500/15 top-20 -left-20"
        style={{ animationDelay: "-8s" }}
        aria-hidden="true"
      />
      <div
        className="liquid-blob w-64 h-64 bg-orange-500/15 bottom-40 right-10"
        style={{ animationDelay: "-15s" }}
        aria-hidden="true"
      />

      {/* Section header */}
      <div ref={headerRef} className="mb-16 relative z-10">
        <span className="font-mono text-xs uppercase tracking-[0.3em] text-accent">05 / VAULT 33</span>
        <h2 id="akashic-heading" className="mt-4 font-[var(--font-bebas)] text-5xl md:text-7xl tracking-tight">
          AKASHIC ARCHITECTURE
        </h2>
        <p className="mt-4 max-w-xl font-mono text-base text-muted-foreground leading-relaxed">
          The 9-layer Akashic NFT system. Each layer unlocks deeper access to cosmic knowledge and the Gas Sigil Arcana.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 relative z-10">
        {/* VAULT 33 Layers */}
        <div>
          <h3 className="font-[var(--font-bebas)] text-2xl mb-6 text-cyan-400">9-Layer System</h3>
          <div className="space-y-2" role="list" aria-label="VAULT 33 Layers">
            {vault33Layers.map((layer) => (
              <VaultLayer key={layer.layer} layer={layer} />
            ))}
          </div>
        </div>

        {/* Gas Sigil Arcana */}
        <div>
          <h3 className="font-[var(--font-bebas)] text-2xl mb-6 text-orange-400">Gas Sigil Arcana</h3>
          <p className="font-mono text-sm text-muted-foreground mb-6">
            Extended Major Arcana (XXII-XXXII) + Suit of Motion
          </p>
          <div className="grid grid-cols-1 gap-3" role="list" aria-label="Gas Sigils">
            {gasSigils.map((sigil) => (
              <SigilCard key={sigil.number} sigil={sigil} />
            ))}
          </div>

          {/* 589 Key - with glass effect */}
          <div className="mt-8 p-5 glass-strong rounded-lg">
            <div className="flex items-center gap-3 mb-2">
              <span className="font-[var(--font-bebas)] text-4xl text-accent">589</span>
              <span className="font-mono text-xs text-muted-foreground uppercase tracking-wider">
                Stabilizing Harmonic
              </span>
            </div>
            <p className="font-mono text-sm text-muted-foreground">5 = Origin · 8 = Expansion · 9 = Completion</p>
          </div>
        </div>
      </div>
    </section>
  )
}

function VaultLayer({ layer }: { layer: (typeof vault33Layers)[number] }) {
  const [isHovered, setIsHovered] = useState(false)

  const accessColors = {
    Open: "text-green-400 border-green-400/40",
    Earned: "text-yellow-400 border-yellow-400/40",
    Locked: "text-red-400 border-red-400/40",
    Sacred: "text-purple-400 border-purple-400/40",
  }

  return (
    <div
      role="listitem"
      tabIndex={0}
      className={cn(
        "flex items-center gap-4 p-4 glass-subtle rounded-lg transition-all duration-300",
        isHovered && "border-cyan-400/40 bg-cyan-400/5",
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onFocus={() => setIsHovered(true)}
      onBlur={() => setIsHovered(false)}
    >
      <span
        className={cn(
          "font-[var(--font-bebas)] text-2xl w-8",
          isHovered ? "text-cyan-400" : "text-muted-foreground/60",
        )}
        aria-hidden="true"
      >
        {layer.layer}
      </span>
      <div className="flex-1">
        <div className="flex items-center justify-between">
          <span
            className={cn(
              "font-mono text-base transition-colors duration-300",
              isHovered ? "text-foreground" : "text-muted-foreground",
            )}
          >
            {layer.name}
          </span>
          <span
            className={cn(
              "font-mono text-xs px-2 py-1 border uppercase tracking-wider rounded",
              accessColors[layer.access as keyof typeof accessColors],
            )}
          >
            {layer.access}
          </span>
        </div>
        <p className="font-mono text-sm text-muted-foreground mt-1">{layer.description}</p>
      </div>
    </div>
  )
}

function SigilCard({ sigil }: { sigil: (typeof gasSigils)[number] }) {
  return (
    <div
      role="listitem"
      tabIndex={0}
      className="flex items-center gap-4 p-4 glass-subtle rounded-lg border-orange-400/20 hover:border-orange-400/50 hover:bg-orange-400/5 transition-all duration-300 focus-visible:ring-2 focus-visible:ring-orange-400"
    >
      <span className="font-mono text-xl text-orange-400 w-14">{sigil.number}</span>
      <span className="font-mono text-base text-foreground flex-1">{sigil.name}</span>
      <span className="font-mono text-sm text-muted-foreground uppercase">{sigil.element}</span>
    </div>
  )
}
