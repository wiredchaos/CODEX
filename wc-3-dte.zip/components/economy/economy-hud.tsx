"use client"

import { useState, useEffect } from "react"
import { Wallet, Coins, ArrowUpDown, Gift, X } from "lucide-react"
import { Button } from "@/components/ui/button"

interface EconomyHUDProps {
  userId?: string
  compact?: boolean
}

export function EconomyHUD({ userId = "demo_user", compact = false }: EconomyHUDProps) {
  const [credits, setCredits] = useState(0)
  const [isOpen, setIsOpen] = useState(false)
  const [faucetMessage, setFaucetMessage] = useState("")

  useEffect(() => {
    // In production, fetch from API
    const stored = localStorage.getItem(`wc_credits_${userId}`)
    if (stored) setCredits(Number.parseInt(stored, 10))
  }, [userId])

  const claimFaucet = () => {
    const newCredits = credits + 1000
    setCredits(newCredits)
    localStorage.setItem(`wc_credits_${userId}`, String(newCredits))
    setFaucetMessage("Claimed 1,000 WC Credits!")
    setTimeout(() => setFaucetMessage(""), 3000)
  }

  if (compact) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="flex items-center gap-2 px-3 py-1.5 bg-black/60 border border-cyan-500/30 rounded-full text-cyan-400 text-sm hover:bg-cyan-500/10 transition-colors"
      >
        <Coins className="w-4 h-4" />
        <span className="font-mono">{credits.toLocaleString()}</span>
        <span className="text-cyan-400/60">WCC</span>
      </button>
    )
  }

  return (
    <>
      {/* Compact trigger */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-20 right-4 z-40 flex items-center gap-2 px-4 py-2 bg-black/80 border border-cyan-500/30 rounded-full text-cyan-400 hover:bg-cyan-500/10 transition-colors backdrop-blur-sm"
      >
        <Wallet className="w-5 h-5" />
        <span className="font-mono text-lg">{credits.toLocaleString()}</span>
        <span className="text-cyan-400/60 text-sm">WCC</span>
      </button>

      {/* Expanded panel */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-md bg-black/90 border border-cyan-500/30 rounded-2xl p-6 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold text-cyan-400">WC Economy</h2>
              <button onClick={() => setIsOpen(false)} className="text-gray-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Balance */}
            <div className="p-4 bg-cyan-500/10 border border-cyan-500/20 rounded-xl">
              <p className="text-sm text-cyan-400/60 mb-1">Your Balance</p>
              <p className="text-3xl font-mono font-bold text-cyan-400">
                {credits.toLocaleString()} <span className="text-lg">WCC</span>
              </p>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-2 gap-3">
              <Button onClick={claimFaucet} className="flex items-center gap-2 bg-green-600 hover:bg-green-700">
                <Gift className="w-4 h-4" />
                Faucet
              </Button>
              <Button
                variant="outline"
                className="flex items-center gap-2 border-cyan-500/30 text-cyan-400 bg-transparent"
              >
                <ArrowUpDown className="w-4 h-4" />
                Swap
              </Button>
            </div>

            {faucetMessage && <p className="text-center text-green-400 text-sm">{faucetMessage}</p>}

            {/* Simulated Assets */}
            <div className="space-y-2">
              <p className="text-sm text-gray-400">Simulated Assets</p>
              <div className="space-y-1 text-sm">
                {["BTC", "ETH", "SOL", "DOGE", "XRP"].map((asset) => (
                  <div key={asset} className="flex justify-between text-gray-300">
                    <span>{asset}</span>
                    <span className="text-cyan-400/60">0.00</span>
                  </div>
                ))}
              </div>
            </div>

            <p className="text-xs text-center text-gray-500">Demo mode. No real assets or transactions.</p>
          </div>
        </div>
      )}
    </>
  )
}
