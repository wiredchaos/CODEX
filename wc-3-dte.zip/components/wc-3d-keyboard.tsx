"use client"

import { useState, useCallback, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"

interface KeyConfig {
  key: string
  label: string
  width?: number
  cluster: "left" | "center" | "right" | "nav" | "numpad"
}

const KEYBOARD_LAYOUT: KeyConfig[][] = [
  // Row 1 - Function keys
  [
    { key: "Escape", label: "ESC", cluster: "left" },
    { key: "F1", label: "F1", cluster: "left" },
    { key: "F2", label: "F2", cluster: "left" },
    { key: "F3", label: "F3", cluster: "left" },
    { key: "F4", label: "F4", cluster: "center" },
    { key: "F5", label: "F5", cluster: "center" },
    { key: "F6", label: "F6", cluster: "center" },
    { key: "F7", label: "F7", cluster: "center" },
    { key: "F8", label: "F8", cluster: "right" },
    { key: "F9", label: "F9", cluster: "right" },
    { key: "F10", label: "F10", cluster: "right" },
    { key: "F11", label: "F11", cluster: "right" },
    { key: "F12", label: "F12", cluster: "right" },
  ],
  // Row 2 - Numbers
  [
    { key: "`", label: "`", cluster: "left" },
    { key: "1", label: "1", cluster: "left" },
    { key: "2", label: "2", cluster: "left" },
    { key: "3", label: "3", cluster: "left" },
    { key: "4", label: "4", cluster: "left" },
    { key: "5", label: "5", cluster: "center" },
    { key: "6", label: "6", cluster: "center" },
    { key: "7", label: "7", cluster: "right" },
    { key: "8", label: "8", cluster: "right" },
    { key: "9", label: "9", cluster: "right" },
    { key: "0", label: "0", cluster: "right" },
    { key: "-", label: "-", cluster: "right" },
    { key: "=", label: "=", cluster: "right" },
    { key: "Backspace", label: "⌫", width: 2, cluster: "right" },
  ],
  // Row 3 - QWERTY
  [
    { key: "Tab", label: "TAB", width: 1.5, cluster: "left" },
    { key: "q", label: "Q", cluster: "left" },
    { key: "w", label: "W", cluster: "left" },
    { key: "e", label: "E", cluster: "left" },
    { key: "r", label: "R", cluster: "left" },
    { key: "t", label: "T", cluster: "center" },
    { key: "y", label: "Y", cluster: "center" },
    { key: "u", label: "U", cluster: "right" },
    { key: "i", label: "I", cluster: "right" },
    { key: "o", label: "O", cluster: "right" },
    { key: "p", label: "P", cluster: "right" },
    { key: "[", label: "[", cluster: "right" },
    { key: "]", label: "]", cluster: "right" },
    { key: "\\", label: "\\", width: 1.5, cluster: "right" },
  ],
  // Row 4 - ASDF
  [
    { key: "CapsLock", label: "CAPS", width: 1.75, cluster: "left" },
    { key: "a", label: "A", cluster: "left" },
    { key: "s", label: "S", cluster: "left" },
    { key: "d", label: "D", cluster: "left" },
    { key: "f", label: "F", cluster: "left" },
    { key: "g", label: "G", cluster: "center" },
    { key: "h", label: "H", cluster: "center" },
    { key: "j", label: "J", cluster: "right" },
    { key: "k", label: "K", cluster: "right" },
    { key: "l", label: "L", cluster: "right" },
    { key: ";", label: ";", cluster: "right" },
    { key: "'", label: "'", cluster: "right" },
    { key: "Enter", label: "ENTER", width: 2.25, cluster: "right" },
  ],
  // Row 5 - ZXCV
  [
    { key: "Shift", label: "SHIFT", width: 2.25, cluster: "left" },
    { key: "z", label: "Z", cluster: "left" },
    { key: "x", label: "X", cluster: "left" },
    { key: "c", label: "C", cluster: "left" },
    { key: "v", label: "V", cluster: "center" },
    { key: "b", label: "B", cluster: "center" },
    { key: "n", label: "N", cluster: "center" },
    { key: "m", label: "M", cluster: "right" },
    { key: ",", label: ",", cluster: "right" },
    { key: ".", label: ".", cluster: "right" },
    { key: "/", label: "/", cluster: "right" },
    { key: "Shift", label: "SHIFT", width: 2.75, cluster: "right" },
  ],
  // Row 6 - Bottom
  [
    { key: "Control", label: "CTRL", width: 1.25, cluster: "left" },
    { key: "Meta", label: "⌘", width: 1.25, cluster: "left" },
    { key: "Alt", label: "ALT", width: 1.25, cluster: "left" },
    { key: " ", label: "SPACE", width: 6.25, cluster: "center" },
    { key: "Alt", label: "ALT", width: 1.25, cluster: "right" },
    { key: "Meta", label: "⌘", width: 1.25, cluster: "right" },
    { key: "ContextMenu", label: "☰", width: 1.25, cluster: "right" },
    { key: "Control", label: "CTRL", width: 1.25, cluster: "right" },
  ],
]

const clusterColors = {
  left: "from-cyan-500/20 to-cyan-600/10",
  center: "from-purple-500/20 to-purple-600/10",
  right: "from-red-500/20 to-red-600/10",
  nav: "from-amber-500/20 to-amber-600/10",
  numpad: "from-green-500/20 to-green-600/10",
}

const clusterGlow = {
  left: "0 0 20px rgba(6, 182, 212, 0.3)",
  center: "0 0 20px rgba(168, 85, 247, 0.3)",
  right: "0 0 20px rgba(239, 68, 68, 0.3)",
  nav: "0 0 20px rgba(245, 158, 11, 0.3)",
  numpad: "0 0 20px rgba(34, 197, 94, 0.3)",
}

interface WC3DKeyboardProps {
  onKeyPress?: (key: string) => void
  onInput?: (value: string) => void
  placeholder?: string
  className?: string
  showInput?: boolean
}

export function WC3DKeyboard({
  onKeyPress,
  onInput,
  placeholder = "Type here...",
  className = "",
  showInput = true,
}: WC3DKeyboardProps) {
  const [pressedKeys, setPressedKeys] = useState<Set<string>>(new Set())
  const [inputValue, setInputValue] = useState("")
  const [isMounted, setIsMounted] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  const handleKeyDown = useCallback(
    (key: string) => {
      setPressedKeys((prev) => new Set(prev).add(key.toLowerCase()))

      if (key === "Backspace") {
        setInputValue((prev) => prev.slice(0, -1))
      } else if (key === "Enter") {
        onInput?.(inputValue)
      } else if (key.length === 1) {
        setInputValue((prev) => prev + key)
      }

      onKeyPress?.(key)
    },
    [inputValue, onKeyPress, onInput],
  )

  const handleKeyUp = useCallback((key: string) => {
    setPressedKeys((prev) => {
      const next = new Set(prev)
      next.delete(key.toLowerCase())
      return next
    })
  }, [])

  // Physical keyboard support
  useEffect(() => {
    const onPhysicalKeyDown = (e: KeyboardEvent) => {
      handleKeyDown(e.key)
    }
    const onPhysicalKeyUp = (e: KeyboardEvent) => {
      handleKeyUp(e.key)
    }

    window.addEventListener("keydown", onPhysicalKeyDown)
    window.addEventListener("keyup", onPhysicalKeyUp)
    return () => {
      window.removeEventListener("keydown", onPhysicalKeyDown)
      window.removeEventListener("keyup", onPhysicalKeyUp)
    }
  }, [handleKeyDown, handleKeyUp])

  useEffect(() => {
    onInput?.(inputValue)
  }, [inputValue, onInput])

  if (!isMounted) {
    return (
      <div className={`w-full ${className}`}>
        <div className="h-[300px] bg-black/50 rounded-xl animate-pulse flex items-center justify-center">
          <span className="text-cyan-500/50 text-sm">Loading 3D Keyboard...</span>
        </div>
      </div>
    )
  }

  return (
    <div ref={containerRef} className={`w-full ${className}`}>
      {showInput && (
        <div className="mb-4 relative">
          <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 via-purple-500/20 to-red-500/20 rounded-lg blur-xl" />
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder={placeholder}
            className="relative w-full px-4 py-3 bg-black/80 border border-cyan-500/30 rounded-lg text-white placeholder:text-gray-500 focus:outline-none focus:border-cyan-500/60 font-mono"
          />
        </div>
      )}

      <div
        className="relative p-4 rounded-xl overflow-hidden"
        style={{
          background: "linear-gradient(145deg, rgba(0,0,0,0.9), rgba(10,10,20,0.95))",
          boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.8), inset 0 1px 0 rgba(255,255,255,0.05)",
          transform: "perspective(1000px) rotateX(5deg)",
        }}
      >
        {/* Keyboard glow effect */}
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-0 left-0 w-1/3 h-full bg-gradient-to-r from-cyan-500/10 to-transparent" />
          <div className="absolute top-0 left-1/3 w-1/3 h-full bg-gradient-to-r from-purple-500/10 via-purple-500/10 to-transparent" />
          <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-l from-red-500/10 to-transparent" />
        </div>

        <div className="relative space-y-1">
          {KEYBOARD_LAYOUT.map((row, rowIndex) => (
            <div key={rowIndex} className="flex gap-1 justify-center">
              {row.map((keyConfig, keyIndex) => {
                const isPressed = pressedKeys.has(keyConfig.key.toLowerCase())
                const width = keyConfig.width || 1

                return (
                  <motion.button
                    key={`${rowIndex}-${keyIndex}`}
                    className={`
                      relative flex items-center justify-center
                      rounded-md border border-white/10
                      text-xs font-medium text-white/80
                      transition-all duration-75
                      bg-gradient-to-b ${clusterColors[keyConfig.cluster]}
                    `}
                    style={{
                      width: `${width * 40}px`,
                      height: "40px",
                      boxShadow: isPressed
                        ? `inset 0 2px 4px rgba(0,0,0,0.5), ${clusterGlow[keyConfig.cluster]}`
                        : "0 4px 6px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.1)",
                      transform: isPressed ? "translateY(2px)" : "translateY(0)",
                    }}
                    onMouseDown={() => handleKeyDown(keyConfig.key)}
                    onMouseUp={() => handleKeyUp(keyConfig.key)}
                    onMouseLeave={() => handleKeyUp(keyConfig.key)}
                    whileTap={{ scale: 0.95 }}
                  >
                    <span
                      className={`
                        transition-all duration-75
                        ${isPressed ? "text-white" : "text-white/70"}
                      `}
                    >
                      {keyConfig.label}
                    </span>

                    <AnimatePresence>
                      {isPressed && (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.8 }}
                          className="absolute inset-0 rounded-md"
                          style={{
                            background: `radial-gradient(circle at center, ${
                              keyConfig.cluster === "left"
                                ? "rgba(6, 182, 212, 0.4)"
                                : keyConfig.cluster === "center"
                                  ? "rgba(168, 85, 247, 0.4)"
                                  : "rgba(239, 68, 68, 0.4)"
                            }, transparent)`,
                          }}
                        />
                      )}
                    </AnimatePresence>
                  </motion.button>
                )
              })}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

// Hook for using 3D keyboard anywhere
export function useWC3DKeyboard() {
  const [isOpen, setIsOpen] = useState(false)
  const [inputValue, setInputValue] = useState("")

  const open = useCallback(() => setIsOpen(true), [])
  const close = useCallback(() => setIsOpen(false), [])
  const toggle = useCallback(() => setIsOpen((prev) => !prev), [])

  return {
    isOpen,
    inputValue,
    setInputValue,
    open,
    close,
    toggle,
    KeyboardComponent: isOpen ? WC3DKeyboard : null,
  }
}

export default WC3DKeyboard
