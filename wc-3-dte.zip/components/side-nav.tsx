"use client"

import { useState, useEffect } from "react"
import { cn } from "@/lib/utils"
import { useRealm } from "@/contexts/realm-context"
import { useRouter } from "next/navigation"

const navItems = [
  { id: "hero", label: "Index" },
  { id: "realms", label: "Realms" },
  { id: "timeline", label: "Timeline" },
  { id: "factions", label: "Factions" },
  { id: "patches", label: "Patches" },
  { id: "xr-gallery", label: "XR Assets" },
  { id: "colophon", label: "Colophon" },
]

const floorLinks = [
  // CHAOS OS
  { id: "chaos-os", label: "CHAOS OS", color: "#8B5CF6", route: "/chaos-os" },
  // Core Floors
  { id: "789", label: "789 Studios", color: "#FFD700", route: "/789" },
  { id: "333", label: "33.3FM Signal", color: "#00BFFF", route: "/333" },
  { id: "vault33", label: "VAULT 33", color: "#A020F0", route: "/vault33" },
  // Training & Games
  { id: "hrm", label: "HRM Training", color: "#00FF88", route: "/hrm" },
  { id: "npc", label: "NPC Engine", color: "#FF6B6B", route: "/npc" },
  // Analytics
  { id: "hemisphere", label: "Hemisphere", color: "#FF4500", route: "/hemisphere" },
  { id: "globe", label: "Globe Explorer", color: "#00CED1", route: "/globe" },
  // Admin
  { id: "funnels", label: "WL Funnels", color: "#00FFF7", route: "/admin/funnels" },
]

export function SideNav() {
  const [activeSection, setActiveSection] = useState("hero")
  const { activeRealm, realmColors } = useRealm()
  const router = useRouter()

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id)
          }
        })
      },
      { threshold: 0.3 },
    )

    navItems.forEach(({ id }) => {
      const element = document.getElementById(id)
      if (element) observer.observe(element)
    })

    return () => observer.disconnect()
  }, [])

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <nav
      className="fixed left-0 top-0 z-50 h-screen w-16 md:w-24 hidden md:flex flex-col justify-center glass-strong border-r realm-transition"
      style={{
        borderColor: `${realmColors.primary}30`,
        boxShadow: `inset -5px 0 20px ${realmColors.glow}`,
      }}
      aria-label="Section navigation"
    >
      <div className="absolute top-6 left-1/2 -translate-x-1/2">
        <div
          className="w-5 h-5 rounded-full transition-all duration-500"
          style={{
            backgroundColor: realmColors.primary,
            boxShadow: `0 0 10px ${realmColors.primary}, 0 0 20px ${realmColors.primary}, 0 0 40px ${realmColors.primary}`,
          }}
          aria-hidden="true"
        />
      </div>

      <div className="flex flex-col gap-6 px-4">
        {navItems.map(({ id, label }) => {
          const isActive = activeSection === id
          return (
            <button
              key={id}
              onClick={() => scrollToSection(id)}
              className="group relative flex items-center gap-3 focus-visible:ring-2 focus-visible:ring-accent rounded-sm p-1"
              aria-label={`Navigate to ${label} section`}
              aria-current={isActive ? "true" : undefined}
            >
              <span
                className={cn("h-3 w-3 rounded-full transition-all duration-300 realm-transition")}
                style={{
                  backgroundColor: isActive ? realmColors.primary : `${realmColors.primary}40`,
                  boxShadow: isActive
                    ? `0 0 8px ${realmColors.primary}, 0 0 16px ${realmColors.primary}, 0 0 24px ${realmColors.primary}`
                    : "none",
                  transform: isActive ? "scale(1.25)" : "scale(1)",
                }}
                aria-hidden="true"
              />
              <span
                className={cn(
                  "absolute left-6 font-mono text-xs uppercase tracking-widest opacity-0 transition-all duration-200 group-hover:opacity-100 group-hover:left-8 whitespace-nowrap realm-transition",
                )}
                style={{
                  color: isActive ? realmColors.primary : "#a3a3a3",
                  textShadow: isActive ? `0 0 10px ${realmColors.primary}, 0 0 20px ${realmColors.primary}` : "none",
                }}
              >
                {label}
              </span>
            </button>
          )
        })}

        {/* Floor Links */}
        <div className="mt-4 pt-4 border-t border-neutral-800 space-y-4">
          {floorLinks.map((floor) => (
            <button
              key={floor.id}
              onClick={() => router.push(floor.route)}
              className="group relative flex items-center gap-3 focus-visible:ring-2 rounded-sm p-1 w-full neon-touch"
              style={{
                focusVisibleRingColor: floor.color,
              }}
              aria-label={`Navigate to ${floor.label}`}
            >
              <span
                className="h-3 w-3 rounded-full transition-all duration-300"
                style={{
                  backgroundColor: floor.color,
                  boxShadow: `0 0 8px ${floor.color}, 0 0 16px ${floor.color}`,
                }}
                aria-hidden="true"
              />
              <span
                className="absolute left-6 font-mono text-xs uppercase tracking-widest opacity-0 transition-all duration-200 group-hover:opacity-100 group-hover:left-8 whitespace-nowrap"
                style={{
                  color: floor.color,
                  textShadow: `0 0 10px ${floor.color}, 0 0 20px ${floor.color}`,
                }}
              >
                {floor.label}
              </span>
            </button>
          ))}
        </div>
      </div>

      {activeRealm && (
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2">
          <span
            className="font-mono text-xs uppercase tracking-widest -rotate-90 origin-center block whitespace-nowrap neon-text-bright"
            style={{
              color: realmColors.primary,
              textShadow: `0 0 5px ${realmColors.primary}, 0 0 10px ${realmColors.primary}, 0 0 20px ${realmColors.primary}`,
            }}
          >
            {activeRealm}
          </span>
        </div>
      )}
    </nav>
  )
}
