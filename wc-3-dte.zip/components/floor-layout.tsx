"use client"

import type { ReactNode } from "react"
import { ElevatorTravel, usePatchLifecycle } from "./elevator-travel"

interface FloorLayoutProps {
  children: ReactNode
  patchId: string
  floorName: string
  backgroundColor?: string
}

export function FloorLayout({ children, patchId, floorName, backgroundColor = "#000" }: FloorLayoutProps) {
  const { onExitPatch } = usePatchLifecycle(patchId)

  return (
    <div className="min-h-screen relative" style={{ backgroundColor }}>
      {children}
      <ElevatorTravel currentFloor={floorName} onExitPatch={onExitPatch} />
    </div>
  )
}

// Floor-specific wrappers for common use
export function Floor333Layout({ children }: { children: ReactNode }) {
  return (
    <FloorLayout patchId="patch_33_3fm_dogechain" floorName="33.3FM" backgroundColor="#000">
      {children}
    </FloorLayout>
  )
}

export function Floor789Layout({ children }: { children: ReactNode }) {
  return (
    <FloorLayout patchId="patch_789_studios" floorName="789" backgroundColor="#0D0800">
      {children}
    </FloorLayout>
  )
}

export function FloorFENLayout({ children }: { children: ReactNode }) {
  return (
    <FloorLayout patchId="patch_fen" floorName="FEN" backgroundColor="#0D000D">
      {children}
    </FloorLayout>
  )
}

export function FloorVault33Layout({ children }: { children: ReactNode }) {
  return (
    <FloorLayout patchId="patch_vault33" floorName="VAULT33" backgroundColor="#050010">
      {children}
    </FloorLayout>
  )
}

export function FloorHRMLayout({ children }: { children: ReactNode }) {
  return (
    <FloorLayout patchId="patch_hrm_games" floorName="HRM" backgroundColor="#000D0D">
      {children}
    </FloorLayout>
  )
}

export function FloorNPCLayout({ children }: { children: ReactNode }) {
  return (
    <FloorLayout patchId="patch_npc" floorName="NPC" backgroundColor="#000">
      {children}
    </FloorLayout>
  )
}

export function FloorMallLayout({ children }: { children: ReactNode }) {
  return (
    <FloorLayout patchId="patch_mall" floorName="MALL" backgroundColor="#000">
      {children}
    </FloorLayout>
  )
}

export function FloorCreditRepairLayout({ children }: { children: ReactNode }) {
  return (
    <FloorLayout patchId="patch_credit_repair" floorName="CREDIT" backgroundColor="#000010">
      {children}
    </FloorLayout>
  )
}

export function FloorNeuraLayout({ children }: { children: ReactNode }) {
  return (
    <FloorLayout patchId="patch_neura" floorName="NEURA" backgroundColor="#050509">
      {children}
    </FloorLayout>
  )
}

export function FloorGlobeLayout({ children }: { children: ReactNode }) {
  return (
    <FloorLayout patchId="patch_globe" floorName="GLOBE" backgroundColor="#000">
      {children}
    </FloorLayout>
  )
}

export function FloorGammaLayout({ children }: { children: ReactNode }) {
  return (
    <FloorLayout patchId="patch_gamma" floorName="GAMMA" backgroundColor="#000">
      {children}
    </FloorLayout>
  )
}
