"use client"

import { useRef, useMemo, useEffect } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { Points, PointMaterial, OrbitControls } from "@react-three/drei"
import * as THREE from "three"

function NeuralBrain() {
  const brainRef = useRef<THREE.Group>(null)
  const veinsRef = useRef<THREE.Points>(null)
  const pulseRef = useRef<THREE.Points>(null)
  const silverRef = useRef<THREE.Points>(null)

  const brainPositions = useMemo(() => {
    const positions = []
    const count = 4000
    const radius = 1.8

    for (let i = 0; i < count; i++) {
      const phi = Math.acos(-1 + (2 * i) / count)
      const theta = Math.sqrt(count * Math.PI) * phi
      const wrinkle = Math.sin(phi * 10) * 0.1 + Math.cos(theta * 8) * 0.08
      const r = radius + wrinkle

      const x = r * Math.cos(theta) * Math.sin(phi)
      const y = r * Math.sin(theta) * Math.sin(phi) * 1.15
      const z = r * Math.cos(phi)

      positions.push(x, y, z)
    }

    return new Float32Array(positions)
  }, [])

  const veinPositions = useMemo(() => {
    const veins = []
    const veinCount = 32

    for (let v = 0; v < veinCount; v++) {
      const startPhi = Math.random() * Math.PI
      const startTheta = Math.random() * Math.PI * 2

      for (let i = 0; i < 100; i++) {
        const t = i / 100
        const phi = startPhi + Math.sin(t * 5 + v) * 0.6
        const theta = startTheta + t * 2.5 + Math.cos(t * 4) * 0.4
        const radius = 1.88 + Math.sin(t * 8) * 0.06

        const x = radius * Math.cos(theta) * Math.sin(phi)
        const y = radius * Math.sin(theta) * Math.sin(phi) * 1.15
        const z = radius * Math.cos(phi)

        veins.push(x, y, z)
      }
    }

    return new Float32Array(veins)
  }, [])

  const silverVeins = useMemo(() => {
    const veins = []
    const veinCount = 20

    for (let v = 0; v < veinCount; v++) {
      const startPhi = Math.random() * Math.PI
      const startTheta = Math.random() * Math.PI * 2

      for (let i = 0; i < 70; i++) {
        const t = i / 70
        const phi = startPhi + Math.cos(t * 6 + v * 0.7) * 0.5
        const theta = startTheta + t * 2 + Math.sin(t * 5) * 0.5
        const radius = 1.92 + Math.cos(t * 10) * 0.04

        const x = radius * Math.cos(theta) * Math.sin(phi)
        const y = radius * Math.sin(theta) * Math.sin(phi) * 1.15
        const z = radius * Math.cos(phi)

        veins.push(x, y, z)
      }
    }

    return new Float32Array(veins)
  }, [])

  // Pulsing energy nodes
  const pulsePositions = useMemo(() => {
    const pulses = []
    for (let i = 0; i < 150; i++) {
      const phi = Math.random() * Math.PI
      const theta = Math.random() * Math.PI * 2
      const radius = 1.95 + Math.random() * 0.1

      const x = radius * Math.cos(theta) * Math.sin(phi)
      const y = radius * Math.sin(theta) * Math.sin(phi) * 1.15
      const z = radius * Math.cos(phi)

      pulses.push(x, y, z)
    }
    return new Float32Array(pulses)
  }, [])

  useFrame((state) => {
    const time = state.clock.getElapsedTime()

    if (brainRef.current) {
      brainRef.current.rotation.y = time * 0.06
      brainRef.current.rotation.x = Math.sin(time * 0.04) * 0.08
    }

    if (veinsRef.current) {
      const material = veinsRef.current.material as THREE.PointsMaterial
      material.size = 0.035 + Math.sin(time * 2.5) * 0.01
      material.opacity = 0.8 + Math.sin(time * 3) * 0.15
    }

    if (silverRef.current) {
      const material = silverRef.current.material as THREE.PointsMaterial
      material.opacity = 0.5 + Math.sin(time * 2 + 1) * 0.2
    }

    // Energy node pulse
    if (pulseRef.current) {
      const material = pulseRef.current.material as THREE.PointsMaterial
      material.size = 0.05 + Math.sin(time * 4) * 0.025
      material.opacity = 0.7 + Math.sin(time * 5) * 0.25
    }
  })

  return (
    <group ref={brainRef}>
      <Points positions={brainPositions} stride={3} frustumCulled={false}>
        <PointMaterial
          transparent
          color="#0a0a0a"
          size={0.022}
          sizeAttenuation={true}
          depthWrite={false}
          opacity={0.95}
        />
      </Points>

      <mesh>
        <sphereGeometry args={[1.6, 64, 64]} />
        <meshStandardMaterial color="#050505" roughness={1} metalness={0} />
      </mesh>

      <Points ref={veinsRef} positions={veinPositions} stride={3} frustumCulled={false}>
        <PointMaterial
          transparent
          color="#00FFF7"
          size={0.035}
          sizeAttenuation={true}
          depthWrite={false}
          opacity={0.9}
          blending={THREE.AdditiveBlending}
        />
      </Points>

      <Points ref={silverRef} positions={silverVeins} stride={3} frustumCulled={false}>
        <PointMaterial
          transparent
          color="#E8E8E8"
          size={0.028}
          sizeAttenuation={true}
          depthWrite={false}
          opacity={0.6}
          blending={THREE.AdditiveBlending}
        />
      </Points>

      <Points ref={pulseRef} positions={pulsePositions} stride={3} frustumCulled={false}>
        <PointMaterial
          transparent
          color="#00FFF7"
          size={0.06}
          sizeAttenuation={true}
          depthWrite={false}
          opacity={0.85}
          blending={THREE.AdditiveBlending}
        />
      </Points>

      <mesh>
        <sphereGeometry args={[0.4, 32, 32]} />
        <meshBasicMaterial color="#00FFF7" transparent opacity={0.2} />
      </mesh>
    </group>
  )
}

function DataRings() {
  const ringsRef = useRef<THREE.Group>(null)

  const ringPositions = useMemo(() => {
    const positions = []
    const ringCount = 2
    const pointsPerRing = 100

    for (let r = 0; r < ringCount; r++) {
      const radius = 2.8 + r * 0.4
      for (let i = 0; i < pointsPerRing; i++) {
        const angle = (i / pointsPerRing) * Math.PI * 2
        positions.push(Math.cos(angle) * radius, (r - 0.5) * 0.4, Math.sin(angle) * radius)
      }
    }

    return new Float32Array(positions)
  }, [])

  useFrame((state) => {
    if (ringsRef.current) {
      ringsRef.current.rotation.y = state.clock.getElapsedTime() * 0.1
      ringsRef.current.rotation.x = Math.sin(state.clock.getElapsedTime() * 0.08) * 0.15
    }
  })

  return (
    <group ref={ringsRef}>
      <Points positions={ringPositions} stride={3} frustumCulled={false}>
        <PointMaterial
          transparent
          color="#00FFF7"
          size={0.015}
          sizeAttenuation={true}
          depthWrite={false}
          opacity={0.3}
          blending={THREE.AdditiveBlending}
        />
      </Points>
    </group>
  )
}

function FloatingData() {
  const ref = useRef<THREE.Points>(null)

  const positions = useMemo(() => {
    const pos = []
    for (let i = 0; i < 80; i++) {
      const angle = Math.random() * Math.PI * 2
      const radius = 3.5 + Math.random() * 1.5
      const height = (Math.random() - 0.5) * 4
      pos.push(Math.cos(angle) * radius, height, Math.sin(angle) * radius)
    }
    return new Float32Array(pos)
  }, [])

  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.y = state.clock.getElapsedTime() * 0.08
    }
  })

  return (
    <Points ref={ref} positions={positions} stride={3} frustumCulled={false}>
      <PointMaterial
        transparent
        color="#00FFF7"
        size={0.025}
        sizeAttenuation={true}
        depthWrite={false}
        opacity={0.35}
        blending={THREE.AdditiveBlending}
      />
    </Points>
  )
}

function BrainScene() {
  return (
    <>
      <ambientLight intensity={0.1} />
      <pointLight position={[5, 5, 5]} intensity={0.3} color="#00FFF7" />
      <pointLight position={[-5, -3, -5]} intensity={0.15} color="#00FFF7" />
      <NeuralBrain />
      <DataRings />
      <FloatingData />
      <OrbitControls
        enableZoom={false}
        enablePan={false}
        autoRotate
        autoRotateSpeed={0.25}
        minPolarAngle={Math.PI * 0.3}
        maxPolarAngle={Math.PI * 0.7}
      />
    </>
  )
}

export function GlobeViewer() {
  useEffect(() => {
    const handleError = (e: ErrorEvent) => {
      if (
        e.message === "ResizeObserver loop completed with undelivered notifications." ||
        e.message === "ResizeObserver loop limit exceeded"
      ) {
        e.stopImmediatePropagation()
      }
    }

    window.addEventListener("error", handleError)

    return () => {
      window.removeEventListener("error", handleError)
    }
  }, [])

  return (
    <Canvas camera={{ position: [0, 0, 6], fov: 45 }} resize={{ debounce: 100 }} gl={{ antialias: true, alpha: true }}>
      <BrainScene />
    </Canvas>
  )
}
