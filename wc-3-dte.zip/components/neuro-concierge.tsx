"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Brain, ArrowRight, Sparkles, Building2 } from "lucide-react"
import Image from "next/image"

interface NeuroConciergeProps {
  onComplete: () => void
  onSkip: () => void
}

const MICRO_INTAKE_QUESTIONS = [
  {
    id: "intent",
    question: "What brings you to WIRED CHAOS today?",
    options: [
      { label: "Explore the ecosystem", value: "explore", track: "both" },
      { label: "Business tools & services", value: "business", track: "business" },
      { label: "Creative & media production", value: "creative", track: "business" },
      { label: "Deeper knowledge & archives", value: "akashic", track: "akashic" },
    ],
  },
  {
    id: "industry",
    question: "Which area resonates most with you?",
    options: [
      { label: "Finance / Credit / Wealth", value: "finance", track: "business" },
      { label: "Media / Entertainment / OTT", value: "media", track: "business" },
      { label: "Technology / AI / Blockchain", value: "tech", track: "both" },
      { label: "Education / Research / History", value: "education", track: "akashic" },
    ],
  },
  {
    id: "skill",
    question: "How would you describe your experience level?",
    options: [
      { label: "Just getting started", value: "beginner", depth: "quick" },
      { label: "Some experience", value: "intermediate", depth: "standard" },
      { label: "Advanced practitioner", value: "advanced", depth: "deep" },
      { label: "Expert / Builder", value: "expert", depth: "deep" },
    ],
  },
  {
    id: "mode",
    question: "How do you prefer to learn?",
    options: [
      { label: "Show me visually", value: "visual", mode: "visual" },
      { label: "Guide me step-by-step", value: "guided", mode: "guided" },
      { label: "Let me explore freely", value: "free", mode: "free" },
      { label: "Deep dive with context", value: "deep", mode: "deep" },
    ],
  },
]

export function NeuroConcierge({ onComplete, onSkip }: NeuroConciergeProps) {
  const router = useRouter()
  const [stage, setStage] = useState<"welcome" | "intake" | "plan">("welcome")
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Record<string, string>>({})
  const [tourPlan, setTourPlan] = useState<{
    track: "business" | "akashic" | "both"
    depth: "quick" | "standard" | "deep"
    floors: string[]
  } | null>(null)

  const handleAnswer = (questionId: string, value: string) => {
    const newAnswers = { ...answers, [questionId]: value }
    setAnswers(newAnswers)

    if (currentQuestion < MICRO_INTAKE_QUESTIONS.length - 1) {
      setCurrentQuestion((prev) => prev + 1)
    } else {
      generateTourPlan(newAnswers)
    }
  }

  const generateTourPlan = (finalAnswers: Record<string, string>) => {
    let businessScore = 0
    let akashicScore = 0

    Object.entries(finalAnswers).forEach(([key, value]) => {
      const question = MICRO_INTAKE_QUESTIONS.find((q) => q.id === key)
      const option = question?.options.find((o) => o.value === value)
      if (option?.track === "business") businessScore += 2
      if (option?.track === "akashic") akashicScore += 2
      if (option?.track === "both") {
        businessScore += 1
        akashicScore += 1
      }
    })

    const track = akashicScore > businessScore + 2 ? "akashic" : businessScore > akashicScore + 2 ? "business" : "both"

    const depthOption = MICRO_INTAKE_QUESTIONS.find((q) => q.id === "skill")?.options.find(
      (o) => o.value === finalAnswers.skill,
    )
    const depth = (depthOption?.depth as "quick" | "standard" | "deep") || "standard"

    const floors =
      track === "business"
        ? ["/789", "/333", "/credit-repair", "/mall"]
        : track === "akashic"
          ? ["/fen", "/vault33", "/fen/akira"]
          : ["/789", "/333", "/fen", "/vault33"]

    setTourPlan({ track, depth, floors })
    setStage("plan")
  }

  const startTour = () => {
    if (tourPlan) {
      localStorage.setItem("wc_tour_plan", JSON.stringify(tourPlan))
      localStorage.setItem("wc_tour_index", "0")
      router.push(tourPlan.floors[0])
      onComplete()
    }
  }

  if (stage === "welcome") {
    return (
      <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black">
        <div className="absolute inset-0 opacity-30">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: `radial-gradient(circle at 50% 50%, #00FFF720 0%, transparent 50%)`,
            }}
          />
        </div>

        <div className="relative z-10 w-full max-w-lg mx-4 text-center">
          {/* NEURO Avatar */}
          <div className="mb-8">
            <div
              className="w-32 h-32 mx-auto rounded-full flex items-center justify-center relative"
              style={{
                background: "linear-gradient(135deg, #00FFF7, #A020F0)",
                boxShadow: "0 0 60px rgba(0, 255, 247, 0.5)",
              }}
            >
              <Image
                src="/images/8ac1f692-4c57-47da-86ee.jpeg"
                alt="NEURO Prompt Command"
                width={120}
                height={120}
                className="rounded-full object-cover"
              />
              <div
                className="absolute inset-[-8px] border-2 border-dashed rounded-full animate-spin"
                style={{ borderColor: "rgba(0, 255, 247, 0.3)", animationDuration: "15s" }}
              />
            </div>
          </div>

          <h1
            className="font-display text-4xl uppercase mb-4"
            style={{
              color: "#00FFF7",
              textShadow: "0 0 30px rgba(0, 255, 247, 0.8)",
            }}
          >
            NEURO CONCIERGE
          </h1>

          <p className="text-neutral-400 mb-8 font-mono text-sm">
            Welcome to WIRED CHAOS META. I am your guide through the dual realms.
          </p>

          <div className="flex flex-col gap-4">
            <button
              onClick={() => setStage("intake")}
              className="w-full py-4 px-6 rounded-xl font-mono text-sm uppercase tracking-wider transition-all flex items-center justify-center gap-3"
              style={{
                background: "linear-gradient(135deg, #00FFF7, #00BFFF)",
                color: "#000",
                boxShadow: "0 0 30px rgba(0, 255, 247, 0.5)",
              }}
            >
              <Sparkles className="w-5 h-5" />
              Start Guided Tour
              <ArrowRight className="w-5 h-5" />
            </button>

            <button
              onClick={onSkip}
              className="w-full py-4 px-6 rounded-xl font-mono text-sm uppercase tracking-wider transition-all flex items-center justify-center gap-3 border border-neutral-700 text-neutral-400 hover:border-cyan-500/50 hover:text-cyan-400"
            >
              <Building2 className="w-5 h-5" />
              Skip → Elevator
            </button>
          </div>

          <p className="text-neutral-600 text-xs mt-6 font-mono">
            You can access the elevator at any time during your visit
          </p>
        </div>
      </div>
    )
  }

  if (stage === "intake") {
    const question = MICRO_INTAKE_QUESTIONS[currentQuestion]

    return (
      <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black">
        <div className="relative z-10 w-full max-w-lg mx-4">
          {/* Progress */}
          <div className="flex gap-2 mb-8 justify-center">
            {MICRO_INTAKE_QUESTIONS.map((_, i) => (
              <div
                key={i}
                className="h-1 w-12 rounded-full transition-all"
                style={{
                  background: i <= currentQuestion ? "#00FFF7" : "#333",
                  boxShadow: i <= currentQuestion ? "0 0 10px #00FFF7" : "none",
                }}
              />
            ))}
          </div>

          {/* NEURO mini avatar */}
          <div className="flex justify-center mb-6">
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center"
              style={{
                background: "linear-gradient(135deg, #00FFF7, #A020F0)",
                boxShadow: "0 0 30px rgba(0, 255, 247, 0.4)",
              }}
            >
              <Brain className="w-8 h-8 text-black" />
            </div>
          </div>

          <h2
            className="text-xl font-display uppercase text-center mb-8"
            style={{ color: "#00FFF7", textShadow: "0 0 20px rgba(0, 255, 247, 0.6)" }}
          >
            {question.question}
          </h2>

          <div className="flex flex-col gap-3">
            {question.options.map((option) => (
              <button
                key={option.value}
                onClick={() => handleAnswer(question.id, option.value)}
                className="w-full py-4 px-6 rounded-xl font-mono text-sm text-left transition-all border border-neutral-800 hover:border-cyan-500/50 hover:bg-cyan-500/10"
                style={{ color: "#fff" }}
              >
                {option.label}
              </button>
            ))}
          </div>

          <button
            onClick={onSkip}
            className="w-full mt-6 py-2 text-neutral-600 text-xs font-mono hover:text-neutral-400"
          >
            Skip to Elevator →
          </button>
        </div>
      </div>
    )
  }

  if (stage === "plan" && tourPlan) {
    const trackLabels = {
      business: "Business Track",
      akashic: "Akashic Track",
      both: "Dual Track Experience",
    }

    const depthLabels = {
      quick: "Quick Tour (~5 min)",
      standard: "Standard Tour (~15 min)",
      deep: "Deep Dive (~30+ min)",
    }

    return (
      <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black">
        <div className="relative z-10 w-full max-w-lg mx-4 text-center">
          <div className="flex justify-center mb-6">
            <div
              className="w-20 h-20 rounded-full flex items-center justify-center"
              style={{
                background:
                  tourPlan.track === "akashic"
                    ? "linear-gradient(135deg, #A020F0, #8B00FF)"
                    : tourPlan.track === "business"
                      ? "linear-gradient(135deg, #0066FF, #00BFFF)"
                      : "linear-gradient(135deg, #00FFF7, #A020F0)",
                boxShadow: `0 0 40px ${tourPlan.track === "akashic" ? "rgba(160, 32, 240, 0.5)" : "rgba(0, 255, 247, 0.5)"}`,
              }}
            >
              <Brain className="w-10 h-10 text-white" />
            </div>
          </div>

          <h2
            className="text-2xl font-display uppercase mb-2"
            style={{
              color: tourPlan.track === "akashic" ? "#A020F0" : "#00FFF7",
              textShadow: `0 0 20px ${tourPlan.track === "akashic" ? "rgba(160, 32, 240, 0.6)" : "rgba(0, 255, 247, 0.6)"}`,
            }}
          >
            Your Tour Plan
          </h2>

          <p className="text-neutral-400 font-mono text-sm mb-6">{trackLabels[tourPlan.track]}</p>

          <div
            className="p-6 rounded-xl mb-6"
            style={{
              background: "rgba(0,0,0,0.5)",
              border: `1px solid ${tourPlan.track === "akashic" ? "#A020F040" : "#00FFF740"}`,
            }}
          >
            <p className="text-neutral-500 text-xs font-mono mb-3 uppercase">{depthLabels[tourPlan.depth]}</p>

            <div className="flex flex-wrap gap-2 justify-center">
              {tourPlan.floors.map((floor) => (
                <span
                  key={floor}
                  className="px-3 py-1 rounded-full text-xs font-mono uppercase"
                  style={{
                    background: tourPlan.track === "akashic" ? "#A020F020" : "#00FFF720",
                    color: tourPlan.track === "akashic" ? "#A020F0" : "#00FFF7",
                  }}
                >
                  {floor.replace("/", "").toUpperCase() || "LOBBY"}
                </span>
              ))}
            </div>
          </div>

          <div className="flex flex-col gap-3">
            <button
              onClick={startTour}
              className="w-full py-4 px-6 rounded-xl font-mono text-sm uppercase tracking-wider transition-all flex items-center justify-center gap-3"
              style={{
                background:
                  tourPlan.track === "akashic"
                    ? "linear-gradient(135deg, #A020F0, #8B00FF)"
                    : "linear-gradient(135deg, #00FFF7, #00BFFF)",
                color: tourPlan.track === "akashic" ? "#fff" : "#000",
                boxShadow: `0 0 30px ${tourPlan.track === "akashic" ? "rgba(160, 32, 240, 0.5)" : "rgba(0, 255, 247, 0.5)"}`,
              }}
            >
              Begin Tour
              <ArrowRight className="w-5 h-5" />
            </button>

            <button onClick={onSkip} className="w-full py-3 text-neutral-500 text-sm font-mono hover:text-neutral-300">
              Skip to Elevator
            </button>
          </div>
        </div>
      </div>
    )
  }

  return null
}
