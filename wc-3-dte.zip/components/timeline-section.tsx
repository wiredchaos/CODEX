"use client"

import { useRef, useEffect, useState } from "react"
import { cn } from "@/lib/utils"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"
import { useRealm } from "@/contexts/realm-context"

gsap.registerPlugin(ScrollTrigger)

const timelineAges = [
  { age: "I", name: "Before Continents", period: "3.6B – 500M", event: "Primordial formation" },
  { age: "II", name: "Pangaea", period: "500M – 200M", event: "Single landmass" },
  { age: "III", name: "First Flame", period: "200M – 65M", event: "Dinosaur extinction" },
  { age: "IV", name: "The Fracturing", period: "65M – 12K", event: "Continental drift" },
  { age: "V", name: "The Sinking", period: "12,000 BCE", event: "Atlantis falls" },
  { age: "VI", name: "Neteru Rise", period: "10,000 – 3000 BCE", event: "Khemetic emergence" },
  { age: "VII", name: "Empire Chain", period: "3000 BCE – 476 CE", event: "Classical civilizations" },
  { age: "VIII", name: "Veil Era", period: "476 – 1776", event: "Hidden knowledge" },
  { age: "IX", name: "Industrial Cipher", period: "1776 – 1971", event: "Mechanical age" },
  { age: "X", name: "Digital Dawn", period: "1971 – 2008", event: "Computing revolution" },
  { age: "XI", name: "Black Ledger Year", period: "2025.X", event: "Binarum Anomaly", active: true },
  { age: "XII", name: "NEURO Era", period: "Future", event: "Conscious self-authorship" },
]

export function TimelineSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const headerRef = useRef<HTMLDivElement>(null)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!sectionRef.current || !headerRef.current) return

    const ctx = gsap.context(() => {
      gsap.fromTo(
        headerRef.current,
        { x: -60, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 1,
          ease: "power3.out",
          scrollTrigger: {
            trigger: headerRef.current,
            start: "top 85%",
            toggleActions: "play none none reverse",
          },
        },
      )
    }, sectionRef)

    return () => ctx.revert()
  }, [])

  return (
    <section
      id="timeline"
      ref={sectionRef}
      className="relative py-20 md:py-32 px-6 md:pl-28"
      aria-labelledby="timeline-heading"
    >
      <div
        className="liquid-blob w-64 md:w-80 h-64 md:h-80 bg-orange-500/20 top-10 right-0"
        style={{ animationDelay: "-3s" }}
        aria-hidden="true"
      />

      {/* Section header */}
      <div ref={headerRef} className="mb-12 md:mb-16 pr-6 md:pr-12 relative z-10">
        <span className="font-mono text-xs uppercase tracking-[0.3em] text-accent">02 / 12 Ages</span>
        <h2
          id="timeline-heading"
          className="mt-4 font-[var(--font-bebas)] text-4xl md:text-5xl lg:text-7xl tracking-tight"
        >
          MASTER TIMELINE
        </h2>
        <p className="mt-4 max-w-xl font-mono text-sm md:text-base text-muted-foreground leading-relaxed">
          From 3.6 billion years ago to humanity&apos;s conscious self-authorship. The 33 shards of the First Cipher
          scattered across reality.
        </p>
      </div>

      <div
        ref={scrollRef}
        className="flex gap-3 md:gap-4 overflow-x-auto pb-6 md:pb-8 pr-6 md:pr-12 scrollbar-hide relative z-10"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none", WebkitOverflowScrolling: "touch" }}
        role="list"
        aria-label="Timeline of 12 Ages"
      >
        {timelineAges.map((age, index) => (
          <TimelineCard key={age.age} age={age} index={index} />
        ))}
      </div>

      <div className="md:hidden mt-4 flex items-center justify-center gap-2" aria-hidden="true">
        <div className="h-px w-8 bg-accent/40" />
        <span className="font-mono text-[10px] text-accent uppercase tracking-wider">Swipe to explore</span>
        <div className="h-px w-8 bg-accent/40" />
      </div>
    </section>
  )
}

function TimelineCard({
  age,
  index,
}: {
  age: (typeof timelineAges)[number]
  index: number
}) {
  const [isHovered, setIsHovered] = useState(false)
  const { realmColors } = useRealm()

  return (
    <article
      role="listitem"
      tabIndex={0}
      className={cn(
        "group relative flex-shrink-0 w-48 md:w-52 glass-subtle neon-touch card-neon p-4 md:p-5 transition-all duration-300 rounded-lg",
        "hover:bg-card/50 hover:border-accent/50 focus-visible:ring-2 focus-visible:ring-accent",
        age.active && "bg-accent/10 border-accent/60",
      )}
      aria-current={age.active ? "true" : undefined}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onFocus={() => setIsHovered(true)}
      onBlur={() => setIsHovered(false)}
      style={{
        borderColor: isHovered || age.active ? realmColors.primary : "rgba(255, 255, 255, 0.1)",
        boxShadow: isHovered || age.active ? `0 0 20px ${realmColors.glow}, 0 0 40px ${realmColors.glow}20` : "none",
      }}
    >
      {/* Age number */}
      <div className="flex items-baseline justify-between mb-3 md:mb-4">
        <span
          className={cn(
            "font-[var(--font-bebas)] text-2xl md:text-3xl transition-all duration-300",
            age.active ? "text-accent" : isHovered ? "neon-text-bright" : "text-muted-foreground/60",
          )}
          style={{
            color: age.active ? realmColors.primary : isHovered ? realmColors.primary : undefined,
            textShadow:
              !age.active && isHovered
                ? `0 0 5px ${realmColors.primary}, 0 0 10px ${realmColors.primary}, 0 0 20px ${realmColors.primary}`
                : undefined,
          }}
        >
          {age.age}
        </span>
        <span className="font-mono text-[10px] md:text-xs text-muted-foreground uppercase">Age</span>
      </div>

      {/* Name */}
      <h3
        className={cn(
          "font-[var(--font-bebas)] text-lg md:text-xl tracking-tight mb-2 transition-all duration-300",
          age.active ? "text-accent" : "group-hover:text-foreground text-muted-foreground",
        )}
        style={{
          color: age.active ? realmColors.primary : isHovered ? realmColors.primary : undefined,
          textShadow:
            !age.active && isHovered
              ? `0 0 5px ${realmColors.primary}, 0 0 10px ${realmColors.primary}, 0 0 20px ${realmColors.primary}`
              : age.active
                ? `0 0 10px ${realmColors.primary}`
                : undefined,
        }}
      >
        {age.name}
      </h3>

      <span
        className={cn(
          "font-mono text-xs md:text-sm block mb-2 md:mb-3 transition-colors duration-300",
          isHovered ? "text-muted-foreground/90" : "text-muted-foreground",
        )}
      >
        {age.period}
      </span>

      <p className="font-mono text-xs md:text-sm text-muted-foreground">{age.event}</p>

      {/* Active indicator */}
      {age.active && (
        <div
          className="absolute top-3 right-3 w-2 md:w-3 h-2 md:h-3 rounded-full bg-accent animate-pulse"
          aria-label="Current age"
          style={{
            backgroundColor: realmColors.primary,
            boxShadow: `0 0 10px ${realmColors.primary}`,
          }}
        />
      )}

      {!age.active && isHovered && (
        <div
          className="absolute top-3 right-3 w-2 md:w-3 h-2 md:h-3 rounded-full animate-pulse"
          aria-hidden="true"
          style={{
            backgroundColor: realmColors.primary,
            boxShadow: `0 0 15px ${realmColors.primary}, 0 0 30px ${realmColors.glow}`,
          }}
        />
      )}
    </article>
  )
}
