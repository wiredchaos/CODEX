"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Globe, Cpu, TrendingUp, ChevronRight } from "lucide-react"
import { galaxies, type GalaxyMode } from "@/lib/registry/galaxies"

interface GalaxyPortalGridProps {
  onSelectGalaxy?: (mode: GalaxyMode) => void
}

const iconMap = {
  Globe,
  Cpu,
  TrendingUp,
}

export function GalaxyPortalGrid({ onSelectGalaxy }: GalaxyPortalGridProps) {
  const router = useRouter()
  const [hoveredGalaxy, setHoveredGalaxy] = useState<string | null>(null)

  const handleSelect = (galaxyId: GalaxyMode) => {
    if (onSelectGalaxy) {
      onSelectGalaxy(galaxyId)
    } else {
      // Default: navigate to lobby with mode param
      router.push(`/?mode=${galaxyId}`)
    }
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-6">
      {galaxies.map((galaxy) => {
        const IconComponent = iconMap[galaxy.icon as keyof typeof iconMap] || Globe
        const isHovered = hoveredGalaxy === galaxy.id

        return (
          <button
            key={galaxy.id}
            onClick={() => handleSelect(galaxy.id)}
            onMouseEnter={() => setHoveredGalaxy(galaxy.id)}
            onMouseLeave={() => setHoveredGalaxy(null)}
            className="group relative p-8 rounded-2xl border transition-all duration-300 text-left"
            style={{
              backgroundColor: isHovered ? `${galaxy.color}15` : "rgba(0,0,0,0.6)",
              borderColor: isHovered ? galaxy.color : "rgba(255,255,255,0.1)",
              boxShadow: isHovered ? `0 0 40px ${galaxy.color}30` : "none",
            }}
          >
            {/* Animated galaxy background */}
            <div
              className="absolute inset-0 rounded-2xl opacity-20 transition-opacity duration-300"
              style={{
                background: `radial-gradient(circle at 50% 50%, ${galaxy.color}40 0%, transparent 70%)`,
                opacity: isHovered ? 0.4 : 0.1,
              }}
            />

            <div className="relative z-10 space-y-4">
              <div
                className="w-16 h-16 rounded-full flex items-center justify-center transition-transform duration-300"
                style={{
                  backgroundColor: `${galaxy.color}20`,
                  transform: isHovered ? "scale(1.1)" : "scale(1)",
                }}
              >
                <IconComponent className="w-8 h-8" style={{ color: galaxy.color }} />
              </div>

              <div>
                <h3 className="text-xl font-bold text-white mb-1">{galaxy.title}</h3>
                <p className="text-sm text-gray-400">{galaxy.subtitle}</p>
              </div>

              <div className="flex items-center gap-2 text-sm" style={{ color: galaxy.color }}>
                <span>{galaxy.visibleFloors.length} floors</span>
                <span>•</span>
                <span>{galaxy.visibleSuites.length} suites</span>
              </div>

              <div
                className="flex items-center gap-2 text-sm font-medium transition-transform duration-300"
                style={{
                  color: galaxy.color,
                  transform: isHovered ? "translateX(4px)" : "translateX(0)",
                }}
              >
                Enter Portal <ChevronRight className="w-4 h-4" />
              </div>
            </div>
          </button>
        )
      })}
    </div>
  )
}
