"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { NeuroConcierge } from "./neuro-concierge"
import { AkashicTrigger } from "./akashic-trigger"
import { TourGuide } from "./tour-guide"

export function EntryGate() {
  const router = useRouter()
  const [showConcierge, setShowConcierge] = useState(false)
  const [hasVisited, setHasVisited] = useState(true)

  useEffect(() => {
    // Check if first visit
    const visited = localStorage.getItem("wc_visited")
    if (!visited) {
      setHasVisited(false)
      setShowConcierge(true)
    } else {
      setHasVisited(true)
    }
  }, [])

  const handleComplete = () => {
    localStorage.setItem("wc_visited", "true")
    setShowConcierge(false)
    setHasVisited(true)
  }

  const handleSkip = () => {
    localStorage.setItem("wc_visited", "true")
    setShowConcierge(false)
    setHasVisited(true)
  }

  const handleAkashicTrigger = () => {
    router.push("/fen")
  }

  return (
    <>
      {showConcierge && <NeuroConcierge onComplete={handleComplete} onSkip={handleSkip} />}
      {hasVisited && <AkashicTrigger onTrigger={handleAkashicTrigger} />}
      {hasVisited && <TourGuide />}
    </>
  )
}
