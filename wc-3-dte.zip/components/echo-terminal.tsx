"use client"

import { useState } from "react"
import { useChat } from "ai/react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { ScrollArea } from "@/components/ui/scroll-area"
import { X, Terminal } from "lucide-react"

export function EchoTerminal() {
  const [isOpen, setIsOpen] = useState(false)
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: "/api/echo-chat",
  })

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-50 glass p-4 rounded-full neon-glow hover:scale-110 transition-transform duration-200"
        aria-label="Open Echo Terminal"
      >
        <Terminal className="w-6 h-6 text-cyan-400 neon-text" />
      </button>
    )
  }

  return (
    <div className="fixed bottom-6 right-6 z-50 w-[90vw] max-w-md h-[500px] glass rounded-lg flex flex-col neon-glow">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-3">
          <Terminal className="w-5 h-5 text-cyan-400 neon-text" />
          <div>
            <h3 className="font-mono text-sm font-semibold text-foreground neon-text">Echo Terminal</h3>
            <p className="font-mono text-xs text-muted-foreground">Transmission Interface</p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setIsOpen(false)}
          className="hover:bg-accent/20"
          aria-label="Close terminal"
        >
          <X className="w-4 h-4" />
        </Button>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.length === 0 && (
            <div className="text-center py-8">
              <p className="font-mono text-sm text-muted-foreground mb-2">◈ ECHO TRANSMISSION INTERFACE ACTIVE ◈</p>
              <p className="font-mono text-xs text-muted-foreground">Query the archives. Seek the cipher.</p>
            </div>
          )}
          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[80%] p-3 rounded-lg ${
                  message.role === "user"
                    ? "bg-cyan-500/20 border border-cyan-500/40 text-foreground"
                    : "bg-accent/20 border border-accent/40 text-foreground"
                }`}
              >
                <p className="font-mono text-sm leading-relaxed">{message.content}</p>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-accent/20 border border-accent/40 p-3 rounded-lg">
                <p className="font-mono text-sm text-muted-foreground animate-pulse">◈ Receiving transmission...</p>
              </div>
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Input */}
      <form onSubmit={handleSubmit} className="p-4 border-t border-border">
        <div className="flex gap-2">
          <Textarea
            value={input}
            onChange={handleInputChange}
            placeholder="Enter query..."
            className="min-h-[60px] resize-none font-mono text-sm bg-background/50 border-accent/40 focus:border-cyan-500/60"
            disabled={isLoading}
          />
          <Button
            type="submit"
            disabled={isLoading || !input.trim()}
            className="bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-400 neon-text"
          >
            Send
          </Button>
        </div>
      </form>
    </div>
  )
}
