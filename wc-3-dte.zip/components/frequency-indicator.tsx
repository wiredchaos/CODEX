"use client"

import { useEffect, useState } from "react"
import { cn } from "@/lib/utils"
import { useRealm } from "@/contexts/realm-context"

export function FrequencyIndicator() {
  const [pulse, setPulse] = useState(false)
  const { activeRealm, realmColors } = useRealm()

  const frequencyLabels = {
    neuralis: "Foundation · Trinity · Duality",
    chaosphere: "Origin · Expansion · Completion",
    underground: "Hidden · Shadow · Cipher",
  }

  useEffect(() => {
    const interval = setInterval(() => {
      setPulse((prev) => !prev)
    }, realmColors.frequency)
    return () => clearInterval(interval)
  }, [realmColors.frequency])

  return (
    <div className="mt-6 flex flex-col gap-3" role="status" aria-live="polite">
      {/* FEN = 589 Display */}
      <div className="flex items-center gap-3">
        <span
          className="font-mono text-2xl sm:text-3xl font-bold neon-text-bright tracking-wider"
          style={{
            color: "#00FFF7",
            textShadow: "0 0 5px #00FFF7, 0 0 10px #00FFF7, 0 0 20px #00FFF7, 0 0 40px #00FFF7",
          }}
        >
          FEN
        </span>
        <div
          className="h-8 w-px"
          style={{
            background: `linear-gradient(to bottom, transparent, #00FFF7, transparent)`,
            boxShadow: "0 0 10px #00FFF7",
          }}
        />
        <span
          className="font-mono text-2xl sm:text-3xl font-bold neon-text-bright tracking-wider"
          style={{
            color: "#FF1A1A",
            textShadow: "0 0 5px #FF1A1A, 0 0 10px #FF1A1A, 0 0 20px #FF1A1A, 0 0 40px #FF1A1A",
          }}
        >
          589
        </span>
      </div>

      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <div
            className={cn(
              "w-4 h-4 rounded-full transition-all duration-300 realm-transition",
              pulse ? "scale-125" : "scale-100",
            )}
            style={{
              backgroundColor: realmColors.primary,
              boxShadow: pulse
                ? `0 0 10px ${realmColors.primary}, 0 0 20px ${realmColors.primary}, 0 0 40px ${realmColors.primary}, 0 0 60px ${realmColors.primary}`
                : `0 0 5px ${realmColors.primary}, 0 0 10px ${realmColors.primary}`,
            }}
            aria-hidden="true"
          />
          <span
            className="font-mono text-xs uppercase tracking-wider"
            style={{
              color: realmColors.primary,
              textShadow: `0 0 5px ${realmColors.glow}`,
            }}
          >
            Trifecta Engine
          </span>
        </div>
        <div
          className="h-px flex-1 max-w-32 realm-transition"
          style={{
            background: `linear-gradient(to right, ${realmColors.primary}, ${realmColors.primary}40, transparent)`,
            boxShadow: `0 0 10px ${realmColors.glow}`,
          }}
          aria-hidden="true"
        />
        <span
          className="font-mono text-xs uppercase tracking-wider"
          style={{
            color: realmColors.primary,
            textShadow: `0 0 5px ${realmColors.glow}`,
          }}
        >
          {activeRealm ? frequencyLabels[activeRealm] : frequencyLabels.chaosphere}
        </span>
      </div>
    </div>
  )
}
