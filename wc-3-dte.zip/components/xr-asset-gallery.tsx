"use client"

import { useState } from "react"
import { useRealm } from "@/contexts/realm-context"
import { WiredModelViewer } from "./wired-model-viewer"
import { Cable as Cube, Layers, Sparkles, Lock, Unlock } from "lucide-react"

interface XRAsset {
  id: string
  title: string
  description: string
  glbUrl: string
  usdzUrl?: string
  realm: "neuralis" | "chaosphere" | "underground"
  category: "character" | "wearable" | "artifact" | "passport"
  rarity: "common" | "rare" | "epic" | "legendary" | "mythic"
  isAkashic: boolean
}

// Demo assets - replace with actual Supabase data
const demoAssets: XRAsset[] = [
  {
    id: "1",
    title: "ECHO ENGINEER AVATAR",
    description: "Standard issue consciousness vessel for Neuralis realm operations",
    glbUrl: "/futuristic-humanoid-avatar-cyan-holographic.jpg",
    realm: "neuralis",
    category: "character",
    rarity: "rare",
    isAkashic: false,
  },
  {
    id: "2",
    title: "FLAME SIGIL ARTIFACT",
    description: "Ancient relic from the Chaosphere containing trapped frequency codes",
    glbUrl: "/mystical-flame-artifact-orange-glowing.jpg",
    realm: "chaosphere",
    category: "artifact",
    rarity: "legendary",
    isAkashic: true,
  },
  {
    id: "3",
    title: "VAULT 33 ACCESS KEY",
    description: "Cryptographic passport granting entry to Underground archives",
    glbUrl: "/futuristic-key-card-purple-holographic.jpg",
    realm: "underground",
    category: "passport",
    rarity: "mythic",
    isAkashic: true,
  },
  {
    id: "4",
    title: "NMX OPERATOR UNIFORM",
    description: "Official NEURO META X operator wearable with embedded telemetry",
    glbUrl: "/futuristic-uniform-jacket-cyberpunk.jpg",
    realm: "neuralis",
    category: "wearable",
    rarity: "epic",
    isAkashic: false,
  },
]

const rarityColors = {
  common: "#9ca3af",
  rare: "#3b82f6",
  epic: "#a855f7",
  legendary: "#f97316",
  mythic: "#ef4444",
}

export function XRAssetGallery() {
  const { activeRealm, setActiveRealm, realmColors } = useRealm()
  const [selectedAsset, setSelectedAsset] = useState<XRAsset | null>(null)
  const [filterRealm, setFilterRealm] = useState<string>("all")
  const [showAkashicOnly, setShowAkashicOnly] = useState(false)

  const filteredAssets = demoAssets.filter((asset) => {
    if (filterRealm !== "all" && asset.realm !== filterRealm) return false
    if (showAkashicOnly && !asset.isAkashic) return false
    return true
  })

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "character":
        return <Cube className="w-4 h-4" />
      case "wearable":
        return <Layers className="w-4 h-4" />
      case "artifact":
        return <Sparkles className="w-4 h-4" />
      case "passport":
        return <Lock className="w-4 h-4" />
      default:
        return <Cube className="w-4 h-4" />
    }
  }

  return (
    <section
      id="xr-gallery"
      className="relative py-20 md:py-32 px-4 md:px-8 overflow-hidden"
      aria-labelledby="xr-gallery-heading"
    >
      {/* Background elements */}
      <div
        className="liquid-blob absolute top-1/4 -left-32 w-96 h-96"
        style={{ backgroundColor: realmColors.primary }}
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-12">
          <div>
            <span className="font-mono text-sm tracking-widest uppercase" style={{ color: realmColors.primary }}>
              XR ASSET GALLERY
            </span>
            <h2 id="xr-gallery-heading" className="font-display text-4xl md:text-5xl lg:text-6xl tracking-tight mt-2">
              PHYGITAL COLLECTION
            </h2>
            <p className="text-base md:text-lg text-muted-foreground mt-4 max-w-2xl leading-relaxed">
              Explore 3D assets across all realms. Business layer items are publicly viewable. Akashic layer artifacts
              require appropriate clearance level.
            </p>
          </div>

          {/* Filter controls */}
          <div className="flex flex-wrap items-center gap-3">
            {/* Realm filter */}
            <div className="flex items-center gap-1 p-1 rounded-lg glass">
              {["all", "neuralis", "chaosphere", "underground"].map((realm) => (
                <button
                  key={realm}
                  onClick={() => setFilterRealm(realm)}
                  className={`px-4 py-2 rounded-md font-mono text-sm transition-all neon-touch ${
                    filterRealm === realm ? "bg-foreground/10" : "hover:bg-foreground/5"
                  }`}
                  style={{
                    color: filterRealm === realm ? realmColors.primary : undefined,
                  }}
                  aria-pressed={filterRealm === realm}
                >
                  {realm.toUpperCase()}
                </button>
              ))}
            </div>

            {/* Akashic toggle */}
            <button
              onClick={() => setShowAkashicOnly(!showAkashicOnly)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg glass neon-touch font-mono text-sm transition-all ${
                showAkashicOnly ? "bg-purple-500/20 border-purple-500" : ""
              }`}
              aria-pressed={showAkashicOnly}
            >
              {showAkashicOnly ? <Unlock className="w-4 h-4 text-purple-400" /> : <Lock className="w-4 h-4" />}
              AKASHIC ONLY
            </button>
          </div>
        </div>

        {/* Asset grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAssets.map((asset) => (
            <button
              key={asset.id}
              onClick={() => {
                setSelectedAsset(asset)
                setActiveRealm(asset.realm)
              }}
              className="text-left glass-card p-4 card-neon neon-touch focus:outline-none focus-visible:ring-2"
              style={{
                ["--realm-primary" as string]:
                  asset.realm === "neuralis" ? "#22d3ee" : asset.realm === "chaosphere" ? "#f97316" : "#a855f7",
              }}
              aria-label={`View ${asset.title}`}
            >
              {/* Asset preview */}
              <div
                className="aspect-square rounded-lg mb-4 flex items-center justify-center relative overflow-hidden"
                style={{
                  background: `linear-gradient(135deg, ${
                    asset.realm === "neuralis"
                      ? "rgba(34, 211, 238, 0.1)"
                      : asset.realm === "chaosphere"
                        ? "rgba(249, 115, 22, 0.1)"
                        : "rgba(168, 85, 247, 0.1)"
                  }, transparent)`,
                }}
              >
                <img
                  src={asset.glbUrl || "/placeholder.svg"}
                  alt={asset.title}
                  className="w-full h-full object-cover"
                />
                {/* Akashic indicator */}
                {asset.isAkashic && (
                  <div className="absolute top-2 right-2 px-2 py-1 rounded bg-purple-500/20 border border-purple-500/50">
                    <span className="font-mono text-xs text-purple-400">AKASHIC</span>
                  </div>
                )}
              </div>

              {/* Asset info */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div
                    className="flex items-center gap-2 font-mono text-xs"
                    style={{
                      color:
                        asset.realm === "neuralis" ? "#22d3ee" : asset.realm === "chaosphere" ? "#f97316" : "#a855f7",
                    }}
                  >
                    {getCategoryIcon(asset.category)}
                    {asset.category.toUpperCase()}
                  </div>
                  <span className="font-mono text-xs font-bold" style={{ color: rarityColors[asset.rarity] }}>
                    {asset.rarity.toUpperCase()}
                  </span>
                </div>
                <h3 className="font-mono text-base font-bold">{asset.title}</h3>
                <p className="text-sm text-muted-foreground line-clamp-2">{asset.description}</p>
              </div>
            </button>
          ))}
        </div>

        {/* Empty state */}
        {filteredAssets.length === 0 && (
          <div className="text-center py-20 glass rounded-xl">
            <Lock className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <p className="font-mono text-lg text-muted-foreground">NO ASSETS MATCH CURRENT FILTERS</p>
          </div>
        )}

        {/* Selected asset modal */}
        {selectedAsset && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm"
            onClick={() => setSelectedAsset(null)}
            role="dialog"
            aria-modal="true"
            aria-labelledby="modal-title"
          >
            <div
              className="relative w-full max-w-4xl glass-strong rounded-2xl p-6 md:p-8"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setSelectedAsset(null)}
                className="absolute top-4 right-4 p-2 rounded-lg glass neon-touch"
                aria-label="Close modal"
              >
                <span className="font-mono text-lg">×</span>
              </button>

              <div className="grid md:grid-cols-2 gap-8">
                <WiredModelViewer
                  glbUrl={selectedAsset.glbUrl}
                  usdzUrl={selectedAsset.usdzUrl}
                  title={selectedAsset.title}
                  realmOverride={selectedAsset.realm}
                />

                <div className="space-y-6">
                  <div>
                    <div
                      className="flex items-center gap-2 font-mono text-sm mb-2"
                      style={{
                        color:
                          selectedAsset.realm === "neuralis"
                            ? "#22d3ee"
                            : selectedAsset.realm === "chaosphere"
                              ? "#f97316"
                              : "#a855f7",
                      }}
                    >
                      {getCategoryIcon(selectedAsset.category)}
                      {selectedAsset.category.toUpperCase()} / {selectedAsset.realm.toUpperCase()}
                    </div>
                    <h3 id="modal-title" className="font-display text-3xl md:text-4xl">
                      {selectedAsset.title}
                    </h3>
                  </div>

                  <p className="text-base text-muted-foreground leading-relaxed">{selectedAsset.description}</p>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="glass rounded-lg p-4">
                      <span className="font-mono text-xs text-muted-foreground">RARITY</span>
                      <p
                        className="font-mono text-lg font-bold mt-1"
                        style={{ color: rarityColors[selectedAsset.rarity] }}
                      >
                        {selectedAsset.rarity.toUpperCase()}
                      </p>
                    </div>
                    <div className="glass rounded-lg p-4">
                      <span className="font-mono text-xs text-muted-foreground">LAYER</span>
                      <p
                        className="font-mono text-lg font-bold mt-1"
                        style={{ color: selectedAsset.isAkashic ? "#a855f7" : "#22d3ee" }}
                      >
                        {selectedAsset.isAkashic ? "AKASHIC" : "BUSINESS"}
                      </p>
                    </div>
                  </div>

                  {selectedAsset.isAkashic && (
                    <div className="p-4 rounded-lg border border-purple-500/30 bg-purple-500/10">
                      <p className="font-mono text-sm text-purple-300">
                        <Lock className="w-4 h-4 inline-block mr-2" />
                        This asset belongs to the Akashic layer. Access requires VAULT 33 clearance.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  )
}
