"use client"

import { useState, useCallback, useRef } from "react"
import { useRouter } from "next/navigation"
import {
  X,
  ChevronUp,
  ChevronDown,
  Brain,
  CreditCard,
  ShoppingBag,
  Cpu,
  Building2,
  Radio,
  Wallet,
  BookOpen,
  Sparkles,
  Film,
  GraduationCap,
  AlertTriangle,
} from "lucide-react"
import Image from "next/image"

interface ElevatorOverlayProps {
  isOpen: boolean
  onClose: () => void
}

const businessFloors = [
  { id: "lobby", label: "LBY", sublabel: "WIRED CHAOS META", route: "/", color: "#00FFF7", icon: Building2 },
  { id: "789", label: "789", sublabel: "STUDIOS / OTT", route: "/789", color: "#FFD700", icon: Film },
  { id: "333", label: "333", sublabel: "SIGNAL STUDIO", route: "/333", color: "#00FFF7", icon: Radio },
  { id: "mall", label: "MLL", sublabel: "CHAOS STORE", route: "/mall", color: "#00FFF7", icon: ShoppingBag },
  {
    id: "credit",
    label: "CRD",
    sublabel: "CREDIT REPAIR",
    route: "/credit-repair",
    color: "#0066FF",
    icon: CreditCard,
  },
  { id: "neura", label: "NRA", sublabel: "LEGACY ARCH", route: "/neura", color: "#00F0FF", icon: Building2 },
  { id: "npc", label: "NPC", sublabel: "NEURO PROMPT", route: "/npc", color: "#00FF88", icon: Cpu },
  {
    id: "crypto",
    label: "CSN",
    sublabel: "CRYPTO SPACES",
    route: "/789/crypto-spaces",
    color: "#0066FF",
    icon: Wallet,
  },
  {
    id: "university",
    label: "UNI",
    sublabel: "WC ACADEMY",
    route: "/university",
    color: "#0088FF",
    icon: GraduationCap,
  },
]

const fenFloors = [
  {
    id: "akira",
    label: "AKR",
    sublabel: "NEURO CODEX",
    route: "/fen/akira",
    color: "#A020F0",
    requiresRiddle: true,
    icon: Sparkles,
  },
  { id: "vault33", label: "V33", sublabel: "AKASHIC VAULT", route: "/vault33", color: "#A020F0", icon: BookOpen },
  { id: "gamma", label: "GAM", sublabel: "DD CARTOONS", route: "/gamma", color: "#FF6B35", icon: Film },
  { id: "fen", label: "FEN", sublabel: "AKASHIC REALM", route: "/fen", color: "#A020F0", icon: Sparkles },
]

const FEN_RIDDLE = {
  question: "I pulse at 589, connecting realms unseen. What am I?",
  answers: ["frequency", "fen", "trifecta"],
}

function AnimatedVectors({ color }: { color: string }) {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-20">
      <svg className="absolute bottom-4 left-4 w-20 h-20">
        <circle cx="10" cy="10" r="3" fill={color} className="animate-pulse" />
        <circle cx="35" cy="15" r="3" fill={color} className="animate-pulse" style={{ animationDelay: "0.5s" }} />
        <circle cx="15" cy="40" r="3" fill={color} className="animate-pulse" style={{ animationDelay: "1s" }} />
        <line x1="10" y1="10" x2="35" y2="15" stroke={color} strokeWidth="1" strokeOpacity="0.4" />
        <line x1="35" y1="15" x2="15" y2="40" stroke={color} strokeWidth="1" strokeOpacity="0.4" />
      </svg>
    </div>
  )
}

export function ElevatorOverlay({ isOpen, onClose }: ElevatorOverlayProps) {
  const router = useRouter()
  const [currentSection, setCurrentSection] = useState<"business" | "fen">("business")
  const [currentFloor, setCurrentFloor] = useState(0)
  const [isMoving, setIsMoving] = useState(false)
  const [doorsOpen, setDoorsOpen] = useState(true)
  const [riddleAnswer, setRiddleAnswer] = useState("")
  const [showRiddle, setShowRiddle] = useState(false)
  const [riddleError, setRiddleError] = useState(false)
  const [fenUnlocked, setFenUnlocked] = useState(false)

  const isNavigating = useRef(false)

  const activeFloors = currentSection === "business" ? businessFloors : fenFloors
  const currentFloorData = activeFloors[currentFloor]

  const checkRiddle = useCallback(() => {
    const answer = riddleAnswer.toLowerCase().trim()
    if (FEN_RIDDLE.answers.includes(answer)) {
      setFenUnlocked(true)
      setShowRiddle(false)
      setRiddleError(false)
    } else {
      setRiddleError(true)
      setTimeout(() => setRiddleError(false), 2000)
    }
  }, [riddleAnswer])

  const emergencyExit = useCallback(() => {
    isNavigating.current = false
    setIsMoving(false)
    setDoorsOpen(true)
    onClose()
  }, [onClose])

  const goToFloor = useCallback(
    (index: number) => {
      const targetFloor = activeFloors[index]

      if (targetFloor.requiresRiddle && !fenUnlocked) {
        setShowRiddle(true)
        return
      }

      if (index === currentFloor || isMoving || isNavigating.current) return

      isNavigating.current = true
      setIsMoving(true)
      setDoorsOpen(false)

      const closeDoorTimer = setTimeout(() => {
        setCurrentFloor(index)
      }, 500)

      const openDoorTimer = setTimeout(() => {
        setDoorsOpen(true)
        setIsMoving(false)
      }, 1500)

      const navigateTimer = setTimeout(() => {
        if (isNavigating.current) {
          router.push(activeFloors[index].route)
          onClose()
          isNavigating.current = false
        }
      }, 2000)

      return () => {
        clearTimeout(closeDoorTimer)
        clearTimeout(openDoorTimer)
        clearTimeout(navigateTimer)
      }
    },
    [activeFloors, currentFloor, fenUnlocked, isMoving, onClose, router],
  )

  if (!isOpen) return null

  if (showRiddle) {
    return (
      <div className="fixed inset-0 z-[100] flex items-center justify-center" role="dialog" aria-modal="true">
        <div className="absolute inset-0 bg-black/95 backdrop-blur-xl" onClick={() => setShowRiddle(false)} />
        <div className="relative z-10 w-full max-w-lg mx-4">
          <div
            className="relative p-8 rounded-2xl overflow-hidden"
            style={{
              background: "linear-gradient(135deg, rgba(0,0,0,0.9), rgba(26,0,42,0.9))",
              border: "2px solid #A020F0",
              boxShadow: "0 0 40px rgba(160, 32, 240, 0.5)",
            }}
          >
            <div className="flex justify-center mb-6">
              <div
                className="w-20 h-20 rounded-full flex items-center justify-center"
                style={{
                  background: "linear-gradient(135deg, #A020F0, #8B00FF)",
                  boxShadow: "0 0 30px rgba(160, 32, 240, 0.8)",
                }}
              >
                <Brain className="w-10 h-10 text-white animate-pulse" />
              </div>
            </div>
            <h3 className="text-2xl font-display uppercase text-center mb-2" style={{ color: "#A020F0" }}>
              NEURO CONCIERGE
            </h3>
            <p className="text-sm text-center text-neutral-400 mb-6 font-mono">
              FEN access requires special authorization
            </p>
            <p className="text-center text-white mb-6 font-mono text-sm">{FEN_RIDDLE.question}</p>
            <input
              type="text"
              value={riddleAnswer}
              onChange={(e) => setRiddleAnswer(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && checkRiddle()}
              placeholder="Enter your answer..."
              className="w-full px-4 py-3 rounded-lg font-mono text-sm text-white mb-4 focus:outline-none"
              style={{ background: "rgba(0,0,0,0.5)", border: riddleError ? "2px solid #FF1A1A" : "2px solid #A020F0" }}
              autoFocus
            />
            {riddleError && (
              <p className="text-center text-red-500 text-sm font-mono mb-4 animate-pulse">ACCESS DENIED</p>
            )}
            <div className="flex gap-3">
              <button
                onClick={() => setShowRiddle(false)}
                className="flex-1 px-4 py-2 rounded-lg font-mono text-sm uppercase border border-neutral-600 text-neutral-400"
              >
                Cancel
              </button>
              <button
                onClick={checkRiddle}
                className="flex-1 px-4 py-2 rounded-lg font-mono text-sm uppercase text-white"
                style={{ background: "linear-gradient(135deg, #A020F0, #8B00FF)" }}
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center"
      role="dialog"
      aria-modal="true"
      aria-label="NEURO Concierge Navigation"
    >
      <div className="absolute inset-0 bg-black/95 backdrop-blur-xl" onClick={emergencyExit} />

      <div className="relative z-10 w-full max-w-2xl mx-4">
        <div className="absolute -top-14 right-0 flex items-center gap-3">
          <button
            onClick={emergencyExit}
            className="flex items-center gap-2 px-3 py-2 rounded-lg font-mono text-xs uppercase transition-all hover:scale-105"
            style={{
              background: "linear-gradient(135deg, #FF1A1A, #CC0000)",
              color: "#fff",
              boxShadow: "0 0 20px rgba(255, 26, 26, 0.5)",
            }}
            aria-label="Emergency Exit"
          >
            <AlertTriangle className="w-4 h-4" />
            PANIC EXIT
          </button>
          <button
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-white transition-colors rounded"
            aria-label="Close"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="flex justify-center mb-4">
          <div
            className="w-24 h-24 rounded-full flex items-center justify-center relative overflow-hidden"
            style={{ boxShadow: `0 0 40px ${currentFloorData?.color || "#00FFF7"}80` }}
          >
            <Image
              src="/images/20251214-084103.jpg"
              alt="NEURO Concierge"
              width={96}
              height={96}
              className="object-cover rounded-full"
            />
            <div
              className="absolute inset-[-4px] border-2 rounded-full animate-spin pointer-events-none"
              style={{
                borderColor: currentFloorData?.color || "#00FFF7",
                borderTopColor: "transparent",
                borderBottomColor: "transparent",
                animationDuration: "3s",
              }}
            />
          </div>
        </div>

        <div
          className="relative border-4 rounded-lg overflow-hidden"
          style={{
            borderColor: currentFloorData?.color || "#00FFF7",
            boxShadow: `0 0 30px ${currentFloorData?.color || "#00FFF7"}40`,
            background: "linear-gradient(180deg, rgba(0,0,0,0.95) 0%, rgba(5,5,10,0.98) 100%)",
          }}
        >
          <AnimatedVectors color={currentFloorData?.color || "#00FFF7"} />

          <div className="flex border-b border-neutral-800">
            <button
              onClick={() => {
                setCurrentSection("business")
                setCurrentFloor(0)
              }}
              className="flex-1 py-3 font-mono text-sm uppercase tracking-widest transition-all"
              style={{
                background: currentSection === "business" ? "#0066FF20" : "transparent",
                color: currentSection === "business" ? "#0066FF" : "#666",
                borderBottom: currentSection === "business" ? "2px solid #0066FF" : "none",
              }}
            >
              BUSINESS
            </button>
            <button
              onClick={() => {
                setCurrentSection("fen")
                setCurrentFloor(0)
              }}
              className="flex-1 py-3 font-mono text-sm uppercase tracking-widest transition-all"
              style={{
                background: currentSection === "fen" ? "#A020F020" : "transparent",
                color: currentSection === "fen" ? "#A020F0" : "#666",
                borderBottom: currentSection === "fen" ? "2px solid #A020F0" : "none",
              }}
            >
              FEN {fenUnlocked && "🔓"}
            </button>
          </div>

          <div className="flex items-center justify-between p-4 border-b border-neutral-800">
            <div className="flex items-center gap-4">
              <div
                className="font-mono text-4xl font-bold tracking-wider"
                style={{
                  color: currentFloorData?.color || "#00FFF7",
                  textShadow: `0 0 20px ${currentFloorData?.color || "#00FFF7"}`,
                }}
              >
                {currentFloorData?.label || "LBY"}
              </div>
              <div className="flex flex-col">
                <span className="text-xs text-neutral-500 font-mono uppercase">Current Floor</span>
                <span className="text-sm font-mono uppercase" style={{ color: currentFloorData?.color || "#00FFF7" }}>
                  {currentFloorData?.sublabel || "LOBBY"}
                </span>
              </div>
            </div>
            <div className="flex flex-col items-center">
              <ChevronUp className={`w-5 h-5 ${isMoving ? "text-cyan-400 animate-bounce" : "text-neutral-700"}`} />
              <ChevronDown className={`w-5 h-5 ${isMoving ? "text-cyan-400 animate-bounce" : "text-neutral-700"}`} />
            </div>
          </div>

          <div className="relative h-48 overflow-hidden">
            <div
              className="absolute top-0 left-0 h-full w-1/2 border-r border-neutral-700 transition-transform duration-500 ease-in-out"
              style={{
                background: "linear-gradient(90deg, rgba(20,20,25,1), rgba(30,30,35,1))",
                transform: doorsOpen ? "translateX(-100%)" : "translateX(0)",
              }}
            >
              <div className="absolute inset-0 flex items-center justify-end pr-4">
                <div
                  className="w-1 h-24 rounded-full"
                  style={{
                    background: `linear-gradient(180deg, transparent, ${currentFloorData?.color || "#00FFF7"}, transparent)`,
                  }}
                />
              </div>
            </div>

            <div
              className="absolute top-0 right-0 h-full w-1/2 border-l border-neutral-700 transition-transform duration-500 ease-in-out"
              style={{
                background: "linear-gradient(270deg, rgba(20,20,25,1), rgba(30,30,35,1))",
                transform: doorsOpen ? "translateX(100%)" : "translateX(0)",
              }}
            >
              <div className="absolute inset-0 flex items-center justify-start pl-4">
                <div
                  className="w-1 h-24 rounded-full"
                  style={{
                    background: `linear-gradient(180deg, transparent, ${currentFloorData?.color || "#00FFF7"}, transparent)`,
                  }}
                />
              </div>
            </div>

            <div
              className="absolute inset-0 flex items-center justify-center transition-opacity duration-300"
              style={{ opacity: doorsOpen ? 1 : 0 }}
            >
              <div className="text-center">
                {currentFloorData?.icon && (
                  <currentFloorData.icon className="w-12 h-12 mx-auto mb-2" style={{ color: currentFloorData.color }} />
                )}
                <div
                  className="font-mono text-5xl font-bold mb-2"
                  style={{
                    color: currentFloorData?.color || "#00FFF7",
                    textShadow: `0 0 30px ${currentFloorData?.color || "#00FFF7"}`,
                  }}
                >
                  {currentFloorData?.label || "LBY"}
                </div>
                <div className="font-mono text-sm uppercase tracking-widest text-neutral-400">
                  {currentFloorData?.sublabel}
                </div>
              </div>
            </div>

            {isMoving && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/80">
                <div className="text-center">
                  <div className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                  <p className="font-mono text-xs text-cyan-400 uppercase">In Transit</p>
                </div>
              </div>
            )}
          </div>

          <div className="p-4 grid grid-cols-3 gap-2">
            {activeFloors.map((floor, index) => {
              const Icon = floor.icon
              const isCurrentFloor = index === currentFloor
              const isLocked = floor.requiresRiddle && !fenUnlocked

              return (
                <button
                  key={floor.id}
                  onClick={() => goToFloor(index)}
                  disabled={isMoving}
                  className="relative p-3 rounded-lg font-mono text-xs uppercase transition-all disabled:opacity-50"
                  style={{
                    background: isCurrentFloor ? `${floor.color}30` : "rgba(30,30,35,0.8)",
                    border: `2px solid ${isCurrentFloor ? floor.color : "#333"}`,
                    color: isCurrentFloor ? floor.color : "#666",
                    boxShadow: isCurrentFloor ? `0 0 15px ${floor.color}40` : "none",
                  }}
                >
                  <Icon className="w-5 h-5 mx-auto mb-1" />
                  <div className="font-bold">{floor.label}</div>
                  <div className="text-[10px] opacity-70 truncate">{floor.sublabel}</div>
                  {isLocked && <div className="absolute top-1 right-1 text-[10px]">🔒</div>}
                </button>
              )
            })}
          </div>

          <div className="p-3 border-t border-neutral-800 text-center">
            <button
              onClick={emergencyExit}
              className="font-mono text-xs uppercase text-red-500 hover:text-red-400 transition-colors"
            >
              <AlertTriangle className="w-3 h-3 inline mr-1" />
              Emergency Exit - Return to Current Page
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
