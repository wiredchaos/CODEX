"use client"

import type React from "react"

import { cn } from "@/lib/utils"
import Image from "next/image"
import type { LucideIcon } from "lucide-react"

interface MinimalistCardProps {
  variant?: "floor" | "profile" | "compact"
  abbr?: string
  title: string
  subtitle?: string
  icon?: LucideIcon
  image?: string
  isActive?: boolean
  accentColor?: string
  onClick?: () => void
  className?: string
  badge?: string
  status?: "online" | "offline" | "busy" | "away"
}

export function MinimalistCard({
  variant = "floor",
  abbr,
  title,
  subtitle,
  icon: Icon,
  image,
  isActive = false,
  accentColor = "#00FFF7",
  onClick,
  className,
  badge,
  status,
}: MinimalistCardProps) {
  const statusColors = {
    online: "#10B981",
    offline: "#6B7280",
    busy: "#EF4444",
    away: "#F59E0B",
  }

  if (variant === "profile") {
    return (
      <button
        onClick={onClick}
        className={cn(
          "group relative flex items-center gap-4 p-4 rounded-2xl transition-all duration-300",
          "border hover:scale-[1.02] active:scale-[0.98]",
          "bg-black/40 backdrop-blur-sm",
          className,
        )}
        style={{
          borderColor: isActive ? accentColor : "#333",
          boxShadow: isActive ? `0 0 30px ${accentColor}20` : "none",
        }}
      >
        {/* Avatar */}
        <div className="relative">
          <div
            className="w-14 h-14 rounded-full overflow-hidden ring-2 transition-all"
            style={{
              ringColor: isActive ? accentColor : "#444",
            }}
          >
            {image ? (
              <Image
                src={image || "/placeholder.svg"}
                alt={title}
                width={56}
                height={56}
                className="object-cover w-full h-full"
              />
            ) : (
              <div
                className="w-full h-full flex items-center justify-center text-xl font-bold"
                style={{ background: `${accentColor}20`, color: accentColor }}
              >
                {abbr || title.charAt(0)}
              </div>
            )}
          </div>
          {status && (
            <div
              className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full border-2 border-black"
              style={{ background: statusColors[status] }}
            />
          )}
        </div>

        {/* Info */}
        <div className="flex-1 text-left">
          <p className="font-medium text-white group-hover:text-cyan-300 transition-colors">{title}</p>
          {subtitle && <p className="text-sm text-neutral-500 font-mono">{subtitle}</p>}
        </div>

        {/* Badge */}
        {badge && (
          <span
            className="px-2 py-1 rounded-full text-xs font-mono uppercase"
            style={{ background: `${accentColor}20`, color: accentColor }}
          >
            {badge}
          </span>
        )}

        {/* Hover glow */}
        <div
          className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
          style={{ boxShadow: `inset 0 0 40px ${accentColor}10` }}
        />
      </button>
    )
  }

  if (variant === "compact") {
    return (
      <button
        onClick={onClick}
        className={cn(
          "group relative flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300",
          "border hover:scale-[1.02] active:scale-[0.98]",
          className,
        )}
        style={{
          background: isActive ? `${accentColor}10` : "transparent",
          borderColor: isActive ? accentColor : "#333",
        }}
      >
        {Icon && <Icon className="w-5 h-5" style={{ color: isActive ? accentColor : "#666" }} />}
        <span className="font-mono text-sm" style={{ color: isActive ? accentColor : "#888" }}>
          {abbr || title}
        </span>
      </button>
    )
  }

  // Default: floor variant (elevator button style)
  return (
    <button
      onClick={onClick}
      className={cn(
        "group relative flex flex-col items-center justify-center p-4 rounded-xl transition-all duration-300",
        "border hover:scale-105 active:scale-95",
        className,
      )}
      style={{
        background: isActive ? `${accentColor}15` : "transparent",
        borderColor: isActive ? accentColor : "#333",
        boxShadow: isActive ? `0 0 20px ${accentColor}30` : "none",
      }}
    >
      {/* Icon or Image */}
      {image ? (
        <div className="w-10 h-10 rounded-lg overflow-hidden mb-2">
          <Image
            src={image || "/placeholder.svg"}
            alt={title}
            width={40}
            height={40}
            className="object-cover w-full h-full"
          />
        </div>
      ) : Icon ? (
        <Icon className="w-6 h-6 mb-2" style={{ color: isActive ? accentColor : "#666" }} />
      ) : null}

      {/* Abbr */}
      <span className="font-mono text-sm font-bold" style={{ color: isActive ? accentColor : "#888" }}>
        {abbr || title.substring(0, 3).toUpperCase()}
      </span>

      {/* Subtitle */}
      {subtitle && (
        <span className="text-neutral-600 text-[10px] font-mono truncate max-w-full mt-1">
          {subtitle.length > 12 ? `${subtitle.substring(0, 10)}...` : subtitle}
        </span>
      )}

      {/* Hover ring */}
      <div
        className="absolute inset-0 rounded-xl border-2 opacity-0 group-hover:opacity-100 transition-opacity"
        style={{ borderColor: `${accentColor}40` }}
      />
    </button>
  )
}

// Export a grid wrapper for consistent layouts
export function MinimalistCardGrid({
  children,
  columns = 3,
  className,
}: {
  children: React.ReactNode
  columns?: 2 | 3 | 4
  className?: string
}) {
  const colClasses = {
    2: "grid-cols-2",
    3: "grid-cols-3",
    4: "grid-cols-4",
  }

  return <div className={cn("grid gap-3", colClasses[columns], className)}>{children}</div>
}
