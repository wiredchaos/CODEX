"use client"

import { useState, createContext, useContext, type ReactNode } from "react"
import type { GalaxyMode } from "@/lib/registry/galaxies"
import { EconomyHUD } from "@/components/economy/economy-hud"

// Global Shell State
interface ShellState {
  mode: GalaxyMode
  currentFloor: number
  currentSuiteId: string | null
  hasDeepSignalAccess: boolean
  isElevatorOpen: boolean
  isConciergeOpen: boolean
}

interface ShellContextType extends ShellState {
  setMode: (mode: GalaxyMode) => void
  setFloor: (floor: number) => void
  setSuite: (suiteId: string | null) => void
  toggleElevator: () => void
  toggleConcierge: () => void
  grantDeepAccess: () => void
}

const ShellContext = createContext<ShellContextType | null>(null)

export function useShell() {
  const ctx = useContext(ShellContext)
  if (!ctx) throw new Error("useShell must be used within WCMSTRShell")
  return ctx
}

interface WCMSTRShellProps {
  children: ReactNode
  defaultMode?: GalaxyMode
}

export function WCMSTRShell({ children, defaultMode = "public" }: WCMSTRShellProps) {
  const [state, setState] = useState<ShellState>({
    mode: defaultMode,
    currentFloor: 0,
    currentSuiteId: null,
    hasDeepSignalAccess: false,
    isElevatorOpen: false,
    isConciergeOpen: false,
  })

  const setMode = (mode: GalaxyMode) => setState((s) => ({ ...s, mode, currentFloor: 0, currentSuiteId: null }))
  const setFloor = (floor: number) => setState((s) => ({ ...s, currentFloor: floor, currentSuiteId: null }))
  const setSuite = (suiteId: string | null) => setState((s) => ({ ...s, currentSuiteId: suiteId }))
  const toggleElevator = () => setState((s) => ({ ...s, isElevatorOpen: !s.isElevatorOpen }))
  const toggleConcierge = () => setState((s) => ({ ...s, isConciergeOpen: !s.isConciergeOpen }))
  const grantDeepAccess = () => setState((s) => ({ ...s, hasDeepSignalAccess: true }))

  const contextValue: ShellContextType = {
    ...state,
    setMode,
    setFloor,
    setSuite,
    toggleElevator,
    toggleConcierge,
    grantDeepAccess,
  }

  return (
    <ShellContext.Provider value={contextValue}>
      <div className="min-h-screen bg-black text-white">
        {children}

        {/* Economy HUD - always visible except investor mode */}
        {state.mode !== "investor" && <EconomyHUD compact />}
      </div>
    </ShellContext.Provider>
  )
}
