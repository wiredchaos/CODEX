"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { cn } from "@/lib/utils"
import { useRealm } from "@/contexts/realm-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"

type Message = {
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

export function AIAssistant() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "NEURO META X interface initialized. How may I assist with WIRED CHAOS META navigation?",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const { activeRealm } = useRealm()
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    const userMessage: Message = {
      role: "user",
      content: input,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      const response = await fetch("/api/ai-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, userMessage].map((m) => ({ role: m.role, content: m.content })),
          realm: activeRealm,
        }),
      })

      const data = await response.json()

      const assistantMessage: Message = {
        role: "assistant",
        content: data.message,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, assistantMessage])
    } catch (error) {
      console.error("[v0] AI chat error:", error)
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: "System error. Unable to process request. Please try again.",
          timestamp: new Date(),
        },
      ])
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <>
      {/* Floating AI button */}
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          "fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full neon-touch card-neon",
          "glass-strong shadow-2xl transition-all duration-300",
          isOpen && "scale-0 opacity-0",
        )}
        aria-label="Open AI Assistant"
      >
        <span className="text-xl" aria-hidden="true">
          ◇
        </span>
      </Button>

      {/* AI Chat Panel */}
      <div
        className={cn(
          "fixed bottom-6 right-6 z-50 w-full max-w-md h-[500px] glass-strong neon-touch card-neon rounded-lg transition-all duration-500 shadow-2xl",
          isOpen ? "scale-100 opacity-100" : "scale-0 opacity-0 pointer-events-none",
        )}
        role="dialog"
        aria-label="AI Assistant Chat"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center gap-3">
            <span className="text-accent text-xl" aria-hidden="true">
              ◇
            </span>
            <div>
              <h3 className="font-[var(--font-bebas)] text-lg tracking-tight">NEURO META X</h3>
              <p className="font-mono text-xs text-muted-foreground">AI Navigation Assistant</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setIsOpen(false)} className="neon-touch">
            ✕
          </Button>
        </div>

        {/* Messages */}
        <ScrollArea className="h-[340px] p-4" ref={scrollRef}>
          <div className="space-y-4">
            {messages.map((message, index) => (
              <div key={index} className={cn("flex gap-3", message.role === "user" ? "justify-end" : "justify-start")}>
                <div
                  className={cn(
                    "max-w-[80%] p-3 rounded-lg glass-subtle",
                    message.role === "user" ? "bg-accent/10 border border-accent/30" : "border border-border",
                  )}
                >
                  <p className="font-mono text-sm leading-relaxed">{message.content}</p>
                  <span className="font-mono text-[10px] text-muted-foreground mt-2 block">
                    {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </span>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex gap-3 justify-start">
                <div className="max-w-[80%] p-3 rounded-lg glass-subtle border border-border">
                  <div className="flex gap-1">
                    <span className="w-2 h-2 rounded-full bg-accent animate-pulse" />
                    <span className="w-2 h-2 rounded-full bg-accent animate-pulse" style={{ animationDelay: "0.2s" }} />
                    <span className="w-2 h-2 rounded-full bg-accent animate-pulse" style={{ animationDelay: "0.4s" }} />
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Input */}
        <form onSubmit={handleSubmit} className="p-4 border-t border-border">
          <div className="flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about WIRED CHAOS META..."
              className="font-mono text-sm glass-subtle neon-touch"
              disabled={isLoading}
            />
            <Button type="submit" disabled={isLoading} className="neon-touch">
              Send
            </Button>
          </div>
        </form>
      </div>
    </>
  )
}
