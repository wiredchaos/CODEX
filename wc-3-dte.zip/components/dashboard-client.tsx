"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { createClient } from "@/lib/supabase/client"
import type { User } from "@supabase/supabase-js"
import { ArrowLeft, LogOut, UserIcon, Zap, Trophy, Brain, Activity, Gamepad2, BookOpen, Settings } from "lucide-react"
import { LiveCircuitry } from "@/components/live-circuitry"

const DASH_COLORS = {
  primary: "#00FFF7",
  secondary: "#FF4500",
  accent: "#FFD700",
  success: "#00FF88",
  dark: "#000000",
  glow: "rgba(0, 255, 247, 0.5)",
}

interface DashboardClientProps {
  user: User
  profile: {
    id: string
    display_name?: string
    avatar_url?: string
    xp?: number
    level?: number
    current_streak?: number
  } | null
  hemisphereData: {
    neuralis_index?: number
    chaosphere_index?: number
    hemisphere?: string
    stability_trend?: string
  } | null
}

export function DashboardClient({ user, profile, hemisphereData }: DashboardClientProps) {
  const router = useRouter()
  const [isLoggingOut, setIsLoggingOut] = useState(false)

  const handleLogout = async () => {
    setIsLoggingOut(true)
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push("/")
  }

  const quickLinks = [
    { label: "HRM Training", icon: Gamepad2, href: "/hrm", color: "#00FF88" },
    { label: "NPC Agents", icon: Brain, href: "/npc", color: "#00FFF7" },
    { label: "789 Studios", icon: Activity, href: "/789", color: "#FFD700" },
    { label: "VAULT 33", icon: BookOpen, href: "/vault33", color: "#A020F0" },
  ]

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: DASH_COLORS.dark }}>
      <LiveCircuitry />

      {/* Grid Background */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${DASH_COLORS.primary}15 1px, transparent 1px),
            linear-gradient(to bottom, ${DASH_COLORS.primary}15 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Header */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(0, 0, 0, 0.9)",
          borderColor: `${DASH_COLORS.primary}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link
                href="/"
                className="flex items-center gap-2 transition-colors hover:opacity-80"
                style={{ color: DASH_COLORS.primary }}
              >
                <ArrowLeft className="w-5 h-5" />
                <span className="font-mono text-sm uppercase hidden sm:inline">Lobby</span>
              </Link>
              <div className="w-px h-6" style={{ background: `${DASH_COLORS.primary}30` }} />
              <h1 className="font-display text-xl uppercase tracking-wider" style={{ color: DASH_COLORS.primary }}>
                Dashboard
              </h1>
            </div>
            <div className="flex items-center gap-4">
              <Link
                href="/settings"
                className="p-2 rounded-lg transition-colors"
                style={{ color: DASH_COLORS.primary }}
              >
                <Settings className="w-5 h-5" />
              </Link>
              <button
                onClick={handleLogout}
                disabled={isLoggingOut}
                className="flex items-center gap-2 px-4 py-2 rounded-lg font-mono text-sm transition-all"
                style={{
                  background: `${DASH_COLORS.secondary}20`,
                  border: `1px solid ${DASH_COLORS.secondary}`,
                  color: DASH_COLORS.secondary,
                }}
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">{isLoggingOut ? "..." : "Logout"}</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* User Profile Card */}
        <div
          className="p-6 rounded-2xl mb-8"
          style={{
            background: "rgba(0, 0, 0, 0.6)",
            border: `1px solid ${DASH_COLORS.primary}30`,
          }}
        >
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
            <div
              className="w-20 h-20 rounded-xl flex items-center justify-center"
              style={{ background: `${DASH_COLORS.primary}20` }}
            >
              {profile?.avatar_url ? (
                <img
                  src={profile.avatar_url || "/placeholder.svg"}
                  alt="Avatar"
                  className="w-full h-full object-cover rounded-xl"
                />
              ) : (
                <UserIcon className="w-10 h-10" style={{ color: DASH_COLORS.primary }} />
              )}
            </div>
            <div className="flex-1">
              <h2 className="font-display text-2xl text-white mb-1">
                {profile?.display_name || user.email?.split("@")[0] || "Operator"}
              </h2>
              <p className="font-mono text-sm text-neutral-400 mb-3">{user.email}</p>
              <div className="flex flex-wrap gap-4">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4" style={{ color: DASH_COLORS.accent }} />
                  <span className="font-mono text-sm" style={{ color: DASH_COLORS.accent }}>
                    {profile?.xp || 0} XP
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Trophy className="w-4 h-4" style={{ color: DASH_COLORS.primary }} />
                  <span className="font-mono text-sm" style={{ color: DASH_COLORS.primary }}>
                    Level {profile?.level || 1}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4" style={{ color: DASH_COLORS.success }} />
                  <span className="font-mono text-sm" style={{ color: DASH_COLORS.success }}>
                    {profile?.current_streak || 0} day streak
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Hemisphere Status */}
        {hemisphereData && (
          <div
            className="p-6 rounded-2xl mb-8"
            style={{
              background: "rgba(0, 0, 0, 0.6)",
              border: `1px solid ${DASH_COLORS.primary}30`,
            }}
          >
            <h3 className="font-mono text-sm uppercase tracking-wider mb-4" style={{ color: DASH_COLORS.primary }}>
              Hemisphere Status
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-display" style={{ color: DASH_COLORS.primary }}>
                  {Math.round(hemisphereData.neuralis_index || 0)}
                </div>
                <div className="text-xs font-mono text-neutral-500 uppercase">Neuralis</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-display" style={{ color: DASH_COLORS.secondary }}>
                  {Math.round(hemisphereData.chaosphere_index || 0)}
                </div>
                <div className="text-xs font-mono text-neutral-500 uppercase">Chaosphere</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-display text-white capitalize">{hemisphereData.hemisphere || "N/A"}</div>
                <div className="text-xs font-mono text-neutral-500 uppercase">Dominant</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-display" style={{ color: DASH_COLORS.success }}>
                  {hemisphereData.stability_trend || "N/A"}
                </div>
                <div className="text-xs font-mono text-neutral-500 uppercase">Trend</div>
              </div>
            </div>
          </div>
        )}

        {/* Quick Links */}
        <h3 className="font-mono text-sm uppercase tracking-wider mb-4" style={{ color: DASH_COLORS.primary }}>
          Quick Access
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {quickLinks.map((link) => {
            const Icon = link.icon
            return (
              <Link
                key={link.href}
                href={link.href}
                className="p-4 rounded-xl text-center transition-all hover:scale-[1.02]"
                style={{
                  background: "rgba(0, 0, 0, 0.6)",
                  border: `1px solid ${link.color}30`,
                }}
              >
                <div
                  className="w-12 h-12 mx-auto mb-3 rounded-xl flex items-center justify-center"
                  style={{ background: `${link.color}20` }}
                >
                  <Icon className="w-6 h-6" style={{ color: link.color }} />
                </div>
                <div className="font-mono text-sm" style={{ color: link.color }}>
                  {link.label}
                </div>
              </Link>
            )
          })}
        </div>
      </main>
    </div>
  )
}
