"use client"

import { useRouter } from "next/navigation"
import { ElevatorTravel, usePatchLifecycle } from "./elevator-travel"

export function BackToLobbyButton() {
  const router = useRouter()
  const { onExitPatch, panicExit } = usePatchLifecycle("patch_789_studios")

  return <ElevatorTravel currentFloor="789" onExitPatch={onExitPatch} />
}

// Keeping old name for backwards compatibility but it now uses elevator POV
export { BackToLobbyButton as ElevatorReturnButton }
