import { createClient } from "@supabase/supabase-js"

export type CreditTransactionType = "topup" | "spend" | "refund" | "reward" | "transfer" | "subscription"

export interface CreditTransaction {
  id: string
  userId: string
  amount: number
  type: CreditTransactionType
  source: string
  sourceRef?: string
  description: string
  balanceAfter: number
  metadata?: Record<string, unknown>
  createdAt: Date
}

export class CreditsService {
  private supabase

  constructor() {
    this.supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
  }

  async getBalance(userId: string): Promise<number> {
    const { data } = await this.supabase
      .from("wc_credits_ledger")
      .select("balance_after")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle()

    return data?.balance_after ?? 0
  }

  async addCredits(
    userId: string,
    amount: number,
    source: string,
    description: string,
    sourceRef?: string,
    metadata?: Record<string, unknown>,
  ): Promise<CreditTransaction | null> {
    const currentBalance = await this.getBalance(userId)
    const newBalance = currentBalance + amount

    const { data, error } = await this.supabase
      .from("wc_credits_ledger")
      .insert({
        user_id: userId,
        amount,
        type: "topup",
        source,
        source_ref: sourceRef,
        description,
        balance_after: newBalance,
        metadata,
      })
      .select()
      .single()

    if (error) {
      console.error("[v0] Credits add error:", error)
      return null
    }

    return {
      id: data.id,
      userId: data.user_id,
      amount: data.amount,
      type: data.type,
      source: data.source,
      sourceRef: data.source_ref,
      description: data.description,
      balanceAfter: data.balance_after,
      metadata: data.metadata,
      createdAt: new Date(data.created_at),
    }
  }

  async spendCredits(
    userId: string,
    amount: number,
    source: string,
    description: string,
    sourceRef?: string,
    metadata?: Record<string, unknown>,
  ): Promise<CreditTransaction | null> {
    const currentBalance = await this.getBalance(userId)

    if (currentBalance < amount) {
      console.error("[v0] Insufficient credits:", { currentBalance, requested: amount })
      return null
    }

    const newBalance = currentBalance - amount

    const { data, error } = await this.supabase
      .from("wc_credits_ledger")
      .insert({
        user_id: userId,
        amount: -amount,
        type: "spend",
        source,
        source_ref: sourceRef,
        description,
        balance_after: newBalance,
        metadata,
      })
      .select()
      .single()

    if (error) {
      console.error("[v0] Credits spend error:", error)
      return null
    }

    return {
      id: data.id,
      userId: data.user_id,
      amount: Math.abs(data.amount),
      type: data.type,
      source: data.source,
      sourceRef: data.source_ref,
      description: data.description,
      balanceAfter: data.balance_after,
      metadata: data.metadata,
      createdAt: new Date(data.created_at),
    }
  }

  async getTransactionHistory(userId: string, limit = 50, offset = 0): Promise<CreditTransaction[]> {
    const { data } = await this.supabase
      .from("wc_credits_ledger")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1)

    if (!data) return []

    return data.map((tx) => ({
      id: tx.id,
      userId: tx.user_id,
      amount: Math.abs(tx.amount),
      type: tx.type,
      source: tx.source,
      sourceRef: tx.source_ref,
      description: tx.description,
      balanceAfter: tx.balance_after,
      metadata: tx.metadata,
      createdAt: new Date(tx.created_at),
    }))
  }
}

export const creditsService = new CreditsService()
