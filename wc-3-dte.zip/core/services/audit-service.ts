import { createClient } from "@supabase/supabase-js"

export type AuditAction =
  | "create"
  | "read"
  | "update"
  | "delete"
  | "login"
  | "logout"
  | "access"
  | "deny"
  | "execute"
  | "error"

export interface AuditLogEntry {
  id: string
  userId?: string
  agentId?: string
  action: AuditAction
  entityType: string
  entityId?: string
  oldData?: Record<string, unknown>
  newData?: Record<string, unknown>
  metadata?: Record<string, unknown>
  ipAddress?: string
  createdAt: Date
}

export class AuditService {
  private supabase

  constructor() {
    this.supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
  }

  async log(entry: Omit<AuditLogEntry, "id" | "createdAt">): Promise<void> {
    const { error } = await this.supabase.from("wc_core_audit_log").insert({
      user_id: entry.userId,
      agent_id: entry.agentId,
      action: entry.action,
      entity_type: entry.entityType,
      entity_id: entry.entityId,
      old_data: entry.oldData,
      new_data: entry.newData,
      metadata: entry.metadata,
      ip_address: entry.ipAddress,
    })

    if (error) {
      console.error("[v0] Audit log error:", error)
    }
  }

  async getAuditLog(
    filters: {
      userId?: string
      entityType?: string
      action?: AuditAction
      startDate?: Date
      endDate?: Date
    },
    limit = 100,
    offset = 0,
  ): Promise<AuditLogEntry[]> {
    let query = this.supabase
      .from("wc_core_audit_log")
      .select("*")
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1)

    if (filters.userId) {
      query = query.eq("user_id", filters.userId)
    }
    if (filters.entityType) {
      query = query.eq("entity_type", filters.entityType)
    }
    if (filters.action) {
      query = query.eq("action", filters.action)
    }
    if (filters.startDate) {
      query = query.gte("created_at", filters.startDate.toISOString())
    }
    if (filters.endDate) {
      query = query.lte("created_at", filters.endDate.toISOString())
    }

    const { data } = await query

    if (!data) return []

    return data.map((log) => ({
      id: log.id,
      userId: log.user_id,
      agentId: log.agent_id,
      action: log.action,
      entityType: log.entity_type,
      entityId: log.entity_id,
      oldData: log.old_data,
      newData: log.new_data,
      metadata: log.metadata,
      ipAddress: log.ip_address,
      createdAt: new Date(log.created_at),
    }))
  }
}

export const auditService = new AuditService()
