import { createClient } from "@supabase/supabase-js"

export type RealmType = "business" | "akashic" | "both" | "system"
export type AccessLevel = "lite" | "full" | "premium"

export interface RealmAccess {
  realm: RealmType
  accessLevel: AccessLevel
  hasFenAccess: boolean
  canAccessAkashic: boolean
}

export interface PatchConfig {
  id: string
  name: string
  realm: RealmType
  isLiteVersion: boolean
  businessVersionId?: string
  akashicVersionId?: string
  route: string
}

// Business-side patches (LITE version by default)
const BUSINESS_PATCHES = [
  "credit-repair",
  "neura",
  "mall",
  "university",
  "fashion",
  "789-studios",
  "789-ott",
  "33-3-fm",
  "npc",
  "games",
  "cbe",
  "creator-codex",
]

// Akashic-side patches (FEN access required)
const AKASHIC_PATCHES = ["vault33", "akira-codex", "neteru", "echo-engineers", "underground", "dynamis", "cipher-hunt"]

// Patches that exist in BOTH realms with mirrored versions
const DUAL_REALM_PATCHES = ["university", "games", "fashion", "mall"]

export class RealmFirewall {
  private supabase

  constructor() {
    this.supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
  }

  async getUserRealmAccess(userId: string): Promise<RealmAccess> {
    // Check user's realm preferences and FEN access
    const { data: profile } = await this.supabase.from("profiles").select("*").eq("id", userId).maybeSingle()

    const { data: fenProgress } = await this.supabase
      .from("fen_user_progress")
      .select("*")
      .eq("user_id", userId)
      .maybeSingle()

    const hasFenAccess = !!fenProgress && (fenProgress.chaos_xp > 0 || fenProgress.vault_keys > 0)

    // Default: Business LITE unless user has FEN access
    if (!hasFenAccess) {
      return {
        realm: "business",
        accessLevel: "lite",
        hasFenAccess: false,
        canAccessAkashic: false,
      }
    }

    // User has FEN access - check their preference
    const { data: realmPref } = await this.supabase
      .from("hemisphere_profiles")
      .select("*")
      .eq("user_id", userId)
      .maybeSingle()

    const prefersBoth = realmPref?.akashic_affinity > 0 && realmPref?.business_affinity > 0

    return {
      realm: prefersBoth ? "both" : hasFenAccess ? "akashic" : "business",
      accessLevel: "full",
      hasFenAccess: true,
      canAccessAkashic: hasFenAccess,
    }
  }

  async getAccessiblePatches(userId: string): Promise<PatchConfig[]> {
    const access = await this.getUserRealmAccess(userId)

    const { data: patches } = await this.supabase.from("wc_patches").select("*").eq("status", "active")

    if (!patches) return []

    return patches
      .filter((patch) => {
        // System patches always accessible
        if (patch.realm === "system") return true

        // Business patches accessible to all
        if (patch.realm === "business") {
          // Return lite version if user doesn't have full access
          return true
        }

        // Akashic patches only if user has FEN access
        if (patch.realm === "akashic") {
          return access.canAccessAkashic
        }

        // Dual realm patches
        if (patch.realm === "both") {
          return true
        }

        return false
      })
      .map((patch) => ({
        id: patch.id,
        name: patch.name || patch.patch_name,
        realm: patch.realm,
        isLiteVersion: access.accessLevel === "lite" && patch.realm === "business",
        businessVersionId: patch.business_version_id,
        akashicVersionId: patch.akashic_version_id,
        route: patch.route,
      }))
  }

  async createAkashicMirror(businessPatchId: string): Promise<string | null> {
    const { data: businessPatch } = await this.supabase
      .from("wc_patches")
      .select("*")
      .eq("id", businessPatchId)
      .single()

    if (!businessPatch) return null

    const akashicVersion = {
      ...businessPatch,
      id: undefined,
      realm: "akashic",
      name: `${businessPatch.name} (Akashic)`,
      slug: `${businessPatch.slug}-akashic`,
      route: businessPatch.route.replace("/", "/fen/"),
      is_lite_version: false,
      business_version_id: businessPatchId,
    }

    const { data: created } = await this.supabase.from("wc_patches").insert(akashicVersion).select().single()

    if (created) {
      // Link back to business version
      await this.supabase.from("wc_patches").update({ akashic_version_id: created.id }).eq("id", businessPatchId)

      return created.id
    }

    return null
  }

  isPatchAccessible(patchName: string, access: RealmAccess): boolean {
    const isBusinessPatch = BUSINESS_PATCHES.includes(patchName)
    const isAkashicPatch = AKASHIC_PATCHES.includes(patchName)
    const isDualRealm = DUAL_REALM_PATCHES.includes(patchName)

    if (isBusinessPatch || isDualRealm) return true
    if (isAkashicPatch) return access.canAccessAkashic

    return false
  }

  getRealmColor(realm: RealmType): string {
    switch (realm) {
      case "business":
        return "#0066FF" // Blue
      case "akashic":
        return "#9333EA" // Purple
      case "both":
        return "#00F0FF" // Cyan
      case "system":
        return "#FFD700" // Gold
      default:
        return "#FFFFFF"
    }
  }
}

export const realmFirewall = new RealmFirewall()
