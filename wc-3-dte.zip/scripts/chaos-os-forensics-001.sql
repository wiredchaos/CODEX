-- CHAOS OS Forensics + Agentic Schema Migration
-- Idempotent - safe to run multiple times

-- ForensicSource table
CREATE TABLE IF NOT EXISTS forensic_sources (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type TEXT NOT NULL DEFAULT 'github',
  name TEXT NOT NULL,
  repo_url TEXT NOT NULL,
  branch TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ForensicRun table
CREATE TABLE IF NOT EXISTS forensic_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_id UUID NOT NULL REFERENCES forensic_sources(id) ON DELETE CASCADE,
  mode TEXT NOT NULL DEFAULT 'quick',
  status TEXT NOT NULL DEFAULT 'queued',
  started_at TIMESTAMPTZ,
  finished_at TIMESTAMPTZ,
  files_indexed INTEGER NOT NULL DEFAULT 0,
  chunks_indexed INTEGER NOT NULL DEFAULT 0,
  findings_json TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ForensicDoc table
CREATE TABLE IF NOT EXISTS forensic_docs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_id UUID NOT NULL REFERENCES forensic_sources(id) ON DELETE CASCADE,
  path TEXT NOT NULL,
  ext TEXT NOT NULL,
  sha TEXT NOT NULL,
  size_bytes INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(source_id, path, sha)
);

-- ForensicChunk table
CREATE TABLE IF NOT EXISTS forensic_chunks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  doc_id UUID NOT NULL REFERENCES forensic_docs(id) ON DELETE CASCADE,
  idx INTEGER NOT NULL,
  text TEXT NOT NULL,
  tokens INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_forensic_chunks_doc_id ON forensic_chunks(doc_id);

-- Full-text search index on chunks
CREATE INDEX IF NOT EXISTS idx_forensic_chunks_text_search 
ON forensic_chunks USING gin(to_tsvector('english', text));

-- AgenticJob table
CREATE TABLE IF NOT EXISTS agentic_jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  kind TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'queued',
  input_json TEXT NOT NULL,
  plan_json TEXT,
  result_json TEXT,
  error TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  started_at TIMESTAMPTZ,
  finished_at TIMESTAMPTZ
);

-- AgenticJobEvent table
CREATE TABLE IF NOT EXISTS agentic_job_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id UUID NOT NULL REFERENCES agentic_jobs(id) ON DELETE CASCADE,
  ts TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  level TEXT NOT NULL DEFAULT 'info',
  message TEXT NOT NULL,
  payload_json TEXT
);

CREATE INDEX IF NOT EXISTS idx_agentic_job_events_job_id ON agentic_job_events(job_id);

-- Grant permissions
GRANT ALL ON forensic_sources TO authenticated;
GRANT ALL ON forensic_runs TO authenticated;
GRANT ALL ON forensic_docs TO authenticated;
GRANT ALL ON forensic_chunks TO authenticated;
GRANT ALL ON agentic_jobs TO authenticated;
GRANT ALL ON agentic_job_events TO authenticated;
