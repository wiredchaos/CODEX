import type { PatchRegistryEntry } from "@/schemas/patch.schema"

export const PATCH_REGISTRY: Record<string, PatchRegistryEntry> = {
  patch_33_3fm_dogechain: {
    id: "patch_33_3fm_dogechain",
    displayName: "33.3FM DOGECHAIN",
    slug: "33-3fm",
    systemClass: "Multimedia Broadcast Patch",
    status: "active",
    owner: "NEURO",
    realm: "business",
    acceptedPayments: ["DOGE", "SOL", "ETH", "BTC", "HBAR", "XRP"],
    explicitExclusions: ["WLFI", "VRG33589"],
  },
  patch_789_studios: {
    id: "patch_789_studios",
    displayName: "789 STUDIOS",
    slug: "789",
    systemClass: "Production Studio Patch",
    status: "active",
    owner: "NEURO",
    realm: "business",
    acceptedPayments: ["DOGE", "SOL", "ETH"],
  },
  patch_vault33: {
    id: "patch_vault33",
    displayName: "VAULT 33",
    slug: "vault33",
    systemClass: "Akashic Archive Patch",
    status: "active",
    owner: "NEURO",
    realm: "akashic",
  },
  patch_hrm_games: {
    id: "patch_hrm_games",
    displayName: "HRM TRAINING",
    slug: "hrm",
    systemClass: "Training Games Patch",
    status: "active",
    owner: "NEURO",
    realm: "business",
  },
  patch_neura: {
    id: "patch_neura",
    displayName: "NEURA",
    slug: "neura",
    systemClass: "Intelligent Legacy Architecture",
    status: "active",
    owner: "NEURO",
    realm: "business",
  },
  patch_credit_repair: {
    id: "patch_credit_repair",
    displayName: "CREDIT REPAIR",
    slug: "credit-repair",
    systemClass: "Financial Wellness Patch",
    status: "active",
    owner: "NEURO",
    realm: "business",
  },
}

export function getPatch(id: string): PatchRegistryEntry | undefined {
  return PATCH_REGISTRY[id]
}

export function getPatchBySlug(slug: string): PatchRegistryEntry | undefined {
  return Object.values(PATCH_REGISTRY).find((p) => p.slug === slug)
}

export function getActivePatches(): PatchRegistryEntry[] {
  return Object.values(PATCH_REGISTRY).filter((p) => p.status === "active")
}

export function getPatchesByRealm(realm: "business" | "akashic" | "universal"): PatchRegistryEntry[] {
  return Object.values(PATCH_REGISTRY).filter((p) => p.realm === realm)
}
