# WIRED CHAOS META - Render Prompt Quick Card

## API Endpoints

```
GET /api/render/prompt
```

### Query Parameters

| Param | Description | Example |
|-------|-------------|---------|
| `id` | Get specific prompt | `?id=npc-avatar-base` |
| `tag` | Filter by tag | `?tag=avatar` |
| `realm` | Filter by realm | `?realm=neuralis` |
| `search` | Text search | `?search=vault` |
| `list` | List all IDs | `?list=true` |
| `palette` | Include color palette | `?palette=true` |

### POST Batch Request

```json
POST /api/render/prompt
{
  "ids": ["npc-avatar-base", "env-vault33", "globe-standard"]
}
```

---

## Available Prompts

### Avatars
- `npc-avatar-base` - Base NPC avatar template
- `npc-avatar-trinity` - Trinity Node visualization

### Environments
- `env-vault33` - VAULT 33 Akashic interior
- `env-studio789` - Studio 789 production floor
- `env-floor333` - Neuralis business hub

### Globe Variants
- `globe-standard` - Lei lines + portals
- `globe-flat-earth` - Flat earth belief model
- `globe-inner-earth` - Hollow earth cross-section

### NFT/Badges
- `badge-frequency-key` - 33.3FM access key
- `badge-akashic-record` - Knowledge fragment

### Game Assets
- `game-hrm-card` - HRM training card
- `game-labyrinth-tile` - Labyrinth tile

---

## Color Palette

```typescript
PALETTE.primary.cyan    = '#00E5FF'
PALETTE.primary.orange  = '#FF4500'
PALETTE.primary.black   = '#0A0A0A'

PALETTE.realm.neuralis   = '#00E5FF'  // Business
PALETTE.realm.chaosphere = '#FF4500'  // Creative
PALETTE.realm.akashic    = '#8B5CF6'  // Archive
PALETTE.realm.underground = '#10B981' // Hidden
```

---

## Tags

`avatar` | `environment` | `ui` | `icon` | `badge` | `nft` | `game` | `studio` | `vault` | `globe` | `neuralis` | `chaosphere` | `akashic`

---

## Usage Example

```typescript
import { getPrompt, PALETTE } from '@/lib/render/prompt-registry'

const prompt = getPrompt('npc-avatar-base')
console.log(prompt?.prompt) // Full generation prompt
console.log(PALETTE.primary.cyan) // #00E5FF
