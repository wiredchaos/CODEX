export interface FloorConfig {
  id: string
  label: string
  sublabel: string
  route: string
  color: string
  icon: string
  realm: "business" | "akashic" | "universal"
  section: "business" | "operations" | "fen"
}

export interface RouteCard {
  id: string
  recommendedFloors: string[]
  mode: "guided" | "elevator" | "hybrid"
  userLevel: "noob" | "intermediate" | "advanced"
  handoffSummary: string
  timestamp: number
  track: "business" | "akashic" | "both"
}

export interface ElevatorState {
  currentFloor: string
  previousFloor: string | null
  routeCard: RouteCard | null
  isTransitioning: boolean
  reducedMotion: boolean
}

export interface PatchLifecycle {
  onEnterPatch: () => void | Promise<void>
  onExitPatch: () => void | Promise<void>
  panicExit: () => void
}

export interface ElevatorExitEvent {
  type: "PATCH_EXIT_TO_ELEVATOR"
  payload: {
    routeCard: RouteCard | null
    handoffSummary: string
    recommendedFloors: string[]
    uiPrefs: {
      reducedMotion: boolean
      fontScale: number
      contrast: "normal" | "high"
    }
  }
}
