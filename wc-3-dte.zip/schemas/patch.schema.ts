import { z } from "zod"

export const FloorConfigSchema = z.object({
  id: z.string(),
  label: z.string(),
  sublabel: z.string(),
  route: z.string(),
  color: z.string(),
  icon: z.string(),
  realm: z.enum(["business", "akashic", "universal"]),
  section: z.enum(["business", "operations", "fen"]),
})

export const RouteCardSchema = z.object({
  id: z.string(),
  recommendedFloors: z.array(z.string()),
  mode: z.enum(["guided", "elevator", "hybrid"]),
  userLevel: z.enum(["noob", "intermediate", "advanced"]),
  handoffSummary: z.string(),
  timestamp: z.number(),
  track: z.enum(["business", "akashic", "both"]),
})

export const PatchRegistryEntrySchema = z.object({
  id: z.string(),
  displayName: z.string(),
  slug: z.string(),
  systemClass: z.string(),
  status: z.enum(["active", "inactive", "maintenance"]),
  owner: z.string(),
  realm: z.enum(["business", "akashic", "universal"]),
  acceptedPayments: z.array(z.string()).optional(),
  explicitExclusions: z.array(z.string()).optional(),
})

export type FloorConfig = z.infer<typeof FloorConfigSchema>
export type RouteCard = z.infer<typeof RouteCardSchema>
export type PatchRegistryEntry = z.infer<typeof PatchRegistryEntrySchema>
