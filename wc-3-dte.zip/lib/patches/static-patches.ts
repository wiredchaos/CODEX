// Canonical Patch Registry for WIRED CHAOS META
// This file serves as the source of truth for all patches

export type PatchStatus = "active" | "dormant" | "broken" | "external"
export type PatchRealm = "neuralis" | "chaosphere" | "both" | "external"

export interface PatchDefinition {
  id: string
  name: string
  displayName: string
  description: string
  route: string
  realm: PatchRealm
  status: PatchStatus
  color: string
  tables: string[]
  hasAkashicVersion: boolean
  hasBusinessVersion: boolean
  capabilities: string[]
  dependencies: string[]
}

export const PATCH_REGISTRY: PatchDefinition[] = [
  // CHAOS OS Core
  {
    id: "chaos-os",
    name: "CHAOS_OS",
    displayName: "CHAOS OS",
    description: "Operating system shell for WIRED CHAOS META with forensics and agentic runtime",
    route: "/chaos-os",
    realm: "both",
    status: "active",
    color: "#8B5CF6",
    tables: [
      "agentic_jobs",
      "agentic_job_events",
      "forensic_sources",
      "forensic_runs",
      "forensic_docs",
      "forensic_chunks",
    ],
    hasAkashicVersion: true,
    hasBusinessVersion: true,
    capabilities: ["forensic_scan", "agentic_jobs", "brain_chat", "builder", "university"],
    dependencies: [],
  },
  {
    id: "chaos-brain",
    name: "CHAOS_BRAIN",
    displayName: "CHAOS BRAIN",
    description: "AI conversational interface for system control",
    route: "/chaos-os/brain-console",
    realm: "both",
    status: "active",
    color: "#00FFFF",
    tables: [],
    hasAkashicVersion: true,
    hasBusinessVersion: true,
    capabilities: ["chat", "command_execution"],
    dependencies: ["chaos-os"],
  },
  {
    id: "bwb",
    name: "BWB",
    displayName: "Build With Brain",
    description: "AI-assisted development environment",
    route: "/chaos-os/bwb",
    realm: "both",
    status: "active",
    color: "#FF6B00",
    tables: [],
    hasAkashicVersion: true,
    hasBusinessVersion: true,
    capabilities: ["code_generation", "project_scaffolding"],
    dependencies: ["chaos-os", "chaos-brain"],
  },
  {
    id: "chaos-build",
    name: "CHAOS_BUILD",
    displayName: "CHAOS Builder",
    description: "Visual builder for WIRED CHAOS components",
    route: "/chaos-os/builder",
    realm: "both",
    status: "active",
    color: "#FFD700",
    tables: ["wc_scenes", "wc_3d_assets", "wc_3d_asset_variants"],
    hasAkashicVersion: true,
    hasBusinessVersion: true,
    capabilities: ["visual_building", "scene_creation", "asset_management"],
    dependencies: ["chaos-os"],
  },
  // Core Floors
  {
    id: "789-studios",
    name: "789_STUDIOS",
    displayName: "789 Studios",
    description: "Creator economy, OTT streaming, talent management, crew coordination",
    route: "/789",
    realm: "chaosphere",
    status: "active",
    color: "#FFD700",
    tables: ["wc_creator_789_profiles", "wc_creator_789_earnings", "videos", "creators", "series", "seasons"],
    hasAkashicVersion: false,
    hasBusinessVersion: true,
    capabilities: ["ott_streaming", "creator_profiles", "talent_management", "crew_management"],
    dependencies: [],
  },
  {
    id: "333-fm",
    name: "33_3FM",
    displayName: "33.3FM Signal",
    description: "Underground radio, NFT museum, IP audit system",
    route: "/333",
    realm: "neuralis",
    status: "active",
    color: "#00BFFF",
    tables: ["fm_tracks", "fm_creators", "fm_podcasts", "museum_galleries", "museum_nft_exhibits", "museum_ip_audits"],
    hasAkashicVersion: true,
    hasBusinessVersion: true,
    capabilities: ["radio_streaming", "museum_curation", "ip_verification"],
    dependencies: [],
  },
  {
    id: "vault33",
    name: "VAULT_33",
    displayName: "VAULT 33",
    description: "Akashic vault with 9 layers, gas sigils, cipher keys",
    route: "/vault33",
    realm: "neuralis",
    status: "active",
    color: "#A020F0",
    tables: ["codex_entry", "akashic_glossary_entry", "ug_vault_nodes", "ug_cipher_keys"],
    hasAkashicVersion: true,
    hasBusinessVersion: false,
    capabilities: ["akashic_access", "cipher_decode", "lore_reveal"],
    dependencies: [],
  },
  {
    id: "fen",
    name: "FEN_REALM",
    displayName: "FEN Realm",
    description: "Gamification engine, whitelist system, riddle gates",
    route: "/fen",
    realm: "both",
    status: "active",
    color: "#FF6B6B",
    tables: ["fen_user_progress", "fen_reward_wallet", "fen_events", "fen_wl_snapshot", "fen_config"],
    hasAkashicVersion: true,
    hasBusinessVersion: true,
    capabilities: ["gamification", "whitelist_management", "riddle_gates"],
    dependencies: [],
  },
  // Training & Education
  {
    id: "hrm",
    name: "HRM_TRAINING",
    displayName: "HRM Training Games",
    description: "6 interactive training games with 3 learning modes",
    route: "/hrm",
    realm: "both",
    status: "active",
    color: "#00FF88",
    tables: ["hrm_games", "hrm_user_game_progress", "hrm_company_configs", "hrm_company_analytics"],
    hasAkashicVersion: true,
    hasBusinessVersion: true,
    capabilities: ["training_games", "skill_assessment", "company_analytics"],
    dependencies: [],
  },
  {
    id: "npc-engine",
    name: "NPC_ENGINE",
    displayName: "NPC Engine",
    description: "AI agents, job execution, quest system, training plans",
    route: "/npc",
    realm: "both",
    status: "active",
    color: "#FF4500",
    tables: ["wc_npc_agents", "wc_npc_jobs", "wc_npc_job_events", "npc_quests", "npc_lessons", "npc_progress"],
    hasAkashicVersion: true,
    hasBusinessVersion: true,
    capabilities: ["ai_agents", "job_execution", "quest_management"],
    dependencies: [],
  },
  {
    id: "university",
    name: "WIRED_CHAOS_UNIVERSITY",
    displayName: "WIRED CHAOS University",
    description: "Structured learning, certification, course management",
    route: "/chaos-os/university",
    realm: "both",
    status: "active",
    color: "#FF69B4",
    tables: ["hoc_university_course", "hoc_course_enrollment"],
    hasAkashicVersion: true,
    hasBusinessVersion: true,
    capabilities: ["courses", "certification", "progress_tracking"],
    dependencies: ["chaos-os"],
  },
  // Analytics & Telemetry
  {
    id: "hemisphere",
    name: "HEMISPHERE",
    displayName: "Hemisphere Dashboard",
    description: "Neuralis/Chaosphere balance visualization, role engine, telemetry",
    route: "/hemisphere",
    realm: "both",
    status: "active",
    color: "#00CED1",
    tables: [
      "hemisphere_profiles",
      "hemisphere_history",
      "wc_user_hemisphere_scores",
      "wc_user_roles",
      "wc_role_history",
      "wc_telemetry_events",
    ],
    hasAkashicVersion: true,
    hasBusinessVersion: true,
    capabilities: ["hemisphere_tracking", "role_assignment", "telemetry_visualization"],
    dependencies: [],
  },
  {
    id: "globe",
    name: "GLOBE_EXPLORER",
    displayName: "Globe Explorer",
    description: "3D globe with lei lines, portals, flat earth, inner earth variants",
    route: "/globe",
    realm: "both",
    status: "active",
    color: "#32CD32",
    tables: [],
    hasAkashicVersion: true,
    hasBusinessVersion: false,
    capabilities: ["3d_visualization", "belief_variants", "sacred_sites"],
    dependencies: [],
  },
  // Economy & Finance
  {
    id: "credit-repair",
    name: "CREDIT_REPAIR",
    displayName: "Credit Repair Bootcamp",
    description: "Credit education, dispute letter generation, score tracking",
    route: "/credit-repair",
    realm: "both",
    status: "active",
    color: "#FFD700",
    tables: [
      "cr_credit_profiles",
      "cr_dispute_letters",
      "cr_dispute_items",
      "cr_bootcamp_modules",
      "cr_bootcamp_progress",
    ],
    hasAkashicVersion: false,
    hasBusinessVersion: true,
    capabilities: ["credit_education", "dispute_generation", "score_tracking"],
    dependencies: [],
  },
  {
    id: "dynamis",
    name: "DYNAMIS_VAULTS",
    displayName: "Dynamis Vaults",
    description: "NTRU leasing, council seats, BTC DCA flows",
    route: "/dynamis",
    realm: "both",
    status: "dormant",
    color: "#4ADE80",
    tables: ["dynamis_vault", "dynamis_lease", "dynamis_token", "dynamis_council_seat", "vault_fee_flows"],
    hasAkashicVersion: true,
    hasBusinessVersion: true,
    capabilities: ["ntru_leasing", "btc_dca", "council_governance"],
    dependencies: [],
  },
  // Fashion & Avatar
  {
    id: "fashion-fabricator",
    name: "FASHION_FABRICATOR",
    displayName: "Fashion Fabricator",
    description: "AI fashion design, avatar traits, NFT minting",
    route: "/fashion",
    realm: "chaosphere",
    status: "dormant",
    color: "#F472B6",
    tables: ["wc_fashion_projects", "wc_fashion_courses", "wc_fashion_listings", "wc_fashion_enrollments"],
    hasAkashicVersion: false,
    hasBusinessVersion: true,
    capabilities: ["ai_fashion", "avatar_traits", "nft_minting"],
    dependencies: [],
  },
  // Compliance
  {
    id: "neura-tax",
    name: "NEURA_TAX",
    displayName: "NEURA Tax",
    description: "Tax compliance, ISO standards, regulatory mapping",
    route: "/neura-tax",
    realm: "neuralis",
    status: "dormant",
    color: "#6366F1",
    tables: [
      "wc_iso_industry_profiles",
      "wc_iso_regulations",
      "wc_iso_controls",
      "wc_iso_audit_events",
      "wc_iso_gap_reports",
    ],
    hasAkashicVersion: false,
    hasBusinessVersion: true,
    capabilities: ["compliance_audit", "iso_mapping", "gap_analysis"],
    dependencies: [],
  },
  // External Systems
  {
    id: "creator-codex",
    name: "CREATOR_CODEX",
    displayName: "Creator Codex",
    description: "External creator workflow and asset management system",
    route: "https://creatorcodex.io",
    realm: "external",
    status: "external",
    color: "#9333EA",
    tables: [],
    hasAkashicVersion: false,
    hasBusinessVersion: true,
    capabilities: [],
    dependencies: [],
  },
  {
    id: "akira-codex",
    name: "AKIRA_CODEX",
    displayName: "Akira Codex",
    description: "External Akira lore and narrative system",
    route: "https://akiracodex.io",
    realm: "external",
    status: "external",
    color: "#EC4899",
    tables: [],
    hasAkashicVersion: true,
    hasBusinessVersion: false,
    capabilities: [],
    dependencies: [],
  },
  {
    id: "cbe",
    name: "CBE",
    displayName: "CBE Platform",
    description: "External competency-based education platform",
    route: "https://cbe.wiredchaos.io",
    realm: "external",
    status: "external",
    color: "#F59E0B",
    tables: [],
    hasAkashicVersion: true,
    hasBusinessVersion: true,
    capabilities: [],
    dependencies: [],
  },
  {
    id: "trust-launcher",
    name: "TRUST_LAUNCHER",
    displayName: "Trust Launcher",
    description: "External entity formation and trust creation",
    route: "https://trustlauncher.io",
    realm: "external",
    status: "external",
    color: "#10B981",
    tables: [],
    hasAkashicVersion: false,
    hasBusinessVersion: true,
    capabilities: [],
    dependencies: [],
  },
]

// Helper functions
export function getPatchById(id: string): PatchDefinition | undefined {
  return PATCH_REGISTRY.find((p) => p.id === id)
}

export function getPatchesByRealm(realm: PatchRealm): PatchDefinition[] {
  return PATCH_REGISTRY.filter((p) => p.realm === realm || p.realm === "both")
}

export function getPatchesByStatus(status: PatchStatus): PatchDefinition[] {
  return PATCH_REGISTRY.filter((p) => p.status === status)
}

export function getActivePatchCount(): number {
  return PATCH_REGISTRY.filter((p) => p.status === "active").length
}

export function getAllTables(): string[] {
  const tables = new Set<string>()
  PATCH_REGISTRY.forEach((p) => p.tables.forEach((t) => tables.add(t)))
  return Array.from(tables)
}
