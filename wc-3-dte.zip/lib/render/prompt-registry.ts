/**
 * WIRED CHAOS META - Render Prompt Registry
 * TypeScript registry for Trinity Engine visual generation
 *
 * Usage:
 *   import { getPrompt, searchPrompts, PALETTE } from '@/lib/render/prompt-registry'
 *   const prompt = getPrompt('npc-avatar')
 */

// WIRED CHAOS Color Palette
export const PALETTE = {
  primary: {
    cyan: "#00E5FF",
    orange: "#FF4500",
    black: "#0A0A0A",
  },
  accent: {
    teal: "#00CED1",
    coral: "#FF6B4A",
    gold: "#FFD700",
  },
  neutral: {
    dark: "#1A1A2E",
    mid: "#16213E",
    light: "#E4E4E7",
  },
  realm: {
    neuralis: "#00E5FF", // Business - Cyan
    chaosphere: "#FF4500", // Creative - Orange
    akashic: "#8B5CF6", // Archive - Violet
    underground: "#10B981", // Hidden - Emerald
  },
} as const

// Prompt Tags for categorization and search
export type PromptTag =
  | "avatar"
  | "environment"
  | "ui"
  | "icon"
  | "badge"
  | "nft"
  | "game"
  | "studio"
  | "vault"
  | "globe"
  | "neuralis"
  | "chaosphere"
  | "akashic"

export interface RenderPrompt {
  id: string
  name: string
  description: string
  prompt: string
  negativePrompt?: string
  tags: PromptTag[]
  aspectRatio: "1:1" | "16:9" | "9:16" | "4:3" | "3:4"
  style: "cyberpunk" | "neon" | "holographic" | "minimal" | "retro"
  realm: "neuralis" | "chaosphere" | "akashic" | "universal"
}

// Master Prompt Registry
export const PROMPT_REGISTRY: Record<string, RenderPrompt> = {
  // NPC Avatars
  "npc-avatar-base": {
    id: "npc-avatar-base",
    name: "NPC Avatar Base",
    description: "Base template for Neuro Prompt Command AI agent avatars",
    prompt: `Futuristic AI assistant avatar, cyberpunk aesthetic, glowing ${PALETTE.primary.cyan} neural circuits, ${PALETTE.primary.orange} accent highlights, dark ${PALETTE.neutral.dark} background, holographic display elements, professional yet mysterious, high detail 3D render, volumetric lighting`,
    negativePrompt: "cartoon, anime, low quality, blurry, distorted face",
    tags: ["avatar", "npc", "neuralis"],
    aspectRatio: "1:1",
    style: "cyberpunk",
    realm: "neuralis",
  },

  "npc-avatar-trinity": {
    id: "npc-avatar-trinity",
    name: "Trinity Node Avatar",
    description: "Trinity AI system visual representation",
    prompt: `Three interconnected holographic spheres forming triangle, ${PALETTE.primary.cyan} energy beams connecting nodes, ${PALETTE.primary.orange} core pulse, floating in digital void, particle effects, neural network visualization, sacred geometry overlay, cinematic lighting`,
    tags: ["avatar", "npc", "icon"],
    aspectRatio: "1:1",
    style: "holographic",
    realm: "universal",
  },

  // Environment Renders
  "env-vault33": {
    id: "env-vault33",
    name: "VAULT 33 Interior",
    description: "Akashic Records vault environment",
    prompt: `Underground digital vault, infinite data columns glowing ${PALETTE.realm.akashic}, ancient symbols merged with circuit patterns, gas sigil containers with ${PALETTE.primary.orange} warnings, 9-layer depth visualization, mysterious fog, volumetric god rays, cyberpunk library aesthetic`,
    negativePrompt: "bright, cheerful, outdoor, natural",
    tags: ["environment", "vault", "akashic"],
    aspectRatio: "16:9",
    style: "cyberpunk",
    realm: "akashic",
  },

  "env-studio789": {
    id: "env-studio789",
    name: "Studio 789 Production Floor",
    description: "789 Studios creative production environment",
    prompt: `Futuristic broadcast studio, multiple holographic screens displaying ${PALETTE.primary.orange} content, ${PALETTE.primary.cyan} accent lighting, professional camera rigs, sound wave visualizations, "789" neon sign, creative chaos organized, industrial-modern hybrid`,
    tags: ["environment", "studio", "chaosphere"],
    aspectRatio: "16:9",
    style: "neon",
    realm: "chaosphere",
  },

  "env-floor333": {
    id: "env-floor333",
    name: "Floor 333 Neuralis Hub",
    description: "Business operations command center",
    prompt: `Corporate command center, clean minimalist design, ${PALETTE.primary.cyan} holographic dashboards, data streams flowing, glass walls with circuit patterns, professional atmosphere, subtle ${PALETTE.primary.orange} alert indicators, executive aesthetic`,
    tags: ["environment", "neuralis"],
    aspectRatio: "16:9",
    style: "minimal",
    realm: "neuralis",
  },

  // Globe Variants
  "globe-standard": {
    id: "globe-standard",
    name: "Standard Globe Model",
    description: "Default Earth visualization with lei lines",
    prompt: `3D Earth globe, glowing ${PALETTE.primary.cyan} lei lines connecting sacred sites, ${PALETTE.primary.orange} portal markers at intersection points, dark space background, subtle atmosphere glow, geographical accuracy, mystical energy network overlay`,
    tags: ["globe", "environment"],
    aspectRatio: "1:1",
    style: "holographic",
    realm: "universal",
  },

  "globe-flat-earth": {
    id: "globe-flat-earth",
    name: "Flat Earth Model",
    description: "Alternative flat earth visualization for belief system variant",
    prompt: `Flat disc Earth model, ${PALETTE.primary.cyan} dome barrier visualization, ${PALETTE.primary.orange} sun and moon orbital paths, ice wall perimeter, ancient map aesthetic merged with holographic display, conspiracy theory visualization`,
    tags: ["globe", "akashic"],
    aspectRatio: "1:1",
    style: "retro",
    realm: "akashic",
  },

  "globe-inner-earth": {
    id: "globe-inner-earth",
    name: "Inner Earth Model",
    description: "Hollow earth cross-section visualization",
    prompt: `Cross-section Earth visualization, hollow interior with ${PALETTE.primary.cyan} inner sun, ${PALETTE.primary.orange} entrance points at poles, underground civilization hints, Agartha visualization, layered geological display, mystical inner world`,
    tags: ["globe", "akashic", "vault"],
    aspectRatio: "1:1",
    style: "holographic",
    realm: "akashic",
  },

  // NFT/Badge Assets
  "badge-frequency-key": {
    id: "badge-frequency-key",
    name: "33.3FM Frequency Key",
    description: "Access key badge for frequency-gated content",
    prompt: `Digital access badge, radio frequency visualization, "33.3FM" display, ${PALETTE.primary.cyan} signal waves, ${PALETTE.primary.orange} authentication seal, holographic card design, premium collectible aesthetic, Dogechain integration symbol`,
    tags: ["badge", "nft", "icon"],
    aspectRatio: "3:4",
    style: "neon",
    realm: "chaosphere",
  },

  "badge-akashic-record": {
    id: "badge-akashic-record",
    name: "Akashic Record Fragment",
    description: "Collectible knowledge fragment from the Akashic Records",
    prompt: `Ancient scroll merged with digital tablet, ${PALETTE.realm.akashic} glowing runes, ${PALETTE.primary.cyan} data streams, mysterious knowledge symbols, classified stamp with ${PALETTE.primary.orange}, premium NFT collectible design`,
    tags: ["badge", "nft", "akashic", "vault"],
    aspectRatio: "3:4",
    style: "cyberpunk",
    realm: "akashic",
  },

  // Game Assets
  "game-hrm-card": {
    id: "game-hrm-card",
    name: "HRM Training Card",
    description: "Card design for HRM training game system",
    prompt: `Training card design, ${PALETTE.primary.cyan} border glow, scenario illustration area, skill icons in ${PALETTE.primary.orange}, professional development aesthetic, game card layout, clean typography space`,
    tags: ["game", "icon", "ui"],
    aspectRatio: "3:4",
    style: "minimal",
    realm: "neuralis",
  },

  "game-labyrinth-tile": {
    id: "game-labyrinth-tile",
    name: "Labyrinth Game Tile",
    description: "Tile asset for labyrinth navigation game",
    prompt: `Maze tile design, ${PALETTE.primary.cyan} pathway glow, ${PALETTE.primary.orange} hazard markers, ancient stone texture with circuit overlay, modular game piece, top-down perspective`,
    tags: ["game", "icon"],
    aspectRatio: "1:1",
    style: "cyberpunk",
    realm: "chaosphere",
  },
}

// Utility Functions
export function getPrompt(id: string): RenderPrompt | undefined {
  return PROMPT_REGISTRY[id]
}

export function getAllPrompts(): RenderPrompt[] {
  return Object.values(PROMPT_REGISTRY)
}

export function searchPrompts(query: string): RenderPrompt[] {
  const lowerQuery = query.toLowerCase()
  return getAllPrompts().filter(
    (prompt) =>
      prompt.name.toLowerCase().includes(lowerQuery) ||
      prompt.description.toLowerCase().includes(lowerQuery) ||
      prompt.tags.some((tag) => tag.includes(lowerQuery)),
  )
}

export function getPromptsByTag(tag: PromptTag): RenderPrompt[] {
  return getAllPrompts().filter((prompt) => prompt.tags.includes(tag))
}

export function getPromptsByRealm(realm: RenderPrompt["realm"]): RenderPrompt[] {
  return getAllPrompts().filter((prompt) => prompt.realm === realm)
}

export function getPromptIds(): string[] {
  return Object.keys(PROMPT_REGISTRY)
}

// Export for Trinity Engine integration
export const RENDER_CONFIG = {
  defaultNegativePrompt: "low quality, blurry, distorted, watermark, text overlay, amateur",
  defaultStyle: "cyberpunk" as const,
  supportedAspectRatios: ["1:1", "16:9", "9:16", "4:3", "3:4"] as const,
  version: "1.0.0",
}
