// WIRED CHAOS Economy Core
// Simulated Web3 economy - demo/beta mode only

import type { WCWallet, WCTransaction, WCExchangeOrder, WCStake } from "./models"
import { DEFAULT_ASSETS } from "./models"

// In-memory state (would be DB in production)
const wallets: Map<string, WCWallet> = new Map()
const transactions: WCTransaction[] = []
const orders: WCExchangeOrder[] = []
const stakes: WCStake[] = []

// Faucet config
const FAUCET_AMOUNT = 1000
const FAUCET_COOLDOWN_MS = 24 * 60 * 60 * 1000 // 24 hours

export function createWallet(userId: string): WCWallet {
  const wallet: WCWallet = {
    id: `wallet_${userId}_${Date.now()}`,
    userId,
    credits: 0,
    vaultCredits: 0,
    createdAt: new Date(),
    updatedAt: new Date(),
  }
  wallets.set(userId, wallet)
  return wallet
}

export function getWallet(userId: string): WCWallet | undefined {
  return wallets.get(userId)
}

export function getOrCreateWallet(userId: string): WCWallet {
  return getWallet(userId) || createWallet(userId)
}

export function claimFaucet(userId: string): { success: boolean; amount: number; message: string } {
  const wallet = getOrCreateWallet(userId)

  // Check cooldown (simplified - in production use DB timestamp)
  const lastFaucet = transactions
    .filter((t) => t.walletId === wallet.id && t.type === "faucet")
    .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())[0]

  if (lastFaucet && Date.now() - lastFaucet.timestamp.getTime() < FAUCET_COOLDOWN_MS) {
    const remaining = Math.ceil((FAUCET_COOLDOWN_MS - (Date.now() - lastFaucet.timestamp.getTime())) / 3600000)
    return { success: false, amount: 0, message: `Faucet available in ${remaining}h` }
  }

  wallet.credits += FAUCET_AMOUNT
  wallet.updatedAt = new Date()

  const tx: WCTransaction = {
    id: `tx_${Date.now()}`,
    walletId: wallet.id,
    type: "faucet",
    amount: FAUCET_AMOUNT,
    asset: "WCC",
    description: "Welcome faucet claim",
    timestamp: new Date(),
  }
  transactions.push(tx)

  return { success: true, amount: FAUCET_AMOUNT, message: `Claimed ${FAUCET_AMOUNT} WC Credits!` }
}

export function earnCredits(userId: string, amount: number, description: string): WCTransaction {
  const wallet = getOrCreateWallet(userId)
  wallet.credits += amount
  wallet.updatedAt = new Date()

  const tx: WCTransaction = {
    id: `tx_${Date.now()}`,
    walletId: wallet.id,
    type: "earn",
    amount,
    asset: "WCC",
    description,
    timestamp: new Date(),
  }
  transactions.push(tx)
  return tx
}

export function spendCredits(
  userId: string,
  amount: number,
  description: string,
): { success: boolean; tx?: WCTransaction; message: string } {
  const wallet = getOrCreateWallet(userId)

  if (wallet.credits < amount) {
    return { success: false, message: "Insufficient credits" }
  }

  wallet.credits -= amount
  wallet.updatedAt = new Date()

  const tx: WCTransaction = {
    id: `tx_${Date.now()}`,
    walletId: wallet.id,
    type: "spend",
    amount: -amount,
    asset: "WCC",
    description,
    timestamp: new Date(),
  }
  transactions.push(tx)
  return { success: true, tx, message: "Transaction complete" }
}

export function simulateSwap(
  userId: string,
  fromAsset: string,
  toAsset: string,
  amount: number,
  venue: "cex" | "dex" = "cex",
): WCExchangeOrder {
  const wallet = getOrCreateWallet(userId)

  const fromPrice = DEFAULT_ASSETS.find((a) => a.symbol === fromAsset)?.price || 1
  const toPrice = DEFAULT_ASSETS.find((a) => a.symbol === toAsset)?.price || 1
  const rate = fromPrice / toPrice

  const order: WCExchangeOrder = {
    id: `order_${Date.now()}`,
    walletId: wallet.id,
    venue,
    side: "buy",
    fromAsset,
    toAsset,
    amount,
    price: rate,
    status: "filled", // Instant fill in simulation
    timestamp: new Date(),
  }
  orders.push(order)

  return order
}

export function getTransactions(userId: string): WCTransaction[] {
  const wallet = getWallet(userId)
  if (!wallet) return []
  return transactions.filter((t) => t.walletId === wallet.id)
}

export function getLeaderboard(): Array<{ userId: string; credits: number }> {
  return Array.from(wallets.values())
    .map((w) => ({ userId: w.userId, credits: w.credits }))
    .sort((a, b) => b.credits - a.credits)
    .slice(0, 10)
}
