// WIRED CHAOS Economy Models
// Simulated Web3 stack - NO real chain calls

export interface WCWallet {
  id: string
  userId: string
  credits: number
  vaultCredits: number
  createdAt: Date
  updatedAt: Date
}

export interface WCAsset {
  id: string
  symbol: string
  name: string
  type: "stable" | "meme" | "nft" | "chain" | "internal"
  balance: number
  price: number // simulated price in WC Credits
  icon?: string
}

export interface WCTransaction {
  id: string
  walletId: string
  type: "earn" | "spend" | "swap" | "stake" | "faucet" | "transfer"
  amount: number
  asset: string
  description: string
  timestamp: Date
}

export interface WCExchangeOrder {
  id: string
  walletId: string
  venue: "cex" | "dex"
  side: "buy" | "sell"
  fromAsset: string
  toAsset: string
  amount: number
  price: number
  status: "pending" | "filled" | "cancelled"
  timestamp: Date
}

export interface WCStake {
  id: string
  walletId: string
  asset: string
  amount: number
  apy: number
  startDate: Date
  unlockDate: Date
}

export const DEFAULT_ASSETS: WCAsset[] = [
  { id: "wcc", symbol: "WCC", name: "WC Credits", type: "internal", balance: 0, price: 1 },
  { id: "usdc", symbol: "USDC", name: "USD Coin (Sim)", type: "stable", balance: 0, price: 1 },
  { id: "doge", symbol: "DOGE", name: "Dogecoin (Sim)", type: "meme", balance: 0, price: 0.08 },
  { id: "btc", symbol: "BTC", name: "Bitcoin (Sim)", type: "chain", balance: 0, price: 42000 },
  { id: "eth", symbol: "ETH", name: "Ethereum (Sim)", type: "chain", balance: 0, price: 2200 },
  { id: "xrp", symbol: "XRP", name: "XRP (Sim)", type: "chain", balance: 0, price: 0.62 },
  { id: "sol", symbol: "SOL", name: "Solana (Sim)", type: "chain", balance: 0, price: 98 },
  { id: "hbar", symbol: "HBAR", name: "Hedera (Sim)", type: "chain", balance: 0, price: 0.07 },
]
