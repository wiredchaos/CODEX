import { neon } from "@neondatabase/serverless"

export const sql = neon(process.env.NEON_DATABASE_URL!)

export type ForensicSource = {
  id: string
  type: string
  name: string
  repo_url: string
  branch: string | null
  created_at: Date
}

export type ForensicRun = {
  id: string
  source_id: string
  mode: string
  status: string
  started_at: Date | null
  finished_at: Date | null
  files_indexed: number
  chunks_indexed: number
  findings_json: string | null
  created_at: Date
}

export type ForensicDoc = {
  id: string
  source_id: string
  path: string
  ext: string
  sha: string
  size_bytes: number
  created_at: Date
}

export type ForensicChunk = {
  id: string
  doc_id: string
  idx: number
  text: string
  tokens: number
  created_at: Date
}

export type AgenticJob = {
  id: string
  kind: string
  status: string
  input_json: string
  plan_json: string | null
  result_json: string | null
  error: string | null
  created_at: Date
  started_at: Date | null
  finished_at: Date | null
}

export type AgenticJobEvent = {
  id: string
  job_id: string
  ts: Date
  level: string
  message: string
  payload_json: string | null
}
