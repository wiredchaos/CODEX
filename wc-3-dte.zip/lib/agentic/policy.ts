// Allowlist of safe actions the Seeker can execute
export const ALLOWED_ACTIONS = [
  // GitHub operations (read-only)
  "github.listFiles",
  "github.fetchContents",

  // Text processing
  "text.chunk",
  "text.tokenize",

  // Security
  "redact.secrets",

  // Database operations (forensics tables only)
  "db.indexChunks",
  "db.searchChunks",
  "db.getAllDocs",
  "db.getFindings",

  // Analysis (no side effects)
  "analyze.generateFindings",
  "analyze.extractPatchMap",
  "analyze.identifyMissing",
  "analyze.checkCompleteness",
  "analyze.prioritizeGaps",

  // Report generation
  "report.generatePatchReport",
  "report.generateMissingReport",
  "report.generateUpgradePlan",

  // Planning
  "plan.generateUpgradeSteps",
]

// Actions that are explicitly forbidden
export const FORBIDDEN_ACTIONS = [
  "github.push",
  "github.delete",
  "github.createBranch",
  "db.drop",
  "db.truncate",
  "db.delete",
  "file.write",
  "file.delete",
  "exec.shell",
  "exec.command",
]

export function validateAction(action: string): boolean {
  if (FORBIDDEN_ACTIONS.some((f) => action.startsWith(f))) {
    return false
  }
  return ALLOWED_ACTIONS.includes(action)
}
