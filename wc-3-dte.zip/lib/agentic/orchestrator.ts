import { sql } from "@/lib/db/neon"
import { executeStep } from "./executor"
import { ALLOWED_ACTIONS } from "./policy"

export type AgenticJobKind =
  | "SEEKER_FORENSICS_SCAN"
  | "SEEKER_PATCH_RECONSTRUCT"
  | "SEEKER_MISSING_DOCS_REPORT"
  | "SEEKER_UPGRADE_PLAN"

export type PlanStep = {
  action: string
  params: Record<string, unknown>
  description: string
}

export type Plan = {
  steps: PlanStep[]
  estimated_duration: string
}

export async function createJob(kind: AgenticJobKind, input: Record<string, unknown>): Promise<string> {
  const result = await sql`
    INSERT INTO agentic_jobs (kind, status, input_json)
    VALUES (${kind}, 'queued', ${JSON.stringify(input)})
    RETURNING id
  `
  return result[0].id
}

export async function generatePlan(kind: AgenticJobKind, input: Record<string, unknown>): Promise<Plan> {
  switch (kind) {
    case "SEEKER_FORENSICS_SCAN":
      return {
        steps: [
          {
            action: "github.listFiles",
            params: { repoUrl: input.repoUrl, branch: input.branch || "main" },
            description: "List all files in repository",
          },
          {
            action: "github.fetchContents",
            params: {
              include: input.include || ["md", "ts", "tsx", "json"],
              exclude: input.exclude || ["node_modules", "dist", ".next"],
            },
            description: "Fetch file contents",
          },
          {
            action: "text.chunk",
            params: { maxTokens: 500 },
            description: "Chunk documents for indexing",
          },
          {
            action: "redact.secrets",
            params: {},
            description: "Redact sensitive information",
          },
          {
            action: "db.indexChunks",
            params: {},
            description: "Index chunks in database",
          },
          {
            action: "analyze.generateFindings",
            params: {},
            description: "Generate forensic findings",
          },
        ],
        estimated_duration: "2-5 minutes",
      }

    case "SEEKER_PATCH_RECONSTRUCT":
      return {
        steps: [
          {
            action: "db.searchChunks",
            params: { query: input.patchName },
            description: `Search for ${input.patchName} references`,
          },
          {
            action: "analyze.extractPatchMap",
            params: {},
            description: "Extract patch structure",
          },
          {
            action: "analyze.identifyMissing",
            params: {},
            description: "Identify missing artifacts",
          },
          {
            action: "report.generatePatchReport",
            params: {},
            description: "Generate reconstruction report",
          },
        ],
        estimated_duration: "1-2 minutes",
      }

    case "SEEKER_MISSING_DOCS_REPORT":
      return {
        steps: [
          {
            action: "db.getAllDocs",
            params: {},
            description: "Retrieve all indexed documents",
          },
          {
            action: "analyze.checkCompleteness",
            params: {},
            description: "Check for missing documentation",
          },
          {
            action: "report.generateMissingReport",
            params: {},
            description: "Generate missing docs report",
          },
        ],
        estimated_duration: "30 seconds",
      }

    case "SEEKER_UPGRADE_PLAN":
      return {
        steps: [
          {
            action: "db.getFindings",
            params: { runId: input.runId },
            description: "Retrieve forensic findings",
          },
          {
            action: "analyze.prioritizeGaps",
            params: {},
            description: "Prioritize identified gaps",
          },
          {
            action: "plan.generateUpgradeSteps",
            params: {},
            description: "Generate upgrade action items",
          },
          {
            action: "report.generateUpgradePlan",
            params: {},
            description: "Compile upgrade plan document",
          },
        ],
        estimated_duration: "1 minute",
      }

    default:
      throw new Error(`Unknown job kind: ${kind}`)
  }
}

export async function runJob(jobId: string): Promise<void> {
  // Update job status to running
  await sql`
    UPDATE agentic_jobs 
    SET status = 'running', started_at = NOW()
    WHERE id = ${jobId}::uuid
  `

  try {
    // Get job details
    const jobs = await sql`
      SELECT kind, input_json FROM agentic_jobs WHERE id = ${jobId}::uuid
    `
    if (jobs.length === 0) throw new Error("Job not found")

    const job = jobs[0]
    const input = JSON.parse(job.input_json)

    // Generate plan
    const plan = await generatePlan(job.kind as AgenticJobKind, input)

    // Store plan
    await sql`
      UPDATE agentic_jobs SET plan_json = ${JSON.stringify(plan)}
      WHERE id = ${jobId}::uuid
    `

    // Execute each step
    const context: Record<string, unknown> = { input }

    for (let i = 0; i < plan.steps.length; i++) {
      const step = plan.steps[i]

      // Validate action is allowed
      if (!ALLOWED_ACTIONS.includes(step.action)) {
        throw new Error(`Action not allowed: ${step.action}`)
      }

      // Log step start
      await sql`
        INSERT INTO agentic_job_events (job_id, level, message, payload_json)
        VALUES (${jobId}::uuid, 'info', ${`Starting: ${step.description}`}, ${JSON.stringify(step)})
      `

      // Execute step
      const result = await executeStep(step, context)
      context[`step_${i}_result`] = result

      // Log step completion
      await sql`
        INSERT INTO agentic_job_events (job_id, level, message)
        VALUES (${jobId}::uuid, 'info', ${`Completed: ${step.description}`})
      `
    }

    // Store result and mark complete
    await sql`
      UPDATE agentic_jobs 
      SET status = 'succeeded', 
          result_json = ${JSON.stringify(context)},
          finished_at = NOW()
      WHERE id = ${jobId}::uuid
    `
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error"

    await sql`
      UPDATE agentic_jobs 
      SET status = 'failed', error = ${errorMessage}, finished_at = NOW()
      WHERE id = ${jobId}::uuid
    `

    await sql`
      INSERT INTO agentic_job_events (job_id, level, message)
      VALUES (${jobId}::uuid, 'error', ${errorMessage})
    `
  }
}
