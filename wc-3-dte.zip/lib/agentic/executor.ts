import type { PlanStep } from "./orchestrator"
import * as githubTools from "./tools/github"
import * as textTools from "./tools/text"
import * as redactTools from "./tools/redact"
import { sql } from "@/lib/db/neon"

type StepContext = Record<string, unknown>

export async function executeStep(step: PlanStep, context: StepContext): Promise<unknown> {
  const [namespace, method] = step.action.split(".")

  switch (namespace) {
    case "github":
      return executeGithubAction(method, step.params, context)
    case "text":
      return executeTextAction(method, step.params, context)
    case "redact":
      return executeRedactAction(method, step.params, context)
    case "db":
      return executeDbAction(method, step.params, context)
    case "analyze":
      return executeAnalyzeAction(method, step.params, context)
    case "report":
      return executeReportAction(method, step.params, context)
    case "plan":
      return executePlanAction(method, step.params, context)
    default:
      throw new Error(`Unknown action namespace: ${namespace}`)
  }
}

async function executeGithubAction(
  method: string,
  params: Record<string, unknown>,
  context: StepContext,
): Promise<unknown> {
  switch (method) {
    case "listFiles":
      return githubTools.listFiles(params.repoUrl as string, params.branch as string)
    case "fetchContents":
      const files = context.step_0_result as string[]
      return githubTools.fetchContents(files, params.include as string[], params.exclude as string[])
    default:
      throw new Error(`Unknown github method: ${method}`)
  }
}

async function executeTextAction(
  method: string,
  params: Record<string, unknown>,
  context: StepContext,
): Promise<unknown> {
  switch (method) {
    case "chunk":
      const contents = context.step_1_result as Array<{
        path: string
        content: string
      }>
      return textTools.chunkDocuments(contents, params.maxTokens as number)
    default:
      throw new Error(`Unknown text method: ${method}`)
  }
}

async function executeRedactAction(
  method: string,
  _params: Record<string, unknown>,
  context: StepContext,
): Promise<unknown> {
  switch (method) {
    case "secrets":
      const chunks = context.step_2_result as Array<{
        path: string
        chunks: string[]
      }>
      return redactTools.redactSecrets(chunks)
    default:
      throw new Error(`Unknown redact method: ${method}`)
  }
}

async function executeDbAction(
  method: string,
  params: Record<string, unknown>,
  context: StepContext,
): Promise<unknown> {
  switch (method) {
    case "indexChunks":
      const redactedChunks = context.step_3_result as Array<{
        path: string
        chunks: string[]
      }>
      const sourceId = (context.input as Record<string, unknown>).sourceId as string
      const runId = (context.input as Record<string, unknown>).runId as string

      let filesIndexed = 0
      let chunksIndexed = 0

      for (const doc of redactedChunks) {
        const ext = doc.path.split(".").pop() || ""
        const sha = Buffer.from(doc.chunks.join("")).toString("base64").slice(0, 40)

        const docResult = await sql`
          INSERT INTO forensic_docs (source_id, path, ext, sha, size_bytes)
          VALUES (${sourceId}::uuid, ${doc.path}, ${ext}, ${sha}, ${doc.chunks.join("").length})
          ON CONFLICT (source_id, path, sha) DO UPDATE SET size_bytes = EXCLUDED.size_bytes
          RETURNING id
        `
        const docId = docResult[0].id
        filesIndexed++

        for (let i = 0; i < doc.chunks.length; i++) {
          await sql`
            INSERT INTO forensic_chunks (doc_id, idx, text, tokens)
            VALUES (${docId}::uuid, ${i}, ${doc.chunks[i]}, ${Math.ceil(doc.chunks[i].length / 4)})
          `
          chunksIndexed++
        }
      }

      // Update run stats
      await sql`
        UPDATE forensic_runs 
        SET files_indexed = ${filesIndexed}, chunks_indexed = ${chunksIndexed}
        WHERE id = ${runId}::uuid
      `

      return { filesIndexed, chunksIndexed }

    case "searchChunks":
      const query = params.query as string
      const results = await sql`
        SELECT fc.text, fd.path, fd.ext
        FROM forensic_chunks fc
        JOIN forensic_docs fd ON fc.doc_id = fd.id
        WHERE to_tsvector('english', fc.text) @@ plainto_tsquery('english', ${query})
        LIMIT 50
      `
      return results

    case "getAllDocs":
      return sql`SELECT path, ext, size_bytes FROM forensic_docs`

    case "getFindings":
      const findingsRunId = params.runId as string
      const run = await sql`
        SELECT findings_json FROM forensic_runs WHERE id = ${findingsRunId}::uuid
      `
      return run[0]?.findings_json ? JSON.parse(run[0].findings_json) : null

    default:
      throw new Error(`Unknown db method: ${method}`)
  }
}

async function executeAnalyzeAction(
  method: string,
  _params: Record<string, unknown>,
  context: StepContext,
): Promise<unknown> {
  switch (method) {
    case "generateFindings":
      const dbResult = context.step_4_result as {
        filesIndexed: number
        chunksIndexed: number
      }

      // Search for patch mentions
      const patchMentions = await sql`
        SELECT DISTINCT 
          CASE 
            WHEN text ILIKE '%33.3fm%' OR text ILIKE '%333%' THEN '33.3FM'
            WHEN text ILIKE '%789%' OR text ILIKE '%studio%' THEN '789 Studios'
            WHEN text ILIKE '%vault33%' OR text ILIKE '%akashic%' THEN 'Vault33'
            WHEN text ILIKE '%fen%' THEN 'FEN'
            WHEN text ILIKE '%credit%repair%' THEN 'Credit Repair'
            WHEN text ILIKE '%npc%' THEN 'NPC Engine'
            WHEN text ILIKE '%hrm%' THEN 'HRM'
            WHEN text ILIKE '%neura%' THEN 'NEURA'
            ELSE 'Unknown'
          END as patch_name,
          COUNT(*) as mentions
        FROM forensic_chunks
        WHERE text ILIKE '%patch%' OR text ILIKE '%floor%' OR text ILIKE '%realm%'
        GROUP BY 1
        HAVING COUNT(*) > 0
      `

      // Get top documents
      const topDocs = await sql`
        SELECT fd.path, COUNT(fc.id) as chunk_count
        FROM forensic_docs fd
        JOIN forensic_chunks fc ON fd.id = fc.doc_id
        GROUP BY fd.path
        ORDER BY chunk_count DESC
        LIMIT 20
      `

      return {
        filesIndexed: dbResult.filesIndexed,
        chunksIndexed: dbResult.chunksIndexed,
        topDocuments: topDocs.map((d) => d.path),
        patchMentions: patchMentions.filter((p) => p.patch_name !== "Unknown"),
        missingArtifacts: [],
        conflicts: [],
        reconstructionCandidates: [],
        upgradeRecommendations: [],
      }

    case "extractPatchMap":
      return { patchMap: context.step_0_result }

    case "identifyMissing":
      return { missing: [] }

    case "checkCompleteness":
      return { complete: true, missing: [] }

    case "prioritizeGaps":
      const findings = context.step_0_result as Record<string, unknown>
      return { prioritized: findings?.missingArtifacts || [] }

    default:
      throw new Error(`Unknown analyze method: ${method}`)
  }
}

async function executeReportAction(
  method: string,
  _params: Record<string, unknown>,
  context: StepContext,
): Promise<unknown> {
  switch (method) {
    case "generatePatchReport":
      return {
        type: "patch_reconstruction",
        data: context,
        generatedAt: new Date().toISOString(),
      }

    case "generateMissingReport":
      return {
        type: "missing_docs",
        data: context,
        generatedAt: new Date().toISOString(),
      }

    case "generateUpgradePlan":
      return {
        type: "upgrade_plan",
        data: context,
        generatedAt: new Date().toISOString(),
      }

    default:
      throw new Error(`Unknown report method: ${method}`)
  }
}

async function executePlanAction(
  method: string,
  _params: Record<string, unknown>,
  context: StepContext,
): Promise<unknown> {
  switch (method) {
    case "generateUpgradeSteps":
      const gaps = context.step_1_result as { prioritized: unknown[] }
      return {
        steps: gaps.prioritized.map((gap, i) => ({
          order: i + 1,
          action: `Fix: ${JSON.stringify(gap)}`,
          priority: "high",
        })),
      }

    default:
      throw new Error(`Unknown plan method: ${method}`)
  }
}
