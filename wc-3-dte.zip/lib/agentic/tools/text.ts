export function chunkDocuments(
  documents: Array<{ path: string; content: string }>,
  maxTokens = 500,
): Array<{ path: string; chunks: string[] }> {
  return documents.map((doc) => ({
    path: doc.path,
    chunks: chunkText(doc.content, maxTokens),
  }))
}

export function chunkText(text: string, maxTokens: number): string[] {
  // Rough estimate: 1 token ≈ 4 characters
  const maxChars = maxTokens * 4
  const chunks: string[] = []

  // Split by paragraphs first
  const paragraphs = text.split(/\n\n+/)

  let currentChunk = ""

  for (const para of paragraphs) {
    if (currentChunk.length + para.length > maxChars) {
      if (currentChunk) {
        chunks.push(currentChunk.trim())
      }
      // If single paragraph is too long, split by sentences
      if (para.length > maxChars) {
        const sentences = para.split(/(?<=[.!?])\s+/)
        for (const sentence of sentences) {
          if (sentence.length > maxChars) {
            // Split long sentences by words
            const words = sentence.split(/\s+/)
            let wordChunk = ""
            for (const word of words) {
              if (wordChunk.length + word.length > maxChars) {
                chunks.push(wordChunk.trim())
                wordChunk = word
              } else {
                wordChunk += " " + word
              }
            }
            if (wordChunk) chunks.push(wordChunk.trim())
          } else {
            chunks.push(sentence)
          }
        }
        currentChunk = ""
      } else {
        currentChunk = para
      }
    } else {
      currentChunk += "\n\n" + para
    }
  }

  if (currentChunk.trim()) {
    chunks.push(currentChunk.trim())
  }

  return chunks.filter((c) => c.length > 0)
}

export function estimateTokens(text: string): number {
  return Math.ceil(text.length / 4)
}
