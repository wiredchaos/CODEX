// Patterns for detecting secrets
const SECRET_PATTERNS = [
  // API Keys
  /(?:api[_-]?key|apikey)['":\s]*[=:]\s*['"]?([a-zA-Z0-9_-]{20,})['"]?/gi,
  // Tokens
  /(?:token|bearer|auth)['":\s]*[=:]\s*['"]?([a-zA-Z0-9_.-]{20,})['"]?/gi,
  // Passwords
  /(?:password|passwd|pwd|secret)['":\s]*[=:]\s*['"]?([^\s'"]{8,})['"]?/gi,
  // AWS Keys
  /(?:AKIA|ASIA)[A-Z0-9]{16}/g,
  // Private Keys
  /-----BEGIN (?:RSA |EC )?PRIVATE KEY-----[\s\S]*?-----END (?:RSA |EC )?PRIVATE KEY-----/g,
  // Connection Strings
  /(?:mongodb|postgres|mysql|redis):\/\/[^\s]+/gi,
  // JWT Tokens
  /eyJ[a-zA-Z0-9_-]*\.eyJ[a-zA-Z0-9_-]*\.[a-zA-Z0-9_-]*/g,
]

export function redactSecrets(
  documents: Array<{ path: string; chunks: string[] }>,
): Array<{ path: string; chunks: string[] }> {
  return documents.map((doc) => ({
    path: doc.path,
    chunks: doc.chunks.map((chunk) => redactText(chunk)),
  }))
}

export function redactText(text: string): string {
  let redacted = text

  for (const pattern of SECRET_PATTERNS) {
    redacted = redacted.replace(pattern, (match) => {
      // Keep first 4 and last 4 characters, redact the rest
      if (match.length > 12) {
        return match.slice(0, 4) + "[REDACTED]" + match.slice(-4)
      }
      return "[REDACTED]"
    })
  }

  return redacted
}
