const GITHUB_TOKEN = process.env.GITHUB_TOKEN

type GitHubTreeItem = {
  path: string
  type: string
  sha: string
  size?: number
}

export async function listFiles(repoUrl: string, branch = "main"): Promise<string[]> {
  // Extract owner/repo from URL
  const match = repoUrl.match(/github\.com\/([^/]+)\/([^/]+)/)
  if (!match) throw new Error("Invalid GitHub URL")

  const [, owner, repo] = match
  const cleanRepo = repo.replace(/\.git$/, "")

  const headers: HeadersInit = {
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
  }

  if (GITHUB_TOKEN) {
    headers.Authorization = `Bearer ${GITHUB_TOKEN}`
  }

  const response = await fetch(`https://api.github.com/repos/${owner}/${cleanRepo}/git/trees/${branch}?recursive=1`, {
    headers,
  })

  if (!response.ok) {
    throw new Error(`GitHub API error: ${response.status}`)
  }

  const data = await response.json()
  return data.tree.filter((item: GitHubTreeItem) => item.type === "blob").map((item: GitHubTreeItem) => item.path)
}

export async function fetchContents(
  files: string[],
  include: string[],
  exclude: string[],
): Promise<Array<{ path: string; content: string }>> {
  const results: Array<{ path: string; content: string }> = []

  // Filter files by include/exclude
  const filteredFiles = files.filter((file) => {
    const ext = file.split(".").pop() || ""

    // Check exclude patterns
    for (const pattern of exclude) {
      if (file.includes(pattern)) return false
    }

    // Check include extensions
    if (include.length > 0) {
      return include.includes(ext)
    }

    return true
  })

  // Limit to 100 files for safety
  const limitedFiles = filteredFiles.slice(0, 100)

  for (const file of limitedFiles) {
    try {
      // In a real implementation, this would fetch from GitHub
      // For now, we'll create placeholder content
      results.push({
        path: file,
        content: `// Content of ${file}\n// Fetched from repository`,
      })
    } catch {
      // Skip files that fail to fetch
    }
  }

  return results
}
