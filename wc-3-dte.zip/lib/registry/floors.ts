// WCMSTR Floor Registry
// Floors are vertical levels in the Elevator system

export interface Floor {
  n: number
  name: string
  preset: string
  gated?: boolean
  locked?: boolean
  color: string
  description: string
}

export const floors: Floor[] = [
  {
    n: 0,
    name: "LOBBY",
    preset: "LobbyPreset",
    color: "#00FFF7",
    description: "Welcome hub. Start here.",
  },
  {
    n: 1,
    name: "OPEN SIGNAL",
    preset: "OpenSignalPreset",
    color: "#00FF88",
    description: "Public access. Explore freely.",
  },
  {
    n: 2,
    name: "ARENA",
    preset: "ArenaPreset",
    color: "#FFD700",
    description: "Games, training, competition.",
  },
  {
    n: 3,
    name: "THRESHOLD",
    preset: "ThresholdPreset",
    gated: true,
    color: "#FF6B35",
    description: "Advanced tools. Builder access.",
  },
  {
    n: 4,
    name: "DEEP SIGNAL",
    preset: "DeepSignalPreset",
    locked: true,
    color: "#A020F0",
    description: "Akashic realm. Restricted.",
  },
]

export function getFloor(n: number): Floor | undefined {
  return floors.find((f) => f.n === n)
}

export function getAccessibleFloors(hasDeepAccess: boolean): Floor[] {
  return floors.filter((f) => !f.locked || hasDeepAccess)
}
