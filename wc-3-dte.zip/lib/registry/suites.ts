// WCMSTR Suite Registry
// Suites are sub-destinations within floors

export type SuiteKind = "panel" | "embed" | "link" | "route"

export interface Suite {
  id: string
  floor: number
  title: string
  kind: SuiteKind
  route?: string
  embedUrl?: string
  tags: string[]
  description?: string
  icon?: string
}

export const suites: Suite[] = [
  // Public Suites
  { id: "demo", floor: 1, title: "Interactive Demo", kind: "panel", tags: ["public"], icon: "Play" },
  {
    id: "community",
    floor: 1,
    title: "Spaces & Community",
    kind: "link",
    tags: ["public"],
    route: "/789/crypto-spaces",
    icon: "Users",
  },
  { id: "learn", floor: 0, title: "What This Is", kind: "panel", tags: ["public"], icon: "Info" },
  { id: "playground", floor: 1, title: "AI Playground", kind: "panel", tags: ["public", "beta"], icon: "Sparkles" },
  { id: "next", floor: 0, title: "What's Next", kind: "panel", tags: ["public"], icon: "ArrowRight" },

  // Mapped Patches (routes)
  { id: "789", floor: 1, title: "789 Studios", kind: "route", route: "/789", tags: ["public"], icon: "Film" },
  { id: "333", floor: 1, title: "33.3FM Signal", kind: "route", route: "/333", tags: ["public"], icon: "Radio" },
  { id: "mall", floor: 1, title: "Chaos Store", kind: "route", route: "/mall", tags: ["public"], icon: "ShoppingBag" },

  // Beta Suites
  { id: "chaos_os", floor: 1, title: "CHAOS OS", kind: "route", route: "/chaos-os", tags: ["beta"], icon: "Terminal" },
  { id: "creator_codex", floor: 1, title: "Creator Codex", kind: "panel", tags: ["beta"], icon: "Book" },
  { id: "workflow", floor: 2, title: "Workflow Engine", kind: "panel", tags: ["beta"], icon: "GitBranch" },
  {
    id: "proof",
    floor: 0,
    title: "Proof of Capability",
    kind: "panel",
    tags: ["beta", "investor"],
    icon: "CheckCircle",
  },
  { id: "sandbox", floor: 2, title: "Experiments", kind: "panel", tags: ["beta"], icon: "Flask" },
  { id: "docs", floor: 0, title: "Documentation", kind: "link", tags: ["beta"], route: "/docs", icon: "FileText" },
  { id: "npc", floor: 2, title: "NPC Engine", kind: "route", route: "/npc", tags: ["beta"], icon: "Cpu" },
  { id: "hrm", floor: 2, title: "HRM Training", kind: "route", route: "/hrm", tags: ["beta"], icon: "GraduationCap" },
  { id: "neura", floor: 1, title: "NEURA", kind: "route", route: "/neura", tags: ["beta"], icon: "Brain" },

  // Investor Express Suites (6 portals)
  {
    id: "what",
    floor: 0,
    title: "What is this?",
    kind: "panel",
    tags: ["investor"],
    description: "WIRED CHAOS META is an agentic operating system for creators.",
  },
  {
    id: "problem",
    floor: 0,
    title: "The Problem",
    kind: "panel",
    tags: ["investor"],
    description: "Web2 platforms extract value. Creators are commodities.",
  },
  {
    id: "built",
    floor: 1,
    title: "What's Built",
    kind: "panel",
    tags: ["investor"],
    description: "16 patches. 77 routes. Production-ready.",
  },
  {
    id: "who",
    floor: 1,
    title: "Who It's For",
    kind: "panel",
    tags: ["investor"],
    description: "5 generations. Web2 to Web3. Boomers to Gen Alpha.",
  },
  {
    id: "money",
    floor: 2,
    title: "Revenue Model",
    kind: "panel",
    tags: ["investor"],
    description: "WL licensing, credits, subscriptions, enterprise.",
  },
  {
    id: "ask",
    floor: 2,
    title: "The Ask",
    kind: "panel",
    tags: ["investor"],
    description: "Strategic partnership. Not just capital.",
  },
]

export function getSuitesByFloor(floor: number): Suite[] {
  return suites.filter((s) => s.floor === floor)
}

export function getSuitesByTags(tags: string[]): Suite[] {
  return suites.filter((s) => s.tags.some((t) => tags.includes(t)))
}

export function getSuite(id: string): Suite | undefined {
  return suites.find((s) => s.id === id)
}
