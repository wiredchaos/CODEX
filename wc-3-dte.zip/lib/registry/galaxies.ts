// WCMSTR Galaxy Portal Registry
// Galaxies are entry modes that determine visible floors/suites

export type GalaxyMode = "public" | "beta" | "investor"

export interface Galaxy {
  id: GalaxyMode
  title: string
  subtitle: string
  defaultFloor: number
  visibleFloors: number[]
  visibleSuites: string[]
  color: string
  icon: string
}

export const galaxies: Galaxy[] = [
  {
    id: "public",
    title: "Explore WIRED CHAOS",
    subtitle: "Start free. No setup. No jargon.",
    defaultFloor: 0,
    visibleFloors: [0, 1, 2, 3],
    visibleSuites: ["demo", "community", "learn", "playground", "next", "789", "333", "mall"],
    color: "#00FFF7",
    icon: "Globe",
  },
  {
    id: "beta",
    title: "Build With WIRED CHAOS",
    subtitle: "Real tools. Real workflows.",
    defaultFloor: 0,
    visibleFloors: [0, 1, 2, 3, 4],
    visibleSuites: ["chaos_os", "creator_codex", "workflow", "proof", "sandbox", "docs", "npc", "hrm", "neura"],
    color: "#FFD700",
    icon: "Cpu",
  },
  {
    id: "investor",
    title: "Investor Express",
    subtitle: "See the system in under 60 seconds.",
    defaultFloor: 0,
    visibleFloors: [0, 1, 2],
    visibleSuites: ["what", "problem", "built", "who", "money", "ask"],
    color: "#A020F0",
    icon: "TrendingUp",
  },
]

export function getGalaxy(id: GalaxyMode): Galaxy | undefined {
  return galaxies.find((g) => g.id === id)
}

export function getVisibleSuites(galaxyId: GalaxyMode, floorNum: number): string[] {
  const galaxy = getGalaxy(galaxyId)
  if (!galaxy) return []
  return galaxy.visibleSuites
}
