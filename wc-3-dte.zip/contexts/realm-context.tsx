"use client"

import { createContext, useContext, useState, useCallback, type ReactNode } from "react"

export type RealmType = "neuralis" | "chaosphere" | "underground" | null

interface RealmContextType {
  activeRealm: RealmType
  setActiveRealm: (realm: RealmType) => void
  realmColors: {
    primary: string
    secondary: string
    accent: string
    glow: string
    frequency: number
  }
}

const realmThemes = {
  neuralis: {
    primary: "#00FFF7", // Neon Cyan
    secondary: "#00ccc6",
    accent: "#4dfffa",
    glow: "rgba(0, 255, 247, 0.4)",
    frequency: 432,
  },
  chaosphere: {
    primary: "#FF1A1A", // Chaos Red
    secondary: "#cc1515",
    accent: "#ff4d4d",
    glow: "rgba(255, 26, 26, 0.4)",
    frequency: 589,
  },
  underground: {
    primary: "#A020F0", // Glitch Purple
    secondary: "#8019c0",
    accent: "#b94df5",
    glow: "rgba(160, 32, 240, 0.4)",
    frequency: 33,
  },
}

const defaultColors = {
  primary: "#FF1A1A",
  secondary: "#cc1515",
  accent: "#ff4d4d",
  glow: "rgba(255, 26, 26, 0.4)",
  frequency: 589,
}

const RealmContext = createContext<RealmContextType | undefined>(undefined)

export function RealmProvider({ children }: { children: ReactNode }) {
  const [activeRealm, setActiveRealmState] = useState<RealmType>(null)

  const setActiveRealm = useCallback((realm: RealmType) => {
    setActiveRealmState(realm)

    // Update CSS custom properties for global theming
    if (typeof window !== "undefined") {
      const root = document.documentElement
      const theme = realm ? realmThemes[realm] : defaultColors

      root.style.setProperty("--realm-primary", theme.primary)
      root.style.setProperty("--realm-secondary", theme.secondary)
      root.style.setProperty("--realm-accent", theme.accent)
      root.style.setProperty("--realm-glow", theme.glow)
      root.setAttribute("data-realm", realm || "default")
    }
  }, [])

  const realmColors = activeRealm ? realmThemes[activeRealm] : defaultColors

  return <RealmContext.Provider value={{ activeRealm, setActiveRealm, realmColors }}>{children}</RealmContext.Provider>
}

export function useRealm() {
  const context = useContext(RealmContext)
  if (context === undefined) {
    throw new Error("useRealm must be used within a RealmProvider")
  }
  return context
}
