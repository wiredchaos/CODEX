"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { createClient } from "@/lib/supabase/client"
import { ArrowLeft, Lock, Mail, Eye, EyeOff, UserPlus, Check } from "lucide-react"
import { LiveCircuitry } from "@/components/live-circuitry"

const AUTH_COLORS = {
  primary: "#00FFF7",
  secondary: "#FF4500",
  accent: "#FFD700",
  success: "#00FF88",
  dark: "#000000",
  glow: "rgba(0, 255, 247, 0.5)",
}

export default function SignUpPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const passwordRequirements = [
    { label: "At least 8 characters", met: password.length >= 8 },
    { label: "Contains uppercase letter", met: /[A-Z]/.test(password) },
    { label: "Contains number", met: /[0-9]/.test(password) },
    { label: "Passwords match", met: password === confirmPassword && password.length > 0 },
  ]

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault()
    const supabase = createClient()
    setIsLoading(true)
    setError(null)

    if (password !== confirmPassword) {
      setError("Passwords do not match")
      setIsLoading(false)
      return
    }

    if (password.length < 8) {
      setError("Password must be at least 8 characters")
      setIsLoading(false)
      return
    }

    try {
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || `${window.location.origin}/dashboard`,
        },
      })
      if (error) throw error
      router.push("/auth/sign-up-success")
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "Registration failed")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div
      className="min-h-screen relative flex items-center justify-center p-4"
      style={{ backgroundColor: AUTH_COLORS.dark }}
    >
      <LiveCircuitry />

      {/* Grid Background */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${AUTH_COLORS.primary}15 1px, transparent 1px),
            linear-gradient(to bottom, ${AUTH_COLORS.primary}15 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Back Button */}
      <Link
        href="/"
        className="absolute top-4 left-4 flex items-center gap-2 z-20 transition-colors hover:opacity-80"
        style={{ color: AUTH_COLORS.primary }}
      >
        <ArrowLeft className="w-5 h-5" />
        <span className="font-mono text-sm uppercase">Lobby</span>
      </Link>

      {/* Sign Up Card */}
      <div
        className="relative z-10 w-full max-w-md p-8 rounded-2xl"
        style={{
          background: "rgba(0, 0, 0, 0.8)",
          border: `1px solid ${AUTH_COLORS.primary}30`,
          boxShadow: `0 0 60px ${AUTH_COLORS.primary}20`,
        }}
      >
        {/* Header */}
        <div className="text-center mb-8">
          <div
            className="w-16 h-16 mx-auto mb-4 rounded-xl flex items-center justify-center"
            style={{ background: `${AUTH_COLORS.primary}20` }}
          >
            <UserPlus className="w-8 h-8" style={{ color: AUTH_COLORS.primary }} />
          </div>
          <h1 className="font-display text-3xl tracking-wider" style={{ color: AUTH_COLORS.primary }}>
            REQUEST ACCESS
          </h1>
          <p className="font-mono text-sm text-neutral-400 mt-2">Create new operator credentials</p>
        </div>

        <form onSubmit={handleSignUp} className="space-y-6">
          {/* Email Field */}
          <div>
            <label className="block font-mono text-xs uppercase tracking-wider text-neutral-400 mb-2">
              Email Address
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-500" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                placeholder="operator@wiredchaos.io"
                className="w-full pl-11 pr-4 py-3 rounded-xl font-mono text-sm bg-black/50 text-white placeholder-neutral-600 outline-none transition-all"
                style={{
                  border: `1px solid ${AUTH_COLORS.primary}30`,
                }}
              />
            </div>
          </div>

          {/* Password Field */}
          <div>
            <label className="block font-mono text-xs uppercase tracking-wider text-neutral-400 mb-2">Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-500" />
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                placeholder="••••••••"
                className="w-full pl-11 pr-12 py-3 rounded-xl font-mono text-sm bg-black/50 text-white placeholder-neutral-600 outline-none transition-all"
                style={{
                  border: `1px solid ${AUTH_COLORS.primary}30`,
                }}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-white transition-colors"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {/* Confirm Password Field */}
          <div>
            <label className="block font-mono text-xs uppercase tracking-wider text-neutral-400 mb-2">
              Confirm Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-500" />
              <input
                type={showPassword ? "text" : "password"}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                placeholder="••••••••"
                className="w-full pl-11 pr-4 py-3 rounded-xl font-mono text-sm bg-black/50 text-white placeholder-neutral-600 outline-none transition-all"
                style={{
                  border: `1px solid ${AUTH_COLORS.primary}30`,
                }}
              />
            </div>
          </div>

          {/* Password Requirements */}
          <div className="space-y-2">
            {passwordRequirements.map((req, i) => (
              <div key={i} className="flex items-center gap-2">
                <div
                  className="w-4 h-4 rounded-full flex items-center justify-center"
                  style={{
                    background: req.met ? `${AUTH_COLORS.success}20` : "rgba(255,255,255,0.1)",
                    border: `1px solid ${req.met ? AUTH_COLORS.success : "rgba(255,255,255,0.2)"}`,
                  }}
                >
                  {req.met && <Check className="w-2.5 h-2.5" style={{ color: AUTH_COLORS.success }} />}
                </div>
                <span
                  className="font-mono text-xs"
                  style={{ color: req.met ? AUTH_COLORS.success : "rgba(255,255,255,0.4)" }}
                >
                  {req.label}
                </span>
              </div>
            ))}
          </div>

          {/* Error Message */}
          {error && (
            <div
              className="p-3 rounded-lg font-mono text-sm"
              style={{
                background: `${AUTH_COLORS.secondary}20`,
                border: `1px solid ${AUTH_COLORS.secondary}`,
                color: AUTH_COLORS.secondary,
              }}
            >
              {error}
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-4 rounded-xl font-mono text-sm uppercase tracking-wider transition-all disabled:opacity-50"
            style={{
              background: AUTH_COLORS.primary,
              color: "#000",
              boxShadow: `0 0 20px ${AUTH_COLORS.glow}`,
            }}
          >
            {isLoading ? "Creating Credentials..." : "Request Access"}
          </button>
        </form>

        {/* Footer Links */}
        <div className="mt-8 text-center space-y-3">
          <p className="font-mono text-sm text-neutral-400">
            Already have access?{" "}
            <Link
              href="/auth/login"
              className="transition-colors hover:underline"
              style={{ color: AUTH_COLORS.primary }}
            >
              Initialize Connection
            </Link>
          </p>
          <p className="font-mono text-xs text-neutral-600">WIRED CHAOS META OS v1.0</p>
        </div>
      </div>
    </div>
  )
}
