"use client"

import Link from "next/link"
import { CheckCircle, Mail, ArrowRight } from "lucide-react"
import { LiveCircuitry } from "@/components/live-circuitry"

const AUTH_COLORS = {
  primary: "#00FFF7",
  success: "#00FF88",
  dark: "#000000",
  glow: "rgba(0, 255, 247, 0.5)",
}

export default function SignUpSuccessPage() {
  return (
    <div
      className="min-h-screen relative flex items-center justify-center p-4"
      style={{ backgroundColor: AUTH_COLORS.dark }}
    >
      <LiveCircuitry />

      {/* Grid Background */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${AUTH_COLORS.primary}15 1px, transparent 1px),
            linear-gradient(to bottom, ${AUTH_COLORS.primary}15 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Success Card */}
      <div
        className="relative z-10 w-full max-w-md p-8 rounded-2xl text-center"
        style={{
          background: "rgba(0, 0, 0, 0.8)",
          border: `1px solid ${AUTH_COLORS.success}30`,
          boxShadow: `0 0 60px ${AUTH_COLORS.success}20`,
        }}
      >
        <div
          className="w-20 h-20 mx-auto mb-6 rounded-full flex items-center justify-center"
          style={{ background: `${AUTH_COLORS.success}20` }}
        >
          <CheckCircle className="w-10 h-10" style={{ color: AUTH_COLORS.success }} />
        </div>

        <h1 className="font-display text-3xl tracking-wider mb-4" style={{ color: AUTH_COLORS.success }}>
          ACCESS REQUESTED
        </h1>

        <p className="font-mono text-sm text-neutral-400 mb-6 leading-relaxed">
          Your access request has been transmitted. Check your email to verify your credentials and complete the
          initialization sequence.
        </p>

        <div
          className="p-4 rounded-xl mb-6"
          style={{
            background: `${AUTH_COLORS.primary}10`,
            border: `1px solid ${AUTH_COLORS.primary}30`,
          }}
        >
          <div className="flex items-center justify-center gap-3">
            <Mail className="w-5 h-5" style={{ color: AUTH_COLORS.primary }} />
            <span className="font-mono text-sm" style={{ color: AUTH_COLORS.primary }}>
              Verification signal sent
            </span>
          </div>
        </div>

        <Link
          href="/auth/login"
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-mono text-sm uppercase tracking-wider transition-all"
          style={{
            background: AUTH_COLORS.primary,
            color: "#000",
          }}
        >
          Return to Portal
          <ArrowRight className="w-4 h-4" />
        </Link>

        <p className="font-mono text-xs text-neutral-600 mt-8">WIRED CHAOS META OS v1.0</p>
      </div>
    </div>
  )
}
