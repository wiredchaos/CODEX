"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  Film,
  Hexagon,
  Users,
  Coins,
  Shield,
  Globe,
  Zap,
  ChevronRight,
  Wallet,
  ArrowRight,
  Star,
  Lock,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ElevatorTravel, usePatchLifecycle } from "@/components/elevator-travel"

const FILM3_COLORS = {
  primary: "#FFD700",
  secondary: "#FFA500",
  accent: "#FF6B00",
  dark: "#0A0A00",
  glow: "rgba(255, 215, 0, 0.4)",
}

const FEATURES = [
  {
    icon: Shield,
    title: "Token-Gate Your Films",
    description: "Control access with NFT tickets and membership tokens. Your audience, your rules.",
  },
  {
    icon: Coins,
    title: "Keep 90% Revenue",
    description: "No middlemen. Smart contracts ensure you get paid directly and instantly.",
  },
  {
    icon: Users,
    title: "Build Direct Relationships",
    description: "Own your audience data. Build communities around your content.",
  },
  {
    icon: Globe,
    title: "Global Distribution",
    description: "Reach worldwide audiences without geographic restrictions or censorship.",
  },
  {
    icon: Zap,
    title: "Instant Payments",
    description: "Get paid in crypto instantly. No 90-day waiting periods.",
  },
  {
    icon: Lock,
    title: "IP Protection",
    description: "Blockchain-verified ownership and immutable proof of creation.",
  },
]

const CREATOR_TIERS = [
  {
    name: "INDIE",
    price: "FREE",
    features: ["1 Film Upload", "Basic Analytics", "Community Access", "Standard Support"],
    highlight: false,
  },
  {
    name: "STUDIO",
    price: "0.5 ETH/yr",
    features: [
      "Unlimited Uploads",
      "Advanced Analytics",
      "Token-Gating Tools",
      "Priority Support",
      "Revenue Dashboard",
      "NFT Minting",
    ],
    highlight: true,
  },
  {
    name: "NETWORK",
    price: "2 ETH/yr",
    features: [
      "Everything in Studio",
      "Multi-Creator Accounts",
      "White-Label Platform",
      "API Access",
      "Dedicated Manager",
      "Custom Smart Contracts",
    ],
    highlight: false,
  },
]

const STATS = [
  { label: "Creators", value: "2,847" },
  { label: "Films Distributed", value: "12,450" },
  { label: "Revenue Paid", value: "$4.2M" },
  { label: "Countries", value: "147" },
]

export default function Film3Page() {
  const router = useRouter()
  const [walletConnected, setWalletConnected] = useState(false)
  const { onExitPatch } = usePatchLifecycle("patch_film3")

  return (
    <div className="min-h-screen relative overflow-hidden" style={{ backgroundColor: FILM3_COLORS.dark }}>
      {/* Animated Grid Background */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${FILM3_COLORS.primary}10 1px, transparent 1px),
            linear-gradient(to bottom, ${FILM3_COLORS.primary}10 1px, transparent 1px)
          `,
          backgroundSize: "80px 80px",
        }}
      />

      {/* Floating Film Elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full opacity-20"
            style={{
              width: `${20 + Math.random() * 40}px`,
              height: `${20 + Math.random() * 40}px`,
              background: `radial-gradient(circle, ${FILM3_COLORS.primary}, transparent)`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `float-particle ${5 + Math.random() * 10}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 5}s`,
            }}
          />
        ))}
      </div>

      {/* Header */}
      <header className="relative z-20 p-4 sm:p-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <button
            onClick={() => router.push("/789")}
            className="flex items-center gap-2 text-neutral-400 hover:text-white transition-colors"
          >
            <ChevronRight className="w-4 h-4 rotate-180" />
            <span className="font-mono text-sm">Back</span>
          </button>

          <span className="font-display text-xl font-bold" style={{ color: FILM3_COLORS.primary }}>
            789
          </span>

          <Button
            onClick={() => setWalletConnected(!walletConnected)}
            className="font-mono text-xs uppercase tracking-wider"
            style={{
              background: walletConnected ? "transparent" : FILM3_COLORS.primary,
              color: walletConnected ? FILM3_COLORS.primary : FILM3_COLORS.dark,
              border: `2px solid ${FILM3_COLORS.primary}`,
            }}
          >
            <Wallet className="w-4 h-4 mr-2" />
            {walletConnected ? "CONNECTED" : "CONNECT WALLET"}
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative z-10 px-4 py-16 sm:py-24">
        <div className="max-w-5xl mx-auto text-center">
          {/* Badge */}
          <Badge
            className="mb-8 px-4 py-2 font-mono text-xs uppercase tracking-wider"
            style={{
              background: `${FILM3_COLORS.primary}20`,
              color: FILM3_COLORS.primary,
              border: `1px solid ${FILM3_COLORS.primary}40`,
            }}
          >
            <Hexagon className="w-4 h-4 mr-2" />
            #FILM3: DECENTRALIZED CINEMA
          </Badge>

          {/* Main Headline */}
          <h1 className="font-display text-4xl sm:text-6xl md:text-7xl font-bold mb-6 leading-tight">
            <span className="text-white">WEB2</span>
            <br />
            <span className="text-white">FILMMAKERS</span>
            <br />
            <span style={{ color: FILM3_COLORS.primary }}>MEET WEB3</span>
          </h1>

          {/* Subheadline */}
          <p className="font-mono text-base sm:text-lg text-neutral-400 max-w-2xl mx-auto mb-10 leading-relaxed">
            Join the #FILM3 movement. Bypass Hollywood gatekeepers. Token-gate your films. Build direct relationships
            with your audience. Keep 90% of revenue.
          </p>

          {/* CTA Button */}
          <Button
            size="lg"
            className="font-mono text-sm uppercase tracking-wider px-8 py-6"
            style={{
              background: FILM3_COLORS.primary,
              color: FILM3_COLORS.dark,
              boxShadow: `0 0 40px ${FILM3_COLORS.glow}`,
            }}
          >
            START YOUR FILM3 JOURNEY
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>

          {/* Floating Badge */}
          <div className="mt-12 inline-flex items-center gap-2">
            <Badge
              variant="outline"
              className="px-4 py-2"
              style={{
                borderColor: FILM3_COLORS.secondary,
                color: FILM3_COLORS.secondary,
              }}
            >
              Film3
            </Badge>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="relative z-10 px-4 py-12">
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            {STATS.map((stat, i) => (
              <div
                key={i}
                className="text-center p-6 rounded-xl"
                style={{
                  background: "rgba(255, 255, 255, 0.02)",
                  border: `1px solid ${FILM3_COLORS.primary}20`,
                }}
              >
                <p className="font-display text-3xl sm:text-4xl font-bold mb-1" style={{ color: FILM3_COLORS.primary }}>
                  {stat.value}
                </p>
                <p className="font-mono text-xs uppercase tracking-wider text-neutral-500">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="relative z-10 px-4 py-16 sm:py-24">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="font-display text-3xl sm:text-4xl font-bold mb-4" style={{ color: FILM3_COLORS.primary }}>
              WHY FILM3?
            </h2>
            <p className="font-mono text-sm text-neutral-400">The future of independent cinema is decentralized</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {FEATURES.map((feature, i) => {
              const Icon = feature.icon
              return (
                <Card
                  key={i}
                  className="group transition-all duration-300 hover:scale-[1.02]"
                  style={{
                    background: "rgba(0, 0, 0, 0.6)",
                    border: `1px solid ${FILM3_COLORS.primary}20`,
                  }}
                >
                  <CardContent className="p-6">
                    <div
                      className="w-12 h-12 rounded-lg flex items-center justify-center mb-4"
                      style={{
                        background: `${FILM3_COLORS.primary}15`,
                        color: FILM3_COLORS.primary,
                      }}
                    >
                      <Icon className="w-6 h-6" />
                    </div>
                    <h3 className="font-mono text-sm uppercase tracking-wider text-white mb-2">{feature.title}</h3>
                    <p className="text-sm text-neutral-400 leading-relaxed">{feature.description}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="relative z-10 px-4 py-16 sm:py-24">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="font-display text-3xl sm:text-4xl font-bold mb-4" style={{ color: FILM3_COLORS.primary }}>
              HOW IT WORKS
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              { step: "01", title: "UPLOAD", desc: "Upload your film to IPFS decentralized storage" },
              { step: "02", title: "TOKENIZE", desc: "Create NFT tickets or membership tokens" },
              { step: "03", title: "DISTRIBUTE", desc: "Set your price and access rules" },
              { step: "04", title: "EARN", desc: "Receive payments directly to your wallet" },
            ].map((item, i) => (
              <div key={i} className="text-center">
                <div
                  className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center font-display text-2xl font-bold"
                  style={{
                    background: `${FILM3_COLORS.primary}20`,
                    color: FILM3_COLORS.primary,
                    border: `2px solid ${FILM3_COLORS.primary}`,
                  }}
                >
                  {item.step}
                </div>
                <h3 className="font-mono text-sm uppercase tracking-wider text-white mb-2">{item.title}</h3>
                <p className="text-xs text-neutral-500">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Tiers */}
      <section className="relative z-10 px-4 py-16 sm:py-24">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="font-display text-3xl sm:text-4xl font-bold mb-4" style={{ color: FILM3_COLORS.primary }}>
              CREATOR TIERS
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {CREATOR_TIERS.map((tier, i) => (
              <Card
                key={i}
                className="relative overflow-hidden"
                style={{
                  background: tier.highlight
                    ? `linear-gradient(135deg, ${FILM3_COLORS.primary}10, ${FILM3_COLORS.dark})`
                    : "rgba(0, 0, 0, 0.6)",
                  border: `2px solid ${tier.highlight ? FILM3_COLORS.primary : FILM3_COLORS.primary + "20"}`,
                  boxShadow: tier.highlight ? `0 0 40px ${FILM3_COLORS.glow}` : "none",
                }}
              >
                {tier.highlight && (
                  <div
                    className="absolute top-0 right-0 px-3 py-1 font-mono text-xs"
                    style={{
                      background: FILM3_COLORS.primary,
                      color: FILM3_COLORS.dark,
                    }}
                  >
                    POPULAR
                  </div>
                )}
                <CardContent className="p-6">
                  <h3
                    className="font-display text-xl font-bold mb-2"
                    style={{ color: tier.highlight ? FILM3_COLORS.primary : "white" }}
                  >
                    {tier.name}
                  </h3>
                  <p className="font-mono text-2xl font-bold mb-6" style={{ color: FILM3_COLORS.primary }}>
                    {tier.price}
                  </p>
                  <ul className="space-y-3 mb-6">
                    {tier.features.map((feature, j) => (
                      <li key={j} className="flex items-center gap-2 text-sm text-neutral-300">
                        <Star className="w-4 h-4" style={{ color: FILM3_COLORS.primary }} />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button
                    className="w-full font-mono text-xs uppercase"
                    style={{
                      background: tier.highlight ? FILM3_COLORS.primary : "transparent",
                      color: tier.highlight ? FILM3_COLORS.dark : FILM3_COLORS.primary,
                      border: `2px solid ${FILM3_COLORS.primary}`,
                    }}
                  >
                    {tier.price === "FREE" ? "START FREE" : "GET STARTED"}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative z-10 px-4 py-16 sm:py-24">
        <div className="max-w-3xl mx-auto text-center">
          <div
            className="p-8 sm:p-12 rounded-2xl"
            style={{
              background: `linear-gradient(135deg, ${FILM3_COLORS.primary}10, transparent)`,
              border: `2px solid ${FILM3_COLORS.primary}30`,
            }}
          >
            <Film className="w-16 h-16 mx-auto mb-6" style={{ color: FILM3_COLORS.primary }} />
            <h2 className="font-display text-2xl sm:text-3xl font-bold mb-4" style={{ color: FILM3_COLORS.primary }}>
              READY TO JOIN THE REVOLUTION?
            </h2>
            <p className="font-mono text-sm text-neutral-400 mb-8">
              Thousands of filmmakers are already bypassing Hollywood. Your audience is waiting.
            </p>
            <Button
              size="lg"
              className="font-mono text-sm uppercase tracking-wider"
              style={{
                background: FILM3_COLORS.primary,
                color: FILM3_COLORS.dark,
              }}
            >
              LAUNCH YOUR FILM3 STUDIO
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </div>
      </section>

      <ElevatorTravel currentFloor="film3" onExitPatch={onExitPatch} />

      <style jsx>{`
        @keyframes float-particle {
          0%, 100% { transform: translateY(0) rotate(0deg); opacity: 0.2; }
          50% { transform: translateY(-30px) rotate(180deg); opacity: 0.4; }
        }
      `}</style>
    </div>
  )
}
