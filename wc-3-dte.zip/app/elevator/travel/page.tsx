"use client"

import { useEffect, useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { ChevronUp, ChevronDown } from "lucide-react"

const COLORS = {
  cyan: "#00FFF7",
  gold: "#FFD700",
  dark: "#02030A",
}

export default function ElevatorTravelPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const destination = searchParams.get("to") || "lobby"
  const [currentFloor, setCurrentFloor] = useState(0)
  const [direction, setDirection] = useState<"up" | "down">("up")
  const [doorsState, setDoorsState] = useState<"closed" | "opening" | "open">("closed")

  useEffect(() => {
    // Simulate floor travel
    const floors = ["LBY", "789", "333", "NPC", "HRM", destination.toUpperCase()]
    let floorIndex = 0

    const travelInterval = setInterval(() => {
      if (floorIndex < floors.length - 1) {
        floorIndex++
        setCurrentFloor(floorIndex)
        setDirection(floorIndex % 2 === 0 ? "up" : "down")
      } else {
        clearInterval(travelInterval)
        setDoorsState("opening")

        setTimeout(() => {
          setDoorsState("open")
          setTimeout(() => {
            router.push(`/${destination}`)
          }, 500)
        }, 800)
      }
    }, 400)

    return () => clearInterval(travelInterval)
  }, [destination, router])

  const floors = ["LBY", "789", "333", "NPC", "HRM", destination.toUpperCase()]

  return (
    <div className="min-h-screen flex flex-col items-center justify-center" style={{ backgroundColor: COLORS.dark }}>
      {/* Elevator Interior */}
      <div
        className="relative w-full max-w-md aspect-[3/4] rounded-2xl overflow-hidden"
        style={{
          background: "linear-gradient(180deg, #1a1a1a 0%, #0a0a0a 100%)",
          border: `2px solid ${COLORS.cyan}30`,
        }}
      >
        {/* Ceiling Light */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-1 bg-gradient-to-r from-transparent via-white/30 to-transparent" />

        {/* Floor Indicator */}
        <div className="absolute top-8 left-1/2 -translate-x-1/2">
          <div
            className="px-8 py-4 rounded-lg text-center"
            style={{
              background: "rgba(0,0,0,0.9)",
              border: `2px solid ${COLORS.cyan}`,
              boxShadow: `0 0 30px ${COLORS.cyan}30`,
            }}
          >
            <div className="flex items-center justify-center gap-2 mb-2">
              {direction === "up" ? (
                <ChevronUp className="w-6 h-6 animate-bounce" style={{ color: COLORS.cyan }} />
              ) : (
                <ChevronDown className="w-6 h-6 animate-bounce" style={{ color: COLORS.cyan }} />
              )}
            </div>
            <span
              className="font-mono text-4xl font-bold tracking-wider"
              style={{
                color: COLORS.cyan,
                textShadow: `0 0 20px ${COLORS.cyan}`,
              }}
            >
              {floors[currentFloor]}
            </span>
          </div>
        </div>

        {/* Side Buttons */}
        <div className="absolute right-4 top-1/2 -translate-y-1/2 space-y-2">
          {floors.map((floor, i) => (
            <div
              key={floor}
              className="w-8 h-8 rounded-full flex items-center justify-center font-mono text-xs transition-all duration-300"
              style={{
                background: i === currentFloor ? COLORS.cyan : "rgba(255,255,255,0.1)",
                color: i === currentFloor ? "#000" : "#666",
                boxShadow: i === currentFloor ? `0 0 15px ${COLORS.cyan}` : "none",
              }}
            >
              {i + 1}
            </div>
          ))}
        </div>

        {/* Elevator Doors */}
        <div className="absolute bottom-0 left-0 right-0 h-2/3 flex">
          <div
            className="flex-1 transition-all duration-700 ease-in-out"
            style={{
              background: "linear-gradient(90deg, #2a2a2a 0%, #3a3a3a 50%, #2a2a2a 100%)",
              borderRight: `1px solid ${COLORS.cyan}40`,
              transform: doorsState === "open" ? "translateX(-100%)" : "translateX(0)",
            }}
          >
            {/* Door texture lines */}
            <div className="h-full flex flex-col justify-evenly px-4">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="h-px bg-white/5" />
              ))}
            </div>
          </div>
          <div
            className="flex-1 transition-all duration-700 ease-in-out"
            style={{
              background: "linear-gradient(270deg, #2a2a2a 0%, #3a3a3a 50%, #2a2a2a 100%)",
              borderLeft: `1px solid ${COLORS.cyan}40`,
              transform: doorsState === "open" ? "translateX(100%)" : "translateX(0)",
            }}
          >
            <div className="h-full flex flex-col justify-evenly px-4">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="h-px bg-white/5" />
              ))}
            </div>
          </div>
        </div>

        {/* Floor glow when arriving */}
        {doorsState !== "closed" && (
          <div
            className="absolute bottom-0 left-0 right-0 h-32 pointer-events-none animate-pulse"
            style={{
              background: `linear-gradient(to top, ${COLORS.cyan}30, transparent)`,
            }}
          />
        )}
      </div>

      {/* Status */}
      <div className="mt-8 text-center">
        <p className="font-mono text-sm text-neutral-500">
          {doorsState === "closed" ? (
            <span className="animate-pulse">In Transit...</span>
          ) : doorsState === "opening" ? (
            <span>Doors Opening...</span>
          ) : (
            <span style={{ color: COLORS.cyan }}>Arrived at {destination.toUpperCase()}</span>
          )}
        </p>
      </div>
    </div>
  )
}
