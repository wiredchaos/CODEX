"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  ChevronUp,
  ChevronDown,
  Brain,
  Film,
  Radio,
  ShoppingBag,
  CreditCard,
  Cpu,
  BookOpen,
  Sparkles,
  GraduationCap,
  Building2,
  Globe,
  BarChart3,
  Gamepad2,
} from "lucide-react"
import { Button } from "@/components/ui/button"

const COLORS = {
  cyan: "#00FFF7",
  gold: "#FFD700",
  purple: "#A020F0",
  red: "#FF1744",
  green: "#00FF88",
  blue: "#00BFFF",
  dark: "#02030A",
}

const ELEVATOR_COLUMNS = [
  {
    id: "business",
    name: "Business Stack",
    color: COLORS.cyan,
    floors: [
      { id: "lobby", label: "LBY", name: "WIRED CHAOS META", route: "/", icon: Building2 },
      { id: "789", label: "789", name: "STUDIOS / OTT", route: "/789", icon: Film },
      { id: "333", label: "333", name: "SIGNAL STUDIO", route: "/333", icon: Radio },
      { id: "mall", label: "MLL", name: "CHAOS STORE", route: "/mall", icon: ShoppingBag },
      { id: "credit", label: "CRD", name: "CREDIT REPAIR", route: "/credit-repair", icon: CreditCard },
      { id: "university", label: "UNI", name: "WC ACADEMY", route: "/university", icon: GraduationCap },
    ],
  },
  {
    id: "core",
    name: "Core Systems",
    color: COLORS.green,
    floors: [
      { id: "npc", label: "NPC", name: "NEURO PROMPT", route: "/npc", icon: Cpu },
      { id: "hrm", label: "HRM", name: "TRAINING GAMES", route: "/hrm", icon: Gamepad2 },
      { id: "hemisphere", label: "HSP", name: "HEMISPHERE", route: "/hemisphere", icon: BarChart3 },
      { id: "globe", label: "GLB", name: "GLOBE EXPLORER", route: "/globe", icon: Globe },
      { id: "chaos-os", label: "COS", name: "CHAOS OS", route: "/chaos-os", icon: Brain },
    ],
  },
  {
    id: "rogue",
    name: "Rogue Frequency",
    color: COLORS.purple,
    floors: [
      { id: "fen", label: "FEN", name: "AKASHIC REALM", route: "/fen", icon: Sparkles },
      { id: "vault33", label: "V33", name: "AKASHIC VAULT", route: "/vault33", icon: BookOpen },
      { id: "akira", label: "AKR", name: "NEURO CODEX", route: "/fen/akira", icon: Sparkles, gated: true },
      { id: "gamma", label: "GAM", name: "DD CARTOONS", route: "/gamma", icon: Film },
    ],
  },
]

export default function ElevatorPage() {
  const router = useRouter()
  const [selectedFloor, setSelectedFloor] = useState<string | null>(null)
  const [hoveredColumn, setHoveredColumn] = useState<string | null>(null)
  const [isTransitioning, setIsTransitioning] = useState(false)
  const [currentLevel, setCurrentLevel] = useState(0)

  const handleFloorSelect = (floor: (typeof ELEVATOR_COLUMNS)[0]["floors"][0]) => {
    if (isTransitioning) return
    if (floor.gated) {
      // Could add riddle gate here
      router.push("/fen")
      return
    }

    setIsTransitioning(true)
    setSelectedFloor(floor.id)

    // Animate travel
    setTimeout(() => {
      router.push(floor.route)
    }, 800)
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: COLORS.dark }}>
      {/* Elevator Interior Background */}
      <div className="fixed inset-0 pointer-events-none">
        {/* Metal walls texture */}
        <div
          className="absolute inset-0"
          style={{
            background: `
              linear-gradient(180deg, rgba(20,20,25,1) 0%, rgba(10,10,15,1) 100%),
              repeating-linear-gradient(90deg, transparent 0px, transparent 100px, rgba(255,255,255,0.02) 100px, rgba(255,255,255,0.02) 101px)
            `,
          }}
        />

        {/* Ceiling lights */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-2 bg-gradient-to-r from-transparent via-white/20 to-transparent" />

        {/* Floor indicator strip */}
        <div
          className="absolute top-8 left-1/2 -translate-x-1/2 px-8 py-2 rounded-lg"
          style={{
            background: "rgba(0,0,0,0.8)",
            border: `1px solid ${COLORS.cyan}30`,
          }}
        >
          <div className="flex items-center gap-4">
            <ChevronUp className="w-4 h-4" style={{ color: COLORS.cyan }} />
            <span className="font-mono text-2xl tracking-wider" style={{ color: COLORS.cyan }}>
              {selectedFloor?.toUpperCase() || "LOBBY"}
            </span>
            <ChevronDown className="w-4 h-4" style={{ color: COLORS.cyan }} />
          </div>
        </div>
      </div>

      {/* Header */}
      <header className="relative z-10 p-6 text-center">
        <h1
          className="text-3xl font-bold uppercase tracking-widest"
          style={{
            color: COLORS.cyan,
            textShadow: `0 0 20px ${COLORS.cyan}50`,
          }}
        >
          Elevator Hall
        </h1>
        <p className="text-neutral-500 text-sm mt-1">Select a floor to travel</p>
      </header>

      {/* 3-Column Elevator Hall */}
      <main className="relative z-10 flex-1 px-4 py-8 overflow-x-auto">
        <div className="flex gap-6 justify-center min-w-max mx-auto">
          {ELEVATOR_COLUMNS.map((column) => (
            <div
              key={column.id}
              className="w-64 rounded-2xl overflow-hidden transition-all duration-300"
              style={{
                background: hoveredColumn === column.id ? `${column.color}10` : "rgba(0,0,0,0.6)",
                border: `2px solid ${hoveredColumn === column.id ? column.color : "rgba(255,255,255,0.1)"}`,
                boxShadow: hoveredColumn === column.id ? `0 0 40px ${column.color}20` : "none",
              }}
              onMouseEnter={() => setHoveredColumn(column.id)}
              onMouseLeave={() => setHoveredColumn(null)}
            >
              {/* Column Header */}
              <div
                className="p-4 border-b text-center"
                style={{
                  borderColor: `${column.color}30`,
                  background: `${column.color}10`,
                }}
              >
                <h2 className="font-mono text-sm uppercase tracking-wider" style={{ color: column.color }}>
                  {column.name}
                </h2>
              </div>

              {/* Floor Buttons */}
              <div className="p-4 space-y-3">
                {column.floors.map((floor) => {
                  const Icon = floor.icon
                  const isSelected = selectedFloor === floor.id

                  return (
                    <button
                      key={floor.id}
                      onClick={() => handleFloorSelect(floor)}
                      disabled={isTransitioning}
                      className="w-full p-3 rounded-xl text-left transition-all duration-200 hover:scale-[1.02] group disabled:opacity-50"
                      style={{
                        background: isSelected ? `${column.color}20` : "rgba(255,255,255,0.03)",
                        border: `1px solid ${isSelected ? column.color : "transparent"}`,
                      }}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className="w-10 h-10 rounded-lg flex items-center justify-center font-mono text-sm font-bold"
                          style={{
                            background: `${column.color}20`,
                            color: column.color,
                          }}
                        >
                          {floor.label}
                        </div>
                        <div className="flex-1">
                          <p className="text-white text-sm font-medium">{floor.name}</p>
                          {floor.gated && <p className="text-xs text-red-400">Riddle Gated</p>}
                        </div>
                        <Icon
                          className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity"
                          style={{ color: column.color }}
                        />
                      </div>
                    </button>
                  )
                })}
              </div>

              {/* Elevator Door Animation */}
              <div className="relative h-16 overflow-hidden">
                <div
                  className="absolute inset-0 flex"
                  style={{
                    opacity: hoveredColumn === column.id ? 1 : 0.3,
                  }}
                >
                  <div
                    className="flex-1 transition-all duration-500"
                    style={{
                      background: `linear-gradient(90deg, ${column.color}20, ${column.color}40)`,
                      transform: hoveredColumn === column.id ? "translateX(-100%)" : "translateX(0)",
                    }}
                  />
                  <div
                    className="flex-1 transition-all duration-500"
                    style={{
                      background: `linear-gradient(270deg, ${column.color}20, ${column.color}40)`,
                      transform: hoveredColumn === column.id ? "translateX(100%)" : "translateX(0)",
                    }}
                  />
                </div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span
                    className="font-mono text-xs uppercase tracking-wider transition-opacity"
                    style={{
                      color: column.color,
                      opacity: hoveredColumn === column.id ? 1 : 0,
                    }}
                  >
                    Doors Open
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Footer Controls */}
      <footer className="relative z-10 p-6">
        <div className="flex items-center justify-center gap-4">
          <Button
            variant="outline"
            className="gap-2 bg-transparent"
            style={{ borderColor: `${COLORS.cyan}40`, color: COLORS.cyan }}
            onClick={() => router.push("/")}
          >
            <Building2 className="w-4 h-4" />
            Return to Lobby
          </Button>
          <Button
            variant="outline"
            className="gap-2 bg-transparent"
            style={{ borderColor: `${COLORS.gold}40`, color: COLORS.gold }}
            onClick={() => router.push("/tour")}
          >
            <Brain className="w-4 h-4" />
            Start Tour
          </Button>
        </div>
      </footer>

      {/* Transition Overlay */}
      {isTransitioning && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black">
          <div className="text-center">
            <div
              className="w-20 h-20 mx-auto mb-4 rounded-lg flex items-center justify-center animate-pulse"
              style={{ background: `${COLORS.cyan}20`, border: `2px solid ${COLORS.cyan}` }}
            >
              <span className="font-mono text-2xl font-bold" style={{ color: COLORS.cyan }}>
                {selectedFloor?.toUpperCase()}
              </span>
            </div>
            <p className="text-neutral-400 font-mono text-sm animate-pulse">Traveling...</p>
          </div>
        </div>
      )}
    </div>
  )
}
