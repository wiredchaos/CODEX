"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  Play,
  Info,
  Plus,
  ChevronLeft,
  ChevronRight,
  Volume2,
  Search,
  Bell,
  User,
  Home,
  Film,
  Tv,
  Users,
} from "lucide-react"
import { Button } from "@/components/ui/button"

const COLORS = {
  primary: "#ff1744",
  secondary: "#00e5ff",
  dark: "#02030A",
  gold: "#FFD700",
}

// Content data
const FEATURED = {
  id: "featured-1",
  title: "The Chaos Protocol",
  description:
    "When reality fragments, a rogue AI emerges from the WIRED CHAOS network. The boundaries between digital and physical worlds collapse in this mind-bending thriller.",
  image: "/cyberpunk-city-neon-red-thriller-movie-poster.jpg",
  rating: "TV-MA",
  year: "2025",
  duration: "2h 14m",
  match: "98%",
}

const CONTENT_ROWS = [
  {
    title: "789 Studios Originals",
    items: [
      { id: "1", title: "Digital Frontier", image: "/sci-fi-digital-landscape-movie-poster.jpg" },
      { id: "2", title: "Neon Dynasty", image: "/neon-cyberpunk-dynasty-movie-poster.jpg" },
      { id: "3", title: "The Collective", image: "/collective-ai-network-movie-poster.jpg" },
      { id: "4", title: "Signal Lost", image: "/lost-signal-apocalypse-movie-poster.jpg" },
      { id: "5", title: "Quantum Break", image: "/quantum-physics-thriller-movie-poster.jpg" },
      { id: "6", title: "The Architect", image: "/architect-building-futuristic-movie-poster.jpg" },
    ],
  },
  {
    title: "CSN Live Lineup",
    items: [
      { id: "7", title: "Morning Briefing", image: "/news-morning-show-set.jpg" },
      { id: "8", title: "Tech Today", image: "/technology-talk-show-set.jpg" },
      { id: "9", title: "Creator Spotlight", image: "/creator-interview-spotlight-set.jpg" },
      { id: "10", title: "Market Watch", image: "/financial-market-news-set.jpg" },
      { id: "11", title: "Evening Edition", image: "/evening-news-broadcast-set.jpg" },
    ],
  },
  {
    title: "Film3 Features",
    items: [
      { id: "12", title: "Decentralized Dreams", image: "/blockchain-decentralized-dreams-movie.jpg" },
      { id: "13", title: "Token Gate", image: "/placeholder-6bplc.png" },
      { id: "14", title: "DAO Rising", image: "/dao-governance-uprising-movie.jpg" },
      { id: "15", title: "The Mint", image: "/placeholder.svg?height=400&width=600" },
    ],
  },
  {
    title: "Documentaries",
    items: [
      { id: "16", title: "Building the Metaverse", image: "/placeholder.svg?height=400&width=600" },
      { id: "17", title: "Creator Economy", image: "/placeholder.svg?height=400&width=600" },
      { id: "18", title: "Web3 Revolution", image: "/placeholder.svg?height=400&width=600" },
      { id: "19", title: "AI Awakening", image: "/placeholder.svg?height=400&width=600" },
    ],
  },
  {
    title: "Conversations",
    items: [
      { id: "20", title: "Founders Forum", image: "/placeholder.svg?height=400&width=600" },
      { id: "21", title: "Artist Collective", image: "/placeholder.svg?height=400&width=600" },
      { id: "22", title: "Tech Titans", image: "/placeholder.svg?height=400&width=600" },
    ],
  },
]

function ContentRow({ title, items }: { title: string; items: (typeof CONTENT_ROWS)[0]["items"] }) {
  const [scrollPosition, setScrollPosition] = useState(0)
  const [hoveredId, setHoveredId] = useState<string | null>(null)

  const scroll = (direction: "left" | "right") => {
    const container = document.getElementById(`row-${title.replace(/\s/g, "-")}`)
    if (container) {
      const scrollAmount = direction === "left" ? -400 : 400
      container.scrollBy({ left: scrollAmount, behavior: "smooth" })
      setScrollPosition(container.scrollLeft + scrollAmount)
    }
  }

  return (
    <div className="relative group/row mb-8">
      <h2 className="text-lg md:text-xl font-semibold text-white mb-3 px-4 md:px-12">{title}</h2>

      {/* Scroll Buttons */}
      <button
        onClick={() => scroll("left")}
        className="absolute left-0 top-1/2 -translate-y-1/2 z-20 w-10 h-full bg-gradient-to-r from-[#02030A] to-transparent opacity-0 group-hover/row:opacity-100 transition-opacity flex items-center justify-center"
        aria-label="Scroll left"
      >
        <ChevronLeft className="w-8 h-8 text-white" />
      </button>
      <button
        onClick={() => scroll("right")}
        className="absolute right-0 top-1/2 -translate-y-1/2 z-20 w-10 h-full bg-gradient-to-l from-[#02030A] to-transparent opacity-0 group-hover/row:opacity-100 transition-opacity flex items-center justify-center"
        aria-label="Scroll right"
      >
        <ChevronRight className="w-8 h-8 text-white" />
      </button>

      {/* Content Slider */}
      <div
        id={`row-${title.replace(/\s/g, "-")}`}
        className="flex gap-2 overflow-x-auto scrollbar-hide px-4 md:px-12 scroll-smooth"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        {items.map((item, index) => (
          <div
            key={item.id}
            className="relative flex-shrink-0 w-[160px] md:w-[240px] aspect-video rounded-md overflow-hidden cursor-pointer transition-all duration-300"
            style={{
              transform: hoveredId === item.id ? "scale(1.1)" : "scale(1)",
              zIndex: hoveredId === item.id ? 10 : 1,
            }}
            onMouseEnter={() => setHoveredId(item.id)}
            onMouseLeave={() => setHoveredId(null)}
          >
            <img src={item.image || "/placeholder.svg"} alt={item.title} className="w-full h-full object-cover" />

            {/* Hover Expansion Panel */}
            {hoveredId === item.id && (
              <div
                className="absolute inset-x-0 -bottom-20 bg-[#181818] rounded-b-md p-3 shadow-2xl"
                style={{ boxShadow: "0 10px 40px rgba(0,0,0,0.8)" }}
              >
                <div className="flex items-center gap-2 mb-2">
                  <button
                    className="w-8 h-8 rounded-full bg-white flex items-center justify-center hover:bg-white/90"
                    aria-label="Play"
                  >
                    <Play className="w-4 h-4 text-black fill-black" />
                  </button>
                  <button
                    className="w-8 h-8 rounded-full border border-white/40 flex items-center justify-center hover:border-white"
                    aria-label="Add to list"
                  >
                    <Plus className="w-4 h-4 text-white" />
                  </button>
                  <button
                    className="w-8 h-8 rounded-full border border-white/40 flex items-center justify-center hover:border-white ml-auto"
                    aria-label="More info"
                  >
                    <Info className="w-4 h-4 text-white" />
                  </button>
                </div>
                <p className="text-white text-sm font-medium truncate">{item.title}</p>
                <p className="text-green-500 text-xs">98% Match</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

export default function WatchPage() {
  const router = useRouter()
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMuted, setIsMuted] = useState(true)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <div className="min-h-screen bg-[#02030A]">
      {/* Top Navigation */}
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled ? "bg-[#02030A]" : "bg-gradient-to-b from-black/80 to-transparent"
        }`}
      >
        <div className="flex items-center justify-between px-4 md:px-12 py-4">
          <div className="flex items-center gap-8">
            {/* Logo */}
            <button
              onClick={() => router.push("/789")}
              className="text-2xl font-bold"
              style={{ color: COLORS.primary }}
            >
              789
            </button>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-6">
              <a href="/watch" className="text-white text-sm font-medium">
                Home
              </a>
              <a href="/watch/series" className="text-white/70 text-sm hover:text-white/90">
                Series
              </a>
              <a href="/watch/films" className="text-white/70 text-sm hover:text-white/90">
                Films
              </a>
              <a href="/watch/csn" className="text-white/70 text-sm hover:text-white/90">
                CSN Live
              </a>
              <a href="/watch/my-list" className="text-white/70 text-sm hover:text-white/90">
                My List
              </a>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button className="text-white" aria-label="Search">
              <Search className="w-5 h-5" />
            </button>
            <button className="text-white hidden md:block" aria-label="Notifications">
              <Bell className="w-5 h-5" />
            </button>
            <button className="text-white" aria-label="Profile">
              <User className="w-5 h-5" />
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Banner */}
      <div className="relative h-[56vw] max-h-[80vh] min-h-[400px]">
        <img src={FEATURED.image || "/placeholder.svg"} alt={FEATURED.title} className="w-full h-full object-cover" />

        {/* Gradient Overlays */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#02030A] via-transparent to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#02030A] via-[#02030A]/20 to-transparent" />

        {/* Hero Content */}
        <div className="absolute bottom-[20%] left-4 md:left-12 max-w-xl">
          <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold text-white mb-4">{FEATURED.title}</h1>
          <div className="flex items-center gap-2 mb-4 text-sm">
            <span className="text-green-500 font-semibold">{FEATURED.match}</span>
            <span className="text-white/70">{FEATURED.year}</span>
            <span className="px-1 border border-white/40 text-white/70 text-xs">{FEATURED.rating}</span>
            <span className="text-white/70">{FEATURED.duration}</span>
          </div>
          <p className="text-white/80 text-sm md:text-base mb-6 line-clamp-3">{FEATURED.description}</p>
          <div className="flex items-center gap-3">
            <Button className="bg-white text-black hover:bg-white/90 px-6 py-2 rounded flex items-center gap-2">
              <Play className="w-5 h-5 fill-black" />
              Play
            </Button>
            <Button
              variant="outline"
              className="bg-white/20 text-white border-0 hover:bg-white/30 px-6 py-2 rounded flex items-center gap-2"
            >
              <Info className="w-5 h-5" />
              More Info
            </Button>
          </div>
        </div>

        {/* Mute Button */}
        <button
          onClick={() => setIsMuted(!isMuted)}
          className="absolute bottom-[20%] right-4 md:right-12 w-10 h-10 rounded-full border border-white/40 flex items-center justify-center text-white hover:border-white"
          aria-label={isMuted ? "Unmute" : "Mute"}
        >
          <Volume2 className={`w-5 h-5 ${isMuted ? "opacity-50" : ""}`} />
        </button>
      </div>

      {/* Content Rows */}
      <div className="relative -mt-32 z-10 pb-20">
        {CONTENT_ROWS.map((row) => (
          <ContentRow key={row.title} title={row.title} items={row.items} />
        ))}
      </div>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-[#02030A] border-t border-white/10 z-50">
        <div className="flex items-center justify-around py-3">
          <button className="flex flex-col items-center gap-1 text-white">
            <Home className="w-5 h-5" />
            <span className="text-xs">Home</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-white/60">
            <Film className="w-5 h-5" />
            <span className="text-xs">Films</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-white/60">
            <Tv className="w-5 h-5" />
            <span className="text-xs">CSN</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-white/60">
            <Users className="w-5 h-5" />
            <span className="text-xs">Community</span>
          </button>
        </div>
      </nav>
    </div>
  )
}
