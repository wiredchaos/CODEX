"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, ExternalLink, Heart, Share2, Grid, Rows3, Verified } from "lucide-react"
import { Button } from "@/components/ui/button"

const STUDIO_COLORS = {
  primary: "#00BFFF",
  secondary: "#1E90FF",
  accent: "#00CED1",
  neon: "#00FFFF",
  dark: "#020812",
  glow: "rgba(0, 191, 255, 0.5)",
}

const NFT_ARTWORKS = [
  {
    id: 1,
    title: "NEURAL GENESIS",
    artist: "CyberVault",
    verified: true,
    price: "2.5 ETH",
    likes: 847,
    image: "/abstract-digital-neural-network-art-neon-cyan.jpg",
    collection: "Genesis Collection",
  },
  {
    id: 2,
    title: "CHAOS PROTOCOL",
    artist: "NeonDrifter",
    verified: true,
    price: "1.8 ETH",
    likes: 623,
    image: "/cyberpunk-chaos-glitch-art-red-black.jpg",
    collection: "Chaos Series",
  },
  {
    id: 3,
    title: "AKASHIC MEMORY",
    artist: "QuantumPulse",
    verified: false,
    price: "3.2 ETH",
    likes: 1204,
    image: "/mystical-akashic-records-purple-gold-sacred-geomet.jpg",
    collection: "Akashic Archives",
  },
  {
    id: 4,
    title: "MOTHERBOARD DREAMS",
    artist: "CircuitMind",
    verified: true,
    price: "0.9 ETH",
    likes: 456,
    image: "/motherboard-circuit-art-glowing-traces-cyan.jpg",
    collection: "Tech Dreams",
  },
  {
    id: 5,
    title: "FREQUENCY 589",
    artist: "WaveRunner",
    verified: true,
    price: "4.1 ETH",
    likes: 2103,
    image: "/sound-wave-frequency-visualization-neon.jpg",
    collection: "Signal Art",
  },
  {
    id: 6,
    title: "NETERU RISING",
    artist: "KhemeticVision",
    verified: true,
    price: "5.5 ETH",
    likes: 1876,
    image: "/egyptian-neteru-gods-futuristic-gold-black.jpg",
    collection: "Khemetic Series",
  },
]

const CATEGORIES = ["All", "Genesis", "Chaos", "Akashic", "Tech", "Signal", "Khemetic"]

export default function MuseumPage() {
  const router = useRouter()
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [likedItems, setLikedItems] = useState<number[]>([])

  const toggleLike = (id: number) => {
    setLikedItems((prev) => (prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]))
  }

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: STUDIO_COLORS.dark }}>
      {/* Grid Background */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${STUDIO_COLORS.primary}10 1px, transparent 1px),
            linear-gradient(to bottom, ${STUDIO_COLORS.primary}10 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Header */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(2, 8, 18, 0.95)",
          borderColor: `${STUDIO_COLORS.primary}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <button
                onClick={() => router.push("/333")}
                className="flex items-center gap-2 transition-colors hover:opacity-80"
                style={{ color: STUDIO_COLORS.primary }}
              >
                <ArrowLeft className="w-5 h-5" />
                <span className="font-mono text-sm uppercase">33-3</span>
              </button>
              <div className="w-px h-6" style={{ background: `${STUDIO_COLORS.primary}30` }} />
              <h1
                className="font-display text-xl sm:text-2xl uppercase tracking-wider"
                style={{
                  color: STUDIO_COLORS.neon,
                  textShadow: `0 0 20px ${STUDIO_COLORS.glow}`,
                }}
              >
                The Neon Vault
              </h1>
            </div>

            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                className="font-mono text-xs uppercase gap-2 bg-transparent"
                style={{
                  borderColor: STUDIO_COLORS.primary,
                  color: STUDIO_COLORS.neon,
                }}
              >
                <ExternalLink className="w-4 h-4" />
                <span className="hidden sm:inline">OpenSea</span>
              </Button>
              <div
                className="flex items-center gap-1 border rounded-lg p-1"
                style={{ borderColor: `${STUDIO_COLORS.primary}30` }}
              >
                <button
                  onClick={() => setViewMode("grid")}
                  className={`p-2 rounded transition-colors ${viewMode === "grid" ? "bg-white/10" : ""}`}
                  style={{ color: viewMode === "grid" ? STUDIO_COLORS.neon : "#666" }}
                >
                  <Grid className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setViewMode("list")}
                  className={`p-2 rounded transition-colors ${viewMode === "list" ? "bg-white/10" : ""}`}
                  style={{ color: viewMode === "list" ? STUDIO_COLORS.neon : "#666" }}
                >
                  <Rows3 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Categories - Fixed Typography */}
          <div className="flex items-center gap-2 mt-4 overflow-x-auto pb-2 scrollbar-hide">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className="px-3 sm:px-4 py-2 rounded-full font-mono text-xs uppercase whitespace-nowrap transition-all flex-shrink-0"
                style={{
                  background: selectedCategory === cat ? STUDIO_COLORS.neon : "transparent",
                  color: selectedCategory === cat ? "#000" : "#999",
                  border: `1px solid ${selectedCategory === cat ? STUDIO_COLORS.neon : "#333"}`,
                  minWidth: "fit-content",
                }}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        <div
          className={`grid gap-4 sm:gap-6 ${
            viewMode === "grid" ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3" : "grid-cols-1"
          }`}
        >
          {NFT_ARTWORKS.map((nft) => (
            <div
              key={nft.id}
              className={`group rounded-2xl overflow-hidden transition-all duration-300 hover:scale-[1.02] cursor-pointer ${
                viewMode === "list" ? "flex" : ""
              }`}
              style={{
                background: "rgba(10, 15, 25, 0.8)",
                border: `1px solid ${STUDIO_COLORS.primary}20`,
              }}
            >
              <div className={`relative ${viewMode === "list" ? "w-32 sm:w-48 flex-shrink-0" : "aspect-square"}`}>
                <img src={nft.image || "/placeholder.svg"} alt={nft.title} className="w-full h-full object-cover" />
                <div
                  className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3"
                  style={{ background: "rgba(0,0,0,0.6)" }}
                >
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      toggleLike(nft.id)
                    }}
                    className="p-3 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
                  >
                    <Heart
                      className={`w-5 h-5 ${likedItems.includes(nft.id) ? "fill-red-500 text-red-500" : "text-white"}`}
                    />
                  </button>
                  <button className="p-3 rounded-full bg-white/10 hover:bg-white/20 transition-colors">
                    <Share2 className="w-5 h-5 text-white" />
                  </button>
                </div>
              </div>

              <div className="p-4 sm:p-5 flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xs font-mono uppercase" style={{ color: STUDIO_COLORS.primary }}>
                    {nft.collection}
                  </span>
                </div>
                <h3
                  className="font-display text-base sm:text-lg uppercase mb-1 group-hover:text-cyan-400 transition-colors"
                  style={{ color: "#fff" }}
                >
                  {nft.title}
                </h3>
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-sm text-neutral-400">by {nft.artist}</span>
                  {nft.verified && <Verified className="w-4 h-4" style={{ color: STUDIO_COLORS.neon }} />}
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-mono text-sm sm:text-base font-bold" style={{ color: STUDIO_COLORS.neon }}>
                    {nft.price}
                  </span>
                  <span className="flex items-center gap-1 text-neutral-500 text-sm">
                    <Heart className="w-3 h-3" />
                    {nft.likes}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}
