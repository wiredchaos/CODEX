"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Shield, FileCheck, AlertTriangle, CheckCircle, Search, Clock, User, Hash } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

const STUDIO_COLORS = {
  primary: "#00BFFF",
  secondary: "#1E90FF",
  accent: "#00CED1",
  neon: "#00FFFF",
  dark: "#020812",
  glow: "rgba(0, 191, 255, 0.5)",
}

const IP_RECORDS = [
  {
    id: "IP-2025-001",
    title: "NEURAL GENESIS",
    type: "Digital Art",
    owner: "CyberVault",
    status: "verified",
    registeredDate: "2025-01-15",
    blockchain: "Ethereum",
    hash: "0x7f8e...3a2b",
  },
  {
    id: "IP-2025-002",
    title: "CHAOS PROTOCOL SERIES",
    type: "Music Collection",
    owner: "Signal Drift",
    status: "verified",
    registeredDate: "2025-01-10",
    blockchain: "Polygon",
    hash: "0x4c2d...8f1a",
  },
  {
    id: "IP-2025-003",
    title: "AKASHIC MEMORY",
    type: "Digital Art",
    owner: "QuantumPulse",
    status: "pending",
    registeredDate: "2025-01-18",
    blockchain: "Ethereum",
    hash: "0x9a3b...2c4d",
  },
  {
    id: "IP-2025-004",
    title: "WIRED PODCAST EP47",
    type: "Audio",
    owner: "Dr. Neural",
    status: "verified",
    registeredDate: "2025-01-12",
    blockchain: "Polygon",
    hash: "0x1e5f...7g8h",
  },
  {
    id: "IP-2025-005",
    title: "MOTHERBOARD DREAMS",
    type: "Digital Art",
    owner: "CircuitMind",
    status: "disputed",
    registeredDate: "2025-01-08",
    blockchain: "Ethereum",
    hash: "0x2b3c...4d5e",
  },
]

const STATUS_COLORS = {
  verified: { bg: "#00FF0020", border: "#00FF00", text: "#00FF00" },
  pending: { bg: "#FFD70020", border: "#FFD700", text: "#FFD700" },
  disputed: { bg: "#FF1A1A20", border: "#FF1A1A", text: "#FF1A1A" },
}

export default function IPAuditPage() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  const filteredRecords = IP_RECORDS.filter((record) => {
    const matchesSearch =
      record.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      record.owner.toLowerCase().includes(searchQuery.toLowerCase()) ||
      record.id.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesStatus = statusFilter === "all" || record.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const stats = {
    total: IP_RECORDS.length,
    verified: IP_RECORDS.filter((r) => r.status === "verified").length,
    pending: IP_RECORDS.filter((r) => r.status === "pending").length,
    disputed: IP_RECORDS.filter((r) => r.status === "disputed").length,
  }

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: STUDIO_COLORS.dark }}>
      {/* Grid Background */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${STUDIO_COLORS.primary}10 1px, transparent 1px),
            linear-gradient(to bottom, ${STUDIO_COLORS.primary}10 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Header */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(2, 8, 18, 0.95)",
          borderColor: `${STUDIO_COLORS.primary}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <button
                onClick={() => router.push("/333")}
                className="flex items-center gap-2 transition-colors hover:opacity-80"
                style={{ color: STUDIO_COLORS.primary }}
              >
                <ArrowLeft className="w-5 h-5" />
                <span className="font-mono text-sm uppercase">33-3</span>
              </button>
              <div className="w-px h-6" style={{ background: `${STUDIO_COLORS.primary}30` }} />
              <div className="flex items-center gap-2">
                <Shield className="w-6 h-6" style={{ color: STUDIO_COLORS.neon }} />
                <h1
                  className="font-display text-xl sm:text-2xl uppercase tracking-wider"
                  style={{
                    color: STUDIO_COLORS.neon,
                    textShadow: `0 0 20px ${STUDIO_COLORS.glow}`,
                  }}
                >
                  IP Audit
                </h1>
              </div>
            </div>

            <Button
              className="font-mono text-xs uppercase gap-2"
              style={{
                background: STUDIO_COLORS.neon,
                color: "#000",
              }}
            >
              <FileCheck className="w-4 h-4" />
              Register New IP
            </Button>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 mb-6 sm:mb-8">
          {[
            { label: "Total Records", value: stats.total, color: STUDIO_COLORS.neon },
            { label: "Verified", value: stats.verified, color: "#00FF00" },
            { label: "Pending", value: stats.pending, color: "#FFD700" },
            { label: "Disputed", value: stats.disputed, color: "#FF1A1A" },
          ].map((stat, i) => (
            <div
              key={i}
              className="p-4 rounded-xl text-center"
              style={{
                background: `${stat.color}10`,
                border: `1px solid ${stat.color}30`,
              }}
            >
              <p className="font-display text-2xl sm:text-3xl mb-1" style={{ color: stat.color }}>
                {stat.value}
              </p>
              <p className="font-mono text-xs text-neutral-500 uppercase">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6 sm:mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
            <Input
              placeholder="Search by title, owner, or ID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-black/50 border-neutral-800 focus:border-cyan-500"
            />
          </div>
          <div className="flex gap-2 overflow-x-auto pb-2 sm:pb-0">
            {["all", "verified", "pending", "disputed"].map((status) => (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className="px-4 py-2 rounded-full font-mono text-xs uppercase whitespace-nowrap transition-all flex-shrink-0"
                style={{
                  background: statusFilter === status ? STUDIO_COLORS.neon : "transparent",
                  color: statusFilter === status ? "#000" : "#999",
                  border: `1px solid ${statusFilter === status ? STUDIO_COLORS.neon : "#333"}`,
                }}
              >
                {status}
              </button>
            ))}
          </div>
        </div>

        {/* Records Table */}
        <div className="rounded-2xl overflow-hidden" style={{ border: `1px solid ${STUDIO_COLORS.primary}20` }}>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr style={{ background: "rgba(0, 191, 255, 0.1)" }}>
                  <th className="px-4 sm:px-6 py-4 text-left font-mono text-xs uppercase tracking-wider text-neutral-400">
                    ID
                  </th>
                  <th className="px-4 sm:px-6 py-4 text-left font-mono text-xs uppercase tracking-wider text-neutral-400">
                    Title
                  </th>
                  <th className="px-4 sm:px-6 py-4 text-left font-mono text-xs uppercase tracking-wider text-neutral-400 hidden sm:table-cell">
                    Type
                  </th>
                  <th className="px-4 sm:px-6 py-4 text-left font-mono text-xs uppercase tracking-wider text-neutral-400 hidden md:table-cell">
                    Owner
                  </th>
                  <th className="px-4 sm:px-6 py-4 text-left font-mono text-xs uppercase tracking-wider text-neutral-400">
                    Status
                  </th>
                  <th className="px-4 sm:px-6 py-4 text-left font-mono text-xs uppercase tracking-wider text-neutral-400 hidden lg:table-cell">
                    Hash
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredRecords.map((record, i) => {
                  const statusStyle = STATUS_COLORS[record.status as keyof typeof STATUS_COLORS]
                  return (
                    <tr
                      key={record.id}
                      className="border-t border-neutral-800 hover:bg-white/5 transition-colors cursor-pointer"
                    >
                      <td className="px-4 sm:px-6 py-4">
                        <span className="font-mono text-xs sm:text-sm" style={{ color: STUDIO_COLORS.primary }}>
                          {record.id}
                        </span>
                      </td>
                      <td className="px-4 sm:px-6 py-4">
                        <p className="font-mono text-xs sm:text-sm text-white uppercase truncate max-w-[150px] sm:max-w-none">
                          {record.title}
                        </p>
                      </td>
                      <td className="px-4 sm:px-6 py-4 hidden sm:table-cell">
                        <span className="text-xs sm:text-sm text-neutral-400">{record.type}</span>
                      </td>
                      <td className="px-4 sm:px-6 py-4 hidden md:table-cell">
                        <div className="flex items-center gap-2">
                          <User className="w-3 h-3 text-neutral-500" />
                          <span className="text-xs sm:text-sm text-neutral-300">{record.owner}</span>
                        </div>
                      </td>
                      <td className="px-4 sm:px-6 py-4">
                        <span
                          className="px-2 sm:px-3 py-1 rounded-full font-mono text-xs uppercase flex items-center gap-1 w-fit"
                          style={{
                            background: statusStyle.bg,
                            border: `1px solid ${statusStyle.border}`,
                            color: statusStyle.text,
                          }}
                        >
                          {record.status === "verified" && <CheckCircle className="w-3 h-3" />}
                          {record.status === "pending" && <Clock className="w-3 h-3" />}
                          {record.status === "disputed" && <AlertTriangle className="w-3 h-3" />}
                          <span className="hidden sm:inline">{record.status}</span>
                        </span>
                      </td>
                      <td className="px-4 sm:px-6 py-4 hidden lg:table-cell">
                        <div className="flex items-center gap-1 text-neutral-500">
                          <Hash className="w-3 h-3" />
                          <span className="font-mono text-xs">{record.hash}</span>
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  )
}
