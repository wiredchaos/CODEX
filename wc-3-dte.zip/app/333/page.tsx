"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  Radio,
  Palette,
  Shield,
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Headphones,
  ImageIcon,
  FileAudio,
} from "lucide-react"
import { ElevatorTravel, usePatchLifecycle } from "@/components/elevator-travel"

const STUDIO_COLORS = {
  cyan: "#00FFF7",
  red: "#FF1A1A",
  black: "#0D0D0D",
  silver: "#C0C0C0",
  neon: "#00FFF7",
  dark: "#000000",
  glow: "rgba(0, 255, 247, 0.5)",
}

const FLOOR_SECTIONS = [
  {
    id: "museum",
    label: "THE NEON VAULT",
    sublabel: "Digital Art Museum",
    icon: Palette,
    route: "/333/museum",
    description: "NFT Gallery • OpenSea Integration • Creator Exhibitions",
  },
  {
    id: "radio",
    label: "33.3 FM",
    sublabel: "Signal Broadcast",
    icon: Radio,
    route: "/333/radio",
    description: "Audio Player • Podcast Hub • Live Transmissions",
  },
  {
    id: "ip-audit",
    label: "IP AUDIT",
    sublabel: "Rights Management",
    icon: Shield,
    route: "/333/ip-audit",
    description: "Copyright Registry • Licensing • Ownership Verification",
  },
]

export default function Floor333Page() {
  const router = useRouter()
  const [hoveredSection, setHoveredSection] = useState<string | null>(null)
  const [audioPlaying, setAudioPlaying] = useState(false)
  const [currentTrack, setCurrentTrack] = useState({
    title: "NEURAL FREQUENCIES",
    artist: "WIRED CHAOS COLLECTIVE",
    frequency: "33.3",
  })

  const { onExitPatch } = usePatchLifecycle("patch_33_3fm_dogechain")

  return (
    <div className="min-h-screen relative overflow-hidden" style={{ backgroundColor: STUDIO_COLORS.black }}>
      <div
        className="fixed inset-0 opacity-15 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${STUDIO_COLORS.cyan}20 1px, transparent 1px),
            linear-gradient(to bottom, ${STUDIO_COLORS.cyan}20 1px, transparent 1px)
          `,
          backgroundSize: "40px 40px",
        }}
      />

      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full"
            style={{
              width: "4px",
              height: "4px",
              left: `${20 + i * 10}%`,
              top: `${10 + i * 12}%`,
              background: i % 2 === 0 ? STUDIO_COLORS.cyan : STUDIO_COLORS.red,
              boxShadow: `0 0 10px ${i % 2 === 0 ? STUDIO_COLORS.cyan : STUDIO_COLORS.red}`,
              animation: `pulse ${2 + i * 0.3}s ease-in-out infinite`,
            }}
          />
        ))}
      </div>

      {/* Header */}
      <header
        className="relative z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(13, 13, 13, 0.95)",
          borderColor: `${STUDIO_COLORS.cyan}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 sm:gap-4">
              <div className="flex items-center gap-2 sm:gap-3">
                <Radio className="w-5 h-5 sm:w-6 sm:h-6" style={{ color: STUDIO_COLORS.cyan }} />
                <div>
                  <h1
                    className="font-display text-lg sm:text-2xl uppercase tracking-wider"
                    style={{
                      color: STUDIO_COLORS.cyan,
                      textShadow: `0 0 20px ${STUDIO_COLORS.glow}`,
                    }}
                  >
                    33.3FM DOGECHAIN
                  </h1>
                  <p className="font-mono text-xs text-neutral-500 uppercase tracking-widest hidden sm:block">
                    Virtual Signal Studio
                  </p>
                </div>
              </div>
            </div>

            <div
              className="flex items-center gap-2 sm:gap-4 px-3 sm:px-4 py-2 rounded-full"
              style={{
                background: `${STUDIO_COLORS.cyan}10`,
                border: `1px solid ${STUDIO_COLORS.cyan}30`,
              }}
            >
              <div className="hidden sm:block">
                <p className="font-mono text-xs truncate max-w-[120px]" style={{ color: STUDIO_COLORS.cyan }}>
                  {currentTrack.title}
                </p>
                <p className="font-mono text-xs" style={{ color: STUDIO_COLORS.silver }}>
                  {currentTrack.frequency} FM
                </p>
              </div>
              <div className="flex items-center gap-1">
                <button
                  className="p-1.5 sm:p-2 hover:bg-white/10 rounded-full transition-colors"
                  aria-label="Previous track"
                >
                  <SkipBack className="w-3 h-3 sm:w-4 sm:h-4" style={{ color: STUDIO_COLORS.cyan }} />
                </button>
                <button
                  onClick={() => setAudioPlaying(!audioPlaying)}
                  className="p-2 sm:p-2.5 rounded-full transition-all"
                  style={{
                    background: STUDIO_COLORS.cyan,
                    boxShadow: audioPlaying ? `0 0 20px ${STUDIO_COLORS.glow}` : "none",
                  }}
                  aria-label={audioPlaying ? "Pause" : "Play"}
                >
                  {audioPlaying ? (
                    <Pause className="w-3 h-3 sm:w-4 sm:h-4 text-black" />
                  ) : (
                    <Play className="w-3 h-3 sm:w-4 sm:h-4 text-black ml-0.5" />
                  )}
                </button>
                <button
                  className="p-1.5 sm:p-2 hover:bg-white/10 rounded-full transition-colors"
                  aria-label="Next track"
                >
                  <SkipForward className="w-3 h-3 sm:w-4 sm:h-4" style={{ color: STUDIO_COLORS.cyan }} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 py-8 sm:py-16">
        {/* Floor Title */}
        <div className="text-center mb-12 sm:mb-16">
          <div
            className="inline-block px-4 py-2 rounded-full mb-4 sm:mb-6"
            style={{
              background: `${STUDIO_COLORS.cyan}15`,
              border: `1px solid ${STUDIO_COLORS.cyan}40`,
            }}
          >
            <span
              className="font-mono text-xs sm:text-sm uppercase tracking-[0.2em] sm:tracking-[0.3em]"
              style={{ color: STUDIO_COLORS.cyan }}
            >
              Floor 33.3 • Virtual Signal Studio
            </span>
          </div>
          <h2
            className="font-display text-4xl sm:text-5xl md:text-7xl uppercase mb-4 sm:mb-6"
            style={{
              color: STUDIO_COLORS.cyan,
              textShadow: `0 0 40px ${STUDIO_COLORS.glow}, 0 0 80px ${STUDIO_COLORS.glow}`,
            }}
          >
            33.3 FM
          </h2>
          <p className="font-mono text-sm sm:text-base px-4" style={{ color: STUDIO_COLORS.silver }}>
            Digital Art Museum • Audio Broadcast • IP Rights Management
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6 mb-12 sm:mb-16">
          {FLOOR_SECTIONS.map((section) => {
            const Icon = section.icon
            const isHovered = hoveredSection === section.id

            return (
              <button
                key={section.id}
                onClick={() => router.push(section.route)}
                onMouseEnter={() => setHoveredSection(section.id)}
                onMouseLeave={() => setHoveredSection(null)}
                className="group relative p-6 sm:p-8 rounded-2xl text-left transition-all duration-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-500"
                style={{
                  background: isHovered
                    ? `linear-gradient(135deg, ${STUDIO_COLORS.cyan}20, ${STUDIO_COLORS.black})`
                    : "rgba(13, 13, 13, 0.9)",
                  border: `2px solid ${isHovered ? STUDIO_COLORS.cyan : `${STUDIO_COLORS.cyan}20`}`,
                  boxShadow: isHovered
                    ? `0 0 40px ${STUDIO_COLORS.glow}, inset 0 0 40px ${STUDIO_COLORS.cyan}10`
                    : "none",
                  transform: isHovered ? "scale(1.02)" : "scale(1)",
                }}
              >
                {/* Corner Accents */}
                <div
                  className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 rounded-tl-2xl transition-opacity duration-300"
                  style={{
                    borderColor: STUDIO_COLORS.cyan,
                    opacity: isHovered ? 1 : 0,
                  }}
                />
                <div
                  className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 rounded-br-2xl transition-opacity duration-300"
                  style={{
                    borderColor: STUDIO_COLORS.red,
                    opacity: isHovered ? 1 : 0,
                  }}
                />

                <div
                  className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl flex items-center justify-center mb-4 sm:mb-6 transition-all duration-300"
                  style={{
                    background: `${STUDIO_COLORS.cyan}20`,
                    boxShadow: isHovered ? `0 0 30px ${STUDIO_COLORS.glow}` : "none",
                  }}
                >
                  <Icon className="w-6 h-6 sm:w-7 sm:h-7" style={{ color: STUDIO_COLORS.cyan }} />
                </div>

                <h3
                  className="font-display text-xl sm:text-2xl uppercase mb-1 sm:mb-2 transition-all duration-300"
                  style={{
                    color: isHovered ? STUDIO_COLORS.cyan : STUDIO_COLORS.silver,
                    textShadow: isHovered ? `0 0 20px ${STUDIO_COLORS.glow}` : "none",
                  }}
                >
                  {section.label}
                </h3>
                <p
                  className="font-mono text-xs sm:text-sm uppercase tracking-wider mb-3 sm:mb-4"
                  style={{ color: isHovered ? STUDIO_COLORS.red : STUDIO_COLORS.cyan }}
                >
                  {section.sublabel}
                </p>
                <p className="text-xs sm:text-sm" style={{ color: STUDIO_COLORS.silver }}>
                  {section.description}
                </p>
              </button>
            )
          })}
        </div>

        <div
          className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 p-4 sm:p-6 rounded-2xl"
          style={{
            background: "rgba(13, 13, 13, 0.8)",
            border: `1px solid ${STUDIO_COLORS.cyan}20`,
          }}
        >
          {[
            { icon: ImageIcon, label: "NFT Artworks", value: "2,847" },
            { icon: Headphones, label: "Audio Tracks", value: "1,203" },
            { icon: FileAudio, label: "Podcasts", value: "89" },
            { icon: Shield, label: "IP Records", value: "4,521" },
          ].map((stat, i) => {
            const Icon = stat.icon
            return (
              <div key={i} className="text-center p-3 sm:p-4">
                <Icon
                  className="w-5 h-5 sm:w-6 sm:h-6 mx-auto mb-2"
                  style={{ color: i % 2 === 0 ? STUDIO_COLORS.cyan : STUDIO_COLORS.red }}
                />
                <p
                  className="font-display text-xl sm:text-2xl mb-1"
                  style={{
                    color: STUDIO_COLORS.cyan,
                    textShadow: `0 0 10px ${STUDIO_COLORS.glow}`,
                  }}
                >
                  {stat.value}
                </p>
                <p className="font-mono text-xs uppercase tracking-wide" style={{ color: STUDIO_COLORS.silver }}>
                  {stat.label}
                </p>
              </div>
            )
          })}
        </div>
      </main>

      <ElevatorTravel currentFloor="33.3FM" onExitPatch={onExitPatch} />

      <style jsx>{`
        @keyframes pulse {
          0%,
          100% {
            opacity: 0.5;
          }
          50% {
            opacity: 1;
          }
        }
      `}</style>
    </div>
  )
}
