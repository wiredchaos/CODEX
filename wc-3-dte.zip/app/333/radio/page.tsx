"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  ArrowLeft,
  Radio,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  Mic,
  Headphones,
  Clock,
  TrendingUp,
} from "lucide-react"
import { Slider } from "@/components/ui/slider"

const STUDIO_COLORS = {
  primary: "#00BFFF",
  secondary: "#1E90FF",
  accent: "#00CED1",
  neon: "#00FFFF",
  dark: "#020812",
  glow: "rgba(0, 191, 255, 0.5)",
}

const TRACKS = [
  { id: 1, title: "NEURAL FREQUENCIES", artist: "WIRED COLLECTIVE", duration: "4:32", bpm: 120 },
  { id: 2, title: "CHAOS TRANSMISSIONS", artist: "SIGNAL DRIFT", duration: "5:18", bpm: 128 },
  { id: 3, title: "AKASHIC WAVES", artist: "DEEP CURRENT", duration: "6:45", bpm: 110 },
  { id: 4, title: "MOTHERBOARD PULSE", artist: "CIRCUIT ECHO", duration: "3:56", bpm: 135 },
  { id: 5, title: "589 RESONANCE", artist: "FREQUENCY MIND", duration: "7:22", bpm: 100 },
]

const PODCASTS = [
  { id: 1, title: "The Wired Mind", episode: "EP 047", duration: "1h 23m", host: "Dr. Neural" },
  { id: 2, title: "Chaos Theory Live", episode: "EP 102", duration: "58m", host: "Signal Ghost" },
  { id: 3, title: "Akashic Archives", episode: "EP 33", duration: "2h 05m", host: "The Keeper" },
]

export default function RadioPage() {
  const router = useRouter()
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTrack, setCurrentTrack] = useState(0)
  const [volume, setVolume] = useState([75])
  const [isMuted, setIsMuted] = useState(false)
  const [progress, setProgress] = useState(0)
  const [visualizerData, setVisualizerData] = useState<number[]>(Array(32).fill(0))

  // Simulate audio visualizer
  useEffect(() => {
    if (!isPlaying) return

    const interval = setInterval(() => {
      setVisualizerData(
        Array(32)
          .fill(0)
          .map(() => Math.random() * 100),
      )
      setProgress((prev) => (prev + 0.5) % 100)
    }, 100)

    return () => clearInterval(interval)
  }, [isPlaying])

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: STUDIO_COLORS.dark }}>
      {/* Grid Background */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${STUDIO_COLORS.primary}10 1px, transparent 1px),
            linear-gradient(to bottom, ${STUDIO_COLORS.primary}10 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Header */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(2, 8, 18, 0.95)",
          borderColor: `${STUDIO_COLORS.primary}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => router.push("/333")}
                className="flex items-center gap-2 transition-colors hover:opacity-80"
                style={{ color: STUDIO_COLORS.primary }}
              >
                <ArrowLeft className="w-5 h-5" />
                <span className="font-mono text-sm uppercase">33-3</span>
              </button>
              <div className="w-px h-6" style={{ background: `${STUDIO_COLORS.primary}30` }} />
              <div className="flex items-center gap-2">
                <Radio className="w-6 h-6" style={{ color: STUDIO_COLORS.neon }} />
                <h1
                  className="font-display text-xl sm:text-2xl uppercase tracking-wider"
                  style={{
                    color: STUDIO_COLORS.neon,
                    textShadow: `0 0 20px ${STUDIO_COLORS.glow}`,
                  }}
                >
                  33.3 FM
                </h1>
              </div>
            </div>

            <div
              className="flex items-center gap-2 px-3 py-1.5 rounded-full animate-pulse"
              style={{
                background: `${STUDIO_COLORS.neon}20`,
                border: `1px solid ${STUDIO_COLORS.neon}`,
              }}
            >
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              <span className="font-mono text-xs uppercase" style={{ color: STUDIO_COLORS.neon }}>
                LIVE
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        {/* Main Player */}
        <div
          className="rounded-3xl p-6 sm:p-8 mb-8 sm:mb-12"
          style={{
            background: "linear-gradient(135deg, rgba(0, 191, 255, 0.1), rgba(2, 8, 18, 0.9))",
            border: `2px solid ${STUDIO_COLORS.primary}30`,
            boxShadow: `0 0 60px ${STUDIO_COLORS.glow}`,
          }}
        >
          {/* Visualizer */}
          <div className="flex items-end justify-center gap-1 h-24 sm:h-32 mb-6 sm:mb-8">
            {visualizerData.map((height, i) => (
              <div
                key={i}
                className="w-1.5 sm:w-2 rounded-full transition-all duration-100"
                style={{
                  height: `${isPlaying ? height : 20}%`,
                  background: `linear-gradient(to top, ${STUDIO_COLORS.neon}, ${STUDIO_COLORS.primary})`,
                  boxShadow: isPlaying ? `0 0 10px ${STUDIO_COLORS.glow}` : "none",
                }}
              />
            ))}
          </div>

          {/* Track Info */}
          <div className="text-center mb-6 sm:mb-8">
            <h2
              className="font-display text-2xl sm:text-4xl uppercase mb-2"
              style={{
                color: STUDIO_COLORS.neon,
                textShadow: `0 0 20px ${STUDIO_COLORS.glow}`,
              }}
            >
              {TRACKS[currentTrack].title}
            </h2>
            <p className="font-mono text-sm sm:text-base text-neutral-400 uppercase tracking-widest">
              {TRACKS[currentTrack].artist}
            </p>
          </div>

          {/* Progress Bar */}
          <div className="mb-6 sm:mb-8">
            <div className="h-1.5 rounded-full overflow-hidden" style={{ background: `${STUDIO_COLORS.primary}20` }}>
              <div
                className="h-full rounded-full transition-all duration-100"
                style={{
                  width: `${progress}%`,
                  background: `linear-gradient(to right, ${STUDIO_COLORS.neon}, ${STUDIO_COLORS.primary})`,
                  boxShadow: `0 0 10px ${STUDIO_COLORS.glow}`,
                }}
              />
            </div>
            <div className="flex justify-between mt-2 font-mono text-xs text-neutral-500">
              <span>
                {Math.floor(progress * 0.0432)}:{String(Math.floor((progress * 2.6) % 60)).padStart(2, "0")}
              </span>
              <span>{TRACKS[currentTrack].duration}</span>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-4 sm:gap-6 mb-6 sm:mb-8">
            <button
              onClick={() => setCurrentTrack((prev) => (prev - 1 + TRACKS.length) % TRACKS.length)}
              className="p-3 rounded-full hover:bg-white/10 transition-colors"
              aria-label="Previous track"
            >
              <SkipBack className="w-6 h-6 sm:w-8 sm:h-8" style={{ color: STUDIO_COLORS.primary }} />
            </button>
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="p-4 sm:p-6 rounded-full transition-all"
              style={{
                background: STUDIO_COLORS.neon,
                boxShadow: isPlaying ? `0 0 40px ${STUDIO_COLORS.glow}` : `0 0 20px ${STUDIO_COLORS.glow}`,
              }}
              aria-label={isPlaying ? "Pause" : "Play"}
            >
              {isPlaying ? (
                <Pause className="w-6 h-6 sm:w-8 sm:h-8 text-black" />
              ) : (
                <Play className="w-6 h-6 sm:w-8 sm:h-8 text-black ml-1" />
              )}
            </button>
            <button
              onClick={() => setCurrentTrack((prev) => (prev + 1) % TRACKS.length)}
              className="p-3 rounded-full hover:bg-white/10 transition-colors"
              aria-label="Next track"
            >
              <SkipForward className="w-6 h-6 sm:w-8 sm:h-8" style={{ color: STUDIO_COLORS.primary }} />
            </button>
          </div>

          {/* Volume */}
          <div className="flex items-center justify-center gap-4 max-w-xs mx-auto">
            <button onClick={() => setIsMuted(!isMuted)} className="p-2" aria-label={isMuted ? "Unmute" : "Mute"}>
              {isMuted ? (
                <VolumeX className="w-5 h-5" style={{ color: STUDIO_COLORS.primary }} />
              ) : (
                <Volume2 className="w-5 h-5" style={{ color: STUDIO_COLORS.primary }} />
              )}
            </button>
            <Slider value={isMuted ? [0] : volume} onValueChange={setVolume} max={100} step={1} className="flex-1" />
          </div>
        </div>

        {/* Playlist & Podcasts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8">
          {/* Tracks */}
          <div>
            <h3 className="font-mono text-sm uppercase tracking-widest mb-4" style={{ color: STUDIO_COLORS.primary }}>
              <TrendingUp className="w-4 h-4 inline mr-2" />
              Trending Tracks
            </h3>
            <div className="space-y-2">
              {TRACKS.map((track, i) => (
                <button
                  key={track.id}
                  onClick={() => {
                    setCurrentTrack(i)
                    setIsPlaying(true)
                  }}
                  className={`w-full flex items-center gap-4 p-4 rounded-xl transition-all text-left ${
                    currentTrack === i ? "bg-white/10" : "hover:bg-white/5"
                  }`}
                  style={{
                    border: currentTrack === i ? `1px solid ${STUDIO_COLORS.neon}` : "1px solid transparent",
                  }}
                >
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ background: `${STUDIO_COLORS.primary}20` }}
                  >
                    {currentTrack === i && isPlaying ? (
                      <div className="flex items-end gap-0.5 h-4">
                        {[1, 2, 3].map((j) => (
                          <div
                            key={j}
                            className="w-1 rounded-full animate-pulse"
                            style={{
                              height: `${50 + Math.random() * 50}%`,
                              background: STUDIO_COLORS.neon,
                              animationDelay: `${j * 0.1}s`,
                            }}
                          />
                        ))}
                      </div>
                    ) : (
                      <Headphones className="w-5 h-5" style={{ color: STUDIO_COLORS.primary }} />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p
                      className="font-mono text-sm uppercase truncate"
                      style={{ color: currentTrack === i ? STUDIO_COLORS.neon : "#fff" }}
                    >
                      {track.title}
                    </p>
                    <p className="text-xs text-neutral-500 truncate">{track.artist}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="font-mono text-xs text-neutral-400">{track.duration}</p>
                    <p className="font-mono text-xs text-neutral-600">{track.bpm} BPM</p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Podcasts */}
          <div>
            <h3 className="font-mono text-sm uppercase tracking-widest mb-4" style={{ color: STUDIO_COLORS.primary }}>
              <Mic className="w-4 h-4 inline mr-2" />
              Podcasts
            </h3>
            <div className="space-y-2">
              {PODCASTS.map((podcast) => (
                <div
                  key={podcast.id}
                  className="flex items-center gap-4 p-4 rounded-xl hover:bg-white/5 transition-all cursor-pointer"
                  style={{ border: `1px solid ${STUDIO_COLORS.primary}20` }}
                >
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{
                      background: `linear-gradient(135deg, ${STUDIO_COLORS.primary}30, ${STUDIO_COLORS.neon}10)`,
                    }}
                  >
                    <Mic className="w-6 h-6" style={{ color: STUDIO_COLORS.neon }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-mono text-sm uppercase text-white truncate">{podcast.title}</p>
                    <p className="text-xs text-neutral-500">
                      {podcast.episode} • {podcast.host}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 text-neutral-500 flex-shrink-0">
                    <Clock className="w-3 h-3" />
                    <span className="text-xs">{podcast.duration}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
