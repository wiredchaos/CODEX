"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  Users,
  Calendar,
  FileText,
  Link2,
  MessageSquare,
  Plus,
  Search,
  Clock,
  Video,
  Download,
  Eye,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

const BOARD_MEMBERS = [
  { id: 1, name: "Alexandra Chen", role: "Chairperson", type: "member", avatar: "/professional-woman-executive.png" },
  { id: 2, name: "Marcus Williams", role: "Vice Chair", type: "member", avatar: "/professional-man-suit.png" },
  { id: 3, name: "Dr. Sarah Okonkwo", role: "Secretary", type: "member", avatar: "/professional-woman-doctor.png" },
  { id: 4, name: "James Rodriguez", role: "Treasurer", type: "member", avatar: "/professional-man-finance.png" },
  { id: 5, name: "Emily Watson", role: "Legal Counsel", type: "observer", avatar: "/professional-woman-lawyer.png" },
  { id: 6, name: "David Kim", role: "Advisor", type: "observer", avatar: "/professional-man-advisor.jpg" },
]

const MEETINGS = [
  { id: 1, title: "Q4 Strategy Review", date: "2025-01-15", time: "10:00 AM", status: "upcoming", type: "quarterly" },
  { id: 2, title: "Budget Approval Meeting", date: "2025-01-08", time: "2:00 PM", status: "upcoming", type: "special" },
  { id: 3, title: "Annual General Meeting", date: "2024-12-20", time: "9:00 AM", status: "completed", type: "annual" },
  {
    id: 4,
    title: "Q3 Performance Review",
    date: "2024-10-15",
    time: "10:00 AM",
    status: "completed",
    type: "quarterly",
  },
]

const DOCUMENTS = [
  { id: 1, name: "Bylaws v2.3", type: "governance", updated: "2024-12-01", size: "2.4 MB" },
  { id: 2, name: "2024 Annual Report", type: "report", updated: "2024-12-15", size: "8.1 MB" },
  { id: 3, name: "Board Resolution #47", type: "resolution", updated: "2024-11-20", size: "156 KB" },
  { id: 4, name: "Investment Policy", type: "policy", updated: "2024-09-10", size: "1.2 MB" },
  { id: 5, name: "Conflict of Interest Disclosure", type: "compliance", updated: "2024-08-05", size: "340 KB" },
]

const MINUTES = [
  { id: 1, meeting: "Annual General Meeting", date: "2024-12-20", status: "approved" },
  { id: 2, meeting: "Q3 Performance Review", date: "2024-10-15", status: "approved" },
  { id: 3, meeting: "Special Session - M&A", date: "2024-09-28", status: "draft" },
]

export default function BoardPortalPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("directory")

  const members = BOARD_MEMBERS.filter((m) => m.type === "member")
  const observers = BOARD_MEMBERS.filter((m) => m.type === "observer")

  return (
    <div className="min-h-screen bg-[#050509] text-white">
      {/* Grid Background */}
      <div
        className="fixed inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, #A855F710 1px, transparent 1px),
            linear-gradient(to bottom, #A855F710 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Header */}
      <header className="relative z-10 border-b border-purple-500/20 bg-[#050509]/90 backdrop-blur-xl">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/neura">
              <Button variant="ghost" size="icon" className="text-purple-400 hover:text-white">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-purple-500/20 border border-purple-500/30 flex items-center justify-center">
                <Users className="w-5 h-5 text-purple-400" />
              </div>
              <div>
                <h1 className="font-display text-xl tracking-wider text-purple-400">NEURA BOARD</h1>
                <p className="text-[10px] text-zinc-500 font-mono uppercase tracking-widest">
                  Board of Directors Portal
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
              <Input
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-zinc-900/50 border-purple-500/20 w-64"
              />
            </div>
            <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
              <MessageSquare className="w-4 h-4 mr-2" />
              AI Assistant
            </Button>
          </div>
        </div>
      </header>

      <main className="relative z-10 container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-zinc-900/50 border border-purple-500/20">
            <TabsTrigger value="directory" className="data-[state=active]:bg-purple-600">
              <Users className="w-4 h-4 mr-2" />
              Directory
            </TabsTrigger>
            <TabsTrigger value="meetings" className="data-[state=active]:bg-purple-600">
              <Calendar className="w-4 h-4 mr-2" />
              Meetings
            </TabsTrigger>
            <TabsTrigger value="minutes" className="data-[state=active]:bg-purple-600">
              <FileText className="w-4 h-4 mr-2" />
              Minutes
            </TabsTrigger>
            <TabsTrigger value="documents" className="data-[state=active]:bg-purple-600">
              <Link2 className="w-4 h-4 mr-2" />
              Documents
            </TabsTrigger>
          </TabsList>

          {/* Directory Tab */}
          <TabsContent value="directory" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-display text-purple-400">Board Members</h2>
              <Button size="sm" variant="outline" className="border-purple-500/30 bg-transparent">
                <Plus className="w-4 h-4 mr-2" />
                Add Member
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {members.map((member) => (
                <div
                  key={member.id}
                  className="p-4 rounded-xl bg-zinc-900/50 border border-purple-500/20 hover:border-purple-500/40 transition-all"
                >
                  <div className="flex items-center gap-4">
                    <Avatar className="w-12 h-12 border-2 border-purple-500/30">
                      <AvatarImage src={member.avatar || "/placeholder.svg"} />
                      <AvatarFallback className="bg-purple-600">
                        {member.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-semibold text-white">{member.name}</h3>
                      <p className="text-sm text-purple-400">{member.role}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <h2 className="text-2xl font-display text-zinc-400 mt-8">Observers</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {observers.map((observer) => (
                <div
                  key={observer.id}
                  className="p-4 rounded-xl bg-zinc-900/30 border border-zinc-700/50 hover:border-zinc-600 transition-all"
                >
                  <div className="flex items-center gap-4">
                    <Avatar className="w-12 h-12 border-2 border-zinc-600">
                      <AvatarImage src={observer.avatar || "/placeholder.svg"} />
                      <AvatarFallback className="bg-zinc-700">
                        {observer.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-semibold text-zinc-300">{observer.name}</h3>
                      <p className="text-sm text-zinc-500">{observer.role}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          {/* Meetings Tab */}
          <TabsContent value="meetings" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-display text-purple-400">Meeting Calendar</h2>
              <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
                <Plus className="w-4 h-4 mr-2" />
                Schedule Meeting
              </Button>
            </div>

            <div className="space-y-4">
              {MEETINGS.map((meeting) => (
                <div
                  key={meeting.id}
                  className={`p-4 rounded-xl border transition-all ${
                    meeting.status === "upcoming"
                      ? "bg-purple-900/20 border-purple-500/30"
                      : "bg-zinc-900/30 border-zinc-700/50"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div
                        className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                          meeting.status === "upcoming" ? "bg-purple-600/20" : "bg-zinc-800"
                        }`}
                      >
                        <Calendar
                          className={`w-6 h-6 ${meeting.status === "upcoming" ? "text-purple-400" : "text-zinc-500"}`}
                        />
                      </div>
                      <div>
                        <h3 className="font-semibold text-white">{meeting.title}</h3>
                        <div className="flex items-center gap-3 text-sm text-zinc-400">
                          <span>{meeting.date}</span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {meeting.time}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge variant={meeting.status === "upcoming" ? "default" : "secondary"}>{meeting.status}</Badge>
                      <Badge variant="outline" className="capitalize">
                        {meeting.type}
                      </Badge>
                      {meeting.status === "upcoming" && (
                        <Button size="sm" variant="ghost" className="text-purple-400">
                          <Video className="w-4 h-4 mr-2" />
                          Join
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          {/* Minutes Tab */}
          <TabsContent value="minutes" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-display text-purple-400">Meeting Minutes</h2>
              <Button size="sm" variant="outline" className="border-purple-500/30 bg-transparent">
                <Plus className="w-4 h-4 mr-2" />
                New Minutes
              </Button>
            </div>

            <div className="space-y-4">
              {MINUTES.map((minute) => (
                <div
                  key={minute.id}
                  className="p-4 rounded-xl bg-zinc-900/50 border border-purple-500/20 hover:border-purple-500/40 transition-all"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-lg bg-purple-600/20 flex items-center justify-center">
                        <FileText className="w-6 h-6 text-purple-400" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-white">{minute.meeting}</h3>
                        <p className="text-sm text-zinc-400">{minute.date}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge variant={minute.status === "approved" ? "default" : "secondary"}>{minute.status}</Badge>
                      <Button size="sm" variant="ghost">
                        <Eye className="w-4 h-4 mr-2" />
                        View
                      </Button>
                      <Button size="sm" variant="ghost">
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          {/* Documents Tab */}
          <TabsContent value="documents" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-display text-purple-400">Document Library</h2>
              <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
                <Plus className="w-4 h-4 mr-2" />
                Upload Document
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {DOCUMENTS.map((doc) => (
                <div
                  key={doc.id}
                  className="p-4 rounded-xl bg-zinc-900/50 border border-purple-500/20 hover:border-purple-500/40 transition-all cursor-pointer"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-lg bg-purple-600/20 flex items-center justify-center mt-1">
                        <FileText className="w-5 h-5 text-purple-400" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-white">{doc.name}</h3>
                        <div className="flex items-center gap-3 text-sm text-zinc-400 mt-1">
                          <Badge variant="outline" className="capitalize text-xs">
                            {doc.type}
                          </Badge>
                          <span>{doc.size}</span>
                        </div>
                        <p className="text-xs text-zinc-500 mt-2">Updated {doc.updated}</p>
                      </div>
                    </div>
                    <Button size="sm" variant="ghost">
                      <Download className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
