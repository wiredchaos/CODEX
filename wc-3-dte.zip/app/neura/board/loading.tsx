export default function Loading() {
  return (
    <div className="min-h-screen bg-[#050509] flex items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <div className="w-12 h-12 rounded-full border-2 border-purple-500 border-t-transparent animate-spin" />
        <p className="text-purple-400 font-mono text-sm">Loading Board Portal...</p>
      </div>
    </div>
  )
}
