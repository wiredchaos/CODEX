"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowRight, Shield, Building2, Wallet, Globe, FileText, ChevronRight, Sparkles, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { LiveCircuitry } from "@/components/live-circuitry"

const NEURA_MODULES = [
  {
    id: "tax",
    name: "NEURA TAX",
    description: "Intelligent tax optimization and IRS schedule mapping",
    icon: FileText,
    color: "#00F0FF",
    status: "active",
    href: "/neura/tax",
  },
  {
    id: "entity",
    name: "NEURA ENTITY",
    description: "Business structure planning and entity optimization",
    icon: Building2,
    color: "#E0B05A",
    status: "active",
    href: "/neura/entity",
  },
  {
    id: "board",
    name: "NEURA BOARD",
    description: "Board of Directors portal with meetings, minutes, and document management",
    icon: Users,
    color: "#A855F7",
    status: "active",
    href: "/neura/board",
  },
  {
    id: "trust",
    name: "NEURA TRUST",
    description: "Multi-generational wealth and trust architecture",
    icon: Shield,
    color: "#00F0FF",
    status: "coming",
    href: "/neura/trust",
  },
  {
    id: "ledger",
    name: "NEURA LEDGER",
    description: "Unified Crypto Ledger with full DeFi tracking",
    icon: Wallet,
    color: "#FFC857",
    status: "active",
    href: "/neura/ledger",
  },
  {
    id: "global",
    name: "NEURA GLOBAL",
    description: "Cross-border compliance and digital nomad support",
    icon: Globe,
    color: "#00F0FF",
    status: "coming",
    href: "/neura/global",
  },
]

export default function NeuraPage() {
  const [hoveredModule, setHoveredModule] = useState<string | null>(null)

  return (
    <div className="min-h-screen bg-[#050509] text-white relative overflow-hidden">
      <LiveCircuitry />

      {/* Grid Background */}
      <div
        className="fixed inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, #00F0FF10 1px, transparent 1px),
            linear-gradient(to bottom, #00F0FF10 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Header */}
      <header className="relative z-10 border-b border-[#00F0FF]/20 bg-[#050509]/90 backdrop-blur-xl">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-lg flex items-center justify-center"
              style={{ background: "linear-gradient(135deg, #00F0FF, #00C4CC)" }}
            >
              <Sparkles className="w-5 h-5 text-[#050509]" />
            </div>
            <div>
              <h1 className="font-display text-xl tracking-wider" style={{ color: "#00F0FF" }}>
                NEURA
              </h1>
              <p className="text-[10px] text-[#A0A4B8] font-mono uppercase tracking-widest">
                Intelligent Legacy Architecture
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-[#A0A4B8] hover:text-white">
                Back to Lobby
              </Button>
            </Link>
            <Link href="/neura/onboarding">
              <Button size="sm" className="neura-btn-primary">
                Begin Setup
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="relative z-10 container mx-auto px-4 py-16">
        {/* Hero */}
        <div className="text-center mb-16">
          <h2
            className="font-display text-5xl sm:text-7xl uppercase mb-4"
            style={{
              color: "#00F0FF",
              textShadow: "0 0 40px rgba(0, 240, 255, 0.5)",
            }}
          >
            INTELLIGENT
            <br />
            LEGACY ARCHITECTURE
          </h2>
          <p className="text-[#A0A4B8] max-w-2xl mx-auto text-lg">
            A unified system blending tax intelligence, entity structuring, trust design, crypto compliance, and
            multi-generational wealth engineering.
          </p>
        </div>

        {/* Modules Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {NEURA_MODULES.map((module) => {
            const Icon = module.icon
            const isHovered = hoveredModule === module.id

            return (
              <div
                key={module.id}
                className="neura-card p-6 transition-all duration-300 cursor-pointer"
                style={{
                  borderColor: isHovered ? module.color : "rgba(0, 240, 255, 0.1)",
                  boxShadow: isHovered ? `0 0 30px ${module.color}30` : "none",
                  transform: isHovered ? "translateY(-4px)" : "translateY(0)",
                }}
                onMouseEnter={() => setHoveredModule(module.id)}
                onMouseLeave={() => setHoveredModule(null)}
              >
                <div className="flex items-start justify-between mb-4">
                  <div
                    className="w-12 h-12 rounded-lg flex items-center justify-center"
                    style={{
                      background: `${module.color}15`,
                      border: `1px solid ${module.color}30`,
                    }}
                  >
                    <Icon className="w-6 h-6" style={{ color: module.color }} />
                  </div>
                  {module.status === "coming" && (
                    <span className="text-[10px] font-mono uppercase px-2 py-1 rounded bg-[#FFC857]/10 text-[#FFC857]">
                      Coming Soon
                    </span>
                  )}
                </div>

                <h3 className="font-display text-xl uppercase mb-2" style={{ color: module.color }}>
                  {module.name}
                </h3>
                <p className="text-sm text-[#A0A4B8]">{module.description}</p>

                <div className="mt-4 flex items-center gap-2 text-sm" style={{ color: module.color }}>
                  <span className="font-mono">Explore</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>
            )
          })}
        </div>

        {/* CTA */}
        <div
          className="text-center p-8 rounded-2xl"
          style={{
            background: "linear-gradient(135deg, rgba(0, 240, 255, 0.1), transparent)",
            border: "1px solid rgba(0, 240, 255, 0.2)",
          }}
        >
          <h3 className="font-display text-2xl uppercase mb-4" style={{ color: "#00F0FF" }}>
            Ready to Begin?
          </h3>
          <p className="text-[#A0A4B8] mb-6 max-w-xl mx-auto">
            Complete your NEURA profile and generate a tax-ready summary with our 6-step onboarding process.
          </p>
          <Link href="/neura/onboarding">
            <Button className="neura-btn-primary px-8 py-3 text-lg">
              Start Onboarding
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-[#00F0FF]/10 py-6">
        <div className="container mx-auto px-4 text-center">
          <p className="text-xs text-[#A0A4B8] font-mono">
            NEURA — Intelligent Legacy Architecture™ | Part of WIRED CHAOS META
          </p>
        </div>
      </footer>
    </div>
  )
}
