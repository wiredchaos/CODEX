import { NextResponse } from "next/server"
import { sql } from "@/lib/db/neon"
import { createJob, runJob } from "@/lib/agentic/orchestrator"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { sourceId, mode = "quick", include, exclude } = body

    if (!sourceId) {
      return NextResponse.json({ error: "sourceId is required" }, { status: 400 })
    }

    // Get source details
    const sources = await sql`
      SELECT * FROM forensic_sources WHERE id = ${sourceId}::uuid
    `

    if (sources.length === 0) {
      return NextResponse.json({ error: "Source not found" }, { status: 404 })
    }

    const source = sources[0]

    // Create forensic run record
    const runResult = await sql`
      INSERT INTO forensic_runs (source_id, mode, status)
      VALUES (${sourceId}::uuid, ${mode}, 'queued')
      RETURNING id
    `
    const runId = runResult[0].id

    // Create agentic job
    const jobId = await createJob("SEEKER_FORENSICS_SCAN", {
      sourceId,
      runId,
      repoUrl: source.repo_url,
      branch: source.branch,
      include: include || ["md", "ts", "tsx", "json"],
      exclude: exclude || ["node_modules", "dist", ".next"],
    })

    // Update run with job reference
    await sql`
      UPDATE forensic_runs SET status = 'running', started_at = NOW()
      WHERE id = ${runId}::uuid
    `

    // Run job asynchronously
    runJob(jobId).then(async () => {
      // Get job result and update run
      const jobs = await sql`
        SELECT result_json, status FROM agentic_jobs WHERE id = ${jobId}::uuid
      `

      if (jobs[0].status === "succeeded" && jobs[0].result_json) {
        const result = JSON.parse(jobs[0].result_json)
        const findings = result.step_5_result || {}

        await sql`
          UPDATE forensic_runs 
          SET status = 'ready', 
              finished_at = NOW(),
              findings_json = ${JSON.stringify(findings)}
          WHERE id = ${runId}::uuid
        `
      } else {
        await sql`
          UPDATE forensic_runs SET status = 'error', finished_at = NOW()
          WHERE id = ${runId}::uuid
        `
      }
    })

    return NextResponse.json({ runId, jobId, status: "running" })
  } catch (error) {
    console.error("[v0] Error starting scan:", error)
    return NextResponse.json({ error: "Failed to start scan" }, { status: 500 })
  }
}
