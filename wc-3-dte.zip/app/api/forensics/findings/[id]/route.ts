import { NextResponse } from "next/server"
import { sql } from "@/lib/db/neon"

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params

    const runs = await sql`
      SELECT findings_json, files_indexed, chunks_indexed, status
      FROM forensic_runs WHERE id = ${id}::uuid
    `

    if (runs.length === 0) {
      return NextResponse.json({ error: "Run not found" }, { status: 404 })
    }

    const run = runs[0]

    if (!run.findings_json) {
      return NextResponse.json({
        status: run.status,
        findings: null,
        message: "Findings not yet available",
      })
    }

    return NextResponse.json({
      status: run.status,
      filesIndexed: run.files_indexed,
      chunksIndexed: run.chunks_indexed,
      findings: JSON.parse(run.findings_json),
    })
  } catch (error) {
    console.error("[v0] Error fetching findings:", error)
    return NextResponse.json({ error: "Failed to fetch findings" }, { status: 500 })
  }
}
