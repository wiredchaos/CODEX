import { NextResponse } from "next/server"
import { sql } from "@/lib/db/neon"

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params

    const runs = await sql`
      SELECT fr.*, fs.name as source_name, fs.repo_url
      FROM forensic_runs fr
      JOIN forensic_sources fs ON fr.source_id = fs.id
      WHERE fr.id = ${id}::uuid
    `

    if (runs.length === 0) {
      return NextResponse.json({ error: "Run not found" }, { status: 404 })
    }

    const run = runs[0]

    return NextResponse.json({
      id: run.id,
      sourceId: run.source_id,
      sourceName: run.source_name,
      repoUrl: run.repo_url,
      mode: run.mode,
      status: run.status,
      startedAt: run.started_at,
      finishedAt: run.finished_at,
      filesIndexed: run.files_indexed,
      chunksIndexed: run.chunks_indexed,
      findings: run.findings_json ? JSON.parse(run.findings_json) : null,
    })
  } catch (error) {
    console.error("[v0] Error fetching run status:", error)
    return NextResponse.json({ error: "Failed to fetch status" }, { status: 500 })
  }
}
