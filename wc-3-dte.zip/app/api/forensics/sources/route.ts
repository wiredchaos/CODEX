import { NextResponse } from "next/server"
import { sql } from "@/lib/db/neon"

export async function GET() {
  try {
    const sources = await sql`
      SELECT * FROM forensic_sources ORDER BY created_at DESC
    `
    return NextResponse.json({ sources })
  } catch (error) {
    console.error("[v0] Error fetching sources:", error)
    return NextResponse.json({ error: "Failed to fetch sources" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { name, repoUrl, branch } = body

    if (!name || !repoUrl) {
      return NextResponse.json({ error: "Name and repoUrl are required" }, { status: 400 })
    }

    const result = await sql`
      INSERT INTO forensic_sources (type, name, repo_url, branch)
      VALUES ('github', ${name}, ${repoUrl}, ${branch || "main"})
      RETURNING *
    `

    return NextResponse.json({ source: result[0] })
  } catch (error) {
    console.error("[v0] Error creating source:", error)
    return NextResponse.json({ error: "Failed to create source" }, { status: 500 })
  }
}
