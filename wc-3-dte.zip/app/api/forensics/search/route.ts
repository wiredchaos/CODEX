import { NextResponse } from "next/server"
import { sql } from "@/lib/db/neon"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { q, filters = {}, limit = 20 } = body

    if (!q) {
      return NextResponse.json({ error: "Query is required" }, { status: 400 })
    }

    let results

    if (filters.repo) {
      results = await sql`
        SELECT fc.text, fc.idx, fd.path, fd.ext, fs.name as source_name
        FROM forensic_chunks fc
        JOIN forensic_docs fd ON fc.doc_id = fd.id
        JOIN forensic_sources fs ON fd.source_id = fs.id
        WHERE to_tsvector('english', fc.text) @@ plainto_tsquery('english', ${q})
          AND fs.repo_url ILIKE ${`%${filters.repo}%`}
        ORDER BY ts_rank(to_tsvector('english', fc.text), plainto_tsquery('english', ${q})) DESC
        LIMIT ${limit}
      `
    } else {
      results = await sql`
        SELECT fc.text, fc.idx, fd.path, fd.ext, fs.name as source_name
        FROM forensic_chunks fc
        JOIN forensic_docs fd ON fc.doc_id = fd.id
        JOIN forensic_sources fs ON fd.source_id = fs.id
        WHERE to_tsvector('english', fc.text) @@ plainto_tsquery('english', ${q})
        ORDER BY ts_rank(to_tsvector('english', fc.text), plainto_tsquery('english', ${q})) DESC
        LIMIT ${limit}
      `
    }

    return NextResponse.json({
      query: q,
      results: results.map((r) => ({
        text: r.text,
        path: r.path,
        ext: r.ext,
        source: r.source_name,
        chunkIndex: r.idx,
      })),
      total: results.length,
    })
  } catch (error) {
    console.error("[v0] Error searching:", error)
    return NextResponse.json({ error: "Search failed" }, { status: 500 })
  }
}
