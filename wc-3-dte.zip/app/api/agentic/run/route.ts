import { NextResponse } from "next/server"
import { createJob, runJob, type AgenticJobKind } from "@/lib/agentic/orchestrator"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { kind, input } = body

    const validKinds: AgenticJobKind[] = [
      "SEEKER_FORENSICS_SCAN",
      "SEEKER_PATCH_RECONSTRUCT",
      "SEEKER_MISSING_DOCS_REPORT",
      "SEEKER_UPGRADE_PLAN",
    ]

    if (!validKinds.includes(kind)) {
      return NextResponse.json({ error: `Invalid job kind. Must be one of: ${validKinds.join(", ")}` }, { status: 400 })
    }

    const jobId = await createJob(kind, input || {})

    // Run job asynchronously
    runJob(jobId)

    return NextResponse.json({
      jobId,
      status: "queued",
      message: "Job created and queued for execution",
    })
  } catch (error) {
    console.error("[v0] Error creating job:", error)
    return NextResponse.json({ error: "Failed to create job" }, { status: 500 })
  }
}
