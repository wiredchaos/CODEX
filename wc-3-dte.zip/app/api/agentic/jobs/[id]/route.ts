import { NextResponse } from "next/server"
import { sql } from "@/lib/db/neon"

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params

    const jobs = await sql`
      SELECT * FROM agentic_jobs WHERE id = ${id}::uuid
    `

    if (jobs.length === 0) {
      return NextResponse.json({ error: "Job not found" }, { status: 404 })
    }

    const job = jobs[0]

    const events = await sql`
      SELECT * FROM agentic_job_events 
      WHERE job_id = ${id}::uuid 
      ORDER BY ts ASC
    `

    return NextResponse.json({
      id: job.id,
      kind: job.kind,
      status: job.status,
      input: job.input_json ? JSON.parse(job.input_json) : null,
      plan: job.plan_json ? JSON.parse(job.plan_json) : null,
      result: job.result_json ? JSON.parse(job.result_json) : null,
      error: job.error,
      createdAt: job.created_at,
      startedAt: job.started_at,
      finishedAt: job.finished_at,
      events: events.map((e) => ({
        id: e.id,
        timestamp: e.ts,
        level: e.level,
        message: e.message,
        payload: e.payload_json ? JSON.parse(e.payload_json) : null,
      })),
    })
  } catch (error) {
    console.error("[v0] Error fetching job:", error)
    return NextResponse.json({ error: "Failed to fetch job" }, { status: 500 })
  }
}
