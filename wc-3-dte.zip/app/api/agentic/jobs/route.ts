import { NextResponse } from "next/server"
import { sql } from "@/lib/db/neon"

export async function GET() {
  try {
    const jobs = await sql`
      SELECT id, kind, status, created_at, started_at, finished_at, error
      FROM agentic_jobs
      ORDER BY created_at DESC
      LIMIT 50
    `

    return NextResponse.json({ jobs })
  } catch (error) {
    console.error("[v0] Error fetching jobs:", error)
    return NextResponse.json({ error: "Failed to fetch jobs" }, { status: 500 })
  }
}
