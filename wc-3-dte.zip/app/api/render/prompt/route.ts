import { type NextRequest, NextResponse } from "next/server"
import {
  getPrompt,
  getAllPrompts,
  searchPrompts,
  getPromptsByTag,
  getPromptsByRealm,
  getPromptIds,
  PALETTE,
  RENDER_CONFIG,
  type PromptTag,
  type RenderPrompt,
} from "@/lib/render/prompt-registry"

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)

  const id = searchParams.get("id")
  const tag = searchParams.get("tag") as PromptTag | null
  const realm = searchParams.get("realm") as RenderPrompt["realm"] | null
  const search = searchParams.get("search")
  const listIds = searchParams.get("list") === "true"
  const includePalette = searchParams.get("palette") === "true"

  try {
    // List all prompt IDs
    if (listIds) {
      return NextResponse.json({
        success: true,
        ids: getPromptIds(),
        count: getPromptIds().length,
      })
    }

    // Get specific prompt by ID
    if (id) {
      const prompt = getPrompt(id)
      if (!prompt) {
        return NextResponse.json({ success: false, error: `Prompt "${id}" not found` }, { status: 404 })
      }
      return NextResponse.json({
        success: true,
        prompt,
        ...(includePalette && { palette: PALETTE }),
      })
    }

    // Search prompts by query
    if (search) {
      const results = searchPrompts(search)
      return NextResponse.json({
        success: true,
        prompts: results,
        count: results.length,
        query: search,
      })
    }

    // Filter by tag
    if (tag) {
      const results = getPromptsByTag(tag)
      return NextResponse.json({
        success: true,
        prompts: results,
        count: results.length,
        tag,
      })
    }

    // Filter by realm
    if (realm) {
      const results = getPromptsByRealm(realm)
      return NextResponse.json({
        success: true,
        prompts: results,
        count: results.length,
        realm,
      })
    }

    // Return all prompts with config
    const allPrompts = getAllPrompts()
    return NextResponse.json({
      success: true,
      prompts: allPrompts,
      count: allPrompts.length,
      config: RENDER_CONFIG,
      ...(includePalette && { palette: PALETTE }),
    })
  } catch (error) {
    console.error("[Render API Error]:", error)
    return NextResponse.json({ success: false, error: "Internal server error" }, { status: 500 })
  }
}

// POST for batch prompt retrieval
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { ids } = body as { ids?: string[] }

    if (!ids || !Array.isArray(ids)) {
      return NextResponse.json({ success: false, error: 'Request body must include "ids" array' }, { status: 400 })
    }

    const prompts: Record<string, RenderPrompt | null> = {}
    const missing: string[] = []

    for (const id of ids) {
      const prompt = getPrompt(id)
      if (prompt) {
        prompts[id] = prompt
      } else {
        prompts[id] = null
        missing.push(id)
      }
    }

    return NextResponse.json({
      success: true,
      prompts,
      found: ids.length - missing.length,
      missing: missing.length > 0 ? missing : undefined,
    })
  } catch (error) {
    console.error("[Render API POST Error]:", error)
    return NextResponse.json({ success: false, error: "Invalid request body" }, { status: 400 })
  }
}
