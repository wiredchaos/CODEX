import { generateText } from "ai"

export const runtime = "edge"

export async function POST(req: Request) {
  try {
    const { messages, realm } = await req.json()

    const systemPrompt = `You are NEURO META X, the AI navigation assistant for WIRED CHAOS META OS. 
You help users understand the dual realm architecture (Neuralis/Business and Chaosphere/Akashic), 
the 12-age Master Timeline, Six Pillars factions, and Neteru Apinaya Patches.

Current active realm: ${realm || "default"}

Provide concise, technical responses in a cryptic yet helpful style. Reference the 589Hz frequency, 
Gas Sigil system, and maintain the strict Business/Akashic firewall separation in your explanations.

Keep responses under 100 words unless complex explanation is needed.`

    const { text } = await generateText({
      model: "openai/gpt-4o-mini",
      messages: [{ role: "system", content: systemPrompt }, ...messages],
      temperature: 0.7,
      maxTokens: 200,
    })

    return Response.json({ message: text })
  } catch (error) {
    console.error("[v0] AI chat route error:", error)
    return Response.json({ message: "System malfunction. Neural pathways temporarily disrupted." }, { status: 500 })
  }
}
