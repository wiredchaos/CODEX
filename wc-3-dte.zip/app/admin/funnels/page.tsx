"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  ArrowLeft,
  Plus,
  Palette,
  Globe,
  Settings,
  BarChart3,
  Users,
  Zap,
  ChevronRight,
  Copy,
  ExternalLink,
  Building2,
  Layers,
  Filter,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const WL_COLORS = {
  primary: "#00FFF7",
  secondary: "#0088FF",
  accent: "#A020F0",
  dark: "#050510",
  glow: "rgba(0, 255, 247, 0.3)",
}

interface Agency {
  id: string
  name: string
  slug: string
  domain: string
  logoUrl: string
  brandColors: { primary: string; secondary: string }
  productTiers: string[]
  settings: Record<string, unknown>
  stats: { leads: number; conversions: number; revenue: number }
}

interface PatchProduct {
  id: string
  patchId: string
  title: string
  description: string
  tier: string
  monthlyPrice: number
  annualPrice: number
  features: string[]
  isActive: boolean
}

const MOCK_AGENCIES: Agency[] = [
  {
    id: "1",
    name: "Neuralis Partners",
    slug: "neuralis-partners",
    domain: "neuralis.io",
    logoUrl: "/neuralis-logo.jpg",
    brandColors: { primary: "#00FFF7", secondary: "#0088FF" },
    productTiers: ["starter", "pro", "enterprise"],
    settings: {},
    stats: { leads: 1247, conversions: 89, revenue: 45600 },
  },
  {
    id: "2",
    name: "Chaos Ventures",
    slug: "chaos-ventures",
    domain: "chaos.vc",
    logoUrl: "/chaos-ventures-logo.jpg",
    brandColors: { primary: "#FF1A1A", secondary: "#FF6B00" },
    productTiers: ["basic", "premium"],
    settings: {},
    stats: { leads: 892, conversions: 67, revenue: 32400 },
  },
  {
    id: "3",
    name: "Underground Labs",
    slug: "underground-labs",
    domain: "ug-labs.co",
    logoUrl: "/underground-labs-logo.jpg",
    brandColors: { primary: "#A020F0", secondary: "#FF00FF" },
    productTiers: ["hacker", "elite"],
    settings: {},
    stats: { leads: 543, conversions: 41, revenue: 18900 },
  },
]

const PATCHES = [
  { id: "credit-repair", name: "Credit Repair", color: "#0066FF" },
  { id: "hrm", name: "HRM Training", color: "#00FF88" },
  { id: "npc", name: "NPC Engine", color: "#00FFF7" },
  { id: "fen", name: "FEN Realm", color: "#A020F0" },
  { id: "789-ott", name: "789 OTT", color: "#FFD700" },
]

export default function FunnelBuilderPage() {
  const router = useRouter()
  const [selectedAgency, setSelectedAgency] = useState<Agency | null>(null)
  const [activeTab, setActiveTab] = useState("agencies")
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [newAgency, setNewAgency] = useState({
    name: "",
    slug: "",
    domain: "",
    primaryColor: "#00FFF7",
    secondaryColor: "#0088FF",
  })

  const handleCreateAgency = () => {
    // Would call Supabase to insert into wc_agencies
    console.log("Creating agency:", newAgency)
    setShowCreateModal(false)
    setNewAgency({ name: "", slug: "", domain: "", primaryColor: "#00FFF7", secondaryColor: "#0088FF" })
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: WL_COLORS.dark }}>
      {/* Background Grid */}
      <div
        className="fixed inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${WL_COLORS.primary}20 1px, transparent 1px),
            linear-gradient(to bottom, ${WL_COLORS.primary}20 1px, transparent 1px)
          `,
          backgroundSize: "40px 40px",
        }}
      />

      {/* Header */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl border-b"
        style={{ background: "rgba(5,5,16,0.95)", borderColor: `${WL_COLORS.primary}30` }}
      >
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => router.push("/")}
              className="flex items-center gap-2 transition-colors hover:opacity-80"
              style={{ color: WL_COLORS.primary }}
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="font-mono text-sm uppercase hidden sm:inline">Hub</span>
            </button>
            <div className="w-px h-6" style={{ background: `${WL_COLORS.primary}30` }} />
            <div className="flex items-center gap-2">
              <Layers className="w-5 h-5" style={{ color: WL_COLORS.primary }} />
              <h1
                className="font-display text-xl uppercase tracking-wider"
                style={{ color: WL_COLORS.primary, textShadow: `0 0 20px ${WL_COLORS.glow}` }}
              >
                WL Funnel Builder
              </h1>
            </div>
          </div>
          <Button
            onClick={() => setShowCreateModal(true)}
            style={{ background: WL_COLORS.primary, color: "#000" }}
            className="font-mono text-xs uppercase"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Agency
          </Button>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-black/50 border border-neutral-800">
            <TabsTrigger
              value="agencies"
              className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
            >
              <Building2 className="w-4 h-4 mr-2" />
              Agencies
            </TabsTrigger>
            <TabsTrigger
              value="products"
              className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
            >
              <Layers className="w-4 h-4 mr-2" />
              Products
            </TabsTrigger>
            <TabsTrigger
              value="analytics"
              className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
            >
              <BarChart3 className="w-4 h-4 mr-2" />
              Analytics
            </TabsTrigger>
          </TabsList>

          {/* Agencies Tab */}
          <TabsContent value="agencies" className="space-y-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {MOCK_AGENCIES.map((agency) => (
                <Card
                  key={agency.id}
                  className="bg-black/40 border-neutral-800 hover:border-cyan-500/50 transition-colors cursor-pointer"
                  onClick={() => setSelectedAgency(agency)}
                >
                  <CardHeader className="pb-2">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-12 h-12 rounded-lg flex items-center justify-center text-xl font-bold"
                        style={{ background: `${agency.brandColors.primary}20`, color: agency.brandColors.primary }}
                      >
                        {agency.name.charAt(0)}
                      </div>
                      <div>
                        <CardTitle className="text-white text-lg">{agency.name}</CardTitle>
                        <CardDescription className="text-neutral-500 flex items-center gap-1">
                          <Globe className="w-3 h-3" />
                          {agency.domain}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-3 gap-2 mt-2">
                      <div className="text-center p-2 rounded-lg" style={{ background: "rgba(255,255,255,0.05)" }}>
                        <p className="text-lg font-bold text-white">{agency.stats.leads}</p>
                        <p className="text-xs text-neutral-500">Leads</p>
                      </div>
                      <div className="text-center p-2 rounded-lg" style={{ background: "rgba(255,255,255,0.05)" }}>
                        <p className="text-lg font-bold text-green-400">{agency.stats.conversions}</p>
                        <p className="text-xs text-neutral-500">Converts</p>
                      </div>
                      <div className="text-center p-2 rounded-lg" style={{ background: "rgba(255,255,255,0.05)" }}>
                        <p className="text-lg font-bold text-amber-400">${(agency.stats.revenue / 1000).toFixed(1)}k</p>
                        <p className="text-xs text-neutral-500">Revenue</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between mt-4 pt-4 border-t border-neutral-800">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full" style={{ background: agency.brandColors.primary }} />
                        <div className="w-3 h-3 rounded-full" style={{ background: agency.brandColors.secondary }} />
                      </div>
                      <ChevronRight className="w-4 h-4 text-neutral-500" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Agency Detail Panel */}
            {selectedAgency && (
              <Card className="bg-black/60 border-neutral-700">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div
                        className="w-16 h-16 rounded-xl flex items-center justify-center text-2xl font-bold"
                        style={{
                          background: `${selectedAgency.brandColors.primary}20`,
                          color: selectedAgency.brandColors.primary,
                          border: `2px solid ${selectedAgency.brandColors.primary}`,
                        }}
                      >
                        {selectedAgency.name.charAt(0)}
                      </div>
                      <div>
                        <CardTitle className="text-white text-2xl">{selectedAgency.name}</CardTitle>
                        <CardDescription className="text-neutral-400 flex items-center gap-2 mt-1">
                          <Globe className="w-4 h-4" />
                          {selectedAgency.domain}
                          <button className="ml-2 hover:text-cyan-400 transition-colors">
                            <ExternalLink className="w-4 h-4" />
                          </button>
                        </CardDescription>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" className="border-neutral-700 hover:border-cyan-500 bg-transparent">
                        <Palette className="w-4 h-4 mr-2" />
                        Brand
                      </Button>
                      <Button variant="outline" className="border-neutral-700 hover:border-cyan-500 bg-transparent">
                        <Settings className="w-4 h-4 mr-2" />
                        Settings
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Funnel URLs */}
                  <div>
                    <h3 className="font-mono text-sm uppercase text-neutral-500 mb-3">Funnel URLs</h3>
                    <div className="space-y-2">
                      {PATCHES.map((patch) => (
                        <div
                          key={patch.id}
                          className="flex items-center justify-between p-3 rounded-lg"
                          style={{ background: "rgba(255,255,255,0.05)" }}
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-2 h-2 rounded-full" style={{ background: patch.color }} />
                            <span className="text-white text-sm">{patch.name}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <code className="text-xs text-neutral-400 bg-black/50 px-2 py-1 rounded">
                              {selectedAgency.domain}/{patch.id}
                            </code>
                            <button className="text-neutral-500 hover:text-cyan-400 transition-colors">
                              <Copy className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Product Tiers */}
                  <div>
                    <h3 className="font-mono text-sm uppercase text-neutral-500 mb-3">Product Tiers</h3>
                    <div className="flex flex-wrap gap-2">
                      {selectedAgency.productTiers.map((tier) => (
                        <span
                          key={tier}
                          className="px-3 py-1 rounded-full text-xs font-mono uppercase"
                          style={{
                            background: `${selectedAgency.brandColors.primary}20`,
                            color: selectedAgency.brandColors.primary,
                            border: `1px solid ${selectedAgency.brandColors.primary}50`,
                          }}
                        >
                          {tier}
                        </span>
                      ))}
                      <button className="px-3 py-1 rounded-full text-xs font-mono uppercase border border-dashed border-neutral-600 text-neutral-500 hover:border-cyan-500 hover:text-cyan-400 transition-colors">
                        <Plus className="w-3 h-3 inline mr-1" />
                        Add Tier
                      </button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Products Tab */}
          <TabsContent value="products" className="space-y-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-neutral-500" />
                <span className="text-sm text-neutral-400">Filter by patch:</span>
                <div className="flex gap-1">
                  {PATCHES.map((patch) => (
                    <button
                      key={patch.id}
                      className="px-2 py-1 rounded text-xs font-mono"
                      style={{ background: `${patch.color}20`, color: patch.color }}
                    >
                      {patch.name}
                    </button>
                  ))}
                </div>
              </div>
              <Button style={{ background: WL_COLORS.secondary }} className="font-mono text-xs uppercase">
                <Plus className="w-4 h-4 mr-2" />
                Add Product
              </Button>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {PATCHES.map((patch) => (
                <Card key={patch.id} className="bg-black/40 border-neutral-800">
                  <CardHeader>
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-3 h-3 rounded-full" style={{ background: patch.color }} />
                      <span className="text-xs font-mono text-neutral-500 uppercase">{patch.name}</span>
                    </div>
                    <CardTitle className="text-white">Starter Plan</CardTitle>
                    <CardDescription className="text-neutral-400">Basic access to {patch.name}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-baseline gap-1 mb-4">
                      <span className="text-3xl font-bold text-white">$29</span>
                      <span className="text-neutral-500">/month</span>
                    </div>
                    <ul className="space-y-2 text-sm text-neutral-300">
                      <li className="flex items-center gap-2">
                        <Zap className="w-4 h-4" style={{ color: patch.color }} />
                        Core features included
                      </li>
                      <li className="flex items-center gap-2">
                        <Users className="w-4 h-4" style={{ color: patch.color }} />
                        Up to 5 users
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid md:grid-cols-4 gap-4">
              <Card className="bg-black/40 border-neutral-800">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-neutral-500">Total Leads</p>
                      <p className="text-3xl font-bold text-white">2,682</p>
                    </div>
                    <Users className="w-8 h-8 text-cyan-400" />
                  </div>
                  <p className="text-xs text-green-400 mt-2">+12.5% from last month</p>
                </CardContent>
              </Card>
              <Card className="bg-black/40 border-neutral-800">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-neutral-500">Conversions</p>
                      <p className="text-3xl font-bold text-white">197</p>
                    </div>
                    <Zap className="w-8 h-8 text-green-400" />
                  </div>
                  <p className="text-xs text-green-400 mt-2">+8.3% from last month</p>
                </CardContent>
              </Card>
              <Card className="bg-black/40 border-neutral-800">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-neutral-500">Revenue</p>
                      <p className="text-3xl font-bold text-white">$96.9k</p>
                    </div>
                    <BarChart3 className="w-8 h-8 text-amber-400" />
                  </div>
                  <p className="text-xs text-green-400 mt-2">+15.2% from last month</p>
                </CardContent>
              </Card>
              <Card className="bg-black/40 border-neutral-800">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-neutral-500">Active Trials</p>
                      <p className="text-3xl font-bold text-white">54</p>
                    </div>
                    <Layers className="w-8 h-8 text-purple-400" />
                  </div>
                  <p className="text-xs text-amber-400 mt-2">12 expiring this week</p>
                </CardContent>
              </Card>
            </div>

            {/* Funnel Performance Chart Placeholder */}
            <Card className="bg-black/40 border-neutral-800">
              <CardHeader>
                <CardTitle className="text-white">Funnel Performance</CardTitle>
                <CardDescription className="text-neutral-500">Lead to conversion by patch</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {PATCHES.map((patch) => (
                    <div key={patch.id}>
                      <div className="flex items-center justify-between text-sm mb-1">
                        <span className="text-white">{patch.name}</span>
                        <span className="text-neutral-400">
                          {Math.floor(Math.random() * 500 + 100)} leads → {Math.floor(Math.random() * 50 + 10)}{" "}
                          conversions
                        </span>
                      </div>
                      <div className="h-2 bg-neutral-800 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full"
                          style={{
                            width: `${Math.floor(Math.random() * 60 + 20)}%`,
                            background: `linear-gradient(to right, ${patch.color}, ${patch.color}80)`,
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Create Agency Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
          <Card className="w-full max-w-md bg-neutral-900 border-neutral-700">
            <CardHeader>
              <CardTitle className="text-white">Create New Agency</CardTitle>
              <CardDescription className="text-neutral-400">Set up a white-label partner</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label className="text-neutral-300">Agency Name</Label>
                <Input
                  value={newAgency.name}
                  onChange={(e) => setNewAgency({ ...newAgency, name: e.target.value })}
                  placeholder="Acme Partners"
                  className="bg-black/50 border-neutral-700"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-neutral-300">Slug</Label>
                <Input
                  value={newAgency.slug}
                  onChange={(e) => setNewAgency({ ...newAgency, slug: e.target.value })}
                  placeholder="acme-partners"
                  className="bg-black/50 border-neutral-700"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-neutral-300">Domain</Label>
                <Input
                  value={newAgency.domain}
                  onChange={(e) => setNewAgency({ ...newAgency, domain: e.target.value })}
                  placeholder="acme.io"
                  className="bg-black/50 border-neutral-700"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-neutral-300">Primary Color</Label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={newAgency.primaryColor}
                      onChange={(e) => setNewAgency({ ...newAgency, primaryColor: e.target.value })}
                      className="w-10 h-10 rounded cursor-pointer"
                    />
                    <Input
                      value={newAgency.primaryColor}
                      onChange={(e) => setNewAgency({ ...newAgency, primaryColor: e.target.value })}
                      className="bg-black/50 border-neutral-700 font-mono text-sm"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-neutral-300">Secondary Color</Label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={newAgency.secondaryColor}
                      onChange={(e) => setNewAgency({ ...newAgency, secondaryColor: e.target.value })}
                      className="w-10 h-10 rounded cursor-pointer"
                    />
                    <Input
                      value={newAgency.secondaryColor}
                      onChange={(e) => setNewAgency({ ...newAgency, secondaryColor: e.target.value })}
                      className="bg-black/50 border-neutral-700 font-mono text-sm"
                    />
                  </div>
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setShowCreateModal(false)}
                  className="border-neutral-700 bg-transparent"
                >
                  Cancel
                </Button>
                <Button onClick={handleCreateAgency} style={{ background: WL_COLORS.primary, color: "#000" }}>
                  Create Agency
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
