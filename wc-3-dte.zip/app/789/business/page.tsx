"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  ArrowLeft,
  Briefcase,
  Bot,
  BarChart3,
  Users,
  Play,
  Pause,
  CheckCircle,
  AlertCircle,
  Clock,
  Zap,
  DollarSign,
  TrendingUp,
  Activity,
} from "lucide-react"
import { Button } from "@/components/ui/button"

const STUDIO_COLORS = {
  primary: "#FFD700",
  secondary: "#FFA500",
  accent: "#FF6B00",
  dark: "#0D0800",
  glow: "rgba(255, 215, 0, 0.5)",
}

const AGENTS = [
  { id: "pm-lead", name: "PM Lead", status: "active", tasks: 12, completed: 8, icon: Users },
  { id: "scene-compiler", name: "Scene Compiler", status: "active", tasks: 5, completed: 3, icon: Zap },
  { id: "billing-agent", name: "Billing Agent", status: "idle", tasks: 0, completed: 15, icon: DollarSign },
  { id: "content-scheduler", name: "Content Scheduler", status: "active", tasks: 8, completed: 6, icon: Clock },
  { id: "analytics-engine", name: "Analytics Engine", status: "processing", tasks: 3, completed: 0, icon: BarChart3 },
  { id: "talent-coordinator", name: "Talent Coordinator", status: "idle", tasks: 0, completed: 22, icon: Users },
]

const RECENT_JOBS = [
  { id: 1, agent: "PM Lead", task: "Review production schedule", status: "completed", time: "2m ago" },
  { id: 2, agent: "Scene Compiler", task: "Compile Act 3 Scene 7", status: "in-progress", time: "5m ago" },
  { id: 3, agent: "Analytics Engine", task: "Generate weekly report", status: "in-progress", time: "8m ago" },
  { id: 4, agent: "Content Scheduler", task: "Schedule release for Episode 5", status: "completed", time: "12m ago" },
  { id: 5, agent: "Billing Agent", task: "Process creator payouts", status: "completed", time: "1h ago" },
]

const METRICS = [
  { label: "Active Agents", value: "4/6", change: "+2", icon: Bot },
  { label: "Jobs Today", value: "47", change: "+12", icon: Activity },
  { label: "Credits Used", value: "2,450", change: "-15%", icon: DollarSign },
  { label: "Success Rate", value: "98.2%", change: "+0.5%", icon: TrendingUp },
]

export default function BusinessSuitePage() {
  const router = useRouter()
  const [selectedAgent, setSelectedAgent] = useState<string | null>(null)

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "#22c55e"
      case "processing":
        return STUDIO_COLORS.primary
      case "idle":
        return "#666"
      default:
        return "#666"
    }
  }

  const getJobStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-4 h-4 text-green-500" />
      case "in-progress":
        return <Clock className="w-4 h-4 text-amber-500 animate-pulse" />
      case "failed":
        return <AlertCircle className="w-4 h-4 text-red-500" />
      default:
        return null
    }
  }

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: STUDIO_COLORS.dark }}>
      {/* Gold Circuitry Background */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${STUDIO_COLORS.primary}15 1px, transparent 1px),
            linear-gradient(to bottom, ${STUDIO_COLORS.primary}15 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Header */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(0, 0, 0, 0.9)",
          borderColor: `${STUDIO_COLORS.primary}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => router.push("/789")}
              className="flex items-center gap-2 transition-colors hover:opacity-80"
              style={{ color: STUDIO_COLORS.primary }}
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="font-mono text-sm uppercase">789 Lobby</span>
            </button>
            <div className="w-px h-6" style={{ background: `${STUDIO_COLORS.primary}30` }} />
            <div className="flex items-center gap-2">
              <Briefcase className="w-6 h-6" style={{ color: STUDIO_COLORS.primary }} />
              <h1
                className="font-display text-2xl uppercase tracking-wider"
                style={{
                  color: STUDIO_COLORS.primary,
                  textShadow: `0 0 20px ${STUDIO_COLORS.glow}`,
                }}
              >
                Business Suite
              </h1>
            </div>
          </div>

          <div
            className="px-3 py-1 rounded-full font-mono text-xs uppercase flex items-center gap-2"
            style={{
              background: "rgba(34, 197, 94, 0.2)",
              color: "#22c55e",
              border: "1px solid rgba(34, 197, 94, 0.5)",
            }}
          >
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            Agentic Runtime Active
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-6 py-8">
        {/* Metrics Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {METRICS.map((metric) => {
            const Icon = metric.icon
            return (
              <div
                key={metric.label}
                className="p-4 rounded-xl"
                style={{
                  background: "rgba(0, 0, 0, 0.6)",
                  border: `1px solid ${STUDIO_COLORS.primary}20`,
                }}
              >
                <div className="flex items-center justify-between mb-2">
                  <Icon className="w-5 h-5 text-neutral-500" />
                  <span
                    className="text-xs font-mono"
                    style={{
                      color: metric.change.startsWith("+")
                        ? "#22c55e"
                        : metric.change.startsWith("-")
                          ? "#ef4444"
                          : "#666",
                    }}
                  >
                    {metric.change}
                  </span>
                </div>
                <p className="font-display text-2xl" style={{ color: STUDIO_COLORS.primary }}>
                  {metric.value}
                </p>
                <p className="text-xs text-neutral-500 uppercase">{metric.label}</p>
              </div>
            )
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Agents Panel */}
          <section className="lg:col-span-2">
            <h2 className="font-mono text-sm uppercase tracking-wider mb-4" style={{ color: STUDIO_COLORS.secondary }}>
              NPC Agent Staff
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {AGENTS.map((agent) => {
                const Icon = agent.icon
                const isSelected = selectedAgent === agent.id

                return (
                  <button
                    key={agent.id}
                    onClick={() => setSelectedAgent(isSelected ? null : agent.id)}
                    className="p-4 rounded-xl text-left transition-all duration-300 hover:scale-[1.02] group"
                    style={{
                      background: isSelected
                        ? `linear-gradient(135deg, ${STUDIO_COLORS.primary}15, transparent)`
                        : "rgba(0, 0, 0, 0.6)",
                      border: `1px solid ${isSelected ? STUDIO_COLORS.primary : "rgba(255, 255, 255, 0.1)"}`,
                      boxShadow: isSelected ? `0 0 20px ${STUDIO_COLORS.glow}` : "none",
                    }}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div
                          className="w-10 h-10 rounded-lg flex items-center justify-center"
                          style={{
                            background: `${STUDIO_COLORS.primary}20`,
                            color: STUDIO_COLORS.primary,
                          }}
                        >
                          <Icon className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className="font-mono text-sm text-white">{agent.name}</h3>
                          <div className="flex items-center gap-2">
                            <div
                              className="w-2 h-2 rounded-full"
                              style={{
                                background: getStatusColor(agent.status),
                                boxShadow:
                                  agent.status === "active" ? `0 0 8px ${getStatusColor(agent.status)}` : "none",
                              }}
                            />
                            <span className="text-xs text-neutral-500 uppercase">{agent.status}</span>
                          </div>
                        </div>
                      </div>

                      <Button
                        size="sm"
                        variant="ghost"
                        className="opacity-0 group-hover:opacity-100 transition-opacity"
                        style={{ color: STUDIO_COLORS.primary }}
                      >
                        {agent.status === "active" ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                      </Button>
                    </div>

                    <div className="flex items-center justify-between text-xs text-neutral-500">
                      <span>{agent.tasks} active tasks</span>
                      <span>{agent.completed} completed</span>
                    </div>

                    {/* Progress bar */}
                    <div className="mt-2 h-1 rounded-full bg-neutral-800 overflow-hidden">
                      <div
                        className="h-full rounded-full"
                        style={{
                          width:
                            agent.tasks > 0 ? `${(agent.completed / (agent.tasks + agent.completed)) * 100}%` : "100%",
                          background: STUDIO_COLORS.primary,
                        }}
                      />
                    </div>
                  </button>
                )
              })}
            </div>
          </section>

          {/* Recent Jobs Panel */}
          <section>
            <h2 className="font-mono text-sm uppercase tracking-wider mb-4" style={{ color: STUDIO_COLORS.secondary }}>
              Recent Jobs
            </h2>
            <div
              className="rounded-xl p-4 space-y-3"
              style={{
                background: "rgba(0, 0, 0, 0.6)",
                border: `1px solid ${STUDIO_COLORS.primary}20`,
              }}
            >
              {RECENT_JOBS.map((job) => (
                <div key={job.id} className="flex items-start gap-3 p-3 rounded-lg transition-colors hover:bg-white/5">
                  {getJobStatusIcon(job.status)}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-white truncate">{job.task}</p>
                    <div className="flex items-center gap-2 text-xs text-neutral-500">
                      <span>{job.agent}</span>
                      <span>•</span>
                      <span>{job.time}</span>
                    </div>
                  </div>
                </div>
              ))}

              <Button
                variant="ghost"
                className="w-full font-mono text-xs uppercase"
                style={{ color: STUDIO_COLORS.primary }}
              >
                View All Jobs
              </Button>
            </div>
          </section>
        </div>
      </main>
    </div>
  )
}
