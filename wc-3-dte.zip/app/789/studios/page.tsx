"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Film, Camera, Video, Mic, Monitor, Play, Upload, Users } from "lucide-react"
import { Button } from "@/components/ui/button"

const STUDIO_COLORS = {
  primary: "#FFD700",
  secondary: "#FFA500",
  accent: "#FF6B00",
  dark: "#0D0800",
  glow: "rgba(255, 215, 0, 0.5)",
}

const STUDIO_ROOMS = [
  { id: "stage-a", name: "Stage A", type: "Primary Sound Stage", capacity: "50 crew", status: "available", icon: Film },
  { id: "stage-b", name: "Stage B", type: "Green Screen Studio", capacity: "30 crew", status: "in-use", icon: Video },
  {
    id: "edit-1",
    name: "Edit Bay 1",
    type: "Post Production",
    capacity: "4 editors",
    status: "available",
    icon: Monitor,
  },
  {
    id: "edit-2",
    name: "Edit Bay 2",
    type: "Color Grading",
    capacity: "2 colorists",
    status: "available",
    icon: Monitor,
  },
  { id: "audio-1", name: "Audio Suite", type: "ADR & Foley", capacity: "6 talent", status: "reserved", icon: Mic },
  {
    id: "virtual",
    name: "Virtual Production",
    type: "LED Volume Stage",
    capacity: "40 crew",
    status: "available",
    icon: Camera,
  },
]

const ACTIVE_PRODUCTIONS = [
  { id: 1, title: "NEURAL DRIFT", type: "Feature Film", progress: 67, phase: "Principal Photography" },
  { id: 2, title: "CHAOS THEORY S2", type: "Series", progress: 45, phase: "Pre-Production" },
  { id: 3, title: "789 ORIGINALS", type: "Content", progress: 89, phase: "Post-Production" },
]

export default function StudiosPage() {
  const router = useRouter()
  const [selectedRoom, setSelectedRoom] = useState<string | null>(null)

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: STUDIO_COLORS.dark }}>
      {/* Gold Circuitry Background */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${STUDIO_COLORS.primary}15 1px, transparent 1px),
            linear-gradient(to bottom, ${STUDIO_COLORS.primary}15 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Header */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(0, 0, 0, 0.9)",
          borderColor: `${STUDIO_COLORS.primary}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => router.push("/789")}
              className="flex items-center gap-2 transition-colors hover:opacity-80"
              style={{ color: STUDIO_COLORS.primary }}
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="font-mono text-sm uppercase">789 Lobby</span>
            </button>
            <div className="w-px h-6" style={{ background: `${STUDIO_COLORS.primary}30` }} />
            <h1
              className="font-display text-2xl uppercase tracking-wider"
              style={{
                color: STUDIO_COLORS.primary,
                textShadow: `0 0 20px ${STUDIO_COLORS.glow}`,
              }}
            >
              Production Studios
            </h1>
          </div>

          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              className="font-mono text-xs uppercase bg-transparent"
              style={{
                borderColor: STUDIO_COLORS.primary,
                color: STUDIO_COLORS.primary,
              }}
            >
              <Upload className="w-4 h-4 mr-2" />
              New Project
            </Button>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-6 py-12">
        {/* Active Productions */}
        <section className="mb-12">
          <h2 className="font-mono text-sm uppercase tracking-wider mb-6" style={{ color: STUDIO_COLORS.secondary }}>
            Active Productions
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {ACTIVE_PRODUCTIONS.map((prod) => (
              <div
                key={prod.id}
                className="p-6 rounded-xl transition-all duration-300 hover:scale-[1.02] cursor-pointer group"
                style={{
                  background: "rgba(0, 0, 0, 0.6)",
                  border: `1px solid ${STUDIO_COLORS.primary}30`,
                }}
              >
                <div className="flex items-center justify-between mb-4">
                  <span
                    className="px-2 py-1 rounded text-xs font-mono uppercase"
                    style={{
                      background: `${STUDIO_COLORS.primary}20`,
                      color: STUDIO_COLORS.primary,
                    }}
                  >
                    {prod.type}
                  </span>
                  <Play
                    className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-opacity"
                    style={{ color: STUDIO_COLORS.primary }}
                  />
                </div>
                <h3 className="font-display text-xl text-white mb-2">{prod.title}</h3>
                <p className="text-neutral-500 text-sm mb-4">{prod.phase}</p>

                {/* Progress Bar */}
                <div className="h-2 rounded-full bg-neutral-800 overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${prod.progress}%`,
                      background: `linear-gradient(90deg, ${STUDIO_COLORS.primary}, ${STUDIO_COLORS.secondary})`,
                      boxShadow: `0 0 10px ${STUDIO_COLORS.glow}`,
                    }}
                  />
                </div>
                <p className="text-right text-xs text-neutral-500 mt-2">{prod.progress}% Complete</p>
              </div>
            ))}
          </div>
        </section>

        {/* Studio Rooms */}
        <section>
          <h2 className="font-mono text-sm uppercase tracking-wider mb-6" style={{ color: STUDIO_COLORS.secondary }}>
            Studio Rooms
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {STUDIO_ROOMS.map((room) => {
              const Icon = room.icon
              const statusColors = {
                available: "#22c55e",
                "in-use": "#ef4444",
                reserved: STUDIO_COLORS.primary,
              }

              return (
                <button
                  key={room.id}
                  onClick={() => setSelectedRoom(room.id)}
                  className="p-6 rounded-xl text-left transition-all duration-300 hover:scale-[1.02] group"
                  style={{
                    background:
                      selectedRoom === room.id
                        ? `linear-gradient(135deg, ${STUDIO_COLORS.primary}15, transparent)`
                        : "rgba(0, 0, 0, 0.6)",
                    border: `1px solid ${selectedRoom === room.id ? STUDIO_COLORS.primary : "rgba(255, 255, 255, 0.1)"}`,
                    boxShadow: selectedRoom === room.id ? `0 0 30px ${STUDIO_COLORS.glow}` : "none",
                  }}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div
                      className="w-12 h-12 rounded-lg flex items-center justify-center"
                      style={{
                        background: `${STUDIO_COLORS.primary}20`,
                        color: STUDIO_COLORS.primary,
                      }}
                    >
                      <Icon className="w-6 h-6" />
                    </div>
                    <div className="flex items-center gap-2">
                      <div
                        className="w-2 h-2 rounded-full"
                        style={{
                          background: statusColors[room.status as keyof typeof statusColors],
                          boxShadow: `0 0 8px ${statusColors[room.status as keyof typeof statusColors]}`,
                        }}
                      />
                      <span className="text-xs text-neutral-500 uppercase">{room.status}</span>
                    </div>
                  </div>

                  <h3
                    className="font-display text-lg uppercase mb-1 group-hover:text-white transition-colors"
                    style={{ color: STUDIO_COLORS.primary }}
                  >
                    {room.name}
                  </h3>
                  <p className="text-neutral-400 text-sm mb-2">{room.type}</p>
                  <p className="text-neutral-600 text-xs flex items-center gap-1">
                    <Users className="w-3 h-3" />
                    {room.capacity}
                  </p>
                </button>
              )
            })}
          </div>
        </section>
      </main>
    </div>
  )
}
