"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Search, Filter, Grid, List, Heart, Share2, ChevronRight, TrendingUp, Verified } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ElevatorTravel, usePatchLifecycle } from "@/components/elevator-travel"

const COLORS = {
  primary: "#FFD700",
  secondary: "#FFA500",
  dark: "#0A0A00",
}

const NFTS = [
  {
    id: 1,
    title: "Genesis Director Pass",
    creator: "789 Studios",
    price: "2.5 ETH",
    image: "/nft-golden-director-pass-film.jpg",
    likes: 847,
    verified: true,
    category: "Access Pass",
  },
  {
    id: 2,
    title: "Chaos Cinema #001",
    creator: "DJ Red Fang",
    price: "0.8 ETH",
    image: "/nft-cyberpunk-cinema-ticket.jpg",
    likes: 324,
    verified: true,
    category: "Collectible",
  },
  {
    id: 3,
    title: "Film3 Pioneer Badge",
    creator: "WIRED CHAOS",
    price: "0.15 ETH",
    image: "/nft-pioneer-badge-hexagon-gold.jpg",
    likes: 1205,
    verified: true,
    category: "Badge",
  },
  {
    id: 4,
    title: "Script Rights - Neon Dreams",
    creator: "Studio789",
    price: "5 ETH",
    image: "/nft-film-script-document-gold.jpg",
    likes: 156,
    verified: true,
    category: "IP Rights",
  },
  {
    id: 5,
    title: "BTS Documentary Access",
    creator: "789 OTT",
    price: "0.3 ETH",
    image: "/nft-documentary-access-film-reel.jpg",
    likes: 589,
    verified: true,
    category: "Access Pass",
  },
  {
    id: 6,
    title: "Premiere Ticket - SIGNAL",
    creator: "33.3FM",
    price: "0.5 ETH",
    image: "/nft-premiere-ticket-cinema-gold.jpg",
    likes: 723,
    verified: true,
    category: "Ticket",
  },
]

export default function NFTMarketplacePage() {
  const router = useRouter()
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const { onExitPatch } = usePatchLifecycle("patch_789_nft")

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: COLORS.dark }}>
      {/* Background Grid */}
      <div
        className="fixed inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${COLORS.primary}20 1px, transparent 1px),
            linear-gradient(to bottom, ${COLORS.primary}20 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Header */}
      <header className="relative z-10 p-4 sm:p-6 border-b" style={{ borderColor: `${COLORS.primary}20` }}>
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <button
            onClick={() => router.push("/789")}
            className="flex items-center gap-2 text-neutral-400 hover:text-white transition-colors"
          >
            <ChevronRight className="w-4 h-4 rotate-180" />
            <span className="font-mono text-sm">Back to 789</span>
          </button>

          <h1 className="font-display text-xl font-bold" style={{ color: COLORS.primary }}>
            NFT MARKETPLACE
          </h1>

          <Button
            variant="outline"
            className="font-mono text-xs bg-transparent"
            style={{ borderColor: COLORS.primary, color: COLORS.primary }}
          >
            Connect Wallet
          </Button>
        </div>
      </header>

      {/* Filters */}
      <div className="relative z-10 p-4 sm:p-6 border-b" style={{ borderColor: `${COLORS.primary}20` }}>
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4 w-full sm:w-auto">
            <div className="relative flex-1 sm:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
              <Input placeholder="Search NFTs..." className="pl-10 bg-black/50 border-neutral-800 font-mono text-sm" />
            </div>
            <Button variant="outline" size="icon" className="border-neutral-800 bg-transparent">
              <Filter className="w-4 h-4" />
            </Button>
          </div>

          <div className="flex items-center gap-4">
            <Tabs defaultValue="all">
              <TabsList className="bg-black/50">
                <TabsTrigger value="all" className="font-mono text-xs">
                  All
                </TabsTrigger>
                <TabsTrigger value="passes" className="font-mono text-xs">
                  Passes
                </TabsTrigger>
                <TabsTrigger value="rights" className="font-mono text-xs">
                  IP Rights
                </TabsTrigger>
                <TabsTrigger value="tickets" className="font-mono text-xs">
                  Tickets
                </TabsTrigger>
              </TabsList>
            </Tabs>

            <div
              className="flex items-center gap-1 border rounded-lg p-1"
              style={{ borderColor: `${COLORS.primary}30` }}
            >
              <button
                onClick={() => setViewMode("grid")}
                className={`p-2 rounded ${viewMode === "grid" ? "bg-amber-500/20" : ""}`}
              >
                <Grid className="w-4 h-4" style={{ color: viewMode === "grid" ? COLORS.primary : "#666" }} />
              </button>
              <button
                onClick={() => setViewMode("list")}
                className={`p-2 rounded ${viewMode === "list" ? "bg-amber-500/20" : ""}`}
              >
                <List className="w-4 h-4" style={{ color: viewMode === "list" ? COLORS.primary : "#666" }} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Bar */}
      <div className="relative z-10 p-4 border-b" style={{ borderColor: `${COLORS.primary}10` }}>
        <div className="max-w-7xl mx-auto flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-6">
            <span className="text-neutral-500">
              Floor: <span style={{ color: COLORS.primary }}>0.15 ETH</span>
            </span>
            <span className="text-neutral-500">
              Volume: <span style={{ color: COLORS.primary }}>124.5 ETH</span>
            </span>
            <span className="text-neutral-500">
              Listed: <span style={{ color: COLORS.primary }}>2,847</span>
            </span>
          </div>
          <div className="flex items-center gap-2 text-green-500">
            <TrendingUp className="w-4 h-4" />
            +24.5% this week
          </div>
        </div>
      </div>

      {/* NFT Grid */}
      <main className="relative z-10 p-4 sm:p-6">
        <div className="max-w-7xl mx-auto">
          <div
            className={`grid gap-6 ${viewMode === "grid" ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3" : "grid-cols-1"}`}
          >
            {NFTS.map((nft) => (
              <Card
                key={nft.id}
                className="group overflow-hidden cursor-pointer transition-all hover:scale-[1.02]"
                style={{
                  background: "rgba(0, 0, 0, 0.8)",
                  border: `1px solid ${COLORS.primary}20`,
                }}
              >
                <div className="relative aspect-square overflow-hidden">
                  <img
                    src={nft.image || "/placeholder.svg"}
                    alt={nft.title}
                    className="w-full h-full object-cover transition-transform group-hover:scale-110"
                  />
                  <div className="absolute top-3 left-3">
                    <Badge
                      className="font-mono text-xs"
                      style={{ background: `${COLORS.primary}20`, color: COLORS.primary }}
                    >
                      {nft.category}
                    </Badge>
                  </div>
                  <div className="absolute top-3 right-3 flex items-center gap-2">
                    <button className="p-2 rounded-full bg-black/50 hover:bg-black/80 transition-colors">
                      <Heart className="w-4 h-4 text-white" />
                    </button>
                    <button className="p-2 rounded-full bg-black/50 hover:bg-black/80 transition-colors">
                      <Share2 className="w-4 h-4 text-white" />
                    </button>
                  </div>
                </div>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-mono text-sm font-medium text-white truncate">{nft.title}</h3>
                    {nft.verified && <Verified className="w-4 h-4" style={{ color: COLORS.primary }} />}
                  </div>
                  <p className="text-xs text-neutral-500 mb-3">by {nft.creator}</p>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs text-neutral-500">Price</p>
                      <p className="font-mono font-bold" style={{ color: COLORS.primary }}>
                        {nft.price}
                      </p>
                    </div>
                    <div className="flex items-center gap-1 text-neutral-500">
                      <Heart className="w-3 h-3" />
                      <span className="text-xs">{nft.likes}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>

      <ElevatorTravel currentFloor="789" onExitPatch={onExitPatch} />
    </div>
  )
}
