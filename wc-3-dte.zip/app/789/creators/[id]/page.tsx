"use client"

import { useRouter, useParams } from "next/navigation"
import { useState } from "react"
import { ArrowLeft, Star, Play, Calendar, MapPin, LinkIcon, Share2, MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"

const STUDIO_COLORS = {
  primary: "#FFD700",
  secondary: "#FFA500",
  accent: "#FF6B00",
  dark: "#0D0800",
  glow: "rgba(255, 215, 0, 0.5)",
}

// Mock creator data - in production this would come from database
const CREATORS_DATA: Record<string, any> = {
  "echo-engineer-1": {
    name: "ECHO//ENGINEER",
    handle: "@echo_eng",
    type: "Filmmaker",
    avatar: "/cyberpunk-filmmaker-avatar-neon.jpg",
    banner: "/placeholder.svg?height=600&width=1200",
    followers: "12.4K",
    following: "234",
    projects: 24,
    rating: 4.9,
    verified: true,
    bio: "Crafting neural narratives through digital cinema. WIRED CHAOS certified filmmaker specializing in sci-fi and thriller genres. Currently leading production on NEURAL DRIFT.",
    location: "Neo Tokyo",
    joined: "2023",
    website: "echoeng.xyz",
    socials: { twitter: "@echo_eng", instagram: "@echoengineering" },
    stats: { views: "2.4M", earnings: "45.2 ETH", awards: 7 },
    works: [
      {
        id: 1,
        title: "NEURAL DRIFT",
        type: "Feature Film",
        thumbnail: "/sci-fi-neural-movie-poster-dark.jpg",
        views: "1.2M",
      },
      {
        id: 2,
        title: "CHAOS THEORY S1",
        type: "Series",
        thumbnail: "/cyberpunk-series-poster-neon.jpg",
        views: "890K",
      },
      {
        id: 3,
        title: "ECHO CHAMBERS",
        type: "Short Film",
        thumbnail: "/placeholder.svg?height=300&width=400",
        views: "234K",
      },
    ],
  },
  "signal-wave-2": {
    name: "SIGNAL//WAVE",
    handle: "@signalwave",
    type: "Musician",
    avatar: "/electronic-musician-avatar-dark.jpg",
    banner: "/placeholder.svg?height=600&width=1200",
    followers: "8.7K",
    following: "156",
    projects: 45,
    rating: 4.8,
    verified: true,
    bio: "Electronic soundscapes for the post-digital age. 789 Audio Labs resident composer. Creating immersive audio experiences for film, games, and the metaverse.",
    location: "Berlin",
    joined: "2022",
    website: "signalwave.audio",
    socials: { twitter: "@signalwave", instagram: "@signalwave_music" },
    stats: { views: "1.8M", earnings: "32.1 ETH", awards: 4 },
    works: [
      {
        id: 1,
        title: "NEURAL DRIFT OST",
        type: "Soundtrack",
        thumbnail: "/placeholder.svg?height=300&width=400",
        views: "456K",
      },
      {
        id: 2,
        title: "AKASHIC FREQUENCIES",
        type: "Album",
        thumbnail: "/placeholder.svg?height=300&width=400",
        views: "678K",
      },
      { id: 3, title: "VOID AMBIENT", type: "EP", thumbnail: "/placeholder.svg?height=300&width=400", views: "234K" },
    ],
  },
}

export default function CreatorProfilePage() {
  const router = useRouter()
  const params = useParams()
  const creatorId = params.id as string
  const [isFollowing, setIsFollowing] = useState(false)

  // Get creator data or use default
  const creator = CREATORS_DATA[creatorId] || CREATORS_DATA["echo-engineer-1"]

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: STUDIO_COLORS.dark }}>
      {/* Gold Circuitry Background */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${STUDIO_COLORS.primary}15 1px, transparent 1px),
            linear-gradient(to bottom, ${STUDIO_COLORS.primary}15 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
        aria-hidden="true"
      />

      {/* Banner */}
      <div className="relative h-64 sm:h-80 overflow-hidden">
        <img src={creator.banner || "/placeholder.svg"} alt="" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />

        {/* Back button */}
        <button
          onClick={() => router.push("/789/creators")}
          className="absolute top-6 left-6 z-20 flex items-center gap-2 px-4 py-2 rounded-lg transition-all hover:scale-105"
          style={{
            background: "rgba(0, 0, 0, 0.8)",
            border: `1px solid ${STUDIO_COLORS.primary}40`,
            color: STUDIO_COLORS.primary,
          }}
          aria-label="Return to Creator Codex"
        >
          <ArrowLeft className="w-4 h-4" />
          <span className="font-mono text-sm uppercase">Creators</span>
        </button>
      </div>

      <main className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 -mt-20">
        {/* Profile Header */}
        <div className="flex flex-col sm:flex-row items-start gap-6 mb-8">
          {/* Avatar */}
          <div className="relative">
            <img
              src={creator.avatar || "/placeholder.svg"}
              alt={creator.name}
              className="w-32 h-32 sm:w-40 sm:h-40 rounded-full object-cover"
              style={{
                border: `4px solid ${STUDIO_COLORS.dark}`,
                boxShadow: `0 0 30px ${STUDIO_COLORS.glow}`,
              }}
            />
            {creator.verified && (
              <div
                className="absolute bottom-2 right-2 w-8 h-8 rounded-full flex items-center justify-center"
                style={{
                  background: STUDIO_COLORS.primary,
                  border: `3px solid ${STUDIO_COLORS.dark}`,
                }}
                aria-label="Verified creator"
              >
                <Star className="w-4 h-4 text-black fill-black" />
              </div>
            )}
          </div>

          {/* Info */}
          <div className="flex-1">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-4">
              <div>
                <h1
                  className="font-display text-3xl sm:text-4xl uppercase mb-1"
                  style={{
                    color: STUDIO_COLORS.primary,
                    textShadow: `0 0 20px ${STUDIO_COLORS.glow}`,
                  }}
                >
                  {creator.name}
                </h1>
                <p className="text-neutral-400">{creator.handle}</p>
              </div>

              <div className="flex items-center gap-3">
                <Button
                  onClick={() => setIsFollowing(!isFollowing)}
                  className="font-mono text-xs uppercase"
                  style={{
                    background: isFollowing ? "transparent" : STUDIO_COLORS.primary,
                    color: isFollowing ? STUDIO_COLORS.primary : "#000",
                    border: `1px solid ${STUDIO_COLORS.primary}`,
                  }}
                >
                  {isFollowing ? "Following" : "Follow"}
                </Button>
                <button
                  className="p-2 rounded-lg transition-colors hover:bg-white/10"
                  style={{ color: STUDIO_COLORS.primary }}
                  aria-label="Message creator"
                >
                  <MessageCircle className="w-5 h-5" />
                </button>
                <button
                  className="p-2 rounded-lg transition-colors hover:bg-white/10"
                  style={{ color: STUDIO_COLORS.primary }}
                  aria-label="Share profile"
                >
                  <Share2 className="w-5 h-5" />
                </button>
              </div>
            </div>

            <p className="text-neutral-300 mb-4 max-w-2xl">{creator.bio}</p>

            {/* Meta Info */}
            <div className="flex flex-wrap items-center gap-4 text-sm text-neutral-500">
              <span className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                {creator.location}
              </span>
              <span className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                Joined {creator.joined}
              </span>
              <a
                href={`https://${creator.website}`}
                className="flex items-center gap-1 hover:text-amber-500 transition-colors"
                target="_blank"
                rel="noopener noreferrer"
              >
                <LinkIcon className="w-4 h-4" />
                {creator.website}
              </a>
            </div>
          </div>
        </div>

        {/* Stats Row */}
        <div
          className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-xl mb-8"
          style={{
            background: "rgba(0, 0, 0, 0.6)",
            border: `1px solid ${STUDIO_COLORS.primary}20`,
          }}
        >
          <div className="text-center">
            <p className="font-display text-2xl" style={{ color: STUDIO_COLORS.primary }}>
              {creator.followers}
            </p>
            <p className="text-xs text-neutral-500 uppercase">Followers</p>
          </div>
          <div className="text-center">
            <p className="font-display text-2xl" style={{ color: STUDIO_COLORS.primary }}>
              {creator.projects}
            </p>
            <p className="text-xs text-neutral-500 uppercase">Projects</p>
          </div>
          <div className="text-center">
            <p className="font-display text-2xl" style={{ color: STUDIO_COLORS.primary }}>
              {creator.stats.views}
            </p>
            <p className="text-xs text-neutral-500 uppercase">Total Views</p>
          </div>
          <div className="text-center">
            <p className="font-display text-2xl" style={{ color: STUDIO_COLORS.primary }}>
              {creator.stats.awards}
            </p>
            <p className="text-xs text-neutral-500 uppercase">Awards</p>
          </div>
        </div>

        {/* Works Grid */}
        <section className="mb-12">
          <h2 className="font-mono text-sm uppercase tracking-wider mb-6" style={{ color: STUDIO_COLORS.secondary }}>
            Featured Works
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {creator.works.map((work: any) => (
              <div
                key={work.id}
                className="rounded-xl overflow-hidden transition-all duration-300 hover:scale-[1.02] cursor-pointer group"
                style={{
                  background: "rgba(0, 0, 0, 0.6)",
                  border: `1px solid ${STUDIO_COLORS.primary}20`,
                }}
              >
                <div className="relative aspect-video">
                  <img
                    src={work.thumbnail || "/placeholder.svg"}
                    alt={work.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <div
                      className="w-14 h-14 rounded-full flex items-center justify-center"
                      style={{
                        background: STUDIO_COLORS.primary,
                        boxShadow: `0 0 30px ${STUDIO_COLORS.glow}`,
                      }}
                    >
                      <Play className="w-6 h-6 text-black ml-1" />
                    </div>
                  </div>
                </div>
                <div className="p-4">
                  <span
                    className="px-2 py-0.5 rounded text-xs font-mono mb-2 inline-block"
                    style={{
                      background: `${STUDIO_COLORS.primary}20`,
                      color: STUDIO_COLORS.primary,
                    }}
                  >
                    {work.type}
                  </span>
                  <h3 className="font-display text-lg text-white group-hover:text-amber-500 transition-colors">
                    {work.title}
                  </h3>
                  <p className="text-neutral-500 text-sm mt-1">{work.views} views</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  )
}
