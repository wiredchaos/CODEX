"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  ArrowLeft,
  Users,
  Star,
  Play,
  Film,
  Music,
  Camera,
  Palette,
  Code,
  Sparkles,
  ExternalLink,
  Heart,
  Share2,
} from "lucide-react"
import { Button } from "@/components/ui/button"

const STUDIO_COLORS = {
  primary: "#FFD700",
  secondary: "#FFA500",
  accent: "#FF6B00",
  dark: "#0D0800",
  glow: "rgba(255, 215, 0, 0.5)",
}

const CREATOR_TYPES = [
  { id: "all", label: "All Creators", icon: Users },
  { id: "filmmaker", label: "Filmmakers", icon: Film },
  { id: "musician", label: "Musicians", icon: Music },
  { id: "photographer", label: "Photographers", icon: Camera },
  { id: "artist", label: "Digital Artists", icon: Palette },
  { id: "developer", label: "Developers", icon: Code },
]

const CREATORS = [
  {
    id: "echo-engineer-1",
    name: "ECHO//ENGINEER",
    handle: "@echo_eng",
    type: "filmmaker",
    avatar: "/cyberpunk-filmmaker-avatar-neon.jpg",
    banner: "/cyberpunk-film-set-neon-lights.jpg",
    followers: "12.4K",
    projects: 24,
    rating: 4.9,
    verified: true,
    bio: "Crafting neural narratives through digital cinema. WIRED CHAOS certified.",
    featured: ["NEURAL DRIFT", "CHAOS THEORY S1"],
  },
  {
    id: "signal-wave-2",
    name: "SIGNAL//WAVE",
    handle: "@signalwave",
    type: "musician",
    avatar: "/electronic-musician-avatar-dark.jpg",
    banner: "/music-studio-synthesizers-dark.jpg",
    followers: "8.7K",
    projects: 45,
    rating: 4.8,
    verified: true,
    bio: "Electronic soundscapes for the post-digital age. 789 Audio Labs resident.",
    featured: ["NEURAL DRIFT OST", "AKASHIC FREQUENCIES"],
  },
  {
    id: "pixel-forge-3",
    name: "PIXEL//FORGE",
    handle: "@pixelforge",
    type: "artist",
    avatar: "/digital-artist-avatar-glitch.jpg",
    banner: "/digital-art-studio-holographic.jpg",
    followers: "15.2K",
    projects: 89,
    rating: 4.7,
    verified: false,
    bio: "NFT architect and visual storyteller. Building worlds one pixel at a time.",
    featured: ["METAVERSE ORIGINS", "CHAOS COLLECTION"],
  },
  {
    id: "code-prophet-4",
    name: "CODE//PROPHET",
    handle: "@codeprophet",
    type: "developer",
    avatar: "/developer-avatar-matrix-code.jpg",
    banner: "/programming-code-terminal-dark.jpg",
    followers: "6.3K",
    projects: 12,
    rating: 4.9,
    verified: true,
    bio: "Building the infrastructure of tomorrow. Smart contracts & dApps.",
    featured: ["789 PROTOCOL", "CHAIN LINK"],
  },
  {
    id: "lens-hunter-5",
    name: "LENS//HUNTER",
    handle: "@lenshunter",
    type: "photographer",
    avatar: "/photographer-avatar-urban.jpg",
    banner: "/urban-photography-cityscape-night.jpg",
    followers: "21.8K",
    projects: 156,
    rating: 4.6,
    verified: true,
    bio: "Capturing the unseen frequencies of urban chaos. Documentary lens.",
    featured: ["UNDERGROUND SERIES", "CITY PULSE"],
  },
  {
    id: "nova-flux-6",
    name: "NOVA//FLUX",
    handle: "@novaflux",
    type: "filmmaker",
    avatar: "/placeholder.svg?height=200&width=200",
    banner: "/placeholder.svg?height=400&width=800",
    followers: "9.1K",
    projects: 18,
    rating: 4.8,
    verified: false,
    bio: "Narrative architect. Blending reality with simulation cinema.",
    featured: ["ECHO CHAMBERS", "VOID WALKER"],
  },
]

export default function CreatorsPage() {
  const router = useRouter()
  const [selectedType, setSelectedType] = useState("all")
  const [hoveredCreator, setHoveredCreator] = useState<string | null>(null)

  const filteredCreators = CREATORS.filter((creator) => selectedType === "all" || creator.type === selectedType)

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: STUDIO_COLORS.dark }}>
      {/* Gold Circuitry Background */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${STUDIO_COLORS.primary}15 1px, transparent 1px),
            linear-gradient(to bottom, ${STUDIO_COLORS.primary}15 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
        aria-hidden="true"
      />

      {/* Header */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(0, 0, 0, 0.9)",
          borderColor: `${STUDIO_COLORS.primary}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <button
                onClick={() => router.push("/789")}
                className="flex items-center gap-2 transition-colors hover:opacity-80"
                style={{ color: STUDIO_COLORS.primary }}
                aria-label="Return to 789 Lobby"
              >
                <ArrowLeft className="w-5 h-5" />
                <span className="font-mono text-sm uppercase hidden sm:inline">789 Lobby</span>
              </button>
              <div className="w-px h-6" style={{ background: `${STUDIO_COLORS.primary}30` }} aria-hidden="true" />
              <div className="flex items-center gap-2">
                <Sparkles className="w-6 h-6" style={{ color: STUDIO_COLORS.primary }} />
                <h1
                  className="font-display text-xl sm:text-2xl uppercase tracking-wider"
                  style={{
                    color: STUDIO_COLORS.primary,
                    textShadow: `0 0 20px ${STUDIO_COLORS.glow}`,
                  }}
                >
                  Creator Codex
                </h1>
              </div>
            </div>

            <Button
              variant="outline"
              className="font-mono text-xs uppercase bg-transparent"
              style={{
                borderColor: STUDIO_COLORS.primary,
                color: STUDIO_COLORS.primary,
              }}
            >
              <Users className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Apply</span>
            </Button>
          </div>

          {/* Filter Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2">
            {CREATOR_TYPES.map((type) => {
              const Icon = type.icon
              return (
                <button
                  key={type.id}
                  onClick={() => setSelectedType(type.id)}
                  className="flex items-center gap-2 px-4 py-2 rounded-full font-mono text-xs uppercase whitespace-nowrap transition-all"
                  style={{
                    background: selectedType === type.id ? STUDIO_COLORS.primary : "transparent",
                    color: selectedType === type.id ? "#000" : "#999",
                    border: `1px solid ${selectedType === type.id ? STUDIO_COLORS.primary : "#333"}`,
                  }}
                  aria-pressed={selectedType === type.id}
                >
                  <Icon className="w-4 h-4" />
                  {type.label}
                </button>
              )
            })}
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        {/* Creator Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCreators.map((creator) => (
            <div
              key={creator.id}
              className="rounded-xl overflow-hidden transition-all duration-300 hover:scale-[1.02] cursor-pointer group"
              style={{
                background: "rgba(0, 0, 0, 0.6)",
                border: `1px solid ${hoveredCreator === creator.id ? STUDIO_COLORS.primary : STUDIO_COLORS.primary + "30"}`,
                boxShadow: hoveredCreator === creator.id ? `0 0 30px ${STUDIO_COLORS.glow}` : "none",
              }}
              onMouseEnter={() => setHoveredCreator(creator.id)}
              onMouseLeave={() => setHoveredCreator(null)}
              onClick={() => router.push(`/789/creators/${creator.id}`)}
              role="article"
              aria-label={`View ${creator.name}'s profile`}
            >
              {/* Banner */}
              <div className="relative h-32 overflow-hidden">
                <img
                  src={creator.banner || "/placeholder.svg"}
                  alt=""
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />

                {/* Play button overlay */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center"
                    style={{
                      background: STUDIO_COLORS.primary,
                      boxShadow: `0 0 30px ${STUDIO_COLORS.glow}`,
                    }}
                  >
                    <Play className="w-5 h-5 text-black ml-0.5" />
                  </div>
                </div>
              </div>

              {/* Avatar */}
              <div className="relative px-4 -mt-10">
                <div className="relative inline-block">
                  <img
                    src={creator.avatar || "/placeholder.svg"}
                    alt={creator.name}
                    className="w-20 h-20 rounded-full object-cover"
                    style={{
                      border: `3px solid ${STUDIO_COLORS.dark}`,
                      boxShadow: `0 0 20px ${STUDIO_COLORS.glow}`,
                    }}
                  />
                  {creator.verified && (
                    <div
                      className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center"
                      style={{
                        background: STUDIO_COLORS.primary,
                        border: `2px solid ${STUDIO_COLORS.dark}`,
                      }}
                      aria-label="Verified creator"
                    >
                      <Star className="w-3 h-3 text-black fill-black" />
                    </div>
                  )}
                </div>
              </div>

              {/* Content */}
              <div className="p-4 pt-2">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3
                      className="font-display text-lg uppercase group-hover:text-white transition-colors"
                      style={{ color: STUDIO_COLORS.primary }}
                    >
                      {creator.name}
                    </h3>
                    <p className="text-neutral-500 text-sm">{creator.handle}</p>
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-amber-500 text-amber-500" />
                    <span className="text-sm text-neutral-400">{creator.rating}</span>
                  </div>
                </div>

                <p className="text-neutral-400 text-sm mb-4 line-clamp-2">{creator.bio}</p>

                {/* Stats */}
                <div className="flex items-center justify-between text-xs text-neutral-500 mb-4">
                  <span>{creator.followers} followers</span>
                  <span>{creator.projects} projects</span>
                </div>

                {/* Featured Works */}
                <div className="flex flex-wrap gap-2">
                  {creator.featured.map((work, i) => (
                    <span
                      key={i}
                      className="px-2 py-1 rounded text-xs"
                      style={{
                        background: `${STUDIO_COLORS.primary}15`,
                        color: STUDIO_COLORS.secondary,
                      }}
                    >
                      {work}
                    </span>
                  ))}
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-neutral-800">
                  <div className="flex items-center gap-3">
                    <button
                      className="p-2 rounded-full transition-colors hover:bg-white/10"
                      style={{ color: STUDIO_COLORS.primary }}
                      aria-label="Like creator"
                    >
                      <Heart className="w-4 h-4" />
                    </button>
                    <button
                      className="p-2 rounded-full transition-colors hover:bg-white/10"
                      style={{ color: STUDIO_COLORS.primary }}
                      aria-label="Share creator"
                    >
                      <Share2 className="w-4 h-4" />
                    </button>
                  </div>
                  <button
                    className="flex items-center gap-1 text-xs uppercase font-mono transition-colors hover:opacity-80"
                    style={{ color: STUDIO_COLORS.primary }}
                  >
                    View Profile
                    <ExternalLink className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}
