"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Radio, Users, Headphones, ExternalLink, Play, Pause, Volume2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { LiveCircuitry } from "@/components/live-circuitry"
import { LiquidGlassWrapper } from "@/components/liquid-glass-wrapper"

interface CryptoSpace {
  id: string
  title: string
  host: string
  hostHandle: string
  listeners: number
  isLive: boolean
  scheduledTime?: string
  topics: string[]
  xSpaceUrl: string
}

const CRYPTO_SPACES: CryptoSpace[] = [
  {
    id: "1",
    title: "WIRED CHAOS Weekly - Alpha Signals",
    host: "NEURO META X",
    hostHandle: "@neurometax",
    listeners: 847,
    isLive: true,
    topics: ["Crypto", "NFTs", "DOGE", "Web3"],
    xSpaceUrl: "https://x.com/i/spaces/1vOxwMBnNbVGB",
  },
  {
    id: "2",
    title: "789 Studios Creator Call",
    host: "SIGNAL GHOST",
    hostHandle: "@signalghost",
    listeners: 0,
    isLive: false,
    scheduledTime: "Tomorrow 8PM EST",
    topics: ["Content", "Monetization", "OTT"],
    xSpaceUrl: "https://x.com/i/spaces/example2",
  },
  {
    id: "3",
    title: "Dogechain DeFi Deep Dive",
    host: "CIPHER LENS",
    hostHandle: "@cipherlens",
    listeners: 0,
    isLive: false,
    scheduledTime: "Friday 6PM EST",
    topics: ["DeFi", "Dogechain", "Yield"],
    xSpaceUrl: "https://x.com/i/spaces/example3",
  },
]

const SPOTIFY_PLAYLIST = "2VwOYrB1C93gNIPiBZNxhH"
const X_COMMUNITY = "https://x.com/i/communities/1956818120120656211"

export default function CryptoSpacesPage() {
  const [isPlaying, setIsPlaying] = useState(false)

  return (
    <div className="min-h-screen bg-black text-white relative overflow-hidden">
      <LiveCircuitry />

      {/* Header */}
      <header className="relative z-10 border-b border-white/10 bg-black/50 backdrop-blur-xl">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/789">
              <Button variant="ghost" size="sm" className="text-white/70 hover:text-white">
                <ArrowLeft className="w-4 h-4 mr-2" />
                789 Studios
              </Button>
            </Link>
            <div className="h-6 w-px bg-white/20" />
            <div className="flex items-center gap-2">
              <Radio className="w-5 h-5 text-cyan-500" />
              <span className="font-bold text-lg">Crypto Spaces Network</span>
            </div>
          </div>

          <a href={X_COMMUNITY} target="_blank" rel="noopener noreferrer">
            <Button
              variant="outline"
              size="sm"
              className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10 bg-transparent"
            >
              <Users className="w-4 h-4 mr-2" />
              Join Community
              <ExternalLink className="w-3 h-3 ml-2" />
            </Button>
          </a>
        </div>
      </header>

      <main className="relative z-10 container mx-auto px-4 py-8">
        {/* 33.3FM Radio Section */}
        <LiquidGlassWrapper variant="panel" glow="blue" className="p-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
                  <Headphones className="w-6 h-6 text-white" />
                </div>
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full animate-pulse" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">33.3FM DOGECHAIN</h2>
                <p className="text-sm text-white/60">Live Radio · Crypto Beats</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <Button onClick={() => setIsPlaying(!isPlaying)} className="bg-blue-600 hover:bg-blue-700">
                {isPlaying ? (
                  <>
                    <Pause className="w-4 h-4 mr-2" />
                    Pause
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Listen Live
                  </>
                )}
              </Button>
              <Volume2 className="w-5 h-5 text-white/50" />
            </div>
          </div>

          {/* Spotify Embed */}
          <div className="rounded-xl overflow-hidden">
            <iframe
              src={`https://open.spotify.com/embed/playlist/${SPOTIFY_PLAYLIST}?utm_source=generator&theme=0`}
              width="100%"
              height="152"
              frameBorder="0"
              allowFullScreen
              allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
              loading="lazy"
              className="rounded-xl"
            />
          </div>
        </LiquidGlassWrapper>

        {/* Live Spaces */}
        <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
          <Radio className="w-6 h-6 text-cyan-500" />
          Live & Upcoming Spaces
        </h2>

        <div className="grid gap-4">
          {CRYPTO_SPACES.map((space) => (
            <LiquidGlassWrapper key={space.id} variant="card" glow={space.isLive ? "cyan" : "none"} className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    {space.isLive ? (
                      <Badge className="bg-red-500 text-white animate-pulse">
                        <Radio className="w-3 h-3 mr-1" />
                        LIVE
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="border-white/30 text-white/70">
                        Scheduled
                      </Badge>
                    )}
                    <span className="text-sm text-white/60">{space.hostHandle}</span>
                  </div>

                  <h3 className="text-xl font-bold text-white mb-2">{space.title}</h3>

                  <div className="flex items-center gap-4 mb-3">
                    <span className="text-sm text-white/70">Hosted by {space.host}</span>
                    {space.isLive && (
                      <span className="text-sm text-cyan-400 flex items-center gap-1">
                        <Users className="w-4 h-4" />
                        {space.listeners.toLocaleString()} listening
                      </span>
                    )}
                    {!space.isLive && space.scheduledTime && (
                      <span className="text-sm text-amber-400">{space.scheduledTime}</span>
                    )}
                  </div>

                  <div className="flex gap-2 flex-wrap">
                    {space.topics.map((topic) => (
                      <Badge key={topic} variant="outline" className="border-white/20 text-white/60 text-xs">
                        #{topic}
                      </Badge>
                    ))}
                  </div>
                </div>

                <a href={space.xSpaceUrl} target="_blank" rel="noopener noreferrer">
                  <Button
                    className={
                      space.isLive ? "bg-cyan-600 hover:bg-cyan-700" : "bg-white/10 hover:bg-white/20 text-white"
                    }
                  >
                    {space.isLive ? "Join Space" : "Set Reminder"}
                    <ExternalLink className="w-4 h-4 ml-2" />
                  </Button>
                </a>
              </div>
            </LiquidGlassWrapper>
          ))}
        </div>
      </main>
    </div>
  )
}
