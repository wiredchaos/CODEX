"use client"

import { useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { ArrowLeft, Star, Clock, Calendar, Share2, Heart, Plus, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { VideoPlayer } from "@/components/video-player"

const STUDIO_COLORS = {
  primary: "#FFD700",
  secondary: "#FFA500",
  accent: "#FF6B00",
  dark: "#0D0800",
  glow: "rgba(255, 215, 0, 0.5)",
}

const VIDEO_DATABASE: Record<
  string,
  {
    id: string
    title: string
    type: string
    duration: string
    rating: number
    year: number
    genre: string[]
    description: string
    videoUrl: string
    poster: string
    cast: { name: string; role: string }[]
    director: string
    related: string[]
  }
> = {
  "1": {
    id: "1",
    title: "NEURAL DRIFT",
    type: "Film",
    duration: "2h 14m",
    rating: 4.8,
    year: 2024,
    genre: ["Sci-Fi", "Thriller", "Drama"],
    description:
      "In a world where consciousness can be uploaded to the cloud, one hacker discovers the dark truth behind the system. As she delves deeper into the neural network, she uncovers a conspiracy that threatens to erase human free will forever.",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    poster: "/sci-fi-neural-movie-poster-dark-cyberpunk.jpg",
    cast: [
      { name: "Maya Chen", role: "Aria" },
      { name: "Marcus Webb", role: "Director Vance" },
      { name: "Luna Torres", role: "Echo" },
    ],
    director: "Kai Nakamura",
    related: ["2", "5"],
  },
  "2": {
    id: "2",
    title: "CHAOS THEORY",
    type: "Series",
    duration: "S1 • 8 Episodes",
    rating: 4.9,
    year: 2024,
    genre: ["Drama", "Sci-Fi", "Mystery"],
    description:
      "When a quantum physicist discovers that reality itself is breaking down, she must race against time to prevent the collapse of the multiverse.",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    poster: "/cyberpunk-series-chaos-theory-neon-lights.jpg",
    cast: [
      { name: "Sarah Blake", role: "Dr. Quinn" },
      { name: "James Morton", role: "Agent Cross" },
    ],
    director: "789 Studios",
    related: ["1", "4"],
  },
  "3": {
    id: "3",
    title: "THE WIRE PROTOCOL",
    type: "Documentary",
    duration: "1h 45m",
    rating: 4.6,
    year: 2023,
    genre: ["Documentary", "Technology"],
    description: "An in-depth exploration of the technology behind the WIRED CHAOS META network.",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    poster: "/documentary-tech-circuits-cables.jpg",
    cast: [],
    director: "789 Docs",
    related: ["6"],
  },
  "4": {
    id: "4",
    title: "AKASHIC RECORDS",
    type: "Series",
    duration: "S2 • 10 Episodes",
    rating: 4.7,
    year: 2024,
    genre: ["Fantasy", "Mystery", "Drama"],
    description:
      "The ancient library holds all knowledge that ever was and ever will be. But some secrets were never meant to be found.",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
    poster: "/mystical-series-ancient-knowledge.jpg",
    cast: [
      { name: "Amara Okonkwo", role: "The Keeper" },
      { name: "Ravi Sharma", role: "The Seeker" },
    ],
    director: "789 Studios",
    related: ["2", "3"],
  },
  "5": {
    id: "5",
    title: "789 UNDERGROUND",
    type: "Film",
    duration: "1h 58m",
    rating: 4.5,
    year: 2024,
    genre: ["Thriller", "Action", "Drama"],
    description:
      "Beneath the neon-lit streets lies a world of hackers, rebels, and revolutionaries. When the system marks them for deletion, they fight back.",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
    poster: "/underground-thriller-urban-dark.jpg",
    cast: [
      { name: "Zeke Williams", role: "Ghost" },
      { name: "Nina Reyes", role: "Cipher" },
    ],
    director: "Kai Nakamura",
    related: ["1", "2"],
  },
  "6": {
    id: "6",
    title: "METAVERSE ORIGINS",
    type: "Documentary",
    duration: "2h 05m",
    rating: 4.4,
    year: 2023,
    genre: ["Documentary", "Technology", "History"],
    description: "The untold story of how the metaverse was built, and the visionaries who made it possible.",
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
    poster: "/metaverse-virtual-reality-futuristic.jpg",
    cast: [],
    director: "789 Docs",
    related: ["3"],
  },
}

export default function VideoPage() {
  const params = useParams()
  const router = useRouter()
  const videoId = params.videoId as string
  const video = VIDEO_DATABASE[videoId]
  const [isInWatchlist, setIsInWatchlist] = useState(false)
  const [isLiked, setIsLiked] = useState(false)

  if (!video) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: STUDIO_COLORS.dark }}>
        <div className="text-center">
          <h1 className="text-2xl text-white mb-4">Content Not Found</h1>
          <Button onClick={() => router.push("/789/ott")} style={{ background: STUDIO_COLORS.primary, color: "#000" }}>
            Return to Library
          </Button>
        </div>
      </div>
    )
  }

  const relatedVideos = video.related.map((id) => VIDEO_DATABASE[id]).filter(Boolean)

  return (
    <div className="min-h-screen" style={{ backgroundColor: STUDIO_COLORS.dark }}>
      {/* Header */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl border-b"
        style={{ background: "rgba(0,0,0,0.9)", borderColor: `${STUDIO_COLORS.primary}30` }}
      >
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center gap-4">
          <button
            onClick={() => router.push("/789/ott")}
            className="flex items-center gap-2 transition-colors hover:opacity-80"
            style={{ color: STUDIO_COLORS.primary }}
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="font-mono text-sm uppercase hidden sm:inline">Back</span>
          </button>
          <div className="w-px h-6" style={{ background: `${STUDIO_COLORS.primary}30` }} />
          <h1 className="font-display text-lg uppercase truncate" style={{ color: STUDIO_COLORS.primary }}>
            {video.title}
          </h1>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        {/* Video Player */}
        <div className="mb-8">
          <VideoPlayer src={video.videoUrl} poster={video.poster} title={video.title} />
        </div>

        {/* Video Info */}
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            {/* Title & Meta */}
            <div>
              <div className="flex items-center gap-3 mb-2">
                <span
                  className="px-2 py-0.5 rounded text-xs font-mono"
                  style={{ background: `${STUDIO_COLORS.primary}20`, color: STUDIO_COLORS.primary }}
                >
                  {video.type}
                </span>
                {video.genre.map((g) => (
                  <span key={g} className="text-xs text-neutral-500">
                    {g}
                  </span>
                ))}
              </div>
              <h1 className="font-display text-3xl sm:text-4xl text-white mb-3">{video.title}</h1>
              <div className="flex flex-wrap items-center gap-4 text-neutral-400 text-sm">
                <span className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-amber-500 text-amber-500" />
                  {video.rating}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {video.duration}
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  {video.year}
                </span>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-wrap gap-3">
              <Button
                onClick={() => setIsInWatchlist(!isInWatchlist)}
                variant="outline"
                className="border-neutral-700 hover:border-amber-500"
              >
                <Plus className={`w-4 h-4 mr-2 ${isInWatchlist ? "rotate-45" : ""}`} />
                {isInWatchlist ? "In Watchlist" : "Add to Watchlist"}
              </Button>
              <Button
                onClick={() => setIsLiked(!isLiked)}
                variant="outline"
                className="border-neutral-700 hover:border-amber-500"
              >
                <Heart className={`w-4 h-4 mr-2 ${isLiked ? "fill-red-500 text-red-500" : ""}`} />
                Like
              </Button>
              <Button variant="outline" className="border-neutral-700 hover:border-amber-500 bg-transparent">
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </Button>
            </div>

            {/* Description */}
            <div>
              <h2 className="font-mono text-sm uppercase text-neutral-500 mb-2">Synopsis</h2>
              <p className="text-neutral-300 leading-relaxed">{video.description}</p>
            </div>

            {/* Cast */}
            {video.cast.length > 0 && (
              <div>
                <h2 className="font-mono text-sm uppercase text-neutral-500 mb-3">Cast</h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {video.cast.map((member) => (
                    <div key={member.name} className="p-3 rounded-lg" style={{ background: "rgba(255,255,255,0.05)" }}>
                      <p className="text-white text-sm">{member.name}</p>
                      <p className="text-neutral-500 text-xs">{member.role}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Crew */}
            <div>
              <h2 className="font-mono text-sm uppercase text-neutral-500 mb-2">Director</h2>
              <p className="text-white">{video.director}</p>
            </div>
          </div>

          {/* Related Content */}
          <div>
            <h2 className="font-mono text-sm uppercase text-neutral-500 mb-4">Related Content</h2>
            <div className="space-y-4">
              {relatedVideos.map((related) => (
                <div
                  key={related.id}
                  onClick={() => router.push(`/789/ott/${related.id}`)}
                  className="flex gap-3 p-2 rounded-lg cursor-pointer transition-colors hover:bg-white/5"
                  style={{ border: `1px solid ${STUDIO_COLORS.primary}20` }}
                >
                  <img
                    src={related.poster || "/placeholder.svg"}
                    alt={related.title}
                    className="w-24 h-16 object-cover rounded"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm truncate">{related.title}</p>
                    <p className="text-neutral-500 text-xs">
                      {related.type} • {related.duration}
                    </p>
                    <div className="flex items-center gap-1 mt-1">
                      <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                      <span className="text-xs text-neutral-400">{related.rating}</span>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-neutral-500 self-center" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
