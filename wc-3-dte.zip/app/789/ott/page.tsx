"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Play, Tv, Clock, Star, TrendingUp, Grid, List, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

const STUDIO_COLORS = {
  primary: "#FFD700",
  secondary: "#FFA500",
  accent: "#FF6B00",
  dark: "#0D0800",
  glow: "rgba(255, 215, 0, 0.5)",
}

const CONTENT_LIBRARY = [
  {
    id: "1",
    title: "NEURAL DRIFT",
    type: "Film",
    duration: "2h 14m",
    rating: 4.8,
    thumbnail: "/sci-fi-neural-movie-poster-dark-cyberpunk.jpg",
    genre: "Sci-Fi",
  },
  {
    id: "2",
    title: "CHAOS THEORY",
    type: "Series",
    duration: "S1 • 8 Episodes",
    rating: 4.9,
    thumbnail: "/cyberpunk-series-chaos-theory-neon-lights.jpg",
    genre: "Drama",
  },
  {
    id: "3",
    title: "THE WIRE PROTOCOL",
    type: "Documentary",
    duration: "1h 45m",
    rating: 4.6,
    thumbnail: "/documentary-tech-circuits-cables.jpg",
    genre: "Documentary",
  },
  {
    id: "4",
    title: "AKASHIC RECORDS",
    type: "Series",
    duration: "S2 • 10 Episodes",
    rating: 4.7,
    thumbnail: "/mystical-series-ancient-knowledge.jpg",
    genre: "Fantasy",
  },
  {
    id: "5",
    title: "789 UNDERGROUND",
    type: "Film",
    duration: "1h 58m",
    rating: 4.5,
    thumbnail: "/underground-thriller-urban-dark.jpg",
    genre: "Thriller",
  },
  {
    id: "6",
    title: "METAVERSE ORIGINS",
    type: "Documentary",
    duration: "2h 05m",
    rating: 4.4,
    thumbnail: "/metaverse-virtual-reality-futuristic.jpg",
    genre: "Documentary",
  },
]

const GENRES = [
  { value: "All", label: "All" },
  { value: "Sci-Fi", label: "Sci-Fi" },
  { value: "Drama", label: "Drama" },
  { value: "Documentary", label: "Docs" },
  { value: "Fantasy", label: "Fantasy" },
  { value: "Thriller", label: "Thriller" },
]

export default function OTTPage() {
  const router = useRouter()
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [selectedGenre, setSelectedGenre] = useState("All")
  const [searchQuery, setSearchQuery] = useState("")

  const filteredContent = CONTENT_LIBRARY.filter((item) => {
    const matchesGenre = selectedGenre === "All" || item.genre === selectedGenre
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesGenre && matchesSearch
  })

  const handleVideoClick = (videoId: string) => {
    router.push(`/789/ott/${videoId}`)
  }

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: STUDIO_COLORS.dark }}>
      {/* Gold Circuitry Background */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${STUDIO_COLORS.primary}15 1px, transparent 1px),
            linear-gradient(to bottom, ${STUDIO_COLORS.primary}15 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Header */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(0, 0, 0, 0.9)",
          borderColor: `${STUDIO_COLORS.primary}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3 sm:gap-4">
              <button
                onClick={() => router.push("/789")}
                className="flex items-center gap-2 transition-colors hover:opacity-80"
                style={{ color: STUDIO_COLORS.primary }}
              >
                <ArrowLeft className="w-5 h-5" />
                <span className="font-mono text-xs sm:text-sm uppercase hidden sm:inline">789 Lobby</span>
              </button>
              <div className="w-px h-6" style={{ background: `${STUDIO_COLORS.primary}30` }} />
              <div className="flex items-center gap-2">
                <Tv className="w-5 h-5 sm:w-6 sm:h-6" style={{ color: STUDIO_COLORS.primary }} />
                <h1
                  className="font-display text-xl sm:text-2xl uppercase tracking-wider"
                  style={{
                    color: STUDIO_COLORS.primary,
                    textShadow: `0 0 20px ${STUDIO_COLORS.glow}`,
                  }}
                >
                  789 OTT
                </h1>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setViewMode("grid")}
                className={`p-2 rounded-lg transition-colors ${viewMode === "grid" ? "bg-white/10" : ""}`}
                style={{ color: viewMode === "grid" ? STUDIO_COLORS.primary : "#666" }}
                aria-label="Grid view"
              >
                <Grid className="w-5 h-5" />
              </button>
              <button
                onClick={() => setViewMode("list")}
                className={`p-2 rounded-lg transition-colors ${viewMode === "list" ? "bg-white/10" : ""}`}
                style={{ color: viewMode === "list" ? STUDIO_COLORS.primary : "#666" }}
                aria-label="List view"
              >
                <List className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 sm:gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
              <Input
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-black/50 border-neutral-800 focus:border-amber-500 text-sm"
              />
            </div>
            <div className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto pb-2 sm:pb-0 scrollbar-hide">
              {GENRES.map((genre) => (
                <button
                  key={genre.value}
                  onClick={() => setSelectedGenre(genre.value)}
                  className="px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-full font-mono text-xs uppercase whitespace-nowrap transition-all flex-shrink-0"
                  style={{
                    background: selectedGenre === genre.value ? STUDIO_COLORS.primary : "transparent",
                    color: selectedGenre === genre.value ? "#000" : "#999",
                    border: `1px solid ${selectedGenre === genre.value ? STUDIO_COLORS.primary : "#333"}`,
                  }}
                >
                  {genre.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        {/* Featured Content */}
        <section className="mb-8 sm:mb-12">
          <div
            onClick={() => handleVideoClick("1")}
            className="relative rounded-2xl overflow-hidden h-[280px] sm:h-[400px] group cursor-pointer"
            style={{
              background: `linear-gradient(135deg, ${STUDIO_COLORS.dark}, #1a1a1a)`,
              border: `2px solid ${STUDIO_COLORS.primary}30`,
            }}
          >
            <img
              src="/sci-fi-neural-movie-poster-dark-cyberpunk.jpg"
              alt="Featured Content"
              className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:opacity-80 transition-opacity"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />

            <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-8">
              <span
                className="px-2 sm:px-3 py-1 rounded-full text-xs font-mono uppercase mb-3 sm:mb-4 inline-block"
                style={{
                  background: `${STUDIO_COLORS.primary}20`,
                  color: STUDIO_COLORS.primary,
                  border: `1px solid ${STUDIO_COLORS.primary}`,
                }}
              >
                Featured
              </span>
              <h2 className="font-display text-3xl sm:text-5xl text-white mb-2">NEURAL DRIFT</h2>
              <p className="text-sm sm:text-base text-neutral-400 mb-4 max-w-xl line-clamp-2 sm:line-clamp-none">
                In a world where consciousness can be uploaded, one hacker discovers the truth behind the system.
              </p>
              <div className="flex flex-wrap items-center gap-3 sm:gap-6">
                <Button
                  className="font-mono uppercase text-xs sm:text-sm"
                  style={{
                    background: STUDIO_COLORS.primary,
                    color: "#000",
                  }}
                >
                  <Play className="w-4 h-4 mr-2" />
                  Watch Now
                </Button>
                <div className="flex items-center gap-2 text-neutral-400">
                  <Clock className="w-4 h-4" />
                  <span className="text-xs sm:text-sm">2h 14m</span>
                </div>
                <div className="flex items-center gap-2 text-neutral-400">
                  <Star className="w-4 h-4 fill-amber-500 text-amber-500" />
                  <span className="text-xs sm:text-sm">4.8</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Content Grid */}
        <section>
          <div className="flex items-center justify-between mb-4 sm:mb-6">
            <h2
              className="font-mono text-xs sm:text-sm uppercase tracking-wider"
              style={{ color: STUDIO_COLORS.secondary }}
            >
              Library ({filteredContent.length})
            </h2>
            <div className="flex items-center gap-2 text-neutral-500">
              <TrendingUp className="w-4 h-4" />
              <span className="text-xs">Trending</span>
            </div>
          </div>

          <div
            className={`grid gap-4 sm:gap-6 ${viewMode === "grid" ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3" : "grid-cols-1"}`}
          >
            {filteredContent.map((item) => (
              <div
                key={item.id}
                onClick={() => handleVideoClick(item.id)}
                className={`group rounded-xl overflow-hidden transition-all duration-300 hover:scale-[1.02] cursor-pointer ${
                  viewMode === "list" ? "flex" : ""
                }`}
                style={{
                  background: "rgba(0, 0, 0, 0.6)",
                  border: `1px solid ${STUDIO_COLORS.primary}20`,
                }}
              >
                <div className={`relative ${viewMode === "list" ? "w-32 sm:w-48 flex-shrink-0" : "aspect-video"}`}>
                  <img
                    src={item.thumbnail || "/placeholder.svg"}
                    alt={item.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <div
                      className="w-12 h-12 sm:w-14 sm:h-14 rounded-full flex items-center justify-center"
                      style={{
                        background: STUDIO_COLORS.primary,
                        boxShadow: `0 0 30px ${STUDIO_COLORS.glow}`,
                      }}
                    >
                      <Play className="w-5 h-5 sm:w-6 sm:h-6 text-black ml-1" />
                    </div>
                  </div>
                </div>

                <div className="p-3 sm:p-4 flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span
                      className="px-2 py-0.5 rounded text-xs font-mono"
                      style={{
                        background: `${STUDIO_COLORS.primary}20`,
                        color: STUDIO_COLORS.primary,
                      }}
                    >
                      {item.type}
                    </span>
                    <span className="text-xs text-neutral-500">{item.genre}</span>
                  </div>
                  <h3
                    className="font-display text-base sm:text-lg uppercase group-hover:text-amber-500 transition-colors truncate"
                    style={{ color: "#fff" }}
                  >
                    {item.title}
                  </h3>
                  <div className="flex items-center gap-3 sm:gap-4 mt-2 text-neutral-500 text-xs sm:text-sm">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {item.duration}
                    </span>
                    <span className="flex items-center gap-1">
                      <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                      {item.rating}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  )
}
