"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  Film,
  Tv,
  Music,
  Users,
  Briefcase,
  Sparkles,
  ChevronRight,
  Play,
  Hexagon,
  Coins,
  ShoppingBag,
} from "lucide-react"
import { AnimatedVectors789 } from "@/components/789-animated-vectors"
import { ElevatorTravel, usePatchLifecycle } from "@/components/elevator-travel"

export default function Studio789Page() {
  const router = useRouter()
  const [selectedFloor, setSelectedFloor] = useState<string | null>(null)
  const [doorsOpen, setDoorsOpen] = useState(true)
  const [isTransitioning, setIsTransitioning] = useState(false)

  const STUDIO_COLORS = {
    primary: "#FFD700",
    secondary: "#FFA500",
    accent: "#FF6B00",
    dark: "#0D0800",
    glow: "rgba(255, 215, 0, 0.5)",
  }

  const FLOORS = [
    {
      id: "lobby",
      name: "789 LOBBY",
      level: "L",
      icon: Sparkles,
      description: "Main Entrance & Directory",
      route: "/789",
    },
    {
      id: "studios",
      name: "PRODUCTION STUDIOS",
      level: "1",
      icon: Film,
      description: "Film & Content Creation",
      route: "/789/studios",
    },
    { id: "ott", name: "789 OTT", level: "2", icon: Tv, description: "Streaming & Distribution", route: "/789/ott" },
    {
      id: "audio",
      name: "AUDIO LABS",
      level: "3",
      icon: Music,
      description: "Music & Sound Design",
      route: "/789/audio",
    },
    {
      id: "talent",
      name: "TALENT DIVISION",
      level: "4",
      icon: Users,
      description: "Creator Management & Booking",
      route: "/789/talent",
    },
    {
      id: "business",
      name: "BUSINESS SUITE",
      level: "5",
      icon: Briefcase,
      description: "Agentic Operations & Admin",
      route: "/789/business",
    },
    {
      id: "film3",
      name: "FILM3",
      level: "6",
      icon: Hexagon,
      description: "Decentralized Cinema & Token-Gating",
      route: "/film3",
    },
    {
      id: "nft",
      name: "NFT MARKETPLACE",
      level: "7",
      icon: ShoppingBag,
      description: "Digital Collectibles & IP Rights",
      route: "/789/nft-marketplace",
    },
    {
      id: "tokenomics",
      name: "TOKENOMICS",
      level: "8",
      icon: Coins,
      description: "$789 Token Economics",
      route: "/789/tokenomics",
    },
  ]

  const handleFloorSelect = (floor: (typeof FLOORS)[0]) => {
    if (isTransitioning || floor.id === "lobby") return

    setIsTransitioning(true)
    setDoorsOpen(false)

    setTimeout(() => {
      setSelectedFloor(floor.id)
      setTimeout(() => {
        router.push(floor.route)
      }, 400)
    }, 600)
  }

  const { onExitPatch } = usePatchLifecycle("patch_789_studios")

  return (
    <div className="min-h-screen relative overflow-hidden" style={{ backgroundColor: STUDIO_COLORS.dark }}>
      {/* 3D Animated Vectors Background */}
      <AnimatedVectors789 />

      {/* 789 Circuitry Background - Gold/Amber theme */}
      <div
        className="fixed inset-0 opacity-30 pointer-events-none z-[1]"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${STUDIO_COLORS.primary}15 1px, transparent 1px),
            linear-gradient(to bottom, ${STUDIO_COLORS.primary}15 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
        aria-hidden="true"
      />

      {/* Animated gold data packets */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-[2]" aria-hidden="true">
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 rounded-full"
            style={{
              background: i % 2 === 0 ? STUDIO_COLORS.primary : STUDIO_COLORS.secondary,
              boxShadow: `0 0 10px ${i % 2 === 0 ? STUDIO_COLORS.primary : STUDIO_COLORS.secondary}`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `studio-packet-${i % 4} ${3 + i * 0.5}s linear infinite`,
              animationDelay: `${i * 0.3}s`,
            }}
          />
        ))}
      </div>

      {/* Main Content */}
      <main className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 py-20">
        {/* 789 Logo */}
        <div className="text-center mb-12">
          <h1
            className="font-display text-7xl sm:text-8xl md:text-9xl font-bold tracking-tighter mb-2"
            style={{
              color: STUDIO_COLORS.primary,
              textShadow: `
                0 0 10px ${STUDIO_COLORS.primary},
                0 0 20px ${STUDIO_COLORS.primary},
                0 0 40px ${STUDIO_COLORS.primary},
                0 0 80px ${STUDIO_COLORS.secondary}
              `,
            }}
          >
            789
          </h1>
          <p
            className="font-mono text-base sm:text-lg uppercase tracking-[0.3em]"
            style={{ color: STUDIO_COLORS.secondary }}
          >
            Studios
          </p>
          <p className="mt-4 text-neutral-400 font-mono text-sm max-w-md mx-auto">
            Production Floor — WIRED CHAOS META Building
          </p>
        </div>

        {/* Elevator Interface */}
        <div
          className="relative w-full max-w-4xl rounded-2xl overflow-hidden"
          style={{
            background: "rgba(0, 0, 0, 0.9)",
            border: `2px solid ${STUDIO_COLORS.primary}30`,
            boxShadow: `0 0 60px ${STUDIO_COLORS.glow}, inset 0 0 30px rgba(0, 0, 0, 0.5)`,
          }}
          role="region"
          aria-label="Elevator floor selection"
        >
          {/* Elevator Doors Animation */}
          <div className="absolute inset-0 flex pointer-events-none z-20" aria-hidden="true">
            <div
              className="h-full transition-all duration-500 ease-in-out"
              style={{
                width: doorsOpen ? "0%" : "50%",
                background: `linear-gradient(90deg, ${STUDIO_COLORS.dark}, #1a1a1a)`,
                borderRight: `2px solid ${STUDIO_COLORS.primary}50`,
              }}
            />
            <div
              className="h-full transition-all duration-500 ease-in-out ml-auto"
              style={{
                width: doorsOpen ? "0%" : "50%",
                background: `linear-gradient(270deg, ${STUDIO_COLORS.dark}, #1a1a1a)`,
                borderLeft: `2px solid ${STUDIO_COLORS.primary}50`,
              }}
            />
          </div>

          {/* Floor Indicator */}
          <div
            className="flex items-center justify-between p-4 border-b"
            style={{ borderColor: `${STUDIO_COLORS.primary}30` }}
          >
            <div className="flex items-center gap-4">
              <div
                className="w-14 h-14 sm:w-16 sm:h-16 rounded-lg flex items-center justify-center font-display text-2xl sm:text-3xl font-bold"
                style={{
                  background: `${STUDIO_COLORS.primary}20`,
                  color: STUDIO_COLORS.primary,
                  boxShadow: `0 0 20px ${STUDIO_COLORS.glow}`,
                }}
                aria-live="polite"
              >
                {selectedFloor ? FLOORS.find((f) => f.id === selectedFloor)?.level : "L"}
              </div>
              <div>
                <p className="font-mono text-xs uppercase tracking-wider text-neutral-500">Current Floor</p>
                <p className="font-display text-lg sm:text-xl uppercase" style={{ color: STUDIO_COLORS.primary }}>
                  {selectedFloor ? FLOORS.find((f) => f.id === selectedFloor)?.name : "789 LOBBY"}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div
                className="w-3 h-3 rounded-full animate-pulse"
                style={{
                  background: isTransitioning ? STUDIO_COLORS.secondary : STUDIO_COLORS.primary,
                  boxShadow: `0 0 10px ${isTransitioning ? STUDIO_COLORS.secondary : STUDIO_COLORS.primary}`,
                }}
                aria-hidden="true"
              />
              <span className="font-mono text-xs uppercase" style={{ color: STUDIO_COLORS.secondary }}>
                {isTransitioning ? "IN TRANSIT" : "READY"}
              </span>
            </div>
          </div>

          {/* Floor Selection Grid */}
          <div className="p-4 sm:p-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {FLOORS.map((floor) => {
              const Icon = floor.icon
              const isSelected = selectedFloor === floor.id
              const isLobby = floor.id === "lobby"

              return (
                <button
                  key={floor.id}
                  onClick={() => handleFloorSelect(floor)}
                  disabled={isTransitioning || isLobby}
                  className="group relative p-4 sm:p-6 rounded-xl text-left transition-all duration-300 hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                  style={{
                    background: isSelected
                      ? `linear-gradient(135deg, ${STUDIO_COLORS.primary}20, ${STUDIO_COLORS.secondary}10)`
                      : "rgba(255, 255, 255, 0.02)",
                    border: `1px solid ${isSelected ? STUDIO_COLORS.primary : "rgba(255, 255, 255, 0.1)"}`,
                    boxShadow: isSelected ? `0 0 30px ${STUDIO_COLORS.glow}` : "none",
                  }}
                  aria-label={`Select ${floor.name}`}
                  aria-pressed={isSelected}
                >
                  {/* Hover glow effect */}
                  <div
                    className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 group-disabled:opacity-0 transition-opacity duration-300 pointer-events-none"
                    style={{
                      boxShadow: `inset 0 0 30px ${STUDIO_COLORS.glow}, 0 0 20px ${STUDIO_COLORS.glow}`,
                    }}
                    aria-hidden="true"
                  />

                  <div className="relative z-10">
                    <div className="flex items-center justify-between mb-3">
                      <div
                        className="w-10 h-10 rounded-lg flex items-center justify-center"
                        style={{
                          background: `${STUDIO_COLORS.primary}20`,
                          color: STUDIO_COLORS.primary,
                        }}
                      >
                        <Icon className="w-5 h-5" />
                      </div>
                      <span className="font-display text-2xl font-bold" style={{ color: STUDIO_COLORS.primary }}>
                        {floor.level}
                      </span>
                    </div>

                    <h3
                      className="font-mono text-sm uppercase tracking-wider mb-1 transition-colors"
                      style={{ color: isSelected ? STUDIO_COLORS.primary : "#ffffff" }}
                    >
                      {floor.name}
                    </h3>
                    <p className="text-xs text-neutral-500">{floor.description}</p>

                    {!isLobby && (
                      <ChevronRight
                        className="absolute bottom-4 sm:bottom-6 right-4 sm:right-6 w-5 h-5 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all"
                        style={{ color: STUDIO_COLORS.primary }}
                        aria-hidden="true"
                      />
                    )}
                  </div>
                </button>
              )
            })}
          </div>

          {/* Status Bar */}
          <div
            className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 border-t gap-4"
            style={{ borderColor: `${STUDIO_COLORS.primary}30` }}
          >
            <div className="flex items-center gap-4">
              <span className="font-mono text-xs text-neutral-500">ARG MODE</span>
              <div className="flex gap-1" role="img" aria-label="Signal strength 3 of 5">
                {[...Array(5)].map((_, i) => (
                  <div
                    key={i}
                    className="w-2 h-4 rounded-sm"
                    style={{
                      background: i < 3 ? STUDIO_COLORS.primary : "rgba(255, 255, 255, 0.1)",
                      boxShadow: i < 3 ? `0 0 5px ${STUDIO_COLORS.primary}` : "none",
                    }}
                  />
                ))}
              </div>
            </div>

            <div className="flex items-center gap-4">
              <span className="font-mono text-xs text-neutral-500">AGENTIC SUITE v1.0</span>
              <div
                className="px-3 py-1 rounded-full font-mono text-xs uppercase"
                style={{
                  background: `${STUDIO_COLORS.primary}20`,
                  color: STUDIO_COLORS.primary,
                  border: `1px solid ${STUDIO_COLORS.primary}40`,
                }}
              >
                Business Layer
              </div>
            </div>
          </div>
        </div>

        {/* 3D Vectors - Film/Production/Blockchain */}
        <div className="mt-12 flex items-center justify-center gap-6 sm:gap-8 flex-wrap">
          {/* Film Reel */}
          <div
            className="w-16 h-16 sm:w-20 sm:h-20 rounded-full flex items-center justify-center animate-spin-slow"
            style={{
              border: `3px solid ${STUDIO_COLORS.primary}`,
              boxShadow: `0 0 20px ${STUDIO_COLORS.glow}`,
            }}
            aria-hidden="true"
          >
            <Film className="w-6 h-6 sm:w-8 sm:h-8" style={{ color: STUDIO_COLORS.primary }} />
          </div>

          {/* Blockchain Cube */}
          <div
            className="w-14 h-14 sm:w-16 sm:h-16 relative animate-float"
            style={{
              transform: "perspective(500px) rotateX(15deg) rotateY(15deg)",
            }}
            aria-hidden="true"
          >
            <div
              className="absolute inset-0 rounded-lg"
              style={{
                background: `linear-gradient(135deg, ${STUDIO_COLORS.primary}40, ${STUDIO_COLORS.secondary}20)`,
                border: `2px solid ${STUDIO_COLORS.primary}`,
                boxShadow: `0 0 30px ${STUDIO_COLORS.glow}`,
              }}
            />
          </div>

          {/* Play Button */}
          <div
            className="w-14 h-14 sm:w-16 sm:h-16 rounded-full flex items-center justify-center animate-pulse"
            style={{
              background: `${STUDIO_COLORS.primary}20`,
              border: `2px solid ${STUDIO_COLORS.primary}`,
              boxShadow: `0 0 20px ${STUDIO_COLORS.glow}`,
            }}
            aria-hidden="true"
          >
            <Play className="w-5 h-5 sm:w-6 sm:h-6 ml-1" style={{ color: STUDIO_COLORS.primary }} />
          </div>
        </div>
      </main>

      <ElevatorTravel currentFloor="789" onExitPatch={onExitPatch} />

      {/* Custom Animations */}
      <style jsx>{`
        @keyframes studio-packet-0 {
          0% { transform: translate(0, 0); opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { transform: translate(100vw, 50vh); opacity: 0; }
        }
        @keyframes studio-packet-1 {
          0% { transform: translate(100vw, 0); opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { transform: translate(0, 100vh); opacity: 0; }
        }
        @keyframes studio-packet-2 {
          0% { transform: translate(50vw, 100vh); opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { transform: translate(0, 0); opacity: 0; }
        }
        @keyframes studio-packet-3 {
          0% { transform: translate(0, 50vh); opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { transform: translate(100vw, 0); opacity: 0; }
        }
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes float {
          0%, 100% { transform: perspective(500px) rotateX(15deg) rotateY(15deg) translateY(0); }
          50% { transform: perspective(500px) rotateX(15deg) rotateY(15deg) translateY(-10px); }
        }
        .animate-spin-slow {
          animation: spin-slow 8s linear infinite;
        }
        .animate-float {
          animation: float 3s ease-in-out infinite;
        }
      `}</style>
    </div>
  )
}
