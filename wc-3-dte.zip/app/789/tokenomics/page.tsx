"use client"

import { useRouter } from "next/navigation"
import { Coins, ChevronRight, PieChart, TrendingUp, Lock, Users, Zap, Shield } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { ElevatorTravel, usePatchLifecycle } from "@/components/elevator-travel"
import type React from "react"

const COLORS = {
  primary: "#FFD700",
  secondary: "#FFA500",
  dark: "#0A0A00",
}

const TOKEN_DISTRIBUTION = [
  { name: "Creator Rewards", percentage: 40, color: "#FFD700" },
  { name: "Platform Treasury", percentage: 25, color: "#FFA500" },
  { name: "Team & Advisors", percentage: 15, color: "#FF6B00" },
  { name: "Community Airdrop", percentage: 10, color: "#FFE066" },
  { name: "Liquidity Pool", percentage: 10, color: "#CC9900" },
]

const TOKEN_METRICS = [
  { label: "Total Supply", value: "1,000,000,000", subtext: "789 Tokens" },
  { label: "Circulating", value: "245,000,000", subtext: "24.5%" },
  { label: "Staked", value: "180,000,000", subtext: "18%" },
  { label: "Burned", value: "12,500,000", subtext: "1.25%" },
]

const UTILITY = [
  {
    icon: Shield,
    title: "Governance",
    description: "Vote on platform decisions, feature priorities, and fund allocation",
  },
  {
    icon: Coins,
    title: "Staking Rewards",
    description: "Earn 12-24% APY by staking tokens in creator pools",
  },
  {
    icon: Lock,
    title: "Access Tiers",
    description: "Unlock premium features, early access, and exclusive content",
  },
  {
    icon: Users,
    title: "Creator Tips",
    description: "Support creators directly with instant, low-fee transfers",
  },
  {
    icon: Zap,
    title: "Gas Subsidies",
    description: "Reduced transaction fees for token holders",
  },
  {
    icon: TrendingUp,
    title: "Revenue Share",
    description: "Earn a percentage of platform revenue based on holdings",
  },
]

export default function TokenomicsPage() {
  const router = useRouter()
  const { onExitPatch } = usePatchLifecycle("patch_789_tokenomics")

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: COLORS.dark }}>
      {/* Background */}
      <div
        className="fixed inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(circle at 50% 50%, ${COLORS.primary}30, transparent 70%)`,
        }}
      />

      {/* Header */}
      <header className="relative z-10 p-4 sm:p-6 border-b" style={{ borderColor: `${COLORS.primary}20` }}>
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <button
            onClick={() => router.push("/789")}
            className="flex items-center gap-2 text-neutral-400 hover:text-white transition-colors"
          >
            <ChevronRight className="w-4 h-4 rotate-180" />
            <span className="font-mono text-sm">Back to 789</span>
          </button>

          <h1 className="font-display text-xl font-bold flex items-center gap-2" style={{ color: COLORS.primary }}>
            <Coins className="w-5 h-5" />
            TOKENOMICS
          </h1>

          <div className="w-20" />
        </div>
      </header>

      <main className="relative z-10 p-4 sm:p-6 max-w-6xl mx-auto space-y-8">
        {/* Token Metrics */}
        <section>
          <h2 className="font-display text-2xl font-bold mb-6 text-white">$789 Token Metrics</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {TOKEN_METRICS.map((metric, i) => (
              <Card
                key={i}
                style={{
                  background: "rgba(0, 0, 0, 0.6)",
                  border: `1px solid ${COLORS.primary}20`,
                }}
              >
                <CardContent className="p-6 text-center">
                  <p className="font-mono text-xs uppercase tracking-wider text-neutral-500 mb-2">{metric.label}</p>
                  <p className="font-display text-2xl font-bold mb-1" style={{ color: COLORS.primary }}>
                    {metric.value}
                  </p>
                  <p className="text-xs text-neutral-400">{metric.subtext}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Distribution */}
        <section>
          <h2 className="font-display text-2xl font-bold mb-6 text-white">Token Distribution</h2>
          <Card
            style={{
              background: "rgba(0, 0, 0, 0.6)",
              border: `1px solid ${COLORS.primary}20`,
            }}
          >
            <CardContent className="p-6">
              <div className="grid md:grid-cols-2 gap-8">
                {/* Pie Chart Visualization */}
                <div className="flex items-center justify-center">
                  <div className="relative w-48 h-48">
                    <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                      {TOKEN_DISTRIBUTION.reduce((acc, item, i) => {
                        const prevTotal = TOKEN_DISTRIBUTION.slice(0, i).reduce((sum, d) => sum + d.percentage, 0)
                        const circumference = 2 * Math.PI * 40
                        const offset = (prevTotal / 100) * circumference
                        const length = (item.percentage / 100) * circumference
                        acc.push(
                          <circle
                            key={i}
                            cx="50"
                            cy="50"
                            r="40"
                            fill="transparent"
                            stroke={item.color}
                            strokeWidth="20"
                            strokeDasharray={`${length} ${circumference - length}`}
                            strokeDashoffset={-offset}
                          />,
                        )
                        return acc
                      }, [] as React.JSX.Element[])}
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <PieChart className="w-8 h-8" style={{ color: COLORS.primary }} />
                    </div>
                  </div>
                </div>

                {/* Legend */}
                <div className="space-y-4">
                  {TOKEN_DISTRIBUTION.map((item, i) => (
                    <div key={i} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-4 h-4 rounded" style={{ background: item.color }} />
                        <span className="font-mono text-sm text-white">{item.name}</span>
                      </div>
                      <span className="font-mono text-sm" style={{ color: COLORS.primary }}>
                        {item.percentage}%
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Utility */}
        <section>
          <h2 className="font-display text-2xl font-bold mb-6 text-white">Token Utility</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {UTILITY.map((item, i) => {
              const Icon = item.icon
              return (
                <Card
                  key={i}
                  className="group transition-all hover:scale-[1.02]"
                  style={{
                    background: "rgba(0, 0, 0, 0.6)",
                    border: `1px solid ${COLORS.primary}20`,
                  }}
                >
                  <CardContent className="p-6">
                    <div
                      className="w-10 h-10 rounded-lg flex items-center justify-center mb-4"
                      style={{ background: `${COLORS.primary}15`, color: COLORS.primary }}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    <h3 className="font-mono text-sm uppercase tracking-wider text-white mb-2">{item.title}</h3>
                    <p className="text-xs text-neutral-400 leading-relaxed">{item.description}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </section>

        {/* Vesting Schedule */}
        <section>
          <h2 className="font-display text-2xl font-bold mb-6 text-white">Vesting Schedule</h2>
          <Card
            style={{
              background: "rgba(0, 0, 0, 0.6)",
              border: `1px solid ${COLORS.primary}20`,
            }}
          >
            <CardContent className="p-6 space-y-6">
              {[
                { name: "Team Tokens", vested: 25, total: "150M", unlocked: "37.5M" },
                { name: "Advisor Tokens", vested: 40, total: "50M", unlocked: "20M" },
                { name: "Community Airdrop", vested: 100, total: "100M", unlocked: "100M" },
              ].map((item, i) => (
                <div key={i}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono text-sm text-white">{item.name}</span>
                    <span className="font-mono text-xs text-neutral-400">
                      {item.unlocked} / {item.total}
                    </span>
                  </div>
                  <Progress value={item.vested} className="h-2" style={{ background: `${COLORS.primary}20` }} />
                  <p className="text-xs text-neutral-500 mt-1">{item.vested}% vested</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </section>
      </main>

      <ElevatorTravel currentFloor="789" onExitPatch={onExitPatch} />
    </div>
  )
}
