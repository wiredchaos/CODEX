"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Users, Star, Calendar, Film, Music, Camera, Mic, Search, Filter, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

const STUDIO_COLORS = {
  primary: "#FFD700",
  secondary: "#FFA500",
  accent: "#FF6B00",
  dark: "#0D0800",
  glow: "rgba(255, 215, 0, 0.5)",
}

const TALENT_ROSTER = [
  {
    id: "echo-1",
    name: "Echo Martinez",
    role: "Director",
    specialty: "Sci-Fi / Thriller",
    rating: 4.9,
    projects: 12,
    availability: "available",
    avatar: "/film-director-portrait-professional.png",
    icon: Film,
  },
  {
    id: "nova-2",
    name: "Nova Chen",
    role: "Composer",
    specialty: "Electronic / Cinematic",
    rating: 4.8,
    projects: 28,
    availability: "busy",
    avatar: "/music-composer-portrait-professional.jpg",
    icon: Music,
  },
  {
    id: "kai-3",
    name: "Kai Thompson",
    role: "Cinematographer",
    specialty: "Visual Effects",
    rating: 4.7,
    projects: 15,
    availability: "available",
    avatar: "/cinematographer-portrait-professional.jpg",
    icon: Camera,
  },
  {
    id: "aria-4",
    name: "Aria Blackwood",
    role: "Voice Actor",
    specialty: "Animation / Games",
    rating: 4.9,
    projects: 45,
    availability: "available",
    avatar: "/voice-actor-portrait-professional.jpg",
    icon: Mic,
  },
  {
    id: "zeph-5",
    name: "Zeph Nakamura",
    role: "Producer",
    specialty: "Documentary",
    rating: 4.6,
    projects: 8,
    availability: "busy",
    avatar: "/film-producer-portrait-professional.jpg",
    icon: Film,
  },
  {
    id: "luna-6",
    name: "Luna Reyes",
    role: "Sound Designer",
    specialty: "Foley / Ambience",
    rating: 4.8,
    projects: 22,
    availability: "available",
    avatar: "/sound-designer-portrait-professional.jpg",
    icon: Music,
  },
]

const UPCOMING_BOOKINGS = [
  { id: 1, talent: "Echo Martinez", project: "NEURAL DRIFT", date: "Dec 15", time: "10:00 AM" },
  { id: 2, talent: "Nova Chen", project: "CHAOS THEORY S2", date: "Dec 16", time: "2:00 PM" },
  { id: 3, talent: "Aria Blackwood", project: "789 ORIGINALS", date: "Dec 18", time: "11:00 AM" },
]

const ROLES = ["All", "Director", "Composer", "Cinematographer", "Voice Actor", "Producer", "Sound Designer"]

export default function TalentDivisionPage() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedRole, setSelectedRole] = useState("All")
  const [selectedTalent, setSelectedTalent] = useState<string | null>(null)

  const filteredTalent = TALENT_ROSTER.filter((talent) => {
    const matchesRole = selectedRole === "All" || talent.role === selectedRole
    const matchesSearch = talent.name.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesRole && matchesSearch
  })

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: STUDIO_COLORS.dark }}>
      {/* Gold Circuitry Background */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${STUDIO_COLORS.primary}15 1px, transparent 1px),
            linear-gradient(to bottom, ${STUDIO_COLORS.primary}15 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
        aria-hidden="true"
      />

      {/* Header */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(0, 0, 0, 0.9)",
          borderColor: `${STUDIO_COLORS.primary}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <button
                onClick={() => router.push("/789")}
                className="flex items-center gap-2 transition-colors hover:opacity-80"
                style={{ color: STUDIO_COLORS.primary }}
                aria-label="Return to 789 Lobby"
              >
                <ArrowLeft className="w-5 h-5" />
                <span className="font-mono text-sm uppercase hidden sm:inline">789 Lobby</span>
              </button>
              <div className="w-px h-6" style={{ background: `${STUDIO_COLORS.primary}30` }} aria-hidden="true" />
              <div className="flex items-center gap-2">
                <Users className="w-6 h-6" style={{ color: STUDIO_COLORS.primary }} />
                <h1
                  className="font-display text-xl sm:text-2xl uppercase tracking-wider"
                  style={{
                    color: STUDIO_COLORS.primary,
                    textShadow: `0 0 20px ${STUDIO_COLORS.glow}`,
                  }}
                >
                  Talent Division
                </h1>
              </div>
            </div>

            <Button
              variant="outline"
              className="font-mono text-xs uppercase bg-transparent"
              style={{
                borderColor: STUDIO_COLORS.primary,
                color: STUDIO_COLORS.primary,
              }}
            >
              <Calendar className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Book Talent</span>
            </Button>
          </div>

          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
              <Input
                placeholder="Search talent..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-black/50 border-neutral-800 focus:border-amber-500"
                aria-label="Search talent roster"
              />
            </div>
            <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0">
              <Filter className="w-4 h-4 text-neutral-500 flex-shrink-0" />
              {ROLES.map((role) => (
                <button
                  key={role}
                  onClick={() => setSelectedRole(role)}
                  className="px-3 py-1.5 rounded-full font-mono text-xs uppercase whitespace-nowrap transition-all"
                  style={{
                    background: selectedRole === role ? STUDIO_COLORS.primary : "transparent",
                    color: selectedRole === role ? "#000" : "#999",
                    border: `1px solid ${selectedRole === role ? STUDIO_COLORS.primary : "#333"}`,
                  }}
                  aria-pressed={selectedRole === role}
                >
                  {role}
                </button>
              ))}
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Talent Grid */}
          <section className="lg:col-span-2">
            <h2 className="font-mono text-sm uppercase tracking-wider mb-6" style={{ color: STUDIO_COLORS.secondary }}>
              Talent Roster ({filteredTalent.length})
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {filteredTalent.map((talent) => {
                const Icon = talent.icon
                const isSelected = selectedTalent === talent.id

                return (
                  <button
                    key={talent.id}
                    onClick={() => setSelectedTalent(isSelected ? null : talent.id)}
                    className="p-4 sm:p-6 rounded-xl text-left transition-all duration-300 hover:scale-[1.02] group"
                    style={{
                      background: isSelected
                        ? `linear-gradient(135deg, ${STUDIO_COLORS.primary}15, transparent)`
                        : "rgba(0, 0, 0, 0.6)",
                      border: `1px solid ${isSelected ? STUDIO_COLORS.primary : "rgba(255, 255, 255, 0.1)"}`,
                      boxShadow: isSelected ? `0 0 30px ${STUDIO_COLORS.glow}` : "none",
                    }}
                    aria-pressed={isSelected}
                  >
                    <div className="flex items-start gap-4">
                      <div className="relative">
                        <img
                          src={talent.avatar || "/placeholder.svg"}
                          alt={talent.name}
                          className="w-16 h-16 rounded-full object-cover"
                          style={{ border: `2px solid ${STUDIO_COLORS.primary}40` }}
                        />
                        <div
                          className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center"
                          style={{
                            background: STUDIO_COLORS.dark,
                            border: `2px solid ${talent.availability === "available" ? "#22c55e" : STUDIO_COLORS.secondary}`,
                          }}
                        >
                          <Icon className="w-3 h-3" style={{ color: STUDIO_COLORS.primary }} />
                        </div>
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <h3
                            className="font-display text-base sm:text-lg uppercase truncate group-hover:text-white transition-colors"
                            style={{ color: STUDIO_COLORS.primary }}
                          >
                            {talent.name}
                          </h3>
                          <div className="flex items-center gap-1">
                            <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                            <span className="text-xs text-neutral-400">{talent.rating}</span>
                          </div>
                        </div>
                        <p className="text-neutral-400 text-sm">{talent.role}</p>
                        <p className="text-neutral-600 text-xs mt-1">{talent.specialty}</p>

                        <div className="flex items-center justify-between mt-3">
                          <span className="text-xs text-neutral-500">{talent.projects} projects</span>
                          <span
                            className="px-2 py-0.5 rounded-full text-xs uppercase"
                            style={{
                              background:
                                talent.availability === "available"
                                  ? "rgba(34, 197, 94, 0.2)"
                                  : `${STUDIO_COLORS.secondary}20`,
                              color: talent.availability === "available" ? "#22c55e" : STUDIO_COLORS.secondary,
                            }}
                          >
                            {talent.availability}
                          </span>
                        </div>
                      </div>
                    </div>

                    <ChevronRight
                      className="absolute top-1/2 right-4 -translate-y-1/2 w-5 h-5 opacity-0 group-hover:opacity-100 transition-opacity"
                      style={{ color: STUDIO_COLORS.primary }}
                    />
                  </button>
                )
              })}
            </div>
          </section>

          {/* Upcoming Bookings */}
          <section>
            <h2 className="font-mono text-sm uppercase tracking-wider mb-6" style={{ color: STUDIO_COLORS.secondary }}>
              Upcoming Bookings
            </h2>
            <div
              className="rounded-xl p-4 space-y-3"
              style={{
                background: "rgba(0, 0, 0, 0.6)",
                border: `1px solid ${STUDIO_COLORS.primary}20`,
              }}
            >
              {UPCOMING_BOOKINGS.map((booking) => (
                <div key={booking.id} className="p-3 rounded-lg transition-colors hover:bg-white/5">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono text-sm text-white">{booking.talent}</span>
                    <span
                      className="px-2 py-0.5 rounded text-xs"
                      style={{
                        background: `${STUDIO_COLORS.primary}20`,
                        color: STUDIO_COLORS.primary,
                      }}
                    >
                      {booking.date}
                    </span>
                  </div>
                  <p className="text-neutral-500 text-xs">{booking.project}</p>
                  <p className="text-neutral-600 text-xs mt-1 flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {booking.time}
                  </p>
                </div>
              ))}

              <Button
                variant="ghost"
                className="w-full font-mono text-xs uppercase mt-4"
                style={{ color: STUDIO_COLORS.primary }}
              >
                View Full Schedule
              </Button>
            </div>

            {/* Quick Stats */}
            <div
              className="rounded-xl p-4 mt-6"
              style={{
                background: "rgba(0, 0, 0, 0.6)",
                border: `1px solid ${STUDIO_COLORS.primary}20`,
              }}
            >
              <h3
                className="font-mono text-xs uppercase tracking-wider mb-4"
                style={{ color: STUDIO_COLORS.secondary }}
              >
                Division Stats
              </h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-neutral-500 text-sm">Total Talent</span>
                  <span className="font-display text-lg" style={{ color: STUDIO_COLORS.primary }}>
                    {TALENT_ROSTER.length}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-neutral-500 text-sm">Available Now</span>
                  <span className="font-display text-lg text-green-500">
                    {TALENT_ROSTER.filter((t) => t.availability === "available").length}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-neutral-500 text-sm">Active Projects</span>
                  <span className="font-display text-lg" style={{ color: STUDIO_COLORS.secondary }}>
                    {TALENT_ROSTER.reduce((acc, t) => acc + t.projects, 0)}
                  </span>
                </div>
              </div>
            </div>
          </section>
        </div>
      </main>
    </div>
  )
}
