"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Users, Star, Award, Mic, Camera, Code, Music } from "lucide-react"
import { LiveCircuitry } from "@/components/live-circuitry"

const STUDIO_COLORS = {
  primary: "#FFD700",
  secondary: "#FFA500",
  accent: "#FF6B00",
  dark: "#0D0800",
  glow: "rgba(255, 215, 0, 0.5)",
}

const CREW_MEMBERS = [
  {
    slug: "neuro",
    name: "NEURO META X",
    role: "Creative Director & Founder",
    avatar: "/cyberpunk-avatar-neuro-meta-gold.jpg",
    icon: Star,
    color: "#FFD700",
    bio: "Visionary architect of the WIRED CHAOS META ecosystem.",
    stats: { projects: 47, collaborations: 128, awards: 12 },
    skills: ["Creative Direction", "World Building", "System Architecture"],
  },
  {
    slug: "signal-ghost",
    name: "SIGNAL GHOST",
    role: "Audio Engineer & Producer",
    avatar: "/cyberpunk-avatar-audio-engineer-headphones.jpg",
    icon: Music,
    color: "#00FFF7",
    bio: "Master of sound design and 33.3FM broadcast engineering.",
    stats: { projects: 89, collaborations: 234, awards: 8 },
    skills: ["Sound Design", "Music Production", "Live Mixing"],
  },
  {
    slug: "cipher-lens",
    name: "CIPHER LENS",
    role: "Visual Director & DP",
    avatar: "/cyberpunk-avatar-cinematographer-camera.jpg",
    icon: Camera,
    color: "#FF6B35",
    bio: "Cinematographer capturing the essence of chaos in every frame.",
    stats: { projects: 56, collaborations: 167, awards: 15 },
    skills: ["Cinematography", "Color Grading", "Visual FX"],
  },
  {
    slug: "void-coder",
    name: "VOID CODER",
    role: "Lead Developer",
    avatar: "/cyberpunk-avatar-developer-hacker-green.jpg",
    icon: Code,
    color: "#00FF88",
    bio: "Architect of the digital infrastructure powering WIRED CHAOS.",
    stats: { projects: 112, collaborations: 89, awards: 6 },
    skills: ["Full Stack", "Blockchain", "AI Systems"],
  },
  {
    slug: "echo-host",
    name: "ECHO HOST",
    role: "Broadcast Host & MC",
    avatar: "/cyberpunk-avatar-radio-host-microphone.jpg",
    icon: Mic,
    color: "#A020F0",
    bio: "Voice of the underground, connecting realms through signal.",
    stats: { projects: 203, collaborations: 456, awards: 9 },
    skills: ["Broadcasting", "Live Hosting", "Community"],
  },
]

export default function CrewPage() {
  const router = useRouter()
  const [hoveredMember, setHoveredMember] = useState<string | null>(null)

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: STUDIO_COLORS.dark }}>
      <LiveCircuitry />

      {/* Gold Grid Background */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${STUDIO_COLORS.primary}15 1px, transparent 1px),
            linear-gradient(to bottom, ${STUDIO_COLORS.primary}15 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Header */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(0, 0, 0, 0.9)",
          borderColor: `${STUDIO_COLORS.primary}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => router.push("/789")}
              className="flex items-center gap-2 transition-colors hover:opacity-80"
              style={{ color: STUDIO_COLORS.primary }}
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="font-mono text-sm uppercase hidden sm:inline">789 Lobby</span>
            </button>
            <div className="w-px h-6" style={{ background: `${STUDIO_COLORS.primary}30` }} />
            <div className="flex items-center gap-2">
              <Users className="w-6 h-6" style={{ color: STUDIO_COLORS.primary }} />
              <h1
                className="font-display text-2xl uppercase tracking-wider"
                style={{
                  color: STUDIO_COLORS.primary,
                  textShadow: `0 0 20px ${STUDIO_COLORS.glow}`,
                }}
              >
                789 CREW
              </h1>
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-12">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h2
            className="font-display text-4xl sm:text-5xl uppercase mb-4"
            style={{
              color: STUDIO_COLORS.primary,
              textShadow: `0 0 30px ${STUDIO_COLORS.glow}`,
            }}
          >
            THE COLLECTIVE
          </h2>
          <p className="text-neutral-400 max-w-2xl mx-auto">
            Meet the visionaries behind 789 Studios. Creators, engineers, and artists pushing the boundaries of digital
            entertainment.
          </p>
        </div>

        {/* Crew Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {CREW_MEMBERS.map((member) => {
            const Icon = member.icon
            const isHovered = hoveredMember === member.slug

            return (
              <button
                key={member.slug}
                onClick={() => router.push(`/789/crew/${member.slug}`)}
                onMouseEnter={() => setHoveredMember(member.slug)}
                onMouseLeave={() => setHoveredMember(null)}
                className="group relative p-6 rounded-xl text-left transition-all duration-300 hover:scale-[1.02]"
                style={{
                  background: isHovered
                    ? `linear-gradient(135deg, ${member.color}15, transparent)`
                    : "rgba(0, 0, 0, 0.6)",
                  border: `1px solid ${isHovered ? member.color : "rgba(255, 255, 255, 0.1)"}`,
                  boxShadow: isHovered ? `0 0 30px ${member.color}30` : "none",
                }}
              >
                {/* Avatar */}
                <div className="flex items-start gap-4 mb-4">
                  <div
                    className="w-16 h-16 rounded-full overflow-hidden"
                    style={{
                      border: `2px solid ${member.color}`,
                      boxShadow: isHovered ? `0 0 20px ${member.color}50` : "none",
                    }}
                  >
                    <img
                      src={member.avatar || "/placeholder.svg"}
                      alt={member.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-display text-lg uppercase" style={{ color: member.color }}>
                      {member.name}
                    </h3>
                    <p className="text-xs text-neutral-400 font-mono uppercase">{member.role}</p>
                  </div>
                  <Icon className="w-5 h-5" style={{ color: member.color }} />
                </div>

                {/* Bio */}
                <p className="text-sm text-neutral-400 mb-4 line-clamp-2">{member.bio}</p>

                {/* Stats */}
                <div className="flex gap-4 text-xs font-mono">
                  <div>
                    <span style={{ color: member.color }}>{member.stats.projects}</span>
                    <span className="text-neutral-500 ml-1">Projects</span>
                  </div>
                  <div>
                    <span style={{ color: member.color }}>{member.stats.collaborations}</span>
                    <span className="text-neutral-500 ml-1">Collabs</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Award className="w-3 h-3" style={{ color: member.color }} />
                    <span style={{ color: member.color }}>{member.stats.awards}</span>
                  </div>
                </div>

                {/* Skills */}
                <div className="flex flex-wrap gap-2 mt-4">
                  {member.skills.map((skill) => (
                    <span
                      key={skill}
                      className="px-2 py-1 rounded text-xs font-mono"
                      style={{
                        background: `${member.color}15`,
                        color: member.color,
                      }}
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </button>
            )
          })}
        </div>
      </main>
    </div>
  )
}
