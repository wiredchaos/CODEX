"use client"

import { useParams, useRouter } from "next/navigation"
import { ArrowLeft, Star, Award, Mic, Camera, Code, Music } from "lucide-react"
import { LiveCircuitry } from "@/components/live-circuitry"

const STUDIO_COLORS = {
  primary: "#FFD700",
  secondary: "#FFA500",
  accent: "#FF6B00",
  dark: "#0D0800",
  glow: "rgba(255, 215, 0, 0.5)",
}

const CREW_DATA: Record<
  string,
  {
    name: string
    role: string
    avatar: string
    icon: typeof Star
    color: string
    bio: string
    fullBio: string
    stats: { projects: number; collaborations: number; awards: number }
    skills: string[]
    achievements?: string[]
    spaces?: { title: string; date: string }[]
    projects?: { title: string; type: string; year: string }[]
    featureSection?: { title: string; features?: string[]; highlights?: string[] }
  }
> = {
  neuro: {
    name: "NEURO META X",
    role: "Creative Director & Founder",
    avatar: "/cyberpunk-avatar-neuro-meta-gold-detailed.jpg",
    icon: Star,
    color: "#FFD700",
    bio: "Visionary architect of the WIRED CHAOS META ecosystem.",
    fullBio:
      "NEURO META X is the visionary founder and creative director behind WIRED CHAOS META. With over a decade of experience in digital media, blockchain technology, and immersive entertainment, NEURO has built an ecosystem that bridges the gap between Web2 and Web3, creating new paradigms for creator economies and digital storytelling.",
    stats: { projects: 47, collaborations: 128, awards: 12 },
    skills: ["Creative Direction", "World Building", "System Architecture", "Tokenomics", "Community Building"],
    achievements: [
      "Founded WIRED CHAOS META (2021)",
      "Launched 789 Studios",
      "Created 33.3FM Signal Network",
      "Pioneered Dual-Realm Architecture",
    ],
    spaces: [
      { title: "Future of Creator DAOs", date: "2024-01-15" },
      { title: "Web3 Entertainment Summit", date: "2024-02-20" },
    ],
    projects: [
      { title: "WIRED CHAOS META", type: "Ecosystem", year: "2021" },
      { title: "789 OTT Platform", type: "Streaming", year: "2023" },
      { title: "33.3FM Radio", type: "Broadcast", year: "2022" },
    ],
    featureSection: {
      title: "VISION",
      features: ["Decentralized Media", "Creator Sovereignty", "Immersive Experiences", "Community Governance"],
    },
  },
  "signal-ghost": {
    name: "SIGNAL GHOST",
    role: "Audio Engineer & Producer",
    avatar: "/cyberpunk-avatar-audio-engineer-headphones-detaile.jpg",
    icon: Music,
    color: "#00FFF7",
    bio: "Master of sound design and 33.3FM broadcast engineering.",
    fullBio:
      "SIGNAL GHOST is the sonic architect behind 33.3FM and all audio production at WIRED CHAOS. Specializing in immersive soundscapes, live broadcast engineering, and music production, SIGNAL GHOST brings the auditory dimension of the metaverse to life.",
    stats: { projects: 89, collaborations: 234, awards: 8 },
    skills: ["Sound Design", "Music Production", "Live Mixing", "Broadcast Engineering", "Spatial Audio"],
    achievements: ["Launched 33.3FM", "100+ Live Broadcasts", "Grammy-nominated collaborations"],
    projects: [
      { title: "33.3FM Launch", type: "Radio", year: "2022" },
      { title: "CHAOS SOUNDS Vol. 1", type: "Album", year: "2023" },
    ],
    featureSection: {
      title: "SOUND",
      highlights: ["Immersive Audio", "Live Broadcasts", "Sound Design", "Music Production"],
    },
  },
  "cipher-lens": {
    name: "CIPHER LENS",
    role: "Visual Director & DP",
    avatar: "/cyberpunk-avatar-cinematographer-camera-detailed.jpg",
    icon: Camera,
    color: "#FF6B35",
    bio: "Cinematographer capturing the essence of chaos in every frame.",
    fullBio:
      "CIPHER LENS is the visual storyteller of WIRED CHAOS, responsible for all cinematography, color grading, and visual effects. With a background in film and digital art, CIPHER brings a cinematic quality to every production.",
    stats: { projects: 56, collaborations: 167, awards: 15 },
    skills: ["Cinematography", "Color Grading", "Visual FX", "Motion Graphics", "3D Visualization"],
    achievements: ["15 Industry Awards", "Shot 50+ Music Videos", "Created 789 OTT Visual Identity"],
    projects: [
      { title: "NEURAL DRIFT", type: "Film", year: "2024" },
      { title: "789 Brand Film", type: "Commercial", year: "2023" },
    ],
    featureSection: {
      title: "VISUALS",
      features: ["Cinematic Excellence", "Color Science", "Visual FX", "Brand Identity"],
    },
  },
  "void-coder": {
    name: "VOID CODER",
    role: "Lead Developer",
    avatar: "/cyberpunk-avatar-developer-hacker-green-detailed.jpg",
    icon: Code,
    color: "#00FF88",
    bio: "Architect of the digital infrastructure powering WIRED CHAOS.",
    fullBio:
      "VOID CODER is the technical mastermind behind all WIRED CHAOS systems. From blockchain smart contracts to AI-powered tools, VOID CODER builds the infrastructure that powers the entire ecosystem.",
    stats: { projects: 112, collaborations: 89, awards: 6 },
    skills: ["Full Stack", "Blockchain", "AI Systems", "Smart Contracts", "System Architecture"],
    achievements: ["Built WIRED CHAOS Core", "Deployed 20+ Smart Contracts", "Created TFS Engine"],
    projects: [
      { title: "WIRED CHAOS Core", type: "Infrastructure", year: "2022" },
      { title: "TFS Engine", type: "Tool", year: "2024" },
    ],
    featureSection: {
      title: "CODE",
      highlights: ["Blockchain", "AI/ML", "Full Stack", "Smart Contracts"],
    },
  },
  "echo-host": {
    name: "ECHO HOST",
    role: "Broadcast Host & MC",
    avatar: "/cyberpunk-avatar-radio-host-microphone-detailed.jpg",
    icon: Mic,
    color: "#A020F0",
    bio: "Voice of the underground, connecting realms through signal.",
    fullBio:
      "ECHO HOST is the charismatic voice of WIRED CHAOS, hosting live broadcasts, community spaces, and events. With a natural ability to connect with audiences, ECHO builds bridges between creators and communities.",
    stats: { projects: 203, collaborations: 456, awards: 9 },
    skills: ["Broadcasting", "Live Hosting", "Community", "Event MC", "Interviewing"],
    achievements: ["500+ Hours Live", "Built 10K+ Community", "Hosted Major Web3 Events"],
    spaces: [
      { title: "Weekly CHAOS Space", date: "Every Friday" },
      { title: "Creator Spotlight Series", date: "Bi-weekly" },
    ],
    featureSection: {
      title: "VOICE",
      features: ["Live Broadcasting", "Community Building", "Event Hosting", "Interviews"],
    },
  },
}

export default function CrewMemberPage() {
  const params = useParams()
  const router = useRouter()
  const slug = params.slug as string
  const member = CREW_DATA[slug]

  if (!member) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: STUDIO_COLORS.dark }}>
        <div className="text-center">
          <h1 className="text-2xl text-white mb-4">Crew Member Not Found</h1>
          <button
            onClick={() => router.push("/789/crew")}
            className="px-4 py-2 rounded-lg font-mono text-sm"
            style={{ background: STUDIO_COLORS.primary, color: "#000" }}
          >
            Back to Crew
          </button>
        </div>
      </div>
    )
  }

  const Icon = member.icon
  const featureItems = member.featureSection?.features || member.featureSection?.highlights || []

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: STUDIO_COLORS.dark }}>
      <LiveCircuitry />

      {/* Background */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${member.color}15 1px, transparent 1px),
            linear-gradient(to bottom, ${member.color}15 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Header */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(0, 0, 0, 0.9)",
          borderColor: `${member.color}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => router.push("/789/crew")}
              className="flex items-center gap-2 transition-colors hover:opacity-80"
              style={{ color: member.color }}
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="font-mono text-sm uppercase hidden sm:inline">Crew</span>
            </button>
            <div className="w-px h-6" style={{ background: `${member.color}30` }} />
            <div className="flex items-center gap-2">
              <Icon className="w-6 h-6" style={{ color: member.color }} />
              <h1
                className="font-display text-xl sm:text-2xl uppercase tracking-wider"
                style={{
                  color: member.color,
                  textShadow: `0 0 20px ${member.color}50`,
                }}
              >
                {member.name}
              </h1>
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-12">
        {/* Hero */}
        <div className="flex flex-col md:flex-row gap-8 mb-12">
          {/* Avatar */}
          <div
            className="w-48 h-48 md:w-64 md:h-64 rounded-2xl overflow-hidden flex-shrink-0 mx-auto md:mx-0"
            style={{
              border: `3px solid ${member.color}`,
              boxShadow: `0 0 40px ${member.color}30`,
            }}
          >
            <img src={member.avatar || "/placeholder.svg"} alt={member.name} className="w-full h-full object-cover" />
          </div>

          {/* Info */}
          <div className="flex-1">
            <p className="text-sm font-mono uppercase mb-2" style={{ color: member.color }}>
              {member.role}
            </p>
            <h2
              className="font-display text-4xl sm:text-5xl uppercase mb-4"
              style={{
                color: member.color,
                textShadow: `0 0 30px ${member.color}50`,
              }}
            >
              {member.name}
            </h2>
            <p className="text-neutral-300 mb-6 leading-relaxed">{member.fullBio}</p>

            {/* Stats */}
            <div className="flex gap-6 mb-6">
              <div className="text-center">
                <div className="text-3xl font-display" style={{ color: member.color }}>
                  {member.stats.projects}
                </div>
                <div className="text-xs text-neutral-500 font-mono uppercase">Projects</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-display" style={{ color: member.color }}>
                  {member.stats.collaborations}
                </div>
                <div className="text-xs text-neutral-500 font-mono uppercase">Collabs</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-display flex items-center justify-center gap-1">
                  <Award className="w-6 h-6" style={{ color: member.color }} />
                  <span style={{ color: member.color }}>{member.stats.awards}</span>
                </div>
                <div className="text-xs text-neutral-500 font-mono uppercase">Awards</div>
              </div>
            </div>

            {/* Skills */}
            <div className="flex flex-wrap gap-2">
              {member.skills?.map((skill) => (
                <span
                  key={skill}
                  className="px-3 py-1 rounded-full text-sm font-mono"
                  style={{
                    background: `${member.color}15`,
                    color: member.color,
                    border: `1px solid ${member.color}30`,
                  }}
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Content Sections */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Achievements */}
          {member.achievements && member.achievements.length > 0 && (
            <div
              className="p-6 rounded-xl"
              style={{
                background: "rgba(0, 0, 0, 0.6)",
                border: `1px solid ${member.color}20`,
              }}
            >
              <h3 className="font-display text-xl uppercase mb-4" style={{ color: member.color }}>
                Achievements
              </h3>
              <ul className="space-y-2">
                {member.achievements.map((achievement, i) => (
                  <li key={i} className="flex items-center gap-2 text-neutral-300 text-sm">
                    <div className="w-2 h-2 rounded-full" style={{ background: member.color }} />
                    {achievement}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Projects */}
          {member.projects && member.projects.length > 0 && (
            <div
              className="p-6 rounded-xl"
              style={{
                background: "rgba(0, 0, 0, 0.6)",
                border: `1px solid ${member.color}20`,
              }}
            >
              <h3 className="font-display text-xl uppercase mb-4" style={{ color: member.color }}>
                Projects
              </h3>
              <div className="space-y-3">
                {member.projects.map((project, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between p-3 rounded-lg"
                    style={{ background: `${member.color}10` }}
                  >
                    <div>
                      <div className="text-white font-mono text-sm">{project.title}</div>
                      <div className="text-xs text-neutral-500">{project.type}</div>
                    </div>
                    <div className="text-xs font-mono" style={{ color: member.color }}>
                      {project.year}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Spaces */}
          {member.spaces && member.spaces.length > 0 && (
            <div
              className="p-6 rounded-xl"
              style={{
                background: "rgba(0, 0, 0, 0.6)",
                border: `1px solid ${member.color}20`,
              }}
            >
              <h3 className="font-display text-xl uppercase mb-4" style={{ color: member.color }}>
                Spaces
              </h3>
              <div className="space-y-3">
                {member.spaces.map((space, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between p-3 rounded-lg"
                    style={{ background: `${member.color}10` }}
                  >
                    <div className="flex items-center gap-2">
                      <Mic className="w-4 h-4" style={{ color: member.color }} />
                      <span className="text-white text-sm">{space.title}</span>
                    </div>
                    <div className="text-xs text-neutral-500">{space.date}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Feature Section */}
          {member.featureSection && featureItems.length > 0 && (
            <div
              className="p-6 rounded-xl"
              style={{
                background: "rgba(0, 0, 0, 0.6)",
                border: `1px solid ${member.color}20`,
              }}
            >
              <h3 className="font-display text-xl uppercase mb-4" style={{ color: member.color }}>
                {member.featureSection.title}
              </h3>
              <div className="grid grid-cols-2 gap-2">
                {featureItems.map((item, i) => (
                  <div
                    key={i}
                    className="p-3 rounded-lg text-center text-sm font-mono"
                    style={{
                      background: `${member.color}10`,
                      color: member.color,
                    }}
                  >
                    {item}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
