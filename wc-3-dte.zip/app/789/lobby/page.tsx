"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Play, Wand2, ChevronRight, Film, Radio, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"

const COLORS = {
  primary: "#ff1744",
  secondary: "#00e5ff",
  gold: "#FFD700",
  dark: "#02030A",
}

const CSN_SCHEDULE = [
  { time: "3:00 PM", show: "Tech Unplugged", host: "Marcus Chen" },
  { time: "5:00 PM", show: "Creator Spotlight", host: "Ava Williams" },
  { time: "7:00 PM", show: "Web3 Weekly", host: "DJ Red Fang" },
  { time: "9:00 PM", show: "Night Signals", host: "Luna X" },
]

const ORIGINALS = [
  { id: "1", title: "The Chaos Protocol", image: "/placeholder.svg?height=300&width=500" },
  { id: "2", title: "Digital Frontier", image: "/placeholder.svg?height=300&width=500" },
  { id: "3", title: "Neon Dynasty", image: "/placeholder.svg?height=300&width=500" },
  { id: "4", title: "Signal Lost", image: "/placeholder.svg?height=300&width=500" },
]

export default function Studio789LobbyPage() {
  const router = useRouter()
  const [hoveredCard, setHoveredCard] = useState<string | null>(null)
  const [currentTime, setCurrentTime] = useState("")

  useEffect(() => {
    const updateTime = () => {
      setCurrentTime(new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }))
    }
    updateTime()
    const interval = setInterval(updateTime, 1000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="min-h-screen bg-[#02030A] relative overflow-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 pointer-events-none">
        {/* Grid */}
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `
              linear-gradient(to right, ${COLORS.primary}20 1px, transparent 1px),
              linear-gradient(to bottom, ${COLORS.primary}20 1px, transparent 1px)
            `,
            backgroundSize: "80px 80px",
          }}
        />

        {/* Floating Film Thumbnails */}
        <div className="absolute inset-0">
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className="absolute w-24 h-16 rounded opacity-20 animate-float"
              style={{
                background: `linear-gradient(135deg, ${COLORS.primary}40, ${COLORS.secondary}20)`,
                left: `${10 + i * 15}%`,
                top: `${20 + (i % 3) * 25}%`,
                animationDelay: `${i * 0.5}s`,
                animationDuration: `${4 + i}s`,
              }}
            />
          ))}
        </div>
      </div>

      {/* Top Bar */}
      <header className="relative z-10 flex items-center justify-between px-6 py-4">
        <h1 className="text-3xl font-bold tracking-tighter" style={{ color: COLORS.primary }}>
          789 <span className="text-white/60 font-normal text-lg">Studios</span>
        </h1>
        <Button
          variant="ghost"
          size="sm"
          className="text-white/60 hover:text-white"
          onClick={() => router.push("/auth/login")}
        >
          Sign In / Join
        </Button>
      </header>

      {/* Main Content */}
      <main className="relative z-10 px-6 py-12 md:py-20">
        {/* Hero Split - Watch vs Create */}
        <div className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto mb-16">
          {/* Watch Card */}
          <div
            className="relative group cursor-pointer rounded-2xl overflow-hidden transition-all duration-500"
            style={{
              background:
                hoveredCard === "watch"
                  ? `linear-gradient(135deg, ${COLORS.primary}30, ${COLORS.primary}10)`
                  : "rgba(255,255,255,0.03)",
              border: `2px solid ${hoveredCard === "watch" ? COLORS.primary : "rgba(255,255,255,0.1)"}`,
              transform: hoveredCard === "watch" ? "scale(1.02)" : "scale(1)",
              boxShadow: hoveredCard === "watch" ? `0 0 60px ${COLORS.primary}30` : "none",
            }}
            onMouseEnter={() => setHoveredCard("watch")}
            onMouseLeave={() => setHoveredCard(null)}
            onClick={() => router.push("/watch")}
          >
            <div className="p-8 md:p-12">
              <div
                className="w-16 h-16 rounded-xl flex items-center justify-center mb-6"
                style={{ backgroundColor: `${COLORS.primary}20` }}
              >
                <Play className="w-8 h-8" style={{ color: COLORS.primary }} />
              </div>

              <h2 className="text-3xl font-bold text-white mb-2">Enter the Studio</h2>
              <p className="text-white/60 mb-8">Stream originals, CSN broadcasts, and Film3 features.</p>

              <Button
                className="gap-2"
                style={{
                  backgroundColor: COLORS.primary,
                  color: "white",
                }}
              >
                Watch Now
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>

            {/* Animated thumbnail strip */}
            <div className="absolute bottom-0 left-0 right-0 h-20 overflow-hidden opacity-30 group-hover:opacity-60 transition-opacity">
              <div className="flex gap-2 animate-scroll-left">
                {[...ORIGINALS, ...ORIGINALS].map((item, i) => (
                  <img
                    key={i}
                    src={item.image || "/placeholder.svg"}
                    alt=""
                    className="w-32 h-20 object-cover rounded"
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Create Card */}
          <div
            className="relative group cursor-pointer rounded-2xl overflow-hidden transition-all duration-500"
            style={{
              background:
                hoveredCard === "create"
                  ? `linear-gradient(135deg, ${COLORS.gold}30, ${COLORS.gold}10)`
                  : "rgba(255,255,255,0.03)",
              border: `2px solid ${hoveredCard === "create" ? COLORS.gold : "rgba(255,255,255,0.1)"}`,
              transform: hoveredCard === "create" ? "scale(1.02)" : "scale(1)",
              boxShadow: hoveredCard === "create" ? `0 0 60px ${COLORS.gold}30` : "none",
            }}
            onMouseEnter={() => setHoveredCard("create")}
            onMouseLeave={() => setHoveredCard(null)}
            onClick={() => router.push("/create")}
          >
            <div className="p-8 md:p-12">
              <div
                className="w-16 h-16 rounded-xl flex items-center justify-center mb-6"
                style={{ backgroundColor: `${COLORS.gold}20` }}
              >
                <Wand2 className="w-8 h-8" style={{ color: COLORS.gold }} />
              </div>

              <h2 className="text-3xl font-bold text-white mb-2">Enter the Creator Hub</h2>
              <p className="text-white/60 mb-8">Host shows, pitch ideas, and build with AI tools.</p>

              <Button
                className="gap-2"
                style={{
                  backgroundColor: COLORS.gold,
                  color: "#0D0800",
                }}
              >
                Creator Hub
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>

            {/* Animated control room elements */}
            <div className="absolute bottom-0 left-0 right-0 h-20 overflow-hidden opacity-30 group-hover:opacity-60 transition-opacity">
              <div className="flex items-center justify-center gap-4 h-full">
                <div className="w-20 h-12 rounded bg-gradient-to-r from-amber-500/40 to-orange-500/40 animate-pulse" />
                <div className="w-16 h-8 rounded bg-gradient-to-r from-amber-500/30 to-yellow-500/30 animate-pulse delay-100" />
                <div className="w-24 h-10 rounded bg-gradient-to-r from-orange-500/40 to-amber-500/40 animate-pulse delay-200" />
              </div>
            </div>
          </div>
        </div>

        {/* 789 Studios Originals Teaser */}
        <div className="max-w-6xl mx-auto mb-12">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-semibold text-white flex items-center gap-2">
              <Film className="w-5 h-5" style={{ color: COLORS.primary }} />
              789 Studios Originals
            </h3>
            <button
              className="text-sm flex items-center gap-1 hover:gap-2 transition-all"
              style={{ color: COLORS.primary }}
              onClick={() => router.push("/watch")}
            >
              See All <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
            {ORIGINALS.map((item) => (
              <div
                key={item.id}
                className="flex-shrink-0 w-[200px] md:w-[280px] aspect-video rounded-lg overflow-hidden cursor-pointer transition-transform hover:scale-105"
                onClick={() => router.push("/watch")}
              >
                <img src={item.image || "/placeholder.svg"} alt={item.title} className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        </div>

        {/* Today on CSN */}
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-semibold text-white flex items-center gap-2">
              <Radio className="w-5 h-5" style={{ color: COLORS.secondary }} />
              Today on CSN
            </h3>
            <div className="flex items-center gap-2 text-white/60">
              <Clock className="w-4 h-4" />
              <span className="font-mono text-sm">{currentTime}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {CSN_SCHEDULE.map((item, i) => (
              <div
                key={i}
                className="p-4 rounded-lg transition-colors cursor-pointer"
                style={{
                  backgroundColor: "rgba(255,255,255,0.03)",
                  border: "1px solid rgba(255,255,255,0.1)",
                }}
              >
                <p className="font-mono text-xs mb-1" style={{ color: COLORS.secondary }}>
                  {item.time}
                </p>
                <p className="text-white font-medium text-sm mb-1">{item.show}</p>
                <p className="text-white/50 text-xs">{item.host}</p>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 px-6 py-8 border-t border-white/10">
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-center gap-6 text-sm text-white/40">
          <a href="/about" className="hover:text-white/70">
            About
          </a>
          <a href="/support" className="hover:text-white/70">
            Support
          </a>
          <a href="/terms" className="hover:text-white/70">
            Terms
          </a>
          <a href="/anti-moloch" className="hover:text-white/70">
            Anti-Moloch Statement
          </a>
        </div>
      </footer>

      {/* Live Ticker */}
      <div
        className="fixed bottom-0 left-0 right-0 py-2 overflow-hidden"
        style={{
          background: `linear-gradient(90deg, ${COLORS.primary}20, ${COLORS.secondary}20)`,
          borderTop: "1px solid rgba(255,255,255,0.1)",
        }}
      >
        <div className="animate-scroll-left flex gap-8 whitespace-nowrap">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="flex gap-8">
              <span className="text-white/70 text-sm">NOW STREAMING: The Chaos Protocol</span>
              <span style={{ color: COLORS.primary }}>●</span>
              <span className="text-white/70 text-sm">LIVE @ 3PM: Tech Unplugged with Marcus Chen</span>
              <span style={{ color: COLORS.secondary }}>●</span>
              <span className="text-white/70 text-sm">NEW: Creator Hub Beta Now Available</span>
              <span style={{ color: COLORS.gold }}>●</span>
            </div>
          ))}
        </div>
      </div>

      <style jsx>{`
        @keyframes scroll-left {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-scroll-left {
          animation: scroll-left 30s linear infinite;
        }
        @keyframes float {
          0%, 100% { transform: translateY(0) rotate(0deg); }
          50% { transform: translateY(-20px) rotate(3deg); }
        }
        .animate-float {
          animation: float 6s ease-in-out infinite;
        }
      `}</style>
    </div>
  )
}
