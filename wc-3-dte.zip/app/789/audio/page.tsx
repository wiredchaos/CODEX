"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Music, Mic, Headphones, Radio, Waves, Volume2, Play, Pause, SkipForward } from "lucide-react"
import { Button } from "@/components/ui/button"

const STUDIO_COLORS = {
  primary: "#FFD700",
  secondary: "#FFA500",
  accent: "#FF6B00",
  dark: "#0D0800",
  glow: "rgba(255, 215, 0, 0.5)",
}

const AUDIO_ROOMS = [
  { id: "studio-a", name: "Recording Studio A", type: "Live Recording", status: "available", icon: Mic },
  { id: "studio-b", name: "Recording Studio B", type: "Vocal Booth", status: "in-use", icon: Headphones },
  { id: "mix-1", name: "Mix Room 1", type: "5.1 Surround", status: "available", icon: Volume2 },
  { id: "foley", name: "Foley Stage", type: "Sound Effects", status: "available", icon: Waves },
  { id: "mastering", name: "Mastering Suite", type: "Final Mix", status: "reserved", icon: Radio },
  { id: "podcast", name: "Podcast Studio", type: "Voice Recording", status: "available", icon: Mic },
]

const ACTIVE_PROJECTS = [
  { id: 1, title: "NEURAL DRIFT OST", artist: "Echo Collective", progress: 78, tracks: 24 },
  { id: 2, title: "CHAOS THEORY S2 SCORE", artist: "Digital Waves", progress: 45, tracks: 18 },
  { id: 3, title: "789 PODCAST EP.47", artist: "Studio789", progress: 92, tracks: 1 },
]

const SOUND_LIBRARY = [
  { id: 1, name: "Cyberpunk Ambience", category: "Ambient", duration: "4:32", bpm: null },
  { id: 2, name: "Neural Pulse Beat", category: "Electronic", duration: "2:18", bpm: 128 },
  { id: 3, name: "Akashic Drone", category: "Cinematic", duration: "6:45", bpm: null },
  { id: 4, name: "Circuit Glitch FX", category: "SFX", duration: "0:12", bpm: null },
]

export default function AudioLabsPage() {
  const router = useRouter()
  const [selectedRoom, setSelectedRoom] = useState<string | null>(null)
  const [isPlaying, setIsPlaying] = useState<number | null>(null)

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: STUDIO_COLORS.dark }}>
      {/* Gold Circuitry Background */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${STUDIO_COLORS.primary}15 1px, transparent 1px),
            linear-gradient(to bottom, ${STUDIO_COLORS.primary}15 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
        aria-hidden="true"
      />

      {/* Animated waveform background */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden opacity-10" aria-hidden="true">
        <svg className="w-full h-full" preserveAspectRatio="none">
          <defs>
            <linearGradient id="waveGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor={STUDIO_COLORS.primary} />
              <stop offset="100%" stopColor={STUDIO_COLORS.secondary} />
            </linearGradient>
          </defs>
          {[...Array(5)].map((_, i) => (
            <path
              key={i}
              d={`M0,${50 + i * 20} Q25,${30 + i * 20} 50,${50 + i * 20} T100,${50 + i * 20} T150,${50 + i * 20} T200,${50 + i * 20}`}
              fill="none"
              stroke="url(#waveGradient)"
              strokeWidth="2"
              className="animate-pulse"
              style={{
                transform: `scaleX(${window?.innerWidth / 200 || 10})`,
                animationDelay: `${i * 0.2}s`,
              }}
            />
          ))}
        </svg>
      </div>

      {/* Header */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(0, 0, 0, 0.9)",
          borderColor: `${STUDIO_COLORS.primary}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => router.push("/789")}
              className="flex items-center gap-2 transition-colors hover:opacity-80"
              style={{ color: STUDIO_COLORS.primary }}
              aria-label="Return to 789 Lobby"
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="font-mono text-sm uppercase hidden sm:inline">789 Lobby</span>
            </button>
            <div className="w-px h-6" style={{ background: `${STUDIO_COLORS.primary}30` }} aria-hidden="true" />
            <div className="flex items-center gap-2">
              <Music className="w-6 h-6" style={{ color: STUDIO_COLORS.primary }} />
              <h1
                className="font-display text-xl sm:text-2xl uppercase tracking-wider"
                style={{
                  color: STUDIO_COLORS.primary,
                  textShadow: `0 0 20px ${STUDIO_COLORS.glow}`,
                }}
              >
                Audio Labs
              </h1>
            </div>
          </div>

          <Button
            variant="outline"
            className="font-mono text-xs uppercase bg-transparent"
            style={{
              borderColor: STUDIO_COLORS.primary,
              color: STUDIO_COLORS.primary,
            }}
          >
            <Mic className="w-4 h-4 mr-2" />
            <span className="hidden sm:inline">New Session</span>
          </Button>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        {/* Active Projects */}
        <section className="mb-12">
          <h2 className="font-mono text-sm uppercase tracking-wider mb-6" style={{ color: STUDIO_COLORS.secondary }}>
            Active Projects
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6">
            {ACTIVE_PROJECTS.map((project) => (
              <div
                key={project.id}
                className="p-4 sm:p-6 rounded-xl transition-all duration-300 hover:scale-[1.02] cursor-pointer group"
                style={{
                  background: "rgba(0, 0, 0, 0.6)",
                  border: `1px solid ${STUDIO_COLORS.primary}30`,
                }}
                role="button"
                tabIndex={0}
                aria-label={`View project ${project.title}`}
              >
                <div className="flex items-center justify-between mb-4">
                  <Headphones className="w-8 h-8" style={{ color: STUDIO_COLORS.primary }} />
                  <span className="text-xs text-neutral-500">{project.tracks} tracks</span>
                </div>
                <h3 className="font-display text-lg sm:text-xl text-white mb-1">{project.title}</h3>
                <p className="text-neutral-500 text-sm mb-4">{project.artist}</p>

                {/* Progress Bar */}
                <div
                  className="h-2 rounded-full bg-neutral-800 overflow-hidden"
                  role="progressbar"
                  aria-valuenow={project.progress}
                  aria-valuemin={0}
                  aria-valuemax={100}
                >
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${project.progress}%`,
                      background: `linear-gradient(90deg, ${STUDIO_COLORS.primary}, ${STUDIO_COLORS.secondary})`,
                      boxShadow: `0 0 10px ${STUDIO_COLORS.glow}`,
                    }}
                  />
                </div>
                <p className="text-right text-xs text-neutral-500 mt-2">{project.progress}% Mixed</p>
              </div>
            ))}
          </div>
        </section>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Audio Rooms */}
          <section className="lg:col-span-2">
            <h2 className="font-mono text-sm uppercase tracking-wider mb-6" style={{ color: STUDIO_COLORS.secondary }}>
              Audio Rooms
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {AUDIO_ROOMS.map((room) => {
                const Icon = room.icon
                const statusColors = {
                  available: "#22c55e",
                  "in-use": "#ef4444",
                  reserved: STUDIO_COLORS.primary,
                }

                return (
                  <button
                    key={room.id}
                    onClick={() => setSelectedRoom(room.id)}
                    className="p-4 sm:p-6 rounded-xl text-left transition-all duration-300 hover:scale-[1.02] group"
                    style={{
                      background:
                        selectedRoom === room.id
                          ? `linear-gradient(135deg, ${STUDIO_COLORS.primary}15, transparent)`
                          : "rgba(0, 0, 0, 0.6)",
                      border: `1px solid ${selectedRoom === room.id ? STUDIO_COLORS.primary : "rgba(255, 255, 255, 0.1)"}`,
                      boxShadow: selectedRoom === room.id ? `0 0 30px ${STUDIO_COLORS.glow}` : "none",
                    }}
                    aria-pressed={selectedRoom === room.id}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div
                        className="w-12 h-12 rounded-lg flex items-center justify-center"
                        style={{
                          background: `${STUDIO_COLORS.primary}20`,
                          color: STUDIO_COLORS.primary,
                        }}
                      >
                        <Icon className="w-6 h-6" />
                      </div>
                      <div className="flex items-center gap-2">
                        <div
                          className="w-2 h-2 rounded-full"
                          style={{
                            background: statusColors[room.status as keyof typeof statusColors],
                            boxShadow: `0 0 8px ${statusColors[room.status as keyof typeof statusColors]}`,
                          }}
                          aria-hidden="true"
                        />
                        <span className="text-xs text-neutral-500 uppercase">{room.status}</span>
                      </div>
                    </div>

                    <h3
                      className="font-display text-base sm:text-lg uppercase mb-1 group-hover:text-white transition-colors"
                      style={{ color: STUDIO_COLORS.primary }}
                    >
                      {room.name}
                    </h3>
                    <p className="text-neutral-400 text-sm">{room.type}</p>
                  </button>
                )
              })}
            </div>
          </section>

          {/* Sound Library */}
          <section>
            <h2 className="font-mono text-sm uppercase tracking-wider mb-6" style={{ color: STUDIO_COLORS.secondary }}>
              Sound Library
            </h2>
            <div
              className="rounded-xl p-4 space-y-2"
              style={{
                background: "rgba(0, 0, 0, 0.6)",
                border: `1px solid ${STUDIO_COLORS.primary}20`,
              }}
            >
              {SOUND_LIBRARY.map((sound) => (
                <div
                  key={sound.id}
                  className="flex items-center gap-3 p-3 rounded-lg transition-colors hover:bg-white/5 group"
                >
                  <button
                    onClick={() => setIsPlaying(isPlaying === sound.id ? null : sound.id)}
                    className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 transition-all"
                    style={{
                      background: isPlaying === sound.id ? STUDIO_COLORS.primary : `${STUDIO_COLORS.primary}20`,
                      color: isPlaying === sound.id ? "#000" : STUDIO_COLORS.primary,
                    }}
                    aria-label={isPlaying === sound.id ? `Pause ${sound.name}` : `Play ${sound.name}`}
                  >
                    {isPlaying === sound.id ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                  </button>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-white truncate">{sound.name}</p>
                    <div className="flex items-center gap-2 text-xs text-neutral-500">
                      <span>{sound.category}</span>
                      <span>•</span>
                      <span>{sound.duration}</span>
                      {sound.bpm && (
                        <>
                          <span>•</span>
                          <span>{sound.bpm} BPM</span>
                        </>
                      )}
                    </div>
                  </div>
                  <SkipForward
                    className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity"
                    style={{ color: STUDIO_COLORS.primary }}
                  />
                </div>
              ))}

              <Button
                variant="ghost"
                className="w-full font-mono text-xs uppercase mt-4"
                style={{ color: STUDIO_COLORS.primary }}
              >
                Browse Full Library
              </Button>
            </div>
          </section>
        </div>
      </main>
    </div>
  )
}
