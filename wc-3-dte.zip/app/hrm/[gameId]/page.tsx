"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import {
  ArrowLeft,
  Compass,
  Command,
  Scale,
  Swords,
  BookOpen,
  Eye,
  CheckCircle,
  XCircle,
  ChevronRight,
  Trophy,
  Clock,
  RotateCcw,
} from "lucide-react"
import { LiveCircuitry } from "@/components/live-circuitry"
import { use } from "react"

const HRM_COLORS = {
  primary: "#00FFF7",
  secondary: "#FF4500",
  accent: "#FFD700",
  dark: "#000000",
  success: "#00FF88",
  error: "#FF1A1A",
}

interface Scenario {
  id: string
  situation: string
  options: {
    id: string
    text: string
    feedback: string
    score: number
    isOptimal: boolean
  }[]
}

const GAME_DATA: Record<
  string,
  {
    name: string
    icon: typeof Compass
    color: string
    scenarios: Scenario[]
  }
> = {
  "emotional-compass": {
    name: "Emotional Compass",
    icon: Compass,
    color: "#00FFF7",
    scenarios: [
      {
        id: "ec-1",
        situation:
          "A team member becomes visibly upset during a meeting after their idea is dismissed. The room grows tense. What do you do?",
        options: [
          {
            id: "a",
            text: "Move on quickly to avoid awkwardness",
            feedback: "Ignoring emotions can escalate tension and damage trust.",
            score: 20,
            isOptimal: false,
          },
          {
            id: "b",
            text: "Acknowledge their frustration and suggest revisiting the idea later",
            feedback: "Excellent! This validates their feelings while maintaining meeting flow.",
            score: 100,
            isOptimal: true,
          },
          {
            id: "c",
            text: "Ask others what they think about the idea",
            feedback: "This could help or further embarrass them depending on responses.",
            score: 50,
            isOptimal: false,
          },
          {
            id: "d",
            text: "Take a 5-minute break",
            feedback: "A break can help, but doesn't address the underlying issue.",
            score: 40,
            isOptimal: false,
          },
        ],
      },
      {
        id: "ec-2",
        situation:
          "You notice a high performer has been increasingly withdrawn and missing deadlines. When you check in, they say everything is fine. How do you proceed?",
        options: [
          {
            id: "a",
            text: "Accept their answer and monitor from a distance",
            feedback: "Sometimes people need space, but this misses an opportunity to help.",
            score: 40,
            isOptimal: false,
          },
          {
            id: "b",
            text: "Express specific observations and genuine concern without pressure",
            feedback: "This opens the door while respecting boundaries. Well done!",
            score: 100,
            isOptimal: true,
          },
          {
            id: "c",
            text: "Escalate to HR immediately",
            feedback: "Premature escalation can break trust. Start with direct conversation.",
            score: 20,
            isOptimal: false,
          },
          {
            id: "d",
            text: "Assign them to a team project for more interaction",
            feedback: "Forced interaction without understanding may add stress.",
            score: 30,
            isOptimal: false,
          },
        ],
      },
      {
        id: "ec-3",
        situation:
          "Two team members are in conflict over project ownership. Both have valid claims and the tension is affecting the whole team. What's your approach?",
        options: [
          {
            id: "a",
            text: "Make a quick decision about ownership to end the conflict",
            feedback: "Quick decisions may feel unfair and create resentment.",
            score: 35,
            isOptimal: false,
          },
          {
            id: "b",
            text: "Let them work it out themselves",
            feedback: "Avoiding intervention can let conflicts fester.",
            score: 25,
            isOptimal: false,
          },
          {
            id: "c",
            text: "Facilitate a structured conversation to understand both perspectives",
            feedback: "Excellent approach! Understanding precedes resolution.",
            score: 100,
            isOptimal: true,
          },
          {
            id: "d",
            text: "Reassign both to different projects",
            feedback: "This avoids the issue rather than building conflict resolution skills.",
            score: 30,
            isOptimal: false,
          },
        ],
      },
    ],
  },
  "command-shift": {
    name: "Command Shift",
    icon: Command,
    color: "#FF4500",
    scenarios: [
      {
        id: "cs-1",
        situation:
          "You're being promoted and must hand off your current responsibilities to a peer who has less experience. The transition timeline is tight. What's your priority?",
        options: [
          {
            id: "a",
            text: "Create comprehensive documentation for everything",
            feedback: "Documentation helps but isn't enough for complex responsibilities.",
            score: 50,
            isOptimal: false,
          },
          {
            id: "b",
            text: "Focus on critical decision-making frameworks and key relationships",
            feedback: "Prioritizing judgment and relationships enables independence. Excellent!",
            score: 100,
            isOptimal: true,
          },
          {
            id: "c",
            text: "Schedule daily check-ins for the first month",
            feedback: "Intensive oversight can prevent your successor from building confidence.",
            score: 40,
            isOptimal: false,
          },
          {
            id: "d",
            text: "Introduce them to stakeholders and let them learn on the job",
            feedback: "Sink-or-swim can work but risks important balls being dropped.",
            score: 45,
            isOptimal: false,
          },
        ],
      },
      {
        id: "cs-2",
        situation:
          "A senior leader asks you to take over a troubled project mid-stream. The previous lead left abruptly and the team seems demoralized. Your first move?",
        options: [
          {
            id: "a",
            text: "Review all documentation and create a new project plan",
            feedback: "Understanding history is important but team morale needs immediate attention.",
            score: 45,
            isOptimal: false,
          },
          {
            id: "b",
            text: "Meet individually with each team member to understand their perspective",
            feedback: "One-on-ones build trust and surface hidden issues. Great instinct!",
            score: 100,
            isOptimal: true,
          },
          {
            id: "c",
            text: "Call a team meeting to establish your leadership and new direction",
            feedback: "Too early for major changes without understanding the situation.",
            score: 35,
            isOptimal: false,
          },
          {
            id: "d",
            text: "Focus on quick wins to build momentum",
            feedback: "Quick wins help, but without understanding context, you might choose wrong battles.",
            score: 55,
            isOptimal: false,
          },
        ],
      },
    ],
  },
  "balance-matrix": {
    name: "Balance Matrix",
    icon: Scale,
    color: "#FFD700",
    scenarios: [
      {
        id: "bm-1",
        situation:
          "Three stakeholders have conflicting priorities for your team's Q4 capacity. Finance wants cost reduction, Product wants new features, and Operations wants stability. How do you navigate?",
        options: [
          {
            id: "a",
            text: "Escalate to leadership for a decision",
            feedback: "Escalation may be needed but try facilitation first.",
            score: 40,
            isOptimal: false,
          },
          {
            id: "b",
            text: "Propose a framework that partially addresses each priority with trade-offs clearly articulated",
            feedback: "Transparent trade-off analysis enables informed decisions. Excellent!",
            score: 100,
            isOptimal: true,
          },
          {
            id: "c",
            text: "Prioritize based on which stakeholder has more organizational power",
            feedback: "Political navigation without merit can damage credibility.",
            score: 30,
            isOptimal: false,
          },
          {
            id: "d",
            text: "Commit to all three and hope capacity expands",
            feedback: "Overcommitting sets up the team for failure.",
            score: 20,
            isOptimal: false,
          },
        ],
      },
    ],
  },
  "process-dojo": {
    name: "Process Dojo",
    icon: Swords,
    color: "#00FF88",
    scenarios: [
      {
        id: "pd-1",
        situation:
          "Your team's approval workflow has 7 steps and takes an average of 12 days. Stakeholders are frustrated. You've been asked to improve it. Where do you start?",
        options: [
          {
            id: "a",
            text: "Remove the steps that seem redundant",
            feedback: "Without analysis, you might remove critical controls.",
            score: 35,
            isOptimal: false,
          },
          {
            id: "b",
            text: "Map the current process and identify bottlenecks with data",
            feedback: "Data-driven process analysis prevents mistakes. Well done!",
            score: 100,
            isOptimal: true,
          },
          {
            id: "c",
            text: "Ask each approver why their step exists",
            feedback: "Good input, but people often justify their role without objective analysis.",
            score: 60,
            isOptimal: false,
          },
          {
            id: "d",
            text: "Implement parallel approvals immediately",
            feedback: "Parallel processing can help but may create coordination issues.",
            score: 45,
            isOptimal: false,
          },
        ],
      },
    ],
  },
  "ledger-of-people": {
    name: "Ledger of People",
    icon: BookOpen,
    color: "#A020F0",
    scenarios: [
      {
        id: "lp-1",
        situation:
          "An employee requests access to their complete personnel file. You discover some manager notes contain subjective opinions that could be misinterpreted. What's your approach?",
        options: [
          {
            id: "a",
            text: "Provide everything as requested—they have a right to their file",
            feedback: "Transparency is important but some documents may need context.",
            score: 55,
            isOptimal: false,
          },
          {
            id: "b",
            text: "Consult with HR/Legal about what must be disclosed and provide with appropriate context",
            feedback: "Balancing transparency with proper process protects everyone. Excellent!",
            score: 100,
            isOptimal: true,
          },
          {
            id: "c",
            text: "Remove the subjective notes before sharing",
            feedback: "Altering records is problematic and potentially illegal.",
            score: 10,
            isOptimal: false,
          },
          {
            id: "d",
            text: "Delay the request while you figure out the best approach",
            feedback: "Unnecessary delays can appear like you're hiding something.",
            score: 30,
            isOptimal: false,
          },
        ],
      },
    ],
  },
  "perspective-portal": {
    name: "Perspective Portal",
    icon: Eye,
    color: "#FF1A8C",
    scenarios: [
      {
        id: "pp-1",
        situation:
          "Engineering says the sales team makes impossible promises. Sales says engineering is too slow and rigid. Both sides have brought complaints to you. How do you build understanding?",
        options: [
          {
            id: "a",
            text: "Create a shared Slack channel for better communication",
            feedback: "Tools don't fix relationship problems.",
            score: 25,
            isOptimal: false,
          },
          {
            id: "b",
            text: "Have each team shadow the other for a day",
            feedback: "Experiential learning builds lasting empathy. Excellent choice!",
            score: 100,
            isOptimal: true,
          },
          {
            id: "c",
            text: "Set up a weekly sync meeting with both teams",
            feedback: "Meetings without empathy become complaint sessions.",
            score: 40,
            isOptimal: false,
          },
          {
            id: "d",
            text: "Create clear SLAs and escalation paths",
            feedback: "Process helps but doesn't address the underlying disconnect.",
            score: 50,
            isOptimal: false,
          },
        ],
      },
    ],
  },
}

export default function HRMGamePage({ params }: { params: Promise<{ gameId: string }> }) {
  const resolvedParams = use(params)
  const router = useRouter()
  const searchParams = useSearchParams()
  const mode = searchParams.get("mode") || "Visual/Interactive"

  const [currentScenario, setCurrentScenario] = useState(0)
  const [selectedOption, setSelectedOption] = useState<string | null>(null)
  const [showFeedback, setShowFeedback] = useState(false)
  const [totalScore, setTotalScore] = useState(0)
  const [gameComplete, setGameComplete] = useState(false)
  const [timeElapsed, setTimeElapsed] = useState(0)

  const gameData = GAME_DATA[resolvedParams.gameId]

  useEffect(() => {
    if (!gameComplete) {
      const timer = setInterval(() => setTimeElapsed((t) => t + 1), 1000)
      return () => clearInterval(timer)
    }
  }, [gameComplete])

  if (!gameData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black">
        <div className="text-center">
          <h1 className="text-2xl font-display text-white mb-4">Game Not Found</h1>
          <button
            onClick={() => router.push("/hrm")}
            className="px-4 py-2 rounded-lg font-mono text-sm"
            style={{ background: HRM_COLORS.primary, color: "#000" }}
          >
            Return to HRM
          </button>
        </div>
      </div>
    )
  }

  const Icon = gameData.icon
  const scenario = gameData.scenarios[currentScenario]
  const selectedOptionData = scenario?.options.find((o) => o.id === selectedOption)

  const handleOptionSelect = (optionId: string) => {
    if (showFeedback) return
    setSelectedOption(optionId)
    setShowFeedback(true)
    const option = scenario.options.find((o) => o.id === optionId)
    if (option) {
      setTotalScore((prev) => prev + option.score)
    }
  }

  const handleNext = () => {
    if (currentScenario < gameData.scenarios.length - 1) {
      setCurrentScenario((prev) => prev + 1)
      setSelectedOption(null)
      setShowFeedback(false)
    } else {
      setGameComplete(true)
    }
  }

  const handleRestart = () => {
    setCurrentScenario(0)
    setSelectedOption(null)
    setShowFeedback(false)
    setTotalScore(0)
    setGameComplete(false)
    setTimeElapsed(0)
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const maxScore = gameData.scenarios.length * 100
  const scorePercentage = Math.round((totalScore / maxScore) * 100)

  if (gameComplete) {
    return (
      <div className="min-h-screen relative" style={{ backgroundColor: HRM_COLORS.dark }}>
        <LiveCircuitry />

        <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
          <div
            className="max-w-md w-full p-8 rounded-2xl text-center"
            style={{
              background: "rgba(0, 0, 0, 0.8)",
              border: `1px solid ${gameData.color}`,
              boxShadow: `0 0 60px ${gameData.color}30`,
            }}
          >
            <Trophy className="w-16 h-16 mx-auto mb-4" style={{ color: HRM_COLORS.accent }} />
            <h1 className="font-display text-3xl mb-2" style={{ color: gameData.color }}>
              Training Complete
            </h1>
            <p className="text-neutral-400 mb-6">{gameData.name}</p>

            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="p-4 rounded-xl" style={{ background: `${gameData.color}10` }}>
                <div className="text-3xl font-display" style={{ color: gameData.color }}>
                  {totalScore}
                </div>
                <div className="text-xs font-mono text-neutral-500 uppercase">Score</div>
              </div>
              <div className="p-4 rounded-xl" style={{ background: `${HRM_COLORS.accent}10` }}>
                <div className="text-3xl font-display" style={{ color: HRM_COLORS.accent }}>
                  {scorePercentage}%
                </div>
                <div className="text-xs font-mono text-neutral-500 uppercase">Accuracy</div>
              </div>
            </div>

            <div className="flex items-center justify-center gap-2 mb-8 text-neutral-500">
              <Clock className="w-4 h-4" />
              <span className="font-mono text-sm">{formatTime(timeElapsed)}</span>
            </div>

            <div className="flex gap-3">
              <button
                onClick={handleRestart}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-mono text-sm uppercase transition-all"
                style={{
                  background: "transparent",
                  border: `1px solid ${gameData.color}`,
                  color: gameData.color,
                }}
              >
                <RotateCcw className="w-4 h-4" />
                Retry
              </button>
              <button
                onClick={() => router.push("/hrm")}
                className="flex-1 px-4 py-3 rounded-xl font-mono text-sm uppercase transition-all"
                style={{
                  background: gameData.color,
                  color: "#000",
                }}
              >
                Continue
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: HRM_COLORS.dark }}>
      <LiveCircuitry />

      {/* Header */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(0, 0, 0, 0.9)",
          borderColor: `${gameData.color}30`,
        }}
      >
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => router.push("/hrm")}
                className="flex items-center gap-2 transition-colors hover:opacity-80"
                style={{ color: gameData.color }}
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-2">
                <Icon className="w-5 h-5" style={{ color: gameData.color }} />
                <h1 className="font-display text-lg" style={{ color: gameData.color }}>
                  {gameData.name}
                </h1>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-neutral-500">
                <Clock className="w-4 h-4" />
                <span className="font-mono text-sm">{formatTime(timeElapsed)}</span>
              </div>
              <div className="font-mono text-sm" style={{ color: gameData.color }}>
                {currentScenario + 1}/{gameData.scenarios.length}
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 py-8">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="h-1 rounded-full overflow-hidden" style={{ background: `${gameData.color}20` }}>
            <div
              className="h-full transition-all duration-500"
              style={{
                width: `${((currentScenario + (showFeedback ? 1 : 0)) / gameData.scenarios.length) * 100}%`,
                background: gameData.color,
                boxShadow: `0 0 10px ${gameData.color}`,
              }}
            />
          </div>
        </div>

        {/* Mode Badge */}
        <div className="mb-4">
          <span
            className="px-3 py-1 rounded-full text-xs font-mono uppercase"
            style={{ background: `${gameData.color}20`, color: gameData.color }}
          >
            {mode}
          </span>
        </div>

        {/* Scenario */}
        <div
          className="p-6 rounded-2xl mb-6"
          style={{
            background: "rgba(0, 0, 0, 0.6)",
            border: `1px solid ${gameData.color}30`,
          }}
        >
          <h2 className="text-lg text-white leading-relaxed">{scenario.situation}</h2>
        </div>

        {/* Options */}
        <div className="space-y-3 mb-6">
          {scenario.options.map((option) => {
            const isSelected = selectedOption === option.id
            const showResult = showFeedback && isSelected

            return (
              <button
                key={option.id}
                onClick={() => handleOptionSelect(option.id)}
                disabled={showFeedback}
                className="w-full p-4 rounded-xl text-left transition-all"
                style={{
                  background: showResult
                    ? option.isOptimal
                      ? `${HRM_COLORS.success}15`
                      : `${HRM_COLORS.error}15`
                    : isSelected
                      ? `${gameData.color}15`
                      : "rgba(0, 0, 0, 0.4)",
                  border: `1px solid ${
                    showResult
                      ? option.isOptimal
                        ? HRM_COLORS.success
                        : HRM_COLORS.error
                      : isSelected
                        ? gameData.color
                        : "rgba(255,255,255,0.1)"
                  }`,
                  opacity: showFeedback && !isSelected ? 0.5 : 1,
                }}
              >
                <div className="flex items-start gap-3">
                  <span
                    className="flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center font-mono text-sm uppercase"
                    style={{
                      background: showResult
                        ? option.isOptimal
                          ? `${HRM_COLORS.success}20`
                          : `${HRM_COLORS.error}20`
                        : `${gameData.color}20`,
                      color: showResult ? (option.isOptimal ? HRM_COLORS.success : HRM_COLORS.error) : gameData.color,
                    }}
                  >
                    {option.id}
                  </span>
                  <div className="flex-1">
                    <p className="text-white">{option.text}</p>
                    {showResult && (
                      <div className="mt-3 flex items-start gap-2">
                        {option.isOptimal ? (
                          <CheckCircle className="w-5 h-5 flex-shrink-0" style={{ color: HRM_COLORS.success }} />
                        ) : (
                          <XCircle className="w-5 h-5 flex-shrink-0" style={{ color: HRM_COLORS.error }} />
                        )}
                        <p className="text-sm text-neutral-400">{option.feedback}</p>
                      </div>
                    )}
                  </div>
                  {showResult && (
                    <span
                      className="font-mono text-sm"
                      style={{ color: option.isOptimal ? HRM_COLORS.success : HRM_COLORS.error }}
                    >
                      +{option.score}
                    </span>
                  )}
                </div>
              </button>
            )
          })}
        </div>

        {/* Show optimal answer if wrong */}
        {showFeedback && selectedOptionData && !selectedOptionData.isOptimal && (
          <div
            className="p-4 rounded-xl mb-6"
            style={{
              background: `${HRM_COLORS.success}10`,
              border: `1px solid ${HRM_COLORS.success}30`,
            }}
          >
            <div className="flex items-start gap-2">
              <CheckCircle className="w-5 h-5 flex-shrink-0" style={{ color: HRM_COLORS.success }} />
              <div>
                <p className="text-sm font-medium" style={{ color: HRM_COLORS.success }}>
                  Optimal Response:
                </p>
                <p className="text-sm text-neutral-400 mt-1">{scenario.options.find((o) => o.isOptimal)?.text}</p>
              </div>
            </div>
          </div>
        )}

        {/* Next Button */}
        {showFeedback && (
          <button
            onClick={handleNext}
            className="w-full flex items-center justify-center gap-2 px-6 py-4 rounded-xl font-mono text-sm uppercase transition-all"
            style={{
              background: gameData.color,
              color: "#000",
            }}
          >
            {currentScenario < gameData.scenarios.length - 1 ? "Next Scenario" : "Complete Training"}
            <ChevronRight className="w-5 h-5" />
          </button>
        )}

        {/* Score Display */}
        <div
          className="fixed bottom-4 right-4 px-4 py-2 rounded-xl font-mono text-sm"
          style={{
            background: "rgba(0, 0, 0, 0.8)",
            border: `1px solid ${gameData.color}30`,
            color: gameData.color,
          }}
        >
          Score: {totalScore}
        </div>
      </main>
    </div>
  )
}
