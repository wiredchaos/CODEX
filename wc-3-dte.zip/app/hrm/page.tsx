"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Compass, Command, Scale, Swords, BookOpen, Eye, Play, Trophy, Zap, Users } from "lucide-react"
import { LiveCircuitry } from "@/components/live-circuitry"

const HRM_COLORS = {
  primary: "#00FFF7",
  secondary: "#FF4500",
  accent: "#FFD700",
  dark: "#000000",
  glow: "rgba(0, 255, 247, 0.5)",
}

interface Game {
  id: string
  name: string
  description: string
  icon: typeof Compass
  color: string
  modes: string[]
  difficulty: "beginner" | "intermediate" | "advanced"
  xpReward: number
  completions: number
  realm: "business" | "akashic"
}

const HRM_GAMES: Game[] = [
  {
    id: "emotional-compass",
    name: "Emotional Compass",
    description: "Navigate emotional intelligence scenarios. Learn to read and respond to team dynamics.",
    icon: Compass,
    color: "#00FFF7",
    modes: ["Visual/Interactive", "Scenario/Text", "Mixed"],
    difficulty: "beginner",
    xpReward: 150,
    completions: 2847,
    realm: "business",
  },
  {
    id: "command-shift",
    name: "Command Shift",
    description: "Master leadership transitions. Practice delegation, authority transfer, and team restructuring.",
    icon: Command,
    color: "#FF4500",
    modes: ["Visual/Interactive", "Scenario/Text", "Mixed"],
    difficulty: "intermediate",
    xpReward: 250,
    completions: 1563,
    realm: "business",
  },
  {
    id: "balance-matrix",
    name: "Balance Matrix",
    description: "Optimize work-life equilibrium. Balance competing priorities and stakeholder needs.",
    icon: Scale,
    color: "#FFD700",
    modes: ["Visual/Interactive", "Scenario/Text", "Mixed"],
    difficulty: "beginner",
    xpReward: 175,
    completions: 3201,
    realm: "business",
  },
  {
    id: "process-dojo",
    name: "Process Dojo",
    description: "Train operational excellence. Streamline workflows and eliminate inefficiencies.",
    icon: Swords,
    color: "#00FF88",
    modes: ["Visual/Interactive", "Scenario/Text", "Mixed"],
    difficulty: "advanced",
    xpReward: 350,
    completions: 892,
    realm: "business",
  },
  {
    id: "ledger-of-people",
    name: "Ledger of People",
    description: "Master HR documentation. Navigate compliance, records, and personnel management.",
    icon: BookOpen,
    color: "#A020F0",
    modes: ["Visual/Interactive", "Scenario/Text", "Mixed"],
    difficulty: "intermediate",
    xpReward: 225,
    completions: 1876,
    realm: "akashic",
  },
  {
    id: "perspective-portal",
    name: "Perspective Portal",
    description: "Explore multiple viewpoints. Practice empathy and cross-functional understanding.",
    icon: Eye,
    color: "#FF1A8C",
    modes: ["Visual/Interactive", "Scenario/Text", "Mixed"],
    difficulty: "advanced",
    xpReward: 300,
    completions: 1124,
    realm: "akashic",
  },
]

const DIFFICULTY_COLORS = {
  beginner: "#00FF88",
  intermediate: "#FFD700",
  advanced: "#FF4500",
}

export default function HRMPage() {
  const router = useRouter()
  const [selectedGame, setSelectedGame] = useState<string | null>(null)
  const [selectedMode, setSelectedMode] = useState<string>("Visual/Interactive")
  const [filterRealm, setFilterRealm] = useState<"all" | "business" | "akashic">("all")

  const filteredGames = filterRealm === "all" ? HRM_GAMES : HRM_GAMES.filter((g) => g.realm === filterRealm)

  const totalXP = HRM_GAMES.reduce((acc, g) => acc + g.xpReward, 0)
  const totalCompletions = HRM_GAMES.reduce((acc, g) => acc + g.completions, 0)

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: HRM_COLORS.dark }}>
      <LiveCircuitry />

      {/* Grid Background */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${HRM_COLORS.primary}15 1px, transparent 1px),
            linear-gradient(to bottom, ${HRM_COLORS.primary}15 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Header */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(0, 0, 0, 0.9)",
          borderColor: `${HRM_COLORS.primary}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => router.push("/")}
                className="flex items-center gap-2 transition-colors hover:opacity-80"
                style={{ color: HRM_COLORS.primary }}
              >
                <ArrowLeft className="w-5 h-5" />
                <span className="font-mono text-sm uppercase hidden sm:inline">Lobby</span>
              </button>
              <div className="w-px h-6" style={{ background: `${HRM_COLORS.primary}30` }} />
              <div className="flex items-center gap-2">
                <Trophy className="w-6 h-6" style={{ color: HRM_COLORS.accent }} />
                <h1
                  className="font-display text-2xl uppercase tracking-wider"
                  style={{
                    color: HRM_COLORS.primary,
                    textShadow: `0 0 20px ${HRM_COLORS.glow}`,
                  }}
                >
                  HRM TRAINING
                </h1>
              </div>
            </div>
            <div className="text-xs font-mono text-neutral-500">HUMAN RESOURCE MASTERY</div>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Stats Bar */}
        <div
          className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8 p-4 rounded-xl"
          style={{
            background: "rgba(0, 0, 0, 0.6)",
            border: `1px solid ${HRM_COLORS.primary}20`,
          }}
        >
          <div className="text-center">
            <div className="text-2xl font-display" style={{ color: HRM_COLORS.accent }}>
              6
            </div>
            <div className="text-xs font-mono text-neutral-500 uppercase">Games</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-display" style={{ color: HRM_COLORS.primary }}>
              {totalXP}
            </div>
            <div className="text-xs font-mono text-neutral-500 uppercase">Total XP</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-display" style={{ color: HRM_COLORS.secondary }}>
              3
            </div>
            <div className="text-xs font-mono text-neutral-500 uppercase">Modes</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-display text-white">{totalCompletions.toLocaleString()}</div>
            <div className="text-xs font-mono text-neutral-500 uppercase">Completions</div>
          </div>
        </div>

        {/* Realm Filter */}
        <div className="flex items-center gap-2 mb-6">
          <span className="font-mono text-xs text-neutral-500 uppercase">Filter:</span>
          {(["all", "business", "akashic"] as const).map((realm) => (
            <button
              key={realm}
              onClick={() => setFilterRealm(realm)}
              className="px-3 py-1.5 rounded-lg font-mono text-xs uppercase transition-all"
              style={{
                background: filterRealm === realm ? `${HRM_COLORS.primary}20` : "rgba(0,0,0,0.4)",
                border: `1px solid ${filterRealm === realm ? HRM_COLORS.primary : "rgba(255,255,255,0.1)"}`,
                color: filterRealm === realm ? HRM_COLORS.primary : "#888",
              }}
            >
              {realm}
            </button>
          ))}
        </div>

        {/* Games Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredGames.map((game) => {
            const Icon = game.icon
            const isSelected = selectedGame === game.id

            return (
              <div
                key={game.id}
                className="rounded-xl overflow-hidden transition-all hover:scale-[1.02]"
                style={{
                  background: isSelected ? `${game.color}10` : "rgba(0, 0, 0, 0.6)",
                  border: `1px solid ${isSelected ? game.color : "rgba(255,255,255,0.1)"}`,
                  boxShadow: isSelected ? `0 0 30px ${game.color}30` : "none",
                }}
              >
                {/* Game Header */}
                <div className="p-4 border-b" style={{ borderColor: `${game.color}30` }}>
                  <div className="flex items-start justify-between mb-3">
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center"
                      style={{ background: `${game.color}20` }}
                    >
                      <Icon className="w-6 h-6" style={{ color: game.color }} />
                    </div>
                    <div className="flex items-center gap-2">
                      <span
                        className="px-2 py-0.5 rounded text-xs font-mono uppercase"
                        style={{
                          background: `${DIFFICULTY_COLORS[game.difficulty]}20`,
                          color: DIFFICULTY_COLORS[game.difficulty],
                        }}
                      >
                        {game.difficulty}
                      </span>
                      <span
                        className="px-2 py-0.5 rounded text-xs font-mono uppercase"
                        style={{
                          background: game.realm === "business" ? "rgba(0,255,247,0.1)" : "rgba(160,32,240,0.1)",
                          color: game.realm === "business" ? "#00FFF7" : "#A020F0",
                        }}
                      >
                        {game.realm}
                      </span>
                    </div>
                  </div>
                  <h3 className="font-display text-xl mb-1" style={{ color: game.color }}>
                    {game.name}
                  </h3>
                  <p className="text-sm text-neutral-400 line-clamp-2">{game.description}</p>
                </div>

                {/* Game Stats */}
                <div className="p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <Zap className="w-4 h-4" style={{ color: HRM_COLORS.accent }} />
                      <span className="font-mono text-sm" style={{ color: HRM_COLORS.accent }}>
                        +{game.xpReward} XP
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-neutral-500" />
                      <span className="font-mono text-xs text-neutral-500">
                        {game.completions.toLocaleString()} plays
                      </span>
                    </div>
                  </div>

                  {/* Mode Selection */}
                  {isSelected && (
                    <div className="mb-4 space-y-2">
                      <span className="font-mono text-xs text-neutral-500 uppercase">Select Mode:</span>
                      <div className="grid grid-cols-1 gap-2">
                        {game.modes.map((mode) => (
                          <button
                            key={mode}
                            onClick={() => setSelectedMode(mode)}
                            className="px-3 py-2 rounded-lg font-mono text-xs text-left transition-all"
                            style={{
                              background: selectedMode === mode ? `${game.color}20` : "rgba(0,0,0,0.4)",
                              border: `1px solid ${selectedMode === mode ? game.color : "rgba(255,255,255,0.05)"}`,
                              color: selectedMode === mode ? game.color : "#888",
                            }}
                          >
                            {mode}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    <button
                      onClick={() => setSelectedGame(isSelected ? null : game.id)}
                      className="flex-1 px-4 py-2.5 rounded-lg font-mono text-sm uppercase transition-all"
                      style={{
                        background: isSelected ? "transparent" : `${game.color}20`,
                        border: `1px solid ${game.color}`,
                        color: game.color,
                      }}
                    >
                      {isSelected ? "Close" : "Configure"}
                    </button>
                    {isSelected && (
                      <button
                        onClick={() => router.push(`/hrm/${game.id}?mode=${encodeURIComponent(selectedMode)}`)}
                        className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg font-mono text-sm uppercase transition-all"
                        style={{
                          background: game.color,
                          color: "#000",
                        }}
                      >
                        <Play className="w-4 h-4" />
                        Start
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        {/* Learning Paths Section */}
        <section className="mt-12">
          <h2 className="font-mono text-sm uppercase tracking-wider mb-4" style={{ color: HRM_COLORS.primary }}>
            Recommended Learning Paths
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div
              className="p-4 rounded-xl"
              style={{
                background: "rgba(0, 0, 0, 0.6)",
                border: `1px solid ${HRM_COLORS.primary}20`,
              }}
            >
              <h3 className="font-display text-lg mb-2" style={{ color: HRM_COLORS.primary }}>
                New Manager Track
              </h3>
              <p className="text-sm text-neutral-400 mb-3">
                Essential skills for first-time managers. Build emotional intelligence and delegation mastery.
              </p>
              <div className="flex items-center gap-2">
                <span className="px-2 py-1 rounded text-xs font-mono bg-white/5 text-neutral-400">3 Games</span>
                <span
                  className="px-2 py-1 rounded text-xs font-mono"
                  style={{ background: `${HRM_COLORS.accent}20`, color: HRM_COLORS.accent }}
                >
                  575 XP
                </span>
              </div>
            </div>
            <div
              className="p-4 rounded-xl"
              style={{
                background: "rgba(0, 0, 0, 0.6)",
                border: `1px solid ${HRM_COLORS.secondary}20`,
              }}
            >
              <h3 className="font-display text-lg mb-2" style={{ color: HRM_COLORS.secondary }}>
                Operations Excellence
              </h3>
              <p className="text-sm text-neutral-400 mb-3">
                Advanced process optimization and cross-functional leadership techniques.
              </p>
              <div className="flex items-center gap-2">
                <span className="px-2 py-1 rounded text-xs font-mono bg-white/5 text-neutral-400">4 Games</span>
                <span
                  className="px-2 py-1 rounded text-xs font-mono"
                  style={{ background: `${HRM_COLORS.accent}20`, color: HRM_COLORS.accent }}
                >
                  875 XP
                </span>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}
