"use client"

import { useRouter } from "next/navigation"
import Link from "next/link"
import { ArrowLeft, Globe2 } from "lucide-react"
import { GlobeModels } from "@/components/globe-models"
import { LiveCircuitry } from "@/components/live-circuitry"

const GLOBE_COLORS = {
  primary: "#00FFF7",
  secondary: "#FF4500",
  dark: "#000000",
}

export default function GlobePage() {
  const router = useRouter()

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: GLOBE_COLORS.dark }}>
      <LiveCircuitry />

      {/* Header */}
      <header
        className="fixed top-0 left-0 right-0 z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(0, 0, 0, 0.9)",
          borderColor: `${GLOBE_COLORS.primary}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link
                href="/"
                className="flex items-center gap-2 transition-colors hover:opacity-80"
                style={{ color: GLOBE_COLORS.primary }}
              >
                <ArrowLeft className="w-5 h-5" />
                <span className="font-mono text-sm uppercase hidden sm:inline">Lobby</span>
              </Link>
              <div className="w-px h-6" style={{ background: `${GLOBE_COLORS.primary}30` }} />
              <div className="flex items-center gap-2">
                <Globe2 className="w-6 h-6" style={{ color: GLOBE_COLORS.primary }} />
                <h1 className="font-display text-xl uppercase tracking-wider" style={{ color: GLOBE_COLORS.primary }}>
                  Earth Models
                </h1>
              </div>
            </div>
            <div className="text-xs font-mono text-neutral-500">BELIEF SYSTEM VARIANTS</div>
          </div>
        </div>
      </header>

      {/* Globe Viewer */}
      <div className="pt-20 h-screen">
        <GlobeModels showControls={true} className="w-full h-full" />
      </div>

      {/* Info Panel */}
      <div
        className="fixed bottom-4 left-4 max-w-sm p-4 rounded-xl z-20"
        style={{
          background: "rgba(0, 0, 0, 0.85)",
          border: `1px solid ${GLOBE_COLORS.primary}30`,
        }}
      >
        <h3 className="font-mono text-sm uppercase tracking-wider mb-2" style={{ color: GLOBE_COLORS.primary }}>
          Patch Index Globe Models
        </h3>
        <p className="text-xs text-neutral-400 leading-relaxed">
          Each patch in the Neteru Apinaya Index contains its own globe model variant. Toggle between Standard Globe
          with Lei Lines, Flat Earth with Firmament Dome, and Hollow Earth with Agartha visualization.
        </p>
        <div className="mt-3 pt-3 border-t border-neutral-800">
          <p className="text-xs text-neutral-500">
            Sacred sites marked include portals, energy nodes, vortex points, and anomaly zones. Lei lines connect sites
            within proximity threshold.
          </p>
        </div>
      </div>
    </div>
  )
}
