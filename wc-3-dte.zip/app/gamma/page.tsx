"use client"

import { useRouter } from "next/navigation"
import { ArrowLeft, Play, Tv, Film } from "lucide-react"
import { LiveCircuitry } from "@/components/live-circuitry"

export default function GammaPage() {
  const router = useRouter()

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: "#000" }}>
      <LiveCircuitry />

      {/* Header */}
      <header
        className="relative z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(0, 0, 0, 0.95)",
          borderColor: "rgba(255, 107, 53, 0.3)",
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => router.push("/")}
                className="flex items-center gap-2 transition-colors hover:opacity-80"
                style={{ color: "#FF6B35" }}
                aria-label="Return to lobby"
              >
                <ArrowLeft className="w-5 h-5" />
                <span className="font-mono text-sm uppercase">Lobby</span>
              </button>
              <div className="w-px h-6" style={{ background: "rgba(255, 107, 53, 0.3)" }} />
              <div className="flex items-center gap-3">
                <Film className="w-6 h-6" style={{ color: "#FF6B35" }} />
                <h1
                  className="font-display text-xl sm:text-2xl uppercase tracking-wider"
                  style={{
                    color: "#FF6B35",
                    textShadow: "0 0 20px rgba(255, 107, 53, 0.5)",
                  }}
                >
                  GAMMA — DD CARTOONS
                </h1>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        {/* Title Section */}
        <div className="text-center mb-12">
          <h2
            className="font-display text-5xl sm:text-7xl uppercase mb-4"
            style={{
              color: "#FF6B35",
              textShadow: "0 0 40px rgba(255, 107, 53, 0.8)",
            }}
          >
            GAMMA FLOOR
          </h2>
          <p className="font-mono text-sm sm:text-base text-neutral-400">
            DD CARTOONS • Animation Studio • Creator Codex Integration
          </p>
        </div>

        <div
          className="relative w-full rounded-2xl overflow-hidden"
          style={{
            border: "2px solid #FF6B35",
            boxShadow: "0 0 40px rgba(255, 107, 53, 0.3)",
            background: "rgba(0,0,0,0.8)",
            minHeight: "600px",
          }}
        >
          <iframe
            src="https://v0.app/chat/ppnMEcNEKoM"
            className="w-full h-[600px] md:h-[800px]"
            title="GAMMA DD CARTOONS Studio"
            style={{ border: "none" }}
          />
        </div>

        {/* Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
          <div
            className="p-6 rounded-xl"
            style={{
              background: "rgba(255, 107, 53, 0.1)",
              border: "1px solid rgba(255, 107, 53, 0.3)",
            }}
          >
            <Tv className="w-8 h-8 mb-3" style={{ color: "#FF6B35" }} />
            <h3 className="text-lg font-display uppercase mb-2" style={{ color: "#FF6B35" }}>
              Animation Studio
            </h3>
            <p className="text-sm text-neutral-400">
              Create and manage animated content with blockchain-based royalty tracking
            </p>
          </div>

          <div
            className="p-6 rounded-xl"
            style={{
              background: "rgba(255, 107, 53, 0.1)",
              border: "1px solid rgba(255, 107, 53, 0.3)",
            }}
          >
            <Play className="w-8 h-8 mb-3" style={{ color: "#FF6B35" }} />
            <h3 className="text-lg font-display uppercase mb-2" style={{ color: "#FF6B35" }}>
              Creator Codex
            </h3>
            <p className="text-sm text-neutral-400">Bot creation and NEURO PROMPT COMMAND integration for AI agents</p>
          </div>

          <div
            className="p-6 rounded-xl"
            style={{
              background: "rgba(255, 107, 53, 0.1)",
              border: "1px solid rgba(255, 107, 53, 0.3)",
            }}
          >
            <Film className="w-8 h-8 mb-3" style={{ color: "#FF6B35" }} />
            <h3 className="text-lg font-display uppercase mb-2" style={{ color: "#FF6B35" }}>
              IP Management
            </h3>
            <p className="text-sm text-neutral-400">Rights registry and royalty splits powered by Dogechain</p>
          </div>
        </div>
      </main>
    </div>
  )
}
