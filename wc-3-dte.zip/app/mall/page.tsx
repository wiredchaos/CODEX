"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, ShoppingBag, Search, Heart, ShoppingCart, Star, Sparkles, Tag } from "lucide-react"
import { LiveCircuitry } from "@/components/live-circuitry"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

const MALL_COLORS = {
  primary: "#00FFF7",
  secondary: "#FF1A1A",
  accent: "#FFD700",
  dark: "#000000",
  glow: "rgba(0, 255, 247, 0.5)",
}

const CATEGORIES = ["All", "Apparel", "Digital", "Collectibles", "Music", "Art", "Tech"]

const PRODUCTS = [
  {
    id: 1,
    name: "WIRED CHAOS Hoodie",
    category: "Apparel",
    price: 89,
    xp: 250,
    image: "/cyberpunk-hoodie-black-neon.jpg",
    rarity: "Common",
    rating: 4.8,
  },
  {
    id: 2,
    name: "NEURAL DRIFT NFT",
    category: "Digital",
    price: 0.5,
    xp: 1000,
    currency: "ETH",
    image: "/abstract-nft-art-neon-cyan.jpg",
    rarity: "Rare",
    rating: 4.9,
  },
  {
    id: 3,
    name: "789 Studios Cap",
    category: "Apparel",
    price: 45,
    xp: 150,
    image: "/cyberpunk-cap-gold-black.jpg",
    rarity: "Common",
    rating: 4.7,
  },
  {
    id: 4,
    name: "CHAOS SOUNDS Vol. 1",
    category: "Music",
    price: 15,
    xp: 500,
    image: "/album-cover-cyberpunk-music.jpg",
    rarity: "Uncommon",
    rating: 5.0,
  },
  {
    id: 5,
    name: "Akashic Key Pass",
    category: "Digital",
    price: 1.0,
    xp: 5000,
    currency: "ETH",
    image: "/digital-key-pass-purple-gold.jpg",
    rarity: "Legendary",
    rating: 5.0,
  },
  {
    id: 6,
    name: "NEURO Avatar Pack",
    category: "Digital",
    price: 25,
    xp: 750,
    image: "/placeholder.svg?height=400&width=400",
    rarity: "Rare",
    rating: 4.6,
  },
  {
    id: 7,
    name: "Chaos Art Print",
    category: "Art",
    price: 120,
    xp: 400,
    image: "/placeholder.svg?height=400&width=400",
    rarity: "Uncommon",
    rating: 4.8,
  },
  {
    id: 8,
    name: "Signal Ghost Headphones",
    category: "Tech",
    price: 299,
    xp: 1500,
    image: "/placeholder.svg?height=400&width=400",
    rarity: "Epic",
    rating: 4.9,
  },
]

const RARITY_COLORS: Record<string, string> = {
  Common: "#A0A0A0",
  Uncommon: "#00FF88",
  Rare: "#0088FF",
  Epic: "#A020F0",
  Legendary: "#FFD700",
}

export default function MallPage() {
  const router = useRouter()
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [searchQuery, setSearchQuery] = useState("")
  const [wishlist, setWishlist] = useState<number[]>([])
  const [cart, setCart] = useState<number[]>([])

  const filteredProducts = PRODUCTS.filter((product) => {
    const matchesCategory = selectedCategory === "All" || product.category === selectedCategory
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesCategory && matchesSearch
  })

  const toggleWishlist = (id: number) => {
    setWishlist((prev) => (prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]))
  }

  const addToCart = (id: number) => {
    if (!cart.includes(id)) {
      setCart((prev) => [...prev, id])
    }
  }

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: MALL_COLORS.dark }}>
      <LiveCircuitry />

      {/* Grid Background */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${MALL_COLORS.primary}15 1px, transparent 1px),
            linear-gradient(to bottom, ${MALL_COLORS.primary}15 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Header */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(0, 0, 0, 0.9)",
          borderColor: `${MALL_COLORS.primary}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <button
                onClick={() => router.push("/")}
                className="flex items-center gap-2 transition-colors hover:opacity-80"
                style={{ color: MALL_COLORS.primary }}
              >
                <ArrowLeft className="w-5 h-5" />
                <span className="font-mono text-sm uppercase hidden sm:inline">Lobby</span>
              </button>
              <div className="w-px h-6" style={{ background: `${MALL_COLORS.primary}30` }} />
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-6 h-6" style={{ color: MALL_COLORS.primary }} />
                <h1
                  className="font-display text-2xl uppercase tracking-wider"
                  style={{
                    color: MALL_COLORS.primary,
                    textShadow: `0 0 20px ${MALL_COLORS.glow}`,
                  }}
                >
                  CHAOS MALL
                </h1>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                className="relative p-2 rounded-lg transition-colors hover:bg-white/5"
                style={{ color: MALL_COLORS.primary }}
              >
                <Heart className="w-5 h-5" />
                {wishlist.length > 0 && (
                  <span
                    className="absolute -top-1 -right-1 w-4 h-4 rounded-full text-xs flex items-center justify-center"
                    style={{ background: MALL_COLORS.secondary, color: "#fff" }}
                  >
                    {wishlist.length}
                  </span>
                )}
              </button>
              <button
                className="relative p-2 rounded-lg transition-colors hover:bg-white/5"
                style={{ color: MALL_COLORS.primary }}
              >
                <ShoppingCart className="w-5 h-5" />
                {cart.length > 0 && (
                  <span
                    className="absolute -top-1 -right-1 w-4 h-4 rounded-full text-xs flex items-center justify-center"
                    style={{ background: MALL_COLORS.accent, color: "#000" }}
                  >
                    {cart.length}
                  </span>
                )}
              </button>
            </div>
          </div>

          {/* Search and Categories */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
              <Input
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-black/50 border-neutral-800 focus:border-cyan-500"
              />
            </div>
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className="px-3 py-1.5 rounded-full font-mono text-xs uppercase whitespace-nowrap transition-all"
                  style={{
                    background: selectedCategory === cat ? MALL_COLORS.primary : "transparent",
                    color: selectedCategory === cat ? "#000" : "#999",
                    border: `1px solid ${selectedCategory === cat ? MALL_COLORS.primary : "#333"}`,
                  }}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Featured Banner */}
        <div
          className="relative rounded-2xl overflow-hidden mb-8 p-8"
          style={{
            background: `linear-gradient(135deg, ${MALL_COLORS.dark}, #0a1a1a)`,
            border: `2px solid ${MALL_COLORS.primary}30`,
          }}
        >
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-5 h-5" style={{ color: MALL_COLORS.accent }} />
              <span className="font-mono text-xs uppercase" style={{ color: MALL_COLORS.accent }}>
                Featured Collection
              </span>
            </div>
            <h2 className="font-display text-3xl sm:text-4xl text-white mb-2">GENESIS DROP</h2>
            <p className="text-neutral-400 mb-4 max-w-md">
              Exclusive founding member merchandise and digital collectibles.
            </p>
            <Button style={{ background: MALL_COLORS.primary, color: "#000" }} className="font-mono uppercase">
              Explore Collection
            </Button>
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="group rounded-xl overflow-hidden transition-all hover:scale-[1.02]"
              style={{
                background: "rgba(0, 0, 0, 0.6)",
                border: `1px solid ${MALL_COLORS.primary}20`,
              }}
            >
              {/* Image */}
              <div className="relative aspect-square">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
                {/* Rarity Badge */}
                <div
                  className="absolute top-3 left-3 px-2 py-1 rounded text-xs font-mono uppercase"
                  style={{
                    background: `${RARITY_COLORS[product.rarity]}20`,
                    color: RARITY_COLORS[product.rarity],
                    border: `1px solid ${RARITY_COLORS[product.rarity]}`,
                  }}
                >
                  {product.rarity}
                </div>
                {/* Wishlist Button */}
                <button
                  onClick={() => toggleWishlist(product.id)}
                  className="absolute top-3 right-3 p-2 rounded-full transition-colors"
                  style={{
                    background: wishlist.includes(product.id) ? MALL_COLORS.secondary : "rgba(0,0,0,0.5)",
                  }}
                >
                  <Heart
                    className="w-4 h-4"
                    style={{ color: wishlist.includes(product.id) ? "#fff" : "#999" }}
                    fill={wishlist.includes(product.id) ? "#fff" : "none"}
                  />
                </button>
              </div>

              {/* Info */}
              <div className="p-4">
                <div className="flex items-center gap-1 mb-1">
                  <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                  <span className="text-xs text-neutral-400">{product.rating}</span>
                </div>
                <h3 className="font-mono text-sm text-white mb-1 truncate">{product.name}</h3>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className="font-display text-lg" style={{ color: MALL_COLORS.primary }}>
                      {product.currency === "ETH" ? `${product.price} ETH` : `$${product.price}`}
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Tag className="w-3 h-3" style={{ color: MALL_COLORS.accent }} />
                    <span className="text-xs" style={{ color: MALL_COLORS.accent }}>
                      +{product.xp} XP
                    </span>
                  </div>
                </div>
                <Button
                  onClick={() => addToCart(product.id)}
                  className="w-full font-mono text-xs uppercase"
                  style={{
                    background: cart.includes(product.id) ? "transparent" : MALL_COLORS.primary,
                    color: cart.includes(product.id) ? MALL_COLORS.primary : "#000",
                    border: `1px solid ${MALL_COLORS.primary}`,
                  }}
                  disabled={cart.includes(product.id)}
                >
                  {cart.includes(product.id) ? "In Cart" : "Add to Cart"}
                </Button>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}
