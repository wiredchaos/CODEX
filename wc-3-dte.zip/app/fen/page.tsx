"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Brain, Database, Sparkles, Zap } from "lucide-react"

const FEN_COLORS = {
  cyan: "#00FFF7",
  red: "#FF1A1A",
  purple: "#A020F0",
  silver: "#C0C0C0",
  dark: "#0D0D0D",
  glow: "rgba(0, 255, 247, 0.5)",
}

const FEN_SECTIONS = [
  {
    id: "akira",
    label: "AKIRA CODEX",
    sublabel: "Neuro Code Apinaya",
    icon: Brain,
    route: "/fen/akira",
    description: "Consciousness Architecture • Neural Patterns • Cognitive Protocols",
    color: "#A020F0",
  },
  {
    id: "589",
    label: "589 ENGINE",
    sublabel: "Trifecta Core",
    icon: Zap,
    route: "/fen/589",
    description: "Frequency Resonance • Signal Processing • Reality Interface",
    color: "#FF1A1A",
  },
  {
    id: "vault",
    label: "VAULT 33",
    sublabel: "Akashic Records",
    icon: Database,
    route: "/vault33",
    description: "9-Layer Archive • Memory Storage • Temporal Access",
    color: "#A020F0",
  },
]

export default function FENPage() {
  const router = useRouter()
  const [hoveredSection, setHoveredSection] = useState<string | null>(null)

  return (
    <div className="min-h-screen relative overflow-hidden" style={{ backgroundColor: FEN_COLORS.dark }}>
      {/* Cyan/Purple Circuit Grid */}
      <div
        className="fixed inset-0 opacity-15 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${FEN_COLORS.cyan}20 1px, transparent 1px),
            linear-gradient(to bottom, ${FEN_COLORS.purple}20 1px, transparent 1px)
          `,
          backgroundSize: "40px 40px",
        }}
      />

      {/* Glowing Circuit Nodes */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        {[...Array(10)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full"
            style={{
              width: "5px",
              height: "5px",
              left: `${10 + i * 10}%`,
              top: `${15 + i * 8}%`,
              background: i % 2 === 0 ? FEN_COLORS.cyan : FEN_COLORS.purple,
              boxShadow: `0 0 12px ${i % 2 === 0 ? FEN_COLORS.cyan : FEN_COLORS.purple}`,
              animation: `pulse ${2 + i * 0.2}s ease-in-out infinite`,
            }}
          />
        ))}
      </div>

      {/* Header */}
      <header
        className="relative z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(13, 13, 13, 0.95)",
          borderColor: `${FEN_COLORS.cyan}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => router.push("/")}
                className="flex items-center gap-2 transition-colors hover:opacity-80"
                style={{ color: FEN_COLORS.cyan }}
                aria-label="Return to lobby"
              >
                <ArrowLeft className="w-5 h-5" />
                <span className="font-mono text-sm uppercase">Lobby</span>
              </button>
              <div className="w-px h-6" style={{ background: `${FEN_COLORS.cyan}30` }} />
              <div className="flex items-center gap-3">
                <Sparkles className="w-6 h-6" style={{ color: FEN_COLORS.cyan }} />
                <h1
                  className="font-display text-xl sm:text-2xl uppercase tracking-wider"
                  style={{
                    color: FEN_COLORS.cyan,
                    textShadow: `0 0 20px ${FEN_COLORS.glow}`,
                  }}
                >
                  FEN
                </h1>
              </div>
            </div>

            <div
              className="px-3 py-1.5 rounded-full"
              style={{
                background: `${FEN_COLORS.red}20`,
                border: `1px solid ${FEN_COLORS.red}`,
              }}
            >
              <span className="font-mono text-xs uppercase" style={{ color: FEN_COLORS.red }}>
                589 TRIFECTA ENGINE
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 py-8 sm:py-16">
        {/* Title Section */}
        <div className="text-center mb-12 sm:mb-16">
          <div
            className="inline-block px-4 py-2 rounded-full mb-6"
            style={{
              background: `${FEN_COLORS.cyan}15`,
              border: `1px solid ${FEN_COLORS.cyan}40`,
            }}
          >
            <span
              className="font-mono text-xs sm:text-sm uppercase tracking-[0.3em]"
              style={{ color: FEN_COLORS.cyan }}
            >
              FEN = 589 TRIFECTA ENGINE
            </span>
          </div>
          <h2
            className="font-display text-5xl sm:text-7xl uppercase mb-4"
            style={{
              color: FEN_COLORS.cyan,
              textShadow: `0 0 40px ${FEN_COLORS.glow}, 0 0 80px ${FEN_COLORS.glow}`,
            }}
          >
            FEN
          </h2>
          <p className="font-mono text-sm sm:text-base px-4" style={{ color: FEN_COLORS.silver }}>
            Frequency • Energy • Neuralis — The Akashic Intelligence Layer
          </p>
        </div>

        {/* Section Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {FEN_SECTIONS.map((section) => {
            const Icon = section.icon
            const isHovered = hoveredSection === section.id

            return (
              <button
                key={section.id}
                onClick={() => router.push(section.route)}
                onMouseEnter={() => setHoveredSection(section.id)}
                onMouseLeave={() => setHoveredSection(null)}
                className="group relative p-6 sm:p-8 rounded-2xl text-left transition-all duration-500 focus:outline-none focus-visible:ring-2"
                style={{
                  background: isHovered
                    ? `linear-gradient(135deg, ${section.color}20, ${FEN_COLORS.dark})`
                    : "rgba(13, 13, 13, 0.9)",
                  border: `2px solid ${isHovered ? section.color : `${section.color}20`}`,
                  boxShadow: isHovered ? `0 0 40px ${section.color}40, inset 0 0 40px ${section.color}10` : "none",
                  transform: isHovered ? "scale(1.02)" : "scale(1)",
                }}
              >
                {/* Corner Accents */}
                <div
                  className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 rounded-tl-2xl transition-opacity duration-300"
                  style={{
                    borderColor: section.color,
                    opacity: isHovered ? 1 : 0,
                  }}
                />
                <div
                  className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 rounded-br-2xl transition-opacity duration-300"
                  style={{
                    borderColor: section.color,
                    opacity: isHovered ? 1 : 0,
                  }}
                />

                <div
                  className="w-14 h-14 rounded-xl flex items-center justify-center mb-6 transition-all duration-300"
                  style={{
                    background: `${section.color}20`,
                    boxShadow: isHovered ? `0 0 30px ${section.color}40` : "none",
                  }}
                >
                  <Icon className="w-7 h-7" style={{ color: section.color }} />
                </div>

                <h3
                  className="font-display text-2xl uppercase mb-2 transition-all duration-300"
                  style={{
                    color: isHovered ? section.color : FEN_COLORS.silver,
                    textShadow: isHovered ? `0 0 20px ${section.color}40` : "none",
                  }}
                >
                  {section.label}
                </h3>
                <p className="font-mono text-sm uppercase tracking-wider mb-4" style={{ color: section.color }}>
                  {section.sublabel}
                </p>
                <p className="text-sm" style={{ color: FEN_COLORS.silver }}>
                  {section.description}
                </p>
              </button>
            )
          })}
        </div>

        {/* Info Panel */}
        <div
          className="p-6 rounded-2xl text-center"
          style={{
            background: "rgba(13, 13, 13, 0.8)",
            border: `1px solid ${FEN_COLORS.cyan}30`,
          }}
        >
          <p className="font-mono text-sm mb-2" style={{ color: FEN_COLORS.cyan }}>
            FEN = FREQUENCY • ENERGY • NEURALIS
          </p>
          <p className="text-xs" style={{ color: FEN_COLORS.silver }}>
            The 589 TRIFECTA ENGINE powers the Akashic intelligence layer, integrating consciousness architecture,
            reality frequency modulation, and temporal memory access.
          </p>
        </div>
      </main>

      <style jsx>{`
        @keyframes pulse {
          0%,
          100% {
            opacity: 0.5;
          }
          50% {
            opacity: 1;
          }
        }
      `}</style>
    </div>
  )
}
