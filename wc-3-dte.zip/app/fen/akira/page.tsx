"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Brain, Code, Database, Eye, Lock, Sparkles, Zap } from "lucide-react"

const AKIRA_COLORS = {
  primary: "#A020F0",
  secondary: "#8B00FF",
  accent: "#DA70D6",
  neon: "#FF00FF",
  dark: "#0D0D0D",
  glow: "rgba(160, 32, 240, 0.5)",
}

const CODEX_SECTIONS = [
  {
    id: "neural",
    label: "NEURAL PATTERNS",
    icon: Brain,
    description: "Advanced consciousness mapping and cognitive architecture",
    status: "ACTIVE",
  },
  {
    id: "cipher",
    label: "CIPHER CORE",
    icon: Lock,
    description: "Encryption protocols and security frameworks",
    status: "ENCRYPTED",
  },
  {
    id: "database",
    label: "KNOWLEDGE BASE",
    icon: Database,
    description: "Accumulated wisdom and historical records",
    status: "SYNCING",
  },
  {
    id: "vision",
    label: "VISION SYSTEM",
    icon: Eye,
    description: "Pattern recognition and predictive analytics",
    status: "ANALYZING",
  },
  {
    id: "code",
    label: "CODE LIBRARY",
    icon: Code,
    description: "Algorithmic blueprints and execution protocols",
    status: "COMPILED",
  },
  {
    id: "quantum",
    label: "QUANTUM LINK",
    icon: Zap,
    description: "Non-local consciousness and entanglement network",
    status: "CONNECTED",
  },
]

export default function AkiraCodexPage() {
  const router = useRouter()
  const [hoveredSection, setHoveredSection] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<"overview" | "codex" | "interface">("overview")

  return (
    <div className="min-h-screen relative overflow-hidden" style={{ backgroundColor: AKIRA_COLORS.dark }}>
      {/* Purple Circuit Grid */}
      <div
        className="fixed inset-0 opacity-15 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${AKIRA_COLORS.primary}30 1px, transparent 1px),
            linear-gradient(to bottom, ${AKIRA_COLORS.primary}30 1px, transparent 1px)
          `,
          backgroundSize: "40px 40px",
        }}
      />

      {/* Glowing Nodes */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full"
            style={{
              width: "6px",
              height: "6px",
              left: `${15 + i * 8}%`,
              top: `${10 + i * 7}%`,
              background: AKIRA_COLORS.primary,
              boxShadow: `0 0 15px ${AKIRA_COLORS.glow}`,
              animation: `pulse ${1.5 + i * 0.2}s ease-in-out infinite`,
            }}
          />
        ))}
      </div>

      {/* Header */}
      <header
        className="relative z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(13, 13, 13, 0.95)",
          borderColor: `${AKIRA_COLORS.primary}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => router.push("/")}
                className="flex items-center gap-2 transition-colors hover:opacity-80"
                style={{ color: AKIRA_COLORS.primary }}
                aria-label="Return to lobby"
              >
                <ArrowLeft className="w-5 h-5" />
                <span className="font-mono text-sm uppercase">FEN</span>
              </button>
              <div className="w-px h-6" style={{ background: `${AKIRA_COLORS.primary}30` }} />
              <div className="flex items-center gap-3">
                <Brain className="w-6 h-6" style={{ color: AKIRA_COLORS.neon }} />
                <h1
                  className="font-display text-xl sm:text-2xl uppercase tracking-wider"
                  style={{
                    color: AKIRA_COLORS.neon,
                    textShadow: `0 0 20px ${AKIRA_COLORS.glow}`,
                  }}
                >
                  AKIRA CODEX
                </h1>
              </div>
            </div>

            <div
              className="flex items-center gap-2 px-3 py-1.5 rounded-full"
              style={{
                background: `${AKIRA_COLORS.primary}20`,
                border: `1px solid ${AKIRA_COLORS.primary}`,
              }}
            >
              <Sparkles className="w-4 h-4 animate-pulse" style={{ color: AKIRA_COLORS.neon }} />
              <span className="font-mono text-xs uppercase" style={{ color: AKIRA_COLORS.neon }}>
                NEURO ACTIVE
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        {/* Title Section */}
        <div className="text-center mb-12">
          <h2
            className="font-display text-5xl sm:text-7xl uppercase mb-4"
            style={{
              color: AKIRA_COLORS.neon,
              textShadow: `0 0 40px ${AKIRA_COLORS.glow}, 0 0 80px ${AKIRA_COLORS.glow}`,
            }}
          >
            AKIRA CODEX
          </h2>
          <p className="font-mono text-sm sm:text-base" style={{ color: AKIRA_COLORS.accent }}>
            Neuro Code Apinaya • Consciousness Architecture • FEN 589 TRIFECTA ENGINE
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center justify-center gap-2 mb-8">
          {(["overview", "codex", "interface"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className="px-4 sm:px-6 py-2 rounded-full font-mono text-xs sm:text-sm uppercase tracking-wider transition-all"
              style={{
                background: activeTab === tab ? AKIRA_COLORS.primary : "transparent",
                color: activeTab === tab ? "#fff" : AKIRA_COLORS.accent,
                border: `1px solid ${activeTab === tab ? AKIRA_COLORS.primary : `${AKIRA_COLORS.primary}30`}`,
                boxShadow: activeTab === tab ? `0 0 20px ${AKIRA_COLORS.glow}` : "none",
              }}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Codex Sections Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {CODEX_SECTIONS.map((section) => {
            const Icon = section.icon
            const isHovered = hoveredSection === section.id

            return (
              <div
                key={section.id}
                onMouseEnter={() => setHoveredSection(section.id)}
                onMouseLeave={() => setHoveredSection(null)}
                className="relative p-6 rounded-2xl transition-all duration-500 cursor-pointer"
                style={{
                  background: isHovered
                    ? `linear-gradient(135deg, ${AKIRA_COLORS.primary}20, ${AKIRA_COLORS.dark})`
                    : "rgba(13, 13, 13, 0.9)",
                  border: `2px solid ${isHovered ? AKIRA_COLORS.neon : `${AKIRA_COLORS.primary}20`}`,
                  boxShadow: isHovered
                    ? `0 0 40px ${AKIRA_COLORS.glow}, inset 0 0 40px ${AKIRA_COLORS.primary}10`
                    : "none",
                  transform: isHovered ? "scale(1.02)" : "scale(1)",
                }}
              >
                {/* Corner Accents */}
                <div
                  className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 rounded-tl-2xl transition-opacity duration-300"
                  style={{
                    borderColor: AKIRA_COLORS.neon,
                    opacity: isHovered ? 1 : 0,
                  }}
                />
                <div
                  className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 rounded-br-2xl transition-opacity duration-300"
                  style={{
                    borderColor: AKIRA_COLORS.neon,
                    opacity: isHovered ? 1 : 0,
                  }}
                />

                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-all duration-300"
                  style={{
                    background: `${AKIRA_COLORS.primary}20`,
                    boxShadow: isHovered ? `0 0 30px ${AKIRA_COLORS.glow}` : "none",
                  }}
                >
                  <Icon className="w-6 h-6" style={{ color: AKIRA_COLORS.neon }} />
                </div>

                <h3
                  className="font-display text-lg sm:text-xl uppercase mb-2 transition-all duration-300"
                  style={{
                    color: isHovered ? AKIRA_COLORS.neon : "#fff",
                    textShadow: isHovered ? `0 0 20px ${AKIRA_COLORS.glow}` : "none",
                  }}
                >
                  {section.label}
                </h3>

                <p className="text-xs sm:text-sm mb-3" style={{ color: AKIRA_COLORS.accent }}>
                  {section.description}
                </p>

                <div
                  className="inline-block px-2 py-1 rounded text-xs font-mono uppercase"
                  style={{
                    background: `${AKIRA_COLORS.primary}20`,
                    color: AKIRA_COLORS.neon,
                    border: `1px solid ${AKIRA_COLORS.primary}40`,
                  }}
                >
                  {section.status}
                </div>
              </div>
            )
          })}
        </div>

        {/* Info Footer */}
        <div
          className="mt-12 p-6 rounded-2xl text-center"
          style={{
            background: "rgba(13, 13, 13, 0.8)",
            border: `1px solid ${AKIRA_COLORS.primary}30`,
          }}
        >
          <p className="font-mono text-sm" style={{ color: AKIRA_COLORS.accent }}>
            AKIRA CODEX is part of the FEN (589 TRIFECTA ENGINE) floor, housing advanced neuro-cognitive systems and
            consciousness architecture protocols.
          </p>
        </div>
      </main>

      <style jsx>{`
        @keyframes pulse {
          0%,
          100% {
            opacity: 0.5;
          }
          50% {
            opacity: 1;
          }
        }
      `}</style>
    </div>
  )
}
