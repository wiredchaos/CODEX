"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  Film,
  Mic,
  FileText,
  Calendar,
  Users,
  Wand2,
  BookOpen,
  Plus,
  ChevronRight,
  Play,
  BarChart3,
  Clock,
  CheckCircle2,
  AlertCircle,
  Sparkles,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const COLORS = {
  primary: "#FFD700",
  secondary: "#FFA500",
  accent: "#ff6b00",
  dark: "#0D0800",
  red: "#ff1744",
}

const MY_SHOWS = [
  {
    id: "1",
    title: "Tech Unplugged",
    status: "live",
    nextEpisode: "Today 3:00 PM",
    thumbnail: "/placeholder.svg?height=200&width=300",
    views: "12.4K",
  },
  {
    id: "2",
    title: "Creator Chronicles",
    status: "scheduled",
    nextEpisode: "Tomorrow 7:00 PM",
    thumbnail: "/placeholder.svg?height=200&width=300",
    views: "8.2K",
  },
  {
    id: "3",
    title: "Web3 Weekly",
    status: "draft",
    nextEpisode: "Draft",
    thumbnail: "/placeholder.svg?height=200&width=300",
    views: "—",
  },
]

const TOOLS = [
  {
    id: "pitch",
    title: "Show Pitch",
    description: "Submit your show concept for review",
    icon: FileText,
    route: "/create/pitch",
    color: COLORS.primary,
  },
  {
    id: "schedule",
    title: "Schedule",
    description: "Manage your broadcast calendar",
    icon: Calendar,
    route: "/create/schedule",
    color: COLORS.secondary,
  },
  {
    id: "npc",
    title: "NPC Tools",
    description: "AI agents for content creation",
    icon: Wand2,
    route: "/npc",
    color: COLORS.accent,
  },
  {
    id: "studio",
    title: "Virtual Studio",
    description: "Configure your broadcast environment",
    icon: Film,
    route: "/create/studio",
    color: COLORS.primary,
  },
  {
    id: "guests",
    title: "Guest Manager",
    description: "Invite and manage show guests",
    icon: Users,
    route: "/create/guests",
    color: COLORS.secondary,
  },
  {
    id: "docs",
    title: "Creator Docs",
    description: "Guides, templates, and resources",
    icon: BookOpen,
    route: "/create/docs",
    color: COLORS.accent,
  },
]

const AI_TOOLS = [
  {
    id: "beatsheet",
    title: "Beat Sheet Generator",
    description: "AI-powered episode structure",
    icon: Sparkles,
  },
  {
    id: "prompt-packs",
    title: "Prompt Packs",
    description: "Pre-built AI prompt collections",
    icon: FileText,
  },
  {
    id: "voice-coach",
    title: "Voice Coach",
    description: "Real-time delivery feedback",
    icon: Mic,
  },
]

export default function CreatePage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<"shows" | "tools" | "ai">("shows")

  return (
    <div className="min-h-screen" style={{ backgroundColor: COLORS.dark }}>
      {/* Header */}
      <header
        className="sticky top-0 z-50 border-b"
        style={{
          backgroundColor: "rgba(13, 8, 0, 0.95)",
          borderColor: `${COLORS.primary}30`,
          backdropFilter: "blur(10px)",
        }}
      >
        <div className="flex items-center justify-between px-4 md:px-8 py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => router.push("/789")}
              className="text-2xl font-bold"
              style={{ color: COLORS.primary }}
            >
              789
            </button>
            <Badge
              className="text-xs uppercase tracking-wider"
              style={{
                backgroundColor: `${COLORS.accent}20`,
                color: COLORS.accent,
                border: `1px solid ${COLORS.accent}40`,
              }}
            >
              Creator Hub
            </Badge>
          </div>

          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="sm"
              className="hidden md:flex gap-2 bg-transparent"
              style={{
                borderColor: `${COLORS.primary}40`,
                color: COLORS.primary,
              }}
              onClick={() => router.push("/watch")}
            >
              <Play className="w-4 h-4" />
              Switch to Watch
            </Button>
            <Button
              size="sm"
              className="gap-2"
              style={{
                backgroundColor: COLORS.primary,
                color: COLORS.dark,
              }}
            >
              <Plus className="w-4 h-4" />
              New Show
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-6 px-4 md:px-8 pb-4">
          {[
            { id: "shows", label: "My Shows" },
            { id: "tools", label: "CSN Tools" },
            { id: "ai", label: "AI / NPC" },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className="relative pb-2 text-sm font-medium transition-colors"
              style={{
                color: activeTab === tab.id ? COLORS.primary : "rgba(255,255,255,0.6)",
              }}
            >
              {tab.label}
              {activeTab === tab.id && (
                <div
                  className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full"
                  style={{ backgroundColor: COLORS.primary }}
                />
              )}
            </button>
          ))}
        </div>
      </header>

      <main className="px-4 md:px-8 py-8">
        {/* My Shows Tab */}
        {activeTab === "shows" && (
          <div className="space-y-8">
            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: "Total Views", value: "45.2K", icon: BarChart3 },
                { label: "Watch Hours", value: "1,234", icon: Clock },
                { label: "Episodes", value: "24", icon: Film },
                { label: "Subscribers", value: "892", icon: Users },
              ].map((stat) => (
                <Card
                  key={stat.label}
                  className="border"
                  style={{
                    backgroundColor: "rgba(255,255,255,0.02)",
                    borderColor: `${COLORS.primary}20`,
                  }}
                >
                  <CardContent className="flex items-center gap-4 p-4">
                    <div
                      className="w-10 h-10 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: `${COLORS.primary}20` }}
                    >
                      <stat.icon className="w-5 h-5" style={{ color: COLORS.primary }} />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-white">{stat.value}</p>
                      <p className="text-xs text-white/60">{stat.label}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Shows Grid */}
            <div>
              <h2 className="text-xl font-semibold text-white mb-4">Your Shows</h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {MY_SHOWS.map((show) => (
                  <Card
                    key={show.id}
                    className="overflow-hidden cursor-pointer transition-all hover:scale-[1.02] border"
                    style={{
                      backgroundColor: "rgba(255,255,255,0.02)",
                      borderColor: `${COLORS.primary}20`,
                    }}
                  >
                    <div className="relative aspect-video">
                      <img
                        src={show.thumbnail || "/placeholder.svg"}
                        alt={show.title}
                        className="w-full h-full object-cover"
                      />
                      <Badge
                        className="absolute top-3 right-3 text-xs uppercase"
                        style={{
                          backgroundColor:
                            show.status === "live"
                              ? COLORS.red
                              : show.status === "scheduled"
                                ? COLORS.primary
                                : "rgba(255,255,255,0.2)",
                          color: show.status === "draft" ? "white" : COLORS.dark,
                        }}
                      >
                        {show.status === "live" && (
                          <span className="w-2 h-2 rounded-full bg-white animate-pulse mr-1" />
                        )}
                        {show.status}
                      </Badge>
                    </div>
                    <CardContent className="p-4">
                      <h3 className="text-lg font-semibold text-white mb-1">{show.title}</h3>
                      <div className="flex items-center justify-between text-sm text-white/60">
                        <span>{show.nextEpisode}</span>
                        <span>{show.views} views</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}

                {/* Add New Show Card */}
                <Card
                  className="flex items-center justify-center cursor-pointer transition-all hover:scale-[1.02] border-dashed"
                  style={{
                    backgroundColor: "transparent",
                    borderColor: `${COLORS.primary}40`,
                    minHeight: "200px",
                  }}
                >
                  <div className="text-center">
                    <div
                      className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-3"
                      style={{ backgroundColor: `${COLORS.primary}20` }}
                    >
                      <Plus className="w-6 h-6" style={{ color: COLORS.primary }} />
                    </div>
                    <p className="text-white font-medium">Create New Show</p>
                    <p className="text-sm text-white/60">Pitch your concept</p>
                  </div>
                </Card>
              </div>
            </div>
          </div>
        )}

        {/* CSN Tools Tab */}
        {activeTab === "tools" && (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {TOOLS.map((tool) => (
              <Card
                key={tool.id}
                className="cursor-pointer transition-all hover:scale-[1.02] border group"
                style={{
                  backgroundColor: "rgba(255,255,255,0.02)",
                  borderColor: `${tool.color}20`,
                }}
                onClick={() => router.push(tool.route)}
              >
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div
                      className="w-12 h-12 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: `${tool.color}20` }}
                    >
                      <tool.icon className="w-6 h-6" style={{ color: tool.color }} />
                    </div>
                    <ChevronRight
                      className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-opacity"
                      style={{ color: tool.color }}
                    />
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-1">{tool.title}</h3>
                  <p className="text-sm text-white/60">{tool.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* AI / NPC Tab */}
        {activeTab === "ai" && (
          <div className="space-y-8">
            {/* NPC Agents Banner */}
            <Card
              className="border overflow-hidden"
              style={{
                backgroundColor: `${COLORS.accent}10`,
                borderColor: `${COLORS.accent}40`,
              }}
            >
              <CardContent className="p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div
                    className="w-14 h-14 rounded-xl flex items-center justify-center"
                    style={{ backgroundColor: `${COLORS.accent}30` }}
                  >
                    <Wand2 className="w-7 h-7" style={{ color: COLORS.accent }} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white">NPC Agent Marketplace</h3>
                    <p className="text-white/70">Hire AI agents to automate content creation</p>
                  </div>
                </div>
                <Button
                  className="gap-2"
                  style={{
                    backgroundColor: COLORS.accent,
                    color: COLORS.dark,
                  }}
                  onClick={() => router.push("/npc")}
                >
                  <Sparkles className="w-4 h-4" />
                  Browse Agents
                </Button>
              </CardContent>
            </Card>

            {/* AI Tools Grid */}
            <div>
              <h2 className="text-xl font-semibold text-white mb-4">AI Content Tools</h2>
              <div className="grid md:grid-cols-3 gap-6">
                {AI_TOOLS.map((tool) => (
                  <Card
                    key={tool.id}
                    className="cursor-pointer transition-all hover:scale-[1.02] border"
                    style={{
                      backgroundColor: "rgba(255,255,255,0.02)",
                      borderColor: `${COLORS.primary}20`,
                    }}
                  >
                    <CardContent className="p-6 text-center">
                      <div
                        className="w-14 h-14 rounded-xl flex items-center justify-center mx-auto mb-4"
                        style={{ backgroundColor: `${COLORS.primary}20` }}
                      >
                        <tool.icon className="w-7 h-7" style={{ color: COLORS.primary }} />
                      </div>
                      <h3 className="text-lg font-semibold text-white mb-1">{tool.title}</h3>
                      <p className="text-sm text-white/60">{tool.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Education Section */}
            <Card
              className="border"
              style={{
                backgroundColor: "rgba(255,255,255,0.02)",
                borderColor: `${COLORS.primary}20`,
              }}
            >
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <BookOpen className="w-5 h-5" style={{ color: COLORS.primary }} />
                  Creator University
                </CardTitle>
                <CardDescription>Learn to build with AI-powered content tools</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  { title: "NPC 101: Getting Started", status: "completed", duration: "15 min" },
                  { title: "Advanced Prompt Engineering", status: "in-progress", duration: "45 min" },
                  { title: "Building AI-Assisted Shows", status: "locked", duration: "1 hr" },
                ].map((course, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between p-3 rounded-lg"
                    style={{ backgroundColor: "rgba(255,255,255,0.03)" }}
                  >
                    <div className="flex items-center gap-3">
                      {course.status === "completed" ? (
                        <CheckCircle2 className="w-5 h-5 text-green-500" />
                      ) : course.status === "in-progress" ? (
                        <AlertCircle className="w-5 h-5" style={{ color: COLORS.primary }} />
                      ) : (
                        <Clock className="w-5 h-5 text-white/40" />
                      )}
                      <span className={`text-sm ${course.status === "locked" ? "text-white/40" : "text-white"}`}>
                        {course.title}
                      </span>
                    </div>
                    <span className="text-xs text-white/50">{course.duration}</span>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  )
}
