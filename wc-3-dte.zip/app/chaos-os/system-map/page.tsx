"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import {
  Map,
  ArrowLeft,
  CheckCircle,
  AlertCircle,
  XCircle,
  ExternalLink,
  Database,
  Globe,
  Users,
  CreditCard,
  GraduationCap,
  Radio,
  Gamepad2,
  Building,
  Brain,
  Shield,
  Palette,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

type Patch = {
  id: string
  name: string
  displayName: string
  description: string
  route: string
  realm: "neuralis" | "chaosphere" | "both" | "external"
  status: "active" | "dormant" | "broken" | "external"
  icon: React.ElementType
  color: string
  tables: string[]
  hasAkashicVersion: boolean
  hasBusinessVersion: boolean
}

const patches: Patch[] = [
  // CHAOS OS Core
  {
    id: "chaos-os",
    name: "CHAOS_OS",
    displayName: "CHAOS OS",
    description: "Operating system shell for WIRED CHAOS META",
    route: "/chaos-os",
    realm: "both",
    status: "active",
    icon: Brain,
    color: "#8B5CF6",
    tables: ["agentic_jobs", "forensic_sources", "forensic_runs"],
    hasAkashicVersion: true,
    hasBusinessVersion: true,
  },
  {
    id: "chaos-brain",
    name: "CHAOS_BRAIN",
    displayName: "CHAOS BRAIN",
    description: "AI conversational interface",
    route: "/chaos-os/brain-console",
    realm: "both",
    status: "active",
    icon: Brain,
    color: "#00FFFF",
    tables: [],
    hasAkashicVersion: true,
    hasBusinessVersion: true,
  },
  // Core Floors
  {
    id: "789-studios",
    name: "789_STUDIOS",
    displayName: "789 Studios",
    description: "Creator economy, OTT, talent management",
    route: "/789",
    realm: "chaosphere",
    status: "active",
    icon: Building,
    color: "#FFD700",
    tables: ["wc_creator_789_profiles", "wc_creator_789_earnings", "videos", "creators"],
    hasAkashicVersion: false,
    hasBusinessVersion: true,
  },
  {
    id: "333-fm",
    name: "33_3FM",
    displayName: "33.3FM Signal",
    description: "Underground radio, museum, IP audit",
    route: "/333",
    realm: "neuralis",
    status: "active",
    icon: Radio,
    color: "#00BFFF",
    tables: ["fm_tracks", "fm_creators", "museum_galleries", "museum_nft_exhibits"],
    hasAkashicVersion: true,
    hasBusinessVersion: true,
  },
  {
    id: "vault33",
    name: "VAULT_33",
    displayName: "VAULT 33",
    description: "Akashic vault, gas sigils, 9 layers",
    route: "/vault33",
    realm: "neuralis",
    status: "active",
    icon: Shield,
    color: "#A020F0",
    tables: ["codex_entry", "akashic_glossary_entry"],
    hasAkashicVersion: true,
    hasBusinessVersion: false,
  },
  {
    id: "fen",
    name: "FEN_REALM",
    displayName: "FEN Realm",
    description: "Gamification, whitelist, riddles",
    route: "/fen",
    realm: "both",
    status: "active",
    icon: Gamepad2,
    color: "#FF6B6B",
    tables: ["fen_user_progress", "fen_reward_wallet", "fen_events", "fen_wl_snapshot"],
    hasAkashicVersion: true,
    hasBusinessVersion: true,
  },
  // Training & Education
  {
    id: "hrm",
    name: "HRM_TRAINING",
    displayName: "HRM Training",
    description: "6 training games, 3 learning modes",
    route: "/hrm",
    realm: "both",
    status: "active",
    icon: GraduationCap,
    color: "#00FF88",
    tables: ["hrm_games", "hrm_user_game_progress", "hrm_company_configs"],
    hasAkashicVersion: true,
    hasBusinessVersion: true,
  },
  {
    id: "npc-engine",
    name: "NPC_ENGINE",
    displayName: "NPC Engine",
    description: "AI agents, job execution, training",
    route: "/npc",
    realm: "both",
    status: "active",
    icon: Users,
    color: "#FF4500",
    tables: ["wc_npc_agents", "wc_npc_jobs", "npc_quests", "npc_lessons"],
    hasAkashicVersion: true,
    hasBusinessVersion: true,
  },
  {
    id: "university",
    name: "WIRED_CHAOS_UNIVERSITY",
    displayName: "WIRED CHAOS University",
    description: "Learning, certification, courses",
    route: "/chaos-os/university",
    realm: "both",
    status: "active",
    icon: GraduationCap,
    color: "#FF69B4",
    tables: ["hoc_university_course", "hoc_course_enrollment"],
    hasAkashicVersion: true,
    hasBusinessVersion: true,
  },
  // Analytics & Telemetry
  {
    id: "hemisphere",
    name: "HEMISPHERE",
    displayName: "Hemisphere Dashboard",
    description: "Neuralis/Chaosphere balance, role engine",
    route: "/hemisphere",
    realm: "both",
    status: "active",
    icon: Globe,
    color: "#00CED1",
    tables: ["hemisphere_profiles", "wc_user_hemisphere_scores", "wc_user_roles"],
    hasAkashicVersion: true,
    hasBusinessVersion: true,
  },
  {
    id: "globe",
    name: "GLOBE_EXPLORER",
    displayName: "Globe Explorer",
    description: "3D globe with lei lines, portals, belief variants",
    route: "/globe",
    realm: "both",
    status: "active",
    icon: Globe,
    color: "#32CD32",
    tables: [],
    hasAkashicVersion: true,
    hasBusinessVersion: false,
  },
  // Economy
  {
    id: "credit-repair",
    name: "CREDIT_REPAIR",
    displayName: "Credit Repair",
    description: "Credit bootcamp, dispute letters, scoring",
    route: "/credit-repair",
    realm: "both",
    status: "active",
    icon: CreditCard,
    color: "#FFD700",
    tables: ["cr_credit_profiles", "cr_dispute_letters", "cr_bootcamp_modules"],
    hasAkashicVersion: false,
    hasBusinessVersion: true,
  },
  // External Links
  {
    id: "creator-codex",
    name: "CREATOR_CODEX",
    displayName: "Creator Codex",
    description: "External creator workflow system",
    route: "https://creatorcodex.io",
    realm: "external",
    status: "external",
    icon: Palette,
    color: "#9333EA",
    tables: [],
    hasAkashicVersion: false,
    hasBusinessVersion: true,
  },
  {
    id: "akira-codex",
    name: "AKIRA_CODEX",
    displayName: "Akira Codex",
    description: "External Akira system",
    route: "https://akiracodex.io",
    realm: "external",
    status: "external",
    icon: Brain,
    color: "#EC4899",
    tables: [],
    hasAkashicVersion: true,
    hasBusinessVersion: false,
  },
  {
    id: "fashion-fabricator",
    name: "FASHION_FABRICATOR",
    displayName: "Fashion Fabricator",
    description: "AI fashion design, avatar traits",
    route: "/fashion",
    realm: "chaosphere",
    status: "dormant",
    icon: Palette,
    color: "#F472B6",
    tables: ["wc_fashion_projects", "wc_fashion_courses", "wc_fashion_listings"],
    hasAkashicVersion: false,
    hasBusinessVersion: true,
  },
  {
    id: "neura-tax",
    name: "NEURA_TAX",
    displayName: "NEURA Tax",
    description: "Tax compliance, ISO standards",
    route: "/neura-tax",
    realm: "neuralis",
    status: "dormant",
    icon: Database,
    color: "#6366F1",
    tables: ["wc_iso_industry_profiles", "wc_iso_regulations", "wc_iso_controls"],
    hasAkashicVersion: false,
    hasBusinessVersion: true,
  },
]

export default function SystemMapPage() {
  const [selectedRealm, setSelectedRealm] = useState<string>("all")

  const filteredPatches =
    selectedRealm === "all" ? patches : patches.filter((p) => p.realm === selectedRealm || p.realm === "both")

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "active":
        return <CheckCircle className="h-4 w-4 text-green-400" />
      case "dormant":
        return <AlertCircle className="h-4 w-4 text-yellow-400" />
      case "broken":
        return <XCircle className="h-4 w-4 text-red-400" />
      case "external":
        return <ExternalLink className="h-4 w-4 text-blue-400" />
      default:
        return null
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-950 text-green-400 border-green-800">Active</Badge>
      case "dormant":
        return <Badge className="bg-yellow-950 text-yellow-400 border-yellow-800">Dormant</Badge>
      case "broken":
        return <Badge className="bg-red-950 text-red-400 border-red-800">Broken</Badge>
      case "external":
        return <Badge className="bg-blue-950 text-blue-400 border-blue-800">External</Badge>
      default:
        return null
    }
  }

  const activeCount = patches.filter((p) => p.status === "active").length
  const dormantCount = patches.filter((p) => p.status === "dormant").length
  const externalCount = patches.filter((p) => p.status === "external").length

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border/40 bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <Link href="/chaos-os">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div className="h-8 w-8 rounded-lg bg-blue-950 flex items-center justify-center">
              <Map className="h-5 w-5 text-blue-400" />
            </div>
            <div>
              <h1 className="text-lg font-bold">System Map</h1>
              <p className="text-xs text-muted-foreground">Patch Registry & Navigation</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card className="bg-green-950/20 border-green-800/30">
            <CardContent className="pt-4">
              <p className="text-2xl font-bold text-green-400">{activeCount}</p>
              <p className="text-sm text-muted-foreground">Active Patches</p>
            </CardContent>
          </Card>
          <Card className="bg-yellow-950/20 border-yellow-800/30">
            <CardContent className="pt-4">
              <p className="text-2xl font-bold text-yellow-400">{dormantCount}</p>
              <p className="text-sm text-muted-foreground">Dormant</p>
            </CardContent>
          </Card>
          <Card className="bg-blue-950/20 border-blue-800/30">
            <CardContent className="pt-4">
              <p className="text-2xl font-bold text-blue-400">{externalCount}</p>
              <p className="text-sm text-muted-foreground">External</p>
            </CardContent>
          </Card>
          <Card className="bg-violet-950/20 border-violet-800/30">
            <CardContent className="pt-4">
              <p className="text-2xl font-bold text-violet-400">{patches.length}</p>
              <p className="text-sm text-muted-foreground">Total Patches</p>
            </CardContent>
          </Card>
        </div>

        {/* Realm Filter */}
        <Tabs value={selectedRealm} onValueChange={setSelectedRealm} className="mb-6">
          <TabsList>
            <TabsTrigger value="all">All Realms</TabsTrigger>
            <TabsTrigger value="neuralis">Neuralis</TabsTrigger>
            <TabsTrigger value="chaosphere">Chaosphere</TabsTrigger>
            <TabsTrigger value="external">External</TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Patch Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredPatches.map((patch) => {
            const Icon = patch.icon
            const isExternal = patch.status === "external"

            const CardWrapper = isExternal ? "a" : Link
            const cardProps = isExternal
              ? { href: patch.route, target: "_blank", rel: "noopener noreferrer" }
              : { href: patch.route }

            return (
              <CardWrapper key={patch.id} {...cardProps}>
                <Card
                  className="h-full cursor-pointer transition-all duration-200 hover:border-opacity-100 border-opacity-50"
                  style={{ borderColor: `${patch.color}40` }}
                >
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div
                          className="h-8 w-8 rounded-lg flex items-center justify-center"
                          style={{ backgroundColor: `${patch.color}20` }}
                        >
                          <Icon className="h-4 w-4" style={{ color: patch.color }} />
                        </div>
                        {getStatusIcon(patch.status)}
                      </div>
                      {getStatusBadge(patch.status)}
                    </div>
                    <CardTitle className="text-base mt-2">{patch.displayName}</CardTitle>
                    <CardDescription className="text-xs">{patch.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-1 mb-2">
                      {patch.hasBusinessVersion && (
                        <Badge variant="outline" className="text-xs">
                          Business
                        </Badge>
                      )}
                      {patch.hasAkashicVersion && (
                        <Badge variant="outline" className="text-xs">
                          Akashic
                        </Badge>
                      )}
                    </div>
                    {patch.tables.length > 0 && (
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <Database className="h-3 w-3" />
                        <span>{patch.tables.length} tables</span>
                      </div>
                    )}
                    <p className="text-xs text-muted-foreground font-mono mt-1">{patch.route}</p>
                  </CardContent>
                </Card>
              </CardWrapper>
            )
          })}
        </div>
      </main>
    </div>
  )
}
