"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Search, Plus, Play, Clock, CheckCircle, XCircle, Loader2, Github, ArrowLeft, FileText } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"

type Source = {
  id: string
  type: string
  name: string
  repo_url: string
  branch: string | null
  created_at: string
}

type Run = {
  id: string
  source_id: string
  mode: string
  status: string
  started_at: string | null
  finished_at: string | null
  files_indexed: number
  chunks_indexed: number
}

export default function ForensicsPage() {
  const [sources, setSources] = useState<Source[]>([])
  const [runs, setRuns] = useState<Run[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<unknown[]>([])
  const [searching, setSearching] = useState(false)
  const [addDialogOpen, setAddDialogOpen] = useState(false)
  const [newSource, setNewSource] = useState({ name: "", repoUrl: "", branch: "main" })
  const [addingSource, setAddingSource] = useState(false)

  useEffect(() => {
    fetchSources()
    fetchRuns()
  }, [])

  async function fetchSources() {
    try {
      const res = await fetch("/api/forensics/sources")
      const data = await res.json()
      setSources(data.sources || [])
    } catch (error) {
      console.error("[v0] Error fetching sources:", error)
    }
  }

  async function fetchRuns() {
    try {
      // We'll need to add this endpoint
      setRuns([])
    } catch (error) {
      console.error("[v0] Error fetching runs:", error)
    } finally {
      setLoading(false)
    }
  }

  async function addSource() {
    setAddingSource(true)
    try {
      const res = await fetch("/api/forensics/sources", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newSource),
      })
      if (res.ok) {
        await fetchSources()
        setAddDialogOpen(false)
        setNewSource({ name: "", repoUrl: "", branch: "main" })
      }
    } catch (error) {
      console.error("[v0] Error adding source:", error)
    } finally {
      setAddingSource(false)
    }
  }

  async function startScan(sourceId: string) {
    try {
      const res = await fetch("/api/forensics/scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sourceId, mode: "quick" }),
      })
      if (res.ok) {
        await fetchRuns()
      }
    } catch (error) {
      console.error("[v0] Error starting scan:", error)
    }
  }

  async function handleSearch() {
    if (!searchQuery.trim()) return
    setSearching(true)
    try {
      const res = await fetch("/api/forensics/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ q: searchQuery, limit: 20 }),
      })
      const data = await res.json()
      setSearchResults(data.results || [])
    } catch (error) {
      console.error("[v0] Error searching:", error)
    } finally {
      setSearching(false)
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "ready":
        return <CheckCircle className="h-4 w-4 text-green-400" />
      case "running":
        return <Loader2 className="h-4 w-4 text-blue-400 animate-spin" />
      case "error":
        return <XCircle className="h-4 w-4 text-red-400" />
      default:
        return <Clock className="h-4 w-4 text-yellow-400" />
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border/40 bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <Link href="/chaos-os">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div className="h-8 w-8 rounded-lg bg-emerald-950 flex items-center justify-center">
              <Search className="h-5 w-5 text-emerald-400" />
            </div>
            <div>
              <h1 className="text-lg font-bold">Forensics</h1>
              <p className="text-xs text-muted-foreground">Repository Scanner & Indexer</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container px-4 py-8">
        {/* Search Bar */}
        <Card className="mb-6 bg-muted/30">
          <CardContent className="pt-4">
            <div className="flex gap-2">
              <Input
                placeholder="Search indexed corpus (e.g., '33.3FM', 'patch', 'elevator')..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                className="flex-1"
              />
              <Button onClick={handleSearch} disabled={searching}>
                {searching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Search Results */}
        {searchResults.length > 0 && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-base">Search Results</CardTitle>
              <CardDescription>{searchResults.length} matches found</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {searchResults.map((result: any, i) => (
                  <div key={i} className="p-3 rounded-lg bg-muted/50 text-sm">
                    <div className="flex items-center gap-2 mb-1">
                      <FileText className="h-3 w-3 text-muted-foreground" />
                      <span className="font-mono text-xs text-muted-foreground">{result.path}</span>
                      <Badge variant="outline" className="text-xs">
                        {result.source}
                      </Badge>
                    </div>
                    <p className="text-muted-foreground line-clamp-2">{result.text}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Sources */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-base">Sources</CardTitle>
                <CardDescription>Connected repositories</CardDescription>
              </div>
              <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button size="sm">
                    <Plus className="h-4 w-4 mr-1" />
                    Add Source
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add Repository Source</DialogTitle>
                    <DialogDescription>Connect a GitHub repository for forensic scanning</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 pt-4">
                    <div>
                      <Label>Name</Label>
                      <Input
                        placeholder="WIRED CHAOS META"
                        value={newSource.name}
                        onChange={(e) => setNewSource({ ...newSource, name: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label>Repository URL</Label>
                      <Input
                        placeholder="https://github.com/owner/repo"
                        value={newSource.repoUrl}
                        onChange={(e) => setNewSource({ ...newSource, repoUrl: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label>Branch</Label>
                      <Input
                        placeholder="main"
                        value={newSource.branch}
                        onChange={(e) => setNewSource({ ...newSource, branch: e.target.value })}
                      />
                    </div>
                    <Button
                      onClick={addSource}
                      disabled={addingSource || !newSource.name || !newSource.repoUrl}
                      className="w-full"
                    >
                      {addingSource ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      ) : (
                        <Plus className="h-4 w-4 mr-2" />
                      )}
                      Add Source
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                </div>
              ) : sources.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Github className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>No sources added yet</p>
                  <p className="text-sm">Add a GitHub repository to start scanning</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {sources.map((source) => (
                    <div key={source.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <div className="flex items-center gap-3">
                        <Github className="h-5 w-5 text-muted-foreground" />
                        <div>
                          <p className="font-medium">{source.name}</p>
                          <p className="text-xs text-muted-foreground font-mono">{source.repo_url}</p>
                        </div>
                      </div>
                      <Button size="sm" variant="outline" onClick={() => startScan(source.id)}>
                        <Play className="h-3 w-3 mr-1" />
                        Scan
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Runs */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Recent Runs</CardTitle>
              <CardDescription>Forensic scan history</CardDescription>
            </CardHeader>
            <CardContent>
              {runs.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Clock className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>No scans yet</p>
                  <p className="text-sm">Run a scan on a source to see results</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {runs.map((run) => (
                    <Link key={run.id} href={`/chaos-os/forensics/runs/${run.id}`}>
                      <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted/70 transition-colors cursor-pointer">
                        <div className="flex items-center gap-3">
                          {getStatusIcon(run.status)}
                          <div>
                            <p className="font-medium text-sm">{run.mode} scan</p>
                            <p className="text-xs text-muted-foreground">
                              {run.files_indexed} files, {run.chunks_indexed} chunks
                            </p>
                          </div>
                        </div>
                        <Badge variant="outline">{run.status}</Badge>
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
