"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Bot, Play, Clock, CheckCircle, XCircle, Loader2, ArrowLeft, Terminal, Zap } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type Job = {
  id: string
  kind: string
  status: string
  created_at: string
  started_at: string | null
  finished_at: string | null
  error: string | null
}

const JOB_KINDS = [
  {
    value: "SEEKER_FORENSICS_SCAN",
    label: "Forensics Scan",
    description: "Scan and index a repository",
  },
  {
    value: "SEEKER_PATCH_RECONSTRUCT",
    label: "Patch Reconstruct",
    description: "Reconstruct a specific patch",
  },
  {
    value: "SEEKER_MISSING_DOCS_REPORT",
    label: "Missing Docs Report",
    description: "Generate missing documentation report",
  },
  {
    value: "SEEKER_UPGRADE_PLAN",
    label: "Upgrade Plan",
    description: "Generate system upgrade plan",
  },
]

export default function AgenticPage() {
  const [jobs, setJobs] = useState<Job[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedKind, setSelectedKind] = useState<string>("")
  const [runningJob, setRunningJob] = useState(false)

  useEffect(() => {
    fetchJobs()
    const interval = setInterval(fetchJobs, 5000) // Poll every 5s
    return () => clearInterval(interval)
  }, [])

  async function fetchJobs() {
    try {
      const res = await fetch("/api/agentic/jobs")
      const data = await res.json()
      setJobs(data.jobs || [])
    } catch (error) {
      console.error("[v0] Error fetching jobs:", error)
    } finally {
      setLoading(false)
    }
  }

  async function runJob() {
    if (!selectedKind) return
    setRunningJob(true)
    try {
      const res = await fetch("/api/agentic/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kind: selectedKind, input: {} }),
      })
      if (res.ok) {
        await fetchJobs()
        setSelectedKind("")
      }
    } catch (error) {
      console.error("[v0] Error running job:", error)
    } finally {
      setRunningJob(false)
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "succeeded":
        return <CheckCircle className="h-4 w-4 text-green-400" />
      case "running":
        return <Loader2 className="h-4 w-4 text-blue-400 animate-spin" />
      case "failed":
        return <XCircle className="h-4 w-4 text-red-400" />
      default:
        return <Clock className="h-4 w-4 text-yellow-400" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "succeeded":
        return "bg-green-950 text-green-400 border-green-800"
      case "running":
        return "bg-blue-950 text-blue-400 border-blue-800"
      case "failed":
        return "bg-red-950 text-red-400 border-red-800"
      default:
        return "bg-yellow-950 text-yellow-400 border-yellow-800"
    }
  }

  const formatJobKind = (kind: string) => {
    return kind.replace("SEEKER_", "").replace(/_/g, " ")
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border/40 bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <Link href="/chaos-os">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div className="h-8 w-8 rounded-lg bg-violet-950 flex items-center justify-center">
              <Bot className="h-5 w-5 text-violet-400" />
            </div>
            <div>
              <h1 className="text-lg font-bold">Agentic Console</h1>
              <p className="text-xs text-muted-foreground">Seeker + PM Lead Runtime</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container px-4 py-8">
        {/* Run New Job */}
        <Card className="mb-6 bg-violet-950/20 border-violet-800/30">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Zap className="h-4 w-4 text-violet-400" />
              Run New Job
            </CardTitle>
            <CardDescription>Execute a Seeker agent job</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-3">
              <Select value={selectedKind} onValueChange={setSelectedKind}>
                <SelectTrigger className="flex-1">
                  <SelectValue placeholder="Select job type..." />
                </SelectTrigger>
                <SelectContent>
                  {JOB_KINDS.map((kind) => (
                    <SelectItem key={kind.value} value={kind.value}>
                      <div>
                        <span className="font-medium">{kind.label}</span>
                        <span className="text-xs text-muted-foreground ml-2">{kind.description}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                onClick={runJob}
                disabled={!selectedKind || runningJob}
                className="bg-violet-600 hover:bg-violet-700"
              >
                {runningJob ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Play className="h-4 w-4 mr-2" />}
                Run
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Jobs List */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Terminal className="h-4 w-4" />
              Job History
            </CardTitle>
            <CardDescription>Recent agentic job executions</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : jobs.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Bot className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No jobs yet</p>
                <p className="text-sm">Run a job to see execution history</p>
              </div>
            ) : (
              <div className="space-y-3">
                {jobs.map((job) => (
                  <Link key={job.id} href={`/chaos-os/agentic/jobs/${job.id}`}>
                    <div className="flex items-center justify-between p-4 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors cursor-pointer border border-border/50">
                      <div className="flex items-center gap-4">
                        {getStatusIcon(job.status)}
                        <div>
                          <p className="font-medium">{formatJobKind(job.kind)}</p>
                          <p className="text-xs text-muted-foreground font-mono">{job.id.slice(0, 8)}...</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge className={getStatusColor(job.status)}>{job.status}</Badge>
                        <span className="text-xs text-muted-foreground">
                          {new Date(job.created_at).toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
