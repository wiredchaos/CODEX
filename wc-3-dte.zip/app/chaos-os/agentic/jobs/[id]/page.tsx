"use client"

import { useState, useEffect, use } from "react"
import Link from "next/link"
import {
  Bot,
  ArrowLeft,
  CheckCircle,
  XCircle,
  Loader2,
  Clock,
  ChevronDown,
  ChevronRight,
  AlertCircle,
  Info,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

type JobEvent = {
  id: string
  timestamp: string
  level: string
  message: string
  payload: unknown | null
}

type PlanStep = {
  action: string
  params: Record<string, unknown>
  description: string
}

type JobDetail = {
  id: string
  kind: string
  status: string
  input: Record<string, unknown> | null
  plan: { steps: PlanStep[]; estimated_duration: string } | null
  result: Record<string, unknown> | null
  error: string | null
  createdAt: string
  startedAt: string | null
  finishedAt: string | null
  events: JobEvent[]
}

export default function JobDetailPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = use(params)
  const [job, setJob] = useState<JobDetail | null>(null)
  const [loading, setLoading] = useState(true)
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(["plan", "events"]))

  useEffect(() => {
    fetchJob()
    const interval = setInterval(fetchJob, 3000)
    return () => clearInterval(interval)
  }, [id])

  async function fetchJob() {
    try {
      const res = await fetch(`/api/agentic/jobs/${id}`)
      const data = await res.json()
      setJob(data)
    } catch (error) {
      console.error("[v0] Error fetching job:", error)
    } finally {
      setLoading(false)
    }
  }

  const toggleSection = (section: string) => {
    const newExpanded = new Set(expandedSections)
    if (newExpanded.has(section)) {
      newExpanded.delete(section)
    } else {
      newExpanded.add(section)
    }
    setExpandedSections(newExpanded)
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "succeeded":
        return <CheckCircle className="h-5 w-5 text-green-400" />
      case "running":
        return <Loader2 className="h-5 w-5 text-blue-400 animate-spin" />
      case "failed":
        return <XCircle className="h-5 w-5 text-red-400" />
      default:
        return <Clock className="h-5 w-5 text-yellow-400" />
    }
  }

  const getEventIcon = (level: string) => {
    switch (level) {
      case "error":
        return <XCircle className="h-3 w-3 text-red-400" />
      case "warn":
        return <AlertCircle className="h-3 w-3 text-yellow-400" />
      default:
        return <Info className="h-3 w-3 text-blue-400" />
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (!job) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Job not found</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border/40 bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <Link href="/chaos-os/agentic">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div className="h-8 w-8 rounded-lg bg-violet-950 flex items-center justify-center">
              <Bot className="h-5 w-5 text-violet-400" />
            </div>
            <div>
              <h1 className="text-lg font-bold">Job Detail</h1>
              <p className="text-xs text-muted-foreground font-mono">{job.id}</p>
            </div>
          </div>
          {getStatusIcon(job.status)}
        </div>
      </header>

      <main className="container px-4 py-8 max-w-4xl">
        {/* Overview */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg">{job.kind.replace("SEEKER_", "").replace(/_/g, " ")}</CardTitle>
                <CardDescription>Created {new Date(job.createdAt).toLocaleString()}</CardDescription>
              </div>
              <Badge
                className={
                  job.status === "succeeded"
                    ? "bg-green-950 text-green-400"
                    : job.status === "failed"
                      ? "bg-red-950 text-red-400"
                      : job.status === "running"
                        ? "bg-blue-950 text-blue-400"
                        : "bg-yellow-950 text-yellow-400"
                }
              >
                {job.status}
              </Badge>
            </div>
          </CardHeader>
          {job.error && (
            <CardContent>
              <div className="p-3 rounded-lg bg-red-950/30 border border-red-800/50">
                <p className="text-sm text-red-400">{job.error}</p>
              </div>
            </CardContent>
          )}
        </Card>

        {/* Plan */}
        {job.plan && (
          <Card className="mb-6">
            <CardHeader className="cursor-pointer" onClick={() => toggleSection("plan")}>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base flex items-center gap-2">
                  {expandedSections.has("plan") ? (
                    <ChevronDown className="h-4 w-4" />
                  ) : (
                    <ChevronRight className="h-4 w-4" />
                  )}
                  Execution Plan
                </CardTitle>
                <Badge variant="outline">{job.plan.estimated_duration}</Badge>
              </div>
            </CardHeader>
            {expandedSections.has("plan") && (
              <CardContent>
                <div className="space-y-3">
                  {job.plan.steps.map((step, i) => (
                    <div key={i} className="flex items-start gap-3 p-3 rounded-lg bg-muted/30">
                      <span className="flex-shrink-0 w-6 h-6 rounded-full bg-violet-950 text-violet-400 flex items-center justify-center text-xs font-mono">
                        {i + 1}
                      </span>
                      <div>
                        <p className="font-medium text-sm">{step.description}</p>
                        <p className="text-xs text-muted-foreground font-mono">{step.action}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            )}
          </Card>
        )}

        {/* Events */}
        <Card>
          <CardHeader className="cursor-pointer" onClick={() => toggleSection("events")}>
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                {expandedSections.has("events") ? (
                  <ChevronDown className="h-4 w-4" />
                ) : (
                  <ChevronRight className="h-4 w-4" />
                )}
                Execution Trace
              </CardTitle>
              <Badge variant="outline">{job.events.length} events</Badge>
            </div>
          </CardHeader>
          {expandedSections.has("events") && (
            <CardContent>
              {job.events.length === 0 ? (
                <p className="text-sm text-muted-foreground">No events yet</p>
              ) : (
                <div className="space-y-2">
                  {job.events.map((event) => (
                    <div key={event.id} className="flex items-start gap-2 text-sm">
                      {getEventIcon(event.level)}
                      <span className="text-xs text-muted-foreground font-mono w-20 flex-shrink-0">
                        {new Date(event.timestamp).toLocaleTimeString()}
                      </span>
                      <span>{event.message}</span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          )}
        </Card>
      </main>
    </div>
  )
}
