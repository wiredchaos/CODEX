"use client"

import { useState } from "react"
import Link from "next/link"
import { Brain, Search, Bot, Map, Wrench, GraduationCap, Zap, Database, ArrowRight } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

const modules = [
  {
    id: "brain",
    name: "CHAOS BRAIN",
    description: "AI-powered conversational interface for system control",
    icon: Brain,
    href: "/chaos-os/brain-console",
    color: "text-cyan-400",
    bg: "bg-cyan-950/30",
  },
  {
    id: "forensics",
    name: "Forensics",
    description: "Scan, index, and reconstruct project repositories",
    icon: Search,
    href: "/chaos-os/forensics",
    color: "text-emerald-400",
    bg: "bg-emerald-950/30",
  },
  {
    id: "agentic",
    name: "Agentic Console",
    description: "Seeker + PM Lead job execution and monitoring",
    icon: Bot,
    href: "/chaos-os/agentic",
    color: "text-violet-400",
    bg: "bg-violet-950/30",
  },
  {
    id: "bwb",
    name: "BWB",
    description: "Build With Brain - AI-assisted development",
    icon: Wrench,
    href: "/chaos-os/bwb",
    color: "text-orange-400",
    bg: "bg-orange-950/30",
  },
  {
    id: "builder",
    name: "CHAOS Build",
    description: "Visual builder for WIRED CHAOS components",
    icon: Zap,
    href: "/chaos-os/builder",
    color: "text-yellow-400",
    bg: "bg-yellow-950/30",
  },
  {
    id: "university",
    name: "University",
    description: "WIRED CHAOS learning and certification",
    icon: GraduationCap,
    href: "/chaos-os/university",
    color: "text-pink-400",
    bg: "bg-pink-950/30",
  },
  {
    id: "system-map",
    name: "System Map",
    description: "Patch registry status and navigation",
    icon: Map,
    href: "/chaos-os/system-map",
    color: "text-blue-400",
    bg: "bg-blue-950/30",
  },
  {
    id: "database",
    name: "Database",
    description: "Direct database access and queries",
    icon: Database,
    href: "/chaos-os/database",
    color: "text-red-400",
    bg: "bg-red-950/30",
  },
]

export default function ChaosOSPage() {
  const [hoveredModule, setHoveredModule] = useState<string | null>(null)

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/40 bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-cyan-500 to-violet-500 flex items-center justify-center">
              <Brain className="h-5 w-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold">CHAOS OS</h1>
              <p className="text-xs text-muted-foreground">WIRED CHAOS META Operating System</p>
            </div>
          </div>
          <Link href="/">
            <Button variant="outline" size="sm">
              Return to Lobby
            </Button>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="container px-4 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-2">System Modules</h2>
          <p className="text-muted-foreground">Select a module to access CHAOS OS functionality</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {modules.map((module) => {
            const Icon = module.icon
            const isHovered = hoveredModule === module.id

            return (
              <Link key={module.id} href={module.href}>
                <Card
                  className={`h-full cursor-pointer transition-all duration-200 ${module.bg} border-border/50 hover:border-${module.color.split("-")[1]}-500/50`}
                  onMouseEnter={() => setHoveredModule(module.id)}
                  onMouseLeave={() => setHoveredModule(null)}
                >
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <Icon className={`h-6 w-6 ${module.color}`} />
                      <ArrowRight
                        className={`h-4 w-4 transition-transform duration-200 ${
                          isHovered ? "translate-x-0 opacity-100" : "-translate-x-2 opacity-0"
                        } ${module.color}`}
                      />
                    </div>
                    <CardTitle className="text-base">{module.name}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-sm">{module.description}</CardDescription>
                  </CardContent>
                </Card>
              </Link>
            )
          })}
        </div>

        {/* Quick Stats */}
        <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-muted/30">
            <CardContent className="pt-4">
              <p className="text-2xl font-bold text-cyan-400">15</p>
              <p className="text-sm text-muted-foreground">Active Patches</p>
            </CardContent>
          </Card>
          <Card className="bg-muted/30">
            <CardContent className="pt-4">
              <p className="text-2xl font-bold text-emerald-400">267</p>
              <p className="text-sm text-muted-foreground">Database Tables</p>
            </CardContent>
          </Card>
          <Card className="bg-muted/30">
            <CardContent className="pt-4">
              <p className="text-2xl font-bold text-violet-400">4</p>
              <p className="text-sm text-muted-foreground">Seeker Jobs</p>
            </CardContent>
          </Card>
          <Card className="bg-muted/30">
            <CardContent className="pt-4">
              <p className="text-2xl font-bold text-orange-400">2</p>
              <p className="text-sm text-muted-foreground">Active Realms</p>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
