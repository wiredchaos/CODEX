import { notFound } from "next/navigation"
import { SideNav } from "@/components/side-nav"
import { NeonBorder } from "@/components/neon-border"

const creators = {
  "neuro-meta-x": {
    name: "NEURO META X | NMX",
    role: "Prime Architect",
    realm: "neuralis",
    bio: "Lead architect of the WIRED CHAOS META OS. Orchestrates the Business Stack infrastructure across Neuralis realm, managing telemetry systems, hemisphere mapping, and patch governance protocols.",
    works: [
      {
        category: "Literary",
        items: [
          "The 589 Codex — Frequency Foundation Text",
          "Neteru Apinaya Chronicles — 33 Patch Series",
          "Business Stack Manifesto — Architecture Guide",
        ],
      },
      {
        category: "Interactive Systems",
        items: [
          "Global Telemetry Bus — Real-time Metrics Platform",
          "Hemisphere Mapping Engine — Dual Scoring System",
          "Role Engine — NPC & Player Framework",
        ],
      },
      {
        category: "Infrastructure",
        items: [
          "Patch Governance System — Business/Akashic Firewall",
          "WL Gamification Framework — Achievement Protocols",
          "Anti-Moloch Logic Layer — Self-Healing Systems",
        ],
      },
    ],
    stats: {
      patches: 33,
      transmissions: 589,
      uptime: "99.9%",
    },
  },
}

export default function CreatorPage({ params }: { params: { id: string } }) {
  const creator = creators[params.id as keyof typeof creators]

  if (!creator) {
    notFound()
  }

  return (
    <main className="relative min-h-screen" id="main-content">
      <SideNav />
      <div className="grid-bg fixed inset-0 opacity-30" aria-hidden="true" />

      <div className="relative z-10 min-h-screen px-6 py-20 md:pl-28 md:pr-12">
        {/* Header */}
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-4">
            <NeonBorder color="cyan" className="px-4 py-2">
              <span className="font-mono text-xs uppercase tracking-widest text-cyan-400">Business Stack</span>
            </NeonBorder>
            <NeonBorder color="cyan" className="px-4 py-2">
              <span className="font-mono text-xs uppercase tracking-widest text-cyan-400">{creator.realm}</span>
            </NeonBorder>
          </div>

          <h1 className="font-[var(--font-bebas)] text-6xl md:text-8xl text-foreground neon-text mb-4">
            {creator.name}
          </h1>
          <p className="font-mono text-xl text-cyan-400 uppercase tracking-wide neon-text">{creator.role}</p>
        </div>

        {/* Bio */}
        <div className="glass p-8 mb-12 max-w-3xl neon-glow">
          <p className="text-base leading-relaxed text-foreground">{creator.bio}</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-12 max-w-3xl">
          {Object.entries(creator.stats).map(([key, value]) => (
            <div key={key} className="glass p-6 text-center neon-glow">
              <div className="text-4xl font-bold text-cyan-400 neon-text mb-2">{value}</div>
              <div className="font-mono text-xs uppercase tracking-widest text-muted-foreground">{key}</div>
            </div>
          ))}
        </div>

        {/* Works */}
        <div className="max-w-4xl">
          <h2 className="font-[var(--font-bebas)] text-4xl text-foreground mb-8 neon-text">Works & Systems</h2>
          <div className="space-y-8">
            {creator.works.map((category) => (
              <div key={category.category} className="glass p-8 neon-glow">
                <h3 className="font-mono text-sm uppercase tracking-widest text-cyan-400 mb-4 neon-text">
                  {category.category}
                </h3>
                <ul className="space-y-3">
                  {category.items.map((item) => (
                    <li key={item} className="flex items-start gap-3">
                      <span className="text-cyan-400 mt-1 neon-text">→</span>
                      <span className="text-foreground leading-relaxed">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>
    </main>
  )
}
