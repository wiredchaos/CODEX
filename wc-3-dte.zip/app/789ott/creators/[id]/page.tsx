import { notFound } from "next/navigation"
import { SideNav } from "@/components/side-nav"
import { NeonBorder } from "@/components/neon-border"

const creators = {
  "neuro-meta-x": {
    name: "NEURO META X | NMX",
    role: "Prime Architect",
    realm: "neuralis",
    bio: "Broadcast architect for Studio789 OTT. Produces transmissions across multiple channels, maintaining the 589 frequency signature in all broadcast content.",
    transmissions: [
      {
        series: "META OS Daily Brief",
        episodes: 589,
        hours: 294,
        status: "Active",
      },
      {
        series: "Patch Index Review",
        episodes: 33,
        hours: 66,
        status: "Active",
      },
      {
        series: "Realm Crossover Sessions",
        episodes: 12,
        hours: 24,
        status: "Active",
      },
    ],
    stats: {
      totalEpisodes: 634,
      totalHours: 384,
      subscribers: "589K",
    },
  },
}

export default function OTTCreatorPage({ params }: { params: { id: string } }) {
  const creator = creators[params.id as keyof typeof creators]

  if (!creator) {
    notFound()
  }

  return (
    <main className="relative min-h-screen" id="main-content">
      <SideNav />
      <div className="grid-bg fixed inset-0 opacity-30" aria-hidden="true" />

      <div className="relative z-10 min-h-screen px-6 py-20 md:pl-28 md:pr-12">
        {/* Header */}
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-4">
            <NeonBorder color="red" className="px-4 py-2">
              <span className="font-mono text-xs uppercase tracking-widest text-red-400">Studio789 OTT</span>
            </NeonBorder>
            <NeonBorder color="red" className="px-4 py-2">
              <span className="font-mono text-xs uppercase tracking-widest text-red-400">Broadcast</span>
            </NeonBorder>
          </div>

          <h1 className="font-[var(--font-bebas)] text-6xl md:text-8xl text-foreground neon-text mb-4">
            {creator.name}
          </h1>
          <p className="font-mono text-xl text-red-400 uppercase tracking-wide neon-text">{creator.role}</p>
        </div>

        {/* Bio */}
        <div className="glass p-8 mb-12 max-w-3xl neon-glow-red">
          <p className="text-base leading-relaxed text-foreground">{creator.bio}</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-12 max-w-3xl">
          {Object.entries(creator.stats).map(([key, value]) => (
            <div key={key} className="glass p-6 text-center neon-glow-red">
              <div className="text-4xl font-bold text-red-400 neon-text mb-2">{value}</div>
              <div className="font-mono text-xs uppercase tracking-widest text-muted-foreground">{key}</div>
            </div>
          ))}
        </div>

        {/* Transmissions */}
        <div className="max-w-4xl">
          <h2 className="font-[var(--font-bebas)] text-4xl text-foreground mb-8 neon-text">Broadcast Transmissions</h2>
          <div className="space-y-6">
            {creator.transmissions.map((transmission) => (
              <div key={transmission.series} className="glass p-8 neon-glow-red">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                  <h3 className="font-mono text-lg text-foreground neon-text">{transmission.series}</h3>
                  <span
                    className={`inline-block px-3 py-1 rounded font-mono text-xs uppercase ${
                      transmission.status === "Active"
                        ? "bg-red-500/20 text-red-400 border border-red-500/40"
                        : "bg-muted text-muted-foreground border border-border"
                    }`}
                  >
                    {transmission.status}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <div className="text-2xl font-bold text-red-400 neon-text">{transmission.episodes}</div>
                    <div className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Episodes</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-red-400 neon-text">{transmission.hours}h</div>
                    <div className="font-mono text-xs text-muted-foreground uppercase tracking-widest">Total Hours</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </main>
  )
}
