"use client"

import { useRouter } from "next/navigation"
import { ArrowLeft, Radio, Building2, TrendingUp, Sparkles } from "lucide-react"
import { useState } from "react"
import Image from "next/image"

const LOBBY_COLORS = {
  cyan: "#00FFF7",
  red: "#FF1A1A",
  purple: "#A020F0",
  gold: "#FFD700",
  blue: "#00BFFF",
  dark: "#000000",
}

const LOBBY_SECTIONS = [
  {
    id: "beastcoast",
    title: "BEASTCOAST",
    subtitle: "BROADCAST",
    color: LOBBY_COLORS.red,
    icon: Radio,
    route: "/",
    description: "Main broadcast studio",
  },
  {
    id: "589-mint",
    title: "589",
    subtitle: "MINT FACTORY",
    color: LOBBY_COLORS.cyan,
    icon: Building2,
    route: "/",
    description: "NFT minting and creation",
  },
  {
    id: "333-dogechain",
    title: "33.3FM",
    subtitle: "DOGECHAIN",
    color: LOBBY_COLORS.blue,
    icon: Radio,
    route: "/333",
    description: "Virtual signal studio",
  },
  {
    id: "ai-academy",
    title: "AI ACADEMY",
    subtitle: "LEARNING",
    color: LOBBY_COLORS.cyan,
    icon: TrendingUp,
    route: "/",
    description: "AI education platform",
  },
]

export default function LobbyPage() {
  const router = useRouter()
  const [hoveredSection, setHoveredSection] = useState<string | null>(null)
  const [showChoice, setShowChoice] = useState(true)

  return (
    <div className="min-h-screen relative overflow-hidden bg-black">
      {/* TRON Grid Background */}
      <div
        className="fixed inset-0 opacity-30"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${LOBBY_COLORS.cyan}20 1px, transparent 1px),
            linear-gradient(to bottom, ${LOBBY_COLORS.cyan}20 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {showChoice && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-xl">
          <div className="text-center max-w-md mx-4">
            {/* NEURO Avatar */}
            <div className="mb-8">
              <div
                className="w-32 h-32 mx-auto rounded-full flex items-center justify-center relative overflow-hidden"
                style={{
                  boxShadow: "0 0 60px rgba(0, 255, 247, 0.5)",
                }}
              >
                <Image
                  src="/images/20251214-084103.jpg"
                  alt="NEURO Concierge"
                  width={128}
                  height={128}
                  className="rounded-full object-cover"
                />
                <div
                  className="absolute inset-[-4px] border-2 rounded-full animate-spin"
                  style={{
                    borderColor: "#00FFF7",
                    borderTopColor: "transparent",
                    borderBottomColor: "transparent",
                    animationDuration: "3s",
                  }}
                />
              </div>
            </div>

            <h2
              className="font-display text-3xl uppercase mb-4"
              style={{ color: "#00FFF7", textShadow: "0 0 30px rgba(0, 255, 247, 0.8)" }}
            >
              NEURO CONCIERGE
            </h2>

            <p className="text-neutral-400 font-mono text-sm mb-8">
              Welcome to WIRED CHAOS META. How would you like to proceed?
            </p>

            <div className="flex flex-col gap-4">
              <button
                onClick={() => {
                  setShowChoice(false)
                  router.push("/?tour=true")
                }}
                className="w-full py-4 px-6 rounded-xl font-mono text-sm uppercase tracking-wider flex items-center justify-center gap-3"
                style={{
                  background: "linear-gradient(135deg, #00FFF7, #00BFFF)",
                  color: "#000",
                  boxShadow: "0 0 30px rgba(0, 255, 247, 0.5)",
                }}
              >
                <Sparkles className="w-5 h-5" />
                Start Guided Tour
              </button>

              <button
                onClick={() => setShowChoice(false)}
                className="w-full py-4 px-6 rounded-xl font-mono text-sm uppercase tracking-wider flex items-center justify-center gap-3 border border-neutral-700 text-neutral-400 hover:border-cyan-500/50"
              >
                <Building2 className="w-5 h-5" />
                Skip → Elevator
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="relative z-50 backdrop-blur-xl border-b border-cyan-500/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => router.push("/")}
              className="flex items-center gap-2 transition-colors hover:opacity-80"
              style={{ color: LOBBY_COLORS.cyan }}
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="font-mono text-xs sm:text-sm uppercase">WIRED CHAOS</span>
            </button>

            <div>
              <h1
                className="font-display text-xl sm:text-3xl uppercase tracking-wider"
                style={{
                  color: LOBBY_COLORS.cyan,
                  textShadow: `0 0 20px ${LOBBY_COLORS.cyan}, 0 0 40px ${LOBBY_COLORS.cyan}`,
                }}
              >
                LOBBY
              </h1>
              <p className="font-mono text-xs text-neutral-500 uppercase tracking-widest text-right">Main Entrance</p>
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-16">
        {/* Banner Image */}
        <div className="mb-12 sm:mb-16">
          <Image
            src="/images/3ee74b7a-d18b-4084-afe2.jpeg"
            alt="WIRED CHAOS Lobby"
            width={1200}
            height={400}
            className="w-full rounded-2xl border-2 border-cyan-500/30 shadow-2xl object-cover"
            style={{
              boxShadow: `0 0 60px ${LOBBY_COLORS.cyan}40`,
            }}
          />
        </div>

        {/* Interactive Sections */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {LOBBY_SECTIONS.map((section) => {
            const Icon = section.icon
            const isHovered = hoveredSection === section.id

            return (
              <button
                key={section.id}
                onClick={() => router.push(section.route)}
                onMouseEnter={() => setHoveredSection(section.id)}
                onMouseLeave={() => setHoveredSection(null)}
                className="group relative p-6 sm:p-8 rounded-2xl text-left transition-all duration-500 focus:outline-none focus-visible:ring-2"
                style={{
                  background: isHovered
                    ? `linear-gradient(135deg, ${section.color}20, ${LOBBY_COLORS.dark})`
                    : "rgba(10, 15, 25, 0.8)",
                  border: `2px solid ${isHovered ? section.color : `${section.color}20`}`,
                  boxShadow: isHovered ? `0 0 40px ${section.color}60, inset 0 0 40px ${section.color}10` : "none",
                  transform: isHovered ? "scale(1.05)" : "scale(1)",
                }}
              >
                <div
                  className="w-14 h-14 rounded-xl flex items-center justify-center mb-6 transition-all duration-300"
                  style={{
                    background: `${section.color}20`,
                    boxShadow: isHovered ? `0 0 30px ${section.color}60` : "none",
                  }}
                >
                  <Icon className="w-7 h-7" style={{ color: section.color }} />
                </div>

                <h3
                  className="font-display text-2xl uppercase mb-2 transition-all duration-300"
                  style={{
                    color: isHovered ? section.color : "#fff",
                    textShadow: isHovered ? `0 0 20px ${section.color}` : "none",
                  }}
                >
                  {section.title}
                </h3>
                <p className="font-mono text-sm uppercase tracking-wider mb-4" style={{ color: section.color }}>
                  {section.subtitle}
                </p>
                <p className="text-sm text-neutral-500">{section.description}</p>
              </button>
            )
          })}
        </div>
      </main>
    </div>
  )
}
