"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  ArrowLeft,
  CreditCard,
  TrendingUp,
  Shield,
  FileText,
  CheckCircle,
  AlertTriangle,
  Target,
  Zap,
} from "lucide-react"
import { LiveCircuitry } from "@/components/live-circuitry"
import { Button } from "@/components/ui/button"

const BUSINESS_BLUE = {
  primary: "#0066FF",
  secondary: "#0044CC",
  accent: "#0088FF",
  dark: "#000814",
  glow: "rgba(0, 102, 255, 0.5)",
}

const CREDIT_TIERS = [
  { range: "300-579", label: "POOR", color: "#FF1A1A", description: "Needs significant repair" },
  { range: "580-669", label: "FAIR", color: "#FFA500", description: "Room for improvement" },
  { range: "670-739", label: "GOOD", color: "#FFD700", description: "Solid foundation" },
  { range: "740-799", label: "VERY GOOD", color: "#00FF88", description: "Excellent standing" },
  { range: "800-850", label: "EXCEPTIONAL", color: "#00FFF7", description: "Top tier credit" },
]

const SERVICES = [
  {
    icon: FileText,
    title: "Dispute Management",
    description: "AI-powered dispute letter generation and tracking",
    features: ["Auto-generated dispute letters", "Bureau response tracking", "Success rate analytics"],
  },
  {
    icon: Shield,
    title: "Identity Protection",
    description: "Monitor and protect your credit identity",
    features: ["Dark web monitoring", "Fraud alerts", "Identity theft insurance"],
  },
  {
    icon: TrendingUp,
    title: "Score Optimization",
    description: "Strategic credit building recommendations",
    features: ["Payment optimization", "Utilization guidance", "Account age strategy"],
  },
  {
    icon: Target,
    title: "Goal Planning",
    description: "Set and track your credit improvement goals",
    features: ["Mortgage readiness", "Auto loan prep", "Business credit path"],
  },
]

export default function CreditRepairPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<"overview" | "disputes" | "monitoring" | "goals">("overview")
  const [currentScore, setCurrentScore] = useState(650)

  const getScoreTier = (score: number) => {
    if (score < 580) return CREDIT_TIERS[0]
    if (score < 670) return CREDIT_TIERS[1]
    if (score < 740) return CREDIT_TIERS[2]
    if (score < 800) return CREDIT_TIERS[3]
    return CREDIT_TIERS[4]
  }

  const tier = getScoreTier(currentScore)

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: BUSINESS_BLUE.dark }}>
      <LiveCircuitry />

      {/* Blue Grid Background */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${BUSINESS_BLUE.primary}15 1px, transparent 1px),
            linear-gradient(to bottom, ${BUSINESS_BLUE.primary}15 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Header */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(0, 0, 0, 0.9)",
          borderColor: `${BUSINESS_BLUE.primary}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => router.push("/")}
                className="flex items-center gap-2 transition-colors hover:opacity-80"
                style={{ color: BUSINESS_BLUE.primary }}
              >
                <ArrowLeft className="w-5 h-5" />
                <span className="font-mono text-sm uppercase hidden sm:inline">Lobby</span>
              </button>
              <div className="w-px h-6" style={{ background: `${BUSINESS_BLUE.primary}30` }} />
              <div className="flex items-center gap-2">
                <CreditCard className="w-6 h-6" style={{ color: BUSINESS_BLUE.primary }} />
                <h1
                  className="font-display text-2xl uppercase tracking-wider"
                  style={{
                    color: BUSINESS_BLUE.primary,
                    textShadow: `0 0 20px ${BUSINESS_BLUE.glow}`,
                  }}
                >
                  CREDIT REPAIR
                </h1>
              </div>
            </div>
            <div
              className="px-3 py-1 rounded-full text-xs font-mono uppercase"
              style={{
                background: `${BUSINESS_BLUE.primary}20`,
                color: BUSINESS_BLUE.primary,
                border: `1px solid ${BUSINESS_BLUE.primary}40`,
              }}
            >
              Business Realm
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Score Display */}
        <div
          className="p-6 sm:p-8 rounded-2xl mb-8"
          style={{
            background: "rgba(0, 0, 0, 0.6)",
            border: `1px solid ${BUSINESS_BLUE.primary}20`,
          }}
        >
          <div className="flex flex-col md:flex-row items-center gap-8">
            {/* Score Circle */}
            <div className="relative">
              <div
                className="w-40 h-40 rounded-full flex items-center justify-center"
                style={{
                  background: `conic-gradient(${tier.color} ${(currentScore / 850) * 360}deg, rgba(255,255,255,0.1) 0deg)`,
                  boxShadow: `0 0 40px ${tier.color}30`,
                }}
              >
                <div
                  className="w-32 h-32 rounded-full flex flex-col items-center justify-center"
                  style={{ background: BUSINESS_BLUE.dark }}
                >
                  <span className="text-4xl font-display" style={{ color: tier.color }}>
                    {currentScore}
                  </span>
                  <span className="text-xs font-mono text-neutral-400">SCORE</span>
                </div>
              </div>
            </div>

            {/* Score Info */}
            <div className="flex-1 text-center md:text-left">
              <div
                className="inline-block px-3 py-1 rounded-full text-sm font-mono uppercase mb-2"
                style={{
                  background: `${tier.color}20`,
                  color: tier.color,
                }}
              >
                {tier.label}
              </div>
              <h2 className="text-2xl font-display text-white mb-2">{tier.description}</h2>
              <p className="text-neutral-400 mb-4">Score Range: {tier.range}</p>

              {/* Score Tiers Bar */}
              <div className="flex gap-1 h-2 rounded-full overflow-hidden">
                {CREDIT_TIERS.map((t, i) => (
                  <div
                    key={i}
                    className="flex-1"
                    style={{
                      background:
                        currentScore >= Number.parseInt(t.range.split("-")[0]) ? t.color : "rgba(255,255,255,0.1)",
                    }}
                  />
                ))}
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 rounded-xl" style={{ background: "rgba(0,0,0,0.4)" }}>
                <Zap className="w-6 h-6 mx-auto mb-2" style={{ color: "#00FF88" }} />
                <div className="text-2xl font-display text-white">+45</div>
                <div className="text-xs text-neutral-500">Points Gained</div>
              </div>
              <div className="text-center p-4 rounded-xl" style={{ background: "rgba(0,0,0,0.4)" }}>
                <CheckCircle className="w-6 h-6 mx-auto mb-2" style={{ color: BUSINESS_BLUE.primary }} />
                <div className="text-2xl font-display text-white">12</div>
                <div className="text-xs text-neutral-500">Items Removed</div>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {(["overview", "disputes", "monitoring", "goals"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className="px-4 py-2 rounded-lg font-mono text-sm uppercase whitespace-nowrap transition-all"
              style={{
                background: activeTab === tab ? BUSINESS_BLUE.primary : "rgba(0,0,0,0.4)",
                color: activeTab === tab ? "#000" : "#999",
                border: `1px solid ${activeTab === tab ? BUSINESS_BLUE.primary : "rgba(255,255,255,0.1)"}`,
              }}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Services Grid */}
        {activeTab === "overview" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {SERVICES.map((service, i) => {
              const Icon = service.icon
              return (
                <div
                  key={i}
                  className="p-6 rounded-xl transition-all hover:scale-[1.02]"
                  style={{
                    background: "rgba(0, 0, 0, 0.6)",
                    border: `1px solid ${BUSINESS_BLUE.primary}20`,
                  }}
                >
                  <div className="flex items-start gap-4 mb-4">
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center"
                      style={{ background: `${BUSINESS_BLUE.primary}20` }}
                    >
                      <Icon className="w-6 h-6" style={{ color: BUSINESS_BLUE.primary }} />
                    </div>
                    <div>
                      <h3 className="font-display text-lg text-white uppercase">{service.title}</h3>
                      <p className="text-sm text-neutral-400">{service.description}</p>
                    </div>
                  </div>
                  <ul className="space-y-2">
                    {service.features.map((feature, j) => (
                      <li key={j} className="flex items-center gap-2 text-sm text-neutral-300">
                        <CheckCircle className="w-4 h-4" style={{ color: BUSINESS_BLUE.primary }} />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              )
            })}
          </div>
        )}

        {activeTab === "disputes" && (
          <div
            className="p-8 rounded-xl text-center"
            style={{
              background: "rgba(0, 0, 0, 0.6)",
              border: `1px solid ${BUSINESS_BLUE.primary}20`,
            }}
          >
            <AlertTriangle className="w-12 h-12 mx-auto mb-4" style={{ color: "#FFA500" }} />
            <h3 className="text-xl font-display text-white mb-2">DISPUTE CENTER</h3>
            <p className="text-neutral-400 mb-6">AI-powered dispute generation and tracking coming soon.</p>
            <Button style={{ background: BUSINESS_BLUE.primary }} className="font-mono uppercase">
              Join Waitlist
            </Button>
          </div>
        )}

        {activeTab === "monitoring" && (
          <div
            className="p-8 rounded-xl text-center"
            style={{
              background: "rgba(0, 0, 0, 0.6)",
              border: `1px solid ${BUSINESS_BLUE.primary}20`,
            }}
          >
            <Shield className="w-12 h-12 mx-auto mb-4" style={{ color: BUSINESS_BLUE.primary }} />
            <h3 className="text-xl font-display text-white mb-2">CREDIT MONITORING</h3>
            <p className="text-neutral-400 mb-6">24/7 credit monitoring and alerts.</p>
            <Button style={{ background: BUSINESS_BLUE.primary }} className="font-mono uppercase">
              Enable Monitoring
            </Button>
          </div>
        )}

        {activeTab === "goals" && (
          <div
            className="p-8 rounded-xl text-center"
            style={{
              background: "rgba(0, 0, 0, 0.6)",
              border: `1px solid ${BUSINESS_BLUE.primary}20`,
            }}
          >
            <Target className="w-12 h-12 mx-auto mb-4" style={{ color: "#00FF88" }} />
            <h3 className="text-xl font-display text-white mb-2">GOAL PLANNER</h3>
            <p className="text-neutral-400 mb-6">Set your credit goals and track progress.</p>
            <Button style={{ background: BUSINESS_BLUE.primary }} className="font-mono uppercase">
              Set Goals
            </Button>
          </div>
        )}
      </main>
    </div>
  )
}
