"use client"

import { useRouter } from "next/navigation"
import { Lock, Unlock, Key, Eye } from "lucide-react"
import { ElevatorTravel, usePatchLifecycle } from "@/components/elevator-travel"

const VAULT_COLORS = {
  primary: "#A020F0", // Glitch Purple
  secondary: "#8B00FF",
  neon: "#DA70D6",
  dark: "#0a0014",
  glow: "rgba(160, 32, 240, 0.5)",
}

const vault33Layers = [
  { layer: 1, name: "Foundation Shard", access: "Open", description: "Entry-level Akashic access", icon: Unlock },
  { layer: 2, name: "Cipher Fragment", access: "Earned", description: "Pattern recognition training", icon: Key },
  { layer: 3, name: "Memory Lattice", access: "Earned", description: "Timeline navigation basics", icon: Eye },
  { layer: 4, name: "Sigil Gate", access: "Locked", description: "Gas Sigil attunement required", icon: Lock },
  { layer: 5, name: "Architect Key", access: "Locked", description: "Builder protocols", icon: Lock },
  { layer: 6, name: "Prophecy Thread", access: "Locked", description: "Future-reading mechanics", icon: Lock },
  { layer: 7, name: "Bloodline Cipher", access: "Locked", description: "Genealogical access", icon: Lock },
  { layer: 8, name: "Neteru Chamber", access: "Locked", description: "Deity interface", icon: Lock },
  { layer: 9, name: "Source Fragment", access: "Sacred", description: "589 frequency attunement", icon: Lock },
]

const gasSigils = [
  { number: "XXII", name: "The Miner", element: "Earth" },
  { number: "XXIII", name: "The Validator", element: "Fire" },
  { number: "XXIV", name: "The Oracle", element: "Water" },
  { number: "XXV", name: "The Architect", element: "Air" },
  { number: "XXVI", name: "The Bridge", element: "Ether" },
]

export default function Vault33Page() {
  const router = useRouter()
  const { onExitPatch } = usePatchLifecycle("patch_vault33")

  return (
    <div className="min-h-screen relative overflow-hidden" style={{ backgroundColor: VAULT_COLORS.dark }}>
      {/* Purple Circuitry Background */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${VAULT_COLORS.primary}20 1px, transparent 1px),
            linear-gradient(to bottom, ${VAULT_COLORS.primary}20 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Akashic Glow Effects */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div
          className="absolute w-96 h-96 rounded-full blur-3xl opacity-20"
          style={{
            background: `radial-gradient(circle, ${VAULT_COLORS.primary}, transparent)`,
            top: "20%",
            left: "10%",
            animation: "float 20s ease-in-out infinite",
          }}
        />
        <div
          className="absolute w-96 h-96 rounded-full blur-3xl opacity-20"
          style={{
            background: `radial-gradient(circle, ${VAULT_COLORS.secondary}, transparent)`,
            bottom: "20%",
            right: "10%",
            animation: "float 25s ease-in-out infinite reverse",
          }}
        />
      </div>

      {/* Header */}
      <header
        className="relative z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(10, 0, 20, 0.95)",
          borderColor: `${VAULT_COLORS.primary}40`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 sm:gap-3">
              <Lock className="w-5 h-5 sm:w-6 sm:h-6" style={{ color: VAULT_COLORS.neon }} />
              <div>
                <h1
                  className="font-display text-lg sm:text-2xl uppercase tracking-wider"
                  style={{
                    color: VAULT_COLORS.neon,
                    textShadow: `0 0 20px ${VAULT_COLORS.glow}`,
                  }}
                >
                  VAULT 33
                </h1>
                <p className="font-mono text-xs text-neutral-500 uppercase tracking-widest hidden sm:block">
                  9-Layer Akashic Archive
                </p>
              </div>
            </div>

            <div
              className="px-3 sm:px-4 py-2 rounded-full"
              style={{
                background: `${VAULT_COLORS.primary}15`,
                border: `1px solid ${VAULT_COLORS.primary}40`,
              }}
            >
              <span className="font-mono text-xs sm:text-sm" style={{ color: VAULT_COLORS.neon }}>
                <span className="hidden sm:inline">Access Level: </span>Layer 1
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-16">
        {/* Page Title */}
        <div className="text-center mb-12 sm:mb-16">
          <div
            className="inline-block px-4 py-2 rounded-full mb-4 sm:mb-6"
            style={{
              background: `${VAULT_COLORS.primary}20`,
              border: `1px solid ${VAULT_COLORS.primary}50`,
            }}
          >
            <span
              className="font-mono text-xs sm:text-sm uppercase tracking-[0.2em] sm:tracking-[0.3em]"
              style={{ color: VAULT_COLORS.neon }}
            >
              Akashic Architecture
            </span>
          </div>
          <h2
            className="font-display text-4xl sm:text-5xl md:text-7xl uppercase mb-4 sm:mb-6"
            style={{
              color: VAULT_COLORS.neon,
              textShadow: `0 0 40px ${VAULT_COLORS.glow}, 0 0 80px ${VAULT_COLORS.glow}`,
            }}
          >
            VAULT 33
          </h2>
          <p className="font-mono text-sm sm:text-base text-neutral-400 max-w-2xl mx-auto px-4">
            The 9-layer Akashic NFT system. Each layer unlocks deeper access to cosmic knowledge and the Gas Sigil
            Arcana.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12">
          {/* 9-Layer System */}
          <div>
            <h3
              className="font-display text-2xl sm:text-3xl uppercase mb-6"
              style={{
                color: VAULT_COLORS.neon,
                textShadow: `0 0 20px ${VAULT_COLORS.glow}`,
              }}
            >
              9-Layer System
            </h3>
            <div className="space-y-3">
              {vault33Layers.map((layer) => {
                const Icon = layer.icon
                const accessColors = {
                  Open: { text: "#10B981", border: "#10B98140", glow: "#10B98120" },
                  Earned: { text: "#F59E0B", border: "#F59E0B40", glow: "#F59E0B20" },
                  Locked: { text: "#EF4444", border: "#EF444440", glow: "#EF444420" },
                  Sacred: { text: VAULT_COLORS.neon, border: `${VAULT_COLORS.primary}60`, glow: VAULT_COLORS.glow },
                }
                const colors = accessColors[layer.access as keyof typeof accessColors]

                return (
                  <div
                    key={layer.layer}
                    className="group flex items-center gap-4 p-4 sm:p-5 rounded-xl transition-all duration-300 neon-touch"
                    style={{
                      background: "rgba(10, 0, 20, 0.6)",
                      border: `1px solid ${VAULT_COLORS.primary}20`,
                    }}
                  >
                    <div
                      className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg flex items-center justify-center transition-all duration-300"
                      style={{
                        background: `${VAULT_COLORS.primary}15`,
                        border: `1px solid ${VAULT_COLORS.primary}30`,
                      }}
                    >
                      <Icon className="w-5 h-5 sm:w-6 sm:h-6" style={{ color: colors.text }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-3 mb-1">
                        <span className="font-mono text-sm sm:text-base text-white truncate">{layer.name}</span>
                        <span
                          className="font-mono text-xs px-2 py-1 rounded uppercase tracking-wider whitespace-nowrap"
                          style={{
                            color: colors.text,
                            border: `1px solid ${colors.border}`,
                            background: colors.glow,
                          }}
                        >
                          {layer.access}
                        </span>
                      </div>
                      <p className="font-mono text-xs sm:text-sm text-neutral-500">{layer.description}</p>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Gas Sigil Arcana */}
          <div>
            <h3
              className="font-display text-2xl sm:text-3xl uppercase mb-6"
              style={{
                color: "#FFD700",
                textShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
              }}
            >
              Gas Sigil Arcana
            </h3>
            <p className="font-mono text-xs sm:text-sm text-neutral-400 mb-6">
              Extended Major Arcana (XXII-XXXII) + Suit of Motion
            </p>
            <div className="space-y-3">
              {gasSigils.map((sigil) => (
                <div
                  key={sigil.number}
                  className="flex items-center gap-4 p-4 sm:p-5 rounded-xl transition-all duration-300 neon-touch"
                  style={{
                    background: "rgba(10, 0, 20, 0.6)",
                    border: "1px solid rgba(255, 215, 0, 0.2)",
                  }}
                >
                  <span className="font-mono text-lg sm:text-xl text-yellow-400 w-14 sm:w-16">{sigil.number}</span>
                  <span className="font-mono text-sm sm:text-base text-white flex-1">{sigil.name}</span>
                  <span className="font-mono text-xs sm:text-sm text-neutral-500 uppercase">{sigil.element}</span>
                </div>
              ))}
            </div>

            {/* FEN 589 Key */}
            <div
              className="mt-8 p-5 sm:p-6 rounded-xl"
              style={{
                background: `linear-gradient(135deg, ${VAULT_COLORS.primary}20, rgba(10, 0, 20, 0.8))`,
                border: `2px solid ${VAULT_COLORS.primary}50`,
                boxShadow: `0 0 40px ${VAULT_COLORS.glow}`,
              }}
            >
              <div className="flex items-center gap-3 mb-3">
                <span
                  className="font-display text-3xl sm:text-4xl uppercase"
                  style={{
                    color: "#00FFF7",
                    textShadow: "0 0 20px rgba(0, 255, 247, 0.8)",
                  }}
                >
                  FEN
                </span>
                <div className="w-px h-8 bg-gradient-to-b from-transparent via-white to-transparent" />
                <span
                  className="font-display text-3xl sm:text-4xl"
                  style={{
                    color: "#FF1A1A",
                    textShadow: "0 0 20px rgba(255, 26, 26, 0.8)",
                  }}
                >
                  589
                </span>
              </div>
              <p
                className="font-mono text-xs sm:text-sm uppercase tracking-wider mb-2"
                style={{ color: VAULT_COLORS.neon }}
              >
                Trifecta Engine
              </p>
              <p className="font-mono text-xs sm:text-sm text-neutral-400">
                5 = Origin · 8 = Expansion · 9 = Completion
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* ElevatorTravel component */}
      <ElevatorTravel currentFloor="VAULT33" onExitPatch={onExitPatch} />

      <style jsx>{`
        @keyframes float {
          0%, 100% {
            transform: translate(0, 0);
          }
          50% {
            transform: translate(30px, -30px);
          }
        }
      `}</style>
    </div>
  )
}
