import { HeroSection } from "@/components/hero-section"
import { RealmsSection } from "@/components/realms-section"
import { TimelineSection } from "@/components/timeline-section"
import { FactionsSection } from "@/components/factions-section"
import { PatchesSection } from "@/components/patches-section"
import { ColophonSection } from "@/components/colophon-section"
import { SideNav } from "@/components/side-nav"
import { GlobeViewer } from "@/components/globe-viewer"
import { XRAssetGallery } from "@/components/xr-asset-gallery"
import { LiveCircuitry } from "@/components/live-circuitry"
import { ElevatorButton } from "@/components/elevator-button"
import { MobileNav } from "@/components/mobile-nav"
import { EntryGate } from "@/components/entry-gate"

export default function Page() {
  return (
    <>
      <EntryGate />

      <main id="main-content" className="relative min-h-screen" tabIndex={-1}>
        <SideNav />
        <MobileNav />
        <div className="circuit-bg fixed inset-0 opacity-40" aria-hidden="true" />

        <LiveCircuitry />

        {/* 3D Globe Background */}
        <div className="fixed inset-0 z-0 opacity-50 pointer-events-none" aria-hidden="true">
          <GlobeViewer />
        </div>

        <div className="relative z-10">
          <HeroSection />
          <RealmsSection />
          <TimelineSection />
          <FactionsSection />
          <PatchesSection />
          <XRAssetGallery />
          <ColophonSection />
        </div>

        <ElevatorButton />
      </main>
    </>
  )
}
