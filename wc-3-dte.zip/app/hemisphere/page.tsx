import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { HemisphereDashboardClient } from "@/components/hemisphere-dashboard"

export default async function HemispherePage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Fetch hemisphere profile
  const { data: hemisphereProfile } = await supabase
    .from("hemisphere_profiles")
    .select("*")
    .eq("user_id", user.id)
    .maybeSingle()

  // Fetch hemisphere history (last 30 entries)
  const { data: hemisphereHistory } = await supabase
    .from("hemisphere_history")
    .select("*")
    .eq("user_id", user.id)
    .order("computed_at", { ascending: false })
    .limit(30)

  // Fetch recent telemetry events
  const { data: telemetryEvents } = await supabase
    .from("wc_telemetry_events")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })
    .limit(50)

  // Fetch role data
  const { data: roleData } = await supabase.from("wc_user_roles").select("*").eq("user_id", user.id).maybeSingle()

  return (
    <HemisphereDashboardClient
      userId={user.id}
      hemisphereProfile={hemisphereProfile}
      hemisphereHistory={hemisphereHistory || []}
      telemetryEvents={telemetryEvents || []}
      roleData={roleData}
    />
  )
}
