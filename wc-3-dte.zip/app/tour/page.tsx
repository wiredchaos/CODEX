"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  Brain,
  ChevronRight,
  ChevronLeft,
  Sparkles,
  Check,
  Eye,
  BookOpen,
  Gamepad2,
  Rocket,
  Search,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

const COLORS = {
  primary: "#00FFF7",
  secondary: "#FF6B35",
  accent: "#A020F0",
  dark: "#000000",
  glow: "rgba(0, 255, 247, 0.5)",
}

const STEPS = [
  {
    id: "goals",
    title: "What brings you here?",
    subtitle: "Select all that apply",
    multiSelect: true,
    options: [
      { id: "learn", label: "Learn", description: "Explore tutorials and courses", icon: BookOpen, color: "#00FF88" },
      { id: "build", label: "Build", description: "Create content and scenes", icon: Rocket, color: "#FFD700" },
      { id: "watch", label: "Watch", description: "Stream shows and films", icon: Eye, color: "#FF1744" },
      { id: "play", label: "Play", description: "Interactive games and training", icon: Gamepad2, color: "#00BFFF" },
      { id: "deploy", label: "Deploy", description: "Launch projects to production", icon: Sparkles, color: "#A020F0" },
      { id: "research", label: "Research", description: "Explore the Akashic realms", icon: Search, color: "#FF6B35" },
    ],
  },
  {
    id: "experience",
    title: "What's your experience level?",
    subtitle: "This helps us tailor your journey",
    multiSelect: false,
    options: [
      { id: "beginner", label: "Beginner", description: "New to Web3 and AI tools", color: "#00FF88" },
      { id: "intermediate", label: "Intermediate", description: "Some experience with tech", color: "#FFD700" },
      { id: "advanced", label: "Advanced", description: "Power user / developer", color: "#FF1744" },
    ],
  },
  {
    id: "tourStyle",
    title: "How would you like to explore?",
    subtitle: "Choose your preferred experience",
    multiSelect: false,
    options: [
      { id: "visual", label: "Visual Tour", description: "Guided walkthrough with animations", color: "#00BFFF" },
      { id: "quick", label: "Quick Menu", description: "Jump straight to the elevator", color: "#FFD700" },
      { id: "assisted", label: "Assisted Build", description: "NEURO guides you step by step", color: "#A020F0" },
    ],
  },
  {
    id: "akashic",
    title: "Content Preferences",
    subtitle: "The Akashic realm contains esoteric content",
    multiSelect: false,
    options: [
      { id: "business", label: "Business Only", description: "Focused, professional content", color: "#00FF88" },
      { id: "include", label: "Include Akashic", description: "Explore all realms and mysteries", color: "#A020F0" },
    ],
  },
]

export default function TourPage() {
  const router = useRouter()
  const [currentStep, setCurrentStep] = useState(0)
  const [selections, setSelections] = useState<Record<string, string[]>>({
    goals: [],
    experience: [],
    tourStyle: [],
    akashic: [],
  })

  const step = STEPS[currentStep]
  const isLastStep = currentStep === STEPS.length - 1
  const canProceed = selections[step.id].length > 0

  const handleSelect = (optionId: string) => {
    setSelections((prev) => {
      const current = prev[step.id]
      if (step.multiSelect) {
        return {
          ...prev,
          [step.id]: current.includes(optionId) ? current.filter((id) => id !== optionId) : [...current, optionId],
        }
      }
      return { ...prev, [step.id]: [optionId] }
    })
  }

  const handleNext = () => {
    if (isLastStep) {
      // Generate tour plan and redirect
      const tourStyle = selections.tourStyle[0]
      if (tourStyle === "quick") {
        router.push("/lobby")
      } else {
        router.push("/lobby?tour=true")
      }
    } else {
      setCurrentStep((prev) => prev + 1)
    }
  }

  const handleBack = () => {
    setCurrentStep((prev) => Math.max(0, prev - 1))
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: COLORS.dark }}>
      {/* Animated Background */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `radial-gradient(circle at 30% 20%, ${COLORS.primary}40 0%, transparent 50%),
                              radial-gradient(circle at 70% 80%, ${COLORS.secondary}40 0%, transparent 50%)`,
          }}
        />
        {/* Floating NPC logos */}
        {[...Array(5)].map((_, i) => (
          <div
            key={i}
            className="absolute opacity-10 animate-float"
            style={{
              left: `${20 + i * 15}%`,
              top: `${10 + (i % 3) * 30}%`,
              animationDelay: `${i * 0.5}s`,
              animationDuration: `${4 + i}s`,
            }}
          >
            <Brain className="w-12 h-12" style={{ color: COLORS.primary }} />
          </div>
        ))}
      </div>

      {/* Header */}
      <header className="relative z-10 p-6">
        <div className="flex items-center justify-center gap-3">
          <Brain className="w-8 h-8" style={{ color: COLORS.primary }} />
          <h1
            className="text-2xl font-bold uppercase tracking-wider"
            style={{
              color: COLORS.primary,
              textShadow: `0 0 20px ${COLORS.glow}`,
            }}
          >
            NEURO
          </h1>
        </div>
      </header>

      {/* Progress Bar */}
      <div className="relative z-10 px-6 py-4">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center gap-2">
            {STEPS.map((s, i) => (
              <div key={s.id} className="flex-1 flex items-center">
                <div
                  className="h-1.5 flex-1 rounded-full transition-all duration-500"
                  style={{
                    background: i <= currentStep ? COLORS.primary : "rgba(255,255,255,0.1)",
                    boxShadow: i <= currentStep ? `0 0 10px ${COLORS.primary}` : "none",
                  }}
                />
                {i < STEPS.length - 1 && <div className="w-2" />}
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-2">
            <span className="text-xs text-neutral-500">
              Step {currentStep + 1} of {STEPS.length}
            </span>
            <span className="text-xs" style={{ color: COLORS.primary }}>
              {step.id.toUpperCase()}
            </span>
          </div>
        </div>
      </div>

      {/* Content */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center px-6 py-8">
        <div className="w-full max-w-3xl">
          <div className="text-center mb-8">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-2">{step.title}</h2>
            <p className="text-neutral-400">{step.subtitle}</p>
          </div>

          <div
            className={cn(
              "grid gap-4",
              step.options.length > 4 ? "grid-cols-2 md:grid-cols-3" : "grid-cols-1 md:grid-cols-3",
            )}
          >
            {step.options.map((option) => {
              const isSelected = selections[step.id].includes(option.id)
              const Icon = "icon" in option ? option.icon : null

              return (
                <button
                  key={option.id}
                  onClick={() => handleSelect(option.id)}
                  className="relative p-6 rounded-xl text-left transition-all duration-300 hover:scale-[1.02] group"
                  style={{
                    background: isSelected ? `${option.color}20` : "rgba(255,255,255,0.03)",
                    border: `2px solid ${isSelected ? option.color : "rgba(255,255,255,0.1)"}`,
                    boxShadow: isSelected ? `0 0 30px ${option.color}30` : "none",
                  }}
                >
                  {isSelected && (
                    <div
                      className="absolute top-3 right-3 w-6 h-6 rounded-full flex items-center justify-center"
                      style={{ background: option.color }}
                    >
                      <Check className="w-4 h-4 text-black" />
                    </div>
                  )}

                  {Icon && (
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                      style={{ background: `${option.color}20` }}
                    >
                      <Icon className="w-6 h-6" style={{ color: option.color }} />
                    </div>
                  )}

                  <h3 className="text-lg font-semibold text-white mb-1">{option.label}</h3>
                  <p className="text-sm text-neutral-400">{option.description}</p>
                </button>
              )
            })}
          </div>
        </div>
      </main>

      {/* Footer Navigation */}
      <footer className="relative z-10 p-6">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <Button
            variant="ghost"
            onClick={handleBack}
            disabled={currentStep === 0}
            className="gap-2 text-neutral-400 hover:text-white disabled:opacity-30"
          >
            <ChevronLeft className="w-4 h-4" />
            Back
          </Button>

          <Button
            onClick={handleNext}
            disabled={!canProceed}
            className="gap-2 disabled:opacity-30"
            style={{
              background: canProceed ? COLORS.primary : "rgba(255,255,255,0.1)",
              color: canProceed ? "#000" : "#666",
            }}
          >
            {isLastStep ? "Start Your Journey" : "Continue"}
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </footer>

      <style jsx>{`
        @keyframes float {
          0%,
          100% {
            transform: translateY(0) rotate(0deg);
          }
          50% {
            transform: translateY(-20px) rotate(5deg);
          }
        }
        .animate-float {
          animation: float 6s ease-in-out infinite;
        }
      `}</style>
    </div>
  )
}
