"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Brain, Cpu, Zap, Terminal, Users, Activity, Store, LayoutDashboard, ChevronRight } from "lucide-react"
import { LiveCircuitry } from "@/components/live-circuitry"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

const NPC_COLORS = {
  primary: "#00FFF7",
  secondary: "#A020F0",
  accent: "#00FF88",
  dark: "#000000",
  glow: "rgba(0, 255, 247, 0.5)",
}

const AGENTS = [
  {
    id: "pm-lead",
    name: "PM LEAD",
    role: "Project Orchestrator",
    icon: Users,
    color: "#FFD700",
    status: "active",
    tasks: 12,
    description: "Coordinates all agent activities and project workflows",
  },
  {
    id: "asset-ingestor",
    name: "ASSET INGESTOR",
    icon: Cpu,
    role: "Data Pipeline",
    color: "#00FFF7",
    status: "active",
    tasks: 45,
    description: "Processes and ingests assets into the TFS library",
  },
  {
    id: "tagger",
    name: "TAGGER",
    icon: Activity,
    role: "Metadata Engine",
    color: "#00FF88",
    status: "idle",
    tasks: 0,
    description: "Auto-tags assets with AI-powered classification",
  },
  {
    id: "scene-compiler",
    name: "SCENE COMPILER",
    icon: Zap,
    role: "TFS Builder",
    color: "#FF6B35",
    status: "active",
    tasks: 8,
    description: "Compiles 3D scenes from prompts using TFS engine",
  },
  {
    id: "billing-agent",
    name: "BILLING AGENT",
    icon: Terminal,
    role: "Credits Manager",
    color: "#A020F0",
    status: "active",
    tasks: 3,
    description: "Tracks credit usage and manages billing cycles",
  },
  {
    id: "akashic-aide",
    name: "AKASHIC AIDE",
    icon: Brain,
    role: "Knowledge Guide",
    color: "#FF1A1A",
    status: "idle",
    tasks: 0,
    description: "Guides users through the Akashic realm mysteries",
  },
]

const QUICK_COMMANDS = [
  { label: "Compile Scene", command: "/compile" },
  { label: "Ingest Assets", command: "/ingest" },
  { label: "Check Balance", command: "/balance" },
  { label: "Run Pipeline", command: "/pipeline" },
  { label: "Tag Assets", command: "/tag" },
  { label: "Status Report", command: "/status" },
]

export default function NPCPage() {
  const router = useRouter()
  const [selectedAgent, setSelectedAgent] = useState<string | null>(null)
  const [terminalInput, setTerminalInput] = useState("")
  const [terminalHistory, setTerminalHistory] = useState<string[]>([
    "[NEURO] NPC System initialized",
    "[NEURO] 6 agents online",
    "[NEURO] Ready for commands...",
  ])

  const executeCommand = (cmd: string) => {
    const command = cmd.trim()
    if (!command) return

    setTerminalHistory((prev) => [...prev, `> ${command}`])

    setTimeout(() => {
      let response = ""
      if (command.startsWith("/compile")) {
        response = "[SCENE COMPILER] Initializing TFS compilation..."
      } else if (command.startsWith("/ingest")) {
        response = "[ASSET INGESTOR] Starting asset pipeline..."
      } else if (command.startsWith("/balance")) {
        response = "[BILLING AGENT] Current balance: 1,250 credits"
      } else if (command.startsWith("/status")) {
        response = "[PM LEAD] All systems operational. 4 agents active."
      } else {
        response = `[NEURO] Unknown command: ${command}`
      }
      setTerminalHistory((prev) => [...prev, response])
    }, 500)

    setTerminalInput("")
  }

  return (
    <div className="min-h-screen relative" style={{ backgroundColor: NPC_COLORS.dark }}>
      <LiveCircuitry />

      {/* Grid Background */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, ${NPC_COLORS.primary}15 1px, transparent 1px),
            linear-gradient(to bottom, ${NPC_COLORS.primary}15 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Header */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(0, 0, 0, 0.9)",
          borderColor: `${NPC_COLORS.primary}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => router.push("/")}
                className="flex items-center gap-2 transition-colors hover:opacity-80"
                style={{ color: NPC_COLORS.primary }}
              >
                <Brain className="w-6 h-6" />
                <h1
                  className="font-display text-2xl uppercase tracking-wider"
                  style={{
                    color: NPC_COLORS.primary,
                    textShadow: `0 0 20px ${NPC_COLORS.glow}`,
                  }}
                >
                  NPC
                </h1>
              </button>
              <Badge
                className="text-xs uppercase"
                style={{
                  background: `${NPC_COLORS.primary}20`,
                  color: NPC_COLORS.primary,
                  border: `1px solid ${NPC_COLORS.primary}40`,
                }}
              >
                NEURO PROMPT COMMAND
              </Badge>
            </div>

            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                className="gap-2 bg-transparent hidden sm:flex"
                style={{ borderColor: `${NPC_COLORS.accent}40`, color: NPC_COLORS.accent }}
                onClick={() => router.push("/npc/marketplace")}
              >
                <Store className="w-4 h-4" />
                Marketplace
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="gap-2 bg-transparent hidden sm:flex"
                style={{ borderColor: `${NPC_COLORS.primary}40`, color: NPC_COLORS.primary }}
                onClick={() => router.push("/npc/console")}
              >
                <LayoutDashboard className="w-4 h-4" />
                Job Console
              </Button>
              <div className="text-xs font-mono text-neutral-500">
                <span style={{ color: NPC_COLORS.accent }}>1,250</span> credits
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          <button
            onClick={() => router.push("/npc/marketplace")}
            className="p-6 rounded-xl text-left transition-all hover:scale-[1.02] group"
            style={{
              background: `linear-gradient(135deg, ${NPC_COLORS.accent}15, transparent)`,
              border: `1px solid ${NPC_COLORS.accent}30`,
            }}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center"
                  style={{ background: `${NPC_COLORS.accent}20` }}
                >
                  <Store className="w-6 h-6" style={{ color: NPC_COLORS.accent }} />
                </div>
                <div>
                  <h3 className="text-white font-semibold">Agent Marketplace</h3>
                  <p className="text-sm text-neutral-400">Browse and purchase AI agents</p>
                </div>
              </div>
              <ChevronRight
                className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-opacity"
                style={{ color: NPC_COLORS.accent }}
              />
            </div>
          </button>

          <button
            onClick={() => router.push("/npc/console")}
            className="p-6 rounded-xl text-left transition-all hover:scale-[1.02] group"
            style={{
              background: `linear-gradient(135deg, ${NPC_COLORS.primary}15, transparent)`,
              border: `1px solid ${NPC_COLORS.primary}30`,
            }}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center"
                  style={{ background: `${NPC_COLORS.primary}20` }}
                >
                  <LayoutDashboard className="w-6 h-6" style={{ color: NPC_COLORS.primary }} />
                </div>
                <div>
                  <h3 className="text-white font-semibold">Job Console</h3>
                  <p className="text-sm text-neutral-400">Monitor and manage agent jobs</p>
                </div>
              </div>
              <ChevronRight
                className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-opacity"
                style={{ color: NPC_COLORS.primary }}
              />
            </div>
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Agents Grid */}
          <div className="lg:col-span-2">
            <h2 className="font-mono text-sm uppercase tracking-wider mb-4" style={{ color: NPC_COLORS.primary }}>
              Agent Staff
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {AGENTS.map((agent) => {
                const Icon = agent.icon
                const isSelected = selectedAgent === agent.id

                return (
                  <button
                    key={agent.id}
                    onClick={() => setSelectedAgent(isSelected ? null : agent.id)}
                    className="p-4 rounded-xl text-left transition-all hover:scale-[1.02]"
                    style={{
                      background: isSelected ? `${agent.color}15` : "rgba(0, 0, 0, 0.6)",
                      border: `1px solid ${isSelected ? agent.color : "rgba(255,255,255,0.1)"}`,
                      boxShadow: isSelected ? `0 0 20px ${agent.color}30` : "none",
                    }}
                  >
                    <div className="flex items-start gap-3">
                      <div
                        className="w-10 h-10 rounded-lg flex items-center justify-center"
                        style={{ background: `${agent.color}20` }}
                      >
                        <Icon className="w-5 h-5" style={{ color: agent.color }} />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <h3 className="font-mono text-sm" style={{ color: agent.color }}>
                            {agent.name}
                          </h3>
                          <div
                            className={`w-2 h-2 rounded-full ${agent.status === "active" ? "animate-pulse" : ""}`}
                            style={{
                              background: agent.status === "active" ? "#00FF88" : "#666",
                            }}
                          />
                        </div>
                        <p className="text-xs text-neutral-500 mb-2">{agent.role}</p>
                        <p className="text-xs text-neutral-400 line-clamp-2">{agent.description}</p>
                        {agent.tasks > 0 && (
                          <div className="mt-2 text-xs font-mono" style={{ color: agent.color }}>
                            {agent.tasks} active tasks
                          </div>
                        )}
                      </div>
                    </div>
                  </button>
                )
              })}
            </div>
          </div>

          {/* Terminal */}
          <div className="lg:col-span-1">
            <h2 className="font-mono text-sm uppercase tracking-wider mb-4" style={{ color: NPC_COLORS.primary }}>
              Command Terminal
            </h2>
            <div
              className="rounded-xl overflow-hidden"
              style={{
                background: "rgba(0, 0, 0, 0.8)",
                border: `1px solid ${NPC_COLORS.primary}30`,
              }}
            >
              <div
                className="px-4 py-2 border-b flex items-center justify-between"
                style={{ borderColor: `${NPC_COLORS.primary}30` }}
              >
                <div className="flex items-center gap-2">
                  <Terminal className="w-4 h-4" style={{ color: NPC_COLORS.primary }} />
                  <span className="font-mono text-xs" style={{ color: NPC_COLORS.primary }}>
                    NEURO TERMINAL
                  </span>
                </div>
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-500" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500" />
                  <div className="w-3 h-3 rounded-full bg-green-500" />
                </div>
              </div>

              <div className="h-64 overflow-y-auto p-4 font-mono text-xs">
                {terminalHistory.map((line, i) => (
                  <div
                    key={i}
                    className="mb-1"
                    style={{
                      color: line.startsWith(">") ? NPC_COLORS.primary : "#888",
                    }}
                  >
                    {line}
                  </div>
                ))}
              </div>

              <div
                className="px-4 py-3 border-t flex items-center gap-2"
                style={{ borderColor: `${NPC_COLORS.primary}30` }}
              >
                <span style={{ color: NPC_COLORS.primary }}>{">"}</span>
                <input
                  type="text"
                  value={terminalInput}
                  onChange={(e) => setTerminalInput(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && executeCommand(terminalInput)}
                  placeholder="Enter command..."
                  className="flex-1 bg-transparent border-none outline-none font-mono text-xs text-white placeholder-neutral-600"
                />
              </div>
            </div>

            <div className="mt-4">
              <h3 className="font-mono text-xs text-neutral-500 uppercase mb-2">Quick Commands</h3>
              <div className="grid grid-cols-2 gap-2">
                {QUICK_COMMANDS.map((cmd) => (
                  <button
                    key={cmd.command}
                    onClick={() => executeCommand(cmd.command)}
                    className="px-3 py-2 rounded-lg font-mono text-xs text-left transition-all hover:scale-[1.02]"
                    style={{
                      background: "rgba(0, 0, 0, 0.4)",
                      border: `1px solid ${NPC_COLORS.primary}20`,
                      color: NPC_COLORS.primary,
                    }}
                  >
                    {cmd.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
