"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  ArrowLeft,
  Brain,
  Play,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Clock,
  ChevronRight,
  Loader2,
  AlertTriangle,
  Sparkles,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"

const NPC_COLORS = {
  primary: "#00FFF7",
  secondary: "#A020F0",
  accent: "#00FF88",
  gold: "#FFD700",
  dark: "#000000",
}

type JobStatus = "queued" | "running" | "succeeded" | "failed" | "canceled"

interface Job {
  id: string
  kind: string
  status: JobStatus
  patchName: string
  intent: string
  createdAt: string
  startedAt?: string
  finishedAt?: string
  feeAmount: number
  events: { ts: string; level: string; message: string }[]
  plan?: { step: number; action: string; status: string }[]
}

const MOCK_JOBS: Job[] = [
  {
    id: "job-001",
    kind: "SEEKER_FORENSICS_SCAN",
    status: "succeeded",
    patchName: "creator-codex",
    intent: "Scan and index all Creator Codex documentation",
    createdAt: "2025-12-15T02:30:00Z",
    startedAt: "2025-12-15T02:30:05Z",
    finishedAt: "2025-12-15T02:35:22Z",
    feeAmount: 125,
    events: [
      { ts: "02:30:05", level: "info", message: "Job started" },
      { ts: "02:31:12", level: "info", message: "Scanning 47 files..." },
      { ts: "02:33:45", level: "info", message: "Indexing chunks..." },
      { ts: "02:35:22", level: "info", message: "Job completed successfully" },
    ],
    plan: [
      { step: 1, action: "github.list_files", status: "done" },
      { step: 2, action: "text.chunk_documents", status: "done" },
      { step: 3, action: "text.index_chunks", status: "done" },
      { step: 4, action: "findings.generate", status: "done" },
    ],
  },
  {
    id: "job-002",
    kind: "SEEKER_UPGRADE_PLAN",
    status: "running",
    patchName: "789-studios",
    intent: "Generate upgrade plan for OTT streaming module",
    createdAt: "2025-12-15T03:00:00Z",
    startedAt: "2025-12-15T03:00:08Z",
    feeAmount: 200,
    events: [
      { ts: "03:00:08", level: "info", message: "Job started" },
      { ts: "03:01:15", level: "info", message: "Analyzing current architecture..." },
      { ts: "03:02:30", level: "warn", message: "Missing video player component detected" },
    ],
    plan: [
      { step: 1, action: "forensics.analyze_patch", status: "done" },
      { step: 2, action: "gaps.identify_missing", status: "running" },
      { step: 3, action: "plan.generate_upgrade", status: "pending" },
      { step: 4, action: "report.output", status: "pending" },
    ],
  },
  {
    id: "job-003",
    kind: "SEEKER_PATCH_RECONSTRUCT",
    status: "failed",
    patchName: "akira-codex",
    intent: "Reconstruct Akira Codex realm structure",
    createdAt: "2025-12-15T01:15:00Z",
    startedAt: "2025-12-15T01:15:03Z",
    finishedAt: "2025-12-15T01:16:45Z",
    feeAmount: 0,
    events: [
      { ts: "01:15:03", level: "info", message: "Job started" },
      { ts: "01:15:30", level: "error", message: "Akashic realm access denied - agent not Akashic-enabled" },
      { ts: "01:16:45", level: "error", message: "Job failed: AKASHIC_ACCESS_DENIED" },
    ],
    plan: [{ step: 1, action: "realm.validate_access", status: "failed" }],
  },
  {
    id: "job-004",
    kind: "SEEKER_MISSING_DOCS_REPORT",
    status: "queued",
    patchName: "npc-engine",
    intent: "Generate missing documentation report",
    createdAt: "2025-12-15T03:10:00Z",
    feeAmount: 50,
    events: [],
    plan: [],
  },
]

const STATUS_STYLES: Record<JobStatus, { bg: string; text: string; icon: typeof CheckCircle2 }> = {
  queued: { bg: "rgba(255,255,255,0.1)", text: "#888", icon: Clock },
  running: { bg: "rgba(0,191,255,0.2)", text: "#00BFFF", icon: Loader2 },
  succeeded: { bg: "rgba(0,255,136,0.2)", text: "#00FF88", icon: CheckCircle2 },
  failed: { bg: "rgba(255,26,26,0.2)", text: "#FF1A1A", icon: XCircle },
  canceled: { bg: "rgba(255,165,0,0.2)", text: "#FFA500", icon: AlertTriangle },
}

export default function NPCConsolePage() {
  const router = useRouter()
  const [jobs, setJobs] = useState<Job[]>(MOCK_JOBS)
  const [selectedJob, setSelectedJob] = useState<Job | null>(null)
  const [newIntent, setNewIntent] = useState("")
  const [newPatch, setNewPatch] = useState("creator-codex")

  const submitJob = () => {
    if (!newIntent.trim()) return

    const newJob: Job = {
      id: `job-${Date.now()}`,
      kind: "SEEKER_FORENSICS_SCAN",
      status: "queued",
      patchName: newPatch,
      intent: newIntent,
      createdAt: new Date().toISOString(),
      feeAmount: 100,
      events: [],
      plan: [],
    }

    setJobs([newJob, ...jobs])
    setNewIntent("")
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: NPC_COLORS.dark }}>
      {/* Header */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(0, 0, 0, 0.9)",
          borderColor: `${NPC_COLORS.primary}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => router.push("/npc")}
                className="flex items-center gap-2 transition-colors hover:opacity-80"
                style={{ color: NPC_COLORS.primary }}
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-2">
                <Brain className="w-6 h-6" style={{ color: NPC_COLORS.primary }} />
                <h1 className="font-display text-xl uppercase tracking-wider" style={{ color: NPC_COLORS.primary }}>
                  Job Console
                </h1>
              </div>
            </div>

            <div className="flex items-center gap-2 text-sm">
              <span className="text-neutral-500">Balance:</span>
              <span className="font-mono" style={{ color: NPC_COLORS.gold }}>
                1,250 credits
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* New Job Form */}
        <Card
          className="mb-8"
          style={{
            background: "rgba(0, 0, 0, 0.6)",
            border: `1px solid ${NPC_COLORS.primary}30`,
          }}
        >
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5" style={{ color: NPC_COLORS.primary }} />
              Submit New Job
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-4">
              <select
                value={newPatch}
                onChange={(e) => setNewPatch(e.target.value)}
                className="px-3 py-2 rounded-lg bg-black/50 border text-white text-sm"
                style={{ borderColor: `${NPC_COLORS.primary}30` }}
              >
                <option value="creator-codex">Creator Codex</option>
                <option value="789-studios">789 Studios</option>
                <option value="npc-engine">NPC Engine</option>
                <option value="33-3fm">33.3FM</option>
                <option value="akira-codex">Akira Codex (Akashic)</option>
              </select>
              <Input
                placeholder="Describe what you want the agents to do..."
                value={newIntent}
                onChange={(e) => setNewIntent(e.target.value)}
                className="flex-1 bg-black/50 border-white/10 text-white"
                onKeyPress={(e) => e.key === "Enter" && submitJob()}
              />
              <Button
                onClick={submitJob}
                className="gap-2"
                style={{ backgroundColor: NPC_COLORS.primary, color: "#000" }}
              >
                <Play className="w-4 h-4" />
                Run Job
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Jobs List */}
          <div className="lg:col-span-2 space-y-4">
            <h2 className="font-mono text-sm uppercase tracking-wider mb-4" style={{ color: NPC_COLORS.primary }}>
              Recent Jobs
            </h2>

            {jobs.map((job) => {
              const statusStyle = STATUS_STYLES[job.status]
              const StatusIcon = statusStyle.icon

              return (
                <Card
                  key={job.id}
                  className="cursor-pointer transition-all hover:scale-[1.01]"
                  style={{
                    background: selectedJob?.id === job.id ? "rgba(0,255,247,0.05)" : "rgba(0, 0, 0, 0.6)",
                    border: `1px solid ${selectedJob?.id === job.id ? NPC_COLORS.primary : "rgba(255,255,255,0.1)"}`,
                  }}
                  onClick={() => setSelectedJob(job)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge className="text-xs" style={{ background: statusStyle.bg, color: statusStyle.text }}>
                            <StatusIcon className={`w-3 h-3 mr-1 ${job.status === "running" ? "animate-spin" : ""}`} />
                            {job.status}
                          </Badge>
                          <Badge variant="outline" className="text-xs text-neutral-400 border-neutral-700">
                            {job.kind}
                          </Badge>
                        </div>
                        <p className="text-white text-sm mb-1">{job.intent}</p>
                        <p className="text-xs text-neutral-500">
                          Patch: {job.patchName} | Created: {new Date(job.createdAt).toLocaleTimeString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-mono text-sm" style={{ color: NPC_COLORS.gold }}>
                          {job.feeAmount} credits
                        </p>
                        <ChevronRight className="w-4 h-4 text-neutral-500 mt-2 ml-auto" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {/* Job Detail */}
          <div>
            <h2 className="font-mono text-sm uppercase tracking-wider mb-4" style={{ color: NPC_COLORS.primary }}>
              Job Detail
            </h2>

            {selectedJob ? (
              <Card
                style={{
                  background: "rgba(0, 0, 0, 0.6)",
                  border: `1px solid ${NPC_COLORS.primary}30`,
                }}
              >
                <CardContent className="p-4 space-y-4">
                  {/* Plan Steps */}
                  {selectedJob.plan && selectedJob.plan.length > 0 && (
                    <div>
                      <h3 className="font-mono text-xs uppercase text-neutral-500 mb-2">Execution Plan</h3>
                      <div className="space-y-2">
                        {selectedJob.plan.map((step) => (
                          <div key={step.step} className="flex items-center gap-2 text-sm">
                            {step.status === "done" ? (
                              <CheckCircle2 className="w-4 h-4 text-green-500" />
                            ) : step.status === "running" ? (
                              <Loader2 className="w-4 h-4 text-blue-500 animate-spin" />
                            ) : step.status === "failed" ? (
                              <XCircle className="w-4 h-4 text-red-500" />
                            ) : (
                              <Clock className="w-4 h-4 text-neutral-500" />
                            )}
                            <span className="text-neutral-400 font-mono">{step.action}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Event Log */}
                  <div>
                    <h3 className="font-mono text-xs uppercase text-neutral-500 mb-2">Event Log</h3>
                    <div
                      className="max-h-48 overflow-y-auto space-y-1 p-2 rounded"
                      style={{ background: "rgba(0,0,0,0.5)" }}
                    >
                      {selectedJob.events.length > 0 ? (
                        selectedJob.events.map((event, i) => (
                          <div key={i} className="flex gap-2 text-xs font-mono">
                            <span className="text-neutral-500">[{event.ts}]</span>
                            <span
                              style={{
                                color:
                                  event.level === "error" ? "#FF1A1A" : event.level === "warn" ? "#FFA500" : "#888",
                              }}
                            >
                              {event.message}
                            </span>
                          </div>
                        ))
                      ) : (
                        <p className="text-neutral-500 text-xs">No events yet...</p>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  {selectedJob.status === "failed" && (
                    <Button
                      variant="outline"
                      className="w-full gap-2 bg-transparent"
                      style={{ borderColor: NPC_COLORS.primary, color: NPC_COLORS.primary }}
                    >
                      <RotateCcw className="w-4 h-4" />
                      Retry Job
                    </Button>
                  )}
                </CardContent>
              </Card>
            ) : (
              <Card
                style={{
                  background: "rgba(0, 0, 0, 0.6)",
                  border: "1px solid rgba(255,255,255,0.1)",
                }}
              >
                <CardContent className="p-8 text-center text-neutral-500">Select a job to view details</CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
