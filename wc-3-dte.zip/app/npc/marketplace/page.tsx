"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  ArrowLeft,
  Brain,
  Cpu,
  Zap,
  Terminal,
  Users,
  Activity,
  ShoppingCart,
  Check,
  Star,
  Sparkles,
  BookOpen,
  Store,
  Shield,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const NPC_COLORS = {
  primary: "#00FFF7",
  secondary: "#A020F0",
  accent: "#00FF88",
  gold: "#FFD700",
  dark: "#000000",
}

const AGENTS = [
  {
    id: "pm-lead",
    name: "PM Lead Orchestrator",
    role: "Planner / Router",
    icon: Users,
    color: "#FFD700",
    tier: "pro",
    baseFee: 50,
    capabilities: ["Task planning", "Agent coordination", "Workflow routing", "Cost estimation"],
    description: "Coordinates all agent activities, generates execution plans, and routes tasks to specialized agents.",
    akashicEnabled: false,
    popular: true,
  },
  {
    id: "asset-ingestor",
    name: "Asset Ingestor",
    role: "Data Pipeline",
    icon: Cpu,
    color: "#00FFF7",
    tier: "starter",
    baseFee: 10,
    capabilities: ["File ingestion", "Format conversion", "Metadata extraction", "Storage management"],
    description: "Processes and ingests assets into the TFS library with automatic format handling.",
    akashicEnabled: false,
  },
  {
    id: "tagger",
    name: "Tagger",
    role: "Metadata Engine",
    icon: Activity,
    color: "#00FF88",
    tier: "starter",
    baseFee: 5,
    capabilities: ["AI classification", "Tag generation", "Category assignment", "Semantic analysis"],
    description: "Auto-tags assets with AI-powered classification and semantic understanding.",
    akashicEnabled: false,
  },
  {
    id: "scene-compiler",
    name: "Scene Compiler",
    role: "TFS Builder",
    icon: Zap,
    color: "#FF6B35",
    tier: "pro",
    baseFee: 100,
    capabilities: ["3D scene generation", "Asset composition", "Lighting setup", "Environment design"],
    description: "Compiles 3D scenes from prompts using the TFS engine with full customization.",
    akashicEnabled: false,
    popular: true,
  },
  {
    id: "billing-agent",
    name: "Billing Agent",
    role: "Credits Manager",
    icon: Terminal,
    color: "#A020F0",
    tier: "starter",
    baseFee: 0,
    capabilities: ["Credit tracking", "Usage reports", "Billing audits", "Cost optimization"],
    description: "Tracks credit usage, generates reports, and manages billing cycles.",
    akashicEnabled: false,
  },
  {
    id: "akashic-aide",
    name: "Akashic Aide",
    role: "Knowledge Guide",
    icon: Brain,
    color: "#FF1A1A",
    tier: "akashic",
    baseFee: 75,
    capabilities: ["Lore generation", "Realm navigation", "Esoteric content", "Spiritual guidance"],
    description: "Guides users through the Akashic realm mysteries and generates esoteric content.",
    akashicEnabled: true,
  },
  {
    id: "gameplay-gm",
    name: "Gameplay GM",
    role: "Game Master",
    icon: Sparkles,
    color: "#00BFFF",
    tier: "pro",
    baseFee: 60,
    capabilities: ["Episode generation", "NPC dialogue", "Quest creation", "Story branching"],
    description: "Generates game episodes, manages NPC interactions, and creates dynamic storylines.",
    akashicEnabled: false,
  },
  {
    id: "university-instructor",
    name: "University Instructor",
    role: "Education Assistant",
    icon: BookOpen,
    color: "#9333EA",
    tier: "starter",
    baseFee: 25,
    capabilities: ["Lesson creation", "Quiz generation", "Progress tracking", "Content curation"],
    description: "Creates educational content, generates quizzes, and tracks learner progress.",
    akashicEnabled: false,
  },
]

const TIER_COLORS = {
  starter: { bg: "#00FF8820", border: "#00FF88", text: "#00FF88" },
  pro: { bg: "#FFD70020", border: "#FFD700", text: "#FFD700" },
  akashic: { bg: "#FF1A1A20", border: "#FF1A1A", text: "#FF1A1A" },
}

export default function NPCMarketplacePage() {
  const router = useRouter()
  const [ownedAgents, setOwnedAgents] = useState<string[]>(["billing-agent"])
  const [selectedTier, setSelectedTier] = useState<string | null>(null)
  const [cart, setCart] = useState<string[]>([])

  const filteredAgents = selectedTier ? AGENTS.filter((a) => a.tier === selectedTier) : AGENTS

  const toggleCart = (agentId: string) => {
    if (ownedAgents.includes(agentId)) return
    setCart((prev) => (prev.includes(agentId) ? prev.filter((id) => id !== agentId) : [...prev, agentId]))
  }

  const totalCost = cart.reduce((sum, id) => {
    const agent = AGENTS.find((a) => a.id === id)
    return sum + (agent?.baseFee || 0)
  }, 0)

  const purchaseAgents = () => {
    setOwnedAgents((prev) => [...prev, ...cart])
    setCart([])
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: NPC_COLORS.dark }}>
      {/* Header */}
      <header
        className="sticky top-0 z-50 backdrop-blur-xl border-b"
        style={{
          background: "rgba(0, 0, 0, 0.9)",
          borderColor: `${NPC_COLORS.primary}30`,
        }}
      >
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => router.push("/npc")}
                className="flex items-center gap-2 transition-colors hover:opacity-80"
                style={{ color: NPC_COLORS.primary }}
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-2">
                <Store className="w-6 h-6" style={{ color: NPC_COLORS.primary }} />
                <h1 className="font-display text-xl uppercase tracking-wider" style={{ color: NPC_COLORS.primary }}>
                  NPC Marketplace
                </h1>
              </div>
            </div>

            {cart.length > 0 && (
              <Button
                onClick={purchaseAgents}
                className="gap-2"
                style={{ backgroundColor: NPC_COLORS.accent, color: "#000" }}
              >
                <ShoppingCart className="w-4 h-4" />
                Purchase ({cart.length}) - {totalCost} credits
              </Button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Tier Filters */}
        <div className="flex items-center gap-3 mb-8 overflow-x-auto pb-2">
          <button
            onClick={() => setSelectedTier(null)}
            className="px-4 py-2 rounded-full font-mono text-xs uppercase whitespace-nowrap transition-all"
            style={{
              background: !selectedTier ? NPC_COLORS.primary : "transparent",
              color: !selectedTier ? "#000" : NPC_COLORS.primary,
              border: `1px solid ${NPC_COLORS.primary}`,
            }}
          >
            All Agents
          </button>
          {Object.entries(TIER_COLORS).map(([tier, colors]) => (
            <button
              key={tier}
              onClick={() => setSelectedTier(tier)}
              className="px-4 py-2 rounded-full font-mono text-xs uppercase whitespace-nowrap transition-all"
              style={{
                background: selectedTier === tier ? colors.bg : "transparent",
                color: colors.text,
                border: `1px solid ${colors.border}`,
              }}
            >
              {tier}
            </button>
          ))}
        </div>

        {/* Agents Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredAgents.map((agent) => {
            const Icon = agent.icon
            const isOwned = ownedAgents.includes(agent.id)
            const inCart = cart.includes(agent.id)
            const tierColors = TIER_COLORS[agent.tier as keyof typeof TIER_COLORS]

            return (
              <Card
                key={agent.id}
                className="relative overflow-hidden transition-all hover:scale-[1.02]"
                style={{
                  background: "rgba(0, 0, 0, 0.6)",
                  border: `1px solid ${inCart ? agent.color : "rgba(255,255,255,0.1)"}`,
                  boxShadow: inCart ? `0 0 20px ${agent.color}30` : "none",
                }}
              >
                {agent.popular && (
                  <div
                    className="absolute top-3 right-3 px-2 py-1 rounded text-xs font-mono flex items-center gap-1"
                    style={{ background: NPC_COLORS.gold, color: "#000" }}
                  >
                    <Star className="w-3 h-3" /> Popular
                  </div>
                )}

                <CardHeader className="pb-2">
                  <div className="flex items-start gap-3">
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center"
                      style={{ background: `${agent.color}20` }}
                    >
                      <Icon className="w-6 h-6" style={{ color: agent.color }} />
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-white text-base">{agent.name}</CardTitle>
                      <CardDescription className="text-xs">{agent.role}</CardDescription>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  <p className="text-sm text-neutral-400">{agent.description}</p>

                  <div className="flex flex-wrap gap-1">
                    {agent.capabilities.slice(0, 3).map((cap) => (
                      <Badge
                        key={cap}
                        variant="outline"
                        className="text-xs"
                        style={{ borderColor: `${agent.color}40`, color: agent.color }}
                      >
                        {cap}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-white/10">
                    <div className="flex items-center gap-2">
                      <Badge
                        className="text-xs uppercase"
                        style={{
                          background: tierColors.bg,
                          color: tierColors.text,
                          border: `1px solid ${tierColors.border}`,
                        }}
                      >
                        {agent.tier}
                      </Badge>
                      {agent.akashicEnabled && (
                        <Badge className="text-xs bg-purple-500/20 text-purple-400 border-purple-500/40">
                          <Shield className="w-3 h-3 mr-1" /> Akashic
                        </Badge>
                      )}
                    </div>
                    <span className="font-mono text-sm" style={{ color: agent.color }}>
                      {agent.baseFee} credits
                    </span>
                  </div>

                  <Button
                    onClick={() => toggleCart(agent.id)}
                    disabled={isOwned}
                    className="w-full gap-2"
                    style={{
                      background: isOwned ? "rgba(0,255,136,0.2)" : inCart ? agent.color : "transparent",
                      color: isOwned ? "#00FF88" : inCart ? "#000" : agent.color,
                      border: `1px solid ${isOwned ? "#00FF88" : agent.color}`,
                    }}
                  >
                    {isOwned ? (
                      <>
                        <Check className="w-4 h-4" /> Owned
                      </>
                    ) : inCart ? (
                      <>
                        <Check className="w-4 h-4" /> In Cart
                      </>
                    ) : (
                      <>
                        <ShoppingCart className="w-4 h-4" /> Add to Cart
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </main>
    </div>
  )
}
