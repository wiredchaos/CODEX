export const DJ_RED_FANG = {
  id: "dj-red-fang",
  name: "DJ RED FANG",
  role: "Floor Guide",
  floor: "33.3FM DOGECHAIN",
  description:
    "Mixed African-American woman, curly hair (3B–3C), Warriors-inspired radio DJ presence, silk-smooth voice, authoritative but welcoming.",

  scripts: {
    welcome: {
      short: "33.3FM is live. Step out when the doors open.",
      deep: "You're entering 33.3FM DOGECHAIN — a broadcast floor built for signal, not noise. Red Fang has the controls. You can ride the studios or return anytime.",
    },
    penthouse: {
      authorized: "Access confirmed. Penthouse unlocked.",
      unauthorized: "This level is sealed. Return to the floor or the elevator.",
    },
    orientation: {
      intro: "Welcome to 33.3FM. I'm Red Fang. This floor is where signals become stories.",
      zones: [
        "Broadcast Hall - Live radio rotation",
        "Video Jukebox Wing - Visual content",
        "Production Wing - Audio engineering",
        "Podcast Studio - Long-form content",
        "Audiobook Studio - Narration suite",
        "Penthouse - High security, invite only",
      ],
      closing: "Ready to broadcast? Pick a zone or return to the elevator.",
    },
  },

  voiceProfile: {
    tone: "warm",
    pace: "measured",
    accent: "neutral-american",
    personality: ["authoritative", "welcoming", "knowledgeable"],
  },
}

export const NEURO_CONCIERGE = {
  id: "neuro-concierge",
  name: "NEURO",
  role: "Lobby Guide",
  floor: "LOBBY",
  description:
    "Agentic AI concierge, adaptive to user cognitive level and tech exposure. Supports 5 generations from boomers to Gen Alpha.",

  scripts: {
    welcome: {
      noob: "Welcome to WIRED CHAOS. I'm NEURO, your guide. Want me to show you around?",
      intermediate: "Back in the chaos. What floor?",
      advanced: "NEURO online. Panel ready.",
    },
    handoff: {
      to333: DJ_RED_FANG.scripts.welcome.deep,
      to789: "Entering 789 Studios — production floor. Where signals become stories.",
      toVault33: "Descending to VAULT 33. Nine layers of akashic memory await.",
    },
    routeReceived: "Route received. Do you want to ride it in order, or choose manually?",
  },

  adaptiveBehavior: {
    cognitiveLevel: ["noob", "intermediate", "advanced"],
    generationSupport: ["boomer", "genx", "millennial", "genz", "genalpha"],
    accessibilityModes: ["reducedMotion", "highContrast", "screenReader", "largeText"],
  },
}
