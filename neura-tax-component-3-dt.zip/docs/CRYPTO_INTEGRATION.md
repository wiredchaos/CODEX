# NEURA TAX - Crypto Integration Guide

## Overview

NEURA TAX provides complete crypto tax compliance for all activity across the WIRED CHAOS META ecosystem. This document explains how to integrate crypto tracking into any WIRED CHAOS META application.

## Supported Chains

- **XRPL** - XRP Ledger
- **DOGE** - Dogecoin (including Ordinals/Doginals)
- **SOL** - Solana
- **ETH** - Ethereum mainnet
- **ETH_L2** - Ethereum Layer 2 (Arbitrum, Optimism, etc.)
- **HBAR** - Hedera
- **BTC** - Bitcoin
- **OTHER** - Any other blockchain

## Integration Methods

### 1. Direct API Integration

Use the Unified Crypto Ledger (UCL) API to log transactions:

```typescript
// Log a crypto transaction
POST /api/ucl/crypto-transaction
{
  "txHash": "0x123...",
  "chain": "ETH",
  "timestamp": "2024-01-15T10:30:00Z",
  "eventType": "PURCHASE",
  "transactionType": "DISPOSITION",
  "tokenSymbol": "ETH",
  "quantity": 0.5,
  "fmvUsd": 1100.00,
  "costBasisUsd": 1000.00,
  "patchSource": "ARTIFACT_TERMINAL"
}
```

### 2. CHAOS Patch Integration

All crypto transactions automatically flow through the CHAOS patch layer when `CHAOS_PATCH_ENABLED=true`:

```typescript
import { logCryptoTransaction } from "@/lib/ucl-client";

// Automatically sends CHAOS event
await logCryptoTransaction({
  userId: "user123",
  chain: "SOL",
  eventType: "PAYMENT",
  tokenSymbol: "SOL",
  quantity: 10,
  fmvUsd: 985,
  costBasisUsd: 900,
  patchSource: "VRG33589"
});
```

### 3. Event Types

**Crypto Transactions:**
- `PURCHASE` - User bought crypto
- `SALE` - User sold crypto for fiat
- `TRADE` - Crypto-to-crypto swap
- `TRANSFER_OUT` - Sent to external wallet
- `TRANSFER_IN` - Received from external wallet
- `PAYMENT` - Used crypto as payment (e.g., buying WIRED CHAOS items)
- `FEE` - Transaction fee
- `BRIDGE` - Cross-chain bridge

**NFT Transactions:**
- `MINT` - Minted new NFT
- `PURCHASE` - Bought NFT with crypto
- `SALE` - Sold NFT
- `BURN` - Burned/destroyed NFT
- `TRANSFER_OUT` - Sent NFT
- `TRANSFER_IN` - Received NFT
- `UPGRADE` - NFT trait upgrade (404 mutations)

**Crypto Income:**
- `REWARD` - Rewards from app activity
- `AIRDROP` - Token airdrops
- `STAKING` - Staking rewards
- `MINING` - Mining rewards
- `REFERRAL` - Referral bonuses
- `BONUS` - Platform bonuses
- `EMISSION` - Token emissions
- `XP_CONVERSION` - XP converted to tokens

## Tax Treatment

### Dispositions (Form 8949 / Schedule D)
All crypto used to purchase anything triggers a disposition:
- Buying artifacts with crypto
- Trading one token for another
- Using crypto for NFT mints
- Cross-chain bridging

### Income (Schedule 1 / Schedule C)
All crypto received as income:
- Rewards from Artifact Terminal
- Airdrops
- Staking yields
- XP-to-token conversions

## FMV Calculation

Use the FMV calculator for real-time pricing:

```typescript
import { calculateFMV } from "@/lib/fmv-calculator";

const fmv = await calculateFMV("SOL", "SOL", 10.5, new Date());
console.log(`FMV: $${fmv.usdValue}`);
```

## Chain Utilities

```typescript
import { getChainMetadata, formatAddress, isValidAddress } from "@/lib/chain-utils";

const metadata = getChainMetadata("XRPL");
const shortAddress = formatAddress("rN7n7otQDd6FczFgLdllmUL1MA8...", "XRPL");
const isValid = isValidAddress("0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb", "ETH");
```

## Best Practices

1. **Always log transactions immediately** - Don't defer crypto event logging
2. **Include FMV at transaction time** - Calculate and store USD value when event occurs
3. **Use correct event types** - Proper categorization ensures correct tax treatment
4. **Set patchSource** - Identify which WIRED CHAOS app generated the transaction
5. **Validate addresses** - Use chain-specific address validation
6. **Track acquisition dates** - For long-term vs short-term capital gains (future enhancement)

## Testing

Use the crypto tracking dashboard to verify integration:

```
/crypto - View all transactions
/crypto/schedule-wizard - Test tax form recommendations
/crypto/forms - Generate IRS forms
```

## Support

For integration support or questions about crypto tax compliance, contact the NEURA TAX development team.
