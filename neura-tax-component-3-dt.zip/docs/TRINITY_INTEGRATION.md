# Trinity 3D Core Integration

## Overview

This patch workspace (NEURA TAX + Artifact Terminal) operates as a **consumer** of the WIRED CHAOS Trinity 3D Core. It does not generate 3D scenes, create timelines, or modify spatial infrastructure.

## Architecture

### Crab Leg Pattern
This chat is a WIRED CHAOS crab leg - a dependent extension that:
- Mounts Trinity 3D as a read-only spatial layer
- Respects Akira Codex canon and access gating
- Cannot fork timelines
- Cannot generate Trinity scenes

### Component Structure

```
┌─────────────────────────────────────────┐
│   Trinity 3D Core (External)            │
│   - Spatial Layer (Read-Only)           │
│   - Scene Management                    │
│   - Timeline Infrastructure             │
└─────────────────────────────────────────┘
              ↓ (mount)
┌─────────────────────────────────────────┐
│   <EnvironmentRenderer>                 │
│   patchId="CLEAR"                       │
│   kind="lobby"                          │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│   HUD Layer + Hotspots                  │
│   - Navigation UI                       │
│   - Hotspot Markers                     │
│   - System Status Display               │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│   Business/Akashic Firewall             │
│   - Sanitized Profile Mirror            │
│   - No PII Exposure                     │
│   - Realm Separation                    │
└─────────────────────────────────────────┘
```

## Timeline Door Resolution

### NETERU
- **Status:** Resolved
- **Mount Point:** `/artifact-terminal`
- **Access:** Governed by Akira Codex
- **Realm:** Akashic

### SIGNAL ERA
- **Status:** Resolved
- **Mount Point:** Pending assignment
- **Access:** Governed by Akira Codex

### RVP
- **Status:** Resolved
- **Mount Point:** Pending assignment
- **Access:** Governed by Akira Codex

## Hotspot System

Hotspots are interactive navigation anchors within the Trinity environment:

| Hotspot ID | Name | Realm | Target URL |
|------------|------|-------|------------|
| `neteru` | NETERU Timeline | Akashic | `/artifact-terminal` |
| `signal-era` | SIGNAL ERA Timeline | Akashic | TBD |
| `rvp` | RVP Timeline | Akashic | TBD |
| `neura-tax` | NEURA TAX Portal | Business | `/dashboard` |
| `artifact` | Artifact Terminal | Akashic | `/artifact-terminal` |

## Firewall Rules

### Business Realm (NEURA TAX)
- IRS-compliant data only
- No lore mechanics
- No fictional token values
- PII protection enforced

### Akashic Realm (Artifact Terminal)
- NTRU token mechanics (lore-based)
- 404 Dynamic NFTs
- Echo Engineer tools
- Timeline mutation logic

### Cross-Realm Communication
- Sanitized Profile Mirror only
- Behavioral flags and segments
- No raw financial data in Akashic
- No lore data in Business

## Usage

### Accessing Trinity View
```
Navigate to: /trinity
```

This loads the `<EnvironmentRenderer>` component which mounts the Trinity 3D Core.

### Navigation
Use the HUD left panel for quick navigation between:
- NEURA TAX (Business realm)
- Artifact Terminal (Akashic realm)
- Crypto Ledger (Cross-realm analytics)

### Hotspot Interaction
Hover over hotspot markers in the 3D environment to:
- See zone names
- View realm assignments
- Navigate to target URLs

## Constraints

### Prohibited Actions
- ❌ Generating new 3D scenes
- ❌ Creating timeline infrastructure
- ❌ Modifying Trinity Core
- ❌ Forking timelines
- ❌ Writing to spatial registry

### Permitted Actions
- ✅ Reading Trinity spatial data
- ✅ Rendering HUD overlays
- ✅ Responding to hotspot events
- ✅ Navigating between realms
- ✅ Displaying system status

## Development

### Adding New Hotspots
Edit `lib/trinity-config.ts`:

```typescript
hotspots: [
  {
    id: "new-zone",
    name: "New Zone Name",
    realm: "BUSINESS" | "AKASHIC",
    targetUrl: "/new-route",
    description: "Zone description",
  },
]
```

### Customizing HUD
Edit `components/trinity/trinity-hud.tsx` to modify:
- Top bar system status
- Left navigation panel
- Right info panel
- Bottom constraint display

## References

- Trinity 3D Core: External system (read-only)
- Akira Codex: Canon authority and access gating
- WIRED CHAOS META: Parent orchestration system
- Crab Leg Architecture: Dependent extension pattern
