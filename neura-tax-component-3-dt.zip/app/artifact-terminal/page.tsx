"use client"

import { useMemo, useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"

type RarityTier = "Standard" | "Enhanced" | "Mutated"

type Artifact = {
  id: string
  name: string
  tier: RarityTier
  level: number
  charge: number // 0–100
  nextMutationAt: Date
}

const MOCK_ARTIFACTS: Artifact[] = [
  {
    id: "a1",
    name: "Echo Shard // 404-γ",
    tier: "Standard",
    level: 3,
    charge: 42,
    nextMutationAt: addDays(new Date(), 2),
  },
  {
    id: "a2",
    name: "Chrono Husk // NX-9",
    tier: "Enhanced",
    level: 7,
    charge: 76,
    nextMutationAt: addDays(new Date(), 1),
  },
  {
    id: "a3",
    name: "NTRU Singularity Core",
    tier: "Mutated",
    level: 12,
    charge: 91,
    nextMutationAt: addHours(new Date(), 6),
  },
]

const TIER_COLORS: Record<RarityTier, string> = {
  Standard: "bg-slate-700 text-slate-100",
  Enhanced: "bg-cyan-500/20 text-cyan-300 border border-cyan-500/50",
  Mutated: "bg-fuchsia-500/20 text-fuchsia-300 border border-fuchsia-500/50",
}

function addDays(d: Date, n: number) {
  const copy = new Date(d)
  copy.setDate(copy.getDate() + n)
  return copy
}

function addHours(d: Date, n: number) {
  const copy = new Date(d)
  copy.setHours(copy.getHours() + n)
  return copy
}

function formatCountdown(target: Date) {
  const now = new Date().getTime()
  const diff = target.getTime() - now
  if (diff <= 0) return "Mutation window active"
  const totalSeconds = Math.floor(diff / 1000)
  const days = Math.floor(totalSeconds / 86400)
  const hours = Math.floor((totalSeconds % 86400) / 3600)
  const minutes = Math.floor((totalSeconds % 3600) / 60)
  const parts = []
  if (days) parts.push(`${days}d`)
  if (hours) parts.push(`${hours}h`)
  if (minutes) parts.push(`${minutes}m`)
  if (!parts.length) parts.push("seconds")
  return parts.join(" ")
}

export default function ArtifactTerminalPage() {
  const [selectedTier, setSelectedTier] = useState<RarityTier | "All">("All")
  const [selectedArtifactId, setSelectedArtifactId] = useState<string>("a3")
  const [ntruBalance] = useState<number>(404.33)
  const [mutationEpochTarget] = useState<Date>(addDays(new Date(), 3))
  const [epochCountdown, setEpochCountdown] = useState<string>(formatCountdown(mutationEpochTarget))
  const [exchangeMode, setExchangeMode] = useState<"basic" | "ntru">("basic")
  const [showMutationOdds, setShowMutationOdds] = useState<boolean>(true)
  const [showEntropy, setShowEntropy] = useState<boolean>(false)

  useEffect(() => {
    const id = setInterval(() => {
      setEpochCountdown(formatCountdown(mutationEpochTarget))
    }, 30_000)
    return () => clearInterval(id)
  }, [mutationEpochTarget])

  const filteredArtifacts = useMemo(() => {
    if (selectedTier === "All") return MOCK_ARTIFACTS
    return MOCK_ARTIFACTS.filter((a) => a.tier === selectedTier)
  }, [selectedTier])

  const selectedArtifact = useMemo(
    () => MOCK_ARTIFACTS.find((a) => a.id === selectedArtifactId) ?? MOCK_ARTIFACTS[0],
    [selectedArtifactId],
  )

  const projectedNtruCost = useMemo(() => {
    if (!selectedArtifact) return 0
    const base = selectedArtifact.level * 1.5
    return exchangeMode === "basic" ? base : base * 2.5
  }, [selectedArtifact, exchangeMode])

  const projectedOutcome = useMemo(() => {
    if (!selectedArtifact) return ""
    if (exchangeMode === "basic") {
      return "Stable reroll within same rarity band. No timeline distortion expected."
    }
    return "High-variance reroll. Elevated chance of rarity uplift and 404-state mutation."
  }, [selectedArtifact, exchangeMode])

  return (
    <main className="min-h-screen bg-slate-950 text-slate-50 flex flex-col">
      {/* Top bar */}
      <header className="border-b border-slate-800 px-6 py-4 flex items-center justify-between">
        <div>
          <div className="text-lg font-semibold tracking-tight">NEURA Artifact Terminal</div>
          <div className="text-xs text-slate-400">NTRU Exchange Node • Echo Engineer Console</div>
        </div>
        <div className="flex items-center gap-6 text-xs">
          <div className="text-right">
            <div className="text-slate-400">NTRU Balance</div>
            <div className="font-semibold text-cyan-300">
              {ntruBalance.toLocaleString(undefined, {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
              })}{" "}
              NTRU
            </div>
          </div>
          <Separator orientation="vertical" className="h-8 bg-slate-700" />
          <div className="text-right">
            <div className="text-slate-400 text-[11px] uppercase tracking-wide">Mutation Epoch</div>
            <div className="text-xs font-semibold">{epochCountdown}</div>
          </div>
        </div>
      </header>

      {/* Main grid */}
      <div className="flex-1 px-6 py-6 grid gap-6 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,1.4fr)]">
        {/* Left column – Inventory */}
        <section className="space-y-4">
          <Card className="bg-slate-900/60 border-slate-800">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-semibold">Artifact Inventory</CardTitle>
              <div className="flex gap-2 text-[11px]">
                <FilterChip label="All" active={selectedTier === "All"} onClick={() => setSelectedTier("All")} />
                <FilterChip
                  label="Standard"
                  active={selectedTier === "Standard"}
                  onClick={() => setSelectedTier("Standard")}
                />
                <FilterChip
                  label="Enhanced"
                  active={selectedTier === "Enhanced"}
                  onClick={() => setSelectedTier("Enhanced")}
                />
                <FilterChip
                  label="Mutated"
                  active={selectedTier === "Mutated"}
                  onClick={() => setSelectedTier("Mutated")}
                />
              </div>
            </CardHeader>
            <CardContent className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
              {filteredArtifacts.map((artifact) => (
                <button
                  key={artifact.id}
                  type="button"
                  onClick={() => setSelectedArtifactId(artifact.id)}
                  className={`w-full text-left rounded-md border px-3 py-2 text-xs transition ${
                    artifact.id === selectedArtifactId
                      ? "border-cyan-500/70 bg-slate-900"
                      : "border-slate-800 bg-slate-950/60 hover:border-slate-700"
                  }`}
                >
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-medium">{artifact.name}</span>
                    <TierBadge tier={artifact.tier} />
                  </div>
                  <div className="flex justify-between items-center text-[11px] text-slate-400">
                    <span>Level {artifact.level}</span>
                    <span>
                      Next mutation: <span className="text-slate-200">{formatCountdown(artifact.nextMutationAt)}</span>
                    </span>
                  </div>
                  <div className="mt-1 flex items-center gap-2">
                    <Progress value={artifact.charge} className="h-1.5" />
                    <span className="text-[10px] text-slate-400">Charge {artifact.charge}%</span>
                  </div>
                </button>
              ))}
              {filteredArtifacts.length === 0 && (
                <div className="text-[11px] text-slate-500 py-4">No artifacts match this filter yet.</div>
              )}
            </CardContent>
          </Card>

          {/* Echo Engineer Tools */}
          <Card className="bg-slate-900/70 border-slate-800">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold">Echo Engineer Tools</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-300">Show mutation odds overlay</span>
                <Switch checked={showMutationOdds} onCheckedChange={setShowMutationOdds} />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-300">Show entropy field</span>
                <Switch checked={showEntropy} onCheckedChange={setShowEntropy} />
              </div>
              <Separator className="bg-slate-800 my-2" />
              <div className="space-y-1 text-[11px] text-slate-400">
                <div>
                  <span className="text-slate-500">Mode:</span>{" "}
                  <span className="text-slate-200">
                    {exchangeMode === "basic" ? "Stable Path" : "NTRU-Fueled Path"}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500">Entropy signature:</span>{" "}
                  <span className="text-cyan-300/80">{showEntropy ? "NX-404::∆TIMELINE::ACTIVE" : "Redacted"}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Right column – Exchange + Visualization */}
        <section className="space-y-4">
          <div className="grid md:grid-cols-[minmax(0,1.1fr)_minmax(0,1.1fr)] gap-4">
            {/* Selected artifact summary */}
            <Card className="bg-slate-900/70 border-slate-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold">Selected Artifact</CardTitle>
              </CardHeader>
              <CardContent className="text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium text-slate-100">{selectedArtifact?.name}</span>
                  {selectedArtifact && <TierBadge tier={selectedArtifact.tier} />}
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Level {selectedArtifact?.level}</span>
                  <span>
                    Charge: {selectedArtifact?.charge}% • Next epoch:{" "}
                    <span className="text-slate-200">
                      {selectedArtifact ? formatCountdown(selectedArtifact.nextMutationAt) : "-"}
                    </span>
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Artifacts indexed to the Neteru Apinaya continuum may express emergent traits during NTRU-synchronized
                  mutation windows.
                </p>
              </CardContent>
            </Card>

            {/* 404 Dynamic NFT visualization */}
            <Card className="bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 border border-fuchsia-500/40 shadow-[0_0_40px_rgba(217,70,239,0.25)]">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold flex items-center justify-between">
                  404 Dynamic Evolution
                  <span className="text-[10px] text-fuchsia-300/80 uppercase tracking-wide">
                    Timeline Distortion Visualizer
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent className="text-xs space-y-3">
                <div className="relative rounded-md border border-fuchsia-500/40 bg-slate-950/90 px-3 py-4 overflow-hidden">
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_rgba(236,72,153,0.16),_transparent_55%),radial-gradient(circle_at_bottom,_rgba(59,130,246,0.15),_transparent_55%)] pointer-events-none" />
                  <div className="relative flex flex-col gap-1">
                    <div className="text-[11px] text-fuchsia-300/90">
                      EVOLUTION STAGE:{" "}
                      <span className="font-semibold">{exchangeMode === "basic" ? "Stable Phase" : "Phase 404"}</span>
                    </div>
                    <div className="text-[10px] text-slate-300/90 font-mono">
                      {showMutationOdds
                        ? "prob[rarity++]: 0.33 • prob[glitch404]: 0.07"
                        : "probabilities: masked • engineer mode to reveal"}
                    </div>
                    <div className="mt-2 h-16 rounded bg-slate-900/90 border border-slate-800 flex items-center justify-center text-[10px] font-mono text-slate-400">
                      <span className="animate-pulse">NFT STREAM // {selectedArtifact?.id ?? "????"} // NTRU-LINK</span>
                    </div>
                  </div>
                </div>
                <p className="text-[11px] text-slate-400">
                  When NTRU flux exceeds threshold, the artifact&apos;s on-chain representation may desync from baseline
                  reality and enter a 404 state, rewriting its visible attributes.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Exchange tabs */}
          <Card className="bg-slate-900/70 border-slate-800">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-semibold">Exchange Pathways</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <Tabs
                value={exchangeMode}
                onValueChange={(v) => setExchangeMode(v as "basic" | "ntru")}
                className="space-y-4"
              >
                <TabsList className="bg-slate-900 border border-slate-700">
                  <TabsTrigger
                    value="basic"
                    className="data-[state=active]:bg-slate-800 data-[state=active]:text-slate-50"
                  >
                    Basic Exchange
                  </TabsTrigger>
                  <TabsTrigger
                    value="ntru"
                    className="data-[state=active]:bg-slate-800 data-[state=active]:text-slate-50"
                  >
                    NTRU-Fueled
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="basic" className="space-y-3 text-xs">
                  <p className="text-slate-300">
                    Stable reroll path. No direct NTRU burn; output remains within the artifact&apos;s current rarity
                    band.
                  </p>
                  <ExchangePreview
                    mode="basic"
                    projectedNtruCost={projectedNtruCost}
                    ntruBalance={ntruBalance}
                    projectedOutcome={projectedOutcome}
                  />
                </TabsContent>

                <TabsContent value="ntru" className="space-y-3 text-xs">
                  <p className="text-slate-300">
                    High-volatility path. NTRU exposure amplifies mutation probability, unlocking chances of rarity
                    uplift, corrupted traits, or 404 evolutions.
                  </p>
                  <ExchangePreview
                    mode="ntru"
                    projectedNtruCost={projectedNtruCost}
                    ntruBalance={ntruBalance}
                    projectedOutcome={projectedOutcome}
                  />
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </section>
      </div>
    </main>
  )
}

/* --- Small helper components --- */

function TierBadge({ tier }: { tier: RarityTier }) {
  const base = "px-2 py-0.5 rounded-full text-[10px] inline-flex items-center gap-1"
  const color = TIER_COLORS[tier]
  return (
    <span className={`${base} ${color}`}>
      <span
        className={`h-1.5 w-1.5 rounded-full ${
          tier === "Standard" ? "bg-slate-300" : tier === "Enhanced" ? "bg-cyan-400" : "bg-fuchsia-400"
        }`}
      />
      {tier}
    </span>
  )
}

function FilterChip({
  label,
  active,
  onClick,
}: {
  label: string
  active: boolean
  onClick: () => void
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`px-2 py-0.5 rounded-full border text-[11px] transition ${
        active
          ? "border-cyan-400 bg-cyan-400/10 text-cyan-200"
          : "border-slate-700 bg-slate-900 text-slate-300 hover:border-slate-500"
      }`}
    >
      {label}
    </button>
  )
}

function ExchangePreview({
  mode,
  projectedNtruCost,
  ntruBalance,
  projectedOutcome,
}: {
  mode: "basic" | "ntru"
  projectedNtruCost: number
  ntruBalance: number
  projectedOutcome: string
}) {
  const affordable = mode === "basic" ? true : projectedNtruCost < ntruBalance
  return (
    <div className="grid md:grid-cols-[minmax(0,1.1fr)_minmax(0,1.1fr)] gap-4">
      <div className="space-y-2 text-xs">
        <div className="flex items-center justify-between">
          <span className="text-slate-400">Projected NTRU impact</span>
          <span className="font-semibold text-cyan-300">
            {mode === "basic" ? "0.00 NTRU (no burn)" : `-${projectedNtruCost.toFixed(2)} NTRU`}
          </span>
        </div>
        <div className="text-[11px] text-slate-400">
          {mode === "basic"
            ? "This path preserves your NTRU and performs a localized reroll without destabilizing the ledger."
            : "NTRU is exposed directly to the artifact's entropy field. Expect higher variance and potential timeline drift."}
        </div>
        <div className="mt-2">
          <Button
            size="sm"
            className="w-full text-xs"
            variant={mode === "basic" ? "outline" : "default"}
            disabled={!affordable}
          >
            {mode === "basic" ? "Execute Basic Exchange" : "Execute NTRU-Fueled Exchange"}
          </Button>
          {!affordable && (
            <p className="mt-1 text-[10px] text-rose-400">Insufficient NTRU balance for this operation.</p>
          )}
        </div>
      </div>
      <div className="border border-slate-800 rounded-md bg-slate-950/80 px-3 py-2 text-[11px]">
        <div className="text-slate-400 mb-1">Outcome Projection</div>
        <p className="text-slate-200">{projectedOutcome}</p>
        <p className="mt-2 text-slate-500">
          Final behavior, mutation odds, and rarity bands will be wired to the on-chain NTRU / Artifact models once the
          math engine is integrated.
        </p>
      </div>
    </div>
  )
}
