import { redirect } from "next/navigation"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import NewReturnForm from "@/components/returns/new-return-form"

export default async function NewReturnPage() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect("/auth/signin")
  }

  return (
    <div className="min-h-screen bg-secondary/20">
      <div className="border-b bg-background">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold">Create New Tax Return</h1>
          <p className="text-sm text-muted-foreground">Start preparing your tax return</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <NewReturnForm />
      </div>
    </div>
  )
}
