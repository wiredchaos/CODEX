import { redirect } from "next/navigation"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/db"
import TaxReturnWorkflow from "@/components/returns/tax-return-workflow"
import RiskFlagsPanel from "@/components/returns/risk-flags-panel"
import AuditLogPanel from "@/components/returns/audit-log-panel"

export default async function TaxReturnPage({ params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect("/auth/signin")
  }

  const taxReturn = await prisma.taxReturn.findUnique({
    where: { id: params.id },
    include: {
      user: {
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
        },
      },
      riskFlags: {
        where: { resolved: false },
        orderBy: { createdAt: "desc" },
      },
      auditLogs: {
        orderBy: { createdAt: "desc" },
        take: 20,
        include: {
          user: {
            select: {
              name: true,
              email: true,
            },
          },
        },
      },
    },
  })

  if (!taxReturn) {
    redirect("/dashboard")
  }

  const currentUser = await prisma.user.findUnique({
    where: { id: session.user.id },
  })

  // Check permissions
  const canEdit =
    taxReturn.userId === session.user.id || currentUser?.role === "PREPARER" || currentUser?.role === "ADMIN"

  if (!canEdit && taxReturn.userId !== session.user.id) {
    redirect("/dashboard")
  }

  const canResolve = currentUser?.role === "PREPARER" || currentUser?.role === "ADMIN"

  return (
    <div className="space-y-6">
      <TaxReturnWorkflow taxReturn={taxReturn} currentUser={currentUser!} />

      <div className="grid md:grid-cols-2 gap-6">
        <RiskFlagsPanel flags={taxReturn.riskFlags} canResolve={canResolve} />
        <AuditLogPanel logs={taxReturn.auditLogs} />
      </div>
    </div>
  )
}
