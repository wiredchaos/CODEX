import { redirect } from "next/navigation"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/db"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { FileText, Plus, User } from "lucide-react"
import { format } from "date-fns"
import { FiscalLiabilityAlert } from "@/components/notifications/fiscal-liability-alert"

export default async function DashboardPage() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect("/auth/signin")
  }

  const user = await prisma.user.findUnique({
    where: { id: session.user.id },
    include: {
      taxReturns: {
        orderBy: { updatedAt: "desc" },
        take: 10,
      },
      fiscalTriggers: {
        orderBy: { createdAt: "desc" },
        take: 1,
      },
    },
  })

  if (!user) {
    redirect("/auth/signin")
  }

  const statusColors: Record<string, string> = {
    DRAFT: "bg-gray-500",
    READY_FOR_REVIEW: "bg-blue-500",
    READY_FOR_EFILE: "bg-yellow-500",
    EFILE_SUBMITTED: "bg-purple-500",
    ACCEPTED: "bg-green-500",
    REJECTED: "bg-red-500",
  }

  const latestTrigger = user.fiscalTriggers[0]

  return (
    <div className="min-h-screen bg-secondary/20">
      {/* Header */}
      <div className="border-b bg-background">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold">Dashboard</h1>
              <p className="text-sm text-muted-foreground">Welcome back, {user.name}</p>
            </div>
            <div className="flex items-center gap-3">
              <Badge variant="outline" className="px-3 py-1">
                <User className="mr-2 h-3 w-3" />
                {user.role}
              </Badge>
              <Button asChild>
                <Link href="/returns/new">
                  <Plus className="mr-2 h-4 w-4" />
                  New Tax Return
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        {latestTrigger && (
          <div className="mb-6">
            <FiscalLiabilityAlert trigger={latestTrigger} />
          </div>
        )}

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Quick Stats */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="text-2xl font-bold">{user.taxReturns.length}</div>
                  <div className="text-sm text-muted-foreground">Total Returns</div>
                </div>
                <div>
                  <div className="text-2xl font-bold">{user.taxReturns.filter((r) => r.status === "DRAFT").length}</div>
                  <div className="text-sm text-muted-foreground">In Progress</div>
                </div>
                <div>
                  <div className="text-2xl font-bold">
                    {user.taxReturns.filter((r) => r.status === "ACCEPTED").length}
                  </div>
                  <div className="text-sm text-muted-foreground">Accepted</div>
                </div>
              </CardContent>
            </Card>

            {user.citizenshipStatus === "NON_US" || user.citizenshipStatus === "NON_RESIDENT" ? (
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>Non-US Services</CardTitle>
                  <CardDescription>Document preparation for non-residents</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button asChild variant="outline" className="w-full bg-transparent">
                    <Link href="/non-us">Create Document Pack</Link>
                  </Button>
                </CardContent>
              </Card>
            ) : null}
          </div>

          {/* Tax Returns List */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Your Tax Returns</CardTitle>
                <CardDescription>Manage and track your tax filings</CardDescription>
              </CardHeader>
              <CardContent>
                {user.taxReturns.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <FileText className="h-12 w-12 text-muted-foreground" />
                    <h3 className="mt-4 font-semibold">No tax returns yet</h3>
                    <p className="mt-2 text-sm text-muted-foreground">Get started by creating your first tax return</p>
                    <Button asChild className="mt-6">
                      <Link href="/returns/new">
                        <Plus className="mr-2 h-4 w-4" />
                        Create Tax Return
                      </Link>
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {user.taxReturns.map((taxReturn) => (
                      <Link
                        key={taxReturn.id}
                        href={`/returns/${taxReturn.id}`}
                        className="block rounded-lg border bg-card p-4 transition-colors hover:bg-accent"
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="flex items-center gap-3">
                              <h3 className="font-semibold">Tax Year {taxReturn.taxYear}</h3>
                              <Badge className={statusColors[taxReturn.status]}>
                                {taxReturn.status.replace(/_/g, " ")}
                              </Badge>
                            </div>
                            <p className="mt-1 text-sm text-muted-foreground">Type: {taxReturn.returnType}</p>
                            <p className="mt-1 text-xs text-muted-foreground">
                              Last updated: {format(new Date(taxReturn.updatedAt), "MMM d, yyyy")}
                            </p>
                          </div>
                          <FileText className="h-5 w-5 text-muted-foreground" />
                        </div>
                      </Link>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
