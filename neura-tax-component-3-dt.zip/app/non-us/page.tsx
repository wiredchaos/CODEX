import { redirect } from "next/navigation"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/db"
import NonUsDocumentWizard from "@/components/non-us/non-us-document-wizard"

export default async function NonUsPage() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect("/auth/signin")
  }

  const user = await prisma.user.findUnique({
    where: { id: session.user.id },
    include: {
      nonUsPacks: {
        orderBy: { createdAt: "desc" },
      },
    },
  })

  if (!user) {
    redirect("/auth/signin")
  }

  return (
    <div className="min-h-screen bg-secondary/20">
      <div className="border-b bg-background">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold">Non-US Document Preparation</h1>
          <p className="text-sm text-muted-foreground">Prepare tax documents for non-residents and non-US citizens</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <NonUsDocumentWizard existingPacks={user.nonUsPacks} />
      </div>
    </div>
  )
}
