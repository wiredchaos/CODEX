import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { generateForm8949 } from "@/lib/form-generators/form-8949"
import { generateScheduleD } from "@/lib/form-generators/schedule-d"
import { generateSchedule1CryptoIncome } from "@/lib/form-generators/schedule-1"

// POST /api/crypto/forms/generate - Generate IRS forms
export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { taxYear, taxpayerName, ssn, forms } = body

    if (!taxYear || !taxpayerName || !ssn || !forms || !Array.isArray(forms)) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const result: any = {}

    // Generate Form 8949 if requested
    if (forms.includes("8949")) {
      result.form8949 = await generateForm8949(session.user.id, taxYear, taxpayerName, ssn)
    }

    // Generate Schedule D if requested
    if (forms.includes("schedule-d")) {
      if (!result.form8949) {
        result.form8949 = await generateForm8949(session.user.id, taxYear, taxpayerName, ssn)
      }
      result.scheduleD = generateScheduleD(result.form8949)
    }

    // Generate Schedule 1 crypto income if requested
    if (forms.includes("schedule-1")) {
      result.schedule1 = await generateSchedule1CryptoIncome(session.user.id, taxYear, taxpayerName, ssn)
    }

    return NextResponse.json(result)
  } catch (error) {
    console.error("[v0] Error generating forms:", error)
    return NextResponse.json({ error: "Failed to generate forms" }, { status: 500 })
  }
}
