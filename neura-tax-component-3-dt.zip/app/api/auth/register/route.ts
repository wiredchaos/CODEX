import { NextResponse } from "next/server"
import { hash } from "bcryptjs"
import { prisma } from "@/lib/db"
import { sendChaosEvent, createAnonId } from "@/lib/chaos-patch"
import { registerSchema } from "@/lib/validation"

export async function POST(request: Request) {
  try {
    const body = await request.json()

    // Validate input
    const validatedData = registerSchema.parse(body)

    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email: validatedData.email },
    })

    if (existingUser) {
      return NextResponse.json({ error: "Email already registered" }, { status: 400 })
    }

    // Hash password
    const hashedPassword = await hash(validatedData.password, 12)

    // Create user
    const user = await prisma.user.create({
      data: {
        email: validatedData.email,
        password: hashedPassword,
        name: validatedData.name,
        citizenshipStatus: validatedData.citizenshipStatus as any,
        disclaimersAcceptedAt: new Date(),
      },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
      },
    })

    // Send CHAOS event (only if enabled)
    await sendChaosEvent({
      appId: "NEURA_TAX",
      eventType: "USER_CREATED",
      timestamp: new Date().toISOString(),
      userAnonId: createAnonId(user.id),
      payload: {
        role: user.role,
      },
    })

    return NextResponse.json({ message: "User created successfully", user }, { status: 201 })
  } catch (error: any) {
    console.error("[Registration Error]", error)

    if (error.name === "ZodError") {
      return NextResponse.json({ error: "Invalid input data", details: error.errors }, { status: 400 })
    }

    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
