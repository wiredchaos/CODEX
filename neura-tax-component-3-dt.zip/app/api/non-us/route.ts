import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/db"
import { sendChaosEvent, createAnonId } from "@/lib/chaos-patch"

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { dataJson } = await request.json()

    const nonUsPack = await prisma.nonUsPack.create({
      data: {
        userId: session.user.id,
        dataJson,
        documentType: "NON_US_DOCUMENT_PACK",
      },
    })

    // Log audit
    await prisma.auditLog.create({
      data: {
        userId: session.user.id,
        action: "NON_US_PACK_CREATED",
        changedFields: {
          country: dataJson.residencyInfo?.country,
        },
      },
    })

    // Send CHAOS event
    await sendChaosEvent({
      appId: "NEURA_TAX",
      eventType: "NON_US_DOCUMENT_PACK_CREATED",
      timestamp: new Date().toISOString(),
      userAnonId: createAnonId(session.user.id),
      payload: {
        country: dataJson.residencyInfo?.country,
        hasUsIncome: dataJson.usIncome?.hasUsIncome,
      },
    })

    return NextResponse.json(nonUsPack, { status: 201 })
  } catch (error) {
    console.error("[Create Non-US Pack Error]", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const packs = await prisma.nonUsPack.findMany({
      where: { userId: session.user.id },
      orderBy: { createdAt: "desc" },
    })

    return NextResponse.json(packs)
  } catch (error) {
    console.error("[Get Non-US Packs Error]", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
