import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/db"
import { checkEfileStatus } from "@/lib/efile-client"
import { sendChaosEvent, createAnonId } from "@/lib/chaos-patch"

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { submissionId } = await request.json()

    const submission = await prisma.efileSubmission.findUnique({
      where: { id: submissionId },
      include: {
        taxReturn: true,
      },
    })

    if (!submission) {
      return NextResponse.json({ error: "Submission not found" }, { status: 404 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    // Check permissions
    const canView =
      submission.taxReturn.userId === session.user.id || user?.role === "PREPARER" || user?.role === "ADMIN"

    if (!canView) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Check status with e-file provider
    const statusResponse = await checkEfileStatus(submission.transmitterRef || "")

    // Update submission record
    const updated = await prisma.efileSubmission.update({
      where: { id: submissionId },
      data: {
        status: statusResponse.status,
        rawResponse: statusResponse,
      },
    })

    // Update tax return status if accepted or rejected
    if (statusResponse.status === "ACCEPTED") {
      await prisma.taxReturn.update({
        where: { id: submission.taxReturnId },
        data: { status: "ACCEPTED" },
      })

      // Send CHAOS event
      await sendChaosEvent({
        appId: "NEURA_TAX",
        eventType: "EFILE_ACCEPTED",
        timestamp: new Date().toISOString(),
        userAnonId: createAnonId(submission.taxReturn.userId),
        payload: {
          taxYear: submission.taxReturn.taxYear,
          acceptedDate: statusResponse.acceptedDate,
        },
      })
    } else if (statusResponse.status === "REJECTED") {
      await prisma.taxReturn.update({
        where: { id: submission.taxReturnId },
        data: { status: "REJECTED" },
      })

      // Send CHAOS event
      await sendChaosEvent({
        appId: "NEURA_TAX",
        eventType: "EFILE_REJECTED",
        timestamp: new Date().toISOString(),
        userAnonId: createAnonId(submission.taxReturn.userId),
        payload: {
          taxYear: submission.taxReturn.taxYear,
          rejectionReasons: statusResponse.rejectionReasons,
        },
      })
    }

    // Log audit
    await prisma.auditLog.create({
      data: {
        userId: session.user.id,
        taxReturnId: submission.taxReturnId,
        action: "EFILE_STATUS_CHECKED",
        changedFields: {
          status: statusResponse.status,
        },
      },
    })

    return NextResponse.json({
      submission: updated,
      status: statusResponse,
    })
  } catch (error) {
    console.error("[E-File Status Error]", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
