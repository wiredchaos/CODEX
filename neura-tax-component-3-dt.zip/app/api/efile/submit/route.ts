import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/db"
import { submitReturnForEfile, validateReturnForEfile } from "@/lib/efile-client"
import { sendChaosEvent, createAnonId } from "@/lib/chaos-patch"

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    // Only preparers and admins can submit for e-file
    if (user?.role !== "PREPARER" && user?.role !== "ADMIN") {
      return NextResponse.json({ error: "Only preparers and admins can submit returns for e-file" }, { status: 403 })
    }

    const { taxReturnId } = await request.json()

    const taxReturn = await prisma.taxReturn.findUnique({
      where: { id: taxReturnId },
      include: {
        user: true,
      },
    })

    if (!taxReturn) {
      return NextResponse.json({ error: "Tax return not found" }, { status: 404 })
    }

    // Check status
    if (taxReturn.status !== "READY_FOR_EFILE") {
      return NextResponse.json({ error: "Return must be in READY_FOR_EFILE status" }, { status: 400 })
    }

    // Validate return data
    const validation = validateReturnForEfile(taxReturn.dataJson)
    if (!validation.valid) {
      return NextResponse.json({ error: "Validation failed", details: validation.errors }, { status: 400 })
    }

    // Submit to e-file provider
    const efileResponse = await submitReturnForEfile({
      taxReturnId: taxReturn.id,
      taxYear: taxReturn.taxYear,
      taxpayerInfo: {
        firstName: taxReturn.dataJson.personalInfo.firstName,
        lastName: taxReturn.dataJson.personalInfo.lastName,
        ssn: taxReturn.dataJson.personalInfo.ssn,
        address: taxReturn.dataJson.personalInfo.address,
      },
      returnData: taxReturn.dataJson,
      metadata: {
        eroId: process.env.ERO_ID || "",
        efin: process.env.EFIN || "",
        ctecId: process.env.CTEC_ID || "",
        appId: "NEURA_TAX",
      },
    })

    // Store submission record
    const submission = await prisma.efileSubmission.create({
      data: {
        taxReturnId: taxReturn.id,
        transmitterRef: efileResponse.transmitterRef,
        status: efileResponse.status,
        rawRequest: {
          taxReturnId,
          submittedBy: session.user.id,
          timestamp: new Date().toISOString(),
        },
        rawResponse: efileResponse,
      },
    })

    // Update tax return status
    if (efileResponse.success) {
      await prisma.taxReturn.update({
        where: { id: taxReturn.id },
        data: { status: "EFILE_SUBMITTED" },
      })
    }

    // Log audit
    await prisma.auditLog.create({
      data: {
        userId: session.user.id,
        taxReturnId: taxReturn.id,
        action: "EFILE_SUBMITTED",
        changedFields: {
          submissionId: submission.id,
          transmitterRef: efileResponse.transmitterRef,
        },
      },
    })

    // Send CHAOS event
    await sendChaosEvent({
      appId: "NEURA_TAX",
      eventType: "EFILE_SUBMITTED",
      timestamp: new Date().toISOString(),
      userAnonId: createAnonId(taxReturn.userId),
      payload: {
        taxYear: taxReturn.taxYear,
        success: efileResponse.success,
      },
    })

    return NextResponse.json({
      success: efileResponse.success,
      submission,
      message: efileResponse.message,
    })
  } catch (error) {
    console.error("[E-File Submit Error]", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
