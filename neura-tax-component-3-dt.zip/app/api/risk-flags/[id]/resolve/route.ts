import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/db"

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    // Only preparers and admins can resolve flags
    if (user?.role !== "PREPARER" && user?.role !== "ADMIN") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const flag = await prisma.riskFlag.update({
      where: { id: params.id },
      data: { resolved: true },
    })

    // Create audit log
    await prisma.auditLog.create({
      data: {
        taxReturnId: flag.taxReturnId,
        userId: session.user.id,
        action: "RISK_FLAG_RESOLVED",
        changedFields: { flagCode: flag.code },
      },
    })

    return NextResponse.json({ success: true, flag })
  } catch (error) {
    console.error("[v0] Error resolving risk flag:", error)
    return NextResponse.json({ error: "Failed to resolve risk flag" }, { status: 500 })
  }
}
