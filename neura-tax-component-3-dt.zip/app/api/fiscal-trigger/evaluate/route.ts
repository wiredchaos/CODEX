import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { evaluateFiscalLiabilityTrigger } from "@/lib/fiscal-trigger"

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { taxYear } = body

    if (!taxYear) {
      return NextResponse.json({ error: "Tax year is required" }, { status: 400 })
    }

    const userId = (session.user as any).id

    const trigger = await evaluateFiscalLiabilityTrigger({
      userId,
      taxYear: Number.parseInt(taxYear),
    })

    if (!trigger) {
      return NextResponse.json({
        success: true,
        triggerDetected: false,
        message: "No fiscal liability triggers detected",
      })
    }

    return NextResponse.json({
      success: true,
      triggerDetected: true,
      trigger: {
        id: trigger.id,
        severity: trigger.severity,
        category: trigger.category,
        liabilityEstimate: trigger.liabilityEstimate,
        createdAt: trigger.createdAt,
      },
    })
  } catch (error) {
    console.error("Error evaluating fiscal trigger:", error)
    return NextResponse.json({ error: "Failed to evaluate fiscal trigger" }, { status: 500 })
  }
}
