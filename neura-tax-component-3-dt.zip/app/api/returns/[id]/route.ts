import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/db"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const taxReturn = await prisma.taxReturn.findUnique({
      where: { id: params.id },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        riskFlags: true,
        efileSubmissions: true,
      },
    })

    if (!taxReturn) {
      return NextResponse.json({ error: "Tax return not found" }, { status: 404 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    // Check permissions
    const canView = taxReturn.userId === session.user.id || user?.role === "PREPARER" || user?.role === "ADMIN"

    if (!canView) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    return NextResponse.json(taxReturn)
  } catch (error) {
    console.error("[Get Return Error]", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const taxReturn = await prisma.taxReturn.findUnique({
      where: { id: params.id },
    })

    if (!taxReturn) {
      return NextResponse.json({ error: "Tax return not found" }, { status: 404 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    // Check permissions
    const canEdit = taxReturn.userId === session.user.id || user?.role === "PREPARER" || user?.role === "ADMIN"

    if (!canEdit) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const { dataJson } = await request.json()

    const updated = await prisma.taxReturn.update({
      where: { id: params.id },
      data: { dataJson },
    })

    // Log audit
    await prisma.auditLog.create({
      data: {
        userId: session.user.id,
        taxReturnId: taxReturn.id,
        action: "TAX_RETURN_UPDATED",
        changedFields: { updated: true },
      },
    })

    return NextResponse.json(updated)
  } catch (error) {
    console.error("[Update Return Error]", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
