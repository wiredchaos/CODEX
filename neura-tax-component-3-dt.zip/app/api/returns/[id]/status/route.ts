import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/db"
import { sendChaosEvent, createAnonId } from "@/lib/chaos-patch"

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { status } = await request.json()

    const taxReturn = await prisma.taxReturn.findUnique({
      where: { id: params.id },
    })

    if (!taxReturn) {
      return NextResponse.json({ error: "Tax return not found" }, { status: 404 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    // Status change permissions
    if (status === "READY_FOR_REVIEW" && taxReturn.userId !== session.user.id) {
      return NextResponse.json({ error: "Only the owner can submit for review" }, { status: 403 })
    }

    if (
      (status === "READY_FOR_EFILE" || status === "EFILE_SUBMITTED") &&
      user?.role !== "PREPARER" &&
      user?.role !== "ADMIN"
    ) {
      return NextResponse.json({ error: "Insufficient permissions" }, { status: 403 })
    }

    const updated = await prisma.taxReturn.update({
      where: { id: params.id },
      data: { status },
    })

    // Log audit
    await prisma.auditLog.create({
      data: {
        userId: session.user.id,
        taxReturnId: taxReturn.id,
        action: "STATUS_CHANGED",
        changedFields: { oldStatus: taxReturn.status, newStatus: status },
      },
    })

    // Send CHAOS event
    await sendChaosEvent({
      appId: "NEURA_TAX",
      eventType: "TAX_RETURN_STATUS_CHANGED",
      timestamp: new Date().toISOString(),
      userAnonId: createAnonId(session.user.id),
      payload: {
        taxReturnId: taxReturn.id,
        oldStatus: taxReturn.status,
        newStatus: status,
      },
    })

    return NextResponse.json(updated)
  } catch (error) {
    console.error("[Status Change Error]", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
