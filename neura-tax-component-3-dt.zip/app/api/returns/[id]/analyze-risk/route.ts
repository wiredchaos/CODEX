import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/db"
import { analyzeRiskFlags } from "@/lib/risk-engine"

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const taxReturn = await prisma.taxReturn.findUnique({
      where: { id: params.id },
    })

    if (!taxReturn) {
      return NextResponse.json({ error: "Tax return not found" }, { status: 404 })
    }

    // Check permissions
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    const canAnalyze = taxReturn.userId === session.user.id || user?.role === "PREPARER" || user?.role === "ADMIN"

    if (!canAnalyze) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Run risk analysis
    const flags = analyzeRiskFlags(taxReturn)

    // Delete old unresolved flags
    await prisma.riskFlag.deleteMany({
      where: {
        taxReturnId: taxReturn.id,
        resolved: false,
      },
    })

    // Create new flags
    const createdFlags = await Promise.all(
      flags.map((flag) =>
        prisma.riskFlag.create({
          data: {
            taxReturnId: taxReturn.id,
            code: flag.code,
            severity: flag.severity,
            description: flag.description,
            resolved: false,
          },
        }),
      ),
    )

    // Create audit log
    await prisma.auditLog.create({
      data: {
        taxReturnId: taxReturn.id,
        userId: session.user.id,
        action: "RISK_ANALYSIS_RUN",
        changedFields: { flagsFound: flags.length },
      },
    })

    return NextResponse.json({ success: true, flags: createdFlags })
  } catch (error) {
    console.error("[v0] Error analyzing risk:", error)
    return NextResponse.json({ error: "Failed to analyze risk" }, { status: 500 })
  }
}
