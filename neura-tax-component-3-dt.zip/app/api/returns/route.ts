import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/db"
import { sendChaosEvent, createAnonId } from "@/lib/chaos-patch"

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { taxYear } = await request.json()

    if (!taxYear || taxYear < 2000 || taxYear > new Date().getFullYear() + 1) {
      return NextResponse.json({ error: "Invalid tax year" }, { status: 400 })
    }

    // Check if return already exists for this year
    const existing = await prisma.taxReturn.findFirst({
      where: {
        userId: session.user.id,
        taxYear,
      },
    })

    if (existing) {
      return NextResponse.json({ error: "Tax return already exists for this year" }, { status: 400 })
    }

    // Create new tax return
    const taxReturn = await prisma.taxReturn.create({
      data: {
        userId: session.user.id,
        taxYear,
        status: "DRAFT",
        returnType: "US_1040",
        dataJson: {
          personalInfo: {},
          filingStatus: null,
          dependents: [],
          income: {},
          deductions: {},
        },
        summaryJson: null,
      },
    })

    // Log audit
    await prisma.auditLog.create({
      data: {
        userId: session.user.id,
        taxReturnId: taxReturn.id,
        action: "TAX_RETURN_CREATED",
        changedFields: { taxYear },
      },
    })

    // Send CHAOS event
    await sendChaosEvent({
      appId: "NEURA_TAX",
      eventType: "TAX_RETURN_CREATED",
      timestamp: new Date().toISOString(),
      userAnonId: createAnonId(session.user.id),
      payload: {
        taxYear,
        returnType: "US_1040",
      },
    })

    return NextResponse.json(taxReturn, { status: 201 })
  } catch (error) {
    console.error("[Create Return Error]", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    // Preparers and admins can see all returns
    const where = user?.role === "PREPARER" || user?.role === "ADMIN" ? {} : { userId: session.user.id }

    const returns = await prisma.taxReturn.findMany({
      where,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
      },
      orderBy: { updatedAt: "desc" },
    })

    return NextResponse.json(returns)
  } catch (error) {
    console.error("[Get Returns Error]", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
