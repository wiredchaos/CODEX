import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { calculateFMV, batchCalculateFMV } from "@/lib/fmv-calculator"
import { z } from "zod"

const fmvCalculationSchema = z.object({
  tokenSymbol: z.string(),
  chain: z.string(),
  quantity: z.number(),
  timestamp: z.string().datetime(),
})

const batchFmvSchema = z.object({
  transactions: z.array(fmvCalculationSchema),
})

// POST /api/ucl/fmv/calculate - Calculate FMV for a transaction
export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()

    // Check if batch or single calculation
    if (body.transactions) {
      const validated = batchFmvSchema.parse(body)
      const results = await batchCalculateFMV(
        validated.transactions.map((tx) => ({
          ...tx,
          chain: tx.chain as any,
          timestamp: new Date(tx.timestamp),
        })),
      )
      return NextResponse.json(results)
    } else {
      const validated = fmvCalculationSchema.parse(body)
      const result = await calculateFMV(
        validated.tokenSymbol,
        validated.chain as any,
        validated.quantity,
        new Date(validated.timestamp),
      )
      return NextResponse.json(result)
    }
  } catch (error) {
    console.error("[v0] Error calculating FMV:", error)
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: "Validation failed", details: error.errors }, { status: 400 })
    }
    return NextResponse.json({ error: "Failed to calculate FMV" }, { status: 500 })
  }
}
