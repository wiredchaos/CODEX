import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { logNftTransaction } from "@/lib/ucl-client"
import { z } from "zod"

const nftTransactionSchema = z.object({
  nftId: z.string(),
  tokenId: z.string().optional(),
  contractAddress: z.string(),
  chain: z.string(),
  timestamp: z.string().datetime(),
  eventType: z.string(),
  cryptoUsed: z.string().optional(),
  cryptoAmount: z.number().optional(),
  fmvUsd: z.number().optional(),
  costBasisUsd: z.number().optional(),
  description: z.string().optional(),
  patchSource: z.string().optional(),
  nftMetadata: z.any().optional(),
})

// POST /api/ucl/nft-transaction - Log an NFT transaction
export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const validated = nftTransactionSchema.parse(body)

    const transaction = await logNftTransaction({
      userId: session.user.id,
      ...validated,
      timestamp: new Date(validated.timestamp),
    })

    return NextResponse.json(transaction)
  } catch (error) {
    console.error("[v0] Error logging NFT transaction:", error)
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: "Validation failed", details: error.errors }, { status: 400 })
    }
    return NextResponse.json({ error: "Failed to log NFT transaction" }, { status: 500 })
  }
}

// GET /api/ucl/nft-transaction - Get NFT transactions
export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(req.url)
    const taxYear = searchParams.get("taxYear")

    if (!taxYear) {
      return NextResponse.json({ error: "taxYear parameter required" }, { status: 400 })
    }

    const { getNftTransactionsForYear } = await import("@/lib/ucl-client")
    const transactions = await getNftTransactionsForYear(session.user.id, Number.parseInt(taxYear))

    return NextResponse.json(transactions)
  } catch (error) {
    console.error("[v0] Error fetching NFT transactions:", error)
    return NextResponse.json({ error: "Failed to fetch transactions" }, { status: 500 })
  }
}
