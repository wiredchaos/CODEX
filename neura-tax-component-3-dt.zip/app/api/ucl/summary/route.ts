import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { calculateCryptoGainsLosses, calculateCryptoIncome } from "@/lib/ucl-client"

// GET /api/ucl/summary - Get crypto tax summary for a year
export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(req.url)
    const taxYear = searchParams.get("taxYear")

    if (!taxYear) {
      return NextResponse.json({ error: "taxYear parameter required" }, { status: 400 })
    }

    const year = Number.parseInt(taxYear)
    const [gainsLosses, income] = await Promise.all([
      calculateCryptoGainsLosses(session.user.id, year),
      calculateCryptoIncome(session.user.id, year),
    ])

    return NextResponse.json({
      taxYear: year,
      gainsLosses,
      income,
      summary: {
        totalCryptoIncome: income.totalIncome,
        netCapitalGainLoss: gainsLosses.netGainLoss,
        totalTransactions: gainsLosses.transactionCount + income.incomeCount,
        requiresScheduleD: gainsLosses.transactionCount > 0,
        requiresForm8949: gainsLosses.transactionCount > 0,
        requiresScheduleC: income.totalSelfEmploymentIncome > 0,
        requiresSchedule1: income.totalOrdinaryIncome > 0,
      },
    })
  } catch (error) {
    console.error("[v0] Error calculating crypto summary:", error)
    return NextResponse.json({ error: "Failed to calculate summary" }, { status: 500 })
  }
}
