import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { logCryptoTransaction } from "@/lib/ucl-client"
import { z } from "zod"

const cryptoTransactionSchema = z.object({
  txHash: z.string().optional(),
  chain: z.string(),
  timestamp: z.string().datetime(),
  eventType: z.string(),
  transactionType: z.string(),
  tokenSymbol: z.string(),
  tokenAddress: z.string().optional(),
  quantity: z.number(),
  fmvUsd: z.number().optional(),
  costBasisUsd: z.number().optional(),
  description: z.string().optional(),
  counterparty: z.string().optional(),
  patchSource: z.string().optional(),
  rawData: z.any().optional(),
})

// POST /api/ucl/crypto-transaction - Log a crypto transaction
export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const validated = cryptoTransactionSchema.parse(body)

    const transaction = await logCryptoTransaction({
      userId: session.user.id,
      ...validated,
      timestamp: new Date(validated.timestamp),
    })

    return NextResponse.json(transaction)
  } catch (error) {
    console.error("[v0] Error logging crypto transaction:", error)
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: "Validation failed", details: error.errors }, { status: 400 })
    }
    return NextResponse.json({ error: "Failed to log transaction" }, { status: 500 })
  }
}

// GET /api/ucl/crypto-transaction - Get crypto transactions
export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(req.url)
    const taxYear = searchParams.get("taxYear")

    if (!taxYear) {
      return NextResponse.json({ error: "taxYear parameter required" }, { status: 400 })
    }

    const { getCryptoTransactionsForYear } = await import("@/lib/ucl-client")
    const transactions = await getCryptoTransactionsForYear(session.user.id, Number.parseInt(taxYear))

    return NextResponse.json(transactions)
  } catch (error) {
    console.error("[v0] Error fetching crypto transactions:", error)
    return NextResponse.json({ error: "Failed to fetch transactions" }, { status: 500 })
  }
}
