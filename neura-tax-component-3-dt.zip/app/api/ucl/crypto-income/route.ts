import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { logCryptoIncome } from "@/lib/ucl-client"
import { z } from "zod"

const cryptoIncomeSchema = z.object({
  incomeType: z.string(),
  timestamp: z.string().datetime(),
  tokenSymbol: z.string(),
  tokenAddress: z.string().optional(),
  chain: z.string(),
  quantity: z.number(),
  fmvUsd: z.number(),
  incomeCategory: z.string(),
  description: z.string().optional(),
  source: z.string().optional(),
  patchSource: z.string().optional(),
})

// POST /api/ucl/crypto-income - Log crypto income
export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const validated = cryptoIncomeSchema.parse(body)

    const income = await logCryptoIncome({
      userId: session.user.id,
      ...validated,
      timestamp: new Date(validated.timestamp),
    })

    return NextResponse.json(income)
  } catch (error) {
    console.error("[v0] Error logging crypto income:", error)
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: "Validation failed", details: error.errors }, { status: 400 })
    }
    return NextResponse.json({ error: "Failed to log income" }, { status: 500 })
  }
}

// GET /api/ucl/crypto-income - Get crypto income
export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(req.url)
    const taxYear = searchParams.get("taxYear")

    if (!taxYear) {
      return NextResponse.json({ error: "taxYear parameter required" }, { status: 400 })
    }

    const { getCryptoIncomeForYear } = await import("@/lib/ucl-client")
    const income = await getCryptoIncomeForYear(session.user.id, Number.parseInt(taxYear))

    return NextResponse.json(income)
  } catch (error) {
    console.error("[v0] Error fetching crypto income:", error)
    return NextResponse.json({ error: "Failed to fetch income" }, { status: 500 })
  }
}
