import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertTriangle, ArrowLeft, FileText, Globe, Shield } from "lucide-react"

export default function DisclaimersPage() {
  return (
    <div className="min-h-screen bg-secondary/20">
      <div className="border-b bg-background">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button asChild variant="ghost" size="sm">
                <Link href="/">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Back to Home
                </Link>
              </Button>
              <div>
                <h1 className="text-2xl font-bold">Legal Disclaimers</h1>
                <p className="text-sm text-muted-foreground">Important information about our services</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="mx-auto max-w-4xl space-y-6">
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Please read these disclaimers carefully. By using NEURA TAX, you acknowledge and accept these terms.
            </AlertDescription>
          </Alert>

          {/* Global App Disclaimer */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <Shield className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Global App Disclaimer</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4 leading-relaxed text-sm text-muted-foreground">
              <p>
                <strong className="text-foreground">NEURA TAX</strong> is a tax preparation and document automation
                platform designed to assist with the preparation and organization of tax-related information. This
                platform is <strong className="text-foreground">not a substitute for professional tax advice</strong>.
              </p>

              <div className="space-y-2">
                <h4 className="font-semibold text-foreground">Important Notes:</h4>
                <ul className="list-inside list-disc space-y-1">
                  <li>This application does not provide legal, tax, or financial advice</li>
                  <li>All calculations and suggestions are for informational purposes only</li>
                  <li>Users are solely responsible for the accuracy of information provided</li>
                  <li>We recommend consulting with a licensed tax professional or CPA for complex situations</li>
                  <li>NEURA TAX is not affiliated with the IRS or any government agency</li>
                </ul>
              </div>

              <p className="font-medium text-foreground">
                By using this platform, you acknowledge that you are ultimately responsible for the accuracy and
                completeness of all information submitted to tax authorities.
              </p>
            </CardContent>
          </Card>

          {/* US E-File Disclaimer */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <FileText className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>US E-File Disclaimer</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4 leading-relaxed text-sm text-muted-foreground">
              <p>
                NEURA TAX provides electronic filing services for US tax returns through authorized third-party
                transmitters.
              </p>

              <div className="space-y-2">
                <h4 className="font-semibold text-foreground">E-File Terms:</h4>
                <ul className="list-inside list-disc space-y-1">
                  <li>
                    Electronic filing is subject to IRS acceptance. The IRS may accept or reject your return based on
                    their validation rules
                  </li>
                  <li>
                    Once submitted, returns cannot be recalled. You may need to file an amended return for corrections
                  </li>
                  <li>
                    E-file transmission does not guarantee accuracy of tax calculations or eligibility for deductions
                  </li>
                  <li>Processing times are controlled by the IRS and may vary based on filing season volume</li>
                  <li>Direct deposit refund timing is determined by the IRS, typically 10-21 days after acceptance</li>
                  <li>
                    You are responsible for reviewing your return before submission. NEURA TAX performs format
                    validation only
                  </li>
                </ul>
              </div>

              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription className="text-xs">
                  <strong>ERO Disclosure:</strong> NEURA TAX acts as an Authorized IRS e-file Provider. Our ERO ID,
                  EFIN, and CTEC ID are included in all e-file transmissions as required by IRS regulations.
                </AlertDescription>
              </Alert>

              <p className="font-medium text-foreground">
                You have the right to review your complete return before authorizing e-file submission. We recommend
                printing or saving a copy for your records.
              </p>
            </CardContent>
          </Card>

          {/* Non-US Document Prep Disclaimer */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <Globe className="h-5 w-5 text-primary" />
                </div>
                <CardTitle>Non-US Document Preparation Disclaimer</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4 leading-relaxed text-sm text-muted-foreground">
              <p>
                NEURA TAX offers document preparation services for non-US citizens and non-resident aliens. These
                services provide <strong className="text-foreground">document templates and guidance only</strong>.
              </p>

              <div className="space-y-2">
                <h4 className="font-semibold text-foreground">Non-US Service Limitations:</h4>
                <ul className="list-inside list-disc space-y-1">
                  <li>Electronic filing (e-file) is NOT available for non-resident tax documents</li>
                  <li>Documents must be printed, signed, and mailed to the IRS by the taxpayer</li>
                  <li>Tax treaty benefits vary by country and individual circumstances - consult a tax professional</li>
                  <li>
                    Form recommendations (1040-NR, W-8BEN, 8233, etc.) are suggestions based on provided information
                    only
                  </li>
                  <li>
                    Visa status and tax residency determinations are complex - professional advice is strongly
                    recommended
                  </li>
                  <li>State tax obligations for non-residents vary significantly by state</li>
                </ul>
              </div>

              <Alert className="bg-destructive/10 border-destructive/20">
                <AlertTriangle className="h-4 w-4 text-destructive" />
                <AlertDescription className="text-xs text-destructive">
                  <strong>Critical:</strong> Non-resident tax rules are highly complex and depend on individual
                  circumstances, treaty countries, visa types, and substantial presence calculations. We strongly
                  recommend consulting with an international tax specialist or CPA experienced in non-resident taxation.
                </AlertDescription>
              </Alert>

              <p className="font-medium text-foreground">
                NEURA TAX provides templates only. You are responsible for determining which forms apply to your
                situation and ensuring compliance with all US tax obligations.
              </p>
            </CardContent>
          </Card>

          {/* Data Privacy & Security */}
          <Card>
            <CardHeader>
              <CardTitle>Data Privacy & Security</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 leading-relaxed text-sm text-muted-foreground">
              <p>
                We take data security seriously and employ industry-standard encryption and security protocols to
                protect your sensitive tax information.
              </p>

              <div className="space-y-2">
                <h4 className="font-semibold text-foreground">Security Measures:</h4>
                <ul className="list-inside list-disc space-y-1">
                  <li>All data is encrypted in transit and at rest</li>
                  <li>Role-based access control limits who can view your information</li>
                  <li>Forensic audit logging tracks all system access and changes</li>
                  <li>Regular security audits and penetration testing</li>
                  <li>Compliance with IRS Publication 1075 data protection standards</li>
                </ul>
              </div>

              <p>
                However, no system is 100% secure. You are responsible for maintaining the confidentiality of your login
                credentials and logging out after each session.
              </p>
            </CardContent>
          </Card>

          {/* Acceptance */}
          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="pt-6">
              <p className="text-center text-sm leading-relaxed">
                <strong className="text-foreground">
                  By creating an account or using NEURA TAX services, you acknowledge that you have read, understood,
                  and accept these disclaimers in their entirety.
                </strong>
              </p>
              <p className="mt-4 text-center text-xs text-muted-foreground">
                Last updated: {new Date().toLocaleDateString("en-US", { month: "long", year: "numeric" })}
              </p>
            </CardContent>
          </Card>

          <div className="flex justify-center gap-4 pt-4">
            <Button asChild>
              <Link href="/auth/register">Accept & Create Account</Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/">Return to Home</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
