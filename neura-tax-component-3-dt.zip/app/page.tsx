import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { FileText, Shield, TrendingUp, Users } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative border-b bg-gradient-to-b from-background to-secondary/20 px-6 py-24 lg:px-8">
        <div className="mx-auto max-w-5xl">
          <div className="text-center">
            <h1 className="text-balance text-5xl font-bold tracking-tight lg:text-6xl">
              Intelligent Tax Preparation Architecture
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-pretty text-lg leading-relaxed text-muted-foreground">
              Professional tax return preparation, forensic audit tracking, and document automation. Built for accuracy,
              compliance, and peace of mind.
            </p>
            <div className="mt-10 flex items-center justify-center gap-4">
              <Button asChild size="lg">
                <Link href="/auth/signin">Get Started</Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link href="/legal/disclaimers">View Disclaimers</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="px-6 py-24 lg:px-8">
        <div className="mx-auto max-w-6xl">
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            <Card className="p-6">
              <FileText className="h-10 w-10 text-primary" />
              <h3 className="mt-4 font-semibold">US Tax Returns</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                Simplified 1040 workflow with W-2, 1099, and deduction tracking
              </p>
            </Card>

            <Card className="p-6">
              <Users className="h-10 w-10 text-primary" />
              <h3 className="mt-4 font-semibold">Non-US Preparation</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                Document packs for non-residents with treaty country support
              </p>
            </Card>

            <Card className="p-6">
              <Shield className="h-10 w-10 text-primary" />
              <h3 className="mt-4 font-semibold">Secure Data Handling</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                Encryption and secure protocols for your sensitive information
              </p>
            </Card>

            <Card className="p-6">
              <TrendingUp className="h-10 w-10 text-primary" />
              <h3 className="mt-4 font-semibold">Performance Metrics</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                Real-time analytics to track your preparation progress
              </p>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
