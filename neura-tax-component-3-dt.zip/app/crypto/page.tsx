import { Suspense } from "react"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { redirect } from "next/navigation"
import { CryptoOverview } from "@/components/crypto/crypto-overview"
import { CryptoTransactionsList } from "@/components/crypto/crypto-transactions-list"
import { NftTransactionsList } from "@/components/crypto/nft-transactions-list"
import { CryptoIncomeList } from "@/components/crypto/crypto-income-list"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Coins, FileText, ImageIcon } from "lucide-react"

export default async function CryptoPage() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect("/auth/signin")
  }

  const currentYear = new Date().getFullYear()

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Crypto Tax Center</h1>
        <p className="text-muted-foreground">
          Track all your crypto transactions, NFT activity, and income across the WIRED CHAOS META ecosystem
        </p>
      </div>

      <Suspense fallback={<div>Loading overview...</div>}>
        <CryptoOverview userId={session.user.id} taxYear={currentYear} />
      </Suspense>

      <div className="mt-8">
        <Tabs defaultValue="transactions" className="w-full">
          <TabsList className="grid w-full grid-cols-3 max-w-md">
            <TabsTrigger value="transactions" className="flex items-center gap-2">
              <Coins className="h-4 w-4" />
              Transactions
            </TabsTrigger>
            <TabsTrigger value="nfts" className="flex items-center gap-2">
              <ImageIcon className="h-4 w-4" />
              NFTs
            </TabsTrigger>
            <TabsTrigger value="income" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Income
            </TabsTrigger>
          </TabsList>

          <TabsContent value="transactions" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Crypto Transactions</CardTitle>
                <CardDescription>All crypto purchases, trades, and payments across all chains</CardDescription>
              </CardHeader>
              <CardContent>
                <Suspense fallback={<div>Loading transactions...</div>}>
                  <CryptoTransactionsList userId={session.user.id} taxYear={currentYear} />
                </Suspense>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="nfts" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>NFT Transactions</CardTitle>
                <CardDescription>Minting, purchasing, selling, and burning NFTs</CardDescription>
              </CardHeader>
              <CardContent>
                <Suspense fallback={<div>Loading NFT transactions...</div>}>
                  <NftTransactionsList userId={session.user.id} taxYear={currentYear} />
                </Suspense>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="income" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Crypto Income</CardTitle>
                <CardDescription>Rewards, airdrops, staking, and other crypto income</CardDescription>
              </CardHeader>
              <CardContent>
                <Suspense fallback={<div>Loading income...</div>}>
                  <CryptoIncomeList userId={session.user.id} taxYear={currentYear} />
                </Suspense>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
