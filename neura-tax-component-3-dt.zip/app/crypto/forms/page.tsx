import { Suspense } from "react"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { redirect } from "next/navigation"
import { CryptoFormsGenerator } from "@/components/crypto/crypto-forms-generator"

export default async function CryptoFormsPage() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect("/auth/signin")
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Generate IRS Forms</h1>
        <p className="text-muted-foreground">
          Automatically generate Form 8949, Schedule D, and Schedule 1 from your crypto transactions
        </p>
      </div>

      <Suspense fallback={<div>Loading form generator...</div>}>
        <CryptoFormsGenerator user={session.user} />
      </Suspense>
    </div>
  )
}
