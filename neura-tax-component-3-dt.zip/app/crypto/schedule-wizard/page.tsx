import { Suspense } from "react"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { redirect } from "next/navigation"
import { CryptoScheduleWizard } from "@/components/crypto/crypto-schedule-wizard"

export default async function CryptoScheduleWizardPage() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect("/auth/signin")
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Crypto Tax Schedule Wizard</h1>
        <p className="text-muted-foreground">
          Answer a few questions to determine which IRS forms and schedules you need for your crypto activity
        </p>
      </div>

      <Suspense fallback={<div>Loading wizard...</div>}>
        <CryptoScheduleWizard userId={session.user.id} />
      </Suspense>
    </div>
  )
}
