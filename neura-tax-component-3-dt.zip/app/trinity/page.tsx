import { TrinityEnvironment } from "@/components/trinity/trinity-environment"

export const metadata = {
  title: "WIRED CHAOS META - Trinity Core",
  description: "Spatial navigation layer for NEURA TAX and Artifact Terminal",
}

export default function TrinityPage() {
  return <TrinityEnvironment />
}
