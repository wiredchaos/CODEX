# NEURA TAX

**Intelligent Tax Preparation Architecture**

A production-ready tax preparation and document automation SaaS platform built with Next.js 14, TypeScript, and Prisma ORM.

## Features

- **US Tax Returns**: Simplified 1040 workflow with W-2, 1099-NEC/MISC/K, and deduction tracking
- **Non-US Document Preparation**: Wizard for non-residents with treaty country support and form recommendations
- **E-File Abstraction**: External vendor API integration with metadata tracking (ERO_ID, EFIN, CTEC_ID)
- **Forensic Risk Engine**: Automated risk flag detection with IRS audit probability analysis
- **Audit Trail**: Comprehensive logging of all changes, status updates, and user actions
- **Role-Based Access**: CLIENT, PREPARER, and ADMIN roles with granular permissions
- **CHAOS Patch Layer**: Optional silent integration with WIRED CHAOS META ecosystem

## Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Database**: PostgreSQL with Prisma ORM
- **Authentication**: NextAuth.js
- **Styling**: Tailwind CSS + shadcn/ui
- **Hosting**: Vercel

## Getting Started

### Prerequisites

- Node.js 18+
- PostgreSQL database
- npm or pnpm

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd neura-tax
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
```bash
cp .env.example .env
```

Edit `.env` with your configuration:
- `DATABASE_URL`: Your PostgreSQL connection string
- `NEXTAUTH_SECRET`: Generate with `openssl rand -base64 32`
- `NEXTAUTH_URL`: Your app URL (http://localhost:3000 for dev)
- E-file credentials (ERO_ID, EFIN, CTEC_ID)
- CHAOS patch settings (see below)

4. Run database migrations:
```bash
npx prisma generate
npx prisma db push
```

5. Start the development server:
```bash
npm run dev
```

6. Open [http://localhost:3000](http://localhost:3000) in your browser

## Database Schema

The application uses the following models:

- **User**: Authentication and role management (CLIENT | PREPARER | ADMIN)
- **TaxReturn**: US 1040 returns with JSON-based data storage
- **EfileSubmission**: E-file API request/response tracking
- **AuditLog**: Comprehensive change tracking for forensic analysis
- **RiskFlag**: Automated risk detection results (LOW | MEDIUM | HIGH)
- **NonUsPack**: Document preparation for non-residents

## User Roles & Permissions

### CLIENT
- Create and edit own tax returns (until marked "Ready for Review")
- View own submissions and status
- Access non-US document preparation

### PREPARER
- Access all tax returns
- Trigger e-file submissions
- Update return statuses
- Resolve risk flags
- View audit logs

### ADMIN
- All PREPARER permissions
- User management capabilities
- System configuration access

## Risk Engine

The forensic risk engine automatically analyzes tax returns for IRS audit triggers:

- Schedule C income without expenses → HIGH RISK
- Deductions >60% of income → HIGH RISK
- Large cash income (>$10,000) → MEDIUM RISK
- Home office without business use % → MEDIUM RISK
- High charitable contributions (>30% income) → MEDIUM RISK
- Round number amounts → LOW RISK
- Missing state information → LOW RISK

Flags can be reviewed and resolved by preparers/admins.

## E-File Integration

The app uses an abstraction layer for e-file vendors:

1. Configure your vendor credentials in `.env`
2. API client in `lib/efile-client.ts` handles submission
3. Metadata (ERO_ID, EFIN, CTEC_ID) is included in all requests
4. Raw request/response stored in database for compliance

**Note**: The e-file client is a placeholder. Implement vendor-specific authentication as needed.

## CHAOS Patch Layer (Optional)

NEURA TAX can optionally integrate with the WIRED CHAOS META ecosystem for anonymized event streaming.

### Configuration

Set these environment variables:

```env
CHAOS_PATCH_ENABLED="true"          # Enable/disable integration
CHAOS_PATCH_URL="<endpoint-url>"    # WIRED CHAOS event receiver
CHAOS_APP_ID="NEURA_TAX"            # Application identifier
CHAOS_FEN_ENDPOINT="<fen-url>"      # Optional FEN endpoint
```

### Events Streamed

When enabled, the following lifecycle events are sent (with anonymized user IDs):

- `USER_CREATED`: New user registration
- `TAX_RETURN_CREATED`: New return started
- `TAX_RETURN_STATUS_CHANGED`: Status updates
- `EFILE_SUBMITTED`: E-file submission
- `EFILE_ACCEPTED`: IRS acceptance
- `EFILE_REJECTED`: IRS rejection
- `NON_US_PACK_CREATED`: Non-US document creation

### Privacy

- User IDs are anonymized using base64 encoding
- No PII (names, emails, SSNs, income data) is sent
- Events contain only metadata and timestamps
- UI never displays WIRED CHAOS branding

### Standalone Mode

To run completely standalone:

```env
CHAOS_PATCH_ENABLED="false"
```

Or simply omit the CHAOS variables. The app functions identically either way.

## Project Structure

```
app/
├── api/
│   ├── auth/             # NextAuth + registration
│   ├── returns/          # Tax return CRUD + risk analysis
│   ├── efile/            # E-file submission + status
│   ├── non-us/           # Non-US document packs
│   └── risk-flags/       # Risk flag resolution
├── auth/                 # Sign in + registration pages
├── dashboard/            # Main user dashboard
├── returns/              # Tax return workflow
├── non-us/               # Non-US wizard
├── legal/                # Disclaimers
└── artifact-terminal/    # NTRU artifact exchange (separate system)

components/
├── returns/              # Tax workflow components
├── non-us/               # Non-US wizard components
└── ui/                   # shadcn/ui components

lib/
├── auth.ts               # NextAuth configuration
├── db.ts                 # Prisma client
├── chaos-patch.ts        # WIRED CHAOS META integration
├── efile-client.ts       # E-file vendor abstraction
├── risk-engine.ts        # Forensic risk analysis
└── validation.ts         # Zod schemas

prisma/
└── schema.prisma         # Database schema
```

## Legal Disclaimers

The application includes three required disclaimers:

1. **Global App Disclaimer**: General terms of use
2. **US E-File Disclaimer**: IRS e-file specific terms
3. **Non-US Document Prep Disclaimer**: Limitations for non-residents

Users must accept during registration. Timestamp stored in database.

## Development

### Running Prisma Studio

```bash
npx prisma studio
```

### Database Migrations

```bash
npx prisma migrate dev --name <migration-name>
```

### Type Generation

```bash
npx prisma generate
```

## Deployment

### Vercel (Recommended)

1. Connect your GitHub repository to Vercel
2. Set environment variables in Vercel dashboard
3. Deploy

### Environment Variables to Set

- All variables from `.env.example`
- Ensure `NEXTAUTH_URL` matches your production domain
- Set strong `NEXTAUTH_SECRET` in production

## Additional Systems

### NEURA Artifact Terminal

The project includes a separate NTRU artifact exchange interface at `/artifact-terminal`. This is part of the broader Neteru Apinaya ecosystem and includes:

- 404 Dynamic NFT visualization
- Two-path exchange system (Basic vs NTRU-Fueled)
- Echo Engineer tools
- Weekly mutation cycle tracking

This system is independent of the tax application and runs in parallel.

## License

All rights reserved.

## Support

For issues or questions, contact your system administrator.
```

```typescript file="" isHidden
