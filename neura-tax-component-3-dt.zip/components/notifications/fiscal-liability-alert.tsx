"use client"

import { AlertTriangle, X } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { useState } from "react"

type FiscalLiabilityAlertProps = {
  trigger: {
    id: string
    severity: string
    taxYear: number
    liabilityEstimate: number
    category: string
    detailsJson: any
  }
  onDismiss?: () => void
}

export function FiscalLiabilityAlert({ trigger, onDismiss }: FiscalLiabilityAlertProps) {
  const [dismissed, setDismissed] = useState(false)

  const severityColors = {
    LOW: "border-blue-500/60 bg-blue-500/10 text-blue-100",
    MEDIUM: "border-yellow-500/60 bg-yellow-500/10 text-yellow-100",
    HIGH: "border-orange-500/60 bg-orange-500/10 text-orange-100",
    CRITICAL: "border-red-500/60 bg-red-500/10 text-red-100",
  }

  const severityIcons = {
    LOW: "text-blue-400",
    MEDIUM: "text-yellow-400",
    HIGH: "text-orange-400",
    CRITICAL: "text-red-400",
  }

  if (dismissed) return null

  const handleDismiss = () => {
    setDismissed(true)
    onDismiss?.()
  }

  return (
    <Alert className={`relative ${severityColors[trigger.severity as keyof typeof severityColors]}`}>
      <AlertTriangle className={`h-5 w-5 ${severityIcons[trigger.severity as keyof typeof severityIcons]}`} />
      <AlertTitle className="flex items-center justify-between pr-8">
        <span>
          Fiscal Liability Alert ({trigger.severity}) - Tax Year {trigger.taxYear}
        </span>
        <Button
          variant="ghost"
          size="sm"
          className="absolute right-2 top-2 h-6 w-6 p-0 hover:bg-white/10"
          onClick={handleDismiss}
        >
          <X className="h-4 w-4" />
        </Button>
      </AlertTitle>
      <AlertDescription className="mt-2 space-y-2">
        <p>
          We've detected a potential tax liability for tax year {trigger.taxYear}. Estimated exposure:{" "}
          <span className="font-semibold">
            $
            {trigger.liabilityEstimate.toLocaleString(undefined, {
              minimumFractionDigits: 0,
              maximumFractionDigits: 0,
            })}
          </span>
          .
        </p>
        {trigger.detailsJson?.reasons && (
          <ul className="ml-4 mt-2 list-disc space-y-1 text-xs opacity-90">
            {trigger.detailsJson.reasons.map((reason: any, idx: number) => (
              <li key={idx}>{reason.reason}</li>
            ))}
          </ul>
        )}
        <p className="mt-3 text-xs opacity-80">
          <strong>Disclaimer:</strong> This is an estimate only and does not represent final tax due. Always confirm
          with a licensed tax professional before filing.
        </p>
      </AlertDescription>
    </Alert>
  )
}
