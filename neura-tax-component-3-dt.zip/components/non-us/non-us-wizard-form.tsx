"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Textarea } from "@/components/ui/textarea"
import { Loader2 } from "lucide-react"

interface NonUsWizardFormProps {
  onCancel: () => void
}

export default function NonUsWizardForm({ onCancel }: NonUsWizardFormProps) {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")
  const [formData, setFormData] = useState({
    residencyInfo: {
      country: "",
      visaType: "",
      residencyStatus: "NON_RESIDENT",
    },
    personalInfo: {
      fullName: "",
      dateOfBirth: "",
      passportNumber: "",
    },
    usIncome: {
      hasUsIncome: false,
      incomeType: "",
      estimatedAmount: 0,
    },
    treatyInfo: {
      hasTreatyBenefit: false,
      treatyCountry: "",
      articleNumber: "",
    },
    additionalNotes: "",
  })

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError("")
    setIsSubmitting(true)

    try {
      // Determine recommended forms based on input
      const recommendedForms = []

      if (formData.residencyInfo.residencyStatus === "NON_RESIDENT") {
        recommendedForms.push("Form 1040-NR")
      }

      if (formData.treatyInfo.hasTreatyBenefit) {
        recommendedForms.push("Form W-8BEN")
      }

      if (formData.usIncome.hasUsIncome) {
        if (formData.usIncome.incomeType === "SELF_EMPLOYMENT") {
          recommendedForms.push("Form 8233")
        }
        recommendedForms.push("Schedule NEC")
      }

      if (["F-1", "J-1", "M-1", "Q-1"].includes(formData.residencyInfo.visaType)) {
        recommendedForms.push("Form 8843")
      }

      const response = await fetch("/api/non-us", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          dataJson: {
            ...formData,
            recommendedForms,
            generatedAt: new Date().toISOString(),
          },
        }),
      })

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.error || "Failed to create document pack")
      }

      router.refresh()
      onCancel()
    } catch (err: any) {
      setError(err.message || "An error occurred")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="mx-auto max-w-3xl space-y-6">
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Residency Information</CardTitle>
          <CardDescription>Tell us about your residency status</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="country">Country of Residence</Label>
            <Input
              id="country"
              value={formData.residencyInfo.country}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  residencyInfo: { ...formData.residencyInfo, country: e.target.value },
                })
              }
              placeholder="e.g., India, China, Canada"
              required
              disabled={isSubmitting}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="visaType">US Visa Type (if applicable)</Label>
            <Select
              value={formData.residencyInfo.visaType}
              onValueChange={(value) =>
                setFormData({
                  ...formData,
                  residencyInfo: { ...formData.residencyInfo, visaType: value },
                })
              }
              disabled={isSubmitting}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select visa type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="F-1">F-1 (Student)</SelectItem>
                <SelectItem value="J-1">J-1 (Exchange Visitor)</SelectItem>
                <SelectItem value="H-1B">H-1B (Temporary Worker)</SelectItem>
                <SelectItem value="L-1">L-1 (Intracompany Transfer)</SelectItem>
                <SelectItem value="O-1">O-1 (Extraordinary Ability)</SelectItem>
                <SelectItem value="B-1/B-2">B-1/B-2 (Tourist/Business)</SelectItem>
                <SelectItem value="OTHER">Other</SelectItem>
                <SelectItem value="NONE">No US Visa</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="residencyStatus">Tax Residency Status</Label>
            <Select
              value={formData.residencyInfo.residencyStatus}
              onValueChange={(value) =>
                setFormData({
                  ...formData,
                  residencyInfo: { ...formData.residencyInfo, residencyStatus: value },
                })
              }
              disabled={isSubmitting}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="NON_RESIDENT">Non-Resident Alien</SelectItem>
                <SelectItem value="RESIDENT">Resident Alien</SelectItem>
                <SelectItem value="DUAL_STATUS">Dual-Status</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              Determined by substantial presence test or green card status
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Personal Information</CardTitle>
          <CardDescription>Basic identification information</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="fullName">Full Name (as on passport)</Label>
            <Input
              id="fullName"
              value={formData.personalInfo.fullName}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  personalInfo: { ...formData.personalInfo, fullName: e.target.value },
                })
              }
              required
              disabled={isSubmitting}
            />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="dateOfBirth">Date of Birth</Label>
              <Input
                id="dateOfBirth"
                type="date"
                value={formData.personalInfo.dateOfBirth}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    personalInfo: { ...formData.personalInfo, dateOfBirth: e.target.value },
                  })
                }
                required
                disabled={isSubmitting}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="passportNumber">Passport Number</Label>
              <Input
                id="passportNumber"
                value={formData.personalInfo.passportNumber}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    personalInfo: { ...formData.personalInfo, passportNumber: e.target.value },
                  })
                }
                required
                disabled={isSubmitting}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>US Income Information</CardTitle>
          <CardDescription>Income earned in or from the United States</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="hasUsIncome">Do you have US-sourced income?</Label>
            <Select
              value={formData.usIncome.hasUsIncome ? "YES" : "NO"}
              onValueChange={(value) =>
                setFormData({
                  ...formData,
                  usIncome: { ...formData.usIncome, hasUsIncome: value === "YES" },
                })
              }
              disabled={isSubmitting}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="YES">Yes</SelectItem>
                <SelectItem value="NO">No</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {formData.usIncome.hasUsIncome && (
            <>
              <div className="space-y-2">
                <Label htmlFor="incomeType">Type of US Income</Label>
                <Select
                  value={formData.usIncome.incomeType}
                  onValueChange={(value) =>
                    setFormData({
                      ...formData,
                      usIncome: { ...formData.usIncome, incomeType: value },
                    })
                  }
                  disabled={isSubmitting}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select income type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="WAGES">Wages/Salary</SelectItem>
                    <SelectItem value="SELF_EMPLOYMENT">Self-Employment/Contract</SelectItem>
                    <SelectItem value="INVESTMENT">Investment Income</SelectItem>
                    <SelectItem value="SCHOLARSHIP">Scholarship/Fellowship</SelectItem>
                    <SelectItem value="OTHER">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="estimatedAmount">Estimated Annual Amount (USD)</Label>
                <Input
                  id="estimatedAmount"
                  type="number"
                  value={formData.usIncome.estimatedAmount}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      usIncome: {
                        ...formData.usIncome,
                        estimatedAmount: Number.parseFloat(e.target.value) || 0,
                      },
                    })
                  }
                  placeholder="0.00"
                  disabled={isSubmitting}
                />
              </div>
            </>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Tax Treaty Information</CardTitle>
          <CardDescription>Benefits under US tax treaties</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="hasTreatyBenefit">Do you claim tax treaty benefits?</Label>
            <Select
              value={formData.treatyInfo.hasTreatyBenefit ? "YES" : "NO"}
              onValueChange={(value) =>
                setFormData({
                  ...formData,
                  treatyInfo: { ...formData.treatyInfo, hasTreatyBenefit: value === "YES" },
                })
              }
              disabled={isSubmitting}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="YES">Yes</SelectItem>
                <SelectItem value="NO">No</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {formData.treatyInfo.hasTreatyBenefit && (
            <>
              <div className="space-y-2">
                <Label htmlFor="treatyCountry">Treaty Country</Label>
                <Input
                  id="treatyCountry"
                  value={formData.treatyInfo.treatyCountry}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      treatyInfo: { ...formData.treatyInfo, treatyCountry: e.target.value },
                    })
                  }
                  placeholder="e.g., India, China"
                  disabled={isSubmitting}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="articleNumber">Treaty Article Number (if known)</Label>
                <Input
                  id="articleNumber"
                  value={formData.treatyInfo.articleNumber}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      treatyInfo: { ...formData.treatyInfo, articleNumber: e.target.value },
                    })
                  }
                  placeholder="e.g., Article 21"
                  disabled={isSubmitting}
                />
              </div>
            </>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Additional Notes</CardTitle>
          <CardDescription>Any other relevant information</CardDescription>
        </CardHeader>
        <CardContent>
          <Textarea
            value={formData.additionalNotes}
            onChange={(e) => setFormData({ ...formData, additionalNotes: e.target.value })}
            placeholder="Include any special circumstances, questions, or notes for your tax professional..."
            rows={4}
            disabled={isSubmitting}
          />
        </CardContent>
      </Card>

      <div className="flex gap-3">
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Creating...
            </>
          ) : (
            "Create Document Pack"
          )}
        </Button>
        <Button type="button" variant="outline" onClick={onCancel} disabled={isSubmitting}>
          Cancel
        </Button>
      </div>
    </form>
  )
}
