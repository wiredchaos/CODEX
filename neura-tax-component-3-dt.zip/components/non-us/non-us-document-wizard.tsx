"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle, Download, FileText, Plus } from "lucide-react"
import { format } from "date-fns"
import NonUsWizardForm from "./non-us-wizard-form"

interface NonUsDocumentWizardProps {
  existingPacks: any[]
}

export default function NonUsDocumentWizard({ existingPacks }: NonUsDocumentWizardProps) {
  const [showWizard, setShowWizard] = useState(false)
  const router = useRouter()

  function handleDownload(pack: any) {
    const dataStr = JSON.stringify(pack.dataJson, null, 2)
    const dataBlob = new Blob([dataStr], { type: "application/json" })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement("a")
    link.href = url
    link.download = `non-us-document-pack-${format(new Date(pack.createdAt), "yyyy-MM-dd")}.json`
    link.click()
    URL.revokeObjectURL(url)
  }

  if (showWizard) {
    return <NonUsWizardForm onCancel={() => setShowWizard(false)} />
  }

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          <strong>Important:</strong> Non-US document preparation does NOT include e-filing. Documents must be printed,
          signed, and mailed to the IRS. We strongly recommend consulting with an international tax specialist.
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Your Document Packs</CardTitle>
              <CardDescription>Manage your non-US tax document preparations</CardDescription>
            </div>
            <Button onClick={() => setShowWizard(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Create New Pack
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {existingPacks.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <FileText className="h-12 w-12 text-muted-foreground" />
              <h3 className="mt-4 font-semibold">No document packs yet</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Create your first non-US document pack to get started
              </p>
              <Button onClick={() => setShowWizard(true)} className="mt-6">
                <Plus className="mr-2 h-4 w-4" />
                Create Document Pack
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {existingPacks.map((pack) => (
                <div key={pack.id} className="flex items-center justify-between rounded-lg border bg-card p-4">
                  <div>
                    <div className="flex items-center gap-3">
                      <h3 className="font-semibold">{pack.dataJson.residencyInfo?.country || "Unknown Country"}</h3>
                      <Badge variant="outline">{pack.documentType}</Badge>
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">
                      Created: {format(new Date(pack.createdAt), "MMM d, yyyy")}
                    </p>
                    {pack.dataJson.recommendedForms && (
                      <div className="mt-2 flex flex-wrap gap-1">
                        {pack.dataJson.recommendedForms.map((form: string) => (
                          <Badge key={form} variant="secondary" className="text-xs">
                            {form}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                  <Button onClick={() => handleDownload(pack)} variant="outline" size="sm">
                    <Download className="mr-2 h-4 w-4" />
                    Download JSON
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>About Non-US Document Preparation</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-sm leading-relaxed text-muted-foreground">
          <p>
            This service helps non-US citizens and non-resident aliens organize information needed for US tax filing. We
            generate a JSON document pack with your information and recommend applicable forms.
          </p>

          <div>
            <h4 className="font-semibold text-foreground mb-2">Commonly Recommended Forms:</h4>
            <ul className="list-inside list-disc space-y-1">
              <li>
                <strong className="text-foreground">Form 1040-NR</strong> - US Nonresident Alien Income Tax Return
              </li>
              <li>
                <strong className="text-foreground">Form W-8BEN</strong> - Certificate of Foreign Status of Beneficial
                Owner
              </li>
              <li>
                <strong className="text-foreground">Form 8233</strong> - Exemption From Withholding on Compensation for
                Independent Services
              </li>
              <li>
                <strong className="text-foreground">Form 8843</strong> - Statement for Exempt Individuals
              </li>
            </ul>
          </div>

          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription className="text-xs">
              Form recommendations are suggestions only. Actual requirements depend on your specific situation, visa
              type, treaty country, and substantial presence test results. Professional advice is strongly recommended.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    </div>
  )
}
