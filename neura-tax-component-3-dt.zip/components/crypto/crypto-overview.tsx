import { calculateCryptoGainsLosses, calculateCryptoIncome } from "@/lib/ucl-client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, TrendingDown, DollarSign, FileText } from "lucide-react"

type CryptoOverviewProps = {
  userId: string
  taxYear: number
}

export async function CryptoOverview({ userId, taxYear }: CryptoOverviewProps) {
  const [gainsLosses, income] = await Promise.all([
    calculateCryptoGainsLosses(userId, taxYear),
    calculateCryptoIncome(userId, taxYear),
  ])

  const stats = [
    {
      title: "Total Crypto Income",
      value: `$${income.totalIncome.toFixed(2)}`,
      description: `${income.incomeCount} income events`,
      icon: DollarSign,
      trend: income.totalIncome > 0 ? "positive" : "neutral",
    },
    {
      title: "Capital Gains",
      value: `$${gainsLosses.totalGains.toFixed(2)}`,
      description: "From dispositions",
      icon: TrendingUp,
      trend: "positive",
    },
    {
      title: "Capital Losses",
      value: `$${gainsLosses.totalLosses.toFixed(2)}`,
      description: "From dispositions",
      icon: TrendingDown,
      trend: "negative",
    },
    {
      title: "Net Gain/Loss",
      value: `$${gainsLosses.netGainLoss.toFixed(2)}`,
      description: `${gainsLosses.transactionCount} transactions`,
      icon: FileText,
      trend: gainsLosses.netGainLoss >= 0 ? "positive" : "negative",
    },
  ]

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <Card key={stat.title}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
            <stat.icon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div
              className={`text-2xl font-bold ${
                stat.trend === "positive" ? "text-green-600" : stat.trend === "negative" ? "text-red-600" : ""
              }`}
            >
              {stat.value}
            </div>
            <p className="text-xs text-muted-foreground mt-1">{stat.description}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
