"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { FileText, Download, Loader2, CheckCircle2 } from "lucide-react"

type CryptoFormsGeneratorProps = {
  user: {
    id: string
    name?: string | null
    email?: string | null
  }
}

export function CryptoFormsGenerator({ user }: CryptoFormsGeneratorProps) {
  const [taxYear, setTaxYear] = useState(new Date().getFullYear().toString())
  const [taxpayerName, setTaxpayerName] = useState(user.name || "")
  const [ssn, setSsn] = useState("")
  const [selectedForms, setSelectedForms] = useState<string[]>(["8949", "schedule-d"])
  const [loading, setLoading] = useState(false)
  const [generatedForms, setGeneratedForms] = useState<any>(null)

  const handleFormToggle = (formId: string) => {
    setSelectedForms((prev) => (prev.includes(formId) ? prev.filter((f) => f !== formId) : [...prev, formId]))
  }

  const handleGenerate = async () => {
    setLoading(true)
    setGeneratedForms(null)

    try {
      const response = await fetch("/api/crypto/forms/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          taxYear: Number.parseInt(taxYear),
          taxpayerName,
          ssn,
          forms: selectedForms,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to generate forms")
      }

      const data = await response.json()
      setGeneratedForms(data)
    } catch (error) {
      console.error("[v0] Error generating forms:", error)
      alert("Failed to generate forms. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  const handleDownload = (formType: string) => {
    if (!generatedForms) return

    const data = generatedForms[formType]
    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: "application/json",
    })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${formType}-${taxYear}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Form Information</CardTitle>
          <CardDescription>Enter your information to generate IRS forms</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="taxYear">Tax Year</Label>
              <Input
                id="taxYear"
                type="number"
                value={taxYear}
                onChange={(e) => setTaxYear(e.target.value)}
                placeholder="2024"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="taxpayerName">Taxpayer Name</Label>
              <Input
                id="taxpayerName"
                value={taxpayerName}
                onChange={(e) => setTaxpayerName(e.target.value)}
                placeholder="John Doe"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="ssn">Social Security Number</Label>
            <Input
              id="ssn"
              type="password"
              value={ssn}
              onChange={(e) => setSsn(e.target.value)}
              placeholder="XXX-XX-XXXX"
              maxLength={11}
            />
            <p className="text-xs text-muted-foreground">
              Your SSN is only used for form generation and is never stored
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Select Forms to Generate</CardTitle>
          <CardDescription>Choose which IRS forms you need</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-start space-x-3">
            <Checkbox
              id="form-8949"
              checked={selectedForms.includes("8949")}
              onCheckedChange={() => handleFormToggle("8949")}
            />
            <div className="space-y-1">
              <Label htmlFor="form-8949" className="font-medium cursor-pointer">
                Form 8949 - Sales and Other Dispositions of Capital Assets
              </Label>
              <p className="text-sm text-muted-foreground">
                Required for reporting crypto and NFT sales, trades, and dispositions
              </p>
            </div>
          </div>

          <div className="flex items-start space-x-3">
            <Checkbox
              id="schedule-d"
              checked={selectedForms.includes("schedule-d")}
              onCheckedChange={() => handleFormToggle("schedule-d")}
            />
            <div className="space-y-1">
              <Label htmlFor="schedule-d" className="font-medium cursor-pointer">
                Schedule D - Capital Gains and Losses
              </Label>
              <p className="text-sm text-muted-foreground">Summary of capital gains and losses from Form 8949</p>
            </div>
          </div>

          <div className="flex items-start space-x-3">
            <Checkbox
              id="schedule-1"
              checked={selectedForms.includes("schedule-1")}
              onCheckedChange={() => handleFormToggle("schedule-1")}
            />
            <div className="space-y-1">
              <Label htmlFor="schedule-1" className="font-medium cursor-pointer">
                Schedule 1 - Additional Income (Crypto Section)
              </Label>
              <p className="text-sm text-muted-foreground">Report crypto rewards, airdrops, and other income</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Button
        onClick={handleGenerate}
        disabled={loading || selectedForms.length === 0 || !taxpayerName || !ssn}
        className="w-full"
        size="lg"
      >
        {loading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Generating Forms...
          </>
        ) : (
          <>
            <FileText className="mr-2 h-4 w-4" />
            Generate Forms
          </>
        )}
      </Button>

      {generatedForms && (
        <Alert className="border-green-200 bg-green-50 dark:border-green-900 dark:bg-green-950">
          <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
          <AlertTitle className="text-green-900 dark:text-green-100">Forms Generated Successfully</AlertTitle>
          <AlertDescription className="text-green-800 dark:text-green-200">
            Your IRS forms have been generated. Download them below and attach to your tax return.
          </AlertDescription>
        </Alert>
      )}

      {generatedForms && (
        <div className="space-y-4">
          {generatedForms.form8949 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Form 8949</CardTitle>
                <CardDescription>{generatedForms.form8949.shortTermTransactions.length} transactions</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Total Proceeds:</span>
                    <p className="font-semibold">${generatedForms.form8949.shortTermTotals.totalProceeds.toFixed(2)}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Total Cost Basis:</span>
                    <p className="font-semibold">
                      ${generatedForms.form8949.shortTermTotals.totalCostBasis.toFixed(2)}
                    </p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Net Gain/Loss:</span>
                    <p
                      className={`font-semibold ${
                        generatedForms.form8949.shortTermTotals.totalGainLoss >= 0 ? "text-green-600" : "text-red-600"
                      }`}
                    >
                      ${generatedForms.form8949.shortTermTotals.totalGainLoss.toFixed(2)}
                    </p>
                  </div>
                </div>
                <Button variant="outline" onClick={() => handleDownload("form8949")} className="w-full">
                  <Download className="mr-2 h-4 w-4" />
                  Download Form 8949
                </Button>
              </CardContent>
            </Card>
          )}

          {generatedForms.scheduleD && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Schedule D</CardTitle>
                <CardDescription>Capital Gains and Losses Summary</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Short-Term Gain/Loss:</span>
                    <p className="font-semibold">${generatedForms.scheduleD.shortTermGainLoss.toFixed(2)}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Long-Term Gain/Loss:</span>
                    <p className="font-semibold">${generatedForms.scheduleD.longTermGainLoss.toFixed(2)}</p>
                  </div>
                  <div className="col-span-2">
                    <span className="text-muted-foreground">Net Capital Gain/Loss:</span>
                    <p
                      className={`text-lg font-bold ${
                        generatedForms.scheduleD.netCapitalGainLoss >= 0 ? "text-green-600" : "text-red-600"
                      }`}
                    >
                      ${generatedForms.scheduleD.netCapitalGainLoss.toFixed(2)}
                    </p>
                  </div>
                </div>
                <Button variant="outline" onClick={() => handleDownload("scheduleD")} className="w-full">
                  <Download className="mr-2 h-4 w-4" />
                  Download Schedule D
                </Button>
              </CardContent>
            </Card>
          )}

          {generatedForms.schedule1 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Schedule 1 - Crypto Income</CardTitle>
                <CardDescription>Additional Income from Cryptocurrency</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Rewards:</span>
                    <span className="font-semibold">
                      ${generatedForms.schedule1.incomeBreakdown.rewards.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Airdrops:</span>
                    <span className="font-semibold">
                      ${generatedForms.schedule1.incomeBreakdown.airdrops.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Staking:</span>
                    <span className="font-semibold">
                      ${generatedForms.schedule1.incomeBreakdown.staking.toFixed(2)}
                    </span>
                  </div>
                  <Separator />
                  <div className="flex justify-between">
                    <span className="font-medium">Total Additional Income:</span>
                    <span className="text-lg font-bold text-green-600">
                      ${generatedForms.schedule1.totalAdditionalIncome.toFixed(2)}
                    </span>
                  </div>
                </div>
                <Button variant="outline" onClick={() => handleDownload("schedule1")} className="w-full">
                  <Download className="mr-2 h-4 w-4" />
                  Download Schedule 1
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  )
}
