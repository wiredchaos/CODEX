import { getCryptoTransactionsForYear } from "@/lib/ucl-client"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

type CryptoTransactionsListProps = {
  userId: string
  taxYear: number
}

export async function CryptoTransactionsList({ userId, taxYear }: CryptoTransactionsListProps) {
  const transactions = await getCryptoTransactionsForYear(userId, taxYear)

  if (transactions.length === 0) {
    return <div className="text-center py-8 text-muted-foreground">No crypto transactions recorded for {taxYear}</div>
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Date</TableHead>
            <TableHead>Type</TableHead>
            <TableHead>Token</TableHead>
            <TableHead>Chain</TableHead>
            <TableHead className="text-right">Quantity</TableHead>
            <TableHead className="text-right">FMV (USD)</TableHead>
            <TableHead className="text-right">Gain/Loss</TableHead>
            <TableHead>Source</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {transactions.map((tx) => (
            <TableRow key={tx.id}>
              <TableCell className="text-sm">{format(new Date(tx.timestamp), "MMM d, yyyy")}</TableCell>
              <TableCell>
                <Badge variant="outline" className="text-xs">
                  {tx.eventType}
                </Badge>
              </TableCell>
              <TableCell className="font-medium">{tx.tokenSymbol}</TableCell>
              <TableCell>
                <Badge variant="secondary" className="text-xs">
                  {tx.chain}
                </Badge>
              </TableCell>
              <TableCell className="text-right font-mono text-sm">
                {Number.parseFloat(tx.quantity.toString()).toFixed(4)}
              </TableCell>
              <TableCell className="text-right font-mono text-sm">
                {tx.fmvUsd ? `$${Number.parseFloat(tx.fmvUsd.toString()).toFixed(2)}` : "-"}
              </TableCell>
              <TableCell className="text-right font-mono text-sm">
                {tx.gainLossUsd ? (
                  <span
                    className={Number.parseFloat(tx.gainLossUsd.toString()) >= 0 ? "text-green-600" : "text-red-600"}
                  >
                    ${Number.parseFloat(tx.gainLossUsd.toString()).toFixed(2)}
                  </span>
                ) : (
                  "-"
                )}
              </TableCell>
              <TableCell className="text-xs text-muted-foreground">{tx.patchSource || "Manual"}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
