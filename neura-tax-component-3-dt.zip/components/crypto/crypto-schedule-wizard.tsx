"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { CheckCircle2, AlertCircle, FileText, ArrowRight, ArrowLeft } from "lucide-react"

type ScheduleRecommendation = {
  schedule: string
  title: string
  description: string
  required: boolean
  reason: string
}

type CryptoScheduleWizardProps = {
  userId: string
}

export function CryptoScheduleWizard({ userId }: CryptoScheduleWizardProps) {
  const [step, setStep] = useState(1)
  const [answers, setAnswers] = useState({
    hadCryptoTransactions: false,
    earnedCryptoIncome: false,
    mintedOrBoughtNfts: false,
    soldCryptoOrNfts: false,
    receivedAirdrops: false,
    stakedOrMined: false,
    usedCryptoForPurchases: false,
    crossChainActivity: false,
    foreignExchanges: false,
    businessActivity: false,
  })
  const [recommendations, setRecommendations] = useState<ScheduleRecommendation[]>([])
  const [loading, setLoading] = useState(false)

  const currentYear = new Date().getFullYear()

  const handleAnswerChange = (key: keyof typeof answers, value: boolean) => {
    setAnswers((prev) => ({ ...prev, [key]: value }))
  }

  const calculateRecommendations = () => {
    const recs: ScheduleRecommendation[] = []

    // Schedule D - Capital Gains and Losses
    if (answers.soldCryptoOrNfts || answers.usedCryptoForPurchases) {
      recs.push({
        schedule: "Schedule D",
        title: "Capital Gains and Losses",
        description: "Required when you sell, trade, or use crypto for purchases",
        required: true,
        reason: "You disposed of cryptocurrency or NFTs during the tax year",
      })
    }

    // Form 8949 - Sales and Dispositions of Capital Assets
    if (answers.soldCryptoOrNfts || answers.usedCryptoForPurchases) {
      recs.push({
        schedule: "Form 8949",
        title: "Sales and Other Dispositions of Capital Assets",
        description: "Detailed breakdown of each crypto transaction",
        required: true,
        reason: "Required to report each individual crypto disposition",
      })
    }

    // Schedule 1 - Additional Income
    if (answers.earnedCryptoIncome || answers.receivedAirdrops) {
      recs.push({
        schedule: "Schedule 1",
        title: "Additional Income and Adjustments to Income",
        description: "Report crypto rewards, airdrops, and other income",
        required: true,
        reason: "You received crypto as income (not from sales)",
      })
    }

    // Schedule C - Business Income
    if (answers.businessActivity || answers.stakedOrMined) {
      recs.push({
        schedule: "Schedule C",
        title: "Profit or Loss from Business",
        description: "Required if you mine, stake, or run crypto as a business",
        required: answers.businessActivity,
        reason: "Crypto activity may qualify as self-employment",
      })
    }

    // FBAR - Foreign Bank Account Report
    if (answers.foreignExchanges) {
      recs.push({
        schedule: "FBAR (FinCEN 114)",
        title: "Foreign Bank Account Report",
        description: "Required if foreign exchange balances exceeded $10,000",
        required: false,
        reason: "You may need to report foreign crypto exchange accounts",
      })
    }

    // Form 8938 - Foreign Financial Assets
    if (answers.foreignExchanges) {
      recs.push({
        schedule: "Form 8938",
        title: "Statement of Specified Foreign Financial Assets",
        description: "Report foreign crypto assets if thresholds are met",
        required: false,
        reason: "Foreign crypto holdings may need to be reported",
      })
    }

    // If no activity at all
    if (recs.length === 0 && answers.hadCryptoTransactions) {
      recs.push({
        schedule: "Form 1040",
        title: "Digital Asset Question",
        description: "You must answer 'Yes' to the digital asset question",
        required: true,
        reason: "All taxpayers must answer the crypto question on Form 1040",
      })
    }

    setRecommendations(recs)
  }

  const renderStep1 = () => (
    <Card>
      <CardHeader>
        <CardTitle>General Crypto Activity</CardTitle>
        <CardDescription>Tell us about your crypto activity in {currentYear}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center space-x-2">
          <Checkbox
            id="hadCryptoTransactions"
            checked={answers.hadCryptoTransactions}
            onCheckedChange={(checked) => handleAnswerChange("hadCryptoTransactions", checked as boolean)}
          />
          <Label htmlFor="hadCryptoTransactions" className="text-sm font-normal cursor-pointer">
            I had any crypto transactions during {currentYear}
          </Label>
        </div>

        <div className="flex items-center space-x-2">
          <Checkbox
            id="earnedCryptoIncome"
            checked={answers.earnedCryptoIncome}
            onCheckedChange={(checked) => handleAnswerChange("earnedCryptoIncome", checked as boolean)}
          />
          <Label htmlFor="earnedCryptoIncome" className="text-sm font-normal cursor-pointer">
            I earned crypto through rewards, staking, or mining
          </Label>
        </div>

        <div className="flex items-center space-x-2">
          <Checkbox
            id="receivedAirdrops"
            checked={answers.receivedAirdrops}
            onCheckedChange={(checked) => handleAnswerChange("receivedAirdrops", checked as boolean)}
          />
          <Label htmlFor="receivedAirdrops" className="text-sm font-normal cursor-pointer">
            I received crypto airdrops or bonuses
          </Label>
        </div>

        <div className="flex items-center space-x-2">
          <Checkbox
            id="stakedOrMined"
            checked={answers.stakedOrMined}
            onCheckedChange={(checked) => handleAnswerChange("stakedOrMined", checked as boolean)}
          />
          <Label htmlFor="stakedOrMined" className="text-sm font-normal cursor-pointer">
            I staked crypto or participated in mining
          </Label>
        </div>
      </CardContent>
    </Card>
  )

  const renderStep2 = () => (
    <Card>
      <CardHeader>
        <CardTitle>Crypto Transactions & NFTs</CardTitle>
        <CardDescription>Tell us about your trading and NFT activity</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center space-x-2">
          <Checkbox
            id="soldCryptoOrNfts"
            checked={answers.soldCryptoOrNfts}
            onCheckedChange={(checked) => handleAnswerChange("soldCryptoOrNfts", checked as boolean)}
          />
          <Label htmlFor="soldCryptoOrNfts" className="text-sm font-normal cursor-pointer">
            I sold, traded, or exchanged cryptocurrency or NFTs
          </Label>
        </div>

        <div className="flex items-center space-x-2">
          <Checkbox
            id="usedCryptoForPurchases"
            checked={answers.usedCryptoForPurchases}
            onCheckedChange={(checked) => handleAnswerChange("usedCryptoForPurchases", checked as boolean)}
          />
          <Label htmlFor="usedCryptoForPurchases" className="text-sm font-normal cursor-pointer">
            I used crypto to purchase goods, services, or anything in WIRED CHAOS META
          </Label>
        </div>

        <div className="flex items-center space-x-2">
          <Checkbox
            id="mintedOrBoughtNfts"
            checked={answers.mintedOrBoughtNfts}
            onCheckedChange={(checked) => handleAnswerChange("mintedOrBoughtNfts", checked as boolean)}
          />
          <Label htmlFor="mintedOrBoughtNfts" className="text-sm font-normal cursor-pointer">
            I minted or purchased NFTs using cryptocurrency
          </Label>
        </div>

        <div className="flex items-center space-x-2">
          <Checkbox
            id="crossChainActivity"
            checked={answers.crossChainActivity}
            onCheckedChange={(checked) => handleAnswerChange("crossChainActivity", checked as boolean)}
          />
          <Label htmlFor="crossChainActivity" className="text-sm font-normal cursor-pointer">
            I used bridges or moved crypto between different blockchains
          </Label>
        </div>
      </CardContent>
    </Card>
  )

  const renderStep3 = () => (
    <Card>
      <CardHeader>
        <CardTitle>Advanced & Foreign Activity</CardTitle>
        <CardDescription>Additional crypto activity that may require special forms</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center space-x-2">
          <Checkbox
            id="foreignExchanges"
            checked={answers.foreignExchanges}
            onCheckedChange={(checked) => handleAnswerChange("foreignExchanges", checked as boolean)}
          />
          <Label htmlFor="foreignExchanges" className="text-sm font-normal cursor-pointer">
            I used foreign crypto exchanges or held crypto abroad
          </Label>
        </div>

        <div className="flex items-center space-x-2">
          <Checkbox
            id="businessActivity"
            checked={answers.businessActivity}
            onCheckedChange={(checked) => handleAnswerChange("businessActivity", checked as boolean)}
          />
          <Label htmlFor="businessActivity" className="text-sm font-normal cursor-pointer">
            I conducted crypto activity as a business or for profit
          </Label>
        </div>

        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Important Note</AlertTitle>
          <AlertDescription className="text-sm">
            If you're unsure about any of these questions, it's best to check the box. We'll help you determine if the
            forms are actually required based on your specific situation.
          </AlertDescription>
        </Alert>
      </CardContent>
    </Card>
  )

  const renderResults = () => (
    <div className="space-y-6">
      <Card className="border-green-200 bg-green-50 dark:border-green-900 dark:bg-green-950">
        <CardHeader>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-5 w-5 text-green-600 dark:text-green-400" />
            <CardTitle className="text-green-900 dark:text-green-100">Analysis Complete</CardTitle>
          </div>
          <CardDescription className="text-green-800 dark:text-green-200">
            Based on your answers, here are the IRS forms and schedules you need
          </CardDescription>
        </CardHeader>
      </Card>

      {recommendations.length === 0 ? (
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">
              Based on your answers, no additional crypto-specific schedules are required. However, you must still
              answer the digital asset question on Form 1040.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {recommendations.map((rec) => (
            <Card key={rec.schedule} className={rec.required ? "border-orange-200" : ""}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <CardTitle className="text-lg">{rec.schedule}</CardTitle>
                      {rec.required && (
                        <Badge variant="destructive" className="ml-2">
                          Required
                        </Badge>
                      )}
                    </div>
                    <CardDescription className="font-medium">{rec.title}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-2">{rec.description}</p>
                <Separator className="my-3" />
                <p className="text-sm">
                  <span className="font-medium">Why you need this: </span>
                  {rec.reason}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Next Steps</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-start gap-3">
            <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold">
              1
            </div>
            <div className="space-y-1">
              <p className="text-sm font-medium">Review your crypto transactions</p>
              <p className="text-sm text-muted-foreground">
                Make sure all your crypto activity from WIRED CHAOS META and other sources is tracked
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold">
              2
            </div>
            <div className="space-y-1">
              <p className="text-sm font-medium">Generate your forms</p>
              <p className="text-sm text-muted-foreground">
                Use NEURA TAX to automatically generate Forms 8949, Schedule D, and other required forms
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold">
              3
            </div>
            <div className="space-y-1">
              <p className="text-sm font-medium">Include with your tax return</p>
              <p className="text-sm text-muted-foreground">Attach these schedules to your Form 1040 when filing</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-3">
        <Button onClick={() => (window.location.href = "/crypto")} variant="outline" className="flex-1">
          View Transactions
        </Button>
        <Button onClick={() => (window.location.href = "/crypto/forms")} className="flex-1">
          Generate Forms
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  )

  return (
    <div className="space-y-6">
      {step < 4 && (
        <div className="flex items-center justify-center gap-2 mb-8">
          {[1, 2, 3].map((s) => (
            <div key={s} className="flex items-center">
              <div
                className={`flex h-8 w-8 items-center justify-center rounded-full text-sm font-medium ${
                  s === step
                    ? "bg-primary text-primary-foreground"
                    : s < step
                      ? "bg-primary/20 text-primary"
                      : "bg-muted text-muted-foreground"
                }`}
              >
                {s}
              </div>
              {s < 3 && <div className={`h-0.5 w-12 mx-2 ${s < step ? "bg-primary" : "bg-muted"}`} />}
            </div>
          ))}
        </div>
      )}

      {step === 1 && renderStep1()}
      {step === 2 && renderStep2()}
      {step === 3 && renderStep3()}
      {step === 4 && renderResults()}

      {step < 4 && (
        <div className="flex justify-between gap-4">
          <Button variant="outline" onClick={() => setStep(step - 1)} disabled={step === 1}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Previous
          </Button>
          <Button
            onClick={() => {
              if (step === 3) {
                calculateRecommendations()
                setStep(4)
              } else {
                setStep(step + 1)
              }
            }}
          >
            {step === 3 ? "See Results" : "Next"}
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      )}

      {step === 4 && (
        <Button variant="outline" onClick={() => setStep(1)} className="w-full">
          Start Over
        </Button>
      )}
    </div>
  )
}
