import { getCryptoIncomeForYear } from "@/lib/ucl-client"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

type CryptoIncomeListProps = {
  userId: string
  taxYear: number
}

export async function CryptoIncomeList({ userId, taxYear }: CryptoIncomeListProps) {
  const income = await getCryptoIncomeForYear(userId, taxYear)

  if (income.length === 0) {
    return <div className="text-center py-8 text-muted-foreground">No crypto income recorded for {taxYear}</div>
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Date</TableHead>
            <TableHead>Type</TableHead>
            <TableHead>Token</TableHead>
            <TableHead>Chain</TableHead>
            <TableHead className="text-right">Quantity</TableHead>
            <TableHead className="text-right">FMV (USD)</TableHead>
            <TableHead>Category</TableHead>
            <TableHead>Source</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {income.map((inc) => (
            <TableRow key={inc.id}>
              <TableCell className="text-sm">{format(new Date(inc.timestamp), "MMM d, yyyy")}</TableCell>
              <TableCell>
                <Badge variant="outline" className="text-xs">
                  {inc.incomeType}
                </Badge>
              </TableCell>
              <TableCell className="font-medium">{inc.tokenSymbol}</TableCell>
              <TableCell>
                <Badge variant="secondary" className="text-xs">
                  {inc.chain}
                </Badge>
              </TableCell>
              <TableCell className="text-right font-mono text-sm">
                {Number.parseFloat(inc.quantity.toString()).toFixed(4)}
              </TableCell>
              <TableCell className="text-right font-mono text-sm text-green-600">
                ${Number.parseFloat(inc.fmvUsd.toString()).toFixed(2)}
              </TableCell>
              <TableCell>
                <Badge variant={inc.incomeCategory === "SELF_EMPLOYMENT" ? "default" : "secondary"} className="text-xs">
                  {inc.incomeCategory}
                </Badge>
              </TableCell>
              <TableCell className="text-xs text-muted-foreground">
                {inc.patchSource || inc.source || "Manual"}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
