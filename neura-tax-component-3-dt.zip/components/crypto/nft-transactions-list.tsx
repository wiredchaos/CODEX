import { getNftTransactionsForYear } from "@/lib/ucl-client"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

type NftTransactionsListProps = {
  userId: string
  taxYear: number
}

export async function NftTransactionsList({ userId, taxYear }: NftTransactionsListProps) {
  const transactions = await getNftTransactionsForYear(userId, taxYear)

  if (transactions.length === 0) {
    return <div className="text-center py-8 text-muted-foreground">No NFT transactions recorded for {taxYear}</div>
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Date</TableHead>
            <TableHead>Event</TableHead>
            <TableHead>NFT ID</TableHead>
            <TableHead>Chain</TableHead>
            <TableHead>Crypto Used</TableHead>
            <TableHead className="text-right">FMV (USD)</TableHead>
            <TableHead className="text-right">Gain/Loss</TableHead>
            <TableHead>Source</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {transactions.map((tx) => (
            <TableRow key={tx.id}>
              <TableCell className="text-sm">{format(new Date(tx.timestamp), "MMM d, yyyy")}</TableCell>
              <TableCell>
                <Badge variant="outline" className="text-xs">
                  {tx.eventType}
                </Badge>
              </TableCell>
              <TableCell className="font-mono text-xs">{tx.nftId.substring(0, 12)}...</TableCell>
              <TableCell>
                <Badge variant="secondary" className="text-xs">
                  {tx.chain}
                </Badge>
              </TableCell>
              <TableCell className="text-sm">
                {tx.cryptoUsed ? (
                  <span>
                    {Number.parseFloat(tx.cryptoAmount?.toString() || "0").toFixed(4)} {tx.cryptoUsed}
                  </span>
                ) : (
                  "-"
                )}
              </TableCell>
              <TableCell className="text-right font-mono text-sm">
                {tx.fmvUsd ? `$${Number.parseFloat(tx.fmvUsd.toString()).toFixed(2)}` : "-"}
              </TableCell>
              <TableCell className="text-right font-mono text-sm">
                {tx.gainLossUsd ? (
                  <span
                    className={Number.parseFloat(tx.gainLossUsd.toString()) >= 0 ? "text-green-600" : "text-red-600"}
                  >
                    ${Number.parseFloat(tx.gainLossUsd.toString()).toFixed(2)}
                  </span>
                ) : (
                  "-"
                )}
              </TableCell>
              <TableCell className="text-xs text-muted-foreground">{tx.patchSource || "Manual"}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
