"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { AlertTriangle, CheckCircle, Info } from "lucide-react"
import { useState } from "react"

type RiskFlag = {
  id: string
  code: string
  severity: "LOW" | "MEDIUM" | "HIGH"
  description: string
  resolved: boolean
}

export default function RiskFlagsPanel({
  flags,
  canResolve,
}: {
  flags: RiskFlag[]
  canResolve: boolean
}) {
  const [resolvedFlags, setResolvedFlags] = useState<Set<string>>(new Set())

  const handleResolve = async (flagId: string) => {
    try {
      const res = await fetch(`/api/risk-flags/${flagId}/resolve`, {
        method: "POST",
      })

      if (res.ok) {
        setResolvedFlags((prev) => new Set([...prev, flagId]))
      }
    } catch (error) {
      console.error("[v0] Error resolving flag:", error)
    }
  }

  const activeFlags = flags.filter((f) => !f.resolved && !resolvedFlags.has(f.id))

  if (activeFlags.length === 0) {
    return (
      <Card className="border-green-500/20 bg-green-500/5">
        <CardHeader>
          <CardTitle className="text-sm flex items-center gap-2">
            <CheckCircle className="h-4 w-4 text-green-500" />
            No Risk Flags
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-xs text-muted-foreground">This return has passed all automated risk checks.</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-yellow-500/20">
      <CardHeader>
        <CardTitle className="text-sm flex items-center gap-2">
          <AlertTriangle className="h-4 w-4 text-yellow-500" />
          Risk Flags ({activeFlags.length})
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {activeFlags.map((flag) => (
          <div key={flag.id} className="border rounded-lg p-3 space-y-2 text-xs">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                {flag.severity === "HIGH" && <AlertTriangle className="h-4 w-4 text-red-500 flex-shrink-0" />}
                {flag.severity === "MEDIUM" && <AlertTriangle className="h-4 w-4 text-yellow-500 flex-shrink-0" />}
                {flag.severity === "LOW" && <Info className="h-4 w-4 text-blue-500 flex-shrink-0" />}
                <span className="font-medium">{flag.code}</span>
              </div>
              <Badge
                variant={
                  flag.severity === "HIGH" ? "destructive" : flag.severity === "MEDIUM" ? "default" : "secondary"
                }
                className="text-[10px]"
              >
                {flag.severity}
              </Badge>
            </div>
            <p className="text-muted-foreground">{flag.description}</p>
            {canResolve && (
              <Button
                size="sm"
                variant="outline"
                className="text-xs h-7 bg-transparent"
                onClick={() => handleResolve(flag.id)}
              >
                Mark Resolved
              </Button>
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
