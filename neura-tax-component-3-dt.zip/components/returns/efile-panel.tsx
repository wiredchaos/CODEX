"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle, Loader2, RefreshCw, Send } from "lucide-react"

interface EfilePanelProps {
  taxReturn: any
  currentUser: any
}

export default function EfilePanel({ taxReturn, currentUser }: EfilePanelProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isChecking, setIsChecking] = useState(false)
  const [error, setError] = useState("")

  const canSubmit =
    taxReturn.status === "READY_FOR_EFILE" && (currentUser.role === "PREPARER" || currentUser.role === "ADMIN")

  const latestSubmission = taxReturn.efileSubmissions?.[0]

  async function handleSubmit() {
    setError("")
    setIsSubmitting(true)

    try {
      const response = await fetch("/api/efile/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ taxReturnId: taxReturn.id }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to submit")
      }

      window.location.reload()
    } catch (err: any) {
      setError(err.message || "An error occurred")
    } finally {
      setIsSubmitting(false)
    }
  }

  async function handleCheckStatus() {
    if (!latestSubmission) return

    setError("")
    setIsChecking(true)

    try {
      const response = await fetch("/api/efile/status", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ submissionId: latestSubmission.id }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to check status")
      }

      window.location.reload()
    } catch (err: any) {
      setError(err.message || "An error occurred")
    } finally {
      setIsChecking(false)
    }
  }

  const statusColors: Record<string, string> = {
    PENDING: "bg-gray-500",
    SUBMITTED: "bg-blue-500",
    ACCEPTED: "bg-green-500",
    REJECTED: "bg-red-500",
    ERROR: "bg-orange-500",
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Electronic Filing</CardTitle>
        <CardDescription>Submit your return to the IRS electronically</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        <div className="flex items-center justify-between">
          <div>
            <Badge className={statusColors[taxReturn.status] || "bg-gray-300"}>{taxReturn.status}</Badge>
          </div>
          <div className="flex items-center space-x-2">
            {canSubmit && (
              <Button onClick={handleSubmit} disabled={isSubmitting}>
                {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                Submit
              </Button>
            )}
            {latestSubmission && (
              <Button onClick={handleCheckStatus} disabled={isChecking}>
                {isChecking ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
                Check Status
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
