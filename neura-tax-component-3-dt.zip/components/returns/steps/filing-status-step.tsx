"use client"

import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface FilingStatusStepProps {
  data: any
  onChange: (data: any) => void
  disabled?: boolean
}

export default function FilingStatusStep({ data, onChange, disabled }: FilingStatusStepProps) {
  const statuses = [
    { value: "SINGLE", label: "Single", description: "Unmarried, divorced, or legally separated" },
    { value: "MARRIED_FILING_JOINTLY", label: "Married Filing Jointly", description: "Married and filing together" },
    {
      value: "MARRIED_FILING_SEPARATELY",
      label: "Married Filing Separately",
      description: "Married but filing separately",
    },
    { value: "HEAD_OF_HOUSEHOLD", label: "Head of Household", description: "Unmarried and supporting a dependent" },
    { value: "QUALIFYING_WIDOW", label: "Qualifying Widow(er)", description: "Spouse died within last 2 years" },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>Filing Status</CardTitle>
        <CardDescription>Select the filing status that applies to you</CardDescription>
      </CardHeader>
      <CardContent>
        <RadioGroup
          value={data.filingStatus || ""}
          onValueChange={(value) => onChange({ ...data, filingStatus: value })}
          disabled={disabled}
          className="space-y-4"
        >
          {statuses.map((status) => (
            <div key={status.value} className="flex items-start space-x-3 rounded-lg border p-4">
              <RadioGroupItem value={status.value} id={status.value} className="mt-1" />
              <div className="flex-1">
                <Label htmlFor={status.value} className="font-semibold cursor-pointer">
                  {status.label}
                </Label>
                <p className="text-sm text-muted-foreground">{status.description}</p>
              </div>
            </div>
          ))}
        </RadioGroup>
      </CardContent>
    </Card>
  )
}
