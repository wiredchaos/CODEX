"use client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Trash2 } from "lucide-react"

interface IncomeStepProps {
  data: any
  onChange: (data: any) => void
  disabled?: boolean
}

export default function IncomeStep({ data, onChange, disabled }: IncomeStepProps) {
  function addW2() {
    const w2s = data.w2Income || []
    onChange({
      ...data,
      w2Income: [...w2s, { employer: "", wages: 0, federalWithholding: 0 }],
    })
  }

  function updateW2(index: number, field: string, value: any) {
    const w2s = [...(data.w2Income || [])]
    w2s[index] = { ...w2s[index], [field]: value }
    onChange({ ...data, w2Income: w2s })
  }

  function removeW2(index: number) {
    const w2s = [...(data.w2Income || [])]
    w2s.splice(index, 1)
    onChange({ ...data, w2Income: w2s })
  }

  function add1099() {
    const form1099s = data.form1099Income || []
    onChange({
      ...data,
      form1099Income: [...form1099s, { payer: "", amount: 0, type: "NEC" }],
    })
  }

  function update1099(index: number, field: string, value: any) {
    const form1099s = [...(data.form1099Income || [])]
    form1099s[index] = { ...form1099s[index], [field]: value }
    onChange({ ...data, form1099Income: form1099s })
  }

  function remove1099(index: number) {
    const form1099s = [...(data.form1099Income || [])]
    form1099s.splice(index, 1)
    onChange({ ...data, form1099Income: form1099s })
  }

  return (
    <div className="space-y-6">
      {/* W-2 Income */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>W-2 Income</CardTitle>
              <CardDescription>Income from employers</CardDescription>
            </div>
            <Button onClick={addW2} size="sm" disabled={disabled}>
              <Plus className="mr-2 h-4 w-4" />
              Add W-2
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {(!data.w2Income || data.w2Income.length === 0) && (
            <p className="text-center text-sm text-muted-foreground py-8">
              No W-2 income added yet. Click "Add W-2" to get started.
            </p>
          )}

          {data.w2Income?.map((w2: any, index: number) => (
            <div key={index} className="rounded-lg border p-4 space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold">W-2 #{index + 1}</h4>
                <Button variant="ghost" size="sm" onClick={() => removeW2(index)} disabled={disabled}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>

              <div className="space-y-2">
                <Label>Employer Name</Label>
                <Input
                  value={w2.employer}
                  onChange={(e) => updateW2(index, "employer", e.target.value)}
                  placeholder="Acme Corp"
                  disabled={disabled}
                />
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>Wages (Box 1)</Label>
                  <Input
                    type="number"
                    value={w2.wages}
                    onChange={(e) => updateW2(index, "wages", Number.parseFloat(e.target.value) || 0)}
                    placeholder="0.00"
                    disabled={disabled}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Federal Tax Withheld (Box 2)</Label>
                  <Input
                    type="number"
                    value={w2.federalWithholding}
                    onChange={(e) => updateW2(index, "federalWithholding", Number.parseFloat(e.target.value) || 0)}
                    placeholder="0.00"
                    disabled={disabled}
                  />
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* 1099 Income */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>1099 Income</CardTitle>
              <CardDescription>Self-employment, contract work, and other income</CardDescription>
            </div>
            <Button onClick={add1099} size="sm" disabled={disabled}>
              <Plus className="mr-2 h-4 w-4" />
              Add 1099
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {(!data.form1099Income || data.form1099Income.length === 0) && (
            <p className="text-center text-sm text-muted-foreground py-8">
              No 1099 income added yet. Click "Add 1099" to get started.
            </p>
          )}

          {data.form1099Income?.map((form1099: any, index: number) => (
            <div key={index} className="rounded-lg border p-4 space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold">1099 #{index + 1}</h4>
                <Button variant="ghost" size="sm" onClick={() => remove1099(index)} disabled={disabled}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>

              <div className="space-y-2">
                <Label>Payer Name</Label>
                <Input
                  value={form1099.payer}
                  onChange={(e) => update1099(index, "payer", e.target.value)}
                  placeholder="Freelance Client"
                  disabled={disabled}
                />
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>Form Type</Label>
                  <Select
                    value={form1099.type}
                    onValueChange={(value) => update1099(index, "type", value)}
                    disabled={disabled}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="NEC">1099-NEC (Non-Employee Compensation)</SelectItem>
                      <SelectItem value="MISC">1099-MISC (Miscellaneous)</SelectItem>
                      <SelectItem value="K">1099-K (Payment Card)</SelectItem>
                      <SelectItem value="INT">1099-INT (Interest)</SelectItem>
                      <SelectItem value="DIV">1099-DIV (Dividends)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Amount</Label>
                  <Input
                    type="number"
                    value={form1099.amount}
                    onChange={(e) => update1099(index, "amount", Number.parseFloat(e.target.value) || 0)}
                    placeholder="0.00"
                    disabled={disabled}
                  />
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
