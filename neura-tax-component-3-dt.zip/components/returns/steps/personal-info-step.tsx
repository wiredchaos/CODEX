"use client"

import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface PersonalInfoStepProps {
  data: any
  onChange: (data: any) => void
  disabled?: boolean
}

export default function PersonalInfoStep({ data, onChange, disabled }: PersonalInfoStepProps) {
  function updateField(field: string, value: string) {
    onChange({ ...data, [field]: value })
  }

  function updateAddress(field: string, value: string) {
    onChange({
      ...data,
      address: { ...data.address, [field]: value },
    })
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Personal Information</CardTitle>
          <CardDescription>Enter your basic information as it appears on your Social Security card</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="firstName">First Name</Label>
              <Input
                id="firstName"
                value={data.firstName || ""}
                onChange={(e) => updateField("firstName", e.target.value)}
                disabled={disabled}
                placeholder="John"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="lastName">Last Name</Label>
              <Input
                id="lastName"
                value={data.lastName || ""}
                onChange={(e) => updateField("lastName", e.target.value)}
                disabled={disabled}
                placeholder="Doe"
              />
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="ssn">Social Security Number</Label>
              <Input
                id="ssn"
                value={data.ssn || ""}
                onChange={(e) => updateField("ssn", e.target.value)}
                disabled={disabled}
                placeholder="XXX-XX-XXXX"
                type="password"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="dateOfBirth">Date of Birth</Label>
              <Input
                id="dateOfBirth"
                type="date"
                value={data.dateOfBirth || ""}
                onChange={(e) => updateField("dateOfBirth", e.target.value)}
                disabled={disabled}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Mailing Address</CardTitle>
          <CardDescription>Where should we send correspondence?</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="street">Street Address</Label>
            <Input
              id="street"
              value={data.address?.street || ""}
              onChange={(e) => updateAddress("street", e.target.value)}
              disabled={disabled}
              placeholder="123 Main St"
            />
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="city">City</Label>
              <Input
                id="city"
                value={data.address?.city || ""}
                onChange={(e) => updateAddress("city", e.target.value)}
                disabled={disabled}
                placeholder="San Francisco"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="state">State</Label>
              <Input
                id="state"
                value={data.address?.state || ""}
                onChange={(e) => updateAddress("state", e.target.value)}
                disabled={disabled}
                placeholder="CA"
                maxLength={2}
              />
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <Label htmlFor="zipCode">ZIP Code</Label>
              <Input
                id="zipCode"
                value={data.address?.zipCode || ""}
                onChange={(e) => updateAddress("zipCode", e.target.value)}
                disabled={disabled}
                placeholder="94102"
              />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
