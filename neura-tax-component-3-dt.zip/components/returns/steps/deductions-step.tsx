"use client"

import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

interface DeductionsStepProps {
  data: any
  onChange: (data: any) => void
  disabled?: boolean
}

export default function DeductionsStep({ data, onChange, disabled }: DeductionsStepProps) {
  const deductionType = data.type || "STANDARD"

  function updateField(field: string, value: any) {
    onChange({ ...data, [field]: value })
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Deduction Type</CardTitle>
          <CardDescription>Choose between standard and itemized deductions</CardDescription>
        </CardHeader>
        <CardContent>
          <RadioGroup
            value={deductionType}
            onValueChange={(value) => updateField("type", value)}
            disabled={disabled}
            className="space-y-4"
          >
            <div className="flex items-start space-x-3 rounded-lg border p-4">
              <RadioGroupItem value="STANDARD" id="standard" className="mt-1" />
              <div className="flex-1">
                <Label htmlFor="standard" className="font-semibold cursor-pointer">
                  Standard Deduction
                </Label>
                <p className="text-sm text-muted-foreground">Most taxpayers benefit from the standard deduction</p>
              </div>
            </div>

            <div className="flex items-start space-x-3 rounded-lg border p-4">
              <RadioGroupItem value="ITEMIZED" id="itemized" className="mt-1" />
              <div className="flex-1">
                <Label htmlFor="itemized" className="font-semibold cursor-pointer">
                  Itemized Deductions
                </Label>
                <p className="text-sm text-muted-foreground">
                  List individual deductions if they exceed the standard amount
                </p>
              </div>
            </div>
          </RadioGroup>
        </CardContent>
      </Card>

      {deductionType === "ITEMIZED" && (
        <Card>
          <CardHeader>
            <CardTitle>Itemized Deductions</CardTitle>
            <CardDescription>Enter your deductible expenses</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Medical & Dental Expenses</Label>
              <Input
                type="number"
                value={data.medical || 0}
                onChange={(e) => updateField("medical", Number.parseFloat(e.target.value) || 0)}
                placeholder="0.00"
                disabled={disabled}
              />
            </div>

            <div className="space-y-2">
              <Label>State & Local Taxes (SALT)</Label>
              <Input
                type="number"
                value={data.stateTaxes || 0}
                onChange={(e) => updateField("stateTaxes", Number.parseFloat(e.target.value) || 0)}
                placeholder="0.00"
                disabled={disabled}
              />
              <p className="text-xs text-muted-foreground">Limited to $10,000</p>
            </div>

            <div className="space-y-2">
              <Label>Mortgage Interest</Label>
              <Input
                type="number"
                value={data.mortgageInterest || 0}
                onChange={(e) => updateField("mortgageInterest", Number.parseFloat(e.target.value) || 0)}
                placeholder="0.00"
                disabled={disabled}
              />
            </div>

            <div className="space-y-2">
              <Label>Charitable Contributions</Label>
              <Input
                type="number"
                value={data.charity || 0}
                onChange={(e) => updateField("charity", Number.parseFloat(e.target.value) || 0)}
                placeholder="0.00"
                disabled={disabled}
              />
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
