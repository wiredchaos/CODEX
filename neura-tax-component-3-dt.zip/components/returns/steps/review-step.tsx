"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2, Loader2 } from "lucide-react"

interface ReviewStepProps {
  taxReturn: any
  formData: any
  currentUser: any
  onSave: () => Promise<void>
}

export default function ReviewStep({ taxReturn, formData, currentUser, onSave }: ReviewStepProps) {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Calculate totals
  const totalW2Income = formData.income?.w2Income?.reduce((sum: number, w2: any) => sum + (w2.wages || 0), 0) || 0
  const total1099Income =
    formData.income?.form1099Income?.reduce((sum: number, f: any) => sum + (f.amount || 0), 0) || 0
  const totalIncome = totalW2Income + total1099Income

  const canSubmitForReview =
    taxReturn.status === "DRAFT" &&
    formData.personalInfo?.firstName &&
    formData.filingStatus &&
    currentUser.role === "CLIENT"

  const canMarkReadyForEfile =
    (taxReturn.status === "READY_FOR_REVIEW" || taxReturn.status === "DRAFT") &&
    (currentUser.role === "PREPARER" || currentUser.role === "ADMIN")

  async function handleStatusChange(newStatus: string) {
    setIsSubmitting(true)
    try {
      await onSave()

      const response = await fetch(`/api/returns/${taxReturn.id}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus }),
      })

      if (!response.ok) {
        throw new Error("Failed to update status")
      }

      router.refresh()
    } catch (error) {
      console.error("[Status Change Error]", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Return Summary</CardTitle>
          <CardDescription>Review your tax return before submission</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Personal Info */}
          <div>
            <h3 className="font-semibold mb-2">Personal Information</h3>
            <div className="text-sm space-y-1 text-muted-foreground">
              <p>
                <strong className="text-foreground">Name:</strong> {formData.personalInfo?.firstName}{" "}
                {formData.personalInfo?.lastName || "(Not provided)"}
              </p>
              <p>
                <strong className="text-foreground">SSN:</strong>{" "}
                {formData.personalInfo?.ssn ? "***-**-" + formData.personalInfo.ssn.slice(-4) : "(Not provided)"}
              </p>
            </div>
          </div>

          {/* Filing Status */}
          <div>
            <h3 className="font-semibold mb-2">Filing Status</h3>
            <Badge>{formData.filingStatus?.replace(/_/g, " ") || "Not selected"}</Badge>
          </div>

          {/* Income Summary */}
          <div>
            <h3 className="font-semibold mb-2">Income Summary</h3>
            <div className="text-sm space-y-1 text-muted-foreground">
              <p>
                <strong className="text-foreground">W-2 Income:</strong> ${totalW2Income.toLocaleString()}
              </p>
              <p>
                <strong className="text-foreground">1099 Income:</strong> ${total1099Income.toLocaleString()}
              </p>
              <p className="pt-2 text-base">
                <strong className="text-foreground">Total Income:</strong> ${totalIncome.toLocaleString()}
              </p>
            </div>
          </div>

          {/* Deductions */}
          <div>
            <h3 className="font-semibold mb-2">Deductions</h3>
            <Badge variant="outline">{formData.deductions?.type || "Standard"} Deduction</Badge>
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Next Steps</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {taxReturn.status === "DRAFT" && (
            <Alert>
              <AlertDescription>
                Save your progress regularly. When ready, submit for review to your tax preparer.
              </AlertDescription>
            </Alert>
          )}

          <div className="flex gap-3">
            {canSubmitForReview && (
              <Button onClick={() => handleStatusChange("READY_FOR_REVIEW")} disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="mr-2 h-4 w-4" />
                    Submit for Review
                  </>
                )}
              </Button>
            )}

            {canMarkReadyForEfile && (
              <Button onClick={() => handleStatusChange("READY_FOR_EFILE")} disabled={isSubmitting} variant="default">
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Updating...
                  </>
                ) : (
                  "Mark Ready for E-File"
                )}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
