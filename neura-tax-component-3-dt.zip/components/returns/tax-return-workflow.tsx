"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertTriangle, ArrowLeft, Save } from "lucide-react"
import PersonalInfoStep from "./steps/personal-info-step"
import FilingStatusStep from "./steps/filing-status-step"
import IncomeStep from "./steps/income-step"
import DeductionsStep from "./steps/deductions-step"
import ReviewStep from "./steps/review-step"

type TaxReturn = any
type User = any

interface TaxReturnWorkflowProps {
  taxReturn: TaxReturn
  currentUser: User
}

export default function TaxReturnWorkflow({ taxReturn, currentUser }: TaxReturnWorkflowProps) {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("personal")
  const [formData, setFormData] = useState(taxReturn.dataJson)
  const [isSaving, setIsSaving] = useState(false)

  const isLocked = taxReturn.status !== "DRAFT" && taxReturn.userId === currentUser.id && currentUser.role === "CLIENT"

  const statusColors: Record<string, string> = {
    DRAFT: "bg-gray-500",
    READY_FOR_REVIEW: "bg-blue-500",
    READY_FOR_EFILE: "bg-yellow-500",
    EFILE_SUBMITTED: "bg-purple-500",
    ACCEPTED: "bg-green-500",
    REJECTED: "bg-red-500",
  }

  async function handleSave() {
    setIsSaving(true)
    try {
      const response = await fetch(`/api/returns/${taxReturn.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dataJson: formData }),
      })

      if (!response.ok) {
        throw new Error("Failed to save")
      }

      router.refresh()
    } catch (error) {
      console.error("[Save Error]", error)
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="min-h-screen bg-secondary/20">
      {/* Header */}
      <div className="border-b bg-background">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" onClick={() => router.push("/dashboard")}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back
              </Button>
              <div>
                <div className="flex items-center gap-3">
                  <h1 className="text-2xl font-bold">Tax Year {taxReturn.taxYear}</h1>
                  <Badge className={statusColors[taxReturn.status]}>{taxReturn.status.replace(/_/g, " ")}</Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  {taxReturn.returnType} - {taxReturn.user.name}
                </p>
              </div>
            </div>
            {!isLocked && (
              <Button onClick={handleSave} disabled={isSaving}>
                <Save className="mr-2 h-4 w-4" />
                {isSaving ? "Saving..." : "Save Progress"}
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Risk Flags */}
      {taxReturn.riskFlags.length > 0 && (
        <div className="border-b bg-destructive/10">
          <div className="container mx-auto px-4 py-4">
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>{taxReturn.riskFlags.length} risk flag(s) detected.</strong> Review required before filing.
              </AlertDescription>
            </Alert>
          </div>
        </div>
      )}

      {/* Workflow Tabs */}
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardContent className="pt-6">
            {isLocked && (
              <Alert className="mb-6">
                <AlertDescription>
                  This return is locked for editing. Contact your preparer for changes.
                </AlertDescription>
              </Alert>
            )}

            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="personal">Personal Info</TabsTrigger>
                <TabsTrigger value="filing">Filing Status</TabsTrigger>
                <TabsTrigger value="income">Income</TabsTrigger>
                <TabsTrigger value="deductions">Deductions</TabsTrigger>
                <TabsTrigger value="review">Review</TabsTrigger>
              </TabsList>

              <TabsContent value="personal" className="mt-6">
                <PersonalInfoStep
                  data={formData.personalInfo}
                  onChange={(data) => setFormData({ ...formData, personalInfo: data })}
                  disabled={isLocked}
                />
              </TabsContent>

              <TabsContent value="filing" className="mt-6">
                <FilingStatusStep data={formData} onChange={setFormData} disabled={isLocked} />
              </TabsContent>

              <TabsContent value="income" className="mt-6">
                <IncomeStep
                  data={formData.income}
                  onChange={(data) => setFormData({ ...formData, income: data })}
                  disabled={isLocked}
                />
              </TabsContent>

              <TabsContent value="deductions" className="mt-6">
                <DeductionsStep
                  data={formData.deductions}
                  onChange={(data) => setFormData({ ...formData, deductions: data })}
                  disabled={isLocked}
                />
              </TabsContent>

              <TabsContent value="review" className="mt-6">
                <ReviewStep taxReturn={taxReturn} formData={formData} currentUser={currentUser} onSave={handleSave} />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
