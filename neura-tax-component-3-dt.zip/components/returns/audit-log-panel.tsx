"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { formatDistanceToNow } from "date-fns"
import { FileText } from "lucide-react"

type AuditLogEntry = {
  id: string
  action: string
  changedFields: any
  createdAt: Date
  user: {
    name: string | null
    email: string
  }
}

export default function AuditLogPanel({ logs }: { logs: AuditLogEntry[] }) {
  if (logs.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-sm flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Audit Trail
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-xs text-muted-foreground">No activity yet.</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-sm flex items-center gap-2">
          <FileText className="h-4 w-4" />
          Audit Trail ({logs.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3 max-h-[400px] overflow-y-auto">
          {logs.map((log) => (
            <div key={log.id} className="border-l-2 border-primary/20 pl-3 py-1 text-xs space-y-1">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-[10px]">
                    {log.action}
                  </Badge>
                  <span className="text-muted-foreground">by {log.user.name || log.user.email}</span>
                </div>
                <span className="text-muted-foreground text-[10px]">
                  {formatDistanceToNow(new Date(log.createdAt), { addSuffix: true })}
                </span>
              </div>
              {log.changedFields && Object.keys(log.changedFields).length > 0 && (
                <div className="text-[10px] text-muted-foreground font-mono">
                  Changed: {Object.keys(log.changedFields).join(", ")}
                </div>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
