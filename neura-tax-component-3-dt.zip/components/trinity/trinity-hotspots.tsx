"use client"

import { useEffect, useState } from "react"

interface TrinityHotspotsProps {
  onHotspotChange: (hotspot: string | null) => void
}

/**
 * TrinityHotspots - Navigation anchor system
 *
 * Hotspots are supplied by Trinity Core and represent interactive zones
 * within the 3D environment. This component listens for hotspot events
 * and notifies the parent component.
 *
 * Hotspot Types:
 * - NETERU Timeline Door
 * - SIGNAL ERA Timeline Door
 * - RVP Timeline Door
 * - NEURA TAX Business Portal
 * - Artifact Terminal Akashic Portal
 */
export function TrinityHotspots({ onHotspotChange }: TrinityHotspotsProps) {
  const [hotspots] = useState([
    { id: "neteru", name: "NETERU Timeline", x: 30, y: 40, color: "fuchsia" },
    { id: "signal-era", name: "SIGNAL ERA Timeline", x: 70, y: 40, color: "cyan" },
    { id: "rvp", name: "RVP Timeline", x: 50, y: 60, color: "green" },
    { id: "neura-tax", name: "NEURA TAX Portal", x: 20, y: 70, color: "cyan" },
    { id: "artifact", name: "Artifact Terminal", x: 80, y: 70, color: "fuchsia" },
  ])

  const [activeId, setActiveId] = useState<string | null>(null)

  useEffect(() => {
    const active = hotspots.find((h) => h.id === activeId)
    onHotspotChange(active ? active.name : null)
  }, [activeId, hotspots, onHotspotChange])

  return (
    <div className="pointer-events-none absolute inset-0 z-40">
      {hotspots.map((hotspot) => (
        <button
          key={hotspot.id}
          className="pointer-events-auto absolute group"
          style={{
            left: `${hotspot.x}%`,
            top: `${hotspot.y}%`,
            transform: "translate(-50%, -50%)",
          }}
          onMouseEnter={() => setActiveId(hotspot.id)}
          onMouseLeave={() => setActiveId(null)}
        >
          {/* Hotspot Marker */}
          <div className="relative">
            {/* Pulse Ring */}
            <div
              className={`absolute inset-0 rounded-full animate-ping opacity-75`}
              style={{
                width: "24px",
                height: "24px",
                backgroundColor: `rgb(var(--${hotspot.color}-500) / 0.4)`,
              }}
            />

            {/* Core Dot */}
            <div
              className={`relative h-6 w-6 rounded-full border-2 transition-all duration-300 group-hover:scale-150`}
              style={{
                borderColor: `rgb(var(--${hotspot.color}-400))`,
                backgroundColor:
                  activeId === hotspot.id
                    ? `rgb(var(--${hotspot.color}-500) / 0.6)`
                    : `rgb(var(--${hotspot.color}-500) / 0.2)`,
                boxShadow: activeId === hotspot.id ? `0 0 20px rgb(var(--${hotspot.color}-400) / 0.8)` : "none",
              }}
            />
          </div>

          {/* Label */}
          <div
            className={`
              absolute top-full mt-2 left-1/2 -translate-x-1/2 whitespace-nowrap
              rounded-md border bg-slate-950/95 px-2 py-1 text-xs font-mono
              transition-opacity duration-200
              ${activeId === hotspot.id ? "opacity-100" : "opacity-0 group-hover:opacity-100"}
            `}
            style={{
              borderColor: `rgb(var(--${hotspot.color}-500) / 0.4)`,
              color: `rgb(var(--${hotspot.color}-400))`,
            }}
          >
            {hotspot.name}
          </div>
        </button>
      ))}
    </div>
  )
}
