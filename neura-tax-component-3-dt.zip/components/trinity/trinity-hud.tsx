"use client"

import Link from "next/link"
import { FileText, Gem, BarChart3 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface TrinityHUDProps {
  activeHotspot: string | null
}

export function TrinityHUD({ activeHotspot }: TrinityHUDProps) {
  return (
    <div className="pointer-events-none absolute inset-0 z-50">
      {/* Top Bar - System Status */}
      <div className="pointer-events-auto absolute top-0 left-0 right-0 border-b border-cyan-500/20 bg-slate-950/80 backdrop-blur-sm">
        <div className="flex items-center justify-between px-6 py-3">
          <div className="flex items-center gap-4">
            <div className="text-xs font-mono text-cyan-400">WIRED CHAOS META</div>
            <div className="h-4 w-px bg-slate-700" />
            <div className="text-xs font-mono text-slate-400">Patch: CLEAR | Floor: LOBBY</div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 rounded-full border border-green-500/30 bg-green-500/10 px-3 py-1">
              <div className="h-1.5 w-1.5 rounded-full bg-green-400 animate-pulse" />
              <span className="text-xs font-mono text-green-400">TRINITY MOUNTED</span>
            </div>
          </div>
        </div>
      </div>

      {/* Left Panel - Quick Navigation */}
      <div className="pointer-events-auto absolute left-6 top-1/2 -translate-y-1/2">
        <Card className="border-slate-800 bg-slate-950/90 backdrop-blur-sm p-4 space-y-3">
          <div className="text-xs font-mono text-slate-400 mb-3">NAVIGATION</div>

          <Button
            asChild
            variant="ghost"
            size="sm"
            className="w-full justify-start gap-2 text-slate-300 hover:text-cyan-400 hover:bg-cyan-500/10"
          >
            <Link href="/dashboard">
              <FileText className="h-4 w-4" />
              <span className="text-xs">NEURA TAX</span>
            </Link>
          </Button>

          <Button
            asChild
            variant="ghost"
            size="sm"
            className="w-full justify-start gap-2 text-slate-300 hover:text-fuchsia-400 hover:bg-fuchsia-500/10"
          >
            <Link href="/artifact-terminal">
              <Gem className="h-4 w-4" />
              <span className="text-xs">ARTIFACT TERMINAL</span>
            </Link>
          </Button>

          <Button
            asChild
            variant="ghost"
            size="sm"
            className="w-full justify-start gap-2 text-slate-300 hover:text-green-400 hover:bg-green-500/10"
          >
            <Link href="/crypto">
              <BarChart3 className="h-4 w-4" />
              <span className="text-xs">CRYPTO LEDGER</span>
            </Link>
          </Button>
        </Card>
      </div>

      {/* Right Panel - Active Hotspot Info */}
      {activeHotspot && (
        <div className="pointer-events-auto absolute right-6 top-1/2 -translate-y-1/2">
          <Card className="border-slate-800 bg-slate-950/90 backdrop-blur-sm p-4 w-64">
            <div className="text-xs font-mono text-cyan-400 mb-2">ACTIVE ZONE</div>
            <div className="text-sm text-slate-200 mb-3">{activeHotspot}</div>
            <div className="text-xs text-slate-500 leading-relaxed">
              Timeline access governed by Akira Codex. Business data remains firewalled.
            </div>
          </Card>
        </div>
      )}

      {/* Bottom Bar - System Constraints */}
      <div className="pointer-events-none absolute bottom-0 left-0 right-0 border-t border-slate-800 bg-slate-950/70 backdrop-blur-sm px-6 py-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4 text-xs font-mono text-slate-600">
            <span>Read-Only Mount</span>
            <span>•</span>
            <span>Akira Codex Gating: Active</span>
            <span>•</span>
            <span>Business Firewall: Enabled</span>
          </div>

          <div className="text-xs font-mono text-slate-600">Consumer Mode | No Scene Generation</div>
        </div>
      </div>
    </div>
  )
}
