"use client"

import { useState } from "react"
import { TrinityHUD } from "./trinity-hud"
import { TrinityHotspots } from "./trinity-hotspots"

export function TrinityEnvironment() {
  const [activeHotspot, setActiveHotspot] = useState<string | null>(null)

  return (
    <div className="relative h-screen w-full overflow-hidden bg-slate-950">
      {/* Trinity 3D Core Mount - Read-Only Consumer */}
      <EnvironmentRenderer patchId="CLEAR" kind="lobby" />

      {/* HUD Overlay - Non-intrusive UI layer */}
      <TrinityHUD activeHotspot={activeHotspot} />

      {/* Hotspot System - Navigation anchors supplied by Trinity Core */}
      <TrinityHotspots onHotspotChange={setActiveHotspot} />
    </div>
  )
}

/**
 * EnvironmentRenderer - Trinity 3D Core Consumer Component
 *
 * This component MOUNTS the existing WIRED CHAOS Trinity 3D Core.
 * It does NOT generate 3D scenes, timelines, or spatial infrastructure.
 *
 * Props:
 * - patchId: "CLEAR" identifies this patch workspace
 * - kind: "lobby" specifies the Trinity floor/environment type
 *
 * Constraints:
 * - Read-only access to Trinity Core
 * - No scene generation authority
 * - Respects Akira Codex gating
 * - Uses hotspots + HUD supplied by core
 */
function EnvironmentRenderer({
  patchId,
  kind,
}: {
  patchId: string
  kind: "lobby" | "timeline" | "vault"
}) {
  return (
    <div
      className="absolute inset-0"
      data-trinity-mount
      data-patch-id={patchId}
      data-environment-kind={kind}
      style={{
        background: "radial-gradient(ellipse at center, rgba(15, 23, 42, 1) 0%, rgba(2, 6, 23, 1) 100%)",
      }}
    >
      {/* Trinity Core renders here - controlled externally */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="text-cyan-400/60 text-sm font-mono tracking-wider">TRINITY CORE MOUNT</div>
          <div className="text-slate-500 text-xs font-mono">
            patchId: {patchId} | kind: {kind}
          </div>
          <div className="mt-8 text-slate-600 text-xs font-mono">Awaiting Trinity 3D Core injection...</div>
        </div>
      </div>
    </div>
  )
}
