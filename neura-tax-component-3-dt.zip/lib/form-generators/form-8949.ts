// Form 8949 - Sales and Other Dispositions of Capital Assets
// Generates IRS Form 8949 from crypto transaction data

import { getCryptoTransactionsForYear, getNftTransactionsForYear } from "../ucl-client"

export type Form8949Transaction = {
  description: string
  dateAcquired: string
  dateSold: string
  proceeds: number
  costBasis: number
  adjustmentCode?: string
  adjustmentAmount?: number
  gainOrLoss: number
  term: "short" | "long"
}

export type Form8949Data = {
  taxYear: number
  taxpayerName: string
  ssn: string
  shortTermTransactions: Form8949Transaction[]
  longTermTransactions: Form8949Transaction[]
  shortTermTotals: {
    totalProceeds: number
    totalCostBasis: number
    totalAdjustments: number
    totalGainLoss: number
  }
  longTermTotals: {
    totalProceeds: number
    totalCostBasis: number
    totalAdjustments: number
    totalGainLoss: number
  }
}

/**
 * Generate Form 8949 data from crypto transactions
 */
export async function generateForm8949(
  userId: string,
  taxYear: number,
  taxpayerName: string,
  ssn: string,
): Promise<Form8949Data> {
  // Fetch all crypto and NFT transactions for the year
  const [cryptoTxs, nftTxs] = await Promise.all([
    getCryptoTransactionsForYear(userId, taxYear),
    getNftTransactionsForYear(userId, taxYear),
  ])

  const shortTermTransactions: Form8949Transaction[] = []
  const longTermTransactions: Form8949Transaction[] = []

  // Process crypto transactions
  for (const tx of cryptoTxs) {
    // Only include dispositions (sales, trades, payments)
    if (!["PURCHASE", "SALE", "TRADE", "PAYMENT"].includes(tx.eventType) || !tx.fmvUsd || !tx.costBasisUsd) {
      continue
    }

    const proceeds = Number.parseFloat(tx.fmvUsd.toString())
    const costBasis = Number.parseFloat(tx.costBasisUsd.toString())
    const gainLoss = Number.parseFloat(tx.gainLossUsd?.toString() || "0")

    // For MVP, treating all as short-term (would need acquisition date tracking for long-term)
    const transaction: Form8949Transaction = {
      description: `${Number.parseFloat(tx.quantity.toString()).toFixed(4)} ${tx.tokenSymbol} on ${tx.chain}`,
      dateAcquired: "VARIOUS", // Would need acquisition tracking
      dateSold: tx.timestamp.toISOString().split("T")[0],
      proceeds,
      costBasis,
      gainOrLoss: gainLoss,
      term: "short", // Default to short-term
    }

    shortTermTransactions.push(transaction)
  }

  // Process NFT transactions
  for (const tx of nftTxs) {
    // Only include sales and burns that have proceeds
    if (!["SALE", "BURN"].includes(tx.eventType) || !tx.fmvUsd || !tx.costBasisUsd) {
      continue
    }

    const proceeds = Number.parseFloat(tx.fmvUsd.toString())
    const costBasis = Number.parseFloat(tx.costBasisUsd.toString())
    const gainLoss = Number.parseFloat(tx.gainLossUsd?.toString() || "0")

    const transaction: Form8949Transaction = {
      description: `NFT ${tx.nftId.substring(0, 12)}... on ${tx.chain}`,
      dateAcquired: "VARIOUS",
      dateSold: tx.timestamp.toISOString().split("T")[0],
      proceeds,
      costBasis,
      gainOrLoss: gainLoss,
      term: "short",
    }

    shortTermTransactions.push(transaction)
  }

  // Calculate totals
  const shortTermTotals = {
    totalProceeds: shortTermTransactions.reduce((sum, tx) => sum + tx.proceeds, 0),
    totalCostBasis: shortTermTransactions.reduce((sum, tx) => sum + tx.costBasis, 0),
    totalAdjustments: shortTermTransactions.reduce((sum, tx) => sum + (tx.adjustmentAmount || 0), 0),
    totalGainLoss: shortTermTransactions.reduce((sum, tx) => sum + tx.gainOrLoss, 0),
  }

  const longTermTotals = {
    totalProceeds: longTermTransactions.reduce((sum, tx) => sum + tx.proceeds, 0),
    totalCostBasis: longTermTransactions.reduce((sum, tx) => sum + tx.costBasis, 0),
    totalAdjustments: longTermTransactions.reduce((sum, tx) => sum + (tx.adjustmentAmount || 0), 0),
    totalGainLoss: longTermTransactions.reduce((sum, tx) => sum + tx.gainOrLoss, 0),
  }

  return {
    taxYear,
    taxpayerName,
    ssn,
    shortTermTransactions,
    longTermTransactions,
    shortTermTotals,
    longTermTotals,
  }
}
