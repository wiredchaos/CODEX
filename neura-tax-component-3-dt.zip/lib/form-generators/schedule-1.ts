// Schedule 1 - Additional Income and Adjustments to Income
// Generates crypto income section for Schedule 1

import { getCryptoIncomeForYear } from "../ucl-client"

export type Schedule1CryptoIncomeData = {
  taxYear: number
  taxpayerName: string
  ssn: string
  ordinaryIncome: number
  otherIncome: number
  totalAdditionalIncome: number
  incomeBreakdown: {
    rewards: number
    airdrops: number
    staking: number
    mining: number
    other: number
  }
}

/**
 * Generate crypto income data for Schedule 1
 */
export async function generateSchedule1CryptoIncome(
  userId: string,
  taxYear: number,
  taxpayerName: string,
  ssn: string,
): Promise<Schedule1CryptoIncomeData> {
  const incomeRecords = await getCryptoIncomeForYear(userId, taxYear)

  const incomeBreakdown = {
    rewards: 0,
    airdrops: 0,
    staking: 0,
    mining: 0,
    other: 0,
  }

  let ordinaryIncome = 0
  let otherIncome = 0

  for (const inc of incomeRecords) {
    const amount = Number.parseFloat(inc.fmvUsd.toString())

    // Categorize by income category
    if (inc.incomeCategory === "ORDINARY") {
      ordinaryIncome += amount
    } else if (inc.incomeCategory === "OTHER") {
      otherIncome += amount
    }
    // Self-employment income goes to Schedule C, not Schedule 1

    // Track income type breakdown
    switch (inc.incomeType) {
      case "REWARD":
        incomeBreakdown.rewards += amount
        break
      case "AIRDROP":
        incomeBreakdown.airdrops += amount
        break
      case "STAKING":
        incomeBreakdown.staking += amount
        break
      case "MINING":
        incomeBreakdown.mining += amount
        break
      default:
        incomeBreakdown.other += amount
    }
  }

  return {
    taxYear,
    taxpayerName,
    ssn,
    ordinaryIncome,
    otherIncome,
    totalAdditionalIncome: ordinaryIncome + otherIncome,
    incomeBreakdown,
  }
}
