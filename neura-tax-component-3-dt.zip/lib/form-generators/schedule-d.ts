// Schedule D - Capital Gains and Losses
// Generates IRS Schedule D from Form 8949 data

import type { Form8949Data } from "./form-8949"

export type ScheduleDData = {
  taxYear: number
  taxpayerName: string
  ssn: string
  shortTermGainLoss: number
  longTermGainLoss: number
  totalCapitalGainLoss: number
  carryoverLosses?: number
  netCapitalGainLoss: number
  qualifiedDividends?: number
  form8949Attached: boolean
}

/**
 * Generate Schedule D from Form 8949 data
 */
export function generateScheduleD(
  form8949Data: Form8949Data,
  carryoverLosses = 0,
  qualifiedDividends = 0,
): ScheduleDData {
  const shortTermGainLoss = form8949Data.shortTermTotals.totalGainLoss
  const longTermGainLoss = form8949Data.longTermTotals.totalGainLoss
  const totalCapitalGainLoss = shortTermGainLoss + longTermGainLoss

  // Apply carryover losses (capped at $3,000 for individuals)
  const netCapitalGainLoss = totalCapitalGainLoss - Math.min(carryoverLosses, 3000)

  return {
    taxYear: form8949Data.taxYear,
    taxpayerName: form8949Data.taxpayerName,
    ssn: form8949Data.ssn,
    shortTermGainLoss,
    longTermGainLoss,
    totalCapitalGainLoss,
    carryoverLosses: carryoverLosses > 0 ? carryoverLosses : undefined,
    netCapitalGainLoss,
    qualifiedDividends: qualifiedDividends > 0 ? qualifiedDividends : undefined,
    form8949Attached: true,
  }
}
