// Fiscal Liability Trigger System
// Evaluates user tax data and creates trigger events when material liability is detected

import { prisma } from "@/lib/db"
import { sendChaosEvent, createAnonId } from "@/lib/chaos-patch"

type EvaluateFiscalTriggerParams = {
  userId: string
  taxYear: number
}

type TriggerReason = {
  category: string
  reason: string
}

export async function evaluateFiscalLiabilityTrigger(params: EvaluateFiscalTriggerParams) {
  const { userId, taxYear } = params

  console.log("[v0] Evaluating fiscal liability trigger for user:", userId, "year:", taxYear)

  // 1. Load user's config or use default
  const userConfig = await prisma.fiscalTriggerConfig.findFirst({
    where: { userId },
  })

  const defaultConfig = await prisma.fiscalTriggerConfig.findFirst({
    where: { userId: null },
  })

  const cfg = userConfig ?? defaultConfig

  if (!cfg) {
    console.log("[v0] No fiscal trigger config found, creating default")
    // Create default config if none exists
    const newDefault = await prisma.fiscalTriggerConfig.create({
      data: {
        userId: null,
        minLiabilityUsd: 1000,
        minSingleEventUsd: 5000,
        minUnderpaymentRatio: 0.8,
        cryptoEventCountLimit: 50,
      },
    })
    return evaluateFiscalLiabilityTrigger(params) // Retry with new config
  }

  // 2. Get or create tax year summary
  let summary = await prisma.taxYearSummary.findUnique({
    where: {
      userId_taxYear: { userId, taxYear },
    },
  })

  if (!summary) {
    console.log("[v0] No tax year summary found, calculating...")
    summary = await calculateTaxYearSummary(userId, taxYear)
  }

  const estimatedLiability = summary.estimatedTaxLiabilityUsd ?? 0
  const paidSoFar = summary.totalPaymentsUsd ?? 0
  const cryptoGain = summary.cryptoRealizedGainUsd ?? 0
  const largestSingleGain = summary.largestSingleGainUsd ?? 0
  const cryptoEventCount = summary.cryptoEventCount ?? 0
  const cryptoIncome = summary.cryptoIncomeUsd ?? 0

  console.log("[v0] Summary data:", {
    estimatedLiability,
    paidSoFar,
    cryptoGain,
    largestSingleGain,
    cryptoEventCount,
  })

  // 3. Evaluate trigger conditions
  const triggers: TriggerReason[] = []

  if (estimatedLiability >= cfg.minLiabilityUsd) {
    triggers.push({
      category: "GENERAL",
      reason: `Estimated liability ($${estimatedLiability.toFixed(2)}) exceeds configured threshold ($${cfg.minLiabilityUsd}).`,
    })
  }

  if (cryptoGain >= cfg.minLiabilityUsd) {
    triggers.push({
      category: "CRYPTO",
      reason: `Crypto gains ($${cryptoGain.toFixed(2)}) exceed configured threshold ($${cfg.minLiabilityUsd}).`,
    })
  }

  if (largestSingleGain >= cfg.minSingleEventUsd) {
    triggers.push({
      category: "CRYPTO",
      reason: `Single crypto event produced large gain ($${largestSingleGain.toFixed(2)}).`,
    })
  }

  const paidRatio = estimatedLiability > 0 ? paidSoFar / estimatedLiability : 1
  if (estimatedLiability > 0 && paidRatio < cfg.minUnderpaymentRatio) {
    triggers.push({
      category: "GENERAL",
      reason: `Estimated payments ($${paidSoFar.toFixed(2)}) appear materially under target (${(paidRatio * 100).toFixed(0)}% of liability).`,
    })
  }

  if (cryptoEventCount >= cfg.cryptoEventCountLimit) {
    triggers.push({
      category: "CRYPTO",
      reason: `High volume of crypto events (${cryptoEventCount}) may require detailed reporting.`,
    })
  }

  if (cryptoIncome >= cfg.minLiabilityUsd) {
    triggers.push({
      category: "CRYPTO",
      reason: `Significant crypto income ($${cryptoIncome.toFixed(2)}) must be reported.`,
    })
  }

  console.log("[v0] Triggers found:", triggers.length)

  if (!triggers.length) {
    console.log("[v0] No fiscal liability triggers detected")
    return null
  }

  // 4. Determine severity
  const severity =
    estimatedLiability > cfg.minLiabilityUsd * 5
      ? "CRITICAL"
      : estimatedLiability > cfg.minLiabilityUsd * 2
        ? "HIGH"
        : "MEDIUM"

  // Determine primary category
  const primaryCategory = triggers.find((t) => t.category === "CRYPTO") ? "CRYPTO" : "GENERAL"

  console.log("[v0] Creating trigger event:", { severity, primaryCategory })

  // 5. Create trigger event
  const triggerEvent = await prisma.fiscalLiabilityTriggerEvent.create({
    data: {
      userId,
      taxYear,
      category: primaryCategory as any,
      severity: severity as any,
      liabilityEstimate: estimatedLiability,
      detailsJson: {
        reasons: triggers,
        summary: {
          estimatedLiability,
          paidSoFar,
          cryptoGain,
          largestSingleGain,
          cryptoEventCount,
          cryptoIncome,
          paidRatio: Math.round(paidRatio * 100),
        },
      },
    },
  })

  // 6. Create user notifications
  await prisma.notification.createMany({
    data: [
      {
        userId,
        title: "Fiscal Liability Detected",
        body:
          severity === "CRITICAL"
            ? "We've detected a significant tax liability risk for this year. Please review your NEURA TAX dashboard for details."
            : "You may have a notable tax liability forming. Review your NEURA TAX summary for more information.",
        channel: "IN_APP",
        relatedTriggerId: triggerEvent.id,
      },
    ],
  })

  console.log("[v0] Notifications created, sending CHAOS event")

  // 7. Send sanitized CHAOS PATCH signal
  await sendChaosEvent({
    appId: process.env.CHAOS_APP_ID || "NEURA_TAX",
    eventType: "FISCAL_LIABILITY_TRIGGERED",
    timestamp: new Date().toISOString(),
    userAnonId: createAnonId(userId),
    payload: {
      taxYear,
      severity,
      liabilityEstimate: Math.round(estimatedLiability),
      category: primaryCategory,
    },
  })

  return triggerEvent
}

// Calculate or recalculate tax year summary from transaction data
async function calculateTaxYearSummary(userId: string, taxYear: number) {
  console.log("[v0] Calculating tax year summary for", userId, taxYear)

  const yearStart = new Date(taxYear, 0, 1)
  const yearEnd = new Date(taxYear, 11, 31, 23, 59, 59)

  // Aggregate crypto transactions
  const cryptoTxs = await prisma.cryptoTransaction.findMany({
    where: {
      userId,
      timestamp: {
        gte: yearStart,
        lte: yearEnd,
      },
    },
  })

  const cryptoRealizedGainUsd = cryptoTxs
    .filter((tx) => (tx.gainLossUsd ?? 0) > 0)
    .reduce((sum, tx) => sum + Number(tx.gainLossUsd ?? 0), 0)

  const cryptoRealizedLossUsd = cryptoTxs
    .filter((tx) => (tx.gainLossUsd ?? 0) < 0)
    .reduce((sum, tx) => sum + Math.abs(Number(tx.gainLossUsd ?? 0)), 0)

  const largestSingleGainUsd = Math.max(0, ...cryptoTxs.map((tx) => Number(tx.gainLossUsd ?? 0)))

  // Aggregate crypto income
  const cryptoIncomes = await prisma.cryptoIncome.findMany({
    where: {
      userId,
      timestamp: {
        gte: yearStart,
        lte: yearEnd,
      },
    },
  })

  const cryptoIncomeUsd = cryptoIncomes.reduce((sum, inc) => sum + Number(inc.fmvUsd), 0)

  // Get tax return if exists
  const taxReturn = await prisma.taxReturn.findFirst({
    where: { userId, taxYear },
  })

  let estimatedTaxLiabilityUsd = 0
  let totalPaymentsUsd = 0

  if (taxReturn?.summaryJson) {
    const summary = taxReturn.summaryJson as any
    estimatedTaxLiabilityUsd = summary.totalTax ?? 0
    totalPaymentsUsd = summary.totalPayments ?? 0
  } else {
    // Rough estimate if no return exists
    // Use simplified 22% effective rate on gains + income
    const taxableAmount = cryptoRealizedGainUsd - cryptoRealizedLossUsd + cryptoIncomeUsd
    estimatedTaxLiabilityUsd = taxableAmount * 0.22
  }

  // Create or update summary
  const summary = await prisma.taxYearSummary.upsert({
    where: {
      userId_taxYear: { userId, taxYear },
    },
    create: {
      userId,
      taxYear,
      estimatedTaxLiabilityUsd,
      totalPaymentsUsd,
      cryptoRealizedGainUsd,
      cryptoRealizedLossUsd,
      largestSingleGainUsd,
      cryptoEventCount: cryptoTxs.length,
      cryptoIncomeUsd,
    },
    update: {
      estimatedTaxLiabilityUsd,
      totalPaymentsUsd,
      cryptoRealizedGainUsd,
      cryptoRealizedLossUsd,
      largestSingleGainUsd,
      cryptoEventCount: cryptoTxs.length,
      cryptoIncomeUsd,
      lastCalculated: new Date(),
    },
  })

  console.log("[v0] Tax year summary calculated:", summary)

  return summary
}

// Public function to manually recalculate and check triggers
export async function recalculateAndCheckTriggers(userId: string, taxYear: number) {
  await calculateTaxYearSummary(userId, taxYear)
  return evaluateFiscalLiabilityTrigger({ userId, taxYear })
}
