// Unified Crypto Ledger (UCL) Client
// Provides API for logging crypto transactions across all WIRED CHAOS META apps

import { prisma } from "./db"
import { sendChaosEvent } from "./chaos-patch"

export type CryptoTransactionInput = {
  userId: string
  txHash?: string
  chain: string
  timestamp: Date
  eventType: string
  transactionType: string
  tokenSymbol: string
  tokenAddress?: string
  quantity: number
  fmvUsd?: number
  costBasisUsd?: number
  description?: string
  counterparty?: string
  patchSource?: string
  rawData?: any
}

export type NftTransactionInput = {
  userId: string
  nftId: string
  tokenId?: string
  contractAddress: string
  chain: string
  timestamp: Date
  eventType: string
  cryptoUsed?: string
  cryptoAmount?: number
  fmvUsd?: number
  costBasisUsd?: number
  description?: string
  patchSource?: string
  nftMetadata?: any
}

export type CryptoIncomeInput = {
  userId: string
  incomeType: string
  timestamp: Date
  tokenSymbol: string
  tokenAddress?: string
  chain: string
  quantity: number
  fmvUsd: number
  incomeCategory: string
  description?: string
  source?: string
  patchSource?: string
}

/**
 * Log a crypto transaction (purchases, trades, payments, etc.)
 */
export async function logCryptoTransaction(input: CryptoTransactionInput) {
  // Calculate gain/loss if both FMV and basis are provided
  let gainLossUsd: number | undefined
  if (input.fmvUsd !== undefined && input.costBasisUsd !== undefined) {
    gainLossUsd = input.fmvUsd - input.costBasisUsd
  }

  const transaction = await prisma.cryptoTransaction.create({
    data: {
      userId: input.userId,
      txHash: input.txHash,
      chain: input.chain as any,
      timestamp: input.timestamp,
      eventType: input.eventType as any,
      transactionType: input.transactionType as any,
      tokenSymbol: input.tokenSymbol,
      tokenAddress: input.tokenAddress,
      quantity: input.quantity,
      fmvUsd: input.fmvUsd,
      costBasisUsd: input.costBasisUsd,
      gainLossUsd,
      description: input.description,
      counterparty: input.counterparty,
      patchSource: input.patchSource,
      rawData: input.rawData,
    },
  })

  // Send CHAOS event
  await sendChaosEvent({
    appId: "NEURA_TAX",
    eventType: "crypto_transaction_logged",
    timestamp: new Date().toISOString(),
    userAnonId: input.userId,
    payload: {
      transactionId: transaction.id,
      chain: input.chain,
      eventType: input.eventType,
      tokenSymbol: input.tokenSymbol,
      patchSource: input.patchSource,
    },
  })

  return transaction
}

/**
 * Log an NFT transaction (minting, burning, purchasing, etc.)
 */
export async function logNftTransaction(input: NftTransactionInput) {
  // Calculate gain/loss if applicable
  let gainLossUsd: number | undefined
  if (input.fmvUsd !== undefined && input.costBasisUsd !== undefined) {
    gainLossUsd = input.fmvUsd - input.costBasisUsd
  }

  const transaction = await prisma.nftTransaction.create({
    data: {
      userId: input.userId,
      nftId: input.nftId,
      tokenId: input.tokenId,
      contractAddress: input.contractAddress,
      chain: input.chain as any,
      timestamp: input.timestamp,
      eventType: input.eventType as any,
      cryptoUsed: input.cryptoUsed,
      cryptoAmount: input.cryptoAmount,
      fmvUsd: input.fmvUsd,
      costBasisUsd: input.costBasisUsd,
      gainLossUsd,
      description: input.description,
      patchSource: input.patchSource,
      nftMetadata: input.nftMetadata,
    },
  })

  await sendChaosEvent({
    appId: "NEURA_TAX",
    eventType: "nft_transaction_logged",
    timestamp: new Date().toISOString(),
    userAnonId: input.userId,
    payload: {
      transactionId: transaction.id,
      nftId: input.nftId,
      chain: input.chain,
      eventType: input.eventType,
      patchSource: input.patchSource,
    },
  })

  return transaction
}

/**
 * Log crypto income (rewards, airdrops, staking, etc.)
 */
export async function logCryptoIncome(input: CryptoIncomeInput) {
  const income = await prisma.cryptoIncome.create({
    data: {
      userId: input.userId,
      incomeType: input.incomeType as any,
      timestamp: input.timestamp,
      tokenSymbol: input.tokenSymbol,
      tokenAddress: input.tokenAddress,
      chain: input.chain as any,
      quantity: input.quantity,
      fmvUsd: input.fmvUsd,
      incomeCategory: input.incomeCategory as any,
      description: input.description,
      source: input.source,
      patchSource: input.patchSource,
    },
  })

  await sendChaosEvent({
    appId: "NEURA_TAX",
    eventType: "crypto_income_logged",
    timestamp: new Date().toISOString(),
    userAnonId: input.userId,
    payload: {
      incomeId: income.id,
      incomeType: input.incomeType,
      tokenSymbol: input.tokenSymbol,
      fmvUsd: input.fmvUsd,
      patchSource: input.patchSource,
    },
  })

  return income
}

/**
 * Get all crypto transactions for a user in a tax year
 */
export async function getCryptoTransactionsForYear(userId: string, taxYear: number) {
  const startDate = new Date(`${taxYear}-01-01`)
  const endDate = new Date(`${taxYear}-12-31T23:59:59`)

  return prisma.cryptoTransaction.findMany({
    where: {
      userId,
      timestamp: {
        gte: startDate,
        lte: endDate,
      },
    },
    orderBy: { timestamp: "asc" },
  })
}

/**
 * Get all NFT transactions for a user in a tax year
 */
export async function getNftTransactionsForYear(userId: string, taxYear: number) {
  const startDate = new Date(`${taxYear}-01-01`)
  const endDate = new Date(`${taxYear}-12-31T23:59:59`)

  return prisma.nftTransaction.findMany({
    where: {
      userId,
      timestamp: {
        gte: startDate,
        lte: endDate,
      },
    },
    orderBy: { timestamp: "asc" },
  })
}

/**
 * Get all crypto income for a user in a tax year
 */
export async function getCryptoIncomeForYear(userId: string, taxYear: number) {
  const startDate = new Date(`${taxYear}-01-01`)
  const endDate = new Date(`${taxYear}-12-31T23:59:59`)

  return prisma.cryptoIncome.findMany({
    where: {
      userId,
      timestamp: {
        gte: startDate,
        lte: endDate,
      },
    },
    orderBy: { timestamp: "asc" },
  })
}

/**
 * Calculate total crypto gains/losses for a tax year
 */
export async function calculateCryptoGainsLosses(userId: string, taxYear: number) {
  const transactions = await getCryptoTransactionsForYear(userId, taxYear)
  const nftTransactions = await getNftTransactionsForYear(userId, taxYear)

  let totalGains = 0
  let totalLosses = 0
  let shortTermGains = 0
  const longTermGains = 0

  // Sum up crypto transaction gains/losses
  transactions.forEach((tx) => {
    if (tx.gainLossUsd) {
      const amount = Number.parseFloat(tx.gainLossUsd.toString())
      if (amount > 0) {
        totalGains += amount
        // For MVP, treating all as short-term (would need holding period tracking)
        shortTermGains += amount
      } else {
        totalLosses += Math.abs(amount)
      }
    }
  })

  // Sum up NFT transaction gains/losses
  nftTransactions.forEach((tx) => {
    if (tx.gainLossUsd) {
      const amount = Number.parseFloat(tx.gainLossUsd.toString())
      if (amount > 0) {
        totalGains += amount
        shortTermGains += amount
      } else {
        totalLosses += Math.abs(amount)
      }
    }
  })

  const netGainLoss = totalGains - totalLosses

  return {
    totalGains,
    totalLosses,
    netGainLoss,
    shortTermGains,
    longTermGains,
    transactionCount: transactions.length + nftTransactions.length,
  }
}

/**
 * Calculate total crypto income for a tax year
 */
export async function calculateCryptoIncome(userId: string, taxYear: number) {
  const income = await getCryptoIncomeForYear(userId, taxYear)

  let totalOrdinaryIncome = 0
  let totalSelfEmploymentIncome = 0
  let totalOtherIncome = 0

  income.forEach((inc) => {
    const amount = Number.parseFloat(inc.fmvUsd.toString())
    switch (inc.incomeCategory) {
      case "ORDINARY":
        totalOrdinaryIncome += amount
        break
      case "SELF_EMPLOYMENT":
        totalSelfEmploymentIncome += amount
        break
      case "OTHER":
        totalOtherIncome += amount
        break
    }
  })

  return {
    totalOrdinaryIncome,
    totalSelfEmploymentIncome,
    totalOtherIncome,
    totalIncome: totalOrdinaryIncome + totalSelfEmploymentIncome + totalOtherIncome,
    incomeCount: income.length,
  }
}
