import { z } from 'zod'

// User validation
export const registerSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  name: z.string().min(2, 'Name must be at least 2 characters'),
  citizenshipStatus: z.enum(['US_CITIZEN', 'US_RESIDENT', 'NON_US', 'NON_RESIDENT']),
})

export const signinSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(1, 'Password is required'),
})

// Tax return validation
export const personalInfoSchema = z.object({
  firstName: z.string().min(1, 'First name is required'),
  lastName: z.string().min(1, 'Last name is required'),
  ssn: z.string().regex(/^\d{3}-\d{2}-\d{4}$/, 'Invalid SSN format (XXX-XX-XXXX)'),
  dateOfBirth: z.string().min(1, 'Date of birth is required'),
  address: z.object({
    street: z.string().min(1, 'Street is required'),
    city: z.string().min(1, 'City is required'),
    state: z.string().min(2, 'State is required').max(2),
    zipCode: z.string().regex(/^\d{5}(-\d{4})?$/, 'Invalid ZIP code'),
  }),
})

export const incomeSchema = z.object({
  w2Income: z.array(z.object({
    employer: z.string(),
    wages: z.number().min(0),
    federalWithholding: z.number().min(0),
  })).optional(),
  form1099Income: z.array(z.object({
    payer: z.string(),
    amount: z.number().min(0),
    type: z.enum(['NEC', 'MISC', 'K', 'INT', 'DIV']),
  })).optional(),
})

export type RegisterInput = z.infer<typeof registerSchema>
export type SigninInput = z.infer<typeof signinSchema>
export type PersonalInfoInput = z.infer<typeof personalInfoSchema>
export type IncomeInput = z.infer<typeof incomeSchema>
