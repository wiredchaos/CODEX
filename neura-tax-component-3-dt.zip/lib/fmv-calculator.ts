// Fair Market Value (FMV) Calculator
// Calculates USD fair market value for crypto assets at a given timestamp
// Supports multiple chains: XRPL, DOGE, SOL, ETH, HBAR, BTC

export type ChainType = "XRPL" | "DOGE" | "SOL" | "ETH" | "ETH_L2" | "HBAR" | "BTC" | "OTHER"

export type FMVResult = {
  usdValue: number
  pricePerToken: number
  source: string
  timestamp: Date
}

/**
 * Calculate Fair Market Value for a crypto transaction
 * In production, this would call real price APIs (CoinGecko, CoinMarketCap, etc.)
 * For MVP, returns estimated values
 */
export async function calculateFMV(
  tokenSymbol: string,
  chain: ChainType,
  quantity: number,
  timestamp: Date,
): Promise<FMVResult> {
  // Get price per token
  const pricePerToken = await getHistoricalPrice(tokenSymbol, chain, timestamp)

  // Calculate total USD value
  const usdValue = quantity * pricePerToken

  return {
    usdValue,
    pricePerToken,
    source: "Historical Price Data",
    timestamp,
  }
}

/**
 * Get historical price for a token at a specific timestamp
 * In production, integrate with CoinGecko, CoinMarketCap, or similar
 */
async function getHistoricalPrice(tokenSymbol: string, chain: ChainType, timestamp: Date): Promise<number> {
  // Mock prices for demonstration
  // In production, call actual price APIs with timestamp
  const mockPrices: Record<string, number> = {
    XRP: 0.52,
    DOGE: 0.08,
    SOL: 98.5,
    ETH: 2200,
    HBAR: 0.055,
    BTC: 42000,
    // Add more tokens as needed
  }

  const normalizedSymbol = tokenSymbol.toUpperCase()
  return mockPrices[normalizedSymbol] || 1.0
}

/**
 * Batch calculate FMV for multiple transactions
 */
export async function batchCalculateFMV(
  transactions: Array<{
    tokenSymbol: string
    chain: ChainType
    quantity: number
    timestamp: Date
  }>,
): Promise<FMVResult[]> {
  return Promise.all(transactions.map((tx) => calculateFMV(tx.tokenSymbol, tx.chain, tx.quantity, tx.timestamp)))
}

/**
 * Get current price for a token (used for real-time estimates)
 */
export async function getCurrentPrice(tokenSymbol: string, chain: ChainType): Promise<number> {
  return getHistoricalPrice(tokenSymbol, chain, new Date())
}

/**
 * Validate chain and token combination
 */
export function validateChainToken(tokenSymbol: string, chain: ChainType): boolean {
  const chainTokenMap: Record<ChainType, string[]> = {
    XRPL: ["XRP"],
    DOGE: ["DOGE"],
    SOL: ["SOL", "USDC", "USDT"],
    ETH: ["ETH", "USDC", "USDT", "WETH", "DAI"],
    ETH_L2: ["ETH", "USDC", "USDT"],
    HBAR: ["HBAR"],
    BTC: ["BTC"],
    OTHER: [], // Accept any token for OTHER chain
  }

  if (chain === "OTHER") return true

  const allowedTokens = chainTokenMap[chain] || []
  return allowedTokens.includes(tokenSymbol.toUpperCase())
}

/**
 * Get chain-specific explorer URL for a transaction
 */
export function getExplorerUrl(txHash: string, chain: ChainType): string {
  const explorerUrls: Record<ChainType, string> = {
    XRPL: `https://livenet.xrpl.org/transactions/${txHash}`,
    DOGE: `https://dogechain.info/tx/${txHash}`,
    SOL: `https://solscan.io/tx/${txHash}`,
    ETH: `https://etherscan.io/tx/${txHash}`,
    ETH_L2: `https://arbiscan.io/tx/${txHash}`,
    HBAR: `https://hashscan.io/mainnet/transaction/${txHash}`,
    BTC: `https://blockchair.com/bitcoin/transaction/${txHash}`,
    OTHER: "",
  }

  return explorerUrls[chain] || ""
}

/**
 * Get recommended cost basis method for chain
 */
export function getRecommendedCostBasisMethod(chain: ChainType): "FIFO" | "LIFO" | "HIFO" {
  // IRS default is FIFO, but users can elect other methods
  return "FIFO"
}
