// CHAOS PATCH LAYER - Optional integration with WIRED CHAOS META ecosystem
// When CHAOS_PATCH_ENABLED=false, this app runs standalone

export type ChaosEvent = {
  appId: string
  eventType: string
  timestamp: string
  userAnonId?: string
  payload?: Record<string, any>
}

export async function sendChaosEvent(event: ChaosEvent) {
  // Only send if chaos patch is enabled
  if (process.env.CHAOS_PATCH_ENABLED !== 'true') {
    console.log('[NEURA TAX] Chaos patch disabled, event not sent:', event.eventType)
    return
  }

  const url = process.env.CHAOS_PATCH_URL
  if (!url) {
    console.warn('[NEURA TAX] CHAOS_PATCH_URL not configured')
    return
  }

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        ...event,
        appId: process.env.CHAOS_APP_ID || 'NEURA_TAX',
      }),
    })

    if (!response.ok) {
      console.error('[NEURA TAX] Chaos patch event failed:', response.statusText)
    }
  } catch (error) {
    console.error('[NEURA TAX] Error sending chaos event:', error)
  }
}

// Helper to create anonymized user ID for privacy
export function createAnonId(userId: string): string {
  // Simple hash for anonymization - in production use proper hashing
  return Buffer.from(userId).toString('base64').substring(0, 16)
}
