/**
 * Trinity Core Integration Configuration
 *
 * This configuration defines how this patch (NEURA TAX + Artifact Terminal)
 * integrates with the WIRED CHAOS Trinity 3D Core as a read-only consumer.
 */

export const TRINITY_CONFIG = {
  // Patch Identity
  patchId: "CLEAR",
  patchName: "NEURA TAX + Artifact Terminal",

  // Trinity Mount Configuration
  mountMode: "READ_ONLY" as const,
  environmentKind: "lobby" as const,

  // Timeline Door Assignments
  timelineDoors: {
    NETERU: {
      resolved: true,
      mountPoint: "/artifact-terminal",
      access: "AKIRA_CODEX",
    },
    SIGNAL_ERA: {
      resolved: true,
      mountPoint: null, // Pending assignment
      access: "AKIRA_CODEX",
    },
    RVP: {
      resolved: true,
      mountPoint: null, // Pending assignment
      access: "AKIRA_CODEX",
    },
  },

  // Hotspot Definitions
  hotspots: [
    {
      id: "neteru",
      name: "NETERU Timeline",
      realm: "AKASHIC",
      targetUrl: "/artifact-terminal",
      description: "404 Dynamic NFT Exchange | NTRU Token Economy",
    },
    {
      id: "signal-era",
      name: "SIGNAL ERA Timeline",
      realm: "AKASHIC",
      targetUrl: null,
      description: "Awaiting Timeline Assignment",
    },
    {
      id: "rvp",
      name: "RVP Timeline",
      realm: "AKASHIC",
      targetUrl: null,
      description: "Awaiting Timeline Assignment",
    },
    {
      id: "neura-tax",
      name: "NEURA TAX Portal",
      realm: "BUSINESS",
      targetUrl: "/dashboard",
      description: "IRS-Compliant Tax Preparation | Crypto Ledger | Fiscal Liability Tracking",
    },
    {
      id: "artifact",
      name: "Artifact Terminal",
      realm: "AKASHIC",
      targetUrl: "/artifact-terminal",
      description: "Neteru Apinaya Artifact Exchange | Echo Engineer Tools",
    },
  ],

  // Firewall Configuration
  firewall: {
    enabled: true,
    businessDataIsolation: true,
    piiProtection: true,
    sanitizedProfileMirrorOnly: true,
  },

  // Architectural Constraints
  constraints: {
    canGenerateScenes: false,
    canModifyTimelines: false,
    canForkTimelines: false,
    canWriteToTrinityCore: false,
    mustRespectAkiraCodexGating: true,
  },
} as const

export type TrinityConfig = typeof TRINITY_CONFIG
