// Chain-specific utilities for WIRED CHAOS META ecosystem

import type { ChainType } from "./fmv-calculator"

export type ChainMetadata = {
  name: string
  symbol: string
  nativeToken: string
  blockTime: number // Average block time in seconds
  confirmations: number // Required confirmations
  explorerUrl: string
  iconColor: string // For UI badges
}

/**
 * Get metadata for a specific chain
 */
export function getChainMetadata(chain: ChainType): ChainMetadata {
  const metadata: Record<ChainType, ChainMetadata> = {
    XRPL: {
      name: "XRP Ledger",
      symbol: "XRPL",
      nativeToken: "XRP",
      blockTime: 4,
      confirmations: 1,
      explorerUrl: "https://livenet.xrpl.org",
      iconColor: "#23292F",
    },
    DOGE: {
      name: "Dogecoin",
      symbol: "DOGE",
      nativeToken: "DOGE",
      blockTime: 60,
      confirmations: 6,
      explorerUrl: "https://dogechain.info",
      iconColor: "#C2A633",
    },
    SOL: {
      name: "Solana",
      symbol: "SOL",
      nativeToken: "SOL",
      blockTime: 0.4,
      confirmations: 32,
      explorerUrl: "https://solscan.io",
      iconColor: "#9945FF",
    },
    ETH: {
      name: "Ethereum",
      symbol: "ETH",
      nativeToken: "ETH",
      blockTime: 12,
      confirmations: 12,
      explorerUrl: "https://etherscan.io",
      iconColor: "#627EEA",
    },
    ETH_L2: {
      name: "Ethereum L2",
      symbol: "L2",
      nativeToken: "ETH",
      blockTime: 2,
      confirmations: 1,
      explorerUrl: "https://arbiscan.io",
      iconColor: "#28A0F0",
    },
    HBAR: {
      name: "Hedera",
      symbol: "HBAR",
      nativeToken: "HBAR",
      blockTime: 3,
      confirmations: 1,
      explorerUrl: "https://hashscan.io",
      iconColor: "#222222",
    },
    BTC: {
      name: "Bitcoin",
      symbol: "BTC",
      nativeToken: "BTC",
      blockTime: 600,
      confirmations: 6,
      explorerUrl: "https://blockchair.com/bitcoin",
      iconColor: "#F7931A",
    },
    OTHER: {
      name: "Other Chain",
      symbol: "OTHER",
      nativeToken: "UNKNOWN",
      blockTime: 10,
      confirmations: 1,
      explorerUrl: "",
      iconColor: "#6B7280",
    },
  }

  return metadata[chain]
}

/**
 * Get all supported chains for WIRED CHAOS META
 */
export function getSupportedChains(): ChainType[] {
  return ["XRPL", "DOGE", "SOL", "ETH", "ETH_L2", "HBAR", "BTC"]
}

/**
 * Check if a chain supports smart contracts
 */
export function supportsSmartContracts(chain: ChainType): boolean {
  return ["ETH", "ETH_L2", "SOL"].includes(chain)
}

/**
 * Check if a chain supports NFTs natively
 */
export function supportsNFTs(chain: ChainType): boolean {
  return ["ETH", "ETH_L2", "SOL", "XRPL"].includes(chain)
}

/**
 * Get gas/fee token for a chain
 */
export function getGasToken(chain: ChainType): string {
  const metadata = getChainMetadata(chain)
  return metadata.nativeToken
}

/**
 * Format address for display based on chain
 */
export function formatAddress(address: string, chain: ChainType): string {
  if (!address) return ""

  // Shorten address for display
  if (address.length > 20) {
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`
  }

  return address
}

/**
 * Validate address format for chain
 */
export function isValidAddress(address: string, chain: ChainType): boolean {
  // Basic validation - in production, use chain-specific validation libraries
  if (!address) return false

  switch (chain) {
    case "XRPL":
      return address.startsWith("r") && address.length >= 25
    case "ETH":
    case "ETH_L2":
      return address.startsWith("0x") && address.length === 42
    case "SOL":
      return address.length >= 32 && address.length <= 44
    case "DOGE":
      return address.startsWith("D") && address.length >= 25
    case "HBAR":
      return /^\d+\.\d+\.\d+$/.test(address)
    case "BTC":
      return (address.startsWith("1") || address.startsWith("3") || address.startsWith("bc1")) && address.length >= 26
    default:
      return address.length > 0
  }
}

/**
 * Get recommended number of decimal places for token on chain
 */
export function getTokenDecimals(tokenSymbol: string, chain: ChainType): number {
  // Standard decimals per token
  const decimals: Record<string, number> = {
    BTC: 8,
    ETH: 18,
    SOL: 9,
    XRP: 6,
    DOGE: 8,
    HBAR: 8,
    USDC: 6,
    USDT: 6,
  }

  return decimals[tokenSymbol.toUpperCase()] || 18
}
