import type { TaxReturn } from "@prisma/client"

export type RiskSeverity = "LOW" | "MEDIUM" | "HIGH"

export type RiskFlag = {
  code: string
  severity: RiskSeverity
  description: string
}

export function analyzeRiskFlags(taxReturn: TaxReturn): RiskFlag[] {
  const flags: RiskFlag[] = []

  try {
    const data = taxReturn.dataJson as any
    const summary = taxReturn.summaryJson as any

    // Rule 1: Schedule C income present but no expenses
    if (data?.income?.scheduleC && data.income.scheduleC.length > 0) {
      const hasExpenses =
        data.deductions?.businessExpenses && Object.values(data.deductions.businessExpenses).some((val: any) => val > 0)

      if (!hasExpenses) {
        flags.push({
          code: "SCHEDULE_C_NO_EXPENSES",
          severity: "HIGH",
          description: "Schedule C income reported with no business expenses. This may trigger IRS audit scrutiny.",
        })
      }
    }

    // Rule 2: Deductions exceed 60% of income
    if (summary?.totalIncome && summary?.totalDeductions) {
      const deductionRatio = summary.totalDeductions / summary.totalIncome
      if (deductionRatio > 0.6) {
        flags.push({
          code: "HIGH_DEDUCTION_RATIO",
          severity: "HIGH",
          description: `Deductions represent ${(deductionRatio * 100).toFixed(1)}% of income, exceeding the 60% threshold commonly flagged by IRS algorithms.`,
        })
      }
    }

    // Rule 3: Large cash income without proper documentation
    if (data?.income?.other) {
      const cashIncome = data.income.other.find((item: any) => item.description?.toLowerCase().includes("cash"))
      if (cashIncome && cashIncome.amount > 10000) {
        flags.push({
          code: "LARGE_CASH_INCOME",
          severity: "MEDIUM",
          description: "Large cash income reported. Ensure proper documentation is available for IRS verification.",
        })
      }
    }

    // Rule 4: Home office deduction without business use percentage
    if (data?.deductions?.homeOffice && !data?.deductions?.homeOfficePercentage) {
      flags.push({
        code: "HOME_OFFICE_INCOMPLETE",
        severity: "MEDIUM",
        description: "Home office deduction claimed without documented business use percentage.",
      })
    }

    // Rule 5: Unusually high charitable contributions
    if (data?.deductions?.charitable && summary?.totalIncome) {
      const charitableRatio = data.deductions.charitable / summary.totalIncome
      if (charitableRatio > 0.3) {
        flags.push({
          code: "HIGH_CHARITABLE_DEDUCTIONS",
          severity: "MEDIUM",
          description: `Charitable contributions exceed 30% of income. IRS may request additional documentation.`,
        })
      }
    }

    // Rule 6: Round numbers suggesting estimation
    if (data?.income?.w2) {
      const hasRoundNumbers = data.income.w2.some((w2: any) => w2.wages % 1000 === 0 && w2.wages > 10000)
      if (hasRoundNumbers) {
        flags.push({
          code: "ROUND_NUMBER_AMOUNTS",
          severity: "LOW",
          description:
            "Round number amounts detected. Ensure all figures are based on actual documentation, not estimates.",
        })
      }
    }

    // Rule 7: Missing state information
    if (!data?.personalInfo?.state) {
      flags.push({
        code: "MISSING_STATE_INFO",
        severity: "LOW",
        description: "State residency information missing. This may delay e-file acceptance.",
      })
    }
  } catch (error) {
    console.error("[v0] Risk analysis error:", error)
    flags.push({
      code: "ANALYSIS_ERROR",
      severity: "LOW",
      description: "Unable to complete full risk analysis. Manual review recommended.",
    })
  }

  return flags
}

export function calculateRiskScore(flags: RiskFlag[]): number {
  let score = 0

  flags.forEach((flag) => {
    switch (flag.severity) {
      case "HIGH":
        score += 10
        break
      case "MEDIUM":
        score += 5
        break
      case "LOW":
        score += 2
        break
    }
  })

  return Math.min(score, 100)
}

export function getRiskLevel(score: number): { level: string; color: string } {
  if (score >= 15) return { level: "High Risk", color: "text-red-500" }
  if (score >= 7) return { level: "Medium Risk", color: "text-yellow-500" }
  if (score > 0) return { level: "Low Risk", color: "text-blue-500" }
  return { level: "No Flags", color: "text-green-500" }
}
