// ═══════════════════════════════════════════════════════════════════════════════
// CREATOR CODEX — TYPE DEFINITIONS & INTERFACES
// Aligned with Akira Codex Tier Firewall System
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Age-gated content tiers matching the Akira Codex firewall system
 */
export type AgeTier = "UNDER_18" | "18_PLUS" | "RED_VEIL_21"

/**
 * Content rating descriptors for publishing platforms
 */
export type ContentRating = "ALL_AGES" | "TEEN" | "MATURE" | "ADULT"

/**
 * Genre categories for story classification
 */
export type StoryGenre =
  | "FANTASY"
  | "SCI_FI"
  | "ROMANCE"
  | "THRILLER"
  | "HORROR"
  | "MYSTERY"
  | "LITERARY"
  | "ADVENTURE"
  | "DARK_FANTASY"
  | "URBAN_FANTASY"
  | "DYSTOPIAN"
  | "PARANORMAL"

/**
 * Story tone/mood classifications
 */
export type StoryTone = "LIGHT" | "DRAMATIC" | "DARK" | "COMEDIC" | "SUSPENSEFUL" | "ROMANTIC" | "MELANCHOLIC" | "EPIC"

/**
 * Gate types for content filtering
 */
export type ContentGate = "LIGHT_GATE" | "SHADOW_GATE" | "RED_VEIL"

/**
 * Initial story seed structure for generation pipeline
 */
export interface StorySeed {
  id: string
  concept: string
  title: string
  premise: string
  ageTier: AgeTier
  contentGate: ContentGate
  genres: StoryGenre[]
  tone: StoryTone
  targetWordCount: number
  chapterCount: number
  protagonistArchetype: string
  antagonistArchetype: string
  settingDescription: string
  thematicElements: string[]
  plotHooks: string[]
  createdAt: Date
}

/**
 * Individual chapter structure
 */
export interface Chapter {
  id: string
  novellaId: string
  number: number
  title: string
  content: string
  wordCount: number
  summary: string
  keyEvents: string[]
  emotionalArc: string
  generatedAt: Date
}

/**
 * Complete mini-novella structure
 */
export interface MiniNovella {
  id: string
  seed: StorySeed
  metadata: BookMetadata
  chapters: Chapter[]
  totalWordCount: number
  status: "DRAFT" | "COMPLETE" | "PUBLISHED"
  createdAt: Date
  updatedAt: Date
}

/**
 * Publishing metadata for Kindle/self-publishing
 */
export interface BookMetadata {
  title: string
  subtitle?: string
  author: string
  penName?: string
  blurb: string
  longDescription: string
  genres: StoryGenre[]
  keywords: string[]
  ageTier: AgeTier
  contentRating: ContentRating
  language: string
  isbn?: string
  asin?: string
  coverImageUrl?: string
  seriesName?: string
  seriesNumber?: number
  copyrightYear: number
  publisher: string
}

/**
 * Gate configuration for content filtering
 */
export interface GateConfiguration {
  gate: ContentGate
  ageTier: AgeTier
  allowedThemes: string[]
  restrictedThemes: string[]
  contentRules: string[]
}

/**
 * Default gate configurations
 */
export const GATE_CONFIGS: Record<ContentGate, GateConfiguration> = {
  LIGHT_GATE: {
    gate: "LIGHT_GATE",
    ageTier: "UNDER_18",
    allowedThemes: ["adventure", "friendship", "courage", "discovery", "growth", "humor", "mystery", "fantasy"],
    restrictedThemes: ["explicit violence", "gore", "sexual content", "substance abuse", "extreme horror"],
    contentRules: [
      "No adult content of any kind",
      "Violence must be mild and consequence-aware",
      "Focus on positive character development",
      "Age-appropriate language only",
    ],
  },
  SHADOW_GATE: {
    gate: "SHADOW_GATE",
    ageTier: "18_PLUS",
    allowedThemes: [
      "mature romance",
      "complex morality",
      "psychological tension",
      "dark themes",
      "violence",
      "trauma exploration",
    ],
    restrictedThemes: ["explicit sexual content", "gratuitous gore", "illegal content"],
    contentRules: [
      "Mature themes allowed with tasteful handling",
      "Fade-to-black for intimate scenes",
      "Violence can be intense but purposeful",
      "Adult language permitted in context",
    ],
  },
  RED_VEIL: {
    gate: "RED_VEIL",
    ageTier: "RED_VEIL_21",
    allowedThemes: [
      "symbolic intimacy",
      "metaphorical passion",
      "poetic sensuality",
      "shadow archetypes",
      "primal themes",
    ],
    restrictedThemes: [
      "explicit anatomical detail",
      "graphic sexual description",
      "illegal content",
      "non-consensual scenarios",
    ],
    contentRules: [
      "Symbolic and metaphorical NSFW only",
      "Poetic/artistic expression of intimacy",
      "No explicit anatomical descriptions",
      "Consent must be implicit or explicit",
      "Shadow/veil language for intimate moments",
    ],
  },
}

/**
 * Utility to map AgeTier to ContentGate
 */
export function ageTierToGate(tier: AgeTier): ContentGate {
  switch (tier) {
    case "UNDER_18":
      return "LIGHT_GATE"
    case "18_PLUS":
      return "SHADOW_GATE"
    case "RED_VEIL_21":
      return "RED_VEIL"
  }
}

/**
 * Utility to map ContentGate to ContentRating
 */
export function gateToRating(gate: ContentGate): ContentRating {
  switch (gate) {
    case "LIGHT_GATE":
      return "TEEN"
    case "SHADOW_GATE":
      return "MATURE"
    case "RED_VEIL":
      return "ADULT"
  }
}

/**
 * Generate a unique ID for entities
 */
export function generateId(prefix: string): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`
}
