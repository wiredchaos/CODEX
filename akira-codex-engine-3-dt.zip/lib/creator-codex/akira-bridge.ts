// ═══════════════════════════════════════════════════════════════════════════════
// CREATOR CODEX → AKIRA CODEX BRIDGE LAYER
// Consumer contract for canon governance and lore integration
// ═══════════════════════════════════════════════════════════════════════════════

import type { LoreReference, LoreCategory } from "@/lib/akira-codex/core/codex-models"
import type { PatchRequest } from "@/lib/akira-codex/core/codex-registry"

// ─────────────────────────────────────────────────────────────────────────────────
// CREATOR CODEX IDENTITY (CONSUMER ROLE)
// ─────────────────────────────────────────────────────────────────────────────────

export const CREATOR_CODEX_IDENTITY = {
  SYSTEM_NAME: "CREATOR_CODEX",
  ROLE: "AUTHORING_AND_PRODUCTION",
  AUTHORITY_LEVEL: "CONSUMER",
  CANON_OWNER: "AKIRA_CODEX",

  // Clear responsibility boundaries
  CAPABILITIES: [
    "Interactive storytelling",
    "Branching narratives",
    "Script and episode generation",
    "Film and episodic packaging",
    "Mint packaging authorization (not governance)",
  ],

  RESTRICTIONS: [
    "Cannot self-canonize content",
    "Cannot bypass Akira decisions",
    "Cannot modify canon locks",
    "Cannot create lore entries",
    "Must submit canonization candidates only",
  ],
} as const

// ─────────────────────────────────────────────────────────────────────────────────
// LORE CONSUMPTION (READ-ONLY)
// ─────────────────────────────────────────────────────────────────────────────────

/**
 * Read-only lore object from Akira Codex
 */
export interface LoreObject {
  id: string
  category: LoreCategory
  title: string
  content: string
  canonLocked: boolean
  lastUpdated: Date
}

/**
 * Consume lore from Akira Codex (READ-ONLY)
 * Creator Codex CANNOT modify these objects
 */
export async function consumeLoreFromAkira(category?: LoreCategory): Promise<LoreObject[]> {
  // In production, this would use the PatchRequest system
  // For now, direct import with read-only contract

  const { initializeLoreDatabase, getLoreByCategory } = await import("@/lib/akira-codex/lore/lore-database")
  const db = initializeLoreDatabase()

  const entries = category ? getLoreByCategory(db, category) : db.entries

  return entries.map((entry) => ({
    id: entry.id,
    category: entry.category,
    title: entry.title,
    content: entry.content,
    canonLocked: true, // All Akira lore is canon-locked
    lastUpdated: entry.createdAt,
  }))
}

/**
 * Get specific lore reference for story integration
 */
export async function fetchLoreReference(entryId: string): Promise<LoreReference | null> {
  const { initializeLoreDatabase, getLoreReference } = await import("@/lib/akira-codex/lore/lore-database")
  const db = initializeLoreDatabase()
  return getLoreReference(db, entryId)
}

// ─────────────────────────────────────────────────────────────────────────────────
// CANONIZATION SUBMISSION SYSTEM
// ─────────────────────────────────────────────────────────────────────────────────

/**
 * Status of canonization request
 */
export type CanonizationStatus = "DRAFT" | "SUBMITTED" | "UNDER_REVIEW" | "APPROVED" | "REJECTED" | "MODIFIED"

/**
 * Canonization candidate — content created in Creator Codex
 * that may be submitted to Akira for canon approval
 */
export interface CanonizationCandidate {
  id: string
  type: "STORY" | "CHARACTER" | "SETTING" | "EVENT" | "LORE_EXPANSION"
  title: string
  summary: string
  fullContent: string

  // Lore integration
  loreReferences: LoreReference[]
  proposedCategory?: LoreCategory

  // Safety and deniability
  isAbstractArchetype: boolean
  containsRealPeople: boolean
  containsRealOrgs: boolean
  containsClaims: boolean
  fictionalFraming: boolean

  // Submission metadata
  status: CanonizationStatus
  submittedAt?: Date
  reviewNotes?: string
  approvedAt?: Date
  rejectedReason?: string
}

/**
 * Create a canonization candidate (for Akira review)
 */
export function createCanonizationCandidate(
  params: Omit<CanonizationCandidate, "id" | "status" | "submittedAt">,
): CanonizationCandidate {
  // Validate safety requirements
  if (!params.fictionalFraming) {
    throw new Error("SAFETY_VIOLATION: All canonization candidates must have fictional framing")
  }

  if (params.containsRealPeople || params.containsRealOrgs || params.containsClaims) {
    throw new Error("DENIABILITY_VIOLATION: Cannot submit content referencing real people, orgs, or claims")
  }

  if (!params.isAbstractArchetype) {
    throw new Error("ARCHETYPE_VIOLATION: All characters must be abstract archetypes, not specific individuals")
  }

  return {
    ...params,
    id: `CC_CANDIDATE_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
    status: "DRAFT",
  }
}

/**
 * Submit candidate to Akira Codex for review
 */
export async function submitToAkiraForReview(
  candidate: CanonizationCandidate,
): Promise<{ success: boolean; message: string }> {
  // Validate candidate is ready for submission
  if (candidate.status !== "DRAFT") {
    return {
      success: false,
      message: `Cannot submit candidate with status: ${candidate.status}`,
    }
  }

  // In production, this would create a PatchRequest to Akira Codex
  const patchRequest: PatchRequest = {
    id: `PATCH_${Date.now()}`,
    sourceSystem: "CREATOR_CODEX",
    targetModule: "STORY_ENGINE", // Akira's story engine reviews canonization
    operation: "WRITE",
    payload: {
      type: "CANONIZATION_REQUEST",
      candidate,
    },
    timestamp: new Date(),
    signature: "CREATOR_CODEX_SIGNATURE", // In production, proper cryptographic signature
  }

  // For now, mark as submitted
  candidate.status = "SUBMITTED"
  candidate.submittedAt = new Date()

  return {
    success: true,
    message: "Canonization candidate submitted to Akira Codex for review",
  }
}

// ─────────────────────────────────────────────────────────────────────────────────
// CANON LOCK ENFORCEMENT
// ─────────────────────────────────────────────────────────────────────────────────

/**
 * Canon lock status — prevents modification of approved content
 */
export interface CanonLock {
  entityId: string
  entityType: string
  lockedBy: "AKIRA_CODEX"
  lockedAt: Date
  reason: string
}

/**
 * Check if content is canon-locked (enforces read-only)
 */
export function isCanonLocked(entityId: string, locks: CanonLock[]): boolean {
  return locks.some((lock) => lock.entityId === entityId)
}

/**
 * Attempt to modify canon-locked content (will throw error)
 */
export function enforceCanonLock(entityId: string, locks: CanonLock[]): void {
  const lock = locks.find((l) => l.entityId === entityId)
  if (lock) {
    throw new Error(
      `CANON_LOCK_VIOLATION: Cannot modify ${lock.entityType} "${entityId}". ` +
        `Locked by ${lock.lockedBy} on ${lock.lockedAt.toISOString()}. ` +
        `Reason: ${lock.reason}`,
    )
  }
}

// ─────────────────────────────────────────────────────────────────────────────────
// SAFETY AND DENIABILITY VALIDATION
// ─────────────────────────────────────────────────────────────────────────────────

/**
 * Validate content for safety and deniability before submission
 */
export interface SafetyValidation {
  passed: boolean
  violations: string[]
  warnings: string[]
}

export function validateContentSafety(
  content: string,
  metadata: {
    containsRealPeople: boolean
    containsRealOrgs: boolean
    containsClaims: boolean
    fictionalFraming: boolean
    isAbstractArchetype: boolean
  },
): SafetyValidation {
  const violations: string[] = []
  const warnings: string[] = []

  // Hard violations (will block submission)
  if (metadata.containsRealPeople) {
    violations.push("Content references real people — must use abstract archetypes only")
  }

  if (metadata.containsRealOrgs) {
    violations.push("Content references real organizations — must use fictional entities only")
  }

  if (metadata.containsClaims) {
    violations.push("Content makes real-world claims — must be purely fictional")
  }

  if (!metadata.fictionalFraming) {
    violations.push("Content lacks fictional framing — all content must be clearly marked as fiction")
  }

  if (!metadata.isAbstractArchetype) {
    violations.push("Characters are not abstract archetypes — must avoid specific identifiable individuals")
  }

  // Soft warnings (won't block, but should be reviewed)
  const lowerContent = content.toLowerCase()

  const sensitiveTerms = [
    "real person",
    "actual person",
    "based on true events",
    "conspiracy",
    "government",
    "corporation",
    "lawsuit",
    "defamation",
    "libel",
    "slander",
  ]

  for (const term of sensitiveTerms) {
    if (lowerContent.includes(term)) {
      warnings.push(`Content contains potentially sensitive term: "${term}"`)
    }
  }

  return {
    passed: violations.length === 0,
    violations,
    warnings,
  }
}
