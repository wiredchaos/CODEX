// ═══════════════════════════════════════════════════════════════════════════════
// CREATOR CODEX — KINDLE/EPUB EXPORT UTILITIES
// Generates publishing-ready packages for self-publishing workflows
// ═══════════════════════════════════════════════════════════════════════════════

import type { MiniNovella, BookMetadata, Chapter } from "./creator-codex-models"

/**
 * Complete export package for Kindle/EPUB publishing
 */
export interface KindleExportPackage {
  /** Unique export ID */
  id: string
  /** Book metadata for publishing platforms */
  metadata: BookMetadata
  /** Full manuscript as single string (EPUB-ready) */
  manuscript: string
  /** Individual chapter files for platforms that need them */
  chapterFiles: ChapterFile[]
  /** Table of contents structure */
  toc: TocEntry[]
  /** Front matter content */
  frontMatter: FrontMatter
  /** Back matter content */
  backMatter: BackMatter
  /** Export timestamp */
  exportedAt: Date
  /** Format version */
  formatVersion: string
}

export interface ChapterFile {
  filename: string
  title: string
  content: string
  wordCount: number
}

export interface TocEntry {
  title: string
  anchor: string
  level: number
}

export interface FrontMatter {
  titlePage: string
  copyrightPage: string
  dedication?: string
  epigraph?: string
}

export interface BackMatter {
  authorBio?: string
  acknowledgments?: string
  alsoBy?: string[]
  newsletter?: string
}

// ─────────────────────────────────────────────────────────────────────────────
// EXPORT PACKAGE BUILDER
// ─────────────────────────────────────────────────────────────────────────────

export interface BuildExportOptions {
  novella: MiniNovella
  authorBio?: string
  dedication?: string
  epigraph?: string
  acknowledgments?: string
  alsoByTitles?: string[]
  newsletterLink?: string
}

export function buildKindleExportPayload(options: BuildExportOptions): KindleExportPackage {
  const { novella, authorBio, dedication, epigraph, acknowledgments, alsoByTitles, newsletterLink } = options

  const { metadata, chapters } = novella

  // Generate front matter
  const frontMatter = generateFrontMatter(metadata, dedication, epigraph)

  // Generate back matter
  const backMatter = generateBackMatter(authorBio, acknowledgments, alsoByTitles, newsletterLink)

  // Build table of contents
  const toc = buildTableOfContents(chapters)

  // Generate chapter files
  const chapterFiles = chapters.map((chapter, index) => ({
    filename: `chapter-${String(index + 1).padStart(2, "0")}.html`,
    title: chapter.title,
    content: formatChapterForEpub(chapter),
    wordCount: chapter.wordCount,
  }))

  // Concatenate full manuscript
  const manuscript = buildFullManuscript(frontMatter, chapters, backMatter, metadata)

  return {
    id: `export_${novella.id}_${Date.now()}`,
    metadata,
    manuscript,
    chapterFiles,
    toc,
    frontMatter,
    backMatter,
    exportedAt: new Date(),
    formatVersion: "1.0.0",
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// HELPER FUNCTIONS
// ─────────────────────────────────────────────────────────────────────────────

function generateFrontMatter(metadata: BookMetadata, dedication?: string, epigraph?: string): FrontMatter {
  const titlePage = `
<div class="title-page">
  <h1 class="book-title">${escapeHtml(metadata.title)}</h1>
  ${metadata.subtitle ? `<h2 class="book-subtitle">${escapeHtml(metadata.subtitle)}</h2>` : ""}
  <p class="book-author">by ${escapeHtml(metadata.penName || metadata.author)}</p>
</div>
`.trim()

  const copyrightPage = `
<div class="copyright-page">
  <p>Copyright © ${metadata.copyrightYear} ${escapeHtml(metadata.author)}</p>
  <p>All rights reserved.</p>
  <p>Published by ${escapeHtml(metadata.publisher)}</p>
  ${metadata.isbn ? `<p>ISBN: ${metadata.isbn}</p>` : ""}
  <p class="legal">
    This is a work of fiction. Names, characters, places, and incidents either are the product 
    of the author's imagination or are used fictitiously. Any resemblance to actual persons, 
    living or dead, events, or locales is entirely coincidental.
  </p>
</div>
`.trim()

  return {
    titlePage,
    copyrightPage,
    dedication: dedication ? `<div class="dedication"><p>${escapeHtml(dedication)}</p></div>` : undefined,
    epigraph: epigraph ? `<div class="epigraph"><blockquote>${escapeHtml(epigraph)}</blockquote></div>` : undefined,
  }
}

function generateBackMatter(
  authorBio?: string,
  acknowledgments?: string,
  alsoBy?: string[],
  newsletter?: string,
): BackMatter {
  return {
    authorBio: authorBio
      ? `<div class="author-bio"><h2>About the Author</h2><p>${escapeHtml(authorBio)}</p></div>`
      : undefined,
    acknowledgments: acknowledgments
      ? `<div class="acknowledgments"><h2>Acknowledgments</h2><p>${escapeHtml(acknowledgments)}</p></div>`
      : undefined,
    alsoBy,
    newsletter: newsletter
      ? `<div class="newsletter"><h2>Stay Connected</h2><p>Join the newsletter: <a href="${escapeHtml(newsletter)}">${escapeHtml(newsletter)}</a></p></div>`
      : undefined,
  }
}

function buildTableOfContents(chapters: Chapter[]): TocEntry[] {
  return chapters.map((chapter, index) => ({
    title: chapter.title || `Chapter ${index + 1}`,
    anchor: `chapter-${index + 1}`,
    level: 1,
  }))
}

function formatChapterForEpub(chapter: Chapter): string {
  // Convert plain text to basic HTML with paragraph breaks
  const paragraphs = chapter.content
    .split(/\n\n+/)
    .filter((p) => p.trim())
    .map((p) => `<p>${escapeHtml(p.trim())}</p>`)
    .join("\n")

  return `
<div class="chapter" id="chapter-${chapter.number}">
  <h2 class="chapter-title">${escapeHtml(chapter.title)}</h2>
  <div class="chapter-content">
    ${paragraphs}
  </div>
</div>
`.trim()
}

function buildFullManuscript(
  frontMatter: FrontMatter,
  chapters: Chapter[],
  backMatter: BackMatter,
  metadata: BookMetadata,
): string {
  const parts: string[] = []

  // Front matter
  parts.push("<!-- FRONT MATTER -->")
  parts.push(frontMatter.titlePage)
  parts.push(frontMatter.copyrightPage)
  if (frontMatter.dedication) parts.push(frontMatter.dedication)
  if (frontMatter.epigraph) parts.push(frontMatter.epigraph)

  // Table of Contents
  parts.push("<!-- TABLE OF CONTENTS -->")
  parts.push('<div class="toc">')
  parts.push("<h2>Contents</h2>")
  parts.push("<nav>")
  chapters.forEach((chapter, i) => {
    parts.push(`  <p><a href="#chapter-${i + 1}">${escapeHtml(chapter.title)}</a></p>`)
  })
  parts.push("</nav>")
  parts.push("</div>")

  // Chapters
  parts.push("<!-- CHAPTERS -->")
  chapters.forEach((chapter) => {
    parts.push(formatChapterForEpub(chapter))
    parts.push('<div class="chapter-break"></div>')
  })

  // Back matter
  parts.push("<!-- BACK MATTER -->")
  if (backMatter.acknowledgments) parts.push(backMatter.acknowledgments)
  if (backMatter.authorBio) parts.push(backMatter.authorBio)
  if (backMatter.alsoBy && backMatter.alsoBy.length > 0) {
    parts.push('<div class="also-by">')
    parts.push("<h2>Also by this Author</h2>")
    parts.push("<ul>")
    backMatter.alsoBy.forEach((title) => {
      parts.push(`  <li>${escapeHtml(title)}</li>`)
    })
    parts.push("</ul>")
    parts.push("</div>")
  }
  if (backMatter.newsletter) parts.push(backMatter.newsletter)

  // Wrap in document structure
  return `<!DOCTYPE html>
<html lang="${metadata.language}">
<head>
  <meta charset="UTF-8">
  <title>${escapeHtml(metadata.title)}</title>
  <meta name="author" content="${escapeHtml(metadata.author)}">
  <meta name="description" content="${escapeHtml(metadata.blurb)}">
</head>
<body>
${parts.join("\n\n")}
</body>
</html>`
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;")
}

// ─────────────────────────────────────────────────────────────────────────────
// EXPORT UTILITIES
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Generate a simple markdown version for preview
 */
export function exportToMarkdown(novella: MiniNovella): string {
  const { metadata, chapters } = novella

  let md = `# ${metadata.title}\n\n`
  md += `*by ${metadata.penName || metadata.author}*\n\n`
  md += `---\n\n`
  md += `${metadata.blurb}\n\n`
  md += `---\n\n`

  chapters.forEach((chapter) => {
    md += `## ${chapter.title}\n\n`
    md += `${chapter.content}\n\n`
    md += `---\n\n`
  })

  return md
}

/**
 * Calculate reading time estimate
 */
export function estimateReadingTime(wordCount: number): string {
  const wordsPerMinute = 200
  const minutes = Math.ceil(wordCount / wordsPerMinute)

  if (minutes < 60) {
    return `${minutes} min read`
  }

  const hours = Math.floor(minutes / 60)
  const remainingMinutes = minutes % 60
  return `${hours}h ${remainingMinutes}m read`
}
