// ═══════════════════════════════════════════════════════════════════════════════
// CREATOR CODEX — INTEGRATION TEST
// Validates governance boundaries and contracts
// ═══════════════════════════════════════════════════════════════════════════════

import { consumeLoreFromAkira, createCanonizationCandidate, validateContentSafety } from "./akira-bridge"
import { validateCreatorCodexBoundaries, registerWithParentSystems } from "./registry"

/**
 * Test suite for Creator Codex structural enforcement
 */
export async function runIntegrationTests(): Promise<{
  passed: number
  failed: number
  results: Array<{ test: string; passed: boolean; error?: string }>
}> {
  const results: Array<{ test: string; passed: boolean; error?: string }> = []
  let passed = 0
  let failed = 0

  // ─────────────────────────────────────────────────────────────────────────
  // TEST 1: Lore consumption (READ-ONLY)
  // ─────────────────────────────────────────────────────────────────────────
  try {
    const lore = await consumeLoreFromAkira("MEROVINGIAN")
    if (lore.length > 0 && lore[0].canonLocked) {
      results.push({ test: "Lore consumption (READ-ONLY)", passed: true })
      passed++
    } else {
      throw new Error("Lore not properly locked or empty")
    }
  } catch (error) {
    results.push({
      test: "Lore consumption (READ-ONLY)",
      passed: false,
      error: String(error),
    })
    failed++
  }

  // ─────────────────────────────────────────────────────────────────────────
  // TEST 2: Boundary validation (should block self-canonization)
  // ─────────────────────────────────────────────────────────────────────────
  try {
    const validation = validateCreatorCodexBoundaries("self-canonize")
    if (!validation.allowed) {
      results.push({ test: "Boundary enforcement (self-canonize blocked)", passed: true })
      passed++
    } else {
      throw new Error("Self-canonization should be blocked")
    }
  } catch (error) {
    results.push({
      test: "Boundary enforcement (self-canonize blocked)",
      passed: false,
      error: String(error),
    })
    failed++
  }

  // ─────────────────────────────────────────────────────────────────────────
  // TEST 3: Safety validation (abstract archetypes only)
  // ─────────────────────────────────────────────────────────────────────────
  try {
    const unsafeMeta = {
      containsRealPeople: true,
      containsRealOrgs: false,
      containsClaims: false,
      fictionalFraming: true,
      isAbstractArchetype: false,
    }

    const safety = validateContentSafety("Test content", unsafeMeta)

    if (!safety.passed && safety.violations.length > 0) {
      results.push({ test: "Safety validation (real people blocked)", passed: true })
      passed++
    } else {
      throw new Error("Real people should fail safety check")
    }
  } catch (error) {
    results.push({
      test: "Safety validation (real people blocked)",
      passed: false,
      error: String(error),
    })
    failed++
  }

  // ─────────────────────────────────────────────────────────────────────────
  // TEST 4: Canonization candidate creation (valid)
  // ─────────────────────────────────────────────────────────────────────────
  try {
    const candidate = createCanonizationCandidate({
      type: "STORY",
      title: "The Shadow Merchant",
      summary: "A tale of abstract archetypes in a fictional realm",
      fullContent: "Once upon a time, in a realm beyond...",
      loreReferences: [],
      isAbstractArchetype: true,
      containsRealPeople: false,
      containsRealOrgs: false,
      containsClaims: false,
      fictionalFraming: true,
    })

    if (candidate.id && candidate.status === "DRAFT") {
      results.push({ test: "Canonization candidate creation (valid)", passed: true })
      passed++
    } else {
      throw new Error("Candidate creation failed")
    }
  } catch (error) {
    results.push({
      test: "Canonization candidate creation (valid)",
      passed: false,
      error: String(error),
    })
    failed++
  }

  // ─────────────────────────────────────────────────────────────────────────
  // TEST 5: Canonization candidate creation (invalid - real people)
  // ─────────────────────────────────────────────────────────────────────────
  try {
    createCanonizationCandidate({
      type: "STORY",
      title: "Test",
      summary: "Test",
      fullContent: "Test",
      loreReferences: [],
      isAbstractArchetype: false,
      containsRealPeople: true,
      containsRealOrgs: false,
      containsClaims: false,
      fictionalFraming: true,
    })

    // Should have thrown
    results.push({
      test: "Canonization candidate rejection (real people)",
      passed: false,
      error: "Should have thrown DENIABILITY_VIOLATION",
    })
    failed++
  } catch (error) {
    if (String(error).includes("DENIABILITY_VIOLATION")) {
      results.push({ test: "Canonization candidate rejection (real people)", passed: true })
      passed++
    } else {
      results.push({
        test: "Canonization candidate rejection (real people)",
        passed: false,
        error: String(error),
      })
      failed++
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // TEST 6: Parent system registration
  // ─────────────────────────────────────────────────────────────────────────
  try {
    const registration = await registerWithParentSystems()
    if (registration.akiraRegistered && registration.trinityRegistered) {
      results.push({ test: "Parent system registration", passed: true })
      passed++
    } else {
      throw new Error(`Registration incomplete: ${registration.errors.join(", ")}`)
    }
  } catch (error) {
    results.push({
      test: "Parent system registration",
      passed: false,
      error: String(error),
    })
    failed++
  }

  return { passed, failed, results }
}

/**
 * Run tests and log results
 */
export async function testCreatorCodexGovernance(): Promise<void> {
  console.log("═══════════════════════════════════════════════════════════")
  console.log("CREATOR CODEX — GOVERNANCE INTEGRATION TEST")
  console.log("═══════════════════════════════════════════════════════════\n")

  const { passed, failed, results } = await runIntegrationTests()

  for (const result of results) {
    const status = result.passed ? "✅ PASS" : "❌ FAIL"
    console.log(`${status} - ${result.test}`)
    if (result.error) {
      console.log(`   Error: ${result.error}`)
    }
  }

  console.log(`\n═══════════════════════════════════════════════════════════`)
  console.log(`RESULTS: ${passed} passed, ${failed} failed`)
  console.log(`STATUS: ${failed === 0 ? "✅ ALL TESTS PASSED" : "❌ SOME TESTS FAILED"}`)
  console.log(`═══════════════════════════════════════════════════════════\n`)
}
