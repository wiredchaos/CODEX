// ═══════════════════════════════════════════════════════════════════════════════
// CREATOR CODEX — GENERATION PIPELINE
// Master Story Engine with Age-Gated Content Firewalls
// ═══════════════════════════════════════════════════════════════════════════════

import { generateText } from "ai"
import {
  type StorySeed,
  type Chapter,
  type MiniNovella,
  type BookMetadata,
  type AgeTier,
  type ContentGate,
  type StoryGenre,
  type StoryTone,
  GATE_CONFIGS,
  ageTierToGate,
  gateToRating,
  generateId,
} from "./creator-codex-models"

import { consumeLoreFromAkira, type LoreObject } from "./akira-bridge"

// ─────────────────────────────────────────────────────────────────────────────
// MASTER STORY ENGINE PROMPT TEMPLATES
// ─────────────────────────────────────────────────────────────────────────────

const MASTER_SEED_PROMPT = `You are a master story architect. Generate a structured story seed from the following concept.

CONCEPT: {concept}
REQUESTED AGE TIER: {ageTier}
CONTENT GATE: {gate}

GATE RULES:
{gateRules}

Generate a JSON response with:
{
  "title": "compelling title",
  "premise": "2-3 sentence hook",
  "genres": ["primary", "secondary"],
  "tone": "story tone",
  "protagonistArchetype": "character archetype",
  "antagonistArchetype": "opposing force archetype",
  "settingDescription": "vivid setting in 2-3 sentences",
  "thematicElements": ["theme1", "theme2", "theme3"],
  "plotHooks": ["hook1", "hook2", "hook3"],
  "targetWordCount": number,
  "chapterCount": number
}

Ensure all content respects the gate rules. Be creative within boundaries.`

const MASTER_CHAPTER_PROMPT = `You are a master storyteller writing Chapter {chapterNum} of {totalChapters}.

STORY CONTEXT:
Title: {title}
Premise: {premise}
Setting: {setting}
Protagonist: {protagonist}
Antagonist: {antagonist}
Themes: {themes}
Tone: {tone}

PREVIOUS SUMMARY: {previousSummary}

CONTENT GATE: {gate}
GATE RULES:
{gateRules}

Write this chapter with:
- Approximately {targetWords} words
- Vivid sensory details
- Character-driven conflict
- Emotional resonance
- A compelling hook for the next chapter

For {gate}:
{gateSpecificInstructions}

Write the chapter now. Begin with a chapter title.`

const GATE_INSTRUCTIONS: Record<ContentGate, string> = {
  LIGHT_GATE: `Focus on wonder, adventure, and growth. Keep all content appropriate for younger readers.
No violence beyond mild cartoon-level conflict. Emphasize friendship, courage, and discovery.`,

  SHADOW_GATE: `You may explore mature themes with sophistication. Violence can be intense but purposeful.
For any romantic/intimate moments: use fade-to-black technique. Cut away at the moment of intimacy.
Example: "Their lips met, and the world fell away... [scene break] Morning light filtered through the curtains."`,

  RED_VEIL: `You may write sensual content using ONLY symbolic and metaphorical language.
Use shadow-veil poetics: metaphors of fire, water, darkness, light, breath, pulse.
NEVER use explicit anatomical terms. Think literary erotica, not explicit content.
Example: "They became a single flame, shadows dancing on the wall, breath like ocean waves..."
The veil must remain—suggest, don't show. Poetry, not pornography.`,
}

// ─────────────────────────────────────────────────────────────────────────────
// STORY SEED GENERATION
// ─────────────────────────────────────────────────────────────────────────────

export interface GenerateSeedOptions {
  concept: string
  ageTier: AgeTier
  preferredGenres?: StoryGenre[]
  preferredTone?: StoryTone
  integrateLore?: boolean
  loreCategories?: Array<"MEROVINGIAN" | "NETERU" | "589_THEORY" | "AKASHIC" | "CHAOS_ORIGIN" | "VEIL">
}

export async function generateStorySeed(options: GenerateSeedOptions): Promise<StorySeed> {
  const { concept, ageTier, preferredGenres, preferredTone, integrateLore, loreCategories } = options
  const gate = ageTierToGate(ageTier)
  const gateConfig = GATE_CONFIGS[gate]

  let loreContext = ""
  if (integrateLore) {
    try {
      const loreObjects: LoreObject[] = []
      if (loreCategories && loreCategories.length > 0) {
        for (const category of loreCategories) {
          const categoryLore = await consumeLoreFromAkira(category)
          loreObjects.push(...categoryLore)
        }
      } else {
        // Get random lore if no specific category requested
        const allLore = await consumeLoreFromAkira()
        loreObjects.push(...allLore.slice(0, 2))
      }

      loreContext =
        "\n\nLORE INTEGRATION (from Akira Codex, READ-ONLY):\n" +
        loreObjects.map((l) => `- ${l.title}: ${l.content.substring(0, 200)}...`).join("\n")
    } catch (error) {
      console.warn("[Creator Codex] Failed to integrate lore:", error)
      // Continue without lore if unavailable
    }
  }

  const prompt =
    MASTER_SEED_PROMPT.replace("{concept}", concept)
      .replace("{ageTier}", ageTier)
      .replace("{gate}", gate)
      .replace("{gateRules}", gateConfig.contentRules.join("\n- ")) + loreContext

  const { text } = await generateText({
    model: "anthropic/claude-sonnet-4-20250514",
    prompt,
    temperature: 0.8,
  })

  // Parse the JSON response
  const jsonMatch = text.match(/\{[\s\S]*\}/)
  if (!jsonMatch) {
    throw new Error("Failed to parse story seed response")
  }

  const parsed = JSON.parse(jsonMatch[0])

  const seed: StorySeed = {
    id: generateId("seed"),
    concept,
    title: parsed.title,
    premise: parsed.premise,
    ageTier,
    contentGate: gate,
    genres: preferredGenres || parsed.genres,
    tone: preferredTone || parsed.tone,
    targetWordCount: parsed.targetWordCount || 15000,
    chapterCount: parsed.chapterCount || 5,
    protagonistArchetype: parsed.protagonistArchetype,
    antagonistArchetype: parsed.antagonistArchetype,
    settingDescription: parsed.settingDescription,
    thematicElements: parsed.thematicElements,
    plotHooks: parsed.plotHooks,
    createdAt: new Date(),
  }

  return seed
}

// ─────────────────────────────────────────────────────────────────────────────
// CHAPTER GENERATION
// ─────────────────────────────────────────────────────────────────────────────

async function generateChapter(seed: StorySeed, chapterNum: number, previousSummary: string): Promise<Chapter> {
  const gateConfig = GATE_CONFIGS[seed.contentGate]
  const targetWords = Math.floor(seed.targetWordCount / seed.chapterCount)

  const prompt = MASTER_CHAPTER_PROMPT.replace("{chapterNum}", String(chapterNum))
    .replace("{totalChapters}", String(seed.chapterCount))
    .replace("{title}", seed.title)
    .replace("{premise}", seed.premise)
    .replace("{setting}", seed.settingDescription)
    .replace("{protagonist}", seed.protagonistArchetype)
    .replace("{antagonist}", seed.antagonistArchetype)
    .replace("{themes}", seed.thematicElements.join(", "))
    .replace("{tone}", seed.tone)
    .replace("{previousSummary}", previousSummary || "This is the opening chapter.")
    .replace("{gate}", seed.contentGate)
    .replace("{gateRules}", gateConfig.contentRules.join("\n- "))
    .replace("{targetWords}", String(targetWords))
    .replace("{gateSpecificInstructions}", GATE_INSTRUCTIONS[seed.contentGate])

  const { text } = await generateText({
    model: "anthropic/claude-sonnet-4-20250514",
    prompt,
    temperature: 0.85,
    maxTokens: 4000,
  })

  // Extract chapter title (first line usually)
  const lines = text.split("\n")
  const titleLine = lines[0].replace(/^#+\s*/, "").replace(/^Chapter\s*\d+[:\s]*/i, "")

  const content = text
  const wordCount = content.split(/\s+/).length

  // Generate summary for next chapter context
  const { text: summaryText } = await generateText({
    model: "anthropic/claude-sonnet-4-20250514",
    prompt: `Summarize this chapter in 2-3 sentences for story continuity:\n\n${content}`,
    temperature: 0.3,
    maxTokens: 200,
  })

  return {
    id: generateId("chapter"),
    novellaId: "", // Will be set by parent
    number: chapterNum,
    title: titleLine || `Chapter ${chapterNum}`,
    content,
    wordCount,
    summary: summaryText,
    keyEvents: [], // Could be extracted with another LLM call
    emotionalArc: seed.tone,
    generatedAt: new Date(),
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// FULL NOVELLA EXPANSION
// ─────────────────────────────────────────────────────────────────────────────

export interface ExpandOptions {
  seed: StorySeed
  authorName: string
  penName?: string
  onChapterComplete?: (chapter: Chapter, progress: number) => void
}

export async function expandToMiniNovella(options: ExpandOptions): Promise<MiniNovella> {
  const { seed, authorName, penName, onChapterComplete } = options

  const novellaId = generateId("novella")
  const chapters: Chapter[] = []
  let previousSummary = ""
  let totalWordCount = 0

  // Generate chapters sequentially for narrative continuity
  for (let i = 1; i <= seed.chapterCount; i++) {
    const chapter = await generateChapter(seed, i, previousSummary)
    chapter.novellaId = novellaId
    chapters.push(chapter)

    previousSummary = chapter.summary
    totalWordCount += chapter.wordCount

    if (onChapterComplete) {
      onChapterComplete(chapter, i / seed.chapterCount)
    }
  }

  // Generate blurb
  const { text: blurb } = await generateText({
    model: "anthropic/claude-sonnet-4-20250514",
    prompt: `Write a compelling 150-word book blurb for:
Title: ${seed.title}
Premise: ${seed.premise}
Genres: ${seed.genres.join(", ")}
Tone: ${seed.tone}

Make it hook readers immediately. End with intrigue.`,
    temperature: 0.7,
  })

  const metadata: BookMetadata = {
    title: seed.title,
    author: authorName,
    penName,
    blurb,
    longDescription: seed.premise + "\n\n" + blurb,
    genres: seed.genres,
    keywords: [...seed.thematicElements, ...seed.genres.map((g) => g.toLowerCase())],
    ageTier: seed.ageTier,
    contentRating: gateToRating(seed.contentGate),
    language: "en",
    copyrightYear: new Date().getFullYear(),
    publisher: "Creator Codex Publishing",
  }

  return {
    id: novellaId,
    seed,
    metadata,
    chapters,
    totalWordCount,
    status: "COMPLETE",
    createdAt: new Date(),
    updatedAt: new Date(),
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// CONTENT VALIDATION
// ─────────────────────────────────────────────────────────────────────────────

export async function validateContentGate(
  content: string,
  gate: ContentGate,
): Promise<{ valid: boolean; violations: string[] }> {
  const gateConfig = GATE_CONFIGS[gate]

  const { text } = await generateText({
    model: "anthropic/claude-sonnet-4-20250514",
    prompt: `Analyze this content for compliance with these rules:
${gateConfig.contentRules.join("\n")}

RESTRICTED THEMES: ${gateConfig.restrictedThemes.join(", ")}

CONTENT TO CHECK:
${content.substring(0, 3000)}

Respond with JSON:
{
  "compliant": true/false,
  "violations": ["list of specific violations if any"]
}`,
    temperature: 0.1,
  })

  const jsonMatch = text.match(/\{[\s\S]*\}/)
  if (!jsonMatch) {
    return { valid: true, violations: [] }
  }

  const result = JSON.parse(jsonMatch[0])
  return {
    valid: result.compliant,
    violations: result.violations || [],
  }
}
