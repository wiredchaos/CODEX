/**
 * WIRED CHAOS UNIVERSITY ARCADE - Noobie/Boomer Onboarding Flow
 * Safe, friendly, achievable onboarding for all player types
 */

import type { OnboardingStep, PlayerMode } from "../aae/aae-types"

export const ONBOARDING_STEPS: OnboardingStep[] = [
  {
    step: 1,
    title: "Warm Welcome",
    description: "Introduction to WIRED CHAOS UNIVERSITY",
    npcMessage:
      "Welcome to WIRED CHAOS UNIVERSITY. Here, we play simple interactive activities that teach skills one step at a time. You choose the speed. We go together.",
    action: "TAP",
    isOptional: false,
  },
  {
    step: 2,
    title: "Choose Your Pace",
    description: "Select your preferred difficulty",
    npcMessage: "If you're new, choose the first option. You can change anytime.",
    action: "SELECT",
    isOptional: false,
  },
  {
    step: 3,
    title: "Your First Tap",
    description: "Practice with a simple tap interaction",
    npcMessage: "Tap here.",
    action: "TUTORIAL",
    isOptional: false,
  },
  {
    step: 4,
    title: "Great Job!",
    description: "Positive reinforcement",
    npcMessage: "Good! Try this next.",
    action: "TUTORIAL",
    isOptional: false,
  },
  {
    step: 5,
    title: "Ready to Play",
    description: "Enter the Arcade",
    npcMessage: "You're doing great! Every tap earns progress. Ready to explore the Arcade?",
    action: "TAP",
    isOptional: false,
  },
]

export const DIFFICULTY_OPTIONS = [
  {
    mode: "NOOBIE" as PlayerMode,
    label: "I'm New to Games",
    description: "Slow pace, big buttons, step-by-step guidance",
    icon: "🌱",
  },
  {
    mode: "CASUAL" as PlayerMode,
    label: "I Play Sometimes",
    description: "Standard pace, balanced challenge",
    icon: "🎮",
  },
  {
    mode: "GAMER" as PlayerMode,
    label: "I Like a Challenge",
    description: "Fast pace, competitive, boss battles",
    icon: "⚡",
  },
]

export interface OnboardingState {
  currentStep: number
  selectedMode: PlayerMode | null
  completedSteps: number[]
  tutorialTaps: number
  isComplete: boolean
}

export function createOnboardingState(): OnboardingState {
  return {
    currentStep: 1,
    selectedMode: null,
    completedSteps: [],
    tutorialTaps: 0,
    isComplete: false,
  }
}

export function advanceOnboarding(state: OnboardingState): OnboardingState {
  const nextStep = state.currentStep + 1
  const isComplete = nextStep > ONBOARDING_STEPS.length

  return {
    ...state,
    currentStep: isComplete ? state.currentStep : nextStep,
    completedSteps: [...state.completedSteps, state.currentStep],
    isComplete,
  }
}

export function selectDifficulty(state: OnboardingState, mode: PlayerMode): OnboardingState {
  return {
    ...state,
    selectedMode: mode,
  }
}

export function recordTutorialTap(state: OnboardingState): OnboardingState {
  return {
    ...state,
    tutorialTaps: state.tutorialTaps + 1,
  }
}

export function canSkipOnboarding(): boolean {
  // Boomers must feel SAFE - always allow skip
  return true
}

export function getSkipMessage(): string {
  return "Skip this game — earn XP anyway"
}
