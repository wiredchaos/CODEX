/**
 * WIRED CHAOS UNIVERSITY ARCADE - Game Configurations
 * All 5 core arcade games with 3-mode difficulty presets
 */

import type { ArcadeGame, GameDifficultyConfig } from "../aae/aae-types"

const NOOBIE_BASE: GameDifficultyConfig = {
  timing: "SLOW",
  iconSize: "LARGE",
  timeMultiplier: 2.0,
  hintAvailability: "ALWAYS",
  penaltyMultiplier: 0,
  xpMultiplier: 1.0,
  autoAssist: true,
  forgivenessMode: true,
  bossStagesEnabled: false,
  comboStreaksEnabled: false,
}

const CASUAL_BASE: GameDifficultyConfig = {
  timing: "NORMAL",
  iconSize: "MEDIUM",
  timeMultiplier: 1.0,
  hintAvailability: "LIMITED",
  penaltyMultiplier: 0.5,
  xpMultiplier: 1.25,
  autoAssist: false,
  forgivenessMode: false,
  bossStagesEnabled: false,
  comboStreaksEnabled: true,
}

const GAMER_BASE: GameDifficultyConfig = {
  timing: "FAST",
  iconSize: "SMALL",
  timeMultiplier: 0.5,
  hintAvailability: "NONE",
  penaltyMultiplier: 1.5,
  xpMultiplier: 2.0,
  autoAssist: false,
  forgivenessMode: false,
  bossStagesEnabled: true,
  comboStreaksEnabled: true,
}

export const ARCADE_GAMES: ArcadeGame[] = [
  {
    id: "red-fang-signal-tuner",
    slug: "signal-tuner",
    name: "Red Fang Signal Tuner",
    description:
      "Type incoming signals to tune into the chaos frequency. Speed and accuracy determine your signal strength.",
    category: "SIGNAL",
    thumbnailUrl: "/cyberpunk-typing-game-neon-red-signal-waves.jpg",
    xpRewardMin: 50,
    xpRewardMax: 200,
    supportsNoobie: true,
    supportsCasual: true,
    supportsGamer: true,
    noobieDifficultyConfig: {
      ...NOOBIE_BASE,
      // Slow scrolling, predictive text, NPC says next key
    },
    casualDifficultyConfig: {
      ...CASUAL_BASE,
      // Normal speed, combo streaks
    },
    gamerDifficultyConfig: {
      ...GAMER_BASE,
      timing: "RAPID",
      // Rapid-fire, perfect streak bonuses, Red Fang Overdrive
    },
  },
  {
    id: "589-akashic-merge-grid",
    slug: "merge-grid",
    name: "589 Akashic Merge Grid",
    description: "Slide and merge tiles to unlock Akashic records. Reach 2048 to access forbidden knowledge.",
    category: "AKASHIC",
    thumbnailUrl: "/cyberpunk-2048-puzzle-game-neon-purple-grid-sacred.jpg",
    xpRewardMin: 75,
    xpRewardMax: 300,
    supportsNoobie: true,
    supportsCasual: true,
    supportsGamer: true,
    noobieDifficultyConfig: {
      ...NOOBIE_BASE,
      autoAssist: true, // Grid highlights best move, undo button
    },
    casualDifficultyConfig: {
      ...CASUAL_BASE,
      hintAvailability: "LIMITED", // Optional hints
    },
    gamerDifficultyConfig: {
      ...GAMER_BASE,
      bossStagesEnabled: true, // 4096 goal, no undo, Wraith disruptions
    },
  },
  {
    id: "echo-detection-protocol",
    slug: "echo-detection",
    name: "Echo Detection Protocol",
    description: "Listen to the patterns. Repeat the sequence. The deeper you go, the more echoes reveal.",
    category: "ECHO",
    thumbnailUrl: "/cyberpunk-simon-says-memory-game-neon-blue-sound-w.jpg",
    xpRewardMin: 40,
    xpRewardMax: 180,
    supportsNoobie: true,
    supportsCasual: true,
    supportsGamer: true,
    noobieDifficultyConfig: {
      ...NOOBIE_BASE,
      // 2-3 tones, slow replay, visual sparkle highlight
    },
    casualDifficultyConfig: {
      ...CASUAL_BASE,
      // 4-5 tones
    },
    gamerDifficultyConfig: {
      ...GAMER_BASE,
      // 8-12 tones, rhythm chaining, boss pattern finale
    },
  },
  {
    id: "moloch-neutralization-ops",
    slug: "moloch-ops",
    name: "Moloch Neutralization Ops",
    description: "Strike the Moloch agents before they infiltrate. Quick reflexes neutralize the threat.",
    category: "MOLOCH",
    thumbnailUrl: "/cyberpunk-whack-a-mole-game-neon-orange-targets-da.jpg",
    xpRewardMin: 60,
    xpRewardMax: 220,
    supportsNoobie: true,
    supportsCasual: true,
    supportsGamer: true,
    noobieDifficultyConfig: {
      ...NOOBIE_BASE,
      iconSize: "LARGE", // Large hit zones, slow pop-ups
    },
    casualDifficultyConfig: {
      ...CASUAL_BASE,
      // Standard difficulty
    },
    gamerDifficultyConfig: {
      ...GAMER_BASE,
      timing: "RAPID", // Multi-target chaos mode, timed combos
    },
  },
  {
    id: "wraith-lords-descent",
    slug: "wraith-descent",
    name: "Wraith Lords Descent",
    description: "The Wraith Lords descend from the void. Blast them before they consume reality.",
    category: "WRAITH",
    thumbnailUrl: "/cyberpunk-space-invaders-game-neon-green-aliens-da.jpg",
    xpRewardMin: 80,
    xpRewardMax: 350,
    supportsNoobie: true,
    supportsCasual: true,
    supportsGamer: true,
    noobieDifficultyConfig: {
      ...NOOBIE_BASE,
      autoAssist: true, // Auto-aim assist, slower enemy movement
    },
    casualDifficultyConfig: {
      ...CASUAL_BASE,
      // Balanced arcade feel
    },
    gamerDifficultyConfig: {
      ...GAMER_BASE,
      bossStagesEnabled: true, // Bullet hell mode, hidden boss
    },
  },
]

export function getGameBySlug(slug: string): ArcadeGame | undefined {
  return ARCADE_GAMES.find((g) => g.slug === slug)
}

export function getGameById(id: string): ArcadeGame | undefined {
  return ARCADE_GAMES.find((g) => g.id === id)
}

export function getGamesByCategory(category: ArcadeGame["category"]): ArcadeGame[] {
  return ARCADE_GAMES.filter((g) => g.category === category)
}
