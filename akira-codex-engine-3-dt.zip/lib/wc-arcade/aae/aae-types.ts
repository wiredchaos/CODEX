/**
 * WIRED CHAOS META LAB - Agentic Adaptation Engine (AAE)
 * Type definitions for the adaptive difficulty system
 * ISOLATED FROM: AKIRA CODEX, CREATOR CODEX, 789 STUDIOS
 */

export type PlayerMode = "NOOBIE" | "CASUAL" | "GAMER"

export type DifficultyTier = "EASY" | "NORMAL" | "HARD" | "CHAOS"

export interface AAEInputMetrics {
  responseTimeMs: number
  mistakeCount: number
  hintUsageCount: number
  rageClickCount: number
  timeoutEvents: number
  tutorialRepeats: number
  earlyQuits: number
  hesitationEvents: number
}

export interface AAEClassification {
  mode: PlayerMode
  confidence: number
  timestamp: Date
  metrics: AAEInputMetrics
  recommendation: string
}

export interface PlayerProfile {
  userId: string
  currentMode: PlayerMode
  preferredMode: PlayerMode | null
  totalGamesPlayed: number
  totalXpEarned: number
  avgResponseTimeMs: number
  avgMistakeRate: number
  lastClassification: AAEClassification | null
  onboardingComplete: boolean
  createdAt: Date
  updatedAt: Date
}

export interface GameDifficultyConfig {
  timing: "SLOW" | "NORMAL" | "FAST" | "RAPID"
  iconSize: "LARGE" | "MEDIUM" | "SMALL"
  timeMultiplier: number
  hintAvailability: "ALWAYS" | "LIMITED" | "NONE"
  penaltyMultiplier: number
  xpMultiplier: number
  autoAssist: boolean
  forgivenessMode: boolean
  bossStagesEnabled: boolean
  comboStreaksEnabled: boolean
}

export interface GameSession {
  sessionId: string
  userId: string
  gameId: string
  mode: PlayerMode
  difficultyConfig: GameDifficultyConfig
  startedAt: Date
  endedAt: Date | null
  score: number
  xpAwarded: number
  metrics: AAEInputMetrics
  adaptationsApplied: string[]
  completed: boolean
}

export interface NPCDialogue {
  id: string
  mode: PlayerMode
  context: "WELCOME" | "HINT" | "ENCOURAGEMENT" | "SUCCESS" | "RETRY" | "COMPETITIVE"
  message: string
  voiceLineUrl?: string
  animationCode?: string
}

export interface OnboardingStep {
  step: number
  title: string
  description: string
  npcMessage: string
  action: "TAP" | "SELECT" | "TUTORIAL" | "SKIP"
  isOptional: boolean
}

export interface ArcadeGame {
  id: string
  slug: string
  name: string
  description: string
  category: "SIGNAL" | "AKASHIC" | "ECHO" | "MOLOCH" | "WRAITH"
  thumbnailUrl: string
  xpRewardMin: number
  xpRewardMax: number
  supportsNoobie: boolean
  supportsCasual: boolean
  supportsGamer: boolean
  noobieDifficultyConfig: GameDifficultyConfig
  casualDifficultyConfig: GameDifficultyConfig
  gamerDifficultyConfig: GameDifficultyConfig
}

export interface WLProgressionReward {
  type: "XP" | "BADGE" | "TRAIT" | "TOKEN_KEY" | "ARTIFACT"
  code: string
  amount: number
  description: string
}
