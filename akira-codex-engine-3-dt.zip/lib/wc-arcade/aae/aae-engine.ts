/**
 * WIRED CHAOS META LAB - Agentic Adaptation Engine (AAE)
 * Core classification and adaptation logic
 */

import type { AAEInputMetrics, AAEClassification, PlayerMode, GameDifficultyConfig, PlayerProfile } from "./aae-types"

// Classification thresholds
const THRESHOLDS = {
  NOOBIE: {
    mistakesMin: 7,
    hintUsageMin: 3,
    avgResponseTimeMin: 5000, // 5 seconds
  },
  CASUAL: {
    mistakesMin: 3,
    mistakesMax: 6,
    avgResponseTimeMin: 2000, // 2 seconds
    avgResponseTimeMax: 5000, // 5 seconds
  },
  GAMER: {
    mistakesMax: 3,
    avgResponseTimeMax: 2000, // 2 seconds
  },
}

/**
 * Classify player mode based on input metrics
 */
export function classifyPlayerMode(metrics: AAEInputMetrics): AAEClassification {
  const {
    responseTimeMs,
    mistakeCount,
    hintUsageCount,
    rageClickCount,
    timeoutEvents,
    tutorialRepeats,
    earlyQuits,
    hesitationEvents,
  } = metrics

  // Calculate weighted stress indicators
  const stressScore = rageClickCount * 2 + timeoutEvents * 3 + hesitationEvents + earlyQuits * 5

  let mode: PlayerMode
  let confidence: number
  let recommendation: string

  // NOOBIE classification
  if (
    mistakeCount >= THRESHOLDS.NOOBIE.mistakesMin ||
    hintUsageCount >= THRESHOLDS.NOOBIE.hintUsageMin ||
    responseTimeMs >= THRESHOLDS.NOOBIE.avgResponseTimeMin ||
    tutorialRepeats > 1 ||
    stressScore > 10
  ) {
    mode = "NOOBIE"
    confidence = calculateConfidence(metrics, "NOOBIE")
    recommendation = "Slow timing, large icons, step-by-step NPC guidance, no penalties"
  }
  // GAMER classification
  else if (
    mistakeCount < THRESHOLDS.GAMER.mistakesMax &&
    responseTimeMs < THRESHOLDS.GAMER.avgResponseTimeMax &&
    hintUsageCount === 0 &&
    stressScore < 3
  ) {
    mode = "GAMER"
    confidence = calculateConfidence(metrics, "GAMER")
    recommendation = "Fast timing, no hints, boss stages enabled, high XP multiplier"
  }
  // CASUAL classification (default)
  else {
    mode = "CASUAL"
    confidence = calculateConfidence(metrics, "CASUAL")
    recommendation = "Standard timing, occasional hints, balanced XP"
  }

  return {
    mode,
    confidence,
    timestamp: new Date(),
    metrics,
    recommendation,
  }
}

/**
 * Calculate confidence score for classification
 */
function calculateConfidence(metrics: AAEInputMetrics, targetMode: PlayerMode): number {
  let score = 0.5 // Base confidence

  if (targetMode === "NOOBIE") {
    if (metrics.mistakeCount >= 10) score += 0.2
    if (metrics.hintUsageCount >= 5) score += 0.15
    if (metrics.responseTimeMs >= 7000) score += 0.15
  } else if (targetMode === "GAMER") {
    if (metrics.mistakeCount === 0) score += 0.2
    if (metrics.responseTimeMs < 1000) score += 0.2
    if (metrics.hintUsageCount === 0) score += 0.1
  } else {
    // CASUAL - moderate indicators
    score += 0.2
  }

  return Math.min(score, 1.0)
}

/**
 * Generate difficulty configuration for a player mode
 */
export function generateDifficultyConfig(mode: PlayerMode): GameDifficultyConfig {
  switch (mode) {
    case "NOOBIE":
      return {
        timing: "SLOW",
        iconSize: "LARGE",
        timeMultiplier: 2.0,
        hintAvailability: "ALWAYS",
        penaltyMultiplier: 0,
        xpMultiplier: 1.0,
        autoAssist: true,
        forgivenessMode: true,
        bossStagesEnabled: false,
        comboStreaksEnabled: false,
      }

    case "CASUAL":
      return {
        timing: "NORMAL",
        iconSize: "MEDIUM",
        timeMultiplier: 1.0,
        hintAvailability: "LIMITED",
        penaltyMultiplier: 0.5,
        xpMultiplier: 1.25,
        autoAssist: false,
        forgivenessMode: false,
        bossStagesEnabled: false,
        comboStreaksEnabled: true,
      }

    case "GAMER":
      return {
        timing: "FAST",
        iconSize: "SMALL",
        timeMultiplier: 0.5,
        hintAvailability: "NONE",
        penaltyMultiplier: 1.5,
        xpMultiplier: 2.0,
        autoAssist: false,
        forgivenessMode: false,
        bossStagesEnabled: true,
        comboStreaksEnabled: true,
      }
  }
}

/**
 * Apply dynamic mid-game adaptation based on real-time metrics
 */
export function applyDynamicAdaptation(
  currentConfig: GameDifficultyConfig,
  realtimeMetrics: Partial<AAEInputMetrics>,
): { config: GameDifficultyConfig; adaptations: string[] } {
  const adaptations: string[] = []
  const config = { ...currentConfig }

  // Detect struggle and ease difficulty
  if (realtimeMetrics.mistakeCount && realtimeMetrics.mistakeCount > 5) {
    if (config.timing !== "SLOW") {
      config.timing = config.timing === "FAST" ? "NORMAL" : "SLOW"
      adaptations.push("TIMING_REDUCED")
    }
    if (!config.forgivenessMode) {
      config.forgivenessMode = true
      adaptations.push("FORGIVENESS_ENABLED")
    }
  }

  // Detect frustration (rage clicks)
  if (realtimeMetrics.rageClickCount && realtimeMetrics.rageClickCount > 3) {
    config.hintAvailability = "ALWAYS"
    config.penaltyMultiplier = 0
    adaptations.push("HINTS_UNLOCKED")
    adaptations.push("PENALTIES_REMOVED")
  }

  // Detect mastery and increase challenge
  if (realtimeMetrics.mistakeCount === 0 && realtimeMetrics.responseTimeMs && realtimeMetrics.responseTimeMs < 1500) {
    if (config.timing !== "RAPID") {
      config.timing = config.timing === "SLOW" ? "NORMAL" : "FAST"
      adaptations.push("TIMING_INCREASED")
    }
    config.xpMultiplier = Math.min(config.xpMultiplier * 1.25, 3.0)
    adaptations.push("XP_BONUS_APPLIED")
  }

  return { config, adaptations }
}

/**
 * Calculate XP reward based on session performance
 */
export function calculateSessionXP(
  baseXP: number,
  mode: PlayerMode,
  config: GameDifficultyConfig,
  metrics: AAEInputMetrics,
  completed: boolean,
): number {
  if (!completed) {
    // Partial XP for incomplete sessions (Noobie-friendly)
    return Math.floor(baseXP * 0.25)
  }

  let xp = baseXP * config.xpMultiplier

  // Bonus for low mistakes
  if (metrics.mistakeCount === 0) {
    xp *= 1.5
  } else if (metrics.mistakeCount < 3) {
    xp *= 1.25
  }

  // Bonus for speed (GAMER mode)
  if (mode === "GAMER" && metrics.responseTimeMs < 1000) {
    xp *= 1.5
  }

  // No hint bonus
  if (metrics.hintUsageCount === 0 && mode !== "NOOBIE") {
    xp *= 1.2
  }

  return Math.floor(xp)
}

/**
 * Initialize empty metrics object
 */
export function createEmptyMetrics(): AAEInputMetrics {
  return {
    responseTimeMs: 0,
    mistakeCount: 0,
    hintUsageCount: 0,
    rageClickCount: 0,
    timeoutEvents: 0,
    tutorialRepeats: 0,
    earlyQuits: 0,
    hesitationEvents: 0,
  }
}

/**
 * Create default player profile
 */
export function createDefaultProfile(userId: string): PlayerProfile {
  return {
    userId,
    currentMode: "CASUAL",
    preferredMode: null,
    totalGamesPlayed: 0,
    totalXpEarned: 0,
    avgResponseTimeMs: 0,
    avgMistakeRate: 0,
    lastClassification: null,
    onboardingComplete: false,
    createdAt: new Date(),
    updatedAt: new Date(),
  }
}
