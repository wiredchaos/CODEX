/**
 * WIRED CHAOS UNIVERSITY ARCADE - NPC Dialogue Engine
 * Adaptive dialogue sets for all player modes
 */

import type { NPCDialogue, PlayerMode } from "../aae/aae-types"

export const NPC_DIALOGUES: NPCDialogue[] = [
  // NOOBIE MODE - Gentle, supportive
  {
    id: "noobie-welcome",
    mode: "NOOBIE",
    context: "WELCOME",
    message:
      "Welcome to WIRED CHAOS UNIVERSITY. Here, we play simple interactive activities that teach skills one step at a time. You choose the speed. We go together.",
  },
  {
    id: "noobie-hint-1",
    mode: "NOOBIE",
    context: "HINT",
    message: "You're doing great. Let's take it step by step.",
  },
  {
    id: "noobie-hint-2",
    mode: "NOOBIE",
    context: "HINT",
    message: "Would you like me to show you?",
  },
  {
    id: "noobie-hint-3",
    mode: "NOOBIE",
    context: "HINT",
    message: "We can try again together.",
  },
  {
    id: "noobie-encourage-1",
    mode: "NOOBIE",
    context: "ENCOURAGEMENT",
    message: "Nice progress! You earned XP.",
  },
  {
    id: "noobie-encourage-2",
    mode: "NOOBIE",
    context: "ENCOURAGEMENT",
    message: "Great work! Every tap earns progress.",
  },
  {
    id: "noobie-success",
    mode: "NOOBIE",
    context: "SUCCESS",
    message: "You did it! That was excellent. Ready for another?",
  },
  {
    id: "noobie-retry",
    mode: "NOOBIE",
    context: "RETRY",
    message: "Let's try again, but slower this time.",
  },

  // CASUAL MODE - Neutral, helpful
  {
    id: "casual-welcome",
    mode: "CASUAL",
    context: "WELCOME",
    message: "Welcome to the Arcade. Pick a game and let's see what you've got.",
  },
  {
    id: "casual-hint-1",
    mode: "CASUAL",
    context: "HINT",
    message: "Good move. Want a hint?",
  },
  {
    id: "casual-hint-2",
    mode: "CASUAL",
    context: "HINT",
    message: "Try this pattern next.",
  },
  {
    id: "casual-encourage",
    mode: "CASUAL",
    context: "ENCOURAGEMENT",
    message: "You're improving quickly.",
  },
  {
    id: "casual-success",
    mode: "CASUAL",
    context: "SUCCESS",
    message: "Well played! XP banked.",
  },
  {
    id: "casual-retry",
    mode: "CASUAL",
    context: "RETRY",
    message: "Close one. Try again?",
  },

  // GAMER MODE - Competitive, lore-powered
  {
    id: "gamer-welcome",
    mode: "GAMER",
    context: "WELCOME",
    message: "The Wraith Lords are watching. Prove your worth in the Arcade.",
  },
  {
    id: "gamer-competitive-1",
    mode: "GAMER",
    context: "COMPETITIVE",
    message: "Combo streak unlocked—push harder.",
  },
  {
    id: "gamer-competitive-2",
    mode: "GAMER",
    context: "COMPETITIVE",
    message: "Chaos Mode activated. Survive if you can.",
  },
  {
    id: "gamer-encourage",
    mode: "GAMER",
    context: "ENCOURAGEMENT",
    message: "The Wraith Lords are watching. Show them your skill.",
  },
  {
    id: "gamer-success",
    mode: "GAMER",
    context: "SUCCESS",
    message: "Victory. The Akashic Records acknowledge your mastery.",
  },
  {
    id: "gamer-retry",
    mode: "GAMER",
    context: "RETRY",
    message: "The Wraith Lords claim another. Rise again, warrior.",
  },
]

export function getDialogue(mode: PlayerMode, context: NPCDialogue["context"]): NPCDialogue {
  const matches = NPC_DIALOGUES.filter((d) => d.mode === mode && d.context === context)
  if (matches.length === 0) {
    // Fallback to CASUAL
    const fallback = NPC_DIALOGUES.find((d) => d.mode === "CASUAL" && d.context === context)
    return fallback || NPC_DIALOGUES[0]
  }
  // Random selection for variety
  return matches[Math.floor(Math.random() * matches.length)]
}

export function getWelcomeDialogue(mode: PlayerMode): string {
  return getDialogue(mode, "WELCOME").message
}

export function getHintDialogue(mode: PlayerMode): string {
  return getDialogue(mode, "HINT").message
}

export function getEncouragementDialogue(mode: PlayerMode): string {
  return getDialogue(mode, "ENCOURAGEMENT").message
}

export function getSuccessDialogue(mode: PlayerMode): string {
  return getDialogue(mode, "SUCCESS").message
}

export function getRetryDialogue(mode: PlayerMode): string {
  return getDialogue(mode, "RETRY").message
}

export function getCompetitiveDialogue(): string {
  return getDialogue("GAMER", "COMPETITIVE").message
}
