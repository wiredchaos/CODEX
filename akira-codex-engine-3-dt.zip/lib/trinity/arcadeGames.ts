/**
 * TRINITY ARCADE PATCH — GAME REGISTRY
 * Static game configurations
 */

import type { GameConfig, DifficultyTier, RealmId } from "./types"

// ============================================
// GAME REGISTRY
// ============================================

export const GAME_REGISTRY: GameConfig[] = [
  {
    id: "signal_typing",
    label: "Signal Typing",
    description: "Decode intercepted transmissions by typing them before time runs out",
    supportedRealms: ["NEURALIS", "CHAOSPHERE", "ECHO"],
    difficultyVariants: ["NOOBIE", "CASUAL", "GAMER"],
    xpReward: { base: 50, multiplier: 1.5 },
    wlProgress: { steps: 1, context: "signal_decode" },
  },
  {
    id: "memory_grid",
    label: "Memory Grid",
    description: "Match pairs of symbols in the shortest time possible",
    supportedRealms: ["NEURALIS", "ECHO"],
    difficultyVariants: ["NOOBIE", "CASUAL", "GAMER"],
    xpReward: { base: 40, multiplier: 1.3 },
  },
  {
    id: "chaos_2048",
    label: "Chaos 2048",
    description: "Merge tiles to reach the highest number — chaos adds random obstacles",
    supportedRealms: ["CHAOSPHERE", "ECHO"],
    difficultyVariants: ["CASUAL", "GAMER"],
    xpReward: { base: 60, multiplier: 2.0 },
    wlProgress: { steps: 2, context: "chaos_mastery" },
  },
  {
    id: "rhythm_pulse",
    label: "Rhythm Pulse",
    description: "Hit the beats in sync with the pulse of the realm",
    supportedRealms: ["NEURALIS", "CHAOSPHERE", "ECHO"],
    difficultyVariants: ["NOOBIE", "CASUAL", "GAMER"],
    xpReward: { base: 45, multiplier: 1.4 },
  },
  {
    id: "trivia_nexus",
    label: "Trivia Nexus",
    description: "Answer questions from the lore of all realms",
    supportedRealms: ["NEURALIS", "ECHO"],
    difficultyVariants: ["NOOBIE", "CASUAL"],
    xpReward: { base: 30, multiplier: 1.2 },
    wlProgress: { steps: 1, context: "lore_knowledge" },
  },
]

// ============================================
// GAME RETRIEVAL
// ============================================

export function getGameById(gameId: string): GameConfig | null {
  return GAME_REGISTRY.find((g) => g.id === gameId) || null
}

export function getGamesByRealm(realmId: RealmId): GameConfig[] {
  return GAME_REGISTRY.filter((g) => g.supportedRealms.includes(realmId))
}

export function getGamesByDifficulty(tier: DifficultyTier): GameConfig[] {
  return GAME_REGISTRY.filter((g) => g.difficultyVariants.includes(tier))
}

export function getAllGames(): GameConfig[] {
  return [...GAME_REGISTRY]
}

// ============================================
// XP CALCULATION
// ============================================

export function calculateXpReward(gameId: string, tier: DifficultyTier, won: boolean, bonusMultiplier = 1): number {
  const game = getGameById(gameId)
  if (!game || !won) return 0

  const tierMultipliers: Record<DifficultyTier, number> = {
    NOOBIE: 0.8,
    CASUAL: 1.0,
    GAMER: 1.5,
  }

  return Math.floor(game.xpReward.base * game.xpReward.multiplier * tierMultipliers[tier] * bonusMultiplier)
}
