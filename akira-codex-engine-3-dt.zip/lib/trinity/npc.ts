/**
 * TRINITY ARCADE PATCH — NPC DIALOGUE SYSTEM
 * Tone-aware dialogue generation
 */

import type { NpcConfig, NpcDialogue, DifficultyTier, RealmId } from "./types"

// ============================================
// NPC REGISTRY
// ============================================

export const NPC_REGISTRY: NpcConfig[] = [
  {
    id: "guide_neuralis",
    name: "Axiom",
    role: "Guide",
    realm: "NEURALIS",
    dialogueTone: "NOOBIE",
    spriteKey: "npc_axiom",
    position: { x: 3, y: 3 },
  },
  {
    id: "guide_chaosphere",
    name: "Vex",
    role: "Challenger",
    realm: "CHAOSPHERE",
    dialogueTone: "GAMER",
    spriteKey: "npc_vex",
    position: { x: 8, y: 8 },
  },
  {
    id: "guide_echo",
    name: "Cipher",
    role: "Mediator",
    realm: "ECHO",
    dialogueTone: "CASUAL",
    spriteKey: "npc_cipher",
    position: { x: 5, y: 5 },
  },
]

// ============================================
// DIALOGUE DATABASE
// ============================================

const DIALOGUE_DB: NpcDialogue[] = [
  // AXIOM — NEURALIS GUIDE (NOOBIE TONE)
  {
    npcId: "guide_neuralis",
    tone: "NOOBIE",
    greeting: "Welcome, traveler. I am Axiom. Don't worry — I'll guide you through everything step by step.",
    hints: [
      "Take your time. There's no rush here.",
      "If you get stuck, just ask me for help.",
      "Every journey begins with a single step.",
    ],
    encouragement: ["You're doing wonderfully!", "See? You're getting the hang of it!", "Excellent progress!"],
    farewell: "Go forth with confidence. I believe in you.",
  },
  {
    npcId: "guide_neuralis",
    tone: "CASUAL",
    greeting: "Hey there. Axiom here. Ready to learn something new?",
    hints: ["Try combining those moves.", "The pattern repeats every third cycle.", "Watch the timing carefully."],
    encouragement: ["Nice one!", "You've got this!", "Solid work!"],
    farewell: "Good luck out there.",
  },
  {
    npcId: "guide_neuralis",
    tone: "GAMER",
    greeting: "Axiom. Let's skip the basics — you know the drill.",
    hints: ["Frame-perfect timing unlocks the bonus.", "Exploit the cooldown window."],
    encouragement: ["Clean execution.", "Optimal."],
    farewell: "Prove yourself.",
  },

  // VEX — CHAOSPHERE CHALLENGER (GAMER TONE)
  {
    npcId: "guide_chaosphere",
    tone: "NOOBIE",
    greeting: "Heh. Fresh meat. I'm Vex. Don't worry, I'll go easy... for now.",
    hints: ["Chaos rewards the bold. Try again.", "Failure is just practice.", "Even I started somewhere."],
    encouragement: ["Not bad for a beginner.", "There's potential in you.", "Keep pushing."],
    farewell: "Come back when you've toughened up.",
  },
  {
    npcId: "guide_chaosphere",
    tone: "CASUAL",
    greeting: "Vex here. Ready to dance with chaos?",
    hints: ["Adapt or perish.", "The pattern shifts. Stay alert.", "Trust your instincts."],
    encouragement: ["Now we're talking!", "That's the spirit!", "Chaos favors you today."],
    farewell: "Until next time, challenger.",
  },
  {
    npcId: "guide_chaosphere",
    tone: "GAMER",
    greeting: "Vex. No hand-holding. Show me what you've got.",
    hints: ["RNG manipulation is possible if you read the seed."],
    encouragement: ["Impressive.", "Worthy."],
    farewell: "The Chaosphere acknowledges you.",
  },

  // CIPHER — ECHO MEDIATOR (CASUAL TONE)
  {
    npcId: "guide_echo",
    tone: "NOOBIE",
    greeting: "Greetings. I am Cipher, keeper of balance. How may I assist you?",
    hints: ["Balance is key. Not too fast, not too slow.", "Listen to the rhythm of Echo.", "Patience brings clarity."],
    encouragement: ["You're finding your balance.", "The Echo responds to you.", "Harmony achieved."],
    farewell: "Walk the middle path.",
  },
  {
    npcId: "guide_echo",
    tone: "CASUAL",
    greeting: "Cipher here. The Echo realm awaits.",
    hints: ["Balance offense and defense.", "The neutral path has hidden advantages.", "Observe before you act."],
    encouragement: ["Well balanced!", "You understand Echo.", "Equilibrium maintained."],
    farewell: "May balance guide you.",
  },
  {
    npcId: "guide_echo",
    tone: "GAMER",
    greeting: "Cipher. The Echo tests all equally.",
    hints: ["True neutrality is the hardest path."],
    encouragement: ["Perfect equilibrium."],
    farewell: "You have mastered the balance.",
  },
]

// ============================================
// DIALOGUE RETRIEVAL
// ============================================

export function getNpcById(npcId: string): NpcConfig | null {
  return NPC_REGISTRY.find((npc) => npc.id === npcId) || null
}

export function getNpcsByRealm(realmId: RealmId): NpcConfig[] {
  return NPC_REGISTRY.filter((npc) => npc.realm === realmId)
}

export function getDialogue(npcId: string, tone: DifficultyTier): NpcDialogue | null {
  return DIALOGUE_DB.find((d) => d.npcId === npcId && d.tone === tone) || null
}

export function getGreeting(npcId: string, tone: DifficultyTier): string {
  const dialogue = getDialogue(npcId, tone)
  return dialogue?.greeting || "..."
}

export function getRandomHint(npcId: string, tone: DifficultyTier): string {
  const dialogue = getDialogue(npcId, tone)
  if (!dialogue || dialogue.hints.length === 0) return "..."
  return dialogue.hints[Math.floor(Math.random() * dialogue.hints.length)]
}

export function getRandomEncouragement(npcId: string, tone: DifficultyTier): string {
  const dialogue = getDialogue(npcId, tone)
  if (!dialogue || dialogue.encouragement.length === 0) return "..."
  return dialogue.encouragement[Math.floor(Math.random() * dialogue.encouragement.length)]
}

export function getFarewell(npcId: string, tone: DifficultyTier): string {
  const dialogue = getDialogue(npcId, tone)
  return dialogue?.farewell || "..."
}
