/**
 * TRINITY ARCADE PATCH — REALM DEFINITIONS
 * Static realm configurations
 */

import type { TrinityRealm, RealmId } from "./types"

export const TRINITY_REALMS: Record<RealmId, TrinityRealm> = {
  NEURALIS: {
    id: "NEURALIS",
    label: "Neuralis",
    description: "The realm of order, logic, and structured learning",
    defaultTone: "NOOBIE",
    colorPrimary: "#3B82F6", // Blue
    colorSecondary: "#1E40AF",
    biasModifier: -0.2, // Softens difficulty
  },
  CHAOSPHERE: {
    id: "CHAOSPHERE",
    label: "Chaosphere",
    description: "The realm of chaos, challenge, and rapid adaptation",
    defaultTone: "GAMER",
    colorPrimary: "#EF4444", // Red
    colorSecondary: "#991B1B",
    biasModifier: 0.3, // Hardens difficulty
  },
  ECHO: {
    id: "ECHO",
    label: "Echo",
    description: "The neutral realm where both forces balance",
    defaultTone: "CASUAL",
    colorPrimary: "#8B5CF6", // Purple
    colorSecondary: "#5B21B6",
    biasModifier: 0, // Neutral
  },
}

export function getRealm(id: RealmId): TrinityRealm {
  return TRINITY_REALMS[id]
}

export function getAllRealms(): TrinityRealm[] {
  return Object.values(TRINITY_REALMS)
}

export function getRealmColor(id: RealmId): { primary: string; secondary: string } {
  const realm = TRINITY_REALMS[id]
  return { primary: realm.colorPrimary, secondary: realm.colorSecondary }
}
