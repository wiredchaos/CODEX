/**
 * TRINITY ARCADE PATCH — AGENTIC ADAPTATION ENGINE
 * Difficulty classification and adaptation logic
 * NO HOST DEPENDENCIES
 */

import type { DifficultyTier, DifficultyProfile, RealmId, SessionTelemetry, TelemetryEvent } from "./types"
import { DIFFICULTY_PROFILES } from "./types"
import { TRINITY_REALMS } from "./realms"

// ============================================
// TELEMETRY ANALYSIS
// ============================================

export interface PerformanceMetrics {
  gamesPlayed: number
  winRate: number
  averageCompletionTime: number
  hintsUsed: number
  failureCount: number
  streakLength: number
}

export function analyzePerformance(events: TelemetryEvent[]): PerformanceMetrics {
  const gameEvents = events.filter((e) => e.eventType === "GAME_START" || e.eventType === "GAME_END")

  let gamesPlayed = 0
  let wins = 0
  let totalTime = 0
  let hintsUsed = 0
  let failures = 0
  let currentStreak = 0
  let maxStreak = 0

  let gameStartTime: number | null = null

  for (const event of gameEvents) {
    if (event.eventType === "GAME_START") {
      gameStartTime = event.timestamp
    } else if (event.eventType === "GAME_END" && gameStartTime) {
      gamesPlayed++
      totalTime += event.timestamp - gameStartTime

      const won = event.data.won as boolean
      hintsUsed += (event.data.hintsUsed as number) || 0

      if (won) {
        wins++
        currentStreak++
        maxStreak = Math.max(maxStreak, currentStreak)
      } else {
        failures++
        currentStreak = 0
      }

      gameStartTime = null
    }
  }

  return {
    gamesPlayed,
    winRate: gamesPlayed > 0 ? wins / gamesPlayed : 0,
    averageCompletionTime: gamesPlayed > 0 ? totalTime / gamesPlayed : 0,
    hintsUsed,
    failureCount: failures,
    streakLength: maxStreak,
  }
}

// ============================================
// DIFFICULTY CLASSIFICATION
// ============================================

export function classifyPlayer(metrics: PerformanceMetrics): DifficultyTier {
  // Not enough data — default to CASUAL
  if (metrics.gamesPlayed < 3) {
    return "CASUAL"
  }

  // High performer — GAMER
  if (metrics.winRate >= 0.8 && metrics.hintsUsed <= metrics.gamesPlayed * 0.5 && metrics.streakLength >= 3) {
    return "GAMER"
  }

  // Struggling — NOOBIE
  if (
    metrics.winRate < 0.4 ||
    metrics.hintsUsed >= metrics.gamesPlayed * 2 ||
    metrics.failureCount >= metrics.gamesPlayed * 0.6
  ) {
    return "NOOBIE"
  }

  // Default — CASUAL
  return "CASUAL"
}

// ============================================
// REALM BIAS OVERLAY
// ============================================

export function applyRealmBias(baseTier: DifficultyTier, realmId: RealmId): DifficultyTier {
  const realm = TRINITY_REALMS[realmId]
  const bias = realm.biasModifier

  const tierOrder: DifficultyTier[] = ["NOOBIE", "CASUAL", "GAMER"]
  const currentIndex = tierOrder.indexOf(baseTier)

  // Bias shifts the tier
  let newIndex = currentIndex
  if (bias < -0.15) {
    newIndex = Math.max(0, currentIndex - 1) // Soften
  } else if (bias > 0.15) {
    newIndex = Math.min(2, currentIndex + 1) // Harden
  }

  return tierOrder[newIndex]
}

// ============================================
// FULL ADAPTATION PIPELINE
// ============================================

export function computeAdaptedDifficulty(
  session: SessionTelemetry,
  currentRealm: RealmId,
): { tier: DifficultyTier; profile: DifficultyProfile } {
  const metrics = analyzePerformance(session.events)
  const baseTier = classifyPlayer(metrics)
  const adaptedTier = applyRealmBias(baseTier, currentRealm)

  return {
    tier: adaptedTier,
    profile: DIFFICULTY_PROFILES[adaptedTier],
  }
}

// ============================================
// SESSION MANAGEMENT
// ============================================

export function createSession(playerId: string): SessionTelemetry {
  return {
    sessionId: `session_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
    playerId,
    startTime: Date.now(),
    events: [],
    currentDifficulty: "CASUAL",
    adaptationHistory: [],
  }
}

export function recordEvent(
  session: SessionTelemetry,
  event: Omit<TelemetryEvent, "timestamp" | "playerId">,
): SessionTelemetry {
  return {
    ...session,
    events: [
      ...session.events,
      {
        ...event,
        timestamp: Date.now(),
        playerId: session.playerId,
      },
    ],
  }
}
