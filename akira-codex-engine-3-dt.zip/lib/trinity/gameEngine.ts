/**
 * TRINITY ARCADE PATCH — GAME ENGINE
 * Game session management and state
 */

import type { DifficultyTier, DifficultyProfile, RealmId, PlayerState, SessionTelemetry } from "./types"
import { DIFFICULTY_PROFILES } from "./types"
import { getGameById, calculateXpReward } from "./arcadeGames"
import { recordEvent } from "./aae"

// ============================================
// GAME SESSION
// ============================================

export interface GameSession {
  sessionId: string
  gameId: string
  playerId: string
  realm: RealmId
  difficulty: DifficultyTier
  profile: DifficultyProfile
  startTime: number
  endTime: number | null
  score: number
  hintsUsed: number
  status: "PENDING" | "ACTIVE" | "COMPLETED" | "ABANDONED"
  result: "WIN" | "LOSE" | null
}

// ============================================
// SESSION MANAGEMENT
// ============================================

export function createGameSession(
  gameId: string,
  playerId: string,
  realm: RealmId,
  difficulty: DifficultyTier,
): GameSession {
  return {
    sessionId: `game_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
    gameId,
    playerId,
    realm,
    difficulty,
    profile: DIFFICULTY_PROFILES[difficulty],
    startTime: Date.now(),
    endTime: null,
    score: 0,
    hintsUsed: 0,
    status: "PENDING",
    result: null,
  }
}

export function startGame(session: GameSession): GameSession {
  return {
    ...session,
    status: "ACTIVE",
    startTime: Date.now(),
  }
}

export function endGame(session: GameSession, result: "WIN" | "LOSE", finalScore: number): GameSession {
  return {
    ...session,
    status: "COMPLETED",
    endTime: Date.now(),
    result,
    score: finalScore,
  }
}

export function abandonGame(session: GameSession): GameSession {
  return {
    ...session,
    status: "ABANDONED",
    endTime: Date.now(),
  }
}

export function useHint(session: GameSession): GameSession {
  return {
    ...session,
    hintsUsed: session.hintsUsed + 1,
  }
}

// ============================================
// PLAYER STATE MANAGEMENT
// ============================================

export function createPlayerState(playerId: string): PlayerState {
  return {
    id: playerId,
    currentRealm: "ECHO",
    position: { x: 5, y: 5 },
    difficultyTier: "CASUAL",
    xp: 0,
    wlProgress: 0,
    completedGames: [],
    unlockedPortals: [],
  }
}

export function updatePlayerAfterGame(player: PlayerState, session: GameSession): PlayerState {
  if (session.status !== "COMPLETED" || session.result !== "WIN") {
    return player
  }

  const xpGained = calculateXpReward(session.gameId, session.difficulty, true)
  const game = getGameById(session.gameId)

  return {
    ...player,
    xp: player.xp + xpGained,
    wlProgress: player.wlProgress + (game?.wlProgress?.steps || 0),
    completedGames: player.completedGames.includes(session.gameId)
      ? player.completedGames
      : [...player.completedGames, session.gameId],
  }
}

export function changeRealm(player: PlayerState, newRealm: RealmId): PlayerState {
  return {
    ...player,
    currentRealm: newRealm,
    position: { x: 5, y: 5 }, // Reset to center of new realm
  }
}

export function movePlayer(player: PlayerState, newPosition: { x: number; y: number }): PlayerState {
  return {
    ...player,
    position: newPosition,
  }
}

// ============================================
// TELEMETRY INTEGRATION
// ============================================

export function recordGameStart(telemetry: SessionTelemetry, gameSession: GameSession): SessionTelemetry {
  return recordEvent(telemetry, {
    eventType: "GAME_START",
    realm: gameSession.realm,
    data: {
      gameId: gameSession.gameId,
      difficulty: gameSession.difficulty,
    },
  })
}

export function recordGameEnd(telemetry: SessionTelemetry, gameSession: GameSession): SessionTelemetry {
  return recordEvent(telemetry, {
    eventType: "GAME_END",
    realm: gameSession.realm,
    data: {
      gameId: gameSession.gameId,
      won: gameSession.result === "WIN",
      score: gameSession.score,
      hintsUsed: gameSession.hintsUsed,
      duration: gameSession.endTime ? gameSession.endTime - gameSession.startTime : 0,
    },
  })
}
