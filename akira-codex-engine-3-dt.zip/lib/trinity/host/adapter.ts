/**
 * TRINITY ARCADE PATCH — PHASE 2 HOST ADAPTER INTERFACE
 * Universal interface all hosts must implement
 * NO HOST LOGIC — interfaces only
 */

// ============================================
// HOST IDENTITY
// ============================================

export interface HostIdentity {
  userId: string
  displayName: string
  avatarUrl?: string
  roles?: string[]
  metadata?: Record<string, unknown>
}

// ============================================
// HOST ECONOMY
// ============================================

export interface HostEconomy {
  /**
   * Grant XP to the player
   */
  grantXp(amount: number, reason: string): Promise<void>

  /**
   * Grant whitelist progress (optional)
   */
  grantWhitelistProgress?(steps: number, context: string): Promise<void>

  /**
   * Get current XP balance
   */
  getXpBalance?(): Promise<number>

  /**
   * Get current whitelist progress
   */
  getWhitelistProgress?(): Promise<number>
}

// ============================================
// HOST LORE BRIDGE
// ============================================

export interface HostLoreBridge {
  /**
   * Get narration text for a given key
   */
  getNarration(key: string, context?: Record<string, unknown>): string

  /**
   * Get NPC skin/sprite override (optional)
   */
  getNpcSkin?(npcId: string): { spriteUrl: string; title?: string } | null

  /**
   * Get realm-specific lore (optional)
   */
  getRealmLore?(realmId: string): { title: string; description: string } | null
}

// ============================================
// HOST TELEMETRY
// ============================================

export interface HostTelemetry {
  /**
   * Track an event
   */
  trackEvent(eventName: string, data: Record<string, unknown>): void

  /**
   * Flush pending events
   */
  flush?(): Promise<void>
}

// ============================================
// MAIN HOST ADAPTER INTERFACE
// ============================================

export interface TrinityHostAdapter {
  /**
   * Unique identifier for this host
   */
  readonly hostId: string

  /**
   * Human-readable host name
   */
  readonly hostName: string

  /**
   * Initialize the adapter
   */
  initialize(): Promise<void>

  /**
   * Get current user identity (null if not authenticated)
   */
  getCurrentIdentity(): Promise<HostIdentity | null>

  /**
   * Get economy interface
   */
  getEconomy(): HostEconomy

  /**
   * Get lore bridge interface
   */
  getLoreBridge(): HostLoreBridge

  /**
   * Get telemetry interface (optional)
   */
  getTelemetry?(): HostTelemetry

  /**
   * Cleanup on unmount
   */
  destroy?(): void
}

// ============================================
// TYPE GUARDS
// ============================================

export function isHostAdapter(obj: unknown): obj is TrinityHostAdapter {
  if (!obj || typeof obj !== "object") return false
  const adapter = obj as TrinityHostAdapter
  return (
    typeof adapter.hostId === "string" &&
    typeof adapter.hostName === "string" &&
    typeof adapter.initialize === "function" &&
    typeof adapter.getCurrentIdentity === "function" &&
    typeof adapter.getEconomy === "function" &&
    typeof adapter.getLoreBridge === "function"
  )
}
