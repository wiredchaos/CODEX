/**
 * TRINITY ARCADE PATCH — PHASE 2 HOST RESOLVER
 * Neutral loader for selecting host adapters
 * NO HOST LOGIC — placeholder registry only
 */

import type { TrinityHostAdapter } from "./adapter"
import type { TrinityPatchManifest } from "./manifest"

// ============================================
// HOST REGISTRY
// ============================================

type HostFactory = () => TrinityHostAdapter

const HOST_REGISTRY = new Map<string, HostFactory>()
const MANIFEST_REGISTRY = new Map<string, TrinityPatchManifest>()

// ============================================
// REGISTRATION
// ============================================

/**
 * Register a host adapter factory
 */
export function registerHost(hostId: string, factory: HostFactory, manifest?: TrinityPatchManifest): void {
  HOST_REGISTRY.set(hostId, factory)
  if (manifest) {
    MANIFEST_REGISTRY.set(hostId, manifest)
  }
}

/**
 * Unregister a host adapter
 */
export function unregisterHost(hostId: string): void {
  HOST_REGISTRY.delete(hostId)
  MANIFEST_REGISTRY.delete(hostId)
}

// ============================================
// RESOLUTION
// ============================================

/**
 * Resolve a host adapter by ID
 * Returns null if not found
 */
export function resolveHostAdapter(hostId: string): TrinityHostAdapter | null {
  const factory = HOST_REGISTRY.get(hostId)
  if (!factory) {
    return null
  }
  return factory()
}

/**
 * Get manifest for a host
 */
export function getHostManifest(hostId: string): TrinityPatchManifest | null {
  return MANIFEST_REGISTRY.get(hostId) || null
}

/**
 * List all registered host IDs
 */
export function listRegisteredHosts(): string[] {
  return Array.from(HOST_REGISTRY.keys())
}

/**
 * Check if a host is registered
 */
export function isHostRegistered(hostId: string): boolean {
  return HOST_REGISTRY.has(hostId)
}

// ============================================
// ENVIRONMENT DETECTION
// ============================================

export type HostEnvironment = "WIRED_CHAOS" | "AKIRA_CODEX" | "NETERU" | "RVP" | "STANDALONE" | "UNKNOWN"

/**
 * Detect current host environment
 * This is a placeholder — real detection added in Phase 3+
 */
export function detectHostEnvironment(): HostEnvironment {
  // Check for environment markers (to be implemented by hosts)
  if (typeof window !== "undefined") {
    const win = window as Record<string, unknown>
    if (win.__WIRED_CHAOS_HOST__) return "WIRED_CHAOS"
    if (win.__AKIRA_CODEX_HOST__) return "AKIRA_CODEX"
    if (win.__NETERU_HOST__) return "NETERU"
    if (win.__RVP_HOST__) return "RVP"
  }
  return "STANDALONE"
}

/**
 * Auto-resolve host adapter based on environment
 */
export function autoResolveHostAdapter(): TrinityHostAdapter | null {
  const env = detectHostEnvironment()

  switch (env) {
    case "WIRED_CHAOS":
      return resolveHostAdapter("wired_chaos")
    case "AKIRA_CODEX":
      return resolveHostAdapter("akira_codex")
    case "NETERU":
      return resolveHostAdapter("neteru")
    case "RVP":
      return resolveHostAdapter("rvp")
    case "STANDALONE":
      return resolveHostAdapter("standalone")
    default:
      return null
  }
}

// ============================================
// INITIALIZATION LIFECYCLE
// ============================================

let currentAdapter: TrinityHostAdapter | null = null
let initialized = false

/**
 * Initialize Trinity with auto-detected or specified host
 */
export async function initializeTrinity(hostId?: string): Promise<TrinityHostAdapter | null> {
  // Cleanup previous adapter
  if (currentAdapter?.destroy) {
    currentAdapter.destroy()
  }

  // Resolve adapter
  currentAdapter = hostId ? resolveHostAdapter(hostId) : autoResolveHostAdapter()

  if (!currentAdapter) {
    console.warn("[Trinity] No host adapter found")
    return null
  }

  // Initialize
  await currentAdapter.initialize()
  initialized = true

  return currentAdapter
}

/**
 * Get current active adapter
 */
export function getCurrentAdapter(): TrinityHostAdapter | null {
  return currentAdapter
}

/**
 * Check if Trinity is initialized
 */
export function isInitialized(): boolean {
  return initialized
}

/**
 * Shutdown Trinity
 */
export function shutdownTrinity(): void {
  if (currentAdapter?.destroy) {
    currentAdapter.destroy()
  }
  currentAdapter = null
  initialized = false
}
