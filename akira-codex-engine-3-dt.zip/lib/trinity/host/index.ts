/**
 * TRINITY ARCADE PATCH — HOST MODULE INDEX
 * Barrel exports for Phase 2 Host Adapter Interfaces
 */

// Adapter interfaces
export type {
  TrinityHostAdapter,
  HostIdentity,
  HostEconomy,
  HostLoreBridge,
  HostTelemetry,
} from "./adapter"
export { isHostAdapter } from "./adapter"

// Manifest schemas
export type {
  TrinityPatchManifest,
  RealmManifestEntry,
  GameManifestEntry,
  PortalManifestEntry,
  LoreHookEntry,
  HostBindings,
  ManifestValidationResult,
} from "./manifest"
export { validateManifest, createDefaultManifest } from "./manifest"

// Host resolution
export {
  registerHost,
  unregisterHost,
  resolveHostAdapter,
  getHostManifest,
  listRegisteredHosts,
  isHostRegistered,
  detectHostEnvironment,
  autoResolveHostAdapter,
  initializeTrinity,
  getCurrentAdapter,
  isInitialized,
  shutdownTrinity,
} from "./resolve"
export type { HostEnvironment } from "./resolve"
