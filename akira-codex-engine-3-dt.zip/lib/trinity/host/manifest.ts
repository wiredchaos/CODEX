/**
 * TRINITY ARCADE PATCH — PHASE 2 MANIFEST SCHEMA
 * Metadata structure hosts use to describe their configuration
 * NO HOST LOGIC — schemas only
 */

import type { DifficultyTier, RealmId } from "../types"

// ============================================
// REALM MANIFEST
// ============================================

export interface RealmManifestEntry {
  id: RealmId
  label: string
  description: string
  defaultTone: DifficultyTier
  enabled: boolean
  customSkin?: {
    colorPrimary: string
    colorSecondary: string
    backgroundImage?: string
  }
}

// ============================================
// GAME MANIFEST
// ============================================

export interface GameManifestEntry {
  id: string
  label: string
  description: string
  realms: RealmId[]
  enabled: boolean
  xpMultiplier?: number
  wlEnabled?: boolean
}

// ============================================
// PORTAL MANIFEST
// ============================================

export interface PortalManifestEntry {
  id: string
  label: string
  fromRealm: RealmId
  toRealm: RealmId
  unlockCondition?: {
    type: "XP_THRESHOLD" | "GAME_COMPLETE" | "CUSTOM"
    value: string | number
  }
}

// ============================================
// LORE HOOK MANIFEST
// ============================================

export interface LoreHookEntry {
  key: string
  source: string
  fallback: string
}

// ============================================
// HOST BINDINGS
// ============================================

export interface HostBindings {
  identity: "HOST_API" | "LOCAL_STORAGE" | "NONE"
  economy: "TOKEN" | "POINTS" | "NONE"
  loreMode: "FULL" | "MINIMAL" | "NONE"
  telemetry: "ENABLED" | "DISABLED"
}

// ============================================
// MAIN MANIFEST SCHEMA
// ============================================

export interface TrinityPatchManifest {
  /**
   * Unique patch identifier
   */
  patchId: string

  /**
   * Version string (semver)
   */
  version: string

  /**
   * Host system name
   */
  hostSystemName: string

  /**
   * Realm configurations
   */
  realms: RealmManifestEntry[]

  /**
   * Game configurations
   */
  games: GameManifestEntry[]

  /**
   * Portal configurations
   */
  portals: PortalManifestEntry[]

  /**
   * Lore hooks
   */
  loreHooks: LoreHookEntry[]

  /**
   * Host bindings
   */
  hostBindings: HostBindings

  /**
   * Custom metadata
   */
  metadata?: Record<string, unknown>
}

// ============================================
// MANIFEST VALIDATION
// ============================================

export interface ManifestValidationResult {
  valid: boolean
  errors: string[]
  warnings: string[]
}

export function validateManifest(manifest: TrinityPatchManifest): ManifestValidationResult {
  const errors: string[] = []
  const warnings: string[] = []

  // Required fields
  if (!manifest.patchId) {
    errors.push("patchId is required")
  }
  if (!manifest.version) {
    errors.push("version is required")
  }
  if (!manifest.hostSystemName) {
    errors.push("hostSystemName is required")
  }

  // Realms validation
  if (!manifest.realms || manifest.realms.length === 0) {
    errors.push("At least one realm is required")
  } else {
    const realmIds = new Set<string>()
    for (const realm of manifest.realms) {
      if (realmIds.has(realm.id)) {
        errors.push(`Duplicate realm ID: ${realm.id}`)
      }
      realmIds.add(realm.id)
    }
  }

  // Games validation
  if (!manifest.games || manifest.games.length === 0) {
    warnings.push("No games configured")
  } else {
    const gameIds = new Set<string>()
    for (const game of manifest.games) {
      if (gameIds.has(game.id)) {
        errors.push(`Duplicate game ID: ${game.id}`)
      }
      gameIds.add(game.id)

      // Check realm references
      for (const realmId of game.realms) {
        if (!manifest.realms.find((r) => r.id === realmId)) {
          errors.push(`Game "${game.id}" references unknown realm: ${realmId}`)
        }
      }
    }
  }

  // Portals validation
  for (const portal of manifest.portals || []) {
    if (!manifest.realms.find((r) => r.id === portal.fromRealm)) {
      errors.push(`Portal "${portal.id}" references unknown fromRealm: ${portal.fromRealm}`)
    }
    if (!manifest.realms.find((r) => r.id === portal.toRealm)) {
      errors.push(`Portal "${portal.id}" references unknown toRealm: ${portal.toRealm}`)
    }
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  }
}

// ============================================
// DEFAULT MANIFEST FACTORY
// ============================================

export function createDefaultManifest(hostName: string): TrinityPatchManifest {
  return {
    patchId: `trinity_${hostName.toLowerCase().replace(/\s+/g, "_")}`,
    version: "1.0.0",
    hostSystemName: hostName,
    realms: [
      {
        id: "NEURALIS",
        label: "Neuralis",
        description: "The realm of order and logic",
        defaultTone: "NOOBIE",
        enabled: true,
      },
      {
        id: "CHAOSPHERE",
        label: "Chaosphere",
        description: "The realm of chaos and challenge",
        defaultTone: "GAMER",
        enabled: true,
      },
      {
        id: "ECHO",
        label: "Echo",
        description: "The realm of balance",
        defaultTone: "CASUAL",
        enabled: true,
      },
    ],
    games: [],
    portals: [],
    loreHooks: [],
    hostBindings: {
      identity: "NONE",
      economy: "POINTS",
      loreMode: "MINIMAL",
      telemetry: "DISABLED",
    },
  }
}
