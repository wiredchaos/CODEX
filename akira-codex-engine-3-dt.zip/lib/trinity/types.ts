/**
 * TRINITY ARCADE PATCH — PHASE 1 CORE TYPES
 * Neutral, host-agnostic type definitions
 * NO HOST LOGIC — interfaces only
 */

// ============================================
// DIFFICULTY & PLAYER PROFILING
// ============================================

export type DifficultyTier = "NOOBIE" | "CASUAL" | "GAMER"

export interface DifficultyProfile {
  tier: DifficultyTier
  label: string
  description: string
  modifiers: {
    speedMultiplier: number
    complexityLevel: number
    hintFrequency: "HIGH" | "MEDIUM" | "LOW" | "NONE"
    failureTolerance: number
  }
}

export const DIFFICULTY_PROFILES: Record<DifficultyTier, DifficultyProfile> = {
  NOOBIE: {
    tier: "NOOBIE",
    label: "Newcomer",
    description: "Gentle introduction with maximum guidance",
    modifiers: {
      speedMultiplier: 0.6,
      complexityLevel: 1,
      hintFrequency: "HIGH",
      failureTolerance: 5,
    },
  },
  CASUAL: {
    tier: "CASUAL",
    label: "Casual",
    description: "Balanced challenge with moderate assistance",
    modifiers: {
      speedMultiplier: 1.0,
      complexityLevel: 2,
      hintFrequency: "MEDIUM",
      failureTolerance: 3,
    },
  },
  GAMER: {
    tier: "GAMER",
    label: "Veteran",
    description: "Full challenge, minimal hand-holding",
    modifiers: {
      speedMultiplier: 1.4,
      complexityLevel: 3,
      hintFrequency: "NONE",
      failureTolerance: 1,
    },
  },
}

// ============================================
// REALM DEFINITIONS
// ============================================

export type RealmId = "NEURALIS" | "CHAOSPHERE" | "ECHO"

export interface TrinityRealm {
  id: RealmId
  label: string
  description: string
  defaultTone: DifficultyTier
  colorPrimary: string
  colorSecondary: string
  biasModifier: number // -1 to +1, affects difficulty
}

// ============================================
// GAME DEFINITIONS
// ============================================

export interface GameConfig {
  id: string
  label: string
  description: string
  supportedRealms: RealmId[]
  difficultyVariants: DifficultyTier[]
  xpReward: { base: number; multiplier: number }
  wlProgress?: { steps: number; context: string }
}

// ============================================
// NPC DEFINITIONS
// ============================================

export interface NpcConfig {
  id: string
  name: string
  role: string
  realm: RealmId
  dialogueTone: DifficultyTier
  spriteKey: string
  position: { x: number; y: number }
}

export interface NpcDialogue {
  npcId: string
  tone: DifficultyTier
  greeting: string
  hints: string[]
  encouragement: string[]
  farewell: string
}

// ============================================
// GRID & NAVIGATION
// ============================================

export interface GridTile {
  x: number
  y: number
  type: "FLOOR" | "WALL" | "PORTAL" | "NPC_SPAWN" | "GAME_NODE"
  realmId?: RealmId
  metadata?: Record<string, unknown>
}

export interface GridPosition {
  x: number
  y: number
}

export interface Portal {
  id: string
  label: string
  fromRealm: RealmId
  toRealm: RealmId
  position: GridPosition
  unlockCondition?: string
}

// ============================================
// PLAYER STATE
// ============================================

export interface PlayerState {
  id: string
  currentRealm: RealmId
  position: GridPosition
  difficultyTier: DifficultyTier
  xp: number
  wlProgress: number
  completedGames: string[]
  unlockedPortals: string[]
}

// ============================================
// TELEMETRY
// ============================================

export interface TelemetryEvent {
  eventType: "GAME_START" | "GAME_END" | "REALM_CHANGE" | "NPC_INTERACT" | "PORTAL_USE"
  timestamp: number
  playerId: string
  realm: RealmId
  data: Record<string, unknown>
}

export interface SessionTelemetry {
  sessionId: string
  playerId: string
  startTime: number
  events: TelemetryEvent[]
  currentDifficulty: DifficultyTier
  adaptationHistory: { timestamp: number; from: DifficultyTier; to: DifficultyTier }[]
}
