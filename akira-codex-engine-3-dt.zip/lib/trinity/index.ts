/**
 * TRINITY ARCADE PATCH — MAIN INDEX
 * Barrel exports for all Trinity modules
 */

// Core types
export * from "./types"

// Realm definitions
export * from "./realms"

// AAE Engine
export * from "./aae"

// Grid Engine
export * from "./grid"

// NPC System
export * from "./npc"

// Game Registry
export * from "./arcadeGames"

// Game Engine
export * from "./gameEngine"

// Host Adapter Interfaces (Phase 2)
export * from "./host/index"
