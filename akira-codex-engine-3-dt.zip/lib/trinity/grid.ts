/**
 * TRINITY ARCADE PATCH — ISOMETRIC GRID ENGINE
 * Grid management, pathfinding, and coordinate conversion
 */

import type { GridTile, GridPosition, RealmId, Portal } from "./types"

// ============================================
// GRID CONSTANTS
// ============================================

export const TILE_WIDTH = 64
export const TILE_HEIGHT = 32
export const GRID_SIZE = 12

// ============================================
// COORDINATE CONVERSION
// ============================================

export function gridToScreen(pos: GridPosition): { x: number; y: number } {
  return {
    x: (pos.x - pos.y) * (TILE_WIDTH / 2),
    y: (pos.x + pos.y) * (TILE_HEIGHT / 2),
  }
}

export function screenToGrid(screenX: number, screenY: number): GridPosition {
  const x = Math.floor(screenX / TILE_WIDTH + screenY / TILE_HEIGHT)
  const y = Math.floor(screenY / TILE_HEIGHT - screenX / TILE_WIDTH)
  return { x, y }
}

// ============================================
// GRID GENERATION
// ============================================

export function generateGrid(realmId: RealmId, size: number = GRID_SIZE): GridTile[][] {
  const grid: GridTile[][] = []

  for (let y = 0; y < size; y++) {
    const row: GridTile[] = []
    for (let x = 0; x < size; x++) {
      // Default floor tiles
      let type: GridTile["type"] = "FLOOR"

      // Walls on edges
      if (x === 0 || y === 0 || x === size - 1 || y === size - 1) {
        type = "WALL"
      }

      row.push({
        x,
        y,
        type,
        realmId,
      })
    }
    grid.push(row)
  }

  return grid
}

// ============================================
// GRID UTILITIES
// ============================================

export function getTile(grid: GridTile[][], pos: GridPosition): GridTile | null {
  if (pos.y >= 0 && pos.y < grid.length && pos.x >= 0 && pos.x < grid[pos.y].length) {
    return grid[pos.y][pos.x]
  }
  return null
}

export function setTile(grid: GridTile[][], pos: GridPosition, tile: Partial<GridTile>): GridTile[][] {
  const newGrid = grid.map((row) => [...row])
  if (pos.y >= 0 && pos.y < newGrid.length && pos.x >= 0 && pos.x < newGrid[pos.y].length) {
    newGrid[pos.y][pos.x] = { ...newGrid[pos.y][pos.x], ...tile }
  }
  return newGrid
}

export function isWalkable(grid: GridTile[][], pos: GridPosition): boolean {
  const tile = getTile(grid, pos)
  return tile !== null && tile.type !== "WALL"
}

// ============================================
// A* PATHFINDING
// ============================================

interface PathNode {
  pos: GridPosition
  g: number
  h: number
  f: number
  parent: PathNode | null
}

function heuristic(a: GridPosition, b: GridPosition): number {
  return Math.abs(a.x - b.x) + Math.abs(a.y - b.y)
}

function posKey(pos: GridPosition): string {
  return `${pos.x},${pos.y}`
}

export function findPath(grid: GridTile[][], start: GridPosition, end: GridPosition): GridPosition[] {
  const openSet: PathNode[] = []
  const closedSet = new Set<string>()

  const startNode: PathNode = {
    pos: start,
    g: 0,
    h: heuristic(start, end),
    f: heuristic(start, end),
    parent: null,
  }

  openSet.push(startNode)

  const directions = [
    { x: 0, y: -1 },
    { x: 0, y: 1 },
    { x: -1, y: 0 },
    { x: 1, y: 0 },
  ]

  while (openSet.length > 0) {
    // Get node with lowest f score
    openSet.sort((a, b) => a.f - b.f)
    const current = openSet.shift()!

    // Reached destination
    if (current.pos.x === end.x && current.pos.y === end.y) {
      const path: GridPosition[] = []
      let node: PathNode | null = current
      while (node) {
        path.unshift(node.pos)
        node = node.parent
      }
      return path
    }

    closedSet.add(posKey(current.pos))

    // Check neighbors
    for (const dir of directions) {
      const neighborPos: GridPosition = {
        x: current.pos.x + dir.x,
        y: current.pos.y + dir.y,
      }

      const key = posKey(neighborPos)
      if (closedSet.has(key) || !isWalkable(grid, neighborPos)) {
        continue
      }

      const g = current.g + 1
      const h = heuristic(neighborPos, end)
      const f = g + h

      const existingNode = openSet.find((n) => n.pos.x === neighborPos.x && n.pos.y === neighborPos.y)

      if (existingNode) {
        if (g < existingNode.g) {
          existingNode.g = g
          existingNode.f = f
          existingNode.parent = current
        }
      } else {
        openSet.push({
          pos: neighborPos,
          g,
          h,
          f,
          parent: current,
        })
      }
    }
  }

  // No path found
  return []
}

// ============================================
// PORTAL MANAGEMENT
// ============================================

export function placePortal(grid: GridTile[][], portal: Portal): GridTile[][] {
  return setTile(grid, portal.position, {
    type: "PORTAL",
    metadata: { portalId: portal.id, toRealm: portal.toRealm },
  })
}

export function getPortalAt(grid: GridTile[][], pos: GridPosition): string | null {
  const tile = getTile(grid, pos)
  if (tile?.type === "PORTAL" && tile.metadata?.portalId) {
    return tile.metadata.portalId as string
  }
  return null
}
