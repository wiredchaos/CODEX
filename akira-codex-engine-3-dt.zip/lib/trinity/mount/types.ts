/**
 * TRINITY FLOOR / TIMELINE MOUNT — CONSUMER TYPES
 *
 * Declarations:
 * - No new 3D generation
 * - No new galaxy creation
 * - This patch mounts to its assigned Trinity Floor or Timeline
 * - Timeline access is governed by Akira Codex
 * - Trinity is read-only infrastructure
 * - This patch operates as a consumer, not an owner
 */

// ============================================
// MOUNT POINT DEFINITIONS (READ-ONLY)
// ============================================

export type MountTarget = "TRINITY_FLOOR" | "AKIRA_TIMELINE"

export interface MountPoint {
  readonly id: string
  readonly target: MountTarget
  readonly floorId?: string // Trinity floor reference
  readonly timelineId?: string // Akira timeline reference
  readonly readOnly: true // ALWAYS read-only
  readonly mountedAt: Date
}

// ============================================
// FLOOR BINDING (CONSUMER ONLY)
// ============================================

export interface TrinityFloorBinding {
  readonly floorId: string
  readonly realmId: "NEURALIS" | "CHAOSPHERE" | "ECHO"
  readonly gridRef: string // Reference to existing grid, NOT a copy
  readonly portalRefs: string[] // References to existing portals
  readonly npcRefs: string[] // References to existing NPCs
  readonly gameNodeRefs: string[] // References to existing game nodes
}

// ============================================
// TIMELINE BINDING (AKIRA CODEX GOVERNED)
// ============================================

export interface AkiraTimelineBinding {
  readonly timelineId: string
  readonly storyId: string
  readonly eraFilter?: string[] // Optional filter for visible eras
  readonly eventRefs: string[] // References to timeline events
  readonly accessLevel: TimelineAccessLevel
}

export type TimelineAccessLevel =
  | "OBSERVER" // Can view only
  | "CONTRIBUTOR" // Can suggest events (requires approval)
  | "NARRATOR" // Full timeline access (Akira Codex only)

// ============================================
// MOUNT SESSION (TRANSIENT)
// ============================================

export interface MountSession {
  readonly sessionId: string
  readonly consumerId: string // The system mounting to Trinity
  readonly mountPoints: MountPoint[]
  readonly startedAt: Date
  readonly expiresAt: Date
  readonly permissions: MountPermissions
}

export interface MountPermissions {
  readonly canReadGrid: boolean
  readonly canReadNpcs: boolean
  readonly canReadPortals: boolean
  readonly canReadTimeline: boolean
  readonly canTriggerEvents: boolean // Emit events, not modify
  readonly canWriteAnything: false // ALWAYS false - consumer only
}

// ============================================
// MOUNT EVENTS (EMIT ONLY, NO MODIFICATION)
// ============================================

export type MountEventType =
  | "FLOOR_ENTERED"
  | "FLOOR_EXITED"
  | "TIMELINE_ACCESSED"
  | "EVENT_OBSERVED"
  | "PORTAL_VIEWED"
  | "NPC_QUERIED"

export interface MountEvent {
  readonly type: MountEventType
  readonly sessionId: string
  readonly mountPointId: string
  readonly timestamp: Date
  readonly data: Readonly<Record<string, unknown>>
}
