/**
 * TRINITY FLOOR / TIMELINE MOUNT
 *
 * DECLARATIONS:
 * - No new 3D generation
 * - No new galaxy creation
 * - This patch mounts to its assigned Trinity Floor or Timeline
 * - Timeline access is governed by Akira Codex
 * - Trinity is read-only infrastructure
 * - This patch operates as a consumer, not an owner
 */

// Types
export type {
  MountTarget,
  MountPoint,
  TrinityFloorBinding,
  AkiraTimelineBinding,
  TimelineAccessLevel,
  MountSession,
  MountPermissions,
  MountEventType,
  MountEvent,
} from "./types"

// Floor Consumer
export {
  TrinityFloorConsumer,
  createFloorBinding,
} from "./floor-consumer"

// Timeline Consumer
export {
  AkiraTimelineConsumer,
  createTimelineBinding,
} from "./timeline-consumer"

// Session Manager
export {
  MountSessionManager,
  mountSessionManager,
} from "./session-manager"
