/**
 * MOUNT SESSION MANAGER
 * Manages consumer sessions for Trinity Floor and Timeline access
 *
 * All sessions are:
 * - Time-limited
 * - Read-only
 * - Auditable
 */

import type { MountSession, MountPoint, MountTarget, MountPermissions } from "./types"
import { TrinityFloorConsumer, createFloorBinding } from "./floor-consumer"
import { AkiraTimelineConsumer, createTimelineBinding } from "./timeline-consumer"
import type { RealmId } from "../types"

// ============================================
// SESSION ID GENERATION
// ============================================

function generateSessionId(): string {
  const timestamp = Date.now().toString(36)
  const random = Math.random().toString(36).substring(2, 10)
  return `MOUNT_${timestamp}_${random}`
}

function generateMountId(target: MountTarget): string {
  const timestamp = Date.now().toString(36)
  const random = Math.random().toString(36).substring(2, 6)
  return `${target}_${timestamp}_${random}`
}

// ============================================
// DEFAULT PERMISSIONS (READ-ONLY)
// ============================================

const DEFAULT_PERMISSIONS: MountPermissions = Object.freeze({
  canReadGrid: true,
  canReadNpcs: true,
  canReadPortals: true,
  canReadTimeline: true,
  canTriggerEvents: true,
  canWriteAnything: false, // ALWAYS FALSE
})

// ============================================
// SESSION MANAGER
// ============================================

export class MountSessionManager {
  private activeSessions: Map<string, MountSession> = new Map()
  private readonly sessionDurationMs: number

  constructor(sessionDurationMinutes = 60) {
    this.sessionDurationMs = sessionDurationMinutes * 60 * 1000
  }

  // ─────────────────────────────────────────
  // SESSION LIFECYCLE
  // ─────────────────────────────────────────

  createSession(consumerId: string): MountSession {
    const now = new Date()
    const session: MountSession = {
      sessionId: generateSessionId(),
      consumerId,
      mountPoints: [],
      startedAt: now,
      expiresAt: new Date(now.getTime() + this.sessionDurationMs),
      permissions: DEFAULT_PERMISSIONS,
    }

    this.activeSessions.set(session.sessionId, session)
    return session
  }

  getSession(sessionId: string): MountSession | null {
    const session = this.activeSessions.get(sessionId)
    if (!session) return null

    // Check expiration
    if (new Date() > session.expiresAt) {
      this.terminateSession(sessionId)
      return null
    }

    return session
  }

  terminateSession(sessionId: string): boolean {
    return this.activeSessions.delete(sessionId)
  }

  // ─────────────────────────────────────────
  // MOUNT POINT CREATION
  // ─────────────────────────────────────────

  mountToFloor(session: MountSession, floorId: string): MountPoint {
    const mountPoint: MountPoint = {
      id: generateMountId("TRINITY_FLOOR"),
      target: "TRINITY_FLOOR",
      floorId,
      readOnly: true,
      mountedAt: new Date(),
    }

    // Add to session (immutable update)
    const updatedSession: MountSession = {
      ...session,
      mountPoints: [...session.mountPoints, mountPoint],
    }
    this.activeSessions.set(session.sessionId, updatedSession)

    return mountPoint
  }

  mountToTimeline(session: MountSession, timelineId: string): MountPoint {
    const mountPoint: MountPoint = {
      id: generateMountId("AKIRA_TIMELINE"),
      target: "AKIRA_TIMELINE",
      timelineId,
      readOnly: true,
      mountedAt: new Date(),
    }

    const updatedSession: MountSession = {
      ...session,
      mountPoints: [...session.mountPoints, mountPoint],
    }
    this.activeSessions.set(session.sessionId, updatedSession)

    return mountPoint
  }

  // ─────────────────────────────────────────
  // CONSUMER FACTORY
  // ─────────────────────────────────────────

  createFloorConsumer(
    session: MountSession,
    floorId: string,
    realmId: RealmId,
    refs: {
      gridRef: string
      portalRefs: string[]
      npcRefs: string[]
      gameNodeRefs: string[]
    },
  ): TrinityFloorConsumer {
    const binding = createFloorBinding(floorId, realmId, refs)
    return new TrinityFloorConsumer(binding, session)
  }

  createTimelineConsumer(
    session: MountSession,
    timelineId: string,
    storyId: string,
    eventRefs: string[],
  ): AkiraTimelineConsumer {
    const binding = createTimelineBinding(timelineId, storyId, eventRefs, "OBSERVER")
    return new AkiraTimelineConsumer(binding, session)
  }

  // ─────────────────────────────────────────
  // AUDIT
  // ─────────────────────────────────────────

  getActiveSessionCount(): number {
    return this.activeSessions.size
  }

  getSessionsByConsumer(consumerId: string): MountSession[] {
    return Array.from(this.activeSessions.values()).filter((s) => s.consumerId === consumerId)
  }
}

// ============================================
// SINGLETON INSTANCE
// ============================================

export const mountSessionManager = new MountSessionManager()
