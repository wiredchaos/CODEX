/**
 * TRINITY FLOOR CONSUMER
 * Read-only access to Trinity Floor infrastructure
 *
 * This module CONSUMES existing Trinity data.
 * It does NOT generate, modify, or own any 3D content.
 */

import type { TrinityFloorBinding, MountSession, MountEvent, MountPermissions } from "./types"
import type { RealmId } from "../types"
import { REALMS } from "../realms"

// ============================================
// FLOOR REFERENCE RESOLVER (READ-ONLY)
// ============================================

export class TrinityFloorConsumer {
  private readonly binding: TrinityFloorBinding
  private readonly session: MountSession

  constructor(binding: TrinityFloorBinding, session: MountSession) {
    this.binding = binding
    this.session = session

    // Validate read-only permissions
    if ((session.permissions as MountPermissions & { canWriteAnything?: boolean }).canWriteAnything) {
      throw new Error("MOUNT_VIOLATION: Consumer cannot have write permissions")
    }
  }

  // ─────────────────────────────────────────
  // GRID ACCESS (READ-ONLY)
  // ─────────────────────────────────────────

  getFloorId(): string {
    return this.binding.floorId
  }

  getRealmId(): RealmId {
    return this.binding.realmId
  }

  getRealmConfig() {
    return REALMS[this.binding.realmId]
  }

  /**
   * Query grid reference - returns reference ID only
   * Actual grid data must be fetched from Trinity Core
   */
  getGridRef(): string {
    this.emitEvent("FLOOR_ENTERED", { gridRef: this.binding.gridRef })
    return this.binding.gridRef
  }

  // ─────────────────────────────────────────
  // PORTAL ACCESS (READ-ONLY)
  // ─────────────────────────────────────────

  getPortalRefs(): readonly string[] {
    return Object.freeze([...this.binding.portalRefs])
  }

  queryPortal(portalRef: string): { exists: boolean; ref: string } {
    const exists = this.binding.portalRefs.includes(portalRef)
    if (exists) {
      this.emitEvent("PORTAL_VIEWED", { portalRef })
    }
    return { exists, ref: portalRef }
  }

  // ─────────────────────────────────────────
  // NPC ACCESS (READ-ONLY)
  // ─────────────────────────────────────────

  getNpcRefs(): readonly string[] {
    return Object.freeze([...this.binding.npcRefs])
  }

  queryNpc(npcRef: string): { exists: boolean; ref: string } {
    const exists = this.binding.npcRefs.includes(npcRef)
    if (exists) {
      this.emitEvent("NPC_QUERIED", { npcRef })
    }
    return { exists, ref: npcRef }
  }

  // ─────────────────────────────────────────
  // GAME NODE ACCESS (READ-ONLY)
  // ─────────────────────────────────────────

  getGameNodeRefs(): readonly string[] {
    return Object.freeze([...this.binding.gameNodeRefs])
  }

  // ─────────────────────────────────────────
  // EVENT EMISSION (NO MODIFICATION)
  // ─────────────────────────────────────────

  private emitEvent(type: MountEvent["type"], data: Record<string, unknown>): MountEvent {
    const event: MountEvent = {
      type,
      sessionId: this.session.sessionId,
      mountPointId: this.binding.floorId,
      timestamp: new Date(),
      data: Object.freeze(data),
    }

    // Event would be sent to telemetry bus here
    // Consumer can only EMIT, not modify Trinity state
    return event
  }
}

// ============================================
// FLOOR BINDING FACTORY
// ============================================

export function createFloorBinding(
  floorId: string,
  realmId: RealmId,
  refs: {
    gridRef: string
    portalRefs: string[]
    npcRefs: string[]
    gameNodeRefs: string[]
  },
): TrinityFloorBinding {
  return Object.freeze({
    floorId,
    realmId,
    gridRef: refs.gridRef,
    portalRefs: Object.freeze([...refs.portalRefs]) as string[],
    npcRefs: Object.freeze([...refs.npcRefs]) as string[],
    gameNodeRefs: Object.freeze([...refs.gameNodeRefs]) as string[],
  })
}
