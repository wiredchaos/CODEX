/**
 * AKIRA CODEX TIMELINE CONSUMER
 * Read-only access to Akira Codex timelines
 *
 * Timeline access is GOVERNED by Akira Codex.
 * This module can observe but never modify timeline data.
 */

import type { AkiraTimelineBinding, MountSession, MountEvent, TimelineAccessLevel } from "./types"

// ============================================
// TIMELINE REFERENCE RESOLVER (READ-ONLY)
// ============================================

export class AkiraTimelineConsumer {
  private readonly binding: AkiraTimelineBinding
  private readonly session: MountSession

  constructor(binding: AkiraTimelineBinding, session: MountSession) {
    this.binding = binding
    this.session = session

    // Validate access level
    if (binding.accessLevel === "NARRATOR") {
      throw new Error("MOUNT_VIOLATION: Consumer cannot have NARRATOR access")
    }
  }

  // ─────────────────────────────────────────
  // TIMELINE ACCESS (READ-ONLY)
  // ─────────────────────────────────────────

  getTimelineId(): string {
    this.emitEvent("TIMELINE_ACCESSED", { timelineId: this.binding.timelineId })
    return this.binding.timelineId
  }

  getStoryId(): string {
    return this.binding.storyId
  }

  getAccessLevel(): TimelineAccessLevel {
    return this.binding.accessLevel
  }

  // ─────────────────────────────────────────
  // ERA FILTERING
  // ─────────────────────────────────────────

  getVisibleEras(): readonly string[] | null {
    if (!this.binding.eraFilter) return null
    return Object.freeze([...this.binding.eraFilter])
  }

  isEraVisible(era: string): boolean {
    if (!this.binding.eraFilter) return true
    return this.binding.eraFilter.includes(era)
  }

  // ─────────────────────────────────────────
  // EVENT REFERENCES (READ-ONLY)
  // ─────────────────────────────────────────

  getEventRefs(): readonly string[] {
    return Object.freeze([...this.binding.eventRefs])
  }

  observeEvent(eventRef: string): { exists: boolean; ref: string } {
    const exists = this.binding.eventRefs.includes(eventRef)
    if (exists) {
      this.emitEvent("EVENT_OBSERVED", { eventRef })
    }
    return { exists, ref: eventRef }
  }

  // ─────────────────────────────────────────
  // CONTRIBUTOR SUGGESTIONS (IF PERMITTED)
  // ─────────────────────────────────────────

  canSuggestEvents(): boolean {
    return this.binding.accessLevel === "CONTRIBUTOR"
  }

  /**
   * Suggest an event to the timeline (requires approval)
   * This does NOT modify the timeline - only emits a suggestion event
   */
  suggestEvent(suggestion: {
    title: string
    description: string
    era?: string
  }): { submitted: boolean; reason?: string } {
    if (!this.canSuggestEvents()) {
      return {
        submitted: false,
        reason: "Access level does not permit suggestions",
      }
    }

    // Emit suggestion event - Akira Codex must approve
    this.emitEvent("EVENT_OBSERVED", {
      type: "SUGGESTION",
      suggestion: Object.freeze(suggestion),
      requiresApproval: true,
    })

    return { submitted: true }
  }

  // ─────────────────────────────────────────
  // EVENT EMISSION (NO MODIFICATION)
  // ─────────────────────────────────────────

  private emitEvent(type: MountEvent["type"], data: Record<string, unknown>): MountEvent {
    const event: MountEvent = {
      type,
      sessionId: this.session.sessionId,
      mountPointId: this.binding.timelineId,
      timestamp: new Date(),
      data: Object.freeze(data),
    }

    return event
  }
}

// ============================================
// TIMELINE BINDING FACTORY
// ============================================

export function createTimelineBinding(
  timelineId: string,
  storyId: string,
  eventRefs: string[],
  accessLevel: TimelineAccessLevel = "OBSERVER",
  eraFilter?: string[],
): AkiraTimelineBinding {
  // Prevent NARRATOR access from external mounts
  const safeAccessLevel = accessLevel === "NARRATOR" ? "CONTRIBUTOR" : accessLevel

  return Object.freeze({
    timelineId,
    storyId,
    eraFilter: eraFilter ? (Object.freeze([...eraFilter]) as string[]) : undefined,
    eventRefs: Object.freeze([...eventRefs]) as string[],
    accessLevel: safeAccessLevel,
  })
}
