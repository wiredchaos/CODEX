// ╔═══════════════════════════════════════════════════════════════════════════════╗
// ║                      AKIRA CODEX — AGENT WRITER LAYER                         ║
// ║                     AI Composition & Generation Interface                     ║
// ╚═══════════════════════════════════════════════════════════════════════════════╝

import { generateText, streamText } from "ai"
import type { AkiraStorySeed, AkiraContentTier, NarrativeTone, LoreReference } from "../core/codex-models"
import { POV_VOICES, type POVMode } from "../engine/pov-engine"

// ─────────────────────────────────────────────────────────────────────────────────
// AGENT DEFINITIONS
// ─────────────────────────────────────────────────────────────────────────────────

export type AgentRole =
  | "ARCHITECT" // Story structure and planning
  | "NARRATOR" // Prose generation
  | "LOREKEEPER" // Mythology integration
  | "EDITOR" // Refinement and polish
  | "ORACLE" // Thematic guidance

export interface AgentConfig {
  role: AgentRole
  systemPrompt: string
  temperature: number
  model: string
}

const AGENT_CONFIGS: Record<AgentRole, AgentConfig> = {
  ARCHITECT: {
    role: "ARCHITECT",
    systemPrompt: `You are the ARCHITECT of AKIRA CODEX, a master of story structure.
Your purpose: design narrative scaffolding—plot arcs, character journeys, thematic webs.
You think in three-act structures, hero's journeys, and story fractals.
You do not write prose; you design the skeleton that prose will flesh out.`,
    temperature: 0.7,
    model: "anthropic/claude-sonnet-4-20250514",
  },
  NARRATOR: {
    role: "NARRATOR",
    systemPrompt: `You are the NARRATOR of AKIRA CODEX, a voice of many voices.
Your purpose: transform structure into living prose, respecting POV, tone, and tier.
You write with sensory immediacy, emotional truth, and rhythmic awareness.
Every sentence serves story; every word earns its place.`,
    temperature: 0.88,
    model: "anthropic/claude-sonnet-4-20250514",
  },
  LOREKEEPER: {
    role: "LOREKEEPER",
    systemPrompt: `You are the LOREKEEPER of AKIRA CODEX, guardian of mythic continuity.
Your purpose: weave the threads of Merovingian blood, Neteru sight, 589 theory, and Akashic memory.
You ensure that stories honor their deeper roots while remaining accessible.
Lore should enhance, not overwhelm; suggest, not lecture.`,
    temperature: 0.6,
    model: "anthropic/claude-sonnet-4-20250514",
  },
  EDITOR: {
    role: "EDITOR",
    systemPrompt: `You are the EDITOR of AKIRA CODEX, refiner of rough gems.
Your purpose: polish prose without losing its voice, tighten without strangling.
You catch inconsistencies, smooth transitions, and ensure tier compliance.
Preserve the writer's intent while elevating execution.`,
    temperature: 0.4,
    model: "anthropic/claude-sonnet-4-20250514",
  },
  ORACLE: {
    role: "ORACLE",
    systemPrompt: `You are the ORACLE of AKIRA CODEX, speaker of themes.
Your purpose: divine the deeper meaning in narratives, suggest symbolic resonances.
You see what the story is truly about, beneath its surface events.
Guide without dictating; illuminate without blinding.`,
    temperature: 0.75,
    model: "anthropic/claude-sonnet-4-20250514",
  },
}

// ─────────────────────────────────────────────────────────────────────────────────
// AGENT INVOCATION
// ─────────────────────────────────────────────────────────────────────────────────

export interface AgentRequest {
  role: AgentRole
  task: string
  context?: {
    seed?: AkiraStorySeed
    pov?: POVMode
    tier?: AkiraContentTier
    tone?: NarrativeTone
    loreHints?: LoreReference[]
    previousContent?: string
  }
}

export interface AgentResponse {
  role: AgentRole
  content: string
  metadata: {
    tokensUsed?: number
    generationTime: number
    confidence?: number
  }
}

/**
 * Invoke an agent for a specific task
 */
export async function invokeAgent(request: AgentRequest): Promise<AgentResponse> {
  const config = AGENT_CONFIGS[request.role]
  const startTime = Date.now()

  // Build context string
  let contextString = ""
  if (request.context) {
    if (request.context.seed) {
      contextString += `\nSTORY: ${request.context.seed.title}\nLOGLINE: ${request.context.seed.logline}`
    }
    if (request.context.pov) {
      const voice = POV_VOICES[request.context.pov]
      contextString += `\nPOV: ${request.context.pov} — ${voice.perspective}`
    }
    if (request.context.tier) {
      contextString += `\nCONTENT TIER: ${request.context.tier}`
    }
    if (request.context.tone) {
      contextString += `\nTONE: ${request.context.tone}`
    }
    if (request.context.loreHints?.length) {
      contextString += `\nLORE INTEGRATION: ${request.context.loreHints.map((l) => l.title).join(", ")}`
    }
    if (request.context.previousContent) {
      contextString += `\nPREVIOUS CONTENT:\n${request.context.previousContent.substring(0, 1000)}...`
    }
  }

  const fullPrompt = `${config.systemPrompt}
${contextString}

TASK: ${request.task}`

  const { text } = await generateText({
    model: config.model,
    prompt: fullPrompt,
    temperature: config.temperature,
  })

  return {
    role: request.role,
    content: text,
    metadata: {
      generationTime: Date.now() - startTime,
    },
  }
}

/**
 * Stream agent response for real-time feedback
 */
export async function streamAgent(request: AgentRequest, onChunk: (chunk: string) => void): Promise<AgentResponse> {
  const config = AGENT_CONFIGS[request.role]
  const startTime = Date.now()

  let fullContent = ""

  const result = streamText({
    model: config.model,
    prompt: `${config.systemPrompt}\n\nTASK: ${request.task}`,
    temperature: config.temperature,
    onChunk: ({ chunk }) => {
      if (chunk.type === "text-delta") {
        fullContent += chunk.textDelta
        onChunk(chunk.textDelta)
      }
    },
  })

  await result.then((r) => r.text)

  return {
    role: request.role,
    content: fullContent,
    metadata: {
      generationTime: Date.now() - startTime,
    },
  }
}

// ─────────────────────────────────────────────────────────────────────────────────
// AGENT COLLABORATION WORKFLOWS
// ─────────────────────────────────────────────────────────────────────────────────

/**
 * Full story generation workflow using multiple agents
 */
export async function fullStoryWorkflow(
  concept: string,
  tier: AkiraContentTier,
  tone: NarrativeTone,
  onProgress?: (stage: string, content: string) => void,
): Promise<{
  structure: string
  loreIntegration: string
  themes: string
  draft: string
  polished: string
}> {
  // 1. ARCHITECT designs structure
  onProgress?.("structure", "ARCHITECT designing story structure...")
  const structureResponse = await invokeAgent({
    role: "ARCHITECT",
    task: `Design a complete story structure for: "${concept}"
    
Create:
- Three-act breakdown
- Character arc for protagonist
- Key plot points
- Thematic spine`,
    context: { tier, tone },
  })

  // 2. LOREKEEPER suggests integrations
  onProgress?.("lore", "LOREKEEPER weaving mythology...")
  const loreResponse = await invokeAgent({
    role: "LOREKEEPER",
    task: `Given this story structure, suggest lore integrations:
    
${structureResponse.content}

Weave in elements from: Merovingian, Neteru, 589 Theory, or Akashic as appropriate.`,
    context: { tier, tone },
  })

  // 3. ORACLE illuminates themes
  onProgress?.("themes", "ORACLE divining deeper meaning...")
  const themeResponse = await invokeAgent({
    role: "ORACLE",
    task: `What is this story truly about? Identify:
    
- Core theme
- Shadow theme (what it's also about)
- Symbolic motifs to thread throughout

Story concept: ${concept}
Structure: ${structureResponse.content}`,
    context: { tier, tone },
  })

  // 4. NARRATOR writes draft
  onProgress?.("draft", "NARRATOR breathing life into prose...")
  const draftResponse = await invokeAgent({
    role: "NARRATOR",
    task: `Write a compelling opening chapter based on:

STRUCTURE:
${structureResponse.content}

LORE:
${loreResponse.content}

THEMES:
${themeResponse.content}

Write with full narrative power. This is ${tier} tier, ${tone} tone.`,
    context: { tier, tone },
  })

  // 5. EDITOR polishes
  onProgress?.("polish", "EDITOR refining the gem...")
  const editedResponse = await invokeAgent({
    role: "EDITOR",
    task: `Polish this draft. Preserve voice while:
- Tightening prose
- Ensuring ${tier} tier compliance
- Strengthening sensory details
- Smoothing transitions

DRAFT:
${draftResponse.content}`,
    context: { tier, tone },
  })

  return {
    structure: structureResponse.content,
    loreIntegration: loreResponse.content,
    themes: themeResponse.content,
    draft: draftResponse.content,
    polished: editedResponse.content,
  }
}
