// ╔═══════════════════════════════════════════════════════════════════════════════╗
// ║                        AKIRA CODEX — TYPE DEFINITIONS                         ║
// ║                    Isolated Schema Layer for Narrative OS                     ║
// ╚═══════════════════════════════════════════════════════════════════════════════╝

import { generateCodexId } from "./codex-registry"

// ─────────────────────────────────────────────────────────────────────────────────
// CONTENT TIER SYSTEM (AKIRA CODEX NATIVE)
// ─────────────────────────────────────────────────────────────────────────────────

/**
 * Akira Codex content tiers — independent from any external system
 */
export type AkiraContentTier =
  | "LIGHT" // All ages, adventure-focused
  | "SHADOW" // Mature themes, fade-to-black
  | "VEIL" // 21+ symbolic/metaphorical only

/**
 * Narrative tone classifications
 */
export type NarrativeTone =
  | "MYTHIC" // Epic, legendary
  | "INTIMATE" // Personal, emotional
  | "NOIR" // Dark, cynical
  | "HOPEFUL" // Optimistic undercurrent
  | "CHAOTIC" // Unpredictable, wild
  | "SACRED" // Spiritual, reverent

/**
 * Story arc patterns
 */
export type ArcPattern =
  | "HERO_JOURNEY"
  | "TRAGEDY"
  | "REDEMPTION"
  | "MYSTERY"
  | "TRANSFORMATION"
  | "CYCLE"
  | "DESCENT"
  | "ASCENSION"

// ─────────────────────────────────────────────────────────────────────────────────
// STORY ENTITIES
// ─────────────────────────────────────────────────────────────────────────────────

/**
 * Story seed — the kernel from which a narrative grows
 */
export interface AkiraStorySeed {
  id: string
  title: string
  logline: string
  tier: AkiraContentTier
  tone: NarrativeTone
  arc: ArcPattern

  // Core elements
  protagonist: CharacterSeed
  antagonist: CharacterSeed
  setting: SettingSeed

  // Lore integration
  loreHooks: LoreReference[]

  // Generation metadata
  targetChapters: number
  targetWordCount: number
  createdAt: Date
}

/**
 * Character seed for story generation
 */
export interface CharacterSeed {
  name: string
  archetype: string
  motivation: string
  flaw: string
  loreConnection?: LoreReference
}

/**
 * Setting seed
 */
export interface SettingSeed {
  name: string
  description: string
  era: string
  atmosphere: string
  loreConnection?: LoreReference
}

/**
 * Chapter structure
 */
export interface AkiraChapter {
  id: string
  storyId: string
  number: number
  title: string
  content: string
  wordCount: number
  pov: "AKIRA" | "NETERU" | "OMNISCIENT"
  summary: string
  keyMoments: string[]
  emotionalBeat: string
  generatedAt: Date
}

/**
 * Complete story/novella
 */
export interface AkiraStory {
  id: string
  seed: AkiraStorySeed
  chapters: AkiraChapter[]
  totalWords: number
  status: "SEED" | "DRAFTING" | "COMPLETE" | "ARCHIVED"
  createdAt: Date
  updatedAt: Date
}

// ─────────────────────────────────────────────────────────────────────────────────
// MISSION SYSTEM
// ─────────────────────────────────────────────────────────────────────────────────

/**
 * Mission types for the Mission Board
 */
export type MissionType =
  | "MAIN_QUEST" // Critical story progression
  | "SIDE_QUEST" // Optional enrichment
  | "LORE_FRAGMENT" // World-building discovery
  | "CHARACTER_ARC" // Character development
  | "MYSTERY" // Investigation/revelation

/**
 * Mission status
 */
export type MissionStatus = "LOCKED" | "AVAILABLE" | "ACTIVE" | "COMPLETE" | "FAILED"

/**
 * Mission definition
 */
export interface AkiraMission {
  id: string
  storyId: string
  type: MissionType
  title: string
  briefing: string
  objectives: MissionObjective[]
  rewards: string[]
  prerequisites: string[]
  status: MissionStatus
  order: number
  createdAt: Date
}

/**
 * Individual objective within a mission
 */
export interface MissionObjective {
  id: string
  description: string
  complete: boolean
  optional: boolean
}

// ─────────────────────────────────────────────────────────────────────────────────
// NARRATIVE GRAPH
// ─────────────────────────────────────────────────────────────────────────────────

/**
 * Node types in the narrative graph
 */
export type GraphNodeType =
  | "STORY_BEAT"
  | "CHARACTER"
  | "LOCATION"
  | "EVENT"
  | "LORE_ENTRY"
  | "BRANCH_POINT"
  | "REVELATION"

/**
 * Graph node
 */
export interface NarrativeNode {
  id: string
  type: GraphNodeType
  label: string
  description: string
  position: { x: number; y: number }
  connections: string[]
  metadata: Record<string, unknown>
}

/**
 * Edge/connection between nodes
 */
export interface NarrativeEdge {
  id: string
  sourceId: string
  targetId: string
  label: string
  type: "CAUSES" | "LEADS_TO" | "REFERENCES" | "CONTRADICTS" | "PARALLELS"
}

/**
 * Complete narrative graph
 */
export interface NarrativeGraph {
  id: string
  storyId: string
  nodes: NarrativeNode[]
  edges: NarrativeEdge[]
  updatedAt: Date
}

// ─────────────────────────────────────────────────────────────────────────────────
// TIMELINE SYSTEM
// ─────────────────────────────────────────────────────────────────────────────────

/**
 * Timeline event
 */
export interface TimelineEvent {
  id: string
  storyId: string
  title: string
  description: string
  era: string
  relativeOrder: number
  chapterId?: string
  loreReference?: LoreReference
  characters: string[]
  significance: "MINOR" | "MODERATE" | "MAJOR" | "PIVOTAL"
}

/**
 * Complete timeline
 */
export interface AkiraTimeline {
  id: string
  storyId: string
  events: TimelineEvent[]
  eras: string[]
  createdAt: Date
}

// ─────────────────────────────────────────────────────────────────────────────────
// LORE INTEGRATION
// ─────────────────────────────────────────────────────────────────────────────────

/**
 * Lore categories specific to Akira Codex mythology
 */
export type LoreCategory =
  | "MEROVINGIAN" // Bloodline mysteries
  | "NETERU" // Ancient watchers
  | "589_THEORY" // Numerical prophecy
  | "AKASHIC" // Memory records
  | "CHAOS_ORIGIN" // Primordial forces
  | "VEIL" // Hidden realms

/**
 * Reference to lore entry
 */
export interface LoreReference {
  id: string
  category: LoreCategory
  title: string
  significance: string
}

/**
 * Full lore entry
 */
export interface LoreEntry {
  id: string
  category: LoreCategory
  title: string
  content: string
  connections: LoreReference[]
  storyAppearances: string[]
  createdAt: Date
}

// ─────────────────────────────────────────────────────────────────────────────────
// FACTORY FUNCTIONS
// ─────────────────────────────────────────────────────────────────────────────────

export function createStorySeed(params: Partial<AkiraStorySeed>): AkiraStorySeed {
  return {
    id: generateCodexId("SEED"),
    title: params.title || "Untitled",
    logline: params.logline || "",
    tier: params.tier || "SHADOW",
    tone: params.tone || "MYTHIC",
    arc: params.arc || "HERO_JOURNEY",
    protagonist: params.protagonist || {
      name: "Unknown",
      archetype: "Seeker",
      motivation: "Truth",
      flaw: "Doubt",
    },
    antagonist: params.antagonist || {
      name: "Unknown",
      archetype: "Shadow",
      motivation: "Control",
      flaw: "Fear",
    },
    setting: params.setting || {
      name: "Unknown Realm",
      description: "",
      era: "Present",
      atmosphere: "Mysterious",
    },
    loreHooks: params.loreHooks || [],
    targetChapters: params.targetChapters || 5,
    targetWordCount: params.targetWordCount || 15000,
    createdAt: new Date(),
  }
}

export function createMission(params: Partial<AkiraMission>): AkiraMission {
  return {
    id: generateCodexId("MISSION"),
    storyId: params.storyId || "",
    type: params.type || "MAIN_QUEST",
    title: params.title || "Unnamed Mission",
    briefing: params.briefing || "",
    objectives: params.objectives || [],
    rewards: params.rewards || [],
    prerequisites: params.prerequisites || [],
    status: params.status || "LOCKED",
    order: params.order || 0,
    createdAt: new Date(),
  }
}

export function createTimelineEvent(params: Partial<TimelineEvent>): TimelineEvent {
  return {
    id: generateCodexId("EVENT"),
    storyId: params.storyId || "",
    title: params.title || "",
    description: params.description || "",
    era: params.era || "Present",
    relativeOrder: params.relativeOrder || 0,
    chapterId: params.chapterId,
    loreReference: params.loreReference,
    characters: params.characters || [],
    significance: params.significance || "MINOR",
  }
}
