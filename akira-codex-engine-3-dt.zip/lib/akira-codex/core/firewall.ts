// ╔═══════════════════════════════════════════════════════════════════════════════╗
// ║                         AKIRA CODEX — FIREWALL                                ║
// ║              Namespace Isolation & External System Protection                 ║
// ╚═══════════════════════════════════════════════════════════════════════════════╝

import type { PatchRequest } from "./codex-registry"

/**
 * AKIRA CODEX SYSTEM IDENTITY
 * Immutable constants defining the Codex as an independent OS
 */
export const AKIRA_CODEX_IDENTITY = {
  SYSTEM_NAME: "AKIRA_CODEX",
  VERSION: "2.0.0",
  BUILD: "NARRATIVE_OS",
  ISOLATION_LEVEL: "FULL",
  CREATED: "2025-06-12",

  BLOCKED_NAMESPACES: ["CHAOS_OS", "WIRED_CHAOS_META", "NPC_ENGINE", "789_STUDIOS"],

  WHITELISTED_CONSUMERS: {
    CREATOR_CODEX: {
      allowedOperations: ["READ"] as const,
      canSubmitCandidates: true,
      canModifyCanon: false,
    },
    TRINITY_CORE: {
      allowedOperations: ["READ"] as const,
      canSubmitCandidates: false,
      canModifyCanon: false,
    },
  },

  // External communication only via PATCH
  COMMUNICATION_PROTOCOL: "PATCH_REQUEST_ONLY",
} as const

/**
 * Firewall violation record
 */
export interface FirewallViolation {
  id: string
  timestamp: Date
  sourceSystem: string
  attemptedOperation: string
  blocked: boolean
  reason: string
}

/**
 * Firewall state
 */
export interface FirewallState {
  active: boolean
  violations: FirewallViolation[]
  allowedPatches: string[]
  lastCheck: Date
}

/**
 * Initialize firewall state
 */
export function initializeFirewall(): FirewallState {
  return {
    active: true,
    violations: [],
    allowedPatches: [],
    lastCheck: new Date(),
  }
}

/**
 * Check if a source system is blocked
 */
export function isBlocked(sourceSystem: string): boolean {
  const normalized = sourceSystem.toUpperCase().replace(/[^A-Z0-9]/g, "")

  return AKIRA_CODEX_IDENTITY.BLOCKED_NAMESPACES.some((blocked) => {
    const normalizedBlocked = blocked.replace(/_/g, "")
    return normalized.includes(normalizedBlocked)
  })
}

/**
 * Validate an incoming request against the firewall
 */
export function validateRequest(
  firewall: FirewallState,
  request: PatchRequest,
): { allowed: boolean; violation?: FirewallViolation } {
  if (!firewall.active) {
    return { allowed: true }
  }

  firewall.lastCheck = new Date()

  const whitelist = AKIRA_CODEX_IDENTITY.WHITELISTED_CONSUMERS as Record<
    string,
    { allowedOperations: readonly string[]; canSubmitCandidates: boolean; canModifyCanon: boolean }
  >
  const normalizedSource = request.sourceSystem.toUpperCase().replace(/[^A-Z0-9]/g, "")

  for (const [consumer, permissions] of Object.entries(whitelist)) {
    if (normalizedSource.includes(consumer.replace(/_/g, ""))) {
      // Whitelisted consumer - check operation permissions
      if (!permissions.allowedOperations.includes(request.operation)) {
        const violation: FirewallViolation = {
          id: `VIOLATION_${Date.now()}`,
          timestamp: new Date(),
          sourceSystem: request.sourceSystem,
          attemptedOperation: request.operation,
          blocked: true,
          reason: `OPERATION_DENIED: ${consumer} is only allowed ${permissions.allowedOperations.join(", ")} operations`,
        }
        firewall.violations.push(violation)
        return { allowed: false, violation }
      }

      // Operation is allowed for this whitelisted consumer
      return { allowed: true }
    }
  }

  if (isBlocked(request.sourceSystem)) {
    const violation: FirewallViolation = {
      id: `VIOLATION_${Date.now()}`,
      timestamp: new Date(),
      sourceSystem: request.sourceSystem,
      attemptedOperation: request.operation,
      blocked: true,
      reason: `NAMESPACE_BLOCKED: ${request.sourceSystem} is in the blocked list`,
    }

    firewall.violations.push(violation)

    return { allowed: false, violation }
  }

  // Check signature (simplified for now)
  if (!request.signature || request.signature.length < 8) {
    const violation: FirewallViolation = {
      id: `VIOLATION_${Date.now()}`,
      timestamp: new Date(),
      sourceSystem: request.sourceSystem,
      attemptedOperation: request.operation,
      blocked: true,
      reason: "INVALID_SIGNATURE: Request signature missing or invalid",
    }

    firewall.violations.push(violation)

    return { allowed: false, violation }
  }

  return { allowed: true }
}

/**
 * Create a valid patch request signature
 */
export function createPatchSignature(sourceSystem: string, operation: string, payload: unknown): string {
  const data = JSON.stringify({ sourceSystem, operation, payload, ts: Date.now() })
  // Simple hash for demo — in production use crypto
  let hash = 0
  for (let i = 0; i < data.length; i++) {
    const char = data.charCodeAt(i)
    hash = (hash << 5) - hash + char
    hash = hash & hash
  }
  return `AKIRA_SIG_${Math.abs(hash).toString(36).toUpperCase()}`
}

/**
 * Create a properly formatted patch request
 */
export function createPatchRequest(
  sourceSystem: string,
  targetModule: PatchRequest["targetModule"],
  operation: PatchRequest["operation"],
  payload: unknown,
): PatchRequest {
  return {
    id: `PATCH_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    sourceSystem,
    targetModule,
    operation,
    payload,
    timestamp: new Date(),
    signature: createPatchSignature(sourceSystem, operation, payload),
  }
}

/**
 * Generate firewall status report
 */
export function getFirewallReport(firewall: FirewallState): {
  status: "SECURE" | "BREACHED" | "INACTIVE"
  totalViolations: number
  recentViolations: FirewallViolation[]
  blockedSystems: string[]
} {
  if (!firewall.active) {
    return {
      status: "INACTIVE",
      totalViolations: firewall.violations.length,
      recentViolations: [],
      blockedSystems: [...AKIRA_CODEX_IDENTITY.BLOCKED_NAMESPACES],
    }
  }

  const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000)
  const recentViolations = firewall.violations.filter((v) => v.timestamp > oneHourAgo)

  return {
    status: recentViolations.length > 5 ? "BREACHED" : "SECURE",
    totalViolations: firewall.violations.length,
    recentViolations: recentViolations.slice(-10),
    blockedSystems: [...AKIRA_CODEX_IDENTITY.BLOCKED_NAMESPACES],
  }
}
