// ╔═══════════════════════════════════════════════════════════════════════════════╗
// ║                           AKIRA CODEX — REGISTRY                              ║
// ║                     Standalone Narrative OS Identity Layer                    ║
// ║━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━║
// ║  ISOLATION PROTOCOL: This module is FIREWALLED from all external systems.    ║
// ║  No imports from: CHAOS OS, WIRED CHAOS META, NPC Engine, 789 Studios        ║
// ╚═══════════════════════════════════════════════════════════════════════════════╝

/**
 * AKIRA CODEX SYSTEM IDENTITY
 * Immutable constants defining the Codex as an independent OS
 */
export const AKIRA_CODEX_IDENTITY = {
  SYSTEM_NAME: "AKIRA_CODEX",
  VERSION: "2.0.0",
  BUILD: "NARRATIVE_OS",
  ISOLATION_LEVEL: "FULL",
  CREATED: "2025-06-12",

  // Firewall declarations
  BLOCKED_NAMESPACES: ["CHAOS_OS", "WIRED_CHAOS_META", "NPC_ENGINE", "CREATOR_CODEX", "789_STUDIOS"],

  // External communication only via PATCH
  COMMUNICATION_PROTOCOL: "PATCH_REQUEST_ONLY",
} as const

/**
 * Codex Operating Modes
 */
export type CodexMode =
  | "STORY_ENGINE" // Active story generation
  | "MISSION_BOARD" // Quest/mission management
  | "NARRATIVE_GRAPH" // Story node visualization
  | "TIMELINE" // Chronological view
  | "POV_SWITCH" // Akira vs Neteru perspective
  | "LORE_BROWSER" // Mythology exploration
  | "AGENT_WRITER" // AI composition layer

/**
 * System status for the Codex
 */
export type CodexStatus = "INITIALIZING" | "ACTIVE" | "GENERATING" | "IDLE" | "ERROR" | "LOCKED"

/**
 * Patch request structure for external system communication
 * This is the ONLY way external systems can interact with Akira Codex
 */
export interface PatchRequest {
  id: string
  sourceSystem: string
  targetModule: CodexMode
  operation: "READ" | "WRITE" | "EXECUTE"
  payload: unknown
  timestamp: Date
  signature: string
}

/**
 * Patch response from Akira Codex
 */
export interface PatchResponse {
  requestId: string
  status: "APPROVED" | "DENIED" | "PARTIAL"
  data?: unknown
  error?: string
  timestamp: Date
}

/**
 * Registry state for the entire Codex system
 */
export interface CodexRegistryState {
  systemId: string
  mode: CodexMode
  status: CodexStatus
  activePOV: "AKIRA" | "NETERU"
  currentStoryId: string | null
  currentMissionId: string | null
  loreContext: string[]
  sessionStart: Date
  lastActivity: Date
  patchLog: PatchRequest[]
}

/**
 * Generate unique Codex-namespaced ID
 */
export function generateCodexId(prefix: string): string {
  const timestamp = Date.now().toString(36)
  const random = Math.random().toString(36).substring(2, 8)
  return `AKIRAX_${prefix}_${timestamp}_${random}`.toUpperCase()
}

/**
 * Validate that a namespace is not blocked
 */
export function validateNamespace(namespace: string): boolean {
  const blocked = AKIRA_CODEX_IDENTITY.BLOCKED_NAMESPACES
  return !blocked.some((blocked) => namespace.toUpperCase().includes(blocked.replace(/_/g, "")))
}

/**
 * Create initial registry state
 */
export function createRegistryState(): CodexRegistryState {
  return {
    systemId: generateCodexId("REGISTRY"),
    mode: "STORY_ENGINE",
    status: "INITIALIZING",
    activePOV: "AKIRA",
    currentStoryId: null,
    currentMissionId: null,
    loreContext: [],
    sessionStart: new Date(),
    lastActivity: new Date(),
    patchLog: [],
  }
}

/**
 * Process incoming patch request with firewall validation
 */
export function processPatchRequest(state: CodexRegistryState, request: PatchRequest): PatchResponse {
  // Firewall check
  if (!validateNamespace(request.sourceSystem)) {
    return {
      requestId: request.id,
      status: "DENIED",
      error: `FIREWALL_BLOCK: ${request.sourceSystem} is not authorized to access AKIRA_CODEX`,
      timestamp: new Date(),
    }
  }

  // Log the patch request
  state.patchLog.push(request)
  state.lastActivity = new Date()

  // Process based on operation type
  switch (request.operation) {
    case "READ":
      return {
        requestId: request.id,
        status: "APPROVED",
        data: { mode: state.mode, status: state.status },
        timestamp: new Date(),
      }
    case "WRITE":
    case "EXECUTE":
      return {
        requestId: request.id,
        status: "PARTIAL",
        error: "WRITE/EXECUTE operations require elevated permissions",
        timestamp: new Date(),
      }
    default:
      return {
        requestId: request.id,
        status: "DENIED",
        error: "Unknown operation type",
        timestamp: new Date(),
      }
  }
}
