// ╔═══════════════════════════════════════════════════════════════════════════════╗
// ║                       AKIRA CODEX — LORE DATABASE                             ║
// ║              Merovingian, Neteru, 589 Theory, Akashic Records                 ║
// ╚═══════════════════════════════════════════════════════════════════════════════╝

import type { LoreEntry, LoreCategory, LoreReference } from "../core/codex-models"
import { generateCodexId } from "../core/codex-registry"

// ─────────────────────────────────────────────────────────────────────────────────
// CORE LORE ENTRIES
// ─────────────────────────────────────────────────────────────────────────────────

export const CORE_LORE: LoreEntry[] = [
  // MEROVINGIAN
  {
    id: generateCodexId("LORE"),
    category: "MEROVINGIAN",
    title: "The Bloodline of Kings",
    content: `The Merovingian lineage traces through shadow and light, a thread of royal 
blood that carries memories older than written history. They say the first Merovingian 
was born from a union between the mortal and the divine—a child of two worlds, 
belonging fully to neither. The bloodline carries gifts: prescience in dreams, 
an affinity for symbols, and the burden of remembering what others forget.`,
    connections: [],
    storyAppearances: [],
    createdAt: new Date(),
  },
  {
    id: generateCodexId("LORE"),
    category: "MEROVINGIAN",
    title: "The Hidden Crown",
    content: `Not all crowns are worn upon the head. The Merovingian inheritance is a 
crown of consciousness—an awakening that comes unbidden, often in times of crisis. 
Those who bear it speak of a moment when the world suddenly reveals its deeper 
architecture: the patterns beneath patterns, the stories beneath stories.`,
    connections: [],
    storyAppearances: [],
    createdAt: new Date(),
  },

  // NETERU
  {
    id: generateCodexId("LORE"),
    category: "NETERU",
    title: "The Watchers",
    content: `Before humanity named the stars, the Neteru watched. They are not gods 
in the way mortals imagine—they do not demand worship or sacrifice. They are 
witnesses, archivists of existence itself. Some say they seeded consciousness 
across the cosmos; others believe they simply observe the unfolding of a story 
they themselves do not fully understand.`,
    connections: [],
    storyAppearances: [],
    createdAt: new Date(),
  },
  {
    id: generateCodexId("LORE"),
    category: "NETERU",
    title: "The Language of Light",
    content: `The Neteru communicate in frequencies beyond human hearing, in colors 
beyond human sight. Yet occasionally, they reach across the veil—through dreams, 
through synchronicities, through moments of inexplicable knowing. Those touched 
by Neteru contact often report seeing geometric patterns, hearing tones that 
seem to carry meaning, feeling an ancient presence at the edge of perception.`,
    connections: [],
    storyAppearances: [],
    createdAt: new Date(),
  },

  // 589 THEORY
  {
    id: generateCodexId("LORE"),
    category: "589_THEORY",
    title: "The Sacred Sequence",
    content: `5-8-9. Three numbers that appear again and again at the hinges of history. 
The 589 Theory posits that these numbers mark moments of convergence—points where 
multiple timelines brush against each other, where choices ripple backward and 
forward simultaneously. Some call it numerology; others call it the universe's 
heartbeat made visible.`,
    connections: [],
    storyAppearances: [],
    createdAt: new Date(),
  },
  {
    id: generateCodexId("LORE"),
    category: "589_THEORY",
    title: "Temporal Signatures",
    content: `Those attuned to the 589 frequency begin to notice: addresses, timestamps, 
page numbers, random sequences—all carrying the signature. It is not that the 
numbers are placed deliberately, but that attention itself bends toward them. 
The theory suggests that consciousness and mathematics share a common root, 
and 589 is where they intersect.`,
    connections: [],
    storyAppearances: [],
    createdAt: new Date(),
  },

  // AKASHIC
  {
    id: generateCodexId("LORE"),
    category: "AKASHIC",
    title: "The Memory Field",
    content: `The Akashic Record is not a library in any physical sense. It is a field—
a resonance that preserves every thought, every action, every moment that has 
ever occurred. Some mystics access it through meditation; others stumble into 
it during near-death experiences. What they report is consistent: a feeling of 
returning home to a place they've never been.`,
    connections: [],
    storyAppearances: [],
    createdAt: new Date(),
  },
  {
    id: generateCodexId("LORE"),
    category: "AKASHIC",
    title: "Past-Life Echoes",
    content: `The Akashic field explains why some memories feel borrowed—why certain 
places feel familiar on first visit, why certain people feel known before 
introduction. These are not fantasies but leakages from the Record, moments 
when the boundary between past and present thins. The truly awakened can 
navigate these echoes deliberately.`,
    connections: [],
    storyAppearances: [],
    createdAt: new Date(),
  },

  // CHAOS ORIGIN
  {
    id: generateCodexId("LORE"),
    category: "CHAOS_ORIGIN",
    title: "Before the First Light",
    content: `Chaos is not disorder—it is potential unmanifest. Before creation, there 
was only Chaos: infinite possibility without form. The first act of creation 
was not building, but limiting—drawing boundaries in the boundless, creating 
space for something to exist rather than everything-and-nothing at once.`,
    connections: [],
    storyAppearances: [],
    createdAt: new Date(),
  },
  {
    id: generateCodexId("LORE"),
    category: "CHAOS_ORIGIN",
    title: "The Return",
    content: `Every ending is a return to Chaos—not destruction, but reunification with 
potential. This is why death is not feared by those who understand: it is 
simply the story releasing its current form to become all stories again. 
The Codex teaches that Chaos is the mother, and all narratives are her children.`,
    connections: [],
    storyAppearances: [],
    createdAt: new Date(),
  },

  // VEIL
  {
    id: generateCodexId("LORE"),
    category: "VEIL",
    title: "The Thin Places",
    content: `The Veil is not uniform—there are places where it wears thin, where 
the hidden realm bleeds through. Ancient temples, crossroads, mountain peaks, 
the hour before dawn. In these thin places, perception shifts: shadows move 
differently, time flows strangely, and the impossible becomes merely unlikely.`,
    connections: [],
    storyAppearances: [],
    createdAt: new Date(),
  },
  {
    id: generateCodexId("LORE"),
    category: "VEIL",
    title: "Veil-Walkers",
    content: `Some are born with the ability to part the Veil at will—Veil-Walkers, 
they are called. They move between the seen and unseen, gathering knowledge 
from both. But the gift comes with a price: the longer one walks between 
worlds, the harder it becomes to remember which is home.`,
    connections: [],
    storyAppearances: [],
    createdAt: new Date(),
  },
]

// ─────────────────────────────────────────────────────────────────────────────────
// LORE DATABASE OPERATIONS
// ─────────────────────────────────────────────────────────────────────────────────

export interface LoreDatabase {
  entries: LoreEntry[]
  lastUpdated: Date
}

/**
 * Initialize lore database with core entries
 */
export function initializeLoreDatabase(): LoreDatabase {
  return {
    entries: [...CORE_LORE],
    lastUpdated: new Date(),
  }
}

/**
 * Get all entries for a category
 */
export function getLoreByCategory(db: LoreDatabase, category: LoreCategory): LoreEntry[] {
  return db.entries.filter((e) => e.category === category)
}

/**
 * Search lore by keyword
 */
export function searchLore(db: LoreDatabase, query: string): LoreEntry[] {
  const q = query.toLowerCase()
  return db.entries.filter((e) => e.title.toLowerCase().includes(q) || e.content.toLowerCase().includes(q))
}

/**
 * Get lore reference for story integration
 */
export function getLoreReference(db: LoreDatabase, entryId: string): LoreReference | null {
  const entry = db.entries.find((e) => e.id === entryId)
  if (!entry) return null

  return {
    id: entry.id,
    category: entry.category,
    title: entry.title,
    significance: entry.content.substring(0, 100) + "...",
  }
}

/**
 * Get random lore hooks for story generation
 */
export function getRandomLoreHooks(db: LoreDatabase, count = 2): LoreReference[] {
  const shuffled = [...db.entries].sort(() => Math.random() - 0.5)
  return shuffled.slice(0, count).map((e) => ({
    id: e.id,
    category: e.category,
    title: e.title,
    significance: e.content.substring(0, 100) + "...",
  }))
}

/**
 * Add custom lore entry
 */
export function addLoreEntry(db: LoreDatabase, entry: Omit<LoreEntry, "id" | "createdAt">): LoreDatabase {
  const newEntry: LoreEntry = {
    ...entry,
    id: generateCodexId("LORE"),
    createdAt: new Date(),
  }

  return {
    entries: [...db.entries, newEntry],
    lastUpdated: new Date(),
  }
}

/**
 * Link lore entry to a story
 */
export function linkLoreToStory(db: LoreDatabase, entryId: string, storyId: string): LoreDatabase {
  return {
    ...db,
    entries: db.entries.map((e) =>
      e.id === entryId ? { ...e, storyAppearances: [...e.storyAppearances, storyId] } : e,
    ),
    lastUpdated: new Date(),
  }
}
