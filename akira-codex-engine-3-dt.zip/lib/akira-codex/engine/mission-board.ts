// ╔═══════════════════════════════════════════════════════════════════════════════╗
// ║                      AKIRA CODEX — MISSION BOARD                              ║
// ║                    Quest Management & Story Progression                       ║
// ╚═══════════════════════════════════════════════════════════════════════════════╝

import { type AkiraMission, type MissionStatus, type AkiraStory, createMission } from "../core/codex-models"
import { generateCodexId } from "../core/codex-registry"

// ─────────────────────────────────────────────────────────────────────────────────
// MISSION BOARD STATE
// ─────────────────────────────────────────────────────────────────────────────────

export interface MissionBoardState {
  storyId: string
  missions: AkiraMission[]
  activeMissionId: string | null
  completedCount: number
  totalCount: number
}

/**
 * Initialize mission board for a story
 */
export function createMissionBoard(storyId: string): MissionBoardState {
  return {
    storyId,
    missions: [],
    activeMissionId: null,
    completedCount: 0,
    totalCount: 0,
  }
}

// ─────────────────────────────────────────────────────────────────────────────────
// MISSION GENERATION
// ─────────────────────────────────────────────────────────────────────────────────

/**
 * Generate missions from a story structure
 */
export function generateMissionsFromStory(story: AkiraStory): AkiraMission[] {
  const missions: AkiraMission[] = []

  // Main quest for overall story
  missions.push(
    createMission({
      storyId: story.id,
      type: "MAIN_QUEST",
      title: `Complete: ${story.seed.title}`,
      briefing: story.seed.logline,
      objectives: story.chapters.map((ch, i) => ({
        id: generateCodexId("OBJ"),
        description: `Read Chapter ${i + 1}: ${ch.title}`,
        complete: false,
        optional: false,
      })),
      rewards: ["Story Completion", "Lore Unlocked"],
      status: "AVAILABLE",
      order: 0,
    }),
  )

  // Character arc missions
  missions.push(
    createMission({
      storyId: story.id,
      type: "CHARACTER_ARC",
      title: `Understand: ${story.seed.protagonist.name}`,
      briefing: `Follow the journey of ${story.seed.protagonist.name}, the ${story.seed.protagonist.archetype}. Motivation: ${story.seed.protagonist.motivation}`,
      objectives: [
        {
          id: generateCodexId("OBJ"),
          description: "Discover the protagonist's origin",
          complete: false,
          optional: false,
        },
        {
          id: generateCodexId("OBJ"),
          description: "Witness the defining choice",
          complete: false,
          optional: false,
        },
        {
          id: generateCodexId("OBJ"),
          description: "Understand the fatal flaw",
          complete: false,
          optional: true,
        },
      ],
      rewards: ["Character Insight", `${story.seed.protagonist.archetype} Archetype Unlocked`],
      status: "LOCKED",
      prerequisites: [missions[0].id],
      order: 1,
    }),
  )

  // Lore fragment missions
  story.seed.loreHooks.forEach((hook, i) => {
    missions.push(
      createMission({
        storyId: story.id,
        type: "LORE_FRAGMENT",
        title: `Lore: ${hook.title}`,
        briefing: `Explore the ${hook.category} connection: ${hook.significance}`,
        objectives: [
          {
            id: generateCodexId("OBJ"),
            description: `Uncover the ${hook.category} reference`,
            complete: false,
            optional: false,
          },
        ],
        rewards: [`${hook.category} Lore Entry`],
        status: "LOCKED",
        order: 10 + i,
      }),
    )
  })

  return missions
}

// ─────────────────────────────────────────────────────────────────────────────────
// MISSION OPERATIONS
// ─────────────────────────────────────────────────────────────────────────────────

/**
 * Start a mission
 */
export function startMission(board: MissionBoardState, missionId: string): MissionBoardState {
  const mission = board.missions.find((m) => m.id === missionId)
  if (!mission) return board

  if (mission.status !== "AVAILABLE") return board

  return {
    ...board,
    activeMissionId: missionId,
    missions: board.missions.map((m) => (m.id === missionId ? { ...m, status: "ACTIVE" as MissionStatus } : m)),
  }
}

/**
 * Complete an objective
 */
export function completeObjective(board: MissionBoardState, missionId: string, objectiveId: string): MissionBoardState {
  const updatedMissions = board.missions.map((mission) => {
    if (mission.id !== missionId) return mission

    const updatedObjectives = mission.objectives.map((obj) =>
      obj.id === objectiveId ? { ...obj, complete: true } : obj,
    )

    // Check if all required objectives are complete
    const allRequiredComplete = updatedObjectives.filter((obj) => !obj.optional).every((obj) => obj.complete)

    return {
      ...mission,
      objectives: updatedObjectives,
      status: allRequiredComplete ? ("COMPLETE" as MissionStatus) : mission.status,
    }
  })

  // Unlock missions whose prerequisites are now met
  const completedIds = updatedMissions.filter((m) => m.status === "COMPLETE").map((m) => m.id)

  const finalMissions = updatedMissions.map((mission) => {
    if (mission.status !== "LOCKED") return mission

    const prereqsMet = mission.prerequisites.every((id) => completedIds.includes(id))
    return prereqsMet ? { ...mission, status: "AVAILABLE" as MissionStatus } : mission
  })

  return {
    ...board,
    missions: finalMissions,
    completedCount: finalMissions.filter((m) => m.status === "COMPLETE").length,
    totalCount: finalMissions.length,
  }
}

/**
 * Get available missions
 */
export function getAvailableMissions(board: MissionBoardState): AkiraMission[] {
  return board.missions.filter((m) => m.status === "AVAILABLE")
}

/**
 * Get mission progress percentage
 */
export function getMissionProgress(board: MissionBoardState): number {
  if (board.totalCount === 0) return 0
  return Math.round((board.completedCount / board.totalCount) * 100)
}
