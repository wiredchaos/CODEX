// ╔═══════════════════════════════════════════════════════════════════════════════╗
// ║                     AKIRA CODEX — NARRATIVE GRAPH                             ║
// ║                   Story Node Visualization & Connections                      ║
// ╚═══════════════════════════════════════════════════════════════════════════════╝

import type { NarrativeGraph, NarrativeNode, NarrativeEdge, GraphNodeType, AkiraStory } from "../core/codex-models"
import { generateCodexId } from "../core/codex-registry"

// ─────────────────────────────────────────────────────────────────────────────────
// GRAPH CONSTRUCTION
// ─────────────────────────────────────────────────────────────────────────────────

/**
 * Create an empty narrative graph
 */
export function createNarrativeGraph(storyId: string): NarrativeGraph {
  return {
    id: generateCodexId("GRAPH"),
    storyId,
    nodes: [],
    edges: [],
    updatedAt: new Date(),
  }
}

/**
 * Add a node to the graph
 */
export function addNode(
  graph: NarrativeGraph,
  type: GraphNodeType,
  label: string,
  description: string,
  position: { x: number; y: number },
  metadata?: Record<string, unknown>,
): NarrativeGraph {
  const node: NarrativeNode = {
    id: generateCodexId("NODE"),
    type,
    label,
    description,
    position,
    connections: [],
    metadata: metadata || {},
  }

  return {
    ...graph,
    nodes: [...graph.nodes, node],
    updatedAt: new Date(),
  }
}

/**
 * Connect two nodes
 */
export function connectNodes(
  graph: NarrativeGraph,
  sourceId: string,
  targetId: string,
  label: string,
  type: NarrativeEdge["type"],
): NarrativeGraph {
  const edge: NarrativeEdge = {
    id: generateCodexId("EDGE"),
    sourceId,
    targetId,
    label,
    type,
  }

  // Update source node connections
  const updatedNodes = graph.nodes.map((node) =>
    node.id === sourceId ? { ...node, connections: [...node.connections, targetId] } : node,
  )

  return {
    ...graph,
    nodes: updatedNodes,
    edges: [...graph.edges, edge],
    updatedAt: new Date(),
  }
}

// ─────────────────────────────────────────────────────────────────────────────────
// GRAPH GENERATION FROM STORY
// ─────────────────────────────────────────────────────────────────────────────────

/**
 * Generate a narrative graph from a complete story
 */
export function generateGraphFromStory(story: AkiraStory): NarrativeGraph {
  let graph = createNarrativeGraph(story.id)

  const centerX = 400
  const centerY = 300
  const radius = 250

  // Add protagonist node at center
  graph = addNode(
    graph,
    "CHARACTER",
    story.seed.protagonist.name,
    `${story.seed.protagonist.archetype} — ${story.seed.protagonist.motivation}`,
    { x: centerX, y: centerY },
    { role: "protagonist", archetype: story.seed.protagonist.archetype },
  )
  const protagonistId = graph.nodes[graph.nodes.length - 1].id

  // Add antagonist node
  graph = addNode(
    graph,
    "CHARACTER",
    story.seed.antagonist.name,
    `${story.seed.antagonist.archetype} — ${story.seed.antagonist.motivation}`,
    { x: centerX + 200, y: centerY - 150 },
    { role: "antagonist", archetype: story.seed.antagonist.archetype },
  )
  const antagonistId = graph.nodes[graph.nodes.length - 1].id

  // Connect protagonist and antagonist
  graph = connectNodes(graph, protagonistId, antagonistId, "Opposes", "CONTRADICTS")

  // Add setting node
  graph = addNode(
    graph,
    "LOCATION",
    story.seed.setting.name,
    story.seed.setting.description,
    { x: centerX - 200, y: centerY - 100 },
    { era: story.seed.setting.era },
  )
  const settingId = graph.nodes[graph.nodes.length - 1].id

  // Add chapter nodes in a circle
  story.chapters.forEach((chapter, i) => {
    const angle = (i / story.chapters.length) * 2 * Math.PI - Math.PI / 2
    const x = centerX + Math.cos(angle) * radius
    const y = centerY + Math.sin(angle) * radius + 100

    graph = addNode(
      graph,
      "STORY_BEAT",
      chapter.title,
      chapter.summary,
      { x, y },
      { chapterId: chapter.id, number: chapter.number, pov: chapter.pov },
    )

    const chapterNodeId = graph.nodes[graph.nodes.length - 1].id

    // Connect chapters sequentially
    if (i > 0) {
      const prevChapterNode = graph.nodes.find(
        (n) => n.type === "STORY_BEAT" && (n.metadata as { number?: number }).number === i,
      )
      if (prevChapterNode) {
        graph = connectNodes(graph, prevChapterNode.id, chapterNodeId, "Leads to", "LEADS_TO")
      }
    }

    // Connect to setting
    graph = connectNodes(graph, chapterNodeId, settingId, "Set in", "REFERENCES")
  })

  // Add lore nodes
  story.seed.loreHooks.forEach((hook, i) => {
    const angle = (i / Math.max(story.seed.loreHooks.length, 1)) * Math.PI + Math.PI
    const x = centerX + Math.cos(angle) * (radius + 100)
    const y = centerY + Math.sin(angle) * (radius + 100)

    graph = addNode(
      graph,
      "LORE_ENTRY",
      hook.title,
      `${hook.category}: ${hook.significance}`,
      { x, y },
      { category: hook.category },
    )
  })

  return graph
}

// ─────────────────────────────────────────────────────────────────────────────────
// GRAPH QUERIES
// ─────────────────────────────────────────────────────────────────────────────────

/**
 * Get all nodes of a specific type
 */
export function getNodesByType(graph: NarrativeGraph, type: GraphNodeType): NarrativeNode[] {
  return graph.nodes.filter((n) => n.type === type)
}

/**
 * Get all edges connecting to/from a node
 */
export function getNodeEdges(graph: NarrativeGraph, nodeId: string): NarrativeEdge[] {
  return graph.edges.filter((e) => e.sourceId === nodeId || e.targetId === nodeId)
}

/**
 * Find path between two nodes
 */
export function findPath(graph: NarrativeGraph, startId: string, endId: string): NarrativeNode[] {
  const visited = new Set<string>()
  const queue: { nodeId: string; path: NarrativeNode[] }[] = []

  const startNode = graph.nodes.find((n) => n.id === startId)
  if (!startNode) return []

  queue.push({ nodeId: startId, path: [startNode] })

  while (queue.length > 0) {
    const current = queue.shift()!

    if (current.nodeId === endId) {
      return current.path
    }

    if (visited.has(current.nodeId)) continue
    visited.add(current.nodeId)

    const edges = getNodeEdges(graph, current.nodeId)
    for (const edge of edges) {
      const nextId = edge.sourceId === current.nodeId ? edge.targetId : edge.sourceId
      const nextNode = graph.nodes.find((n) => n.id === nextId)

      if (nextNode && !visited.has(nextId)) {
        queue.push({ nodeId: nextId, path: [...current.path, nextNode] })
      }
    }
  }

  return []
}
