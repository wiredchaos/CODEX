// ╔═══════════════════════════════════════════════════════════════════════════════╗
// ║                      AKIRA CODEX — TIMELINE VIEWER                            ║
// ║                    Chronological Event Visualization                          ║
// ╚═══════════════════════════════════════════════════════════════════════════════╝

import { type AkiraTimeline, type TimelineEvent, type AkiraStory, createTimelineEvent } from "../core/codex-models"
import { generateCodexId } from "../core/codex-registry"

// ─────────────────────────────────────────────────────────────────────────────────
// TIMELINE CONSTRUCTION
// ─────────────────────────────────────────────────────────────────────────────────

/**
 * Create an empty timeline
 */
export function createTimeline(storyId: string): AkiraTimeline {
  return {
    id: generateCodexId("TIMELINE"),
    storyId,
    events: [],
    eras: [],
    createdAt: new Date(),
  }
}

/**
 * Add an event to the timeline
 */
export function addTimelineEvent(timeline: AkiraTimeline, event: Partial<TimelineEvent>): AkiraTimeline {
  const newEvent = createTimelineEvent({
    ...event,
    storyId: timeline.storyId,
    relativeOrder: timeline.events.length,
  })

  const updatedEras = event.era && !timeline.eras.includes(event.era) ? [...timeline.eras, event.era] : timeline.eras

  return {
    ...timeline,
    events: [...timeline.events, newEvent],
    eras: updatedEras,
  }
}

// ─────────────────────────────────────────────────────────────────────────────────
// TIMELINE GENERATION FROM STORY
// ─────────────────────────────────────────────────────────────────────────────────

/**
 * Generate timeline from story chapters
 */
export function generateTimelineFromStory(story: AkiraStory): AkiraTimeline {
  let timeline = createTimeline(story.id)

  // Add story beginning event
  timeline = addTimelineEvent(timeline, {
    title: "Story Begins",
    description: story.seed.logline,
    era: story.seed.setting.era,
    significance: "PIVOTAL",
    characters: [story.seed.protagonist.name],
  })

  // Add chapter events
  story.chapters.forEach((chapter, i) => {
    timeline = addTimelineEvent(timeline, {
      title: chapter.title,
      description: chapter.summary,
      era: story.seed.setting.era,
      chapterId: chapter.id,
      significance: i === 0 || i === story.chapters.length - 1 ? "MAJOR" : "MODERATE",
      characters: [story.seed.protagonist.name],
    })
  })

  // Add lore-referenced events
  story.seed.loreHooks.forEach((hook) => {
    timeline = addTimelineEvent(timeline, {
      title: `${hook.category} Connection`,
      description: hook.significance,
      era: "Mythic Past",
      loreReference: hook,
      significance: "MINOR",
      characters: [],
    })
  })

  return timeline
}

// ─────────────────────────────────────────────────────────────────────────────────
// TIMELINE QUERIES
// ─────────────────────────────────────────────────────────────────────────────────

/**
 * Get events by era
 */
export function getEventsByEra(timeline: AkiraTimeline, era: string): TimelineEvent[] {
  return timeline.events.filter((e) => e.era === era)
}

/**
 * Get events by significance
 */
export function getEventsBySignificance(
  timeline: AkiraTimeline,
  significance: TimelineEvent["significance"],
): TimelineEvent[] {
  return timeline.events.filter((e) => e.significance === significance)
}

/**
 * Get events involving a character
 */
export function getEventsByCharacter(timeline: AkiraTimeline, characterName: string): TimelineEvent[] {
  return timeline.events.filter((e) => e.characters.some((c) => c.toLowerCase().includes(characterName.toLowerCase())))
}

/**
 * Get pivotal events (story turning points)
 */
export function getPivotalEvents(timeline: AkiraTimeline): TimelineEvent[] {
  return timeline.events.filter((e) => e.significance === "PIVOTAL" || e.significance === "MAJOR")
}

/**
 * Sort timeline chronologically
 */
export function sortTimeline(timeline: AkiraTimeline): AkiraTimeline {
  const sortedEvents = [...timeline.events].sort((a, b) => a.relativeOrder - b.relativeOrder)
  return { ...timeline, events: sortedEvents }
}
