// ╔═══════════════════════════════════════════════════════════════════════════════╗
// ║                      AKIRA CODEX — STORY ENGINE                               ║
// ║                Generate → Expand → Publish Pipeline                           ║
// ╚═══════════════════════════════════════════════════════════════════════════════╝

import { generateText } from "ai"
import {
  type AkiraStorySeed,
  type AkiraChapter,
  type AkiraStory,
  type AkiraContentTier,
  type NarrativeTone,
  type ArcPattern,
  createStorySeed,
} from "../core/codex-models"
import { generateCodexId } from "../core/codex-registry"

// ─────────────────────────────────────────────────────────────────────────────────
// TIER CONTENT RULES
// ─────────────────────────────────────────────────────────────────────────────────

const TIER_RULES: Record<AkiraContentTier, { rules: string[]; instructions: string }> = {
  LIGHT: {
    rules: [
      "All ages appropriate",
      "No violence beyond mild conflict",
      "No adult themes",
      "Focus on wonder, discovery, friendship",
    ],
    instructions: `Write for all ages. Emphasize wonder, adventure, and growth. 
Keep conflict mild and resolution-focused. No dark themes.`,
  },
  SHADOW: {
    rules: [
      "Mature themes permitted",
      "Violence can be intense but purposeful",
      "Fade-to-black for intimate scenes",
      "Complex morality allowed",
    ],
    instructions: `Mature storytelling allowed. Violence serves narrative purpose.
For intimate moments: fade to black. Cut away at the threshold.
Example: "Their eyes met with undeniable gravity... [scene break] Dawn light filtered through."`,
  },
  VEIL: {
    rules: [
      "21+ symbolic content only",
      "Metaphorical/poetic intimacy",
      "NO explicit anatomical detail",
      "Shadow-veil language required",
    ],
    instructions: `Use shadow-veil poetics for sensual content. 
Metaphors only: fire, water, breath, pulse, shadow, light.
NEVER explicit. Think: literary symbolism, not graphic description.
Example: "They became a single tide, shadow and flame intertwined, breath like distant thunder..."`,
  },
}

// ─────────────────────────────────────────────────────────────────────────────────
// PROMPT TEMPLATES
// ─────────────────────────────────────────────────────────────────────────────────

const SEED_GENERATION_PROMPT = `You are a master story architect for AKIRA CODEX, an isolated narrative engine.

Create a story seed from:
CONCEPT: {concept}
TIER: {tier}
TONE: {tone}
ARC PATTERN: {arc}

TIER RULES:
{tierRules}

LORE CONTEXT (integrate subtly if relevant):
- MEROVINGIAN: Bloodline mysteries, hidden royalty
- NETERU: Ancient watchers, celestial guardians
- 589 THEORY: Numerical prophecy, pattern recognition
- AKASHIC: Memory records, past-life echoes

Generate JSON:
{
  "title": "evocative title",
  "logline": "compelling 2-sentence hook",
  "protagonist": {
    "name": "meaningful name",
    "archetype": "core archetype",
    "motivation": "driving force",
    "flaw": "fatal flaw"
  },
  "antagonist": {
    "name": "meaningful name", 
    "archetype": "shadow archetype",
    "motivation": "opposing force",
    "flaw": "weakness"
  },
  "setting": {
    "name": "location name",
    "description": "vivid 2-3 sentences",
    "era": "time period",
    "atmosphere": "mood descriptor"
  },
  "loreHooks": [{"category": "LORE_TYPE", "title": "reference", "significance": "connection"}],
  "targetChapters": number,
  "targetWordCount": number
}`

const CHAPTER_GENERATION_PROMPT = `You are the narrative voice of AKIRA CODEX.

STORY: {title}
LOGLINE: {logline}
CHAPTER: {chapterNum} of {totalChapters}
POV: {pov}
TIER: {tier}
TONE: {tone}

PROTAGONIST: {protagonist}
ANTAGONIST: {antagonist}
SETTING: {setting}

PREVIOUS SUMMARY: {previousSummary}

TIER INSTRUCTIONS:
{tierInstructions}

Write Chapter {chapterNum}:
- Target: {targetWords} words
- Maintain {pov} perspective throughout
- Advance the {arc} arc pattern
- Weave in lore subtly: {loreHints}
- End with a hook for the next chapter

Begin with: "Chapter {chapterNum}: [Your Chapter Title]"`

// ─────────────────────────────────────────────────────────────────────────────────
// SEED GENERATION
// ─────────────────────────────────────────────────────────────────────────────────

export interface GenerateSeedInput {
  concept: string
  tier?: AkiraContentTier
  tone?: NarrativeTone
  arc?: ArcPattern
}

export async function generateSeed(input: GenerateSeedInput): Promise<AkiraStorySeed> {
  const tier = input.tier || "SHADOW"
  const tone = input.tone || "MYTHIC"
  const arc = input.arc || "HERO_JOURNEY"

  const prompt = SEED_GENERATION_PROMPT.replace("{concept}", input.concept)
    .replace("{tier}", tier)
    .replace("{tone}", tone)
    .replace("{arc}", arc)
    .replace("{tierRules}", TIER_RULES[tier].rules.join("\n- "))

  const { text } = await generateText({
    model: "anthropic/claude-sonnet-4-20250514",
    prompt,
    temperature: 0.85,
  })

  const jsonMatch = text.match(/\{[\s\S]*\}/)
  if (!jsonMatch) {
    throw new Error("AKIRA_CODEX: Failed to parse story seed")
  }

  const parsed = JSON.parse(jsonMatch[0])

  return createStorySeed({
    title: parsed.title,
    logline: parsed.logline,
    tier,
    tone,
    arc,
    protagonist: parsed.protagonist,
    antagonist: parsed.antagonist,
    setting: parsed.setting,
    loreHooks: parsed.loreHooks || [],
    targetChapters: parsed.targetChapters || 5,
    targetWordCount: parsed.targetWordCount || 15000,
  })
}

// ─────────────────────────────────────────────────────────────────────────────────
// CHAPTER GENERATION
// ─────────────────────────────────────────────────────────────────────────────────

export interface GenerateChapterInput {
  seed: AkiraStorySeed
  chapterNum: number
  pov: "AKIRA" | "NETERU" | "OMNISCIENT"
  previousSummary: string
}

export async function generateChapter(input: GenerateChapterInput): Promise<AkiraChapter> {
  const { seed, chapterNum, pov, previousSummary } = input
  const tierConfig = TIER_RULES[seed.tier]
  const targetWords = Math.floor(seed.targetWordCount / seed.targetChapters)

  const loreHints = seed.loreHooks.map((h) => `${h.category}: ${h.significance}`).join("; ")

  const prompt = CHAPTER_GENERATION_PROMPT.replace(/{title}/g, seed.title)
    .replace("{logline}", seed.logline)
    .replace(/{chapterNum}/g, String(chapterNum))
    .replace("{totalChapters}", String(seed.targetChapters))
    .replace(/{pov}/g, pov)
    .replace("{tier}", seed.tier)
    .replace("{tone}", seed.tone)
    .replace(
      "{protagonist}",
      `${seed.protagonist.name} (${seed.protagonist.archetype}) - ${seed.protagonist.motivation}`,
    )
    .replace("{antagonist}", `${seed.antagonist.name} (${seed.antagonist.archetype}) - ${seed.antagonist.motivation}`)
    .replace("{setting}", `${seed.setting.name}: ${seed.setting.description}`)
    .replace("{previousSummary}", previousSummary || "This is the opening chapter.")
    .replace("{tierInstructions}", tierConfig.instructions)
    .replace("{targetWords}", String(targetWords))
    .replace("{arc}", seed.arc)
    .replace("{loreHints}", loreHints || "None specified")

  const { text: content } = await generateText({
    model: "anthropic/claude-sonnet-4-20250514",
    prompt,
    temperature: 0.88,
    maxTokens: 4500,
  })

  // Extract title from first line
  const lines = content.split("\n")
  const titleMatch = lines[0].match(/Chapter\s*\d+[:\s]*(.+)/i)
  const chapterTitle = titleMatch ? titleMatch[1].trim() : `Chapter ${chapterNum}`

  // Generate summary for continuity
  const { text: summary } = await generateText({
    model: "anthropic/claude-sonnet-4-20250514",
    prompt: `Summarize this chapter in 2-3 sentences for story continuity:\n\n${content.substring(0, 3000)}`,
    temperature: 0.3,
    maxTokens: 200,
  })

  return {
    id: generateCodexId("CHAPTER"),
    storyId: "", // Set by caller
    number: chapterNum,
    title: chapterTitle,
    content,
    wordCount: content.split(/\s+/).length,
    pov,
    summary,
    keyMoments: [],
    emotionalBeat: seed.tone,
    generatedAt: new Date(),
  }
}

// ─────────────────────────────────────────────────────────────────────────────────
// FULL STORY EXPANSION
// ─────────────────────────────────────────────────────────────────────────────────

export interface ExpandStoryInput {
  seed: AkiraStorySeed
  povPattern?: ("AKIRA" | "NETERU" | "OMNISCIENT")[]
  onProgress?: (chapter: AkiraChapter, progress: number) => void
}

export async function expandToStory(input: ExpandStoryInput): Promise<AkiraStory> {
  const { seed, povPattern, onProgress } = input

  const storyId = generateCodexId("STORY")
  const chapters: AkiraChapter[] = []
  let previousSummary = ""
  let totalWords = 0

  // Default POV pattern alternates
  const defaultPattern: ("AKIRA" | "NETERU" | "OMNISCIENT")[] = Array(seed.targetChapters)
    .fill(0)
    .map((_, i) => (i % 3 === 0 ? "AKIRA" : i % 3 === 1 ? "NETERU" : "OMNISCIENT"))

  const pattern = povPattern || defaultPattern

  for (let i = 1; i <= seed.targetChapters; i++) {
    const pov = pattern[(i - 1) % pattern.length]

    const chapter = await generateChapter({
      seed,
      chapterNum: i,
      pov,
      previousSummary,
    })

    chapter.storyId = storyId
    chapters.push(chapter)
    previousSummary = chapter.summary
    totalWords += chapter.wordCount

    if (onProgress) {
      onProgress(chapter, i / seed.targetChapters)
    }
  }

  return {
    id: storyId,
    seed,
    chapters,
    totalWords,
    status: "COMPLETE",
    createdAt: new Date(),
    updatedAt: new Date(),
  }
}
