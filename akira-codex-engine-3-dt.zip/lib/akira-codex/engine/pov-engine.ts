// ╔═══════════════════════════════════════════════════════════════════════════════╗
// ║                        AKIRA CODEX — POV ENGINE                               ║
// ║                   Akira vs Neteru Perspective System                          ║
// ╚═══════════════════════════════════════════════════════════════════════════════╝

import type { AkiraStory, NarrativeTone } from "../core/codex-models"

// ─────────────────────────────────────────────────────────────────────────────────
// POV DEFINITIONS
// ─────────────────────────────────────────────────────────────────────────────────

export type POVMode = "AKIRA" | "NETERU" | "OMNISCIENT"

/**
 * POV voice characteristics
 */
export interface POVVoice {
  mode: POVMode
  pronouns: string[]
  perspective: string
  emotionalRange: string[]
  narrativeStyle: string
  symbolism: string[]
  blindSpots: string[]
}

/**
 * Defined POV voices for the two primary perspectives
 */
export const POV_VOICES: Record<POVMode, POVVoice> = {
  AKIRA: {
    mode: "AKIRA",
    pronouns: ["I", "me", "my"],
    perspective: "First-person intimate — close to the protagonist's thoughts and feelings",
    emotionalRange: ["doubt", "determination", "wonder", "fear", "hope", "confusion"],
    narrativeStyle: "Immediate, sensory, emotionally raw. Present-tense energy even in past tense.",
    symbolism: ["light breaking through", "paths forking", "echoes of memory", "fire and renewal"],
    blindSpots: [
      "Cannot see antagonist's true motives",
      "Limited by subjective experience",
      "Unreliable in moments of stress",
    ],
  },
  NETERU: {
    mode: "NETERU",
    pronouns: ["we", "one", "the Watcher"],
    perspective: "Ancient observer — sees patterns across time, speaks in mythic register",
    emotionalRange: ["ancient sorrow", "cosmic patience", "veiled concern", "knowing amusement"],
    narrativeStyle: "Distant but not cold. Mythic cadence. Sees what mortals miss.",
    symbolism: ["stars wheeling", "rivers of time", "threads of fate", "shadows of what was"],
    blindSpots: ["Cannot fully understand mortal urgency", "Bound by cosmic laws", "Knowledge is not always wisdom"],
  },
  OMNISCIENT: {
    mode: "OMNISCIENT",
    pronouns: ["he", "she", "they", "the"],
    perspective: "Third-person omniscient — moves between minds and moments",
    emotionalRange: ["detached clarity", "ironic awareness", "compassionate distance"],
    narrativeStyle: "Fluid, moving between characters. Can zoom in or pull back.",
    symbolism: ["the web connecting all", "mirrors reflecting mirrors", "the space between heartbeats"],
    blindSpots: ["May feel less intimate", "Risk of emotional distance"],
  },
}

// ─────────────────────────────────────────────────────────────────────────────────
// POV STATE
// ─────────────────────────────────────────────────────────────────────────────────

export interface POVState {
  currentMode: POVMode
  chapterPOVs: Map<string, POVMode>
  switchHistory: { timestamp: Date; from: POVMode; to: POVMode }[]
}

/**
 * Create initial POV state
 */
export function createPOVState(initialMode: POVMode = "AKIRA"): POVState {
  return {
    currentMode: initialMode,
    chapterPOVs: new Map(),
    switchHistory: [],
  }
}

/**
 * Switch POV mode
 */
export function switchPOV(state: POVState, newMode: POVMode): POVState {
  if (state.currentMode === newMode) return state

  return {
    ...state,
    currentMode: newMode,
    switchHistory: [...state.switchHistory, { timestamp: new Date(), from: state.currentMode, to: newMode }],
  }
}

/**
 * Assign POV to a chapter
 */
export function assignChapterPOV(state: POVState, chapterId: string, pov: POVMode): POVState {
  const newMap = new Map(state.chapterPOVs)
  newMap.set(chapterId, pov)
  return { ...state, chapterPOVs: newMap }
}

// ─────────────────────────────────────────────────────────────────────────────────
// POV ANALYSIS
// ─────────────────────────────────────────────────────────────────────────────────

/**
 * Get POV distribution for a story
 */
export function getPOVDistribution(story: AkiraStory): Record<POVMode, number> {
  const distribution: Record<POVMode, number> = {
    AKIRA: 0,
    NETERU: 0,
    OMNISCIENT: 0,
  }

  story.chapters.forEach((chapter) => {
    distribution[chapter.pov]++
  })

  return distribution
}

/**
 * Suggest optimal POV for a chapter based on content
 */
export function suggestPOV(
  chapterNumber: number,
  totalChapters: number,
  tone: NarrativeTone,
  isClimactic: boolean,
): POVMode {
  // Opening chapters benefit from intimate POV
  if (chapterNumber === 1) return "AKIRA"

  // Climactic moments often work better with omniscient
  if (isClimactic) return "OMNISCIENT"

  // Sacred/mythic tones pair well with Neteru
  if (tone === "SACRED" || tone === "MYTHIC") return "NETERU"

  // Intimate/romantic scenes work with Akira
  if (tone === "INTIMATE" || tone === "HOPEFUL") return "AKIRA"

  // Alternate for variety
  const patterns: POVMode[] = ["AKIRA", "NETERU", "OMNISCIENT"]
  return patterns[chapterNumber % 3]
}

/**
 * Generate POV transition text
 */
export function generatePOVTransition(from: POVMode, to: POVMode): string {
  const transitions: Record<string, string> = {
    AKIRA_NETERU: "The mortal's vision fades, and older eyes open to witness what was always there...",
    NETERU_AKIRA: "The cosmic view narrows to a single heartbeat, a single breath, a single now...",
    AKIRA_OMNISCIENT: "Step back from the singular I, and see the tapestry entire...",
    OMNISCIENT_AKIRA: "But what does it feel like from within? Let us enter...",
    NETERU_OMNISCIENT: "The Watcher's gaze softens, releasing its hold on eternity...",
    OMNISCIENT_NETERU: "And yet, there are those who have watched since the first light...",
  }

  return transitions[`${from}_${to}`] || "The perspective shifts..."
}
