// ╔═══════════════════════════════════════════════════════════════════════════════╗
// ║                       AKIRA CODEX — API ENDPOINTS                             ║
// ║                    Isolated API Layer — No External Bleed                     ║
// ╚═══════════════════════════════════════════════════════════════════════════════╝

import {
  AKIRA_CODEX_IDENTITY,
  type CodexRegistryState,
  type PatchRequest,
  type PatchResponse,
  processPatchRequest,
  createRegistryState,
} from "../core/codex-registry"
import { initializeFirewall, validateRequest, getFirewallReport } from "../core/firewall"
import type { AkiraStorySeed, AkiraStory } from "../core/codex-models"

// ─────────────────────────────────────────────────────────────────────────────────
// API RESPONSE TYPES
// ─────────────────────────────────────────────────────────────────────────────────

export interface CodexAPIResponse<T = unknown> {
  success: boolean
  data?: T
  error?: {
    code: string
    message: string
  }
  meta: {
    system: string
    version: string
    timestamp: Date
  }
}

function createResponse<T>(success: boolean, data?: T, error?: { code: string; message: string }): CodexAPIResponse<T> {
  return {
    success,
    data,
    error,
    meta: {
      system: AKIRA_CODEX_IDENTITY.SYSTEM_NAME,
      version: AKIRA_CODEX_IDENTITY.VERSION,
      timestamp: new Date(),
    },
  }
}

// ─────────────────────────────────────────────────────────────────────────────────
// CODEX API INSTANCE
// ─────────────────────────────────────────────────────────────────────────────────

/**
 * Singleton API instance for Akira Codex
 */
class AkiraCodexAPI {
  private state: CodexRegistryState
  private firewall = initializeFirewall()

  constructor() {
    this.state = createRegistryState()
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // SYSTEM ENDPOINTS
  // ─────────────────────────────────────────────────────────────────────────────

  /**
   * GET /akira-codex/status
   */
  getStatus(): CodexAPIResponse<{
    identity: typeof AKIRA_CODEX_IDENTITY
    state: Omit<CodexRegistryState, "patchLog">
    firewall: ReturnType<typeof getFirewallReport>
  }> {
    return createResponse(true, {
      identity: AKIRA_CODEX_IDENTITY,
      state: {
        systemId: this.state.systemId,
        mode: this.state.mode,
        status: this.state.status,
        activePOV: this.state.activePOV,
        currentStoryId: this.state.currentStoryId,
        currentMissionId: this.state.currentMissionId,
        loreContext: this.state.loreContext,
        sessionStart: this.state.sessionStart,
        lastActivity: this.state.lastActivity,
      },
      firewall: getFirewallReport(this.firewall),
    })
  }

  /**
   * POST /akira-codex/patch
   * External systems must use this endpoint to communicate
   */
  handlePatch(request: PatchRequest): CodexAPIResponse<PatchResponse> {
    // Validate against firewall
    const validation = validateRequest(this.firewall, request)

    if (!validation.allowed) {
      return createResponse(false, undefined, {
        code: "FIREWALL_BLOCK",
        message: validation.violation?.reason || "Request blocked by firewall",
      })
    }

    // Process the patch request
    const response = processPatchRequest(this.state, request)

    return createResponse(
      response.status !== "DENIED",
      response,
      response.status === "DENIED" ? { code: "PATCH_DENIED", message: response.error || "Unknown error" } : undefined,
    )
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // STORY ENDPOINTS
  // ─────────────────────────────────────────────────────────────────────────────

  /**
   * POST /akira-codex/story/create-seed
   */
  async createStorySeed(
    concept: string,
    tier: AkiraStorySeed["tier"],
    tone: AkiraStorySeed["tone"],
  ): Promise<CodexAPIResponse<AkiraStorySeed>> {
    this.state.status = "GENERATING"
    this.state.lastActivity = new Date()

    try {
      const { generateSeed } = await import("../engine/story-engine")
      const seed = await generateSeed({ concept, tier, tone })

      this.state.currentStoryId = seed.id
      this.state.status = "ACTIVE"

      return createResponse(true, seed)
    } catch (error) {
      this.state.status = "ERROR"
      return createResponse(false, undefined, {
        code: "GENERATION_ERROR",
        message: error instanceof Error ? error.message : "Unknown error",
      })
    }
  }

  /**
   * POST /akira-codex/story/expand
   */
  async expandStory(seed: AkiraStorySeed): Promise<CodexAPIResponse<AkiraStory>> {
    this.state.status = "GENERATING"
    this.state.lastActivity = new Date()

    try {
      const { expandToStory } = await import("../engine/story-engine")
      const story = await expandToStory({ seed })

      this.state.currentStoryId = story.id
      this.state.status = "ACTIVE"

      return createResponse(true, story)
    } catch (error) {
      this.state.status = "ERROR"
      return createResponse(false, undefined, {
        code: "EXPANSION_ERROR",
        message: error instanceof Error ? error.message : "Unknown error",
      })
    }
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // MODE SWITCHING
  // ─────────────────────────────────────────────────────────────────────────────

  /**
   * POST /akira-codex/mode
   */
  setMode(mode: CodexRegistryState["mode"]): CodexAPIResponse<{ mode: CodexRegistryState["mode"] }> {
    this.state.mode = mode
    this.state.lastActivity = new Date()
    return createResponse(true, { mode })
  }

  /**
   * POST /akira-codex/pov
   */
  setPOV(pov: "AKIRA" | "NETERU"): CodexAPIResponse<{ pov: "AKIRA" | "NETERU" }> {
    this.state.activePOV = pov
    this.state.lastActivity = new Date()
    return createResponse(true, { pov })
  }
}

// Export singleton
export const akiraCodexAPI = new AkiraCodexAPI()

// Export types for route handlers
export type { CodexAPIResponse }
