/**
 * TRINITY PATCH - NETERU APINAYA Manifest
 * Temple Grounds + Pantheon Trials
 */

import { createTrinityManifest, DEFAULT_REALMS, DEFAULT_GAMES, DEFAULT_NPCS } from "./trinity-manifest"
import type { TrinityPatchManifest, TrinityRealm } from "../core/trinity-types"

// Neteru-specific realm modifications
const NETERU_REALMS: TrinityRealm[] = DEFAULT_REALMS.map((realm) => {
  if (realm.id === "NEURALIS") {
    return {
      ...realm,
      label: "Temple of Thoth",
      description: "Sacred wisdom awaits",
    }
  }
  if (realm.id === "CHAOSPHERE") {
    return {
      ...realm,
      label: "Trials of Set",
      description: "Face the darkness",
    }
  }
  if (realm.id === "ECHO") {
    return {
      ...realm,
      label: "Akashic Records",
      description: "All knowledge preserved",
    }
  }
  return realm
})

export const NeteruApinayaManifest: TrinityPatchManifest = createTrinityManifest("NETERU_APINAYA", {
  realms: NETERU_REALMS,
  games: DEFAULT_GAMES,
  npcs: DEFAULT_NPCS,

  features: {
    promptLab: false,
    wlHooks: true, // Temple progression
    argHooks: true, // 589 sacred frequencies
    studentUnion: false,
    labyrinthTunnel: false,
    nsfwZones: false,
  },

  hostBindings: {
    identity: "HOST_API",
    economy: "XP", // Akashic XP
    loreMode: "NETERU_APINAYA",
  },
})
