/**
 * TRINITY PATCH - WIRED CHAOS META Manifest
 * Full feature set enabled
 */

import { createTrinityManifest, DEFAULT_REALMS, DEFAULT_GAMES, DEFAULT_NPCS } from "./trinity-manifest"
import type { TrinityPatchManifest } from "../core/trinity-types"

export const WiredChaosManifest: TrinityPatchManifest = createTrinityManifest("WIRED_CHAOS_META", {
  realms: DEFAULT_REALMS,
  games: DEFAULT_GAMES,
  npcs: DEFAULT_NPCS,

  features: {
    promptLab: true, // Gamified NPC prompt lab
    wlHooks: true, // Whitelist progression hooks
    argHooks: true, // 589 ARG integration
    studentUnion: true, // Student Union building
    labyrinthTunnel: true, // NPC Labyrinth direct tunnel
    nsfwZones: false, // No NSFW in main WC
  },

  hostBindings: {
    identity: "HOST_API",
    economy: "HYBRID", // XP + Token
    loreMode: "WIRED_CHAOS",
  },
})
