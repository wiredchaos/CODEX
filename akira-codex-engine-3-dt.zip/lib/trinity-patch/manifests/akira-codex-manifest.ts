/**
 * TRINITY PATCH - AKIRA CODEX Manifests
 * Safe and NSFW variants
 */

import { createTrinityManifest, DEFAULT_REALMS, DEFAULT_GAMES, DEFAULT_NPCS } from "./trinity-manifest"
import type { TrinityPatchManifest, TrinityRealm } from "../core/trinity-types"

// Akira-specific realm modifications
const AKIRA_REALMS: TrinityRealm[] = DEFAULT_REALMS.map((realm) => {
  if (realm.id === "NEURALIS") {
    return {
      ...realm,
      label: "Writing Studio",
      description: "Craft your narratives",
    }
  }
  if (realm.id === "CHAOSPHERE") {
    return {
      ...realm,
      label: "Drama Arena",
      description: "Conflict and tension",
    }
  }
  if (realm.id === "ECHO") {
    return {
      ...realm,
      label: "Archives",
      description: "Study the masters",
    }
  }
  return realm
})

export const AkiraCodexSafeManifest: TrinityPatchManifest = createTrinityManifest("AKIRA_CODEX_SAFE", {
  realms: AKIRA_REALMS,
  games: DEFAULT_GAMES.filter((g) => g.category !== "REACTION"), // No reaction games in writing mode
  npcs: DEFAULT_NPCS,

  features: {
    promptLab: true,
    wlHooks: false,
    argHooks: false,
    studentUnion: false,
    labyrinthTunnel: false,
    nsfwZones: false,
  },

  hostBindings: {
    identity: "HOST_API",
    economy: "XP",
    loreMode: "AKIRA_CODEX",
  },
})

export const AkiraCodexNsfwManifest: TrinityPatchManifest = createTrinityManifest("AKIRA_CODEX_NSFW", {
  realms: AKIRA_REALMS,
  games: DEFAULT_GAMES.filter((g) => g.category !== "REACTION"),
  npcs: DEFAULT_NPCS,

  features: {
    promptLab: true,
    wlHooks: false,
    argHooks: false,
    studentUnion: false,
    labyrinthTunnel: false,
    nsfwZones: true, // Red Veil zones enabled
  },

  hostBindings: {
    identity: "HOST_API",
    economy: "XP",
    loreMode: "AKIRA_CODEX_NSFW",
  },
})
