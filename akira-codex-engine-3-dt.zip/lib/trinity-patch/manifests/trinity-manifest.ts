/**
 * TRINITY PATCH - Base Manifest Configuration
 */

import type { TrinityPatchManifest, TrinityRealm, TrinityGame, TrinityNpc } from "../core/trinity-types"

// ============================================================
// DEFAULT REALMS
// ============================================================

export const DEFAULT_REALMS: TrinityRealm[] = [
  {
    id: "NEURALIS",
    label: "Neuralis",
    description: "Learning Nexus - Master the fundamentals",
    defaultTone: "NOOBIE",
    gridSize: { width: 32, height: 32 },
    spawnPoint: { x: 16, y: 16 },
    portals: [
      {
        id: "portal-chaosphere",
        position: { x: 30, y: 16 },
        targetRealmId: "CHAOSPHERE",
        targetPosition: { x: 2, y: 16 },
        label: "To Chaosphere",
      },
      {
        id: "portal-echo",
        position: { x: 16, y: 30 },
        targetRealmId: "ECHO",
        targetPosition: { x: 16, y: 2 },
        label: "To Echo",
      },
    ],
    buildings: [
      {
        id: "arcade-main",
        type: "ARCADE",
        position: { x: 10, y: 10 },
        size: { width: 4, height: 4 },
        label: "Main Arcade",
        interactable: true,
      },
      {
        id: "student-union",
        type: "STUDENT_UNION",
        position: { x: 20, y: 10 },
        size: { width: 5, height: 4 },
        label: "Student Union",
        interactable: true,
      },
      {
        id: "prompt-lab",
        type: "PROMPT_LAB",
        position: { x: 10, y: 20 },
        size: { width: 4, height: 4 },
        label: "Prompt Lab",
        interactable: true,
        npcIds: ["prompt-master"],
      },
    ],
  },
  {
    id: "CHAOSPHERE",
    label: "Chaosphere",
    description: "Chaos Operations - Test your limits",
    defaultTone: "GAMER",
    gridSize: { width: 32, height: 32 },
    spawnPoint: { x: 2, y: 16 },
    portals: [
      {
        id: "portal-neuralis",
        position: { x: 2, y: 16 },
        targetRealmId: "NEURALIS",
        targetPosition: { x: 30, y: 16 },
        label: "To Neuralis",
      },
      {
        id: "portal-labyrinth",
        position: { x: 16, y: 30 },
        targetRealmId: "LABYRINTH",
        targetPosition: { x: 0, y: 0 },
        label: "NPC Labyrinth",
        hookType: "LABYRINTH",
      },
      {
        id: "portal-589",
        position: { x: 30, y: 30 },
        targetRealmId: "ARG_589",
        targetPosition: { x: 0, y: 0 },
        label: "589 Portal",
        hookType: "589",
      },
    ],
    buildings: [
      {
        id: "arcade-chaos",
        type: "ARCADE",
        position: { x: 14, y: 14 },
        size: { width: 4, height: 4 },
        label: "Chaos Arcade",
        interactable: true,
      },
      {
        id: "labyrinth-entrance",
        type: "LABYRINTH_ENTRANCE",
        position: { x: 14, y: 26 },
        size: { width: 4, height: 4 },
        label: "Labyrinth Gate",
        interactable: true,
      },
    ],
  },
  {
    id: "ECHO",
    label: "Echo",
    description: "Observation Deck - Reflect and strategize",
    defaultTone: "CASUAL",
    gridSize: { width: 32, height: 32 },
    spawnPoint: { x: 16, y: 2 },
    portals: [
      {
        id: "portal-neuralis-back",
        position: { x: 16, y: 2 },
        targetRealmId: "NEURALIS",
        targetPosition: { x: 16, y: 30 },
        label: "To Neuralis",
      },
    ],
    buildings: [
      {
        id: "library",
        type: "LIBRARY",
        position: { x: 12, y: 12 },
        size: { width: 6, height: 6 },
        label: "Echo Library",
        interactable: true,
      },
      {
        id: "guild-hall",
        type: "GUILD",
        position: { x: 20, y: 12 },
        size: { width: 5, height: 5 },
        label: "Guild Hall",
        interactable: true,
      },
    ],
  },
]

// ============================================================
// DEFAULT GAMES
// ============================================================

export const DEFAULT_GAMES: TrinityGame[] = [
  {
    id: "redfang",
    label: "Red Fang Signal Tuner",
    description: "Tune into frequencies and decode hidden signals",
    realms: ["NEURALIS", "CHAOSPHERE"],
    difficulty: 2,
    category: "PUZZLE",
    xpReward: { base: 50, multiplier: 1.5 },
    wlProgressOnWin: 1,
  },
  {
    id: "589grid",
    label: "589 Akashic Merge Grid",
    description: "Merge symbols to unlock akashic knowledge",
    realms: ["NEURALIS", "ECHO"],
    difficulty: 3,
    category: "PUZZLE",
    xpReward: { base: 75, multiplier: 2.0 },
    wlProgressOnWin: 2,
  },
  {
    id: "echo",
    label: "Echo Detection Protocol",
    description: "Find patterns in the noise",
    realms: ["ECHO"],
    difficulty: 2,
    category: "MEMORY",
    xpReward: { base: 40, multiplier: 1.2 },
  },
  {
    id: "moloch",
    label: "Moloch Neutralization Ops",
    description: "Strategic defense against entropy",
    realms: ["CHAOSPHERE"],
    difficulty: 4,
    category: "STRATEGY",
    xpReward: { base: 100, multiplier: 2.5 },
    wlProgressOnWin: 3,
  },
  {
    id: "wraith",
    label: "Wraith Lords Descent",
    description: "Survive the endless descent",
    realms: ["CHAOSPHERE"],
    difficulty: 5,
    category: "REACTION",
    xpReward: { base: 150, multiplier: 3.0 },
    wlProgressOnWin: 5,
  },
  {
    id: "prompt-duel",
    label: "Prompt Duel",
    description: "Craft prompts faster and better than your opponent",
    realms: ["NEURALIS"],
    difficulty: 3,
    category: "TYPING",
    xpReward: { base: 60, multiplier: 1.8 },
  },
]

// ============================================================
// DEFAULT NPCS
// ============================================================

export const DEFAULT_NPCS: TrinityNpc[] = [
  {
    id: "guide-main",
    name: "Guide",
    role: "GUIDE",
    position: { x: 15, y: 15 },
    realmId: "NEURALIS",
    spriteUrl: "/sprites/default-guide.png",
    dialogueSetId: "guide-main-dialogue",
  },
  {
    id: "challenger-1",
    name: "Challenger",
    role: "CHALLENGER",
    position: { x: 14, y: 12 },
    realmId: "CHAOSPHERE",
    spriteUrl: "/sprites/default-challenger.png",
    dialogueSetId: "challenger-dialogue",
  },
  {
    id: "prompt-master",
    name: "Prompt Master",
    role: "PROMPT_MASTER",
    position: { x: 11, y: 21 },
    realmId: "NEURALIS",
    spriteUrl: "/sprites/default-prompt-master.png",
    dialogueSetId: "prompt-master-dialogue",
  },
  {
    id: "lore-keeper",
    name: "Lore Keeper",
    role: "LORE_KEEPER",
    position: { x: 14, y: 14 },
    realmId: "ECHO",
    spriteUrl: "/sprites/default-lore-keeper.png",
    dialogueSetId: "lore-keeper-dialogue",
  },
  {
    id: "labyrinth-keeper",
    name: "Labyrinth Keeper",
    role: "GUIDE",
    position: { x: 15, y: 27 },
    realmId: "CHAOSPHERE",
    spriteUrl: "/sprites/default-labyrinth-keeper.png",
    dialogueSetId: "labyrinth-dialogue",
  },
]

// ============================================================
// BASE MANIFEST
// ============================================================

export function createTrinityManifest(
  hostSystemName: string,
  options?: Partial<{
    realms: TrinityRealm[]
    games: TrinityGame[]
    npcs: TrinityNpc[]
    features: TrinityPatchManifest["features"]
    hostBindings: TrinityPatchManifest["hostBindings"]
  }>,
): TrinityPatchManifest {
  return {
    patchId: "TRINITY_ARCADE_OVERWORLD",
    version: "1.0.0",
    hostSystemName,

    realms: options?.realms || DEFAULT_REALMS,
    games: options?.games || DEFAULT_GAMES,
    npcs: options?.npcs || DEFAULT_NPCS,

    features: options?.features || {
      promptLab: true,
      wlHooks: true,
      argHooks: true,
      studentUnion: true,
      labyrinthTunnel: true,
      nsfwZones: false,
    },

    hostBindings: options?.hostBindings || {
      identity: "ANONYMOUS",
      economy: "XP",
      loreMode: "DEFAULT",
    },
  }
}
