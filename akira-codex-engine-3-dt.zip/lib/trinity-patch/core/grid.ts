/**
 * TRINITY PATCH - Isometric Grid Mathematics
 * Handles coordinate conversion and pathfinding
 */

import type { GridPosition, IsoPosition, TileConfig } from "./trinity-types"

// Isometric projection constants
const TILE_WIDTH = 64
const TILE_HEIGHT = 32
const TILE_DEPTH = 16

/**
 * Convert grid coordinates to isometric screen coordinates
 */
export function gridToIso(grid: GridPosition): IsoPosition {
  return {
    isoX: (grid.x - grid.y) * (TILE_WIDTH / 2),
    isoY: (grid.x + grid.y) * (TILE_HEIGHT / 2),
  }
}

/**
 * Convert isometric screen coordinates to grid coordinates
 */
export function isoToGrid(iso: IsoPosition): GridPosition {
  const x = Math.floor((iso.isoX / (TILE_WIDTH / 2) + iso.isoY / (TILE_HEIGHT / 2)) / 2)
  const y = Math.floor((iso.isoY / (TILE_HEIGHT / 2) - iso.isoX / (TILE_WIDTH / 2)) / 2)
  return { x, y }
}

/**
 * Get screen position for rendering (top-left corner of tile)
 */
export function getScreenPosition(
  grid: GridPosition,
  canvasWidth: number,
  canvasHeight: number,
): { screenX: number; screenY: number } {
  const iso = gridToIso(grid)
  return {
    screenX: iso.isoX + canvasWidth / 2,
    screenY: iso.isoY + canvasHeight / 4,
  }
}

/**
 * Get tile depth for z-ordering (render order)
 */
export function getTileDepth(grid: GridPosition, elevation = 0): number {
  return grid.x + grid.y + elevation * 0.1
}

/**
 * Calculate Manhattan distance between two grid positions
 */
export function getDistance(a: GridPosition, b: GridPosition): number {
  return Math.abs(a.x - b.x) + Math.abs(a.y - b.y)
}

/**
 * Get adjacent tiles (4-directional)
 */
export function getAdjacentTiles(pos: GridPosition): GridPosition[] {
  return [
    { x: pos.x - 1, y: pos.y },
    { x: pos.x + 1, y: pos.y },
    { x: pos.x, y: pos.y - 1 },
    { x: pos.x, y: pos.y + 1 },
  ]
}

/**
 * Get adjacent tiles (8-directional for diagonal movement)
 */
export function getAdjacentTiles8(pos: GridPosition): GridPosition[] {
  return [
    { x: pos.x - 1, y: pos.y },
    { x: pos.x + 1, y: pos.y },
    { x: pos.x, y: pos.y - 1 },
    { x: pos.x, y: pos.y + 1 },
    { x: pos.x - 1, y: pos.y - 1 },
    { x: pos.x + 1, y: pos.y - 1 },
    { x: pos.x - 1, y: pos.y + 1 },
    { x: pos.x + 1, y: pos.y + 1 },
  ]
}

/**
 * Check if position is within grid bounds
 */
export function isInBounds(pos: GridPosition, width: number, height: number): boolean {
  return pos.x >= 0 && pos.x < width && pos.y >= 0 && pos.y < height
}

/**
 * A* Pathfinding implementation
 */
export function findPath(
  start: GridPosition,
  end: GridPosition,
  tiles: TileConfig[],
  gridWidth: number,
  gridHeight: number,
): GridPosition[] {
  const tileMap = new Map<string, TileConfig>()
  tiles.forEach((t) => tileMap.set(`${t.position.x},${t.position.y}`, t))

  const isWalkable = (pos: GridPosition): boolean => {
    if (!isInBounds(pos, gridWidth, gridHeight)) return false
    const tile = tileMap.get(`${pos.x},${pos.y}`)
    return tile ? tile.walkable : true
  }

  const heuristic = (a: GridPosition, b: GridPosition): number => {
    return Math.abs(a.x - b.x) + Math.abs(a.y - b.y)
  }

  const openSet: GridPosition[] = [start]
  const cameFrom = new Map<string, GridPosition>()
  const gScore = new Map<string, number>()
  const fScore = new Map<string, number>()

  const key = (p: GridPosition) => `${p.x},${p.y}`

  gScore.set(key(start), 0)
  fScore.set(key(start), heuristic(start, end))

  while (openSet.length > 0) {
    // Get node with lowest fScore
    openSet.sort(
      (a, b) => (fScore.get(key(a)) || Number.POSITIVE_INFINITY) - (fScore.get(key(b)) || Number.POSITIVE_INFINITY),
    )
    const current = openSet.shift()!

    if (current.x === end.x && current.y === end.y) {
      // Reconstruct path
      const path: GridPosition[] = [current]
      let node = current
      while (cameFrom.has(key(node))) {
        node = cameFrom.get(key(node))!
        path.unshift(node)
      }
      return path
    }

    for (const neighbor of getAdjacentTiles(current)) {
      if (!isWalkable(neighbor)) continue

      const tentativeGScore = (gScore.get(key(current)) || Number.POSITIVE_INFINITY) + 1

      if (tentativeGScore < (gScore.get(key(neighbor)) || Number.POSITIVE_INFINITY)) {
        cameFrom.set(key(neighbor), current)
        gScore.set(key(neighbor), tentativeGScore)
        fScore.set(key(neighbor), tentativeGScore + heuristic(neighbor, end))

        if (!openSet.some((p) => p.x === neighbor.x && p.y === neighbor.y)) {
          openSet.push(neighbor)
        }
      }
    }
  }

  return [] // No path found
}

/**
 * Generate a basic grid of tiles
 */
export function generateBasicGrid(
  width: number,
  height: number,
  options?: {
    pathTiles?: GridPosition[]
    wallTiles?: GridPosition[]
    portalTiles?: GridPosition[]
  },
): TileConfig[] {
  const tiles: TileConfig[] = []
  const pathSet = new Set(options?.pathTiles?.map((p) => `${p.x},${p.y}`) || [])
  const wallSet = new Set(options?.wallTiles?.map((p) => `${p.x},${p.y}`) || [])
  const portalSet = new Set(options?.portalTiles?.map((p) => `${p.x},${p.y}`) || [])

  for (let x = 0; x < width; x++) {
    for (let y = 0; y < height; y++) {
      const key = `${x},${y}`
      let type: TileConfig["type"] = "FLOOR"
      let walkable = true

      if (wallSet.has(key)) {
        type = "WALL"
        walkable = false
      } else if (pathSet.has(key)) {
        type = "PATH"
      } else if (portalSet.has(key)) {
        type = "PORTAL"
      }

      tiles.push({
        id: `tile-${x}-${y}`,
        position: { x, y },
        type,
        walkable,
        elevation: 0,
      })
    }
  }

  return tiles
}

export const GRID_CONSTANTS = {
  TILE_WIDTH,
  TILE_HEIGHT,
  TILE_DEPTH,
}
