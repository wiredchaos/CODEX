/**
 * TRINITY PATCH - Agentic Adaptation Engine (AAE)
 * Dynamically adjusts difficulty, tone, and hints based on player behavior
 */

import type {
  AAEProfile,
  AAESessionRecord,
  AAEAdaptation,
  AAEDecision,
  DifficultyTier,
  ToneLevel,
} from "./trinity-types"

// ============================================================
// AAE CONFIGURATION
// ============================================================

const AAE_CONFIG = {
  // Thresholds for difficulty adjustment
  DIFFICULTY_UP_THRESHOLD: 0.85, // Win rate to increase difficulty
  DIFFICULTY_DOWN_THRESHOLD: 0.35, // Win rate to decrease difficulty

  // Frustration detection
  FRUSTRATION_QUIT_WEIGHT: 3, // Weight for early quits
  FRUSTRATION_MISTAKE_WEIGHT: 0.5, // Weight per mistake
  FRUSTRATION_THRESHOLD: 7, // Trigger help at this level

  // Tone shift triggers
  CONSECUTIVE_WINS_FOR_GAMER: 5,
  CONSECUTIVE_LOSSES_FOR_NOOBIE: 3,

  // Session analysis window
  RECENT_SESSION_COUNT: 10,

  // Break suggestion
  SESSION_COUNT_FOR_BREAK: 15,
  TIME_THRESHOLD_FOR_BREAK: 45 * 60 * 1000, // 45 minutes
}

// ============================================================
// AAE PROFILE MANAGEMENT
// ============================================================

export function createDefaultAAEProfile(userId: string): AAEProfile {
  return {
    userId,
    skillLevel: 50,
    preferredTone: "CASUAL",
    reactionTimeAvg: 1000,
    accuracyRate: 0.7,
    frustrationIndex: 0,
    sessionHistory: [],
    adaptations: [],
  }
}

export function updateProfileFromSession(profile: AAEProfile, session: AAESessionRecord): AAEProfile {
  const updatedHistory = [...profile.sessionHistory, session].slice(-50)
  const recentSessions = updatedHistory.slice(-AAE_CONFIG.RECENT_SESSION_COUNT)

  // Calculate new skill level
  const avgScore = recentSessions.reduce((sum, s) => sum + s.score, 0) / recentSessions.length
  const winRate = recentSessions.filter((s) => s.score >= 70).length / recentSessions.length
  const newSkillLevel = Math.min(100, Math.max(0, profile.skillLevel * 0.8 + avgScore * winRate * 0.2))

  // Update reaction time average
  const newReactionAvg = recentSessions.reduce((sum, s) => sum + s.completionTime, 0) / recentSessions.length

  // Update accuracy rate
  const totalMistakes = recentSessions.reduce((sum, s) => sum + s.mistakes, 0)
  const newAccuracy = Math.max(0.1, 1 - totalMistakes / (recentSessions.length * 10))

  // Calculate frustration index
  let frustration = 0
  recentSessions.forEach((s) => {
    if (s.didQuitEarly) frustration += AAE_CONFIG.FRUSTRATION_QUIT_WEIGHT
    frustration += s.mistakes * AAE_CONFIG.FRUSTRATION_MISTAKE_WEIGHT
    if (s.score < 30) frustration += 1
  })

  return {
    ...profile,
    skillLevel: newSkillLevel,
    reactionTimeAvg: newReactionAvg,
    accuracyRate: newAccuracy,
    frustrationIndex: frustration,
    sessionHistory: updatedHistory,
  }
}

// ============================================================
// AAE DECISION ENGINE
// ============================================================

export function makeAAEDecision(profile: AAEProfile): AAEDecision {
  const recentSessions = profile.sessionHistory.slice(-AAE_CONFIG.RECENT_SESSION_COUNT)

  if (recentSessions.length === 0) {
    return {
      recommendedDifficulty: 2,
      recommendedTone: "CASUAL",
      shouldOfferHint: false,
      shouldSuggestBreak: false,
      confidenceScore: 0.5,
      reasoning: "New player - starting with default settings",
    }
  }

  // Calculate win rate for difficulty adjustment
  const winRate = recentSessions.filter((s) => s.score >= 70).length / recentSessions.length

  // Determine recommended difficulty
  let recommendedDifficulty: DifficultyTier = 3
  let difficultyReason = ""

  if (winRate >= AAE_CONFIG.DIFFICULTY_UP_THRESHOLD && profile.skillLevel > 70) {
    recommendedDifficulty = Math.min(5, Math.ceil(profile.skillLevel / 20)) as DifficultyTier
    difficultyReason = "High win rate and skill level - increasing challenge"
  } else if (
    winRate <= AAE_CONFIG.DIFFICULTY_DOWN_THRESHOLD ||
    profile.frustrationIndex > AAE_CONFIG.FRUSTRATION_THRESHOLD
  ) {
    recommendedDifficulty = Math.max(1, Math.floor(profile.skillLevel / 25)) as DifficultyTier
    difficultyReason = "Struggling or frustrated - reducing difficulty"
  } else {
    recommendedDifficulty = (Math.round(profile.skillLevel / 20) as DifficultyTier) || 2
    difficultyReason = "Balanced performance - maintaining current level"
  }

  // Determine recommended tone
  let recommendedTone: ToneLevel = profile.preferredTone
  let toneReason = ""

  const consecutiveWins = countConsecutiveResults(recentSessions, true)
  const consecutiveLosses = countConsecutiveResults(recentSessions, false)

  if (consecutiveWins >= AAE_CONFIG.CONSECUTIVE_WINS_FOR_GAMER) {
    recommendedTone = "GAMER"
    toneReason = "On a winning streak - switching to competitive tone"
  } else if (consecutiveLosses >= AAE_CONFIG.CONSECUTIVE_LOSSES_FOR_NOOBIE) {
    recommendedTone = "NOOBIE"
    toneReason = "Experiencing difficulty - switching to supportive tone"
  }

  // Determine if hints should be offered
  const shouldOfferHint =
    profile.frustrationIndex > AAE_CONFIG.FRUSTRATION_THRESHOLD * 0.7 ||
    (recentSessions.length >= 3 && recentSessions.slice(-3).every((s) => s.score < 50))

  // Determine if break should be suggested
  const sessionCount = profile.sessionHistory.length
  const firstSessionTime = profile.sessionHistory[0]?.timestamp || Date.now()
  const playTime = Date.now() - firstSessionTime
  const shouldSuggestBreak =
    sessionCount >= AAE_CONFIG.SESSION_COUNT_FOR_BREAK || playTime >= AAE_CONFIG.TIME_THRESHOLD_FOR_BREAK

  // Calculate confidence score
  const confidenceScore = Math.min(1, recentSessions.length / AAE_CONFIG.RECENT_SESSION_COUNT)

  return {
    recommendedDifficulty,
    recommendedTone,
    shouldOfferHint,
    shouldSuggestBreak,
    confidenceScore,
    reasoning: [difficultyReason, toneReason].filter(Boolean).join(". ") || "Standard adaptation",
  }
}

function countConsecutiveResults(sessions: AAESessionRecord[], wins: boolean): number {
  let count = 0
  for (let i = sessions.length - 1; i >= 0; i--) {
    const isWin = sessions[i].score >= 70
    if (isWin === wins) {
      count++
    } else {
      break
    }
  }
  return count
}

// ============================================================
// AAE ADAPTATION RECORDING
// ============================================================

export function recordAdaptation(profile: AAEProfile, adaptation: Omit<AAEAdaptation, "triggeredAt">): AAEProfile {
  const newAdaptation: AAEAdaptation = {
    ...adaptation,
    triggeredAt: Date.now(),
  }

  return {
    ...profile,
    adaptations: [...profile.adaptations, newAdaptation].slice(-100),
  }
}

// ============================================================
// DIFFICULTY SCALING
// ============================================================

export interface DifficultyParams {
  timeLimit: number
  targetCount: number
  speedMultiplier: number
  hintAvailable: boolean
  mistakeTolerance: number
}

export function getDifficultyParams(tier: DifficultyTier): DifficultyParams {
  const params: Record<DifficultyTier, DifficultyParams> = {
    1: {
      timeLimit: 120,
      targetCount: 5,
      speedMultiplier: 0.6,
      hintAvailable: true,
      mistakeTolerance: 5,
    },
    2: {
      timeLimit: 90,
      targetCount: 8,
      speedMultiplier: 0.8,
      hintAvailable: true,
      mistakeTolerance: 3,
    },
    3: {
      timeLimit: 60,
      targetCount: 12,
      speedMultiplier: 1.0,
      hintAvailable: true,
      mistakeTolerance: 2,
    },
    4: {
      timeLimit: 45,
      targetCount: 16,
      speedMultiplier: 1.3,
      hintAvailable: false,
      mistakeTolerance: 1,
    },
    5: {
      timeLimit: 30,
      targetCount: 20,
      speedMultiplier: 1.6,
      hintAvailable: false,
      mistakeTolerance: 0,
    },
  }

  return params[tier]
}

// ============================================================
// TONE DIALOGUE MODIFIERS
// ============================================================

export interface ToneDialogue {
  greeting: string
  encouragement: string
  correction: string
  celebration: string
  farewell: string
}

export function getToneDialogue(tone: ToneLevel): ToneDialogue {
  const dialogues: Record<ToneLevel, ToneDialogue> = {
    NOOBIE: {
      greeting: "Hey there! Ready to learn something new? No pressure at all.",
      encouragement: "You're doing great! Take your time, there's no rush.",
      correction: "Oops! That's okay, mistakes help us learn. Want to try again?",
      celebration: "Amazing job! See? You've got this! Keep going!",
      farewell: "Great session! Come back anytime you want to practice more.",
    },
    CASUAL: {
      greeting: "Welcome back! Ready for another round?",
      encouragement: "Nice work! You're making solid progress.",
      correction: "Not quite - give it another shot.",
      celebration: "Well done! That was a solid performance.",
      farewell: "Good game! See you next time.",
    },
    GAMER: {
      greeting: "Let's go. Time to dominate.",
      encouragement: "Keep that momentum. Don't let up.",
      correction: "Missed. Recalibrate and execute.",
      celebration: "Clean. That's how it's done.",
      farewell: "GG. Come back when you're ready for more.",
    },
  }

  return dialogues[tone]
}
