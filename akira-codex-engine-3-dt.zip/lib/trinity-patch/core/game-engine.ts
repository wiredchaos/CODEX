/**
 * TRINITY PATCH - World Game Engine
 * Handles movement, NPC registry, world ticks, and event dispatching
 */

import type {
  TrinityWorldState,
  TrinityCharacter,
  TrinityNpc,
  TrinityEvent,
  GridPosition,
  TileConfig,
  TrinityRealm,
} from "./trinity-types"
import { findPath, getDistance, isInBounds } from "./grid"

// ============================================================
// WORLD STATE MANAGEMENT
// ============================================================

export function createInitialWorldState(
  realm: TrinityRealm,
  player: TrinityCharacter,
  npcs: TrinityNpc[],
  tiles: TileConfig[],
): TrinityWorldState {
  return {
    currentRealmId: realm.id,
    player: {
      ...player,
      position: realm.spawnPoint,
      currentRealmId: realm.id,
    },
    visibleNpcs: npcs.filter((npc) => npc.realmId === realm.id),
    activeTiles: tiles,
    activePortals: realm.portals,
    activeBuildings: realm.buildings,
    worldTick: 0,
    isPaused: false,
  }
}

export function tickWorld(state: TrinityWorldState): TrinityWorldState {
  if (state.isPaused) return state

  return {
    ...state,
    worldTick: state.worldTick + 1,
  }
}

// ============================================================
// PLAYER MOVEMENT
// ============================================================

export function movePlayer(
  state: TrinityWorldState,
  targetPosition: GridPosition,
  gridWidth: number,
  gridHeight: number,
): { state: TrinityWorldState; events: TrinityEvent[] } {
  const events: TrinityEvent[] = []

  // Validate target is in bounds
  if (!isInBounds(targetPosition, gridWidth, gridHeight)) {
    return { state, events }
  }

  // Check if target tile is walkable
  const targetTile = state.activeTiles.find(
    (t) => t.position.x === targetPosition.x && t.position.y === targetPosition.y,
  )

  if (targetTile && !targetTile.walkable) {
    return { state, events }
  }

  // Calculate path
  const path = findPath(state.player.position, targetPosition, state.activeTiles, gridWidth, gridHeight)

  if (path.length === 0) {
    return { state, events }
  }

  // Determine direction
  const nextPos = path[1] || targetPosition
  const direction = getDirection(state.player.position, nextPos)

  // Update player position
  const newPlayer: TrinityCharacter = {
    ...state.player,
    position: targetPosition,
    direction,
    isMoving: false,
  }

  events.push({ type: "PLAYER_MOVE", position: targetPosition })

  // Check for portal collision
  const portal = state.activePortals.find((p) => p.position.x === targetPosition.x && p.position.y === targetPosition.y)
  if (portal) {
    events.push({ type: "PORTAL_ENTER", portalId: portal.id })
  }

  // Check for building collision
  const building = state.activeBuildings.find(
    (b) =>
      targetPosition.x >= b.position.x &&
      targetPosition.x < b.position.x + b.size.width &&
      targetPosition.y >= b.position.y &&
      targetPosition.y < b.position.y + b.size.height,
  )
  if (building && building.interactable) {
    events.push({ type: "BUILDING_ENTER", buildingId: building.id })
  }

  return {
    state: { ...state, player: newPlayer },
    events,
  }
}

function getDirection(from: GridPosition, to: GridPosition): TrinityCharacter["direction"] {
  const dx = to.x - from.x
  const dy = to.y - from.y

  if (dx > 0 && dy > 0) return "SE"
  if (dx > 0 && dy < 0) return "NE"
  if (dx < 0 && dy > 0) return "SW"
  if (dx < 0 && dy < 0) return "NW"
  if (dx > 0) return "E"
  if (dx < 0) return "W"
  if (dy > 0) return "S"
  return "N"
}

// ============================================================
// NPC INTERACTION
// ============================================================

export function interactWithNpc(
  state: TrinityWorldState,
  npcId: string,
): { state: TrinityWorldState; events: TrinityEvent[] } {
  const npc = state.visibleNpcs.find((n) => n.id === npcId)

  if (!npc) {
    return { state, events: [] }
  }

  // Check if player is adjacent to NPC
  const distance = getDistance(state.player.position, npc.position)
  if (distance > 2) {
    return { state, events: [] }
  }

  return {
    state,
    events: [{ type: "NPC_INTERACT", npcId }],
  }
}

// ============================================================
// REALM TRANSITIONS
// ============================================================

export function transitionToRealm(
  state: TrinityWorldState,
  newRealm: TrinityRealm,
  allNpcs: TrinityNpc[],
  newTiles: TileConfig[],
  entryPosition?: GridPosition,
): { state: TrinityWorldState; events: TrinityEvent[] } {
  const fromRealm = state.currentRealmId

  const newState: TrinityWorldState = {
    currentRealmId: newRealm.id,
    player: {
      ...state.player,
      position: entryPosition || newRealm.spawnPoint,
      currentRealmId: newRealm.id,
    },
    visibleNpcs: allNpcs.filter((npc) => npc.realmId === newRealm.id),
    activeTiles: newTiles,
    activePortals: newRealm.portals,
    activeBuildings: newRealm.buildings,
    worldTick: state.worldTick,
    isPaused: false,
  }

  return {
    state: newState,
    events: [{ type: "REALM_CHANGE", fromRealm, toRealm: newRealm.id }],
  }
}

// ============================================================
// GAME SESSION MANAGEMENT
// ============================================================

export function startGame(
  state: TrinityWorldState,
  gameId: string,
): { state: TrinityWorldState; events: TrinityEvent[] } {
  return {
    state: { ...state, isPaused: true },
    events: [{ type: "GAME_START", gameId }],
  }
}

export function endGame(
  state: TrinityWorldState,
  gameId: string,
  score: number,
  won: boolean,
): { state: TrinityWorldState; events: TrinityEvent[] } {
  const events: TrinityEvent[] = [{ type: "GAME_END", gameId, score, won }]

  // Calculate XP reward
  const baseXp = won ? 100 : 25
  const bonusXp = Math.floor(score * 0.5)
  events.push({ type: "XP_GAINED", amount: baseXp + bonusXp, reason: `Game: ${gameId}` })

  // Check for level up
  const newXp = state.player.stats.xp + baseXp + bonusXp
  if (newXp >= state.player.stats.xpToNextLevel) {
    events.push({ type: "LEVEL_UP", newLevel: state.player.stats.level + 1 })
  }

  return {
    state: { ...state, isPaused: false },
    events,
  }
}

// ============================================================
// EVENT DISPATCHER
// ============================================================

export type EventHandler = (event: TrinityEvent) => void

export class TrinityEventBus {
  private handlers: Map<TrinityEvent["type"], EventHandler[]> = new Map()

  on(eventType: TrinityEvent["type"], handler: EventHandler): () => void {
    const existing = this.handlers.get(eventType) || []
    this.handlers.set(eventType, [...existing, handler])

    return () => {
      const handlers = this.handlers.get(eventType) || []
      this.handlers.set(
        eventType,
        handlers.filter((h) => h !== handler),
      )
    }
  }

  emit(event: TrinityEvent): void {
    const handlers = this.handlers.get(event.type) || []
    handlers.forEach((handler) => handler(event))
  }

  emitAll(events: TrinityEvent[]): void {
    events.forEach((event) => this.emit(event))
  }
}

export const globalEventBus = new TrinityEventBus()
