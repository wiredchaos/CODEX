/**
 * TRINITY PATCH - NPC Dialogue Engine
 * Adaptive dialogue based on tone level and context
 */

import type { ToneLevel, TrinityNpc } from "./trinity-types"
import { getToneDialogue } from "./aae"

// ============================================================
// DIALOGUE TYPES
// ============================================================

export interface DialogueNode {
  id: string
  speaker: string
  text: string
  responses?: DialogueResponse[]
  nextNodeId?: string
  condition?: DialogueCondition
  action?: DialogueAction
}

export interface DialogueResponse {
  text: string
  nextNodeId: string
  condition?: DialogueCondition
}

export interface DialogueCondition {
  type: "LEVEL_MIN" | "LEVEL_MAX" | "HAS_ITEM" | "QUEST_COMPLETE" | "TONE_IS"
  value: string | number
}

export interface DialogueAction {
  type: "GRANT_XP" | "START_GAME" | "OPEN_SHOP" | "START_QUEST" | "ENTER_LABYRINTH"
  payload: Record<string, unknown>
}

export interface DialogueSet {
  id: string
  npcId: string
  nodes: DialogueNode[]
  entryNodeId: string
}

// ============================================================
// TONE-ADAPTIVE DIALOGUE TEMPLATES
// ============================================================

export function generateGreeting(npcName: string, tone: ToneLevel): string {
  const toneDialogue = getToneDialogue(tone)

  const greetings: Record<ToneLevel, string[]> = {
    NOOBIE: [
      `Hi there! I'm ${npcName}. Welcome to the arcade!`,
      `Hey! ${npcName} here. Don't worry, I'll help you get started.`,
      `Welcome, friend! I'm ${npcName}. Ready to have some fun?`,
    ],
    CASUAL: [
      `${npcName} here. Good to see you.`,
      `Hey. I'm ${npcName}. Looking for a challenge?`,
      `Welcome back. ${npcName} at your service.`,
    ],
    GAMER: [
      `${npcName}. Let's skip the pleasantries.`,
      `You again. ${npcName}. Ready to compete?`,
      `${npcName}. Time to prove yourself.`,
    ],
  }

  const options = greetings[tone]
  return options[Math.floor(Math.random() * options.length)]
}

export function generateGameIntro(gameName: string, tone: ToneLevel): string {
  const intros: Record<ToneLevel, string[]> = {
    NOOBIE: [
      `This is ${gameName}! It's a fun one. Let me explain how it works...`,
      `Want to try ${gameName}? It's great for beginners. Here's the basics...`,
      `${gameName} is perfect for learning. Take your time with it!`,
    ],
    CASUAL: [
      `${gameName}. You know the drill. Good luck.`,
      `Ready for ${gameName}? Standard rules apply.`,
      `${gameName} awaits. Show me what you've got.`,
    ],
    GAMER: [
      `${gameName}. Maximum difficulty unlocked. Execute.`,
      `${gameName}. No hints. No mercy. Begin.`,
      `You want ${gameName}? Prove you're worthy.`,
    ],
  }

  const options = intros[tone]
  return options[Math.floor(Math.random() * options.length)]
}

export function generateWinResponse(score: number, tone: ToneLevel): string {
  const responses: Record<ToneLevel, string[]> = {
    NOOBIE: [
      `You did it! ${score} points! I knew you could do it!`,
      `Amazing! ${score} points! You're getting so good at this!`,
      `Wonderful job! ${score} points! Keep practicing and you'll be unstoppable!`,
    ],
    CASUAL: [
      `Nice work. ${score} points. Solid run.`,
      `Well played. ${score} points added to your total.`,
      `Good game. ${score} points. Not bad at all.`,
    ],
    GAMER: [`${score}. Acceptable. Next.`, `${score} points. Competent performance.`, `${score}. You passed. Barely.`],
  }

  const options = responses[tone]
  return options[Math.floor(Math.random() * options.length)]
}

export function generateLoseResponse(tone: ToneLevel): string {
  const responses: Record<ToneLevel, string[]> = {
    NOOBIE: [
      `That's okay! Every attempt teaches us something. Want to try again?`,
      `Don't worry about it! Practice makes perfect. Ready for another go?`,
      `No problem! Even the best players started somewhere. Try again?`,
    ],
    CASUAL: [
      `Tough break. Want another shot?`,
      `Didn't work out. Reset and try again?`,
      `Close one. Give it another go?`,
    ],
    GAMER: [`Failed. Again.`, `Insufficient. Retry.`, `Defeat. Learn from it.`],
  }

  const options = responses[tone]
  return options[Math.floor(Math.random() * options.length)]
}

// ============================================================
// DIALOGUE SET BUILDER
// ============================================================

export function buildNpcDialogueSet(npc: TrinityNpc, tone: ToneLevel, availableGames: string[]): DialogueSet {
  const nodes: DialogueNode[] = [
    {
      id: "entry",
      speaker: npc.name,
      text: generateGreeting(npc.name, tone),
      responses: [
        { text: "Show me the games", nextNodeId: "games_list" },
        { text: "Tell me about this place", nextNodeId: "lore_intro" },
        { text: "Goodbye", nextNodeId: "farewell" },
      ],
    },
    {
      id: "games_list",
      speaker: npc.name,
      text: `I have ${availableGames.length} games ready. What interests you?`,
      responses: availableGames.slice(0, 4).map((game) => ({
        text: game,
        nextNodeId: `game_${game.toLowerCase().replace(/\s+/g, "_")}`,
      })),
    },
    {
      id: "lore_intro",
      speaker: npc.name,
      text: getLoreIntro(npc.role, tone),
      nextNodeId: "entry",
    },
    {
      id: "farewell",
      speaker: npc.name,
      text: getToneDialogue(tone).farewell,
    },
  ]

  // Add game-specific nodes
  availableGames.forEach((game) => {
    nodes.push({
      id: `game_${game.toLowerCase().replace(/\s+/g, "_")}`,
      speaker: npc.name,
      text: generateGameIntro(game, tone),
      action: { type: "START_GAME", payload: { gameId: game } },
    })
  })

  return {
    id: `dialogue_${npc.id}`,
    npcId: npc.id,
    nodes,
    entryNodeId: "entry",
  }
}

function getLoreIntro(role: TrinityNpc["role"], tone: ToneLevel): string {
  const intros: Record<TrinityNpc["role"], Record<ToneLevel, string>> = {
    GUIDE: {
      NOOBIE:
        "This is the Trinity Arcade! A place where anyone can learn and play. Each realm offers different challenges.",
      CASUAL: "The Trinity Arcade spans three realms. Each has its own style and challenges. Explore them all.",
      GAMER: "Trinity. Three realms. Infinite challenge. Master all or master none.",
    },
    CHALLENGER: {
      NOOBIE: "I'm here to test your skills! But don't worry, I'll go easy on you at first.",
      CASUAL: "I offer challenges for those who seek them. Think you're ready?",
      GAMER: "You face me, you face defeat. Unless you're exceptional.",
    },
    MERCHANT: {
      NOOBIE: "Welcome to my shop! I have items that can help you on your journey.",
      CASUAL: "Goods and services. Fair prices. What do you need?",
      GAMER: "Upgrades. Buffs. Currency talks.",
    },
    LORE_KEEPER: {
      NOOBIE: "Ah, a seeker of knowledge! Let me tell you the stories of this place...",
      CASUAL: "The archives hold many secrets. What would you like to know?",
      GAMER: "Data. History. Intelligence. What's your query?",
    },
    PROMPT_MASTER: {
      NOOBIE: "The Prompt Lab is where creativity meets challenge! Try crafting prompts and see what happens.",
      CASUAL: "Prompt engineering awaits. Test your creativity against the AI.",
      GAMER: "Prompt Lab. Maximum creativity. Zero tolerance for mediocrity.",
    },
  }

  return intros[role][tone]
}
