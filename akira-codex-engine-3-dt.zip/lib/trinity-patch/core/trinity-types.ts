/**
 * TRINITY ARCADE OVERWORLD PATCH v1
 * Core Type Definitions
 *
 * SYSTEM RULES:
 * - This is a NEUTRAL, PORTABLE engine
 * - Zero lore embedded in types
 * - All personality injected via Host Adapters
 * - No system-specific XP logic
 */

// ============================================================
// REALM SYSTEM
// ============================================================

export type RealmId = "NEURALIS" | "CHAOSPHERE" | "ECHO" | string

export type ToneLevel = "NOOBIE" | "CASUAL" | "GAMER"

export interface TrinityRealm {
  id: RealmId
  label: string
  description: string
  defaultTone: ToneLevel
  gridSize: { width: number; height: number }
  portals: PortalConfig[]
  buildings: BuildingConfig[]
  spawnPoint: GridPosition
}

export interface PortalConfig {
  id: string
  position: GridPosition
  targetRealmId: RealmId
  targetPosition: GridPosition
  label: string
  requiredLevel?: number
  hookType?: "WL" | "589" | "ARG" | "LABYRINTH" | "ARCADE"
}

export interface BuildingConfig {
  id: string
  type: "ARCADE" | "STUDENT_UNION" | "PROMPT_LAB" | "LABYRINTH_ENTRANCE" | "TEMPLE" | "LIBRARY" | "GUILD"
  position: GridPosition
  size: { width: number; height: number }
  label: string
  interactable: boolean
  npcIds?: string[]
}

// ============================================================
// GRID / ISOMETRIC SYSTEM
// ============================================================

export interface GridPosition {
  x: number
  y: number
}

export interface IsoPosition {
  isoX: number
  isoY: number
}

export interface TileConfig {
  id: string
  position: GridPosition
  type: "FLOOR" | "WALL" | "PORTAL" | "BUILDING" | "WATER" | "PATH" | "SPAWN"
  walkable: boolean
  elevation: number
  spriteKey?: string
}

// ============================================================
// CHARACTER / NPC SYSTEM
// ============================================================

export interface TrinityCharacter {
  id: string
  displayName: string
  avatarUrl: string
  position: GridPosition
  currentRealmId: RealmId
  direction: "N" | "S" | "E" | "W" | "NE" | "NW" | "SE" | "SW"
  isMoving: boolean
  stats: CharacterStats
}

export interface CharacterStats {
  level: number
  xp: number
  xpToNextLevel: number
  gamesPlayed: number
  gamesWon: number
  whitelistProgress: number
  achievements: string[]
}

export interface TrinityNpc {
  id: string
  name: string
  role: "GUIDE" | "CHALLENGER" | "MERCHANT" | "LORE_KEEPER" | "PROMPT_MASTER"
  position: GridPosition
  realmId: RealmId
  spriteUrl: string
  dialogueSetId: string
  toneOverride?: ToneLevel
}

// ============================================================
// GAME / ARCADE SYSTEM
// ============================================================

export interface TrinityGame {
  id: string
  label: string
  description: string
  realms: RealmId[]
  difficulty: DifficultyTier
  category: GameCategory
  xpReward: { base: number; multiplier: number }
  wlProgressOnWin?: number
  thumbnailUrl?: string
}

export type DifficultyTier = 1 | 2 | 3 | 4 | 5

export type GameCategory = "PUZZLE" | "TYPING" | "MEMORY" | "STRATEGY" | "REACTION" | "TRIVIA" | "NARRATIVE"

// ============================================================
// AGENTIC ADAPTATION ENGINE (AAE)
// ============================================================

export interface AAEProfile {
  userId: string
  skillLevel: number // 0-100
  preferredTone: ToneLevel
  reactionTimeAvg: number
  accuracyRate: number
  frustrationIndex: number
  sessionHistory: AAESessionRecord[]
  adaptations: AAEAdaptation[]
}

export interface AAESessionRecord {
  gameId: string
  timestamp: number
  score: number
  difficulty: DifficultyTier
  completionTime: number
  mistakes: number
  didQuitEarly: boolean
}

export interface AAEAdaptation {
  type: "DIFFICULTY_DOWN" | "DIFFICULTY_UP" | "TONE_SHIFT" | "HINT_OFFERED" | "BREAK_SUGGESTED"
  triggeredAt: number
  reason: string
  accepted: boolean
}

export interface AAEDecision {
  recommendedDifficulty: DifficultyTier
  recommendedTone: ToneLevel
  shouldOfferHint: boolean
  shouldSuggestBreak: boolean
  confidenceScore: number
  reasoning: string
}

// ============================================================
// HOST ADAPTER INTERFACE
// ============================================================

export interface TrinityIdentity {
  userId: string
  displayName: string
  avatarUrl: string
  hostMetadata?: Record<string, unknown>
}

export interface TrinityEconomy {
  grantXp(amount: number, reason: string): Promise<void>
  grantWhitelistProgress(steps: number, context: string): Promise<void>
  grantToken?(amount: number, tokenType: string): Promise<void>
}

export interface TrinityLoreBridge {
  getNarration(key: string): string
  getNpcSkin(npcId: string): { spriteUrl: string; nameOverride?: string }
  getRealmTheme(realmId: RealmId): RealmThemeOverride
}

export interface RealmThemeOverride {
  backgroundUrl?: string
  tilesetKey?: string
  ambientAudio?: string
  colorAccent?: string
}

export interface TrinityHostAdapter {
  hostId: string
  getCurrentIdentity(): Promise<TrinityIdentity>
  getEconomy(): TrinityEconomy
  getLoreBridge(): TrinityLoreBridge
  getNsfwGate?(): { enabled: boolean; minAge: 18 | 21 }
  getLabyrinthBridge?(): LabyrinthBridge
  getPromptLabBridge?(): PromptLabBridge
}

// ============================================================
// SPECIAL BRIDGES (Optional Host Features)
// ============================================================

export interface LabyrinthBridge {
  enterLabyrinth(userId: string, entryPoint: string): Promise<{ sessionId: string }>
  getLabyrinthState(sessionId: string): Promise<LabyrinthState>
}

export interface LabyrinthState {
  currentRoom: string
  npcsEncountered: string[]
  choicesMade: { nodeId: string; choice: string }[]
  exitAvailable: boolean
}

export interface PromptLabBridge {
  startPromptSession(userId: string, npcId: string): Promise<{ sessionId: string }>
  submitPrompt(sessionId: string, prompt: string): Promise<PromptLabResult>
}

export interface PromptLabResult {
  score: number
  feedback: string
  xpAwarded: number
  badgeUnlocked?: string
}

// ============================================================
// PATCH MANIFEST
// ============================================================

export interface TrinityPatchManifest {
  patchId: "TRINITY_ARCADE_OVERWORLD"
  version: string
  hostSystemName: string

  realms: TrinityRealm[]
  games: TrinityGame[]
  npcs: TrinityNpc[]

  features: {
    promptLab: boolean
    wlHooks: boolean
    argHooks: boolean
    studentUnion: boolean
    labyrinthTunnel: boolean
    nsfwZones: boolean
  }

  hostBindings: {
    identity: "HOST_API" | "ANONYMOUS" | "WALLET"
    economy: "XP" | "TOKEN" | "HYBRID"
    loreMode: string
  }
}

// ============================================================
// WORLD STATE
// ============================================================

export interface TrinityWorldState {
  currentRealmId: RealmId
  player: TrinityCharacter
  visibleNpcs: TrinityNpc[]
  activeTiles: TileConfig[]
  activePortals: PortalConfig[]
  activeBuildings: BuildingConfig[]
  worldTick: number
  isPaused: boolean
}

// ============================================================
// EVENTS
// ============================================================

export type TrinityEvent =
  | { type: "PLAYER_MOVE"; position: GridPosition }
  | { type: "PORTAL_ENTER"; portalId: string }
  | { type: "BUILDING_ENTER"; buildingId: string }
  | { type: "NPC_INTERACT"; npcId: string }
  | { type: "GAME_START"; gameId: string }
  | { type: "GAME_END"; gameId: string; score: number; won: boolean }
  | { type: "XP_GAINED"; amount: number; reason: string }
  | { type: "LEVEL_UP"; newLevel: number }
  | { type: "WL_PROGRESS"; steps: number }
  | { type: "REALM_CHANGE"; fromRealm: RealmId; toRealm: RealmId }
