/**
 * TRINITY ARCADE OVERWORLD PATCH v1
 * Main Entry Point
 *
 * This patch is NEUTRAL and PORTABLE.
 * All host-specific logic is injected via adapters and manifests.
 */

// Core exports
export * from "./core/index"

// Adapter exports
export * from "./adapters/index"

// Manifest exports
export * from "./manifests/index"
