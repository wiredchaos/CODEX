/**
 * TRINITY PATCH - AKIRA CODEX Host Adapter
 * Storyboard Lab + Drama Challenges + Scene XP
 * Includes Safe and NSFW (21+) variants
 */

import type {
  TrinityHostAdapter,
  TrinityIdentity,
  TrinityEconomy,
  TrinityLoreBridge,
  RealmId,
  RealmThemeOverride,
} from "../core/trinity-types"
import { registerHostAdapter } from "./trinity-host-adapter"

// ============================================================
// AKIRA CODEX IDENTITY
// ============================================================

async function getAkiraCodexIdentity(): Promise<TrinityIdentity> {
  return {
    userId: "akira-writer-001",
    displayName: "Story Weaver",
    avatarUrl: "/sprites/akira-avatar.png",
    hostMetadata: {
      writerTier: "APPRENTICE",
      storiesPublished: 0,
      currentPOV: "AKIRA",
    },
  }
}

// ============================================================
// AKIRA CODEX ECONOMY (Scene XP)
// ============================================================

const akiraCodexEconomy: TrinityEconomy = {
  async grantXp(amount, reason) {
    console.log(`[AKIRA_CODEX] Scene XP granted: ${amount} - ${reason}`)
  },

  async grantWhitelistProgress(steps, context) {
    console.log(`[AKIRA_CODEX] Story Progress: ${steps} - ${context}`)
  },
}

// ============================================================
// AKIRA CODEX LORE BRIDGE
// ============================================================

const akiraCodexLoreBridge: TrinityLoreBridge = {
  getNarration(key) {
    const narrations: Record<string, string> = {
      "realm.neuralis":
        "The Writing Studio awaits. Here, narratives are born from imagination and refined through craft.",
      "realm.chaosphere": "The Drama Arena. Conflict drives story. Master tension, master narrative.",
      "realm.echo": "The Archives. Every story ever told echoes here. Study the masters.",
      "building.storyboard": "The Storyboard Lab - visualize your narrative arcs and plot your scenes.",
      "building.challenge": "Drama Challenge Arena - test your storytelling against timed prompts.",
    }
    return narrations[key] || `[AKIRA] Unknown key: ${key}`
  },

  getNpcSkin(npcId) {
    const skins: Record<string, { spriteUrl: string; nameOverride?: string }> = {
      "guide-main": { spriteUrl: "/sprites/akira-mentor.png", nameOverride: "Master Scribe" },
      "challenger-1": { spriteUrl: "/sprites/akira-rival.png", nameOverride: "Rival Author" },
      "lore-keeper": { spriteUrl: "/sprites/akira-archivist.png", nameOverride: "The Archivist" },
    }
    return skins[npcId] || { spriteUrl: "/sprites/akira-default-npc.png" }
  },

  getRealmTheme(realmId: RealmId): RealmThemeOverride {
    const themes: Record<string, RealmThemeOverride> = {
      NEURALIS: {
        backgroundUrl: "/backgrounds/akira-studio.jpg",
        colorAccent: "#ffd700",
      },
      CHAOSPHERE: {
        backgroundUrl: "/backgrounds/akira-arena.jpg",
        colorAccent: "#dc143c",
      },
      ECHO: {
        backgroundUrl: "/backgrounds/akira-archives.jpg",
        colorAccent: "#4169e1",
      },
    }
    return themes[realmId] || { colorAccent: "#ffffff" }
  },
}

// ============================================================
// AKIRA CODEX SAFE ADAPTER
// ============================================================

export const AkiraCodexSafeAdapter: TrinityHostAdapter = {
  hostId: "AKIRA_CODEX_SAFE",

  async getCurrentIdentity() {
    return getAkiraCodexIdentity()
  },

  getEconomy() {
    return akiraCodexEconomy
  },

  getLoreBridge() {
    return akiraCodexLoreBridge
  },

  getNsfwGate() {
    return { enabled: false, minAge: 18 }
  },
}

// ============================================================
// AKIRA CODEX NSFW (21+) ADAPTER
// ============================================================

export const AkiraCodexNsfwAdapter: TrinityHostAdapter = {
  hostId: "AKIRA_CODEX_NSFW",

  async getCurrentIdentity() {
    const identity = await getAkiraCodexIdentity()
    return {
      ...identity,
      hostMetadata: {
        ...identity.hostMetadata,
        nsfwVerified: true,
        contentGate: "RED_VEIL",
      },
    }
  },

  getEconomy() {
    return akiraCodexEconomy
  },

  getLoreBridge() {
    return {
      ...akiraCodexLoreBridge,
      getNarration(key: string) {
        const nsfwNarrations: Record<string, string> = {
          "realm.chaosphere":
            "The Shadow Arena. Mature themes explored through the lens of dramatic narrative. 21+ content enabled.",
          "gate.red_veil": "Red Veil content zone. Symbolic mature content. No explicit material.",
        }
        return nsfwNarrations[key] || akiraCodexLoreBridge.getNarration(key)
      },
    }
  },

  getNsfwGate() {
    return { enabled: true, minAge: 21 }
  },
}

// Register adapters
registerHostAdapter(AkiraCodexSafeAdapter)
registerHostAdapter(AkiraCodexNsfwAdapter)
