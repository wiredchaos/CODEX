/**
 * TRINITY PATCH - Host Adapter Interface
 * All host systems must implement this interface
 */

import type {
  TrinityHostAdapter,
  TrinityIdentity,
  TrinityEconomy,
  TrinityLoreBridge,
  RealmId,
  RealmThemeOverride,
} from "../core/trinity-types"

// ============================================================
// DEFAULT / ANONYMOUS ADAPTER
// ============================================================

export const defaultIdentity: TrinityIdentity = {
  userId: "anon",
  displayName: "Player One",
  avatarUrl: "/sprites/default-avatar.png",
}

export const defaultEconomy: TrinityEconomy = {
  async grantXp(amount, reason) {
    console.log(`[Trinity] XP granted: ${amount} - ${reason}`)
  },
  async grantWhitelistProgress(steps, context) {
    console.log(`[Trinity] WL progress: ${steps} steps - ${context}`)
  },
}

export const defaultLoreBridge: TrinityLoreBridge = {
  getNarration(key) {
    return `Default narration for: ${key}`
  },
  getNpcSkin(npcId) {
    return { spriteUrl: "/sprites/default-npc.png" }
  },
  getRealmTheme(realmId: RealmId): RealmThemeOverride {
    return {
      colorAccent: "#00ffff",
    }
  },
}

export const AnonymousHostAdapter: TrinityHostAdapter = {
  hostId: "ANONYMOUS",

  async getCurrentIdentity() {
    return defaultIdentity
  },

  getEconomy() {
    return defaultEconomy
  },

  getLoreBridge() {
    return defaultLoreBridge
  },
}

// ============================================================
// ADAPTER REGISTRY
// ============================================================

type HostAdapterRegistry = Map<string, TrinityHostAdapter>

const adapterRegistry: HostAdapterRegistry = new Map()

export function registerHostAdapter(adapter: TrinityHostAdapter): void {
  adapterRegistry.set(adapter.hostId, adapter)
}

export function getHostAdapter(hostId: string): TrinityHostAdapter {
  return adapterRegistry.get(hostId) || AnonymousHostAdapter
}

export function listRegisteredHosts(): string[] {
  return Array.from(adapterRegistry.keys())
}

// Register default adapter
registerHostAdapter(AnonymousHostAdapter)
