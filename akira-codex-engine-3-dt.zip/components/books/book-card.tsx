"use client"

import { BookOpen, Clock, Download, Eye } from "lucide-react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import type { MiniNovella, AgeTier } from "@/lib/creator-codex"
import { estimateReadingTime } from "@/lib/creator-codex"

interface BookCardProps {
  book: MiniNovella
}

const TIER_STYLES: Record<AgeTier, { bg: string; text: string; border: string; label: string }> = {
  UNDER_18: {
    bg: "bg-emerald-500/10",
    text: "text-emerald-400",
    border: "border-emerald-500/30",
    label: "All Ages",
  },
  "18_PLUS": {
    bg: "bg-amber-500/10",
    text: "text-amber-400",
    border: "border-amber-500/30",
    label: "18+",
  },
  RED_VEIL_21: {
    bg: "bg-red-500/10",
    text: "text-red-400",
    border: "border-red-500/30",
    label: "Red Veil",
  },
}

export function BookCard({ book }: BookCardProps) {
  const { metadata, totalWordCount } = book
  const tierStyle = TIER_STYLES[metadata.ageTier]
  const readTime = estimateReadingTime(totalWordCount)

  return (
    <Card className="group relative overflow-hidden border-cyan-500/20 bg-background/50 backdrop-blur-xl transition-all duration-300 hover:border-cyan-500/40 hover:shadow-lg hover:shadow-cyan-500/10">
      {/* Glow effect on hover */}
      <div className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 via-transparent to-fuchsia-500/5" />
      </div>

      <CardContent className="relative p-6">
        {/* Age tier badge */}
        <Badge className={`mb-4 ${tierStyle.bg} ${tierStyle.text} ${tierStyle.border} border`}>{tierStyle.label}</Badge>

        {/* Title */}
        <h3 className="mb-2 text-xl font-bold tracking-tight text-foreground group-hover:text-cyan-400 transition-colors">
          {metadata.title}
        </h3>

        {/* Author */}
        <p className="mb-4 text-sm text-muted-foreground">by {metadata.penName || metadata.author}</p>

        {/* Blurb */}
        <p className="mb-4 text-sm leading-relaxed text-muted-foreground line-clamp-4">{metadata.blurb}</p>

        {/* Genres */}
        <div className="flex flex-wrap gap-2 mb-4">
          {metadata.genres.slice(0, 2).map((genre) => (
            <Badge
              key={genre}
              variant="outline"
              className="text-xs border-fuchsia-500/30 text-fuchsia-400 bg-fuchsia-500/5"
            >
              {genre.replace("_", " ")}
            </Badge>
          ))}
        </div>

        {/* Stats */}
        <div className="flex items-center gap-4 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <BookOpen className="h-3 w-3" />
            {totalWordCount.toLocaleString()} words
          </span>
          <span className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            {readTime}
          </span>
        </div>
      </CardContent>

      <CardFooter className="relative border-t border-cyan-500/10 bg-cyan-500/5 p-4">
        <div className="flex w-full gap-2">
          <Button
            variant="outline"
            size="sm"
            className="flex-1 border-cyan-500/30 hover:bg-cyan-500/10 hover:border-cyan-500/50 bg-transparent"
          >
            <Eye className="h-4 w-4 mr-2" />
            Preview
          </Button>
          <Button
            size="sm"
            className="flex-1 bg-gradient-to-r from-cyan-500 to-fuchsia-500 hover:from-cyan-600 hover:to-fuchsia-600 text-white border-0"
          >
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </CardFooter>
    </Card>
  )
}
