"use client"

import { BookCard } from "./book-card"
import type { MiniNovella, AgeTier, StoryGenre, ContentRating } from "@/lib/creator-codex"

// Demo data for the grid
const DEMO_BOOKS: Partial<MiniNovella>[] = [
  {
    id: "novella_001",
    metadata: {
      title: "The Clockwork Dreamer",
      author: "Elena Cross",
      blurb:
        "In a city where dreams are harvested and sold, one girl discovers she can manipulate the machinery of sleep itself. But some nightmares were never meant to wake.",
      genres: ["FANTASY", "MYSTERY"] as StoryGenre[],
      ageTier: "UNDER_18" as AgeTier,
      contentRating: "TEEN" as ContentRating,
      keywords: ["dreams", "steampunk", "mystery"],
      language: "en",
      copyrightYear: 2025,
      publisher: "Creator Codex Publishing",
      longDescription: "",
    },
    totalWordCount: 15420,
    status: "COMPLETE",
  },
  {
    id: "novella_002",
    metadata: {
      title: "Shadows of the Velvet Court",
      author: "Marcus Thane",
      blurb:
        "Political intrigue meets forbidden desire in a world where magic flows through bloodlines—and betrayal runs even deeper. A tale of power, passion, and dark bargains.",
      genres: ["DARK_FANTASY", "ROMANCE"] as StoryGenre[],
      ageTier: "18_PLUS" as AgeTier,
      contentRating: "MATURE" as ContentRating,
      keywords: ["court intrigue", "magic", "romance"],
      language: "en",
      copyrightYear: 2025,
      publisher: "Creator Codex Publishing",
      longDescription: "",
    },
    totalWordCount: 22150,
    status: "COMPLETE",
  },
  {
    id: "novella_003",
    metadata: {
      title: "The Crimson Vow",
      author: "Selene Noir",
      penName: "S. Noir",
      blurb:
        "When the last vampire queen takes a mortal lover, their union threatens to shatter the veil between worlds. Passion burns eternal—but so does vengeance.",
      genres: ["PARANORMAL", "ROMANCE"] as StoryGenre[],
      ageTier: "RED_VEIL_21" as AgeTier,
      contentRating: "ADULT" as ContentRating,
      keywords: ["vampire", "passion", "dark romance"],
      language: "en",
      copyrightYear: 2025,
      publisher: "Creator Codex Publishing",
      longDescription: "",
    },
    totalWordCount: 28300,
    status: "COMPLETE",
  },
  {
    id: "novella_004",
    metadata: {
      title: "Starfall Academy",
      author: "Jamie Rivers",
      blurb:
        "At a school where students train to become galactic guardians, one misfit discovers an ancient power that could save the universe—or destroy it forever.",
      genres: ["SCI_FI", "ADVENTURE"] as StoryGenre[],
      ageTier: "UNDER_18" as AgeTier,
      contentRating: "TEEN" as ContentRating,
      keywords: ["space", "academy", "chosen one"],
      language: "en",
      copyrightYear: 2025,
      publisher: "Creator Codex Publishing",
      longDescription: "",
    },
    totalWordCount: 18750,
    status: "COMPLETE",
  },
  {
    id: "novella_005",
    metadata: {
      title: "The Memory Thief",
      author: "Ada Sterling",
      blurb:
        "In Neo-Tokyo 2089, memories are currency. When a thief steals the wrong mind, she uncovers a conspiracy that reaches into the highest towers of power.",
      genres: ["SCI_FI", "THRILLER"] as StoryGenre[],
      ageTier: "18_PLUS" as AgeTier,
      contentRating: "MATURE" as ContentRating,
      keywords: ["cyberpunk", "heist", "conspiracy"],
      language: "en",
      copyrightYear: 2025,
      publisher: "Creator Codex Publishing",
      longDescription: "",
    },
    totalWordCount: 24600,
    status: "COMPLETE",
  },
  {
    id: "novella_006",
    metadata: {
      title: "Whispers in the Flame",
      author: "Dante Ashford",
      blurb:
        "Two souls bound by ancient fire, torn between duty and desire. In the temple of the Eternal Flame, love becomes worship—and worship becomes surrender.",
      genres: ["FANTASY", "ROMANCE"] as StoryGenre[],
      ageTier: "RED_VEIL_21" as AgeTier,
      contentRating: "ADULT" as ContentRating,
      keywords: ["mythology", "passion", "ritual"],
      language: "en",
      copyrightYear: 2025,
      publisher: "Creator Codex Publishing",
      longDescription: "",
    },
    totalWordCount: 19800,
    status: "COMPLETE",
  },
]

export function BooksGrid() {
  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {DEMO_BOOKS.map((book) => (
        <BookCard key={book.id} book={book as MiniNovella} />
      ))}
    </div>
  )
}
