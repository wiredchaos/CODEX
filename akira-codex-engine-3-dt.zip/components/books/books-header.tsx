"use client"

import { useState } from "react"
import { Sparkles, BookOpen, Filter } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu"
import type { AgeTier } from "@/lib/creator-codex"

const AGE_TIER_LABELS: Record<AgeTier, string> = {
  UNDER_18: "All Ages",
  "18_PLUS": "18+",
  RED_VEIL_21: "Red Veil 21+",
}

export function BooksHeader() {
  const [selectedTiers, setSelectedTiers] = useState<AgeTier[]>(["UNDER_18", "18_PLUS", "RED_VEIL_21"])

  const toggleTier = (tier: AgeTier) => {
    setSelectedTiers((prev) => (prev.includes(tier) ? prev.filter((t) => t !== tier) : [...prev, tier]))
  }

  return (
    <header className="mb-12">
      {/* Glowing title */}
      <div className="flex items-center gap-4 mb-6">
        <div className="relative">
          <BookOpen className="h-12 w-12 text-cyan-400" />
          <div className="absolute inset-0 blur-lg bg-cyan-400/50" />
        </div>
        <div>
          <h1 className="text-4xl font-bold tracking-tight">
            <span className="bg-gradient-to-r from-cyan-400 via-fuchsia-400 to-violet-400 bg-clip-text text-transparent">
              Creator Codex
            </span>
          </h1>
          <p className="text-muted-foreground mt-1">Mini-Novella Publishing Engine</p>
        </div>
      </div>

      {/* Chaos aesthetic subtitle */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
        <Sparkles className="h-4 w-4 text-fuchsia-400" />
        <span className="font-mono">CHAOS OS // STORY_FORGE_v2.0 // AGE_GATED_FIREWALL_ACTIVE</span>
      </div>

      {/* Filter controls */}
      <div className="flex items-center gap-4">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="outline"
              className="border-cyan-500/30 bg-cyan-500/5 hover:bg-cyan-500/10 hover:border-cyan-500/50"
            >
              <Filter className="h-4 w-4 mr-2" />
              Age Tiers
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-48 bg-background/95 backdrop-blur-xl border-cyan-500/20">
            <DropdownMenuLabel className="text-cyan-400">Content Gates</DropdownMenuLabel>
            <DropdownMenuSeparator className="bg-cyan-500/20" />
            {(Object.keys(AGE_TIER_LABELS) as AgeTier[]).map((tier) => (
              <DropdownMenuCheckboxItem
                key={tier}
                checked={selectedTiers.includes(tier)}
                onCheckedChange={() => toggleTier(tier)}
                className="focus:bg-cyan-500/10"
              >
                <span
                  className={
                    tier === "RED_VEIL_21" ? "text-red-400" : tier === "18_PLUS" ? "text-amber-400" : "text-green-400"
                  }
                >
                  {AGE_TIER_LABELS[tier]}
                </span>
              </DropdownMenuCheckboxItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        <Button className="bg-gradient-to-r from-cyan-500 to-fuchsia-500 hover:from-cyan-600 hover:to-fuchsia-600 text-white border-0">
          <Sparkles className="h-4 w-4 mr-2" />
          Generate New Novella
        </Button>
      </div>
    </header>
  )
}
