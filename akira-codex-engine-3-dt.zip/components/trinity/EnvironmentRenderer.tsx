"use client"

import { useEffect, useState } from "react"
import { mountSessionManager } from "@/lib/trinity/mount"
import type { TrinityFloorConsumer } from "@/lib/trinity/mount"

interface EnvironmentRendererProps {
  patchId: string
  kind: "lobby" | "arcade" | "district" | "portal"
  realmId?: "NEURALIS" | "CHAOSPHERE" | "ECHO"
  onMountError?: (error: Error) => void
}

/**
 * TRINITY ENVIRONMENT RENDERER (CONSUMER)
 *
 * This component is a READ-ONLY consumer of the WIRED CHAOS Trinity 3D Core.
 * It does NOT implement its own 3D engine or create timelines/elevators.
 * It mounts to the existing Trinity environment using the Floor Consumer API.
 *
 * Rules:
 * - Read-only Trinity Core access
 * - Respects Akira Codex gating
 * - Uses hotspots + HUD supplied by core
 * - Business data stays firewalled
 */
export function EnvironmentRenderer({ patchId, kind, realmId = "ECHO", onMountError }: EnvironmentRendererProps) {
  const [mounted, setMounted] = useState(false)
  const [consumer, setConsumer] = useState<TrinityFloorConsumer | null>(null)
  const [error, setError] = useState<Error | null>(null)
  const [floorData, setFloorData] = useState<{
    gridSize: number
    portalCount: number
    npcCount: number
    gameNodeCount: number
  } | null>(null)

  useEffect(() => {
    let sessionId: string | null = null

    async function mountToTrinity() {
      try {
        const session = mountSessionManager.createSession(patchId)
        sessionId = session.sessionId

        const floorId = `FLOOR_${realmId}_${kind.toUpperCase()}`
        const mountPoint = mountSessionManager.mountToFloor(session, floorId)

        const binding = {
          floorId: mountPoint.floorId!,
          realmId,
          gridRef: `GRID_${floorId}`,
          portalRefs: [], // Will be populated from Trinity Core
          npcRefs: [],
          gameNodeRefs: [],
        }

        const floorConsumer = mountSessionManager.createFloorConsumer(session, binding)
        setConsumer(floorConsumer)

        const grid = floorConsumer.getGridRef()
        const portals = floorConsumer.getPortalRefs()
        const npcs = floorConsumer.getNpcRefs()
        const gameNodes = floorConsumer.getGameNodeRefs()

        setFloorData({
          gridSize: grid ? 32 : 0, // Placeholder - actual grid from Trinity Core
          portalCount: portals.length,
          npcCount: npcs.length,
          gameNodeCount: gameNodes.length,
        })

        setMounted(true)
        console.log(`[v0] Trinity mount successful: ${patchId} → ${floorId}`)
      } catch (err) {
        const mountError = err instanceof Error ? err : new Error("Mount failed")
        setError(mountError)
        onMountError?.(mountError)
        console.error("[v0] Trinity mount error:", mountError)
      }
    }

    mountToTrinity()

    return () => {
      if (sessionId) {
        mountSessionManager.destroySession(sessionId)
        console.log(`[v0] Trinity mount cleanup: ${sessionId}`)
      }
    }
  }, [patchId, kind, realmId, onMountError])

  // Error state
  if (error) {
    return (
      <div className="flex items-center justify-center h-screen bg-red-950/20 text-red-400 p-8">
        <div className="text-center">
          <h2 className="text-xl font-bold mb-2">Mount Failed</h2>
          <p className="text-sm opacity-80">{error.message}</p>
        </div>
      </div>
    )
  }

  // Loading state
  if (!mounted || !floorData) {
    return (
      <div className="flex items-center justify-center h-screen bg-zinc-950">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-zinc-600 border-t-zinc-400 rounded-full animate-spin mx-auto mb-4" />
          <p className="text-zinc-500 text-sm">Mounting to Trinity Floor...</p>
        </div>
      </div>
    )
  }

  // Mounted state - render cinematic environment
  return (
    <div className="relative w-full h-screen bg-zinc-950 overflow-hidden">
      {/* Video fallback layer (primary for now) */}
      <div className="absolute inset-0">
        <video className="w-full h-full object-cover opacity-60" autoPlay loop muted playsInline>
          <source src={`/trinity/${kind}-${realmId.toLowerCase()}.mp4`} type="video/mp4" />
        </video>
        <div className="absolute inset-0 bg-gradient-to-b from-zinc-950/40 via-transparent to-zinc-950/80" />
      </div>

      {/* 3D Canvas placeholder (will be replaced by Trinity 3D Core when available) */}
      <div className="absolute inset-0 pointer-events-none">{/* Trinity 3D Core will inject WebGL canvas here */}</div>

      {/* HUD Overlay (read-only data from Trinity Core) */}
      <div className="absolute top-4 left-4 bg-zinc-900/80 backdrop-blur-sm border border-zinc-700 rounded-lg p-4 text-xs text-zinc-400">
        <div className="space-y-1">
          <div className="text-zinc-500 uppercase tracking-wider text-[10px]">Trinity Mount</div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-zinc-300">{patchId}</span>
          </div>
          <div className="pt-2 border-t border-zinc-800 mt-2 space-y-1">
            <div>
              Realm: <span className="text-zinc-300">{realmId}</span>
            </div>
            <div>
              Floor: <span className="text-zinc-300">{kind}</span>
            </div>
            <div>
              Grid:{" "}
              <span className="text-zinc-300">
                {floorData.gridSize}x{floorData.gridSize}
              </span>
            </div>
            <div>
              Portals: <span className="text-zinc-300">{floorData.portalCount}</span>
            </div>
            <div>
              NPCs: <span className="text-zinc-300">{floorData.npcCount}</span>
            </div>
            <div>
              Games: <span className="text-zinc-300">{floorData.gameNodeCount}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Hotspot markers (supplied by Trinity Core) */}
      <div className="absolute inset-0 pointer-events-none">
        {consumer && (
          <HotspotOverlay
            portals={consumer.getPortalRefs()}
            npcs={consumer.getNpcRefs()}
            gameNodes={consumer.getGameNodeRefs()}
          />
        )}
      </div>
    </div>
  )
}

/**
 * Hotspot Overlay - renders interactive markers for portals, NPCs, and game nodes
 */
function HotspotOverlay({
  portals,
  npcs,
  gameNodes,
}: {
  portals: readonly string[]
  npcs: readonly string[]
  gameNodes: readonly string[]
}) {
  return (
    <div className="relative w-full h-full">
      {/* Portal hotspots */}
      {portals.map((ref, i) => (
        <div
          key={ref}
          className="absolute w-4 h-4 bg-blue-500/50 rounded-full border border-blue-400 pointer-events-auto cursor-pointer hover:scale-125 transition-transform"
          style={{
            left: `${20 + i * 15}%`,
            top: `${30 + (i % 3) * 20}%`,
          }}
          title={`Portal: ${ref}`}
        />
      ))}

      {/* NPC hotspots */}
      {npcs.map((ref, i) => (
        <div
          key={ref}
          className="absolute w-4 h-4 bg-green-500/50 rounded-full border border-green-400 pointer-events-auto cursor-pointer hover:scale-125 transition-transform"
          style={{
            left: `${30 + i * 15}%`,
            top: `${40 + (i % 3) * 20}%`,
          }}
          title={`NPC: ${ref}`}
        />
      ))}

      {/* Game node hotspots */}
      {gameNodes.map((ref, i) => (
        <div
          key={ref}
          className="absolute w-4 h-4 bg-purple-500/50 rounded-full border border-purple-400 pointer-events-auto cursor-pointer hover:scale-125 transition-transform"
          style={{
            left: `${40 + i * 15}%`,
            top: `${50 + (i % 3) * 20}%`,
          }}
          title={`Game: ${ref}`}
        />
      ))}
    </div>
  )
}
