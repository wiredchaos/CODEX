// ╔═══════════════════════════════════════════════════════════════════════════════╗
// ║                    AKIRA CODEX — STATUS ROUTE HANDLER                         ║
// ╚═══════════════════════════════════════════════════════════════════════════════╝

import { NextResponse } from "next/server"
import { akiraCodexAPI } from "@/lib/akira-codex"

export async function GET() {
  const response = akiraCodexAPI.getStatus()
  return NextResponse.json(response)
}
