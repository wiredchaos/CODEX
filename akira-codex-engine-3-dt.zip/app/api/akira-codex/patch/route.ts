// ╔═══════════════════════════════════════════════════════════════════════════════╗
// ║                    AKIRA CODEX — PATCH ROUTE HANDLER                          ║
// ║           External systems communicate ONLY through this endpoint             ║
// ╚═══════════════════════════════════════════════════════════════════════════════╝

import { NextResponse } from "next/server"
import { akiraCodexAPI } from "@/lib/akira-codex"
import type { PatchRequest } from "@/lib/akira-codex"

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as PatchRequest
    const response = akiraCodexAPI.handlePatch(body)

    return NextResponse.json(response, {
      status: response.success ? 200 : 403,
    })
  } catch {
    return NextResponse.json(
      {
        success: false,
        error: { code: "INVALID_REQUEST", message: "Invalid patch request format" },
        meta: { system: "AKIRA_CODEX", version: "2.0.0", timestamp: new Date() },
      },
      { status: 400 },
    )
  }
}
