// ╔═══════════════════════════════════════════════════════════════════════════════╗
// ║                  AKIRA CODEX — STORY SEED ROUTE HANDLER                       ║
// ╚═══════════════════════════════════════════════════════════════════════════════╝

import { NextResponse } from "next/server"
import { akiraCodexAPI } from "@/lib/akira-codex"
import type { AkiraContentTier, NarrativeTone } from "@/lib/akira-codex"

export async function POST(request: Request) {
  try {
    const { concept, tier, tone } = (await request.json()) as {
      concept: string
      tier: AkiraContentTier
      tone: NarrativeTone
    }

    const response = await akiraCodexAPI.createStorySeed(concept, tier, tone)

    return NextResponse.json(response, {
      status: response.success ? 200 : 500,
    })
  } catch {
    return NextResponse.json(
      {
        success: false,
        error: { code: "SEED_ERROR", message: "Failed to create story seed" },
        meta: { system: "AKIRA_CODEX", version: "2.0.0", timestamp: new Date() },
      },
      { status: 500 },
    )
  }
}
