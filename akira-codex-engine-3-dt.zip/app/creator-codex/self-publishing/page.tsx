"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"

interface PublishDestinations {
  paragraph: boolean
  cbe: boolean
  clear: boolean
}

interface PublishReceipt {
  destination: string
  status: "success" | "error"
  message: string
  url?: string
  timestamp: string
}

export default function SelfPublishingPage() {
  const [title, setTitle] = useState("")
  const [body, setBody] = useState("")
  const [excerpt, setExcerpt] = useState("")
  const [coverImageUrl, setCoverImageUrl] = useState("")
  const [tags, setTags] = useState("")
  const [destinations, setDestinations] = useState<PublishDestinations>({
    paragraph: false,
    cbe: false,
    clear: false,
  })
  const [isPublishing, setIsPublishing] = useState(false)
  const [receipts, setReceipts] = useState<PublishReceipt[]>([])

  const handlePublish = async () => {
    if (!title || !body) {
      setReceipts([
        {
          destination: "validation",
          status: "error",
          message: "Title and body are required",
          timestamp: new Date().toISOString(),
        },
      ])
      return
    }

    const selectedDestinations = Object.entries(destinations)
      .filter(([_, enabled]) => enabled)
      .map(([dest]) => dest)

    if (selectedDestinations.length === 0) {
      setReceipts([
        {
          destination: "validation",
          status: "error",
          message: "Please select at least one publishing destination",
          timestamp: new Date().toISOString(),
        },
      ])
      return
    }

    setIsPublishing(true)
    setReceipts([])

    try {
      const response = await fetch("/api/creator-codex/publish", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          body,
          excerpt,
          coverImageUrl,
          tags: tags
            .split(",")
            .map((t) => t.trim())
            .filter(Boolean),
          destinations: selectedDestinations,
        }),
      })

      const data = await response.json()

      if (response.ok) {
        setReceipts(data.receipts || [])
      } else {
        setReceipts([
          {
            destination: "api",
            status: "error",
            message: data.error || "Publishing failed",
            timestamp: new Date().toISOString(),
          },
        ])
      }
    } catch (error) {
      setReceipts([
        {
          destination: "network",
          status: "error",
          message: error instanceof Error ? error.message : "Network error",
          timestamp: new Date().toISOString(),
        },
      ])
    } finally {
      setIsPublishing(false)
    }
  }

  return (
    <div className="relative min-h-screen bg-background">
      {/* Trinity Environment Mount Container */}
      <div id="trinity-mount" className="absolute inset-0 pointer-events-none" aria-hidden="true">
        {/* Trinity 3D Core will mount here if available */}
      </div>

      {/* Glass HUD Overlay */}
      <div className="relative z-10 min-h-screen p-6">
        <div className="mx-auto max-w-5xl">
          {/* Header */}
          <div className="mb-8 rounded-lg border border-border/50 bg-card/40 p-6 backdrop-blur-xl">
            <h1 className="mb-2 font-mono text-3xl font-bold tracking-tight text-[color:var(--codex-gold)]">
              CREATOR CODEX
            </h1>
            <p className="font-mono text-sm text-muted-foreground">
              Authoring & Publishing Layer (Canon governed by Akira Codex)
            </p>
            <p className="mt-2 font-mono text-xs text-muted-foreground">
              Self-Publishing Swarm • Trinity-Mounted Publishing Bay
            </p>
          </div>

          <div className="grid gap-6 lg:grid-cols-3">
            {/* Publishing Form */}
            <div className="space-y-6 lg:col-span-2">
              <div className="rounded-lg border border-border/50 bg-card/40 p-6 backdrop-blur-xl">
                <h2 className="mb-4 font-mono text-lg font-semibold text-foreground">Content Editor</h2>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="title" className="font-mono text-sm">
                      Title *
                    </Label>
                    <Input
                      id="title"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      className="mt-1.5 border-border/50 bg-input/80 font-mono backdrop-blur"
                      placeholder="Enter title..."
                    />
                  </div>

                  <div>
                    <Label htmlFor="body" className="font-mono text-sm">
                      Body *
                    </Label>
                    <Textarea
                      id="body"
                      value={body}
                      onChange={(e) => setBody(e.target.value)}
                      className="mt-1.5 min-h-[300px] border-border/50 bg-input/80 font-mono text-sm leading-relaxed backdrop-blur"
                      placeholder="Write your content here..."
                    />
                  </div>

                  <div>
                    <Label htmlFor="excerpt" className="font-mono text-sm">
                      Excerpt
                    </Label>
                    <Textarea
                      id="excerpt"
                      value={excerpt}
                      onChange={(e) => setExcerpt(e.target.value)}
                      className="mt-1.5 min-h-[80px] border-border/50 bg-input/80 font-mono text-sm backdrop-blur"
                      placeholder="Optional excerpt or summary..."
                    />
                  </div>

                  <div>
                    <Label htmlFor="coverImageUrl" className="font-mono text-sm">
                      Cover Image URL
                    </Label>
                    <Input
                      id="coverImageUrl"
                      value={coverImageUrl}
                      onChange={(e) => setCoverImageUrl(e.target.value)}
                      className="mt-1.5 border-border/50 bg-input/80 font-mono backdrop-blur"
                      placeholder="https://..."
                    />
                  </div>

                  <div>
                    <Label htmlFor="tags" className="font-mono text-sm">
                      Tags
                    </Label>
                    <Input
                      id="tags"
                      value={tags}
                      onChange={(e) => setTags(e.target.value)}
                      className="mt-1.5 border-border/50 bg-input/80 font-mono backdrop-blur"
                      placeholder="tag1, tag2, tag3"
                    />
                    <p className="mt-1 font-mono text-xs text-muted-foreground">Comma-separated</p>
                  </div>
                </div>
              </div>

              {/* Destinations */}
              <div className="rounded-lg border border-border/50 bg-card/40 p-6 backdrop-blur-xl">
                <h2 className="mb-4 font-mono text-lg font-semibold text-foreground">Publishing Destinations</h2>

                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <Checkbox
                      id="paragraph"
                      checked={destinations.paragraph}
                      onCheckedChange={(checked) =>
                        setDestinations((prev) => ({
                          ...prev,
                          paragraph: checked === true,
                        }))
                      }
                    />
                    <Label htmlFor="paragraph" className="cursor-pointer font-mono text-sm">
                      Publish to Paragraph
                    </Label>
                  </div>

                  <div className="flex items-center space-x-3">
                    <Checkbox
                      id="cbe"
                      checked={destinations.cbe}
                      onCheckedChange={(checked) =>
                        setDestinations((prev) => ({
                          ...prev,
                          cbe: checked === true,
                        }))
                      }
                    />
                    <Label htmlFor="cbe" className="cursor-pointer font-mono text-sm">
                      Publish to CBE
                    </Label>
                  </div>

                  <div className="flex items-center space-x-3">
                    <Checkbox
                      id="clear"
                      checked={destinations.clear}
                      onCheckedChange={(checked) =>
                        setDestinations((prev) => ({
                          ...prev,
                          clear: checked === true,
                        }))
                      }
                    />
                    <Label htmlFor="clear" className="cursor-pointer font-mono text-sm">
                      Publish to CLEAR
                    </Label>
                  </div>
                </div>

                <Button
                  onClick={handlePublish}
                  disabled={isPublishing}
                  className="mt-6 w-full bg-[color:var(--codex-gold)] font-mono font-semibold text-[color:var(--codex-gold-dim)] hover:bg-[color:var(--codex-gold)]/90"
                >
                  {isPublishing ? "Publishing..." : "Publish"}
                </Button>
              </div>
            </div>

            {/* Status Panel */}
            <div className="lg:col-span-1">
              <div className="sticky top-6 rounded-lg border border-border/50 bg-card/40 p-6 backdrop-blur-xl">
                <h2 className="mb-4 font-mono text-lg font-semibold text-foreground">Status</h2>

                {receipts.length === 0 ? (
                  <p className="font-mono text-sm text-muted-foreground">
                    No receipts yet. Configure and publish to see results.
                  </p>
                ) : (
                  <div className="space-y-3">
                    {receipts.map((receipt, index) => (
                      <div
                        key={index}
                        className={`rounded border p-3 ${
                          receipt.status === "success"
                            ? "border-[color:var(--codex-secure)]/50 bg-[color:var(--codex-secure)]/10"
                            : "border-[color:var(--codex-error)]/50 bg-[color:var(--codex-error)]/10"
                        }`}
                      >
                        <div className="mb-1 flex items-center justify-between">
                          <span className="font-mono text-xs font-semibold uppercase">{receipt.destination}</span>
                          <span
                            className={`font-mono text-xs ${
                              receipt.status === "success"
                                ? "text-[color:var(--codex-secure)]"
                                : "text-[color:var(--codex-error)]"
                            }`}
                          >
                            {receipt.status}
                          </span>
                        </div>
                        <p className="font-mono text-xs text-foreground/80">{receipt.message}</p>
                        {receipt.url && (
                          <a
                            href={receipt.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="mt-1 inline-block font-mono text-xs text-[color:var(--codex-gold)] underline"
                          >
                            View
                          </a>
                        )}
                        <p className="mt-1 font-mono text-xs text-muted-foreground">
                          {new Date(receipt.timestamp).toLocaleTimeString()}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
