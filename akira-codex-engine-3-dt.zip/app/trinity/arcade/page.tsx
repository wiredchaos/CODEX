import { EnvironmentRenderer } from "@/components/trinity/EnvironmentRenderer"

export default function TrinityArcadePage() {
  return (
    <div className="w-full h-screen">
      <EnvironmentRenderer
        patchId="CLEAR"
        kind="arcade"
        realmId="CHAOSPHERE"
        onMountError={(error) => {
          console.error("Trinity mount error:", error)
        }}
      />
    </div>
  )
}
