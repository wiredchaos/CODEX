import { EnvironmentRenderer } from "@/components/trinity/EnvironmentRenderer"

export default function TrinityLobbyPage() {
  return (
    <div className="w-full h-screen">
      <EnvironmentRenderer
        patchId="CLEAR"
        kind="lobby"
        realmId="ECHO"
        onMountError={(error) => {
          console.error("Trinity mount error:", error)
        }}
      />
    </div>
  )
}
