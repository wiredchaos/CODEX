import type React from "react"
import Link from "next/link"
import { Shield, Cpu, BookOpen, Map, Clock, Users, Scroll, Terminal } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* System Header */}
      <header className="border-b border-border/50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-codex-secure animate-pulse" />
                <span className="font-mono text-xs text-muted-foreground">SYSTEM ONLINE</span>
              </div>
            </div>
            <div className="flex items-center gap-6 font-mono text-xs text-muted-foreground">
              <span>
                STATUS: <span className="text-codex-secure">SECURE</span>
              </span>
              <span>
                FIREWALL: <span className="text-codex-gold">ACTIVE</span>
              </span>
              <span>
                VERSION: <span className="text-foreground">2.0.0</span>
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-12">
        {/* Identity Block */}
        <div className="mb-16">
          <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-8">
            <div>
              <p className="font-mono text-xs text-codex-gold mb-4">ISOLATED NARRATIVE OPERATING SYSTEM</p>
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight text-foreground mb-4">
                AKIRA CODEX
              </h1>
              <p className="text-lg text-muted-foreground max-w-xl">
                Standalone narrative engine. Firewalled from all external systems. Communication via PATCH_REQUEST_ONLY.
              </p>
            </div>
            <div className="flex flex-col gap-2 font-mono text-xs">
              <div className="flex justify-between gap-8">
                <span className="text-muted-foreground">OPERATING SINCE:</span>
                <span className="text-foreground">2025</span>
              </div>
              <div className="flex justify-between gap-8">
                <span className="text-muted-foreground">MODE:</span>
                <span className="text-codex-gold">STORY_ENGINE_ACTIVE</span>
              </div>
              <div className="flex justify-between gap-8">
                <span className="text-muted-foreground">CURRENT POV:</span>
                <span className="text-foreground">AKIRA</span>
              </div>
              <div className="flex justify-between gap-8">
                <span className="text-muted-foreground">LORE CONTEXT:</span>
                <span className="text-codex-terminal">MEROVINGIAN / NETERU</span>
              </div>
            </div>
          </div>
        </div>

        {/* Firewall Status */}
        <div className="mb-12 p-4 border border-codex-gold/30 bg-codex-gold/5 rounded-lg">
          <div className="flex items-center gap-3 mb-3">
            <Shield className="h-5 w-5 text-codex-gold" />
            <span className="font-mono text-sm text-codex-gold">FIREWALL DECLARATION</span>
          </div>
          <div className="font-mono text-xs text-muted-foreground">
            <p className="mb-2">BLOCKED NAMESPACES:</p>
            <div className="flex flex-wrap gap-2">
              {["CHAOS_OS", "WIRED_CHAOS_META", "NPC_ENGINE", "CREATOR_CODEX", "789_STUDIOS"].map((ns) => (
                <span key={ns} className="px-2 py-1 bg-destructive/20 text-destructive rounded text-xs">
                  {ns}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Module Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
          <Link href="/akira-codex" className="group">
            <ModuleCard
              icon={<Cpu className="h-6 w-6" />}
              title="Dashboard"
              description="System overview and controls"
              status="ACTIVE"
            />
          </Link>
          <Link href="/akira-codex/story" className="group">
            <ModuleCard
              icon={<BookOpen className="h-6 w-6" />}
              title="Story Engine"
              description="Generate → Expand → Publish"
              status="READY"
            />
          </Link>
          <Link href="/akira-codex/missions" className="group">
            <ModuleCard
              icon={<Map className="h-6 w-6" />}
              title="Mission Board"
              description="Quest management system"
              status="READY"
            />
          </Link>
          <Link href="/akira-codex/timeline" className="group">
            <ModuleCard
              icon={<Clock className="h-6 w-6" />}
              title="Timeline"
              description="Chronological events"
              status="READY"
            />
          </Link>
          <Link href="/akira-codex/graph" className="group">
            <ModuleCard
              icon={<Terminal className="h-6 w-6" />}
              title="Narrative Graph"
              description="Story node visualization"
              status="READY"
            />
          </Link>
          <Link href="/akira-codex/pov" className="group">
            <ModuleCard
              icon={<Users className="h-6 w-6" />}
              title="POV Engine"
              description="Akira vs Neteru perspectives"
              status="READY"
            />
          </Link>
          <Link href="/akira-codex/lore" className="group">
            <ModuleCard
              icon={<Scroll className="h-6 w-6" />}
              title="Lore Browser"
              description="Mythology integration"
              status="READY"
            />
          </Link>
          <Link href="/akira-codex/agents" className="group">
            <ModuleCard
              icon={<Cpu className="h-6 w-6" />}
              title="Agent Writer"
              description="AI composition layer"
              status="READY"
            />
          </Link>
        </div>

        {/* System Info */}
        <div className="border-t border-border/50 pt-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 font-mono text-xs">
            <div>
              <p className="text-muted-foreground mb-1">SYSTEM</p>
              <p className="text-foreground">AKIRA_CODEX</p>
            </div>
            <div>
              <p className="text-muted-foreground mb-1">ISOLATION</p>
              <p className="text-codex-secure">FULL</p>
            </div>
            <div>
              <p className="text-muted-foreground mb-1">PROTOCOL</p>
              <p className="text-codex-gold">PATCH_REQUEST_ONLY</p>
            </div>
            <div>
              <p className="text-muted-foreground mb-1">BUILD</p>
              <p className="text-foreground">NARRATIVE_OS</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

function ModuleCard({
  icon,
  title,
  description,
  status,
}: {
  icon: React.ReactNode
  title: string
  description: string
  status: "ACTIVE" | "READY" | "LOCKED"
}) {
  return (
    <div className="p-6 border border-border bg-card rounded-lg transition-all group-hover:border-codex-gold/50 group-hover:bg-card/80">
      <div className="flex items-start justify-between mb-4">
        <div className="text-muted-foreground group-hover:text-codex-gold transition-colors">{icon}</div>
        <span
          className={`font-mono text-xs ${
            status === "ACTIVE" ? "text-codex-secure" : status === "READY" ? "text-codex-gold" : "text-muted-foreground"
          }`}
        >
          {status}
        </span>
      </div>
      <h3 className="font-semibold text-foreground mb-1">{title}</h3>
      <p className="text-sm text-muted-foreground">{description}</p>
    </div>
  )
}
