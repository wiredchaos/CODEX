import { Suspense } from "react"
import { BooksGrid } from "@/components/books/books-grid"
import { BooksHeader } from "@/components/books/books-header"
import { BooksSkeleton } from "@/components/books/books-skeleton"

export const metadata = {
  title: "Creator Codex — Book Library",
  description: "AI-generated mini-novellas with age-gated content tiers",
}

export default function BooksPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Neon glass background effects */}
      <div className="fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute -top-1/2 -left-1/2 h-full w-full rounded-full bg-cyan-500/10 blur-3xl" />
        <div className="absolute -right-1/4 -bottom-1/4 h-3/4 w-3/4 rounded-full bg-fuchsia-500/10 blur-3xl" />
        <div className="absolute top-1/4 right-1/3 h-1/2 w-1/2 rounded-full bg-violet-500/5 blur-3xl" />
      </div>

      <main className="container mx-auto px-4 py-12">
        <BooksHeader />
        <Suspense fallback={<BooksSkeleton />}>
          <BooksGrid />
        </Suspense>
      </main>
    </div>
  )
}
