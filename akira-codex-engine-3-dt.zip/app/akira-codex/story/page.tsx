"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, BookOpen, Sparkles, Loader2, Eye } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"

export default function StoryEnginePage() {
  const [concept, setConcept] = useState("")
  const [tier, setTier] = useState<"LIGHT" | "SHADOW" | "VEIL">("SHADOW")
  const [tone, setTone] = useState<string>("MYTHIC")
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedSeed, setGeneratedSeed] = useState<{
    title: string
    logline: string
    protagonist: string
    antagonist: string
    setting: string
  } | null>(null)

  const handleGenerate = async () => {
    if (!concept.trim()) return
    setIsGenerating(true)

    // Simulate generation
    await new Promise((resolve) => setTimeout(resolve, 2000))

    setGeneratedSeed({
      title: "The Merovingian Cipher",
      logline:
        "When a cryptographer discovers her bloodline carries memories older than written history, she must decode the symbols appearing in her dreams before an ancient order silences her forever.",
      protagonist: "Elara Vance — The Seeker — Driven by truth, haunted by doubt",
      antagonist: "The Veil Keeper — The Shadow — Motivated by preservation through control",
      setting:
        "Neo-Alexandria, 2089 — A city built on the ruins of ancient libraries, where holographic archives intersect with forgotten catacombs.",
    })

    setIsGenerating(false)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 sticky top-0 bg-background/95 backdrop-blur z-50">
        <div className="container mx-auto px-6 py-3">
          <div className="flex items-center gap-4">
            <Link href="/akira-codex">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Dashboard
              </Button>
            </Link>
            <div className="h-6 w-px bg-border" />
            <div className="flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-codex-gold" />
              <span className="font-mono text-sm font-semibold text-foreground">STORY ENGINE</span>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input Panel */}
          <div className="space-y-6">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-sm font-mono text-muted-foreground flex items-center gap-2">
                  <Sparkles className="h-4 w-4" />
                  SEED GENERATION
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="concept" className="font-mono text-xs text-muted-foreground">
                    STORY CONCEPT
                  </Label>
                  <Textarea
                    id="concept"
                    placeholder="Enter your story concept..."
                    value={concept}
                    onChange={(e) => setConcept(e.target.value)}
                    className="min-h-[120px] font-mono text-sm bg-input border-border"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="font-mono text-xs text-muted-foreground">CONTENT TIER</Label>
                    <Select value={tier} onValueChange={(v: "LIGHT" | "SHADOW" | "VEIL") => setTier(v)}>
                      <SelectTrigger className="font-mono text-sm">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="LIGHT">LIGHT — All Ages</SelectItem>
                        <SelectItem value="SHADOW">SHADOW — Mature</SelectItem>
                        <SelectItem value="VEIL">VEIL — 21+ Symbolic</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="font-mono text-xs text-muted-foreground">NARRATIVE TONE</Label>
                    <Select value={tone} onValueChange={setTone}>
                      <SelectTrigger className="font-mono text-sm">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="MYTHIC">MYTHIC</SelectItem>
                        <SelectItem value="INTIMATE">INTIMATE</SelectItem>
                        <SelectItem value="NOIR">NOIR</SelectItem>
                        <SelectItem value="HOPEFUL">HOPEFUL</SelectItem>
                        <SelectItem value="CHAOTIC">CHAOTIC</SelectItem>
                        <SelectItem value="SACRED">SACRED</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Button
                  onClick={handleGenerate}
                  disabled={!concept.trim() || isGenerating}
                  className="w-full bg-codex-gold text-primary-foreground hover:bg-codex-gold/90"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Generating Seed...
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4 mr-2" />
                      Generate Story Seed
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Tier Rules */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-sm font-mono text-muted-foreground">TIER RULES — {tier}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 font-mono text-xs text-muted-foreground">
                  {tier === "LIGHT" && (
                    <>
                      <p>• All ages appropriate content</p>
                      <p>• No violence beyond mild conflict</p>
                      <p>• Focus on wonder, discovery, friendship</p>
                    </>
                  )}
                  {tier === "SHADOW" && (
                    <>
                      <p>• Mature themes permitted</p>
                      <p>• Violence can be intense but purposeful</p>
                      <p>• Fade-to-black for intimate scenes</p>
                    </>
                  )}
                  {tier === "VEIL" && (
                    <>
                      <p>• 21+ symbolic content only</p>
                      <p>• Metaphorical/poetic intimacy</p>
                      <p>• NO explicit anatomical detail</p>
                      <p>• Shadow-veil language required</p>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Output Panel */}
          <div className="space-y-6">
            {generatedSeed ? (
              <Card className="border-codex-gold/30 bg-card">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-mono text-codex-gold flex items-center gap-2">
                      GENERATED SEED
                    </CardTitle>
                    <div className="flex gap-2">
                      <Badge variant="outline" className="font-mono text-xs">
                        {tier}
                      </Badge>
                      <Badge variant="outline" className="font-mono text-xs text-codex-terminal">
                        {tone}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h2 className="text-2xl font-bold text-foreground mb-2">{generatedSeed.title}</h2>
                    <p className="text-muted-foreground">{generatedSeed.logline}</p>
                  </div>

                  <div className="space-y-3 pt-4 border-t border-border">
                    <div>
                      <Label className="font-mono text-xs text-muted-foreground">PROTAGONIST</Label>
                      <p className="text-sm text-foreground mt-1">{generatedSeed.protagonist}</p>
                    </div>
                    <div>
                      <Label className="font-mono text-xs text-muted-foreground">ANTAGONIST</Label>
                      <p className="text-sm text-foreground mt-1">{generatedSeed.antagonist}</p>
                    </div>
                    <div>
                      <Label className="font-mono text-xs text-muted-foreground">SETTING</Label>
                      <p className="text-sm text-foreground mt-1">{generatedSeed.setting}</p>
                    </div>
                  </div>

                  <div className="flex gap-3 pt-4">
                    <Button className="flex-1 bg-codex-gold text-primary-foreground hover:bg-codex-gold/90">
                      <BookOpen className="h-4 w-4 mr-2" />
                      Expand to Story
                    </Button>
                    <Button variant="outline" className="flex-1 bg-transparent">
                      <Eye className="h-4 w-4 mr-2" />
                      Preview
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="border-border bg-card h-full min-h-[400px] flex items-center justify-center">
                <div className="text-center text-muted-foreground">
                  <BookOpen className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p className="font-mono text-sm">Enter a concept and generate a seed</p>
                  <p className="font-mono text-xs mt-2">
                    The story engine will create structure, characters, and setting
                  </p>
                </div>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
