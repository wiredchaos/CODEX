"use client"

import Link from "next/link"
import { ArrowLeft, Map, CheckCircle, Circle, Lock, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

const MISSIONS = [
  {
    id: "1",
    type: "MAIN_QUEST",
    title: "Complete: The Merovingian Cipher",
    briefing:
      "When a cryptographer discovers her bloodline carries memories older than written history, she must decode the symbols appearing in her dreams before an ancient order silences her forever.",
    status: "ACTIVE",
    progress: 40,
    objectives: [
      { text: "Read Chapter 1: The First Dream", complete: true },
      { text: "Read Chapter 2: Signs in the Noise", complete: true },
      { text: "Read Chapter 3: The Bloodline", complete: false },
      { text: "Read Chapter 4: Convergence", complete: false },
      { text: "Read Chapter 5: The Cipher Revealed", complete: false },
    ],
    rewards: ["Story Completion", "Lore Unlocked"],
  },
  {
    id: "2",
    type: "CHARACTER_ARC",
    title: "Understand: Elara Vance",
    briefing: "Follow the journey of Elara Vance, the Seeker. Motivation: Truth. Flaw: Doubt.",
    status: "LOCKED",
    progress: 0,
    objectives: [
      { text: "Discover the protagonist's origin", complete: false },
      { text: "Witness the defining choice", complete: false },
      { text: "Understand the fatal flaw", complete: false },
    ],
    rewards: ["Character Insight", "Seeker Archetype Unlocked"],
  },
  {
    id: "3",
    type: "LORE_FRAGMENT",
    title: "Lore: The Neteru Connection",
    briefing: "Explore the NETERU connection: Ancient watchers guide the bloodline through dreams.",
    status: "AVAILABLE",
    progress: 0,
    objectives: [{ text: "Uncover the NETERU reference", complete: false }],
    rewards: ["NETERU Lore Entry"],
  },
  {
    id: "4",
    type: "LORE_FRAGMENT",
    title: "Lore: 589 Resonance",
    briefing: "Explore the 589_THEORY connection: Numbers appear in patterns that unlock memory.",
    status: "AVAILABLE",
    progress: 0,
    objectives: [{ text: "Uncover the 589_THEORY reference", complete: false }],
    rewards: ["589_THEORY Lore Entry"],
  },
]

export default function MissionBoardPage() {
  const activeMission = MISSIONS.find((m) => m.status === "ACTIVE")
  const availableMissions = MISSIONS.filter((m) => m.status === "AVAILABLE")
  const lockedMissions = MISSIONS.filter((m) => m.status === "LOCKED")

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 sticky top-0 bg-background/95 backdrop-blur z-50">
        <div className="container mx-auto px-6 py-3">
          <div className="flex items-center gap-4">
            <Link href="/akira-codex">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Dashboard
              </Button>
            </Link>
            <div className="h-6 w-px bg-border" />
            <div className="flex items-center gap-2">
              <Map className="h-5 w-5 text-codex-gold" />
              <span className="font-mono text-sm font-semibold text-foreground">MISSION BOARD</span>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        {/* Active Mission */}
        {activeMission && (
          <div className="mb-8">
            <h2 className="font-mono text-xs text-codex-gold mb-4 flex items-center gap-2">
              <Star className="h-4 w-4" />
              ACTIVE MISSION
            </h2>
            <Card className="border-codex-gold/30 bg-card">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <Badge className="font-mono text-xs mb-2 bg-codex-gold text-primary-foreground">
                      {activeMission.type.replace("_", " ")}
                    </Badge>
                    <CardTitle className="text-xl text-foreground">{activeMission.title}</CardTitle>
                  </div>
                  <span className="font-mono text-2xl font-bold text-codex-gold">{activeMission.progress}%</span>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground">{activeMission.briefing}</p>

                <Progress value={activeMission.progress} className="h-2" />

                <div className="space-y-2">
                  <p className="font-mono text-xs text-muted-foreground">OBJECTIVES:</p>
                  {activeMission.objectives.map((obj, i) => (
                    <div key={i} className="flex items-center gap-2">
                      {obj.complete ? (
                        <CheckCircle className="h-4 w-4 text-codex-secure" />
                      ) : (
                        <Circle className="h-4 w-4 text-muted-foreground" />
                      )}
                      <span
                        className={`text-sm ${obj.complete ? "text-muted-foreground line-through" : "text-foreground"}`}
                      >
                        {obj.text}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="pt-4 border-t border-border">
                  <p className="font-mono text-xs text-muted-foreground mb-2">REWARDS:</p>
                  <div className="flex gap-2">
                    {activeMission.rewards.map((reward, i) => (
                      <Badge key={i} variant="outline" className="font-mono text-xs">
                        {reward}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Available Missions */}
        <div className="mb-8">
          <h2 className="font-mono text-xs text-muted-foreground mb-4">AVAILABLE MISSIONS</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {availableMissions.map((mission) => (
              <Card
                key={mission.id}
                className="border-border bg-card hover:border-codex-gold/50 transition-all cursor-pointer"
              >
                <CardContent className="p-4">
                  <Badge variant="outline" className="font-mono text-xs mb-2 text-codex-terminal">
                    {mission.type.replace("_", " ")}
                  </Badge>
                  <h3 className="font-semibold text-foreground mb-1">{mission.title}</h3>
                  <p className="text-sm text-muted-foreground line-clamp-2">{mission.briefing}</p>
                  <div className="flex gap-2 mt-3">
                    {mission.rewards.map((reward, i) => (
                      <Badge key={i} variant="secondary" className="font-mono text-xs">
                        {reward}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Locked Missions */}
        <div>
          <h2 className="font-mono text-xs text-muted-foreground mb-4 flex items-center gap-2">
            <Lock className="h-3 w-3" />
            LOCKED MISSIONS
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {lockedMissions.map((mission) => (
              <Card key={mission.id} className="border-border/50 bg-card/50 opacity-60">
                <CardContent className="p-4">
                  <Badge variant="outline" className="font-mono text-xs mb-2">
                    {mission.type.replace("_", " ")}
                  </Badge>
                  <h3 className="font-semibold text-foreground mb-1 flex items-center gap-2">
                    <Lock className="h-4 w-4" />
                    {mission.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">Complete prerequisites to unlock</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
