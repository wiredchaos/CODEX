"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Scroll, Search, BookOpen } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

const LORE_ENTRIES = {
  MEROVINGIAN: [
    {
      title: "The Bloodline of Kings",
      content:
        "The Merovingian lineage traces through shadow and light, a thread of royal blood that carries memories older than written history. They say the first Merovingian was born from a union between the mortal and the divine—a child of two worlds, belonging fully to neither.",
    },
    {
      title: "The Hidden Crown",
      content:
        "Not all crowns are worn upon the head. The Merovingian inheritance is a crown of consciousness—an awakening that comes unbidden, often in times of crisis.",
    },
  ],
  NETERU: [
    {
      title: "The Watchers",
      content:
        "Before humanity named the stars, the Neteru watched. They are not gods in the way mortals imagine—they do not demand worship or sacrifice. They are witnesses, archivists of existence itself.",
    },
    {
      title: "The Language of Light",
      content:
        "The Neteru communicate in frequencies beyond human hearing, in colors beyond human sight. Yet occasionally, they reach across the veil—through dreams, through synchronicities.",
    },
  ],
  "589_THEORY": [
    {
      title: "The Sacred Sequence",
      content:
        "5-8-9. Three numbers that appear again and again at the hinges of history. The 589 Theory posits that these numbers mark moments of convergence—points where multiple timelines brush against each other.",
    },
    {
      title: "Temporal Signatures",
      content:
        "Those attuned to the 589 frequency begin to notice: addresses, timestamps, page numbers, random sequences—all carrying the signature.",
    },
  ],
  AKASHIC: [
    {
      title: "The Memory Field",
      content:
        "The Akashic Record is not a library in any physical sense. It is a field—a resonance that preserves every thought, every action, every moment that has ever occurred.",
    },
    {
      title: "Past-Life Echoes",
      content:
        "The Akashic field explains why some memories feel borrowed—why certain places feel familiar on first visit, why certain people feel known before introduction.",
    },
  ],
  VEIL: [
    {
      title: "The Thin Places",
      content:
        "The Veil is not uniform—there are places where it wears thin, where the hidden realm bleeds through. Ancient temples, crossroads, mountain peaks, the hour before dawn.",
    },
    {
      title: "Veil-Walkers",
      content:
        "Some are born with the ability to part the Veil at will—Veil-Walkers, they are called. They move between the seen and unseen, gathering knowledge from both.",
    },
  ],
}

type LoreCategory = keyof typeof LORE_ENTRIES

export default function LoreBrowserPage() {
  const [activeCategory, setActiveCategory] = useState<LoreCategory>("MEROVINGIAN")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedEntry, setSelectedEntry] = useState<{ title: string; content: string } | null>(null)

  const categories = Object.keys(LORE_ENTRIES) as LoreCategory[]

  const filteredEntries = searchQuery
    ? Object.entries(LORE_ENTRIES).flatMap(([category, entries]) =>
        entries
          .filter(
            (e) =>
              e.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
              e.content.toLowerCase().includes(searchQuery.toLowerCase()),
          )
          .map((e) => ({ ...e, category })),
      )
    : LORE_ENTRIES[activeCategory].map((e) => ({ ...e, category: activeCategory }))

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 sticky top-0 bg-background/95 backdrop-blur z-50">
        <div className="container mx-auto px-6 py-3">
          <div className="flex items-center gap-4">
            <Link href="/akira-codex">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Dashboard
              </Button>
            </Link>
            <div className="h-6 w-px bg-border" />
            <div className="flex items-center gap-2">
              <Scroll className="h-5 w-5 text-codex-gold" />
              <span className="font-mono text-sm font-semibold text-foreground">LORE BROWSER</span>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        {/* Search */}
        <div className="mb-6">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search lore entries..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 font-mono text-sm bg-input border-border"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Categories & List */}
          <div className="lg:col-span-2 space-y-6">
            {!searchQuery && (
              <div className="flex flex-wrap gap-2">
                {categories.map((category) => (
                  <Button
                    key={category}
                    variant={activeCategory === category ? "default" : "outline"}
                    size="sm"
                    onClick={() => setActiveCategory(category)}
                    className={`font-mono text-xs ${
                      activeCategory === category ? "bg-codex-gold text-primary-foreground hover:bg-codex-gold/90" : ""
                    }`}
                  >
                    {category.replace("_", " ")}
                  </Button>
                ))}
              </div>
            )}

            <div className="space-y-4">
              {filteredEntries.map((entry, i) => (
                <Card
                  key={i}
                  className={`border-border bg-card cursor-pointer transition-all hover:border-codex-gold/50 ${
                    selectedEntry?.title === entry.title ? "border-codex-gold" : ""
                  }`}
                  onClick={() => setSelectedEntry(entry)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <h3 className="font-semibold text-foreground mb-1">{entry.title}</h3>
                        <p className="text-sm text-muted-foreground line-clamp-2">{entry.content}</p>
                      </div>
                      <Badge variant="outline" className="font-mono text-xs shrink-0 text-codex-terminal">
                        {entry.category.replace("_", " ")}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Detail Panel */}
          <div>
            {selectedEntry ? (
              <Card className="border-codex-gold/30 bg-card sticky top-24">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <Badge variant="outline" className="font-mono text-xs text-codex-terminal">
                      {(selectedEntry as { category: string }).category?.replace("_", " ")}
                    </Badge>
                  </div>
                  <CardTitle className="text-xl text-foreground mt-2">{selectedEntry.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground leading-relaxed">{selectedEntry.content}</p>
                  <div className="mt-6 pt-4 border-t border-border">
                    <Button variant="outline" size="sm" className="w-full bg-transparent">
                      <BookOpen className="h-4 w-4 mr-2" />
                      Use in Story
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="border-border bg-card h-64 flex items-center justify-center">
                <div className="text-center text-muted-foreground">
                  <Scroll className="h-8 w-8 mx-auto mb-3 opacity-50" />
                  <p className="font-mono text-sm">Select an entry to view details</p>
                </div>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
