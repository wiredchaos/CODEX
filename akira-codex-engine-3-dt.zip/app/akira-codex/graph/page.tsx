"use client"

import Link from "next/link"
import { ArrowLeft, Terminal } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const GRAPH_NODES = [
  { id: "protagonist", type: "CHARACTER", label: "Elara Vance", x: 50, y: 50 },
  { id: "antagonist", type: "CHARACTER", label: "The Veil Keeper", x: 75, y: 30 },
  { id: "setting", type: "LOCATION", label: "Neo-Alexandria", x: 25, y: 35 },
  { id: "ch1", type: "STORY_BEAT", label: "The First Dream", x: 35, y: 70 },
  { id: "ch2", type: "STORY_BEAT", label: "Signs in the Noise", x: 50, y: 80 },
  { id: "ch3", type: "STORY_BEAT", label: "The Bloodline", x: 65, y: 70 },
  { id: "lore1", type: "LORE_ENTRY", label: "Merovingian", x: 15, y: 60 },
  { id: "lore2", type: "LORE_ENTRY", label: "Neteru", x: 85, y: 55 },
]

const NODE_COLORS = {
  CHARACTER: "bg-codex-gold text-primary-foreground",
  LOCATION: "bg-codex-terminal text-primary-foreground",
  STORY_BEAT: "bg-primary text-primary-foreground",
  LORE_ENTRY: "bg-secondary text-secondary-foreground",
}

export default function NarrativeGraphPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 sticky top-0 bg-background/95 backdrop-blur z-50">
        <div className="container mx-auto px-6 py-3">
          <div className="flex items-center gap-4">
            <Link href="/akira-codex">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Dashboard
              </Button>
            </Link>
            <div className="h-6 w-px bg-border" />
            <div className="flex items-center gap-2">
              <Terminal className="h-5 w-5 text-codex-gold" />
              <span className="font-mono text-sm font-semibold text-foreground">NARRATIVE GRAPH</span>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Graph Visualization */}
          <div className="lg:col-span-3">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-sm font-mono text-muted-foreground">STORY NODE VISUALIZATION</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="relative h-[500px] bg-secondary/20 rounded-lg border border-border overflow-hidden">
                  {/* Connection lines (simplified) */}
                  <svg className="absolute inset-0 w-full h-full">
                    <line
                      x1="50%"
                      y1="50%"
                      x2="75%"
                      y2="30%"
                      stroke="currentColor"
                      className="text-border"
                      strokeWidth="1"
                    />
                    <line
                      x1="50%"
                      y1="50%"
                      x2="25%"
                      y2="35%"
                      stroke="currentColor"
                      className="text-border"
                      strokeWidth="1"
                    />
                    <line
                      x1="50%"
                      y1="50%"
                      x2="35%"
                      y2="70%"
                      stroke="currentColor"
                      className="text-codex-gold/50"
                      strokeWidth="1"
                    />
                    <line
                      x1="35%"
                      y1="70%"
                      x2="50%"
                      y2="80%"
                      stroke="currentColor"
                      className="text-codex-gold/50"
                      strokeWidth="1"
                    />
                    <line
                      x1="50%"
                      y1="80%"
                      x2="65%"
                      y2="70%"
                      stroke="currentColor"
                      className="text-codex-gold/50"
                      strokeWidth="1"
                    />
                    <line
                      x1="50%"
                      y1="50%"
                      x2="15%"
                      y2="60%"
                      stroke="currentColor"
                      className="text-border"
                      strokeDasharray="4"
                      strokeWidth="1"
                    />
                    <line
                      x1="50%"
                      y1="50%"
                      x2="85%"
                      y2="55%"
                      stroke="currentColor"
                      className="text-border"
                      strokeDasharray="4"
                      strokeWidth="1"
                    />
                  </svg>

                  {/* Nodes */}
                  {GRAPH_NODES.map((node) => (
                    <div
                      key={node.id}
                      className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer group"
                      style={{ left: `${node.x}%`, top: `${node.y}%` }}
                    >
                      <div
                        className={`px-3 py-2 rounded-lg text-xs font-mono transition-all group-hover:scale-110 ${NODE_COLORS[node.type as keyof typeof NODE_COLORS]}`}
                      >
                        {node.label}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Legend & Controls */}
          <div className="space-y-6">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-sm font-mono text-muted-foreground">NODE TYPES</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded bg-codex-gold" />
                  <span className="text-sm text-foreground">Character</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded bg-codex-terminal" />
                  <span className="text-sm text-foreground">Location</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded bg-primary" />
                  <span className="text-sm text-foreground">Story Beat</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded bg-secondary" />
                  <span className="text-sm text-foreground">Lore Entry</span>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-sm font-mono text-muted-foreground">GRAPH STATS</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 font-mono text-xs">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Total Nodes:</span>
                  <span className="text-foreground">{GRAPH_NODES.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Characters:</span>
                  <span className="text-codex-gold">2</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Story Beats:</span>
                  <span className="text-foreground">3</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Lore Links:</span>
                  <span className="text-codex-terminal">2</span>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-sm font-mono text-muted-foreground">CONNECTIONS</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-px bg-codex-gold" />
                  <span className="text-muted-foreground">Story Flow</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-px bg-border" />
                  <span className="text-muted-foreground">Relationship</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-px bg-border" style={{ borderStyle: "dashed" }} />
                  <span className="text-muted-foreground">Lore Reference</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
