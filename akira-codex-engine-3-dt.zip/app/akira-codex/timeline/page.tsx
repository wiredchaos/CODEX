"use client"

import Link from "next/link"
import { ArrowLeft, Clock, Circle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const TIMELINE_EVENTS = [
  {
    era: "Mythic Past",
    events: [
      {
        title: "The First Compact",
        description: "Neteru establish watch over the Merovingian bloodline",
        significance: "PIVOTAL",
      },
      {
        title: "The Cipher Created",
        description: "Symbols encoded into the bloodline's genetic memory",
        significance: "MAJOR",
      },
    ],
  },
  {
    era: "Ancient History",
    events: [
      { title: "The Scattering", description: "Bloodline disperses across continents", significance: "MAJOR" },
      {
        title: "The Keepers Emerge",
        description: "Order formed to monitor and control awakened bearers",
        significance: "MAJOR",
      },
    ],
  },
  {
    era: "Present Day",
    events: [
      {
        title: "Story Begins",
        description: "Elara Vance begins experiencing symbolic dreams",
        significance: "PIVOTAL",
      },
      {
        title: "Chapter 1: The First Dream",
        description: "Symbols appear that won't fade after waking",
        significance: "MAJOR",
      },
      {
        title: "Chapter 2: Signs in the Noise",
        description: "Patterns emerge in everyday data",
        significance: "MODERATE",
      },
      { title: "Chapter 3: The Bloodline", description: "Discovery of grandmother's journals", significance: "MAJOR" },
    ],
  },
  {
    era: "Future",
    events: [
      { title: "Chapter 4: Convergence", description: "To be written...", significance: "PENDING" },
      { title: "Chapter 5: The Cipher Revealed", description: "To be written...", significance: "PENDING" },
    ],
  },
]

export default function TimelinePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 sticky top-0 bg-background/95 backdrop-blur z-50">
        <div className="container mx-auto px-6 py-3">
          <div className="flex items-center gap-4">
            <Link href="/akira-codex">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Dashboard
              </Button>
            </Link>
            <div className="h-6 w-px bg-border" />
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-codex-gold" />
              <span className="font-mono text-sm font-semibold text-foreground">TIMELINE VIEWER</span>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8 max-w-4xl">
        <div className="space-y-12">
          {TIMELINE_EVENTS.map((era, eraIndex) => (
            <div key={eraIndex}>
              <div className="flex items-center gap-4 mb-6">
                <Badge
                  variant="outline"
                  className={`font-mono text-xs ${
                    era.era === "Present Day" ? "text-codex-gold border-codex-gold" : "text-muted-foreground"
                  }`}
                >
                  {era.era}
                </Badge>
                <div className="flex-1 h-px bg-border" />
              </div>

              <div className="relative">
                {/* Vertical line */}
                <div className="absolute left-4 top-0 bottom-0 w-px bg-border" />

                <div className="space-y-6">
                  {era.events.map((event, eventIndex) => (
                    <div key={eventIndex} className="relative pl-12">
                      {/* Node */}
                      <div
                        className={`absolute left-0 top-1 w-8 h-8 rounded-full flex items-center justify-center ${
                          event.significance === "PIVOTAL"
                            ? "bg-codex-gold/20 border-2 border-codex-gold"
                            : event.significance === "MAJOR"
                              ? "bg-codex-terminal/20 border-2 border-codex-terminal"
                              : event.significance === "PENDING"
                                ? "bg-muted border-2 border-muted-foreground/30"
                                : "bg-secondary border border-border"
                        }`}
                      >
                        <Circle
                          className={`h-3 w-3 ${
                            event.significance === "PIVOTAL"
                              ? "text-codex-gold fill-codex-gold"
                              : event.significance === "MAJOR"
                                ? "text-codex-terminal fill-codex-terminal"
                                : event.significance === "PENDING"
                                  ? "text-muted-foreground"
                                  : "text-foreground fill-foreground"
                          }`}
                        />
                      </div>

                      <Card className={`border-border bg-card ${event.significance === "PENDING" ? "opacity-50" : ""}`}>
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between gap-4">
                            <div>
                              <h3 className="font-semibold text-foreground mb-1">{event.title}</h3>
                              <p className="text-sm text-muted-foreground">{event.description}</p>
                            </div>
                            <Badge
                              variant="outline"
                              className={`font-mono text-xs shrink-0 ${
                                event.significance === "PIVOTAL"
                                  ? "text-codex-gold border-codex-gold"
                                  : event.significance === "MAJOR"
                                    ? "text-codex-terminal border-codex-terminal"
                                    : event.significance === "PENDING"
                                      ? "text-muted-foreground"
                                      : ""
                              }`}
                            >
                              {event.significance}
                            </Badge>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}
