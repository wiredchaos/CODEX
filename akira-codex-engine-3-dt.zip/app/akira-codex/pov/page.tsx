"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Users, Eye, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const POV_DATA = {
  AKIRA: {
    pronouns: ["I", "me", "my"],
    perspective: "First-person intimate — close to the protagonist's thoughts and feelings",
    emotionalRange: ["doubt", "determination", "wonder", "fear", "hope", "confusion"],
    narrativeStyle: "Immediate, sensory, emotionally raw. Present-tense energy even in past tense.",
    symbolism: ["light breaking through", "paths forking", "echoes of memory", "fire and renewal"],
    blindSpots: [
      "Cannot see antagonist's true motives",
      "Limited by subjective experience",
      "Unreliable in moments of stress",
    ],
    sample: `I knew the moment the dream ended something had changed. The symbols were still there when I opened my eyes—not fading like they should, but burned into my vision like afterimages of the sun. My hands shook as I reached for the notebook on my nightstand.

This wasn't supposed to happen. Dreams were just dreams. Neural noise. Random firings in a sleeping brain.

But these symbols... I'd seen them before. In my grandmother's journals. In the margins of her letters.`,
  },
  NETERU: {
    pronouns: ["we", "one", "the Watcher"],
    perspective: "Ancient observer — sees patterns across time, speaks in mythic register",
    emotionalRange: ["ancient sorrow", "cosmic patience", "veiled concern", "knowing amusement"],
    narrativeStyle: "Distant but not cold. Mythic cadence. Sees what mortals miss.",
    symbolism: ["stars wheeling", "rivers of time", "threads of fate", "shadows of what was"],
    blindSpots: ["Cannot fully understand mortal urgency", "Bound by cosmic laws", "Knowledge is not always wisdom"],
    sample: `We have watched this bloodline for seventeen generations. Each bearer of the cipher dreams differently—some in geometric precision, others in rushing water and fractured light. But this one, this Elara, dreams in the old way. The way the First Ones dreamed before the Veil thickened.

She does not yet know what stirs within her sleeping mind. She cannot see the threads that connect her to the ancient compact. But we see. We have always seen.

The Keepers move in shadow. They sense what we sense. The awakening begins.`,
  },
  OMNISCIENT: {
    pronouns: ["he", "she", "they", "the"],
    perspective: "Third-person omniscient — moves between minds and moments",
    emotionalRange: ["detached clarity", "ironic awareness", "compassionate distance"],
    narrativeStyle: "Fluid, moving between characters. Can zoom in or pull back.",
    symbolism: ["the web connecting all", "mirrors reflecting mirrors", "the space between heartbeats"],
    blindSpots: ["May feel less intimate", "Risk of emotional distance"],
    sample: `Elara woke to symbols she couldn't name but somehow knew. Three floors below, her neighbor—a man she'd never spoken to—deleted a surveillance photo of her window from his encrypted phone. Across the city, in a room lined with ancient manuscripts, a woman circled a date on her calendar: today.

None of them could see the full pattern. Not yet. But the pattern saw them.

It had been waiting for seventeen generations. It could wait a little longer.`,
  },
}

type POVMode = keyof typeof POV_DATA

export default function POVEnginePage() {
  const [activePOV, setActivePOV] = useState<POVMode>("AKIRA")
  const data = POV_DATA[activePOV]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 sticky top-0 bg-background/95 backdrop-blur z-50">
        <div className="container mx-auto px-6 py-3">
          <div className="flex items-center gap-4">
            <Link href="/akira-codex">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Dashboard
              </Button>
            </Link>
            <div className="h-6 w-px bg-border" />
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-codex-gold" />
              <span className="font-mono text-sm font-semibold text-foreground">POV ENGINE</span>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        {/* POV Selector */}
        <div className="flex gap-3 mb-8">
          {(Object.keys(POV_DATA) as POVMode[]).map((pov) => (
            <Button
              key={pov}
              size="lg"
              variant={activePOV === pov ? "default" : "outline"}
              onClick={() => setActivePOV(pov)}
              className={`font-mono flex-1 ${
                activePOV === pov ? "bg-codex-gold text-primary-foreground hover:bg-codex-gold/90" : ""
              }`}
            >
              {pov}
            </Button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Voice Details */}
          <div className="space-y-6">
            <Card className="border-codex-gold/30 bg-card">
              <CardHeader>
                <CardTitle className="text-sm font-mono text-codex-gold flex items-center gap-2">
                  <Eye className="h-4 w-4" />
                  {activePOV} VOICE
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="font-mono text-xs text-muted-foreground mb-2">PERSPECTIVE</p>
                  <p className="text-foreground">{data.perspective}</p>
                </div>

                <div>
                  <p className="font-mono text-xs text-muted-foreground mb-2">PRONOUNS</p>
                  <div className="flex gap-2">
                    {data.pronouns.map((p, i) => (
                      <Badge key={i} variant="outline" className="font-mono">
                        {p}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <p className="font-mono text-xs text-muted-foreground mb-2">NARRATIVE STYLE</p>
                  <p className="text-muted-foreground text-sm">{data.narrativeStyle}</p>
                </div>

                <div>
                  <p className="font-mono text-xs text-muted-foreground mb-2">EMOTIONAL RANGE</p>
                  <div className="flex flex-wrap gap-2">
                    {data.emotionalRange.map((e, i) => (
                      <Badge key={i} variant="secondary" className="font-mono text-xs">
                        {e}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-sm font-mono text-muted-foreground flex items-center gap-2">
                  <Zap className="h-4 w-4" />
                  SYMBOLISM
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {data.symbolism.map((s, i) => (
                    <Badge key={i} variant="outline" className="font-mono text-xs text-codex-terminal">
                      {s}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="border-destructive/30 bg-destructive/5">
              <CardHeader>
                <CardTitle className="text-sm font-mono text-destructive">BLIND SPOTS</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  {data.blindSpots.map((b, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-destructive">•</span>
                      {b}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Sample Text */}
          <Card className="border-border bg-card h-fit">
            <CardHeader>
              <CardTitle className="text-sm font-mono text-muted-foreground">SAMPLE — {activePOV} POV</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="prose prose-sm prose-invert max-w-none">
                <p className="text-foreground leading-relaxed whitespace-pre-line">{data.sample}</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
