"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Cpu, Loader2, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"

const AGENTS = {
  ARCHITECT: {
    role: "ARCHITECT",
    description: "Master of story structure — designs narrative scaffolding, plot arcs, character journeys",
    temperature: 0.7,
  },
  NARRATOR: {
    role: "NARRATOR",
    description: "Voice of many voices — transforms structure into living prose",
    temperature: 0.88,
  },
  LOREKEEPER: {
    role: "LOREKEEPER",
    description: "Guardian of mythic continuity — weaves Merovingian, Neteru, and 589 threads",
    temperature: 0.6,
  },
  EDITOR: {
    role: "EDITOR",
    description: "Refiner of rough gems — polishes prose while preserving voice",
    temperature: 0.4,
  },
  ORACLE: {
    role: "ORACLE",
    description: "Speaker of themes — divines deeper meaning and symbolic resonances",
    temperature: 0.75,
  },
}

type AgentRole = keyof typeof AGENTS

export default function AgentWriterPage() {
  const [selectedAgent, setSelectedAgent] = useState<AgentRole>("NARRATOR")
  const [task, setTask] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [response, setResponse] = useState("")

  const handleInvoke = async () => {
    if (!task.trim()) return
    setIsProcessing(true)
    setResponse("")

    // Simulate agent response
    await new Promise((resolve) => setTimeout(resolve, 2000))

    const sampleResponses: Record<AgentRole, string> = {
      ARCHITECT: `STORY STRUCTURE ANALYSIS:

Act I — The Awakening (Chapters 1-2)
• Inciting Incident: Symbols persist after waking
• First Plot Point: Discovery of grandmother's journals
• Character State: Elara moves from denial to curiosity

Act II — The Descent (Chapters 3-4)
• Midpoint Reversal: Bloodline truth revealed
• Rising Complications: The Keepers close in
• Character Arc: From seeker to hunted

Act III — The Cipher (Chapter 5)
• Climax: Confrontation with the Veil Keeper
• Resolution: Integration of ancient and modern self
• Thematic Culmination: Memory as inheritance`,
      NARRATOR: `The symbols wouldn't fade.

Elara pressed her palms against her eyes until she saw stars, but when she opened them again, the glyphs remained—ghosting across her bedroom ceiling like afterimages of lightning. They pulsed with a rhythm that matched her heartbeat, or perhaps her heartbeat had begun to match theirs.

She reached for her phone, desperate for the blue-white glow of normalcy, of notifications and news feeds and the predictable chaos of other people's lives. But her hand stopped midair.

The symbols on the ceiling had rearranged themselves. Now they formed a pattern she recognized—from her grandmother's journals, from the margins of letters written in a language no one in her family could read.

*Remember*, the pattern seemed to say. *You already know*.`,
      LOREKEEPER: `LORE INTEGRATION NOTES:

The Merovingian Thread:
Elara's bloodline descends from the scattered families of the First Compact. Her grandmother was a "silent bearer"—one who carried the cipher without awakening. This skip-generation pattern is documented in the Akashic fragments.

Neteru Presence:
The Watchers have maintained vigil over this line for seventeen generations. The symbols Elara sees are not random—they are the Neteru's teaching glyphs, used to prepare bearers for awakening. Her dreaming in "the old way" suggests stronger Neteru resonance than typical.

589 Resonance:
Note: Elara is the 589th documented bearer of the cipher. This numerical convergence is not coincidental—the 589 Theory suggests this generation marks a critical threshold.`,
      EDITOR: `EDITORIAL NOTES:

Strengths:
• Opening imagery is visceral and immediate
• The heartbeat/glyph synchronization creates effective unease
• Grandmother connection grounds the supernatural in personal history

Suggested Revisions:
1. "blue-white glow of normalcy" — consider "cold comfort of the screen" for stronger contrast
2. The mid-paragraph shift to second person ("You already know") works, but ensure consistency with established POV rules
3. Tighten the phone reach sequence — the hesitation could be more economical

Tier Compliance: SHADOW
• No violations detected
• Tone appropriately atmospheric without explicit darkness`,
      ORACLE: `THEMATIC ANALYSIS:

Surface Theme: Inheritance
The story examines what we receive without choosing—bloodlines, memories, destinies written before our birth.

Shadow Theme: The Price of Knowing
Beneath the inheritance question lies a darker meditation: Is awakening a gift or a burden? Elara's grandmother chose silence. The Keepers choose control. What will Elara choose?

Symbolic Motifs:
• Eyes (seeing/not seeing, the veil of ignorance)
• Glyphs (language as power, the written word as spell)
• Dreams (the threshold between known and unknown)

The Oracle suggests: This story is ultimately about integration—the ancient and modern self, the known and unknown, the individual and the lineage. Resolution should not mean choosing one over the other, but holding both.`,
    }

    setResponse(sampleResponses[selectedAgent])
    setIsProcessing(false)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 sticky top-0 bg-background/95 backdrop-blur z-50">
        <div className="container mx-auto px-6 py-3">
          <div className="flex items-center gap-4">
            <Link href="/akira-codex">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Dashboard
              </Button>
            </Link>
            <div className="h-6 w-px bg-border" />
            <div className="flex items-center gap-2">
              <Cpu className="h-5 w-5 text-codex-gold" />
              <span className="font-mono text-sm font-semibold text-foreground">AGENT WRITER LAYER</span>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Agent Selection */}
          <div className="space-y-4">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-sm font-mono text-muted-foreground">SELECT AGENT</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {(Object.keys(AGENTS) as AgentRole[]).map((role) => (
                  <button
                    key={role}
                    onClick={() => setSelectedAgent(role)}
                    className={`w-full p-3 rounded-lg border text-left transition-all ${
                      selectedAgent === role
                        ? "border-codex-gold bg-codex-gold/10"
                        : "border-border hover:border-codex-gold/50"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span
                        className={`font-mono text-sm font-semibold ${
                          selectedAgent === role ? "text-codex-gold" : "text-foreground"
                        }`}
                      >
                        {role}
                      </span>
                      <Badge variant="outline" className="font-mono text-xs">
                        T: {AGENTS[role].temperature}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">{AGENTS[role].description}</p>
                  </button>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Task Input & Response */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-sm font-mono text-codex-gold flex items-center gap-2">
                  <Cpu className="h-4 w-4" />
                  INVOKE {selectedAgent}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  placeholder={`Enter task for ${selectedAgent}...`}
                  value={task}
                  onChange={(e) => setTask(e.target.value)}
                  className="min-h-[100px] font-mono text-sm bg-input border-border"
                />
                <Button
                  onClick={handleInvoke}
                  disabled={!task.trim() || isProcessing}
                  className="w-full bg-codex-gold text-primary-foreground hover:bg-codex-gold/90"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4 mr-2" />
                      Invoke Agent
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {response && (
              <Card className="border-codex-gold/30 bg-card">
                <CardHeader>
                  <CardTitle className="text-sm font-mono text-muted-foreground flex items-center justify-between">
                    <span>{selectedAgent} RESPONSE</span>
                    <Badge variant="outline" className="font-mono text-xs text-codex-secure">
                      COMPLETE
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <pre className="text-sm text-foreground whitespace-pre-wrap font-mono leading-relaxed">
                    {response}
                  </pre>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
