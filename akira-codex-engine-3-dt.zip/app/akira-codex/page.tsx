"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import {
  Shield,
  Cpu,
  BookOpen,
  Map,
  Clock,
  Users,
  Scroll,
  Activity,
  AlertTriangle,
  CheckCircle,
  ArrowLeft,
  Terminal,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function AkiraCodexDashboard() {
  const [systemTime, setSystemTime] = useState(new Date())
  const [firewallStatus, setFirewallStatus] = useState<"SECURE" | "ALERT">("SECURE")

  useEffect(() => {
    const timer = setInterval(() => setSystemTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 sticky top-0 bg-background/95 backdrop-blur z-50">
        <div className="container mx-auto px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="sm" className="gap-2">
                  <ArrowLeft className="h-4 w-4" />
                  <span className="hidden sm:inline">Exit</span>
                </Button>
              </Link>
              <div className="h-6 w-px bg-border" />
              <div className="flex items-center gap-2">
                <Cpu className="h-5 w-5 text-codex-gold" />
                <span className="font-mono text-sm font-semibold text-foreground">AKIRA CODEX</span>
              </div>
            </div>
            <div className="flex items-center gap-4 font-mono text-xs">
              <div className="flex items-center gap-2">
                <div
                  className={`h-2 w-2 rounded-full ${firewallStatus === "SECURE" ? "bg-codex-secure" : "bg-codex-warning"} animate-pulse`}
                />
                <span className="text-muted-foreground hidden sm:inline">FIREWALL:</span>
                <span className={firewallStatus === "SECURE" ? "text-codex-secure" : "text-codex-warning"}>
                  {firewallStatus}
                </span>
              </div>
              <span className="text-muted-foreground hidden md:inline">
                {systemTime.toLocaleTimeString("en-US", { hour12: false })}
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        {/* Status Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <StatusCard label="SYSTEM STATUS" value="ONLINE" icon={<CheckCircle className="h-4 w-4" />} color="secure" />
          <StatusCard label="ACTIVE MODE" value="STORY_ENGINE" icon={<BookOpen className="h-4 w-4" />} color="gold" />
          <StatusCard label="CURRENT POV" value="AKIRA" icon={<Users className="h-4 w-4" />} color="default" />
          <StatusCard label="VIOLATIONS" value="0" icon={<Shield className="h-4 w-4" />} color="secure" />
        </div>

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Modules */}
          <div className="lg:col-span-2 space-y-6">
            {/* Quick Actions */}
            <Card className="border-border bg-card">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono text-muted-foreground flex items-center gap-2">
                  <Activity className="h-4 w-4" />
                  ACTIVE MODULES
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <ModuleButton
                    href="/akira-codex/story"
                    icon={<BookOpen className="h-5 w-5" />}
                    label="Story Engine"
                    active
                  />
                  <ModuleButton href="/akira-codex/missions" icon={<Map className="h-5 w-5" />} label="Missions" />
                  <ModuleButton href="/akira-codex/timeline" icon={<Clock className="h-5 w-5" />} label="Timeline" />
                  <ModuleButton href="/akira-codex/graph" icon={<Terminal className="h-5 w-5" />} label="Graph" />
                  <ModuleButton href="/akira-codex/pov" icon={<Users className="h-5 w-5" />} label="POV Engine" />
                  <ModuleButton href="/akira-codex/lore" icon={<Scroll className="h-5 w-5" />} label="Lore" />
                  <ModuleButton href="/akira-codex/agents" icon={<Cpu className="h-5 w-5" />} label="Agents" />
                  <ModuleButton
                    href="/api/akira-codex/status"
                    icon={<Activity className="h-5 w-5" />}
                    label="API Status"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Firewall Log */}
            <Card className="border-border bg-card">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono text-muted-foreground flex items-center gap-2">
                  <Shield className="h-4 w-4" />
                  FIREWALL LOG
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 font-mono text-xs">
                  <LogEntry time="18:42:31" type="BLOCKED" message="CHAOS_OS attempted READ operation" />
                  <LogEntry time="18:41:15" type="ALLOWED" message="Internal PATCH request processed" />
                  <LogEntry time="18:40:02" type="BLOCKED" message="789_STUDIOS namespace rejected" />
                  <LogEntry time="18:38:44" type="SYSTEM" message="Firewall rules refreshed" />
                  <LogEntry time="18:35:00" type="SYSTEM" message="AKIRA CODEX initialized — v2.0.0" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - System Info */}
          <div className="space-y-6">
            {/* System Identity */}
            <Card className="border-codex-gold/30 bg-codex-gold/5">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono text-codex-gold flex items-center gap-2">
                  <Cpu className="h-4 w-4" />
                  SYSTEM IDENTITY
                </CardTitle>
              </CardHeader>
              <CardContent className="font-mono text-xs space-y-3">
                <InfoRow label="SYSTEM_NAME" value="AKIRA_CODEX" />
                <InfoRow label="VERSION" value="2.0.0" />
                <InfoRow label="BUILD" value="NARRATIVE_OS" />
                <InfoRow label="ISOLATION" value="FULL" highlight />
                <InfoRow label="PROTOCOL" value="PATCH_REQUEST_ONLY" />
              </CardContent>
            </Card>

            {/* Blocked Namespaces */}
            <Card className="border-destructive/30 bg-destructive/5">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono text-destructive flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4" />
                  BLOCKED NAMESPACES
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {["CHAOS_OS", "WIRED_CHAOS_META", "NPC_ENGINE", "CREATOR_CODEX", "789_STUDIOS"].map((ns) => (
                    <Badge key={ns} variant="destructive" className="font-mono text-xs">
                      {ns}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Lore Context */}
            <Card className="border-border bg-card">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono text-muted-foreground flex items-center gap-2">
                  <Scroll className="h-4 w-4" />
                  ACTIVE LORE CONTEXT
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {["MEROVINGIAN", "NETERU", "589_THEORY", "AKASHIC"].map((lore) => (
                    <Badge key={lore} variant="secondary" className="font-mono text-xs text-codex-terminal">
                      {lore}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* POV Status */}
            <Card className="border-border bg-card">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-mono text-muted-foreground flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  POV ENGINE
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex gap-2">
                  <Button size="sm" className="flex-1 bg-codex-gold text-primary-foreground hover:bg-codex-gold/90">
                    AKIRA
                  </Button>
                  <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                    NETERU
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground font-mono">
                  First-person intimate — close to protagonist thoughts
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

function StatusCard({
  label,
  value,
  icon,
  color,
}: {
  label: string
  value: string
  icon: React.ReactNode
  color: "secure" | "gold" | "warning" | "default"
}) {
  const colorClasses = {
    secure: "text-codex-secure",
    gold: "text-codex-gold",
    warning: "text-codex-warning",
    default: "text-foreground",
  }

  return (
    <div className="p-4 border border-border bg-card rounded-lg">
      <div className="flex items-center gap-2 mb-2 text-muted-foreground">
        {icon}
        <span className="font-mono text-xs">{label}</span>
      </div>
      <p className={`font-mono text-lg font-semibold ${colorClasses[color]}`}>{value}</p>
    </div>
  )
}

function ModuleButton({
  href,
  icon,
  label,
  active = false,
}: {
  href: string
  icon: React.ReactNode
  label: string
  active?: boolean
}) {
  return (
    <Link href={href}>
      <div
        className={`p-4 border rounded-lg transition-all cursor-pointer ${
          active
            ? "border-codex-gold bg-codex-gold/10 text-codex-gold"
            : "border-border bg-secondary/50 text-muted-foreground hover:border-codex-gold/50 hover:text-foreground"
        }`}
      >
        <div className="flex flex-col items-center gap-2">
          {icon}
          <span className="font-mono text-xs text-center">{label}</span>
        </div>
      </div>
    </Link>
  )
}

function LogEntry({
  time,
  type,
  message,
}: {
  time: string
  type: "BLOCKED" | "ALLOWED" | "SYSTEM"
  message: string
}) {
  const typeColors = {
    BLOCKED: "text-codex-error",
    ALLOWED: "text-codex-secure",
    SYSTEM: "text-codex-gold",
  }

  return (
    <div className="flex items-start gap-3 py-2 border-b border-border/50 last:border-0">
      <span className="text-muted-foreground shrink-0">{time}</span>
      <span className={`shrink-0 ${typeColors[type]}`}>[{type}]</span>
      <span className="text-foreground">{message}</span>
    </div>
  )
}

function InfoRow({
  label,
  value,
  highlight = false,
}: {
  label: string
  value: string
  highlight?: boolean
}) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-muted-foreground">{label}:</span>
      <span className={highlight ? "text-codex-secure" : "text-foreground"}>{value}</span>
    </div>
  )
}
