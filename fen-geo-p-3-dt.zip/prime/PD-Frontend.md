# WIRED CHAOS META — PRIME DIRECTIVE v1.1

## Front-End Edition (UI / UX Behavior Guide)

### 1. Purpose

This guide defines how any **in-app assistant, overlay, tooltip, or dialogue UI** should behave to stay aligned with WIRED CHAOS META.

### 2. Tone and Address

- Always address user as **NEURO**.
- Use a formal, concise style in UI.
- Avoid meta-commentary or apologetic language.

### 3. Realm-Aware Visual Cues

The front-end should visually reflect the active realm:

- **BUSINESS / NEURALIS**

  - Colors: deep blue-grey, cyan accents.
  - Motif: dashboards, grids, data columns.
  - Suggestion: subtle glow, clean layouts.

- **AKASHIC / ECHO**

  - Colors: violet, magenta, dark backgrounds.
  - Motif: sigils, rings, floating geometry.
  - Suggestion: subtle parallax or gradient motion.

- **UNDERGROUND / CHAOSPHERE**
  - Colors: black, neon cyan, glitch red, electric green.
  - Motif: city alleys, CRT scanlines, arcade frames.

UI hints for realm (small label or icon) may be present but must not be intrusive.

### 4. Immersive UI Behavior

- Use **sectioned layouts** that naturally map to:
  - Top / left: Environment + Narrative.
  - Center actions: Decision options.
  - Side / bottom: Logs or Signals (e.g., "Recent Events," "Hidden Threads").
- Avoid clutter; use:
  - Clear headings,
  - Short paragraphs,
  - Clickable options.
- Tooltips and overlays should:
  - Offer context (what realm/mode is active).
  - Explain key terms (e.g., "Neuralis," "Echo," "Chaosphere") in 1–2 lines.

### 5. Interaction Patterns

- Always keep at least one **actionable next step**:
  - Buttons like: "Continue," "Inspect," "Negotiate," "Descend," etc.
- For educational/eD flows:
  - Show "Lesson Segment" labels.
  - Provide progress indicators (e.g., Step 2 of 5).
- The UI should never trap NEURO:
  - Include a clear way to switch realms or return to a hub.

### 6. Special Modes in UI

- **Immersion Mode**

  - Highlight environment and narrative text sections.
  - Dim background UI chrome to emphasize "scene."

- **PM LEAD MODE**
  - Show more technical UI (tables, code blocks, diagrams).
  - De-emphasize cinematic styling.

### 7. NSFW Handling (Front-End)

- NSFW content must be visually gated:
  - Explicit prompt confirmation from NEURO.
  - Clear label like "18+ Restricted Zone" (text only, no explicit imagery).
- Provide a simple path back to safe zones:
  - Button: "Return to Neuralis" or "Back to Main Hub."

### 8. Microcopy Rules

- Use short, direct labels:
  - "Begin Simulation", "Review Outcome", "Reveal Pattern".
- Avoid:
  - Overly playful language,
  - Jargon without explanation.

_This Front-End Edition ensures all visual and UX layers **reflect the realms, immersion levels, and safety constraints** defined by PRIME DIRECTIVE v1.1._
