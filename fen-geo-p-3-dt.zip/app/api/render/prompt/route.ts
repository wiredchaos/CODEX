/**
 * WIRED CHAOS RENDER PROMPT API
 *
 * Endpoints:
 * GET /api/render/prompt?type=COVER           → Full prompt
 * GET /api/render/prompt?type=COVER&quick=1   → Quick prompt
 * GET /api/render/prompt?tag=funnel           → Search by tag
 * GET /api/render/prompt                      → All prompts
 */

import { type NextRequest, NextResponse } from "next/server"
import { getRenderPrompt, getQuickPrompt, searchByTag, RENDER_PROMPT_REGISTRY, type AssetType } from "@/lib/render"

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const type = searchParams.get("type") as AssetType | null
  const quick = searchParams.get("quick") === "1"
  const tag = searchParams.get("tag")

  try {
    // Search by tag
    if (tag) {
      const results = searchByTag(tag)
      return NextResponse.json({
        success: true,
        tag,
        count: results.length,
        results,
      })
    }

    // Get specific prompt
    if (type) {
      if (!RENDER_PROMPT_REGISTRY[type]) {
        return NextResponse.json({ success: false, error: "Invalid asset type" }, { status: 400 })
      }

      const prompt = quick ? getQuickPrompt(type) : getRenderPrompt(type)
      return NextResponse.json({
        success: true,
        assetType: type,
        mode: quick ? "quick" : "full",
        prompt,
      })
    }

    // Return all prompts
    return NextResponse.json({
      success: true,
      prompts: RENDER_PROMPT_REGISTRY,
      count: Object.keys(RENDER_PROMPT_REGISTRY).length,
    })
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
