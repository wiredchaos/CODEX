"use client"

import { useState, useCallback, useEffect } from "react"
import { GameFrameV1 } from "@/components/game-frame"
import { TrinitySceneLayer } from "@/components/trinity"
import { getSceneById } from "@/lib/trinity/scene-registry"
import { getGameConfig, GAMES } from "@/lib/trinity/game-registry"
import { mountGameToTrinity, type TrinityMountHandle } from "@/lib/trinity/mount-system"
import type { GameSession, GameChoice, GameScene } from "@/lib/types/game-session"
import { createGameSession, addLogEntry, updateScene, addXP, updateVariable } from "@/lib/game-engine/session-factory"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Crown, Gamepad2, BookOpen, Eye, ChevronRight, Lock } from "lucide-react"

// ─────────────────────────────────────────────────────────────────────────────
// DEMO SCENES - RVP UNEMPIRE PATCH
// ─────────────────────────────────────────────────────────────────────────────
const DEMO_SCENES: Record<string, { scene: GameScene; choices: GameChoice[] }> = {
  intro: {
    scene: {
      id: "intro",
      title: "The Throne Awaits",
      narrative:
        "The year is 1524. Europe lies fractured, its kingdoms weakened by internal strife and external threats. You have emerged as a contender for power. Will you claim territory through diplomacy, or will you forge your empire through conquest?",
      tags: ["Strategy", "Diplomacy", "Conquest"],
      metadata: { timeline: "1524 CE", riskLevel: "LOW" },
    },
    choices: [
      {
        id: "claim_england",
        label: "Claim England",
        description: "Establish your seat of power on the British Isles.",
        preview: { xpChange: 25, outcomeHint: "Strong naval position" },
      },
      {
        id: "claim_france",
        label: "Claim France",
        description: "Take control of the heart of continental Europe.",
        preview: { xpChange: 30, outcomeHint: "Central trade routes" },
      },
      {
        id: "claim_hre",
        label: "Claim Holy Roman Empire",
        description: "Unite the fragmented German states under your banner.",
        preview: { xpChange: 35, outcomeHint: "Large but fractured" },
      },
      {
        id: "seek_alliance",
        label: "Seek Alliance First",
        description: "Build diplomatic ties before claiming territory.",
        preview: { xpChange: 15, outcomeHint: "Safer but slower" },
        variant: "secondary",
      },
    ],
  },
  claimed_territory: {
    scene: {
      id: "claimed",
      title: "Your Kingdom Rises",
      narrative:
        "Your banner now flies over your claimed lands. Peasants and nobles alike look to you for leadership. But rivals watch from the shadows, and the Ottoman Empire expands in the East. What will be your next move?",
      tags: ["Expansion", "Defense", "Economy"],
      metadata: { timeline: "1525 CE", riskLevel: "MEDIUM" },
    },
    choices: [
      {
        id: "expand_military",
        label: "Expand Military",
        description: "Build fortifications and train soldiers.",
        preview: { xpChange: 20, outcomeHint: "Defense +50%" },
      },
      {
        id: "grow_economy",
        label: "Grow Economy",
        description: "Invest in trade and agriculture.",
        preview: { xpChange: 25, outcomeHint: "Income +30%" },
      },
      {
        id: "attack_neighbor",
        label: "Attack Neighboring Territory",
        description: "Launch a surprise invasion.",
        preview: { xpChange: 40, outcomeHint: "High risk, high reward" },
        variant: "destructive",
      },
      {
        id: "form_alliance",
        label: "Propose Alliance",
        description: "Reach out to a neighboring power.",
        preview: { xpChange: 15, outcomeHint: "Diplomatic safety" },
        variant: "outline",
      },
    ],
  },
}

// ─────────────────────────────────────────────────────────────────────────────
// REALM ICONS
// ─────────────────────────────────────────────────────────────────────────────
const REALM_ICONS = {
  underground: Gamepad2,
  business: BookOpen,
  akashic: Eye,
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN PAGE COMPONENT
// ─────────────────────────────────────────────────────────────────────────────
export default function GamePage() {
  const [session, setSession] = useState<GameSession | null>(null)
  const [playerName, setPlayerName] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [selectedGame, setSelectedGame] = useState<string | null>(null)
  const [mountHandle, setMountHandle] = useState<TrinityMountHandle | null>(null)

  // Get game config
  const gameConfig = selectedGame ? getGameConfig(selectedGame) : null
  const scene = gameConfig ? getSceneById(gameConfig.trinityScene) : null

  useEffect(() => {
    if (selectedGame && gameConfig) {
      // Request read-only mount to Trinity Floor via Akira Codex governance
      const handle = mountGameToTrinity(selectedGame)
      setMountHandle(handle)

      // Log mount status for debugging
      if (handle.status === "MOUNTED") {
        console.log(`[Trinity] Mounted to floor: ${handle.floor?.floorId}`)
        console.log(`[Trinity] Timeline: ${handle.timeline?.timelineId}`)
        console.log(`[Trinity] Governor: ${handle.timeline?.governor}`)
      } else if (handle.status === "DENIED") {
        console.warn(`[Trinity] Mount denied for: ${selectedGame}`)
      }
    } else {
      setMountHandle(null)
    }
  }, [selectedGame, gameConfig])

  // Apply theme from mounted scene (read-only access)
  useEffect(() => {
    const mountedScene = mountHandle?.scene ?? scene
    if (mountedScene) {
      document.documentElement.style.setProperty("--trinity-primary", mountedScene.theme.primary)
      document.documentElement.style.setProperty("--trinity-accent", mountedScene.theme.accent)
      document.documentElement.style.setProperty("--trinity-background", mountedScene.theme.background)
      document.documentElement.style.setProperty("--trinity-foreground", mountedScene.theme.foreground)
      document.documentElement.style.setProperty("--trinity-muted", mountedScene.theme.muted)
    }
  }, [mountHandle, scene])

  const startGame = useCallback(() => {
    if (!playerName.trim() || !gameConfig) return

    const initialScene = DEMO_SCENES.intro
    const newSession = createGameSession("GAME.RVP_UNEMPIRE", `player-${Date.now()}`, playerName, {
      initialScene: initialScene.scene,
      initialChoices: initialScene.choices,
      initialVariables: {
        territories: { key: "territories", label: "Territories", value: 0, type: "number" },
        gold: { key: "gold", label: "Treasury", value: 1000, type: "currency" },
        military: { key: "military", label: "Military Strength", value: 25, type: "progress", max: 100 },
        reputation: {
          key: "reputation",
          label: "Reputation",
          value: "Unknown",
          type: "badge",
          color: "hsl(var(--muted))",
        },
      },
      seasonYear: 1524,
    })

    setSession(newSession)
  }, [playerName, gameConfig])

  const handleChoiceSelect = useCallback(
    (choiceId: string) => {
      if (!session) return
      setIsLoading(true)

      setTimeout(() => {
        let updatedSession = session
        const choice = session.choices.find((c) => c.id === choiceId)

        if (choice) {
          updatedSession = addLogEntry(updatedSession, `Chose: ${choice.label}`, "CHOICE")
          if (choice.preview?.xpChange) {
            updatedSession = addXP(updatedSession, choice.preview.xpChange)
          }
        }

        if (choiceId.startsWith("claim_")) {
          updatedSession = updateVariable(updatedSession, "territories", 1)
          updatedSession = updateVariable(updatedSession, "reputation", "Rising Power")
          updatedSession = addLogEntry(updatedSession, "Territory claimed! Your empire begins.", "CLAIM")
          const nextScene = DEMO_SCENES.claimed_territory
          updatedSession = updateScene(updatedSession, nextScene.scene, nextScene.choices)
        } else if (choiceId === "expand_military") {
          updatedSession = updateVariable(updatedSession, "military", 50)
          updatedSession = updateVariable(updatedSession, "gold", 800)
          updatedSession = addLogEntry(updatedSession, "Military expanded. Treasury depleted.", "OUTCOME")
        } else if (choiceId === "grow_economy") {
          updatedSession = updateVariable(updatedSession, "gold", 1500)
          updatedSession = addLogEntry(updatedSession, "Trade flourishes. Coffers overflow.", "OUTCOME")
        } else if (choiceId === "attack_neighbor") {
          const success = Math.random() > 0.4
          if (success) {
            updatedSession = updateVariable(
              updatedSession,
              "territories",
              ((session.variables.territories?.value as number) || 0) + 1,
            )
            updatedSession = addLogEntry(updatedSession, "Victory! Enemy territory annexed.", "ATTACK")
          } else {
            updatedSession = updateVariable(
              updatedSession,
              "military",
              Math.max(0, ((session.variables.military?.value as number) || 0) - 20),
            )
            updatedSession = addLogEntry(updatedSession, "Defeat! Your forces were repelled.", "DEFENSE")
          }
        } else if (choiceId === "form_alliance" || choiceId === "seek_alliance") {
          updatedSession = updateVariable(updatedSession, "reputation", "Diplomat")
          updatedSession = addLogEntry(updatedSession, "Alliance formed with neighboring power.", "ALLIANCE")
        }

        setSession(updatedSession)
        setIsLoading(false)
      }, 800)
    },
    [session],
  )

  // ═══════════════════════════════════════════════════════════════════════════
  // GAME SELECTOR SCREEN
  // ═══════════════════════════════════════════════════════════════════════════
  if (!selectedGame) {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b border-border bg-card/80 backdrop-blur-sm sticky top-0 z-50">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                <Gamepad2 className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h1 className="text-lg font-bold">WIRED CHAOS META</h1>
                <p className="text-xs text-muted-foreground">GameFrame_v1 + Trinity Reality</p>
              </div>
            </div>
          </div>
        </header>

        <main className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto space-y-8">
            <div className="text-center space-y-2">
              <h2 className="text-2xl font-bold">Select Experience</h2>
              <p className="text-muted-foreground">Choose a realm to enter</p>
              <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
                <Lock className="w-3 h-3" />
                <span>Trinity Mount: READ_ONLY | Governor: AKIRA_CODEX</span>
              </div>
            </div>

            {/* Realm Sections */}
            {(["underground", "business", "akashic"] as const).map((realm) => {
              const RealmIcon = REALM_ICONS[realm]
              const realmGames = GAMES.filter((g) => g.realm === realm)
              const realmLabels = {
                underground: "Chaosphere",
                business: "Neuralis",
                akashic: "Echo",
              }

              return (
                <div key={realm} className="space-y-4">
                  <div className="flex items-center gap-2">
                    <RealmIcon className="w-5 h-5 text-primary" />
                    <h3 className="font-semibold uppercase tracking-wide text-sm">{realmLabels[realm]} Realm</h3>
                    <Badge variant="outline" className="text-xs">
                      {realmGames.length} experiences
                    </Badge>
                  </div>

                  <div className="grid gap-3 sm:grid-cols-2">
                    {realmGames.map((game) => (
                      <Card
                        key={game.slug}
                        className="p-4 cursor-pointer hover:bg-accent/50 transition-colors group"
                        onClick={() => setSelectedGame(game.slug)}
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="space-y-1 flex-1">
                            <h4 className="font-medium group-hover:text-primary transition-colors">{game.title}</h4>
                            <p className="text-sm text-muted-foreground line-clamp-2">{game.description}</p>
                            <div className="flex gap-2 pt-1">
                              <Badge variant="secondary" className="text-xs">
                                {game.firewall}
                              </Badge>
                            </div>
                          </div>
                          <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors flex-shrink-0" />
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              )
            })}
          </div>
        </main>
      </div>
    )
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // JOIN SCREEN (with Trinity Background via Mount)
  // ═══════════════════════════════════════════════════════════════════════════
  if (!session && gameConfig && scene) {
    return (
      <div className="relative min-h-screen overflow-hidden">
        {/* Trinity 3D Background - consumed via mount handle */}
        <TrinitySceneLayer sceneId={gameConfig.trinityScene} realm={gameConfig.realm} />

        {/* HUD Overlay */}
        <div className="relative z-10 min-h-screen flex items-center justify-center p-6">
          <Card className="p-8 md:p-12 max-w-md w-full text-center bg-card/90 backdrop-blur-md border-primary/20">
            <Crown className="w-16 h-16 mx-auto mb-6 text-primary" />
            <h1 className="text-3xl font-bold mb-2">{gameConfig.title}</h1>
            <p className="text-muted-foreground mb-2">{gameConfig.description}</p>
            <div className="flex justify-center gap-2 mb-4">
              <Badge variant="outline">{scene.label}</Badge>
              <Badge variant="secondary">{gameConfig.firewall}</Badge>
            </div>

            {mountHandle && (
              <div className="text-xs text-muted-foreground mb-6 space-y-1">
                <div className="flex items-center justify-center gap-2">
                  <div
                    className={`w-2 h-2 rounded-full ${
                      mountHandle.status === "MOUNTED"
                        ? "bg-green-500"
                        : mountHandle.status === "DENIED"
                          ? "bg-red-500"
                          : "bg-yellow-500"
                    }`}
                  />
                  <span>Mount: {mountHandle.status}</span>
                </div>
                {mountHandle.timeline && <div>Timeline: {mountHandle.timeline.governor}</div>}
              </div>
            )}

            <div className="space-y-4">
              <div className="space-y-2 text-left">
                <Label htmlFor="name">Kingdom Name</Label>
                <Input
                  id="name"
                  placeholder="Enter kingdom name..."
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && startGame()}
                  className="text-base bg-background/50"
                />
              </div>
              <Button onClick={startGame} size="lg" className="w-full min-h-[44px]">
                <Crown className="w-5 h-5 mr-2" />
                Begin Session
              </Button>
              <Button variant="ghost" size="sm" className="w-full" onClick={() => setSelectedGame(null)}>
                Back to Selection
              </Button>
            </div>
          </Card>
        </div>
      </div>
    )
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // GAME FRAME (with Trinity Background via Mount)
  // ═══════════════════════════════════════════════════════════════════════════
  if (session && gameConfig && scene) {
    return (
      <div className="relative min-h-screen overflow-hidden">
        {/* Trinity 3D Background - consumed via mount handle */}
        <TrinitySceneLayer sceneId={gameConfig.trinityScene} realm={gameConfig.realm} />

        {/* Header */}
        <header className="relative z-20 border-b border-primary/20 bg-card/60 backdrop-blur-md sticky top-0">
          <div className="container mx-auto px-4 py-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Crown className="w-6 h-6 text-primary" />
                <div>
                  <h1 className="text-lg font-bold">{gameConfig.title}</h1>
                  <p className="text-xs text-muted-foreground">{scene.label}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {mountHandle?.status === "MOUNTED" && (
                  <Badge variant="outline" className="text-xs">
                    <Lock className="w-3 h-3 mr-1" />
                    READ_ONLY
                  </Badge>
                )}
                <Badge variant="outline">{gameConfig.realm.toUpperCase()}</Badge>
              </div>
            </div>
          </div>
        </header>

        {/* Game Frame HUD */}
        <main className="relative z-10 container mx-auto px-4 py-6">
          <GameFrameV1
            session={session}
            theme={{
              patch: "GAME.RVP_UNEMPIRE",
              showXPBar: true,
              showLedgerPanel: false,
              logMaxEntries: 15,
            }}
            onChoiceSelect={handleChoiceSelect}
            isLoading={isLoading}
            className="[&_.bg-card]:bg-card/80 [&_.bg-card]:backdrop-blur-md"
          />
        </main>
      </div>
    )
  }

  return null
}
