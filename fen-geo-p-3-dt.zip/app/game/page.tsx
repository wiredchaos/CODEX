/**
 * WIRED CHAOS META - Demo Page for GameFrame_v1
 * Shows canonical implementation with RVP UNEMPIRE patch
 */

"use client"

import { useState, useCallback } from "react"
import { GameFrameV1 } from "@/components/game-frame"
import type { GameSession, GameChoice, GameScene } from "@/lib/types/game-session"
import { createGameSession, addLogEntry, updateScene, addXP, updateVariable } from "@/lib/game-engine/session-factory"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Crown } from "lucide-react"

// ─────────────────────────────────────────────────────────────────────────────
// DEMO SCENES
// ─────────────────────────────────────────────────────────────────────────────
const DEMO_SCENES: Record<string, { scene: GameScene; choices: GameChoice[] }> = {
  intro: {
    scene: {
      id: "intro",
      title: "The Throne Awaits",
      narrative:
        "The year is 1524. Europe lies fractured, its kingdoms weakened by internal strife and external threats. You have emerged as a contender for power. Will you claim territory through diplomacy, or will you forge your empire through conquest?",
      tags: ["Strategy", "Diplomacy", "Conquest"],
      metadata: {
        timeline: "1524 CE",
        riskLevel: "LOW",
      },
    },
    choices: [
      {
        id: "claim_england",
        label: "Claim England",
        description: "Establish your seat of power on the British Isles.",
        preview: { xpChange: 25, outcomeHint: "Strong naval position" },
      },
      {
        id: "claim_france",
        label: "Claim France",
        description: "Take control of the heart of continental Europe.",
        preview: { xpChange: 30, outcomeHint: "Central trade routes" },
      },
      {
        id: "claim_hre",
        label: "Claim Holy Roman Empire",
        description: "Unite the fragmented German states under your banner.",
        preview: { xpChange: 35, outcomeHint: "Large but fractured" },
      },
      {
        id: "seek_alliance",
        label: "Seek Alliance First",
        description: "Build diplomatic ties before claiming territory.",
        preview: { xpChange: 15, outcomeHint: "Safer but slower" },
        variant: "secondary",
      },
    ],
  },
  claimed_territory: {
    scene: {
      id: "claimed",
      title: "Your Kingdom Rises",
      narrative:
        "Your banner now flies over your claimed lands. Peasants and nobles alike look to you for leadership. But rivals watch from the shadows, and the Ottoman Empire expands in the East. What will be your next move?",
      tags: ["Expansion", "Defense", "Economy"],
      metadata: {
        timeline: "1525 CE",
        riskLevel: "MEDIUM",
      },
    },
    choices: [
      {
        id: "expand_military",
        label: "Expand Military",
        description: "Build fortifications and train soldiers.",
        preview: { xpChange: 20, outcomeHint: "Defense +50%" },
      },
      {
        id: "grow_economy",
        label: "Grow Economy",
        description: "Invest in trade and agriculture.",
        preview: { xpChange: 25, outcomeHint: "Income +30%" },
      },
      {
        id: "attack_neighbor",
        label: "Attack Neighboring Territory",
        description: "Launch a surprise invasion.",
        preview: { xpChange: 40, outcomeHint: "High risk, high reward" },
        variant: "destructive",
      },
      {
        id: "form_alliance",
        label: "Propose Alliance",
        description: "Reach out to a neighboring power.",
        preview: { xpChange: 15, outcomeHint: "Diplomatic safety" },
        variant: "outline",
      },
    ],
  },
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN DEMO PAGE
// ─────────────────────────────────────────────────────────────────────────────
export default function GameDemoPage() {
  const [session, setSession] = useState<GameSession | null>(null)
  const [playerName, setPlayerName] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const startGame = useCallback(() => {
    if (!playerName.trim()) return

    const initialScene = DEMO_SCENES.intro
    const newSession = createGameSession("GAME.RVP_UNEMPIRE", `player-${Date.now()}`, playerName, {
      initialScene: initialScene.scene,
      initialChoices: initialScene.choices,
      initialVariables: {
        territories: {
          key: "territories",
          label: "Territories",
          value: 0,
          type: "number",
        },
        gold: {
          key: "gold",
          label: "Treasury",
          value: 1000,
          type: "currency",
        },
        military: {
          key: "military",
          label: "Military Strength",
          value: 25,
          type: "progress",
          max: 100,
        },
        reputation: {
          key: "reputation",
          label: "Reputation",
          value: "Unknown",
          type: "badge",
          color: "hsl(var(--muted))",
        },
      },
      seasonYear: 1524,
    })

    setSession(newSession)
  }, [playerName])

  const handleChoiceSelect = useCallback(
    (choiceId: string) => {
      if (!session) return

      setIsLoading(true)

      // Simulate API call delay
      setTimeout(() => {
        let updatedSession = session

        // Process choice
        const choice = session.choices.find((c) => c.id === choiceId)
        if (choice) {
          updatedSession = addLogEntry(updatedSession, `Chose: ${choice.label}`, "CHOICE")

          if (choice.preview?.xpChange) {
            updatedSession = addXP(updatedSession, choice.preview.xpChange)
          }
        }

        // Handle specific choices
        if (choiceId.startsWith("claim_")) {
          updatedSession = updateVariable(updatedSession, "territories", 1)
          updatedSession = updateVariable(updatedSession, "reputation", "Rising Power")
          updatedSession = addLogEntry(updatedSession, "Territory claimed! Your empire begins.", "CLAIM")

          const nextScene = DEMO_SCENES.claimed_territory
          updatedSession = updateScene(updatedSession, nextScene.scene, nextScene.choices)
        } else if (choiceId === "expand_military") {
          updatedSession = updateVariable(updatedSession, "military", 50)
          updatedSession = updateVariable(updatedSession, "gold", 800)
          updatedSession = addLogEntry(updatedSession, "Military expanded. Treasury depleted.", "OUTCOME")
        } else if (choiceId === "grow_economy") {
          updatedSession = updateVariable(updatedSession, "gold", 1500)
          updatedSession = addLogEntry(updatedSession, "Trade flourishes. Coffers overflow.", "OUTCOME")
        } else if (choiceId === "attack_neighbor") {
          const success = Math.random() > 0.4
          if (success) {
            updatedSession = updateVariable(
              updatedSession,
              "territories",
              ((session.variables.territories?.value as number) || 0) + 1,
            )
            updatedSession = addLogEntry(updatedSession, "Victory! Enemy territory annexed.", "ATTACK")
          } else {
            updatedSession = updateVariable(
              updatedSession,
              "military",
              Math.max(0, ((session.variables.military?.value as number) || 0) - 20),
            )
            updatedSession = addLogEntry(updatedSession, "Defeat! Your forces were repelled.", "DEFENSE")
          }
        } else if (choiceId === "form_alliance" || choiceId === "seek_alliance") {
          updatedSession = updateVariable(updatedSession, "reputation", "Diplomat")
          updatedSession = addLogEntry(updatedSession, "Alliance formed with neighboring power.", "ALLIANCE")
        }

        setSession(updatedSession)
        setIsLoading(false)
      }, 800)
    },
    [session],
  )

  // ─────────────────────────────────────────────────────────────────────────
  // RENDER: Join Screen
  // ─────────────────────────────────────────────────────────────────────────
  if (!session) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-6">
        <Card className="p-12 max-w-md w-full text-center">
          <Crown className="w-16 h-16 mx-auto mb-6 text-primary" />
          <h1 className="text-3xl font-bold mb-2">GameFrame_v1 Demo</h1>
          <p className="text-muted-foreground mb-8">
            Canonical UI primitive for WIRED CHAOS META patches.
            <br />
            Patch: GAME.RVP_UNEMPIRE
          </p>
          <div className="space-y-4">
            <div className="space-y-2 text-left">
              <Label htmlFor="name">Your Kingdom Name</Label>
              <Input
                id="name"
                placeholder="Enter kingdom name..."
                value={playerName}
                onChange={(e) => setPlayerName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && startGame()}
              />
            </div>
            <Button onClick={startGame} size="lg" className="w-full">
              <Crown className="w-5 h-5 mr-2" />
              Begin Session
            </Button>
          </div>
        </Card>
      </div>
    )
  }

  // ─────────────────────────────────────────────────────────────────────────
  // RENDER: Game Frame
  // ─────────────────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center gap-3">
            <Crown className="w-6 h-6 text-primary" />
            <h1 className="text-xl font-bold">Unholy Unroman Unempire</h1>
            <span className="text-sm text-muted-foreground">Patch: GAME.RVP_UNEMPIRE</span>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        <GameFrameV1
          session={session}
          theme={{
            patch: "GAME.RVP_UNEMPIRE",
            showXPBar: true,
            showLedgerPanel: false,
            logMaxEntries: 15,
          }}
          onChoiceSelect={handleChoiceSelect}
          isLoading={isLoading}
        />
      </main>
    </div>
  )
}
