/**
 * WIRED CHAOS META - Session Factory
 * Creates pre-configured GameSession instances per patch
 */

import type {
  GameSession,
  GameScene,
  GameChoice,
  GameVariable,
  GameLogEntry,
  PatchIdentifier,
  FirewallMode,
  LedgerType,
} from "@/lib/types/game-session"

// ─────────────────────────────────────────────────────────────────────────────
// FIREWALL MAPPING
// ─────────────────────────────────────────────────────────────────────────────
const PATCH_FIREWALL_MAP: Record<PatchIdentifier, FirewallMode> = {
  // Gaming
  "PATCH.GAME.CHAOS_ARCADE_CORE": "EDUCATION",
  "GAME.RVP_UNEMPIRE": "EDUCATION",
  "GAME.HRM_ARENA": "BUSINESS",
  "GAME.CRYPTO_WHISPER": "BUSINESS",
  // Education
  "PATCH.EDU.NPC_LABYRINTH": "EDUCATION",
  "PATCH.EDU.WCU_ARCADE": "EDUCATION",
  "PATCH.EDU.HRM_ONBOARDING_SUITE": "EDUCATION",
  // Business
  "PATCH.BIZ.CREDIT_REPAIR_SWARM": "BUSINESS",
  "PATCH.BIZ.FINANCE_BOOTCAMP": "BUSINESS",
  "PATCH.BIZ.VAULT_DCA_ENGINE": "BUSINESS",
  "PATCH.BIZ.NEURA_TAX_SUITE": "BUSINESS",
  "PATCH.BIZ.REGULATORY_SWARM": "BUSINESS",
  "PATCH.BIZ.ISO_SUPPLY_SWARM": "BUSINESS",
  // ARG
  "PATCH.ARG.AKASHIC_LAB": "AKASHIC",
  // NSFW
  "PATCH.NSFW.789_AFTERHOURS": "NSFW_LIGHT",
  "PATCH.NSFW.AKIRA_CODEX_DARK": "NSFW_DARK",
}

// ─────────────────────────────────────────────────────────────────────────────
// UTILITY: Generate unique IDs
// ─────────────────────────────────────────────────────────────────────────────
function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`
}

// ─────────────────────────────────────────────────────────────────────────────
// CREATE SESSION
// ─────────────────────────────────────────────────────────────────────────────
export function createGameSession(
  patch: PatchIdentifier,
  playerId: string,
  playerName: string,
  options?: {
    initialScene?: GameScene
    initialChoices?: GameChoice[]
    initialVariables?: Record<string, GameVariable>
    ledgerType?: LedgerType
    walletAddress?: string
    seasonYear?: number
  },
): GameSession {
  const now = Date.now()

  return {
    id: generateId(),
    patch,
    firewall: PATCH_FIREWALL_MAP[patch] || "EDUCATION",
    playerId,
    playerName,
    xp: 0,
    level: 1,
    scene: options?.initialScene || {
      id: "intro",
      title: "Welcome",
      narrative: "Your journey begins here.",
    },
    choices: options?.initialChoices || [],
    variables: options?.initialVariables || {},
    logs: [
      {
        id: generateId(),
        message: `${playerName} has entered the session.`,
        timestamp: now,
        type: "SYSTEM",
      },
    ],
    ledger: options?.ledgerType
      ? {
          type: options.ledgerType,
          walletAddress: options.walletAddress,
          balance: 0,
          transactions: [],
        }
      : undefined,
    createdAt: now,
    updatedAt: now,
    seasonYear: options?.seasonYear,
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// ADD LOG ENTRY
// ─────────────────────────────────────────────────────────────────────────────
export function addLogEntry(
  session: GameSession,
  message: string,
  type: GameLogEntry["type"],
  metadata?: Record<string, unknown>,
): GameSession {
  return {
    ...session,
    logs: [
      {
        id: generateId(),
        message,
        timestamp: Date.now(),
        type,
        metadata,
      },
      ...session.logs,
    ],
    updatedAt: Date.now(),
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// UPDATE SCENE
// ─────────────────────────────────────────────────────────────────────────────
export function updateScene(session: GameSession, scene: GameScene, choices: GameChoice[]): GameSession {
  return {
    ...session,
    scene,
    choices,
    updatedAt: Date.now(),
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// UPDATE VARIABLE
// ─────────────────────────────────────────────────────────────────────────────
export function updateVariable(session: GameSession, key: string, value: string | number | boolean): GameSession {
  if (!session.variables[key]) return session

  return {
    ...session,
    variables: {
      ...session.variables,
      [key]: {
        ...session.variables[key],
        value,
      },
    },
    updatedAt: Date.now(),
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// ADD XP
// ─────────────────────────────────────────────────────────────────────────────
export function addXP(session: GameSession, amount: number): GameSession {
  const newXP = session.xp + amount
  const newLevel = Math.floor(newXP / 100) + 1
  const leveledUp = newLevel > session.level

  let updatedSession: GameSession = {
    ...session,
    xp: newXP,
    level: newLevel,
    updatedAt: Date.now(),
  }

  updatedSession = addLogEntry(updatedSession, `Gained ${amount} XP`, "XP_GAIN")

  if (leveledUp) {
    updatedSession = addLogEntry(updatedSession, `Reached Level ${newLevel}!`, "LEVEL_UP")
  }

  return updatedSession
}
