/**
 * WIRED CHAOS RENDER PROMPT REGISTRY v1.0
 *
 * Canonical prompt definitions for all WIRED CHAOS visual assets.
 * Validated for Trinity 3D Engine, Creator Codex, WCU, and CHAOS OS.
 *
 * TIER-1 BUSINESS | Firewall: BUSINESS | Hemisphere: NEURALIS
 */

// ============================================================================
// BRAND PALETTE (Design Token Registry)
// ============================================================================

export const WIRED_CHAOS_PALETTE = {
  WIRED_BLACK: "#0D0D0D",
  CHAOS_RED: "#FF1A1A",
  NEON_CYAN: "#00FFF7",
  SIGNAL_WHITE: "#FFFFFF",
  GLITCH_PURPLE: "#A020F0",
} as const

// ============================================================================
// RENDER PROMPT TYPES
// ============================================================================

export type RenderStyle = "3D_OCTANE" | "2D_FLAT" | "HYBRID" | "CHAOS_DECK"

export type AssetType =
  | "COVER"
  | "FUNNEL_OVERVIEW"
  | "FREEBIE_ENTRY"
  | "EBOOK"
  | "JOURNAL_TOOLKIT"
  | "BUILDERS_KIT"
  | "ENTITY_PACK"
  | "VISUAL_OPTIONS"
  | "RUSH_MODE"
  | "CONFIRMATION_TRACKING"
  | "DELIVERY"

export interface RenderPrompt {
  assetType: AssetType
  title: string
  notes: string
  prompt: string
  quickPrompt: string
  style: RenderStyle
  palette: {
    base: string
    primary: string
    accent: string
    text: string
    optional: string
  }
  tags: string[]
}

// ============================================================================
// CANONICAL PROMPT REGISTRY
// ============================================================================

export const RENDER_PROMPT_REGISTRY: Record<AssetType, RenderPrompt> = {
  COVER: {
    assetType: "COVER",
    title: "Cover Notes",
    notes: "Black, motherboard, cyan circuitry, Chaos Red paw watermark",
    prompt:
      "3D Octane render cybernetic motherboard background #0D0D0D base, glowing circuitry lines #00FFF7, central paw icon glowing #FF1A1A, cinematic lighting, glitch grain, text accents #FFFFFF, optional edge glow #A020F0.",
    quickPrompt: "Motherboard #0D0D0D + cyan circuits #00FFF7 + red paw #FF1A1A",
    style: "3D_OCTANE",
    palette: {
      base: WIRED_CHAOS_PALETTE.WIRED_BLACK,
      primary: WIRED_CHAOS_PALETTE.NEON_CYAN,
      accent: WIRED_CHAOS_PALETTE.CHAOS_RED,
      text: WIRED_CHAOS_PALETTE.SIGNAL_WHITE,
      optional: WIRED_CHAOS_PALETTE.GLITCH_PURPLE,
    },
    tags: ["cover", "motherboard", "circuits", "paw", "brand"],
  },

  FUNNEL_OVERVIEW: {
    assetType: "FUNNEL_OVERVIEW",
    title: "Funnel Overview",
    notes: "Subway flow map",
    prompt:
      "3D Octane render subway-style map background #0D0D0D, line glowing #00FFF7, circular nodes pulsing #FF1A1A, stop labels #FFFFFF, optional accents #A020F0.",
    quickPrompt: "Subway map #0D0D0D + cyan lines #00FFF7 + red nodes #FF1A1A",
    style: "3D_OCTANE",
    palette: {
      base: WIRED_CHAOS_PALETTE.WIRED_BLACK,
      primary: WIRED_CHAOS_PALETTE.NEON_CYAN,
      accent: WIRED_CHAOS_PALETTE.CHAOS_RED,
      text: WIRED_CHAOS_PALETTE.SIGNAL_WHITE,
      optional: WIRED_CHAOS_PALETTE.GLITCH_PURPLE,
    },
    tags: ["funnel", "subway", "map", "flow", "journey"],
  },

  FREEBIE_ENTRY: {
    assetType: "FREEBIE_ENTRY",
    title: "Freebie Entry",
    notes: "Retro CRT monitor",
    prompt:
      "3D Octane retro CRT monitor, screen text glowing #00FFF7, paw reflection glowing #FF1A1A, deep monitor casing #0D0D0D, body text #FFFFFF, optional glitch flicker #A020F0.",
    quickPrompt: "CRT monitor #0D0D0D + cyan screen #00FFF7 + red paw glow #FF1A1A",
    style: "3D_OCTANE",
    palette: {
      base: WIRED_CHAOS_PALETTE.WIRED_BLACK,
      primary: WIRED_CHAOS_PALETTE.NEON_CYAN,
      accent: WIRED_CHAOS_PALETTE.CHAOS_RED,
      text: WIRED_CHAOS_PALETTE.SIGNAL_WHITE,
      optional: WIRED_CHAOS_PALETTE.GLITCH_PURPLE,
    },
    tags: ["freebie", "crt", "monitor", "retro", "lead-magnet"],
  },

  EBOOK: {
    assetType: "EBOOK",
    title: "eBook",
    notes: "Floating glowing book",
    prompt:
      "3D Octane open book, page edges outlined #00FFF7, glowing bookmark #FF1A1A, motherboard grid #0D0D0D with faint lines #FFFFFF, subtle glitch edges #A020F0.",
    quickPrompt: "Floating book + cyan edges #00FFF7 + red bookmark #FF1A1A",
    style: "3D_OCTANE",
    palette: {
      base: WIRED_CHAOS_PALETTE.WIRED_BLACK,
      primary: WIRED_CHAOS_PALETTE.NEON_CYAN,
      accent: WIRED_CHAOS_PALETTE.CHAOS_RED,
      text: WIRED_CHAOS_PALETTE.SIGNAL_WHITE,
      optional: WIRED_CHAOS_PALETTE.GLITCH_PURPLE,
    },
    tags: ["ebook", "book", "digital-product", "knowledge"],
  },

  JOURNAL_TOOLKIT: {
    assetType: "JOURNAL_TOOLKIT",
    title: "Journal + Toolkit",
    notes: "Notebook with circuitry",
    prompt:
      "3D Octane futuristic notebook #0D0D0D, glowing circuit lines #00FFF7, floating pen #FF1A1A, highlight text #FFFFFF, optional purple rim glow #A020F0.",
    quickPrompt: "Notebook #0D0D0D + cyan circuits #00FFF7 + red pen #FF1A1A",
    style: "3D_OCTANE",
    palette: {
      base: WIRED_CHAOS_PALETTE.WIRED_BLACK,
      primary: WIRED_CHAOS_PALETTE.NEON_CYAN,
      accent: WIRED_CHAOS_PALETTE.CHAOS_RED,
      text: WIRED_CHAOS_PALETTE.SIGNAL_WHITE,
      optional: WIRED_CHAOS_PALETTE.GLITCH_PURPLE,
    },
    tags: ["journal", "toolkit", "notebook", "planning", "templates"],
  },

  BUILDERS_KIT: {
    assetType: "BUILDERS_KIT",
    title: "Builder's Kit",
    notes: "Futuristic workstation",
    prompt:
      "3D Octane workstation, monitors glowing #00FFF7, UI highlights #FF1A1A, desk frame #0D0D0D, white icons #FFFFFF, holographic accents #A020F0.",
    quickPrompt: "Workstation #0D0D0D + cyan monitors #00FFF7 + red UI #FF1A1A",
    style: "3D_OCTANE",
    palette: {
      base: WIRED_CHAOS_PALETTE.WIRED_BLACK,
      primary: WIRED_CHAOS_PALETTE.NEON_CYAN,
      accent: WIRED_CHAOS_PALETTE.CHAOS_RED,
      text: WIRED_CHAOS_PALETTE.SIGNAL_WHITE,
      optional: WIRED_CHAOS_PALETTE.GLITCH_PURPLE,
    },
    tags: ["builders-kit", "workstation", "tools", "premium", "assets"],
  },

  ENTITY_PACK: {
    assetType: "ENTITY_PACK",
    title: "Entity Pack",
    notes: "Circuit tree",
    prompt:
      "3D Octane circuit tree trunk lines #00FFF7, branch nodes glowing #FF1A1A, base dark #0D0D0D, flags rim-lit #FFFFFF, optional haze #A020F0.",
    quickPrompt: "Circuit tree + cyan trunk #00FFF7 + red nodes #FF1A1A",
    style: "3D_OCTANE",
    palette: {
      base: WIRED_CHAOS_PALETTE.WIRED_BLACK,
      primary: WIRED_CHAOS_PALETTE.NEON_CYAN,
      accent: WIRED_CHAOS_PALETTE.CHAOS_RED,
      text: WIRED_CHAOS_PALETTE.SIGNAL_WHITE,
      optional: WIRED_CHAOS_PALETTE.GLITCH_PURPLE,
    },
    tags: ["entity", "legal", "structure", "business", "tree"],
  },

  VISUAL_OPTIONS: {
    assetType: "VISUAL_OPTIONS",
    title: "Visual Options",
    notes: "2D vs 3D vs Chaos Deck",
    prompt:
      "3D Octane split screen, 2D section #FFFFFF with cyan highlights #00FFF7, hybrid Chaos Deck red/cyan #FF1A1A + #00FFF7, right side glowing paw #FF1A1A, dark base #0D0D0D, accents #A020F0.",
    quickPrompt: "Split screen + 2D white #FFFFFF + 3D deck cyan/red",
    style: "HYBRID",
    palette: {
      base: WIRED_CHAOS_PALETTE.WIRED_BLACK,
      primary: WIRED_CHAOS_PALETTE.NEON_CYAN,
      accent: WIRED_CHAOS_PALETTE.CHAOS_RED,
      text: WIRED_CHAOS_PALETTE.SIGNAL_WHITE,
      optional: WIRED_CHAOS_PALETTE.GLITCH_PURPLE,
    },
    tags: ["options", "comparison", "2d-vs-3d", "chaos-deck"],
  },

  RUSH_MODE: {
    assetType: "RUSH_MODE",
    title: "Rush Mode",
    notes: "Futuristic clock",
    prompt:
      "3D Octane glowing cyber clock base #0D0D0D, hands glowing #FF1A1A, spiraling circuitry #00FFF7, ticks #FFFFFF, outer pulse #A020F0.",
    quickPrompt: "Cyber clock #0D0D0D + red hands #FF1A1A + cyan circuits #00FFF7",
    style: "3D_OCTANE",
    palette: {
      base: WIRED_CHAOS_PALETTE.WIRED_BLACK,
      primary: WIRED_CHAOS_PALETTE.NEON_CYAN,
      accent: WIRED_CHAOS_PALETTE.CHAOS_RED,
      text: WIRED_CHAOS_PALETTE.SIGNAL_WHITE,
      optional: WIRED_CHAOS_PALETTE.GLITCH_PURPLE,
    },
    tags: ["rush", "urgency", "clock", "deadline", "timer"],
  },

  CONFIRMATION_TRACKING: {
    assetType: "CONFIRMATION_TRACKING",
    title: "Confirmation & Tracking",
    notes: "4-stage progress bar",
    prompt:
      "3D Octane progress bar #0D0D0D, nodes glowing #00FFF7, active node pulsing #FF1A1A, labels #FFFFFF, inactive glow #A020F0.",
    quickPrompt: "Progress bar #0D0D0D + cyan nodes #00FFF7 + red active #FF1A1A",
    style: "3D_OCTANE",
    palette: {
      base: WIRED_CHAOS_PALETTE.WIRED_BLACK,
      primary: WIRED_CHAOS_PALETTE.NEON_CYAN,
      accent: WIRED_CHAOS_PALETTE.CHAOS_RED,
      text: WIRED_CHAOS_PALETTE.SIGNAL_WHITE,
      optional: WIRED_CHAOS_PALETTE.GLITCH_PURPLE,
    },
    tags: ["confirmation", "tracking", "progress", "status", "journey"],
  },

  DELIVERY: {
    assetType: "DELIVERY",
    title: "Delivery",
    notes: "Download box",
    prompt:
      "3D Octane glowing download box #0D0D0D, arrows glowing #00FFF7, file icons rim-lit #FFFFFF, paw watermark glowing #FF1A1A, accents #A020F0.",
    quickPrompt: "Download box #0D0D0D + cyan arrows #00FFF7 + red paw #FF1A1A",
    style: "3D_OCTANE",
    palette: {
      base: WIRED_CHAOS_PALETTE.WIRED_BLACK,
      primary: WIRED_CHAOS_PALETTE.NEON_CYAN,
      accent: WIRED_CHAOS_PALETTE.CHAOS_RED,
      text: WIRED_CHAOS_PALETTE.SIGNAL_WHITE,
      optional: WIRED_CHAOS_PALETTE.GLITCH_PURPLE,
    },
    tags: ["delivery", "download", "files", "completion", "access"],
  },
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Get render prompt by asset type
 */
export function getRenderPrompt(assetType: AssetType): RenderPrompt {
  return RENDER_PROMPT_REGISTRY[assetType]
}

/**
 * Get quick prompt for rapid rendering
 */
export function getQuickPrompt(assetType: AssetType): string {
  return RENDER_PROMPT_REGISTRY[assetType].quickPrompt
}

/**
 * Get full prompt for detailed rendering
 */
export function getFullPrompt(assetType: AssetType): string {
  return RENDER_PROMPT_REGISTRY[assetType].prompt
}

/**
 * Search prompts by tag
 */
export function searchByTag(tag: string): RenderPrompt[] {
  return Object.values(RENDER_PROMPT_REGISTRY).filter((prompt) => prompt.tags.includes(tag.toLowerCase()))
}

/**
 * Get all asset types
 */
export function getAllAssetTypes(): AssetType[] {
  return Object.keys(RENDER_PROMPT_REGISTRY) as AssetType[]
}

/**
 * Generate custom prompt with variable substitution
 */
export function generateCustomPrompt(assetType: AssetType, overrides?: Partial<RenderPrompt["palette"]>): string {
  const base = RENDER_PROMPT_REGISTRY[assetType]
  const palette = { ...base.palette, ...overrides }

  return base.prompt
    .replace(/#0D0D0D/g, palette.base)
    .replace(/#00FFF7/g, palette.primary)
    .replace(/#FF1A1A/g, palette.accent)
    .replace(/#FFFFFF/g, palette.text)
    .replace(/#A020F0/g, palette.optional)
}
