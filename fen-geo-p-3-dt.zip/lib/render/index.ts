/**
 * WIRED CHAOS RENDER SYSTEM
 * Public exports for prompt registry and utilities
 */

export {
  WIRED_CHAOS_PALETTE,
  RENDER_PROMPT_REGISTRY,
  getRenderPrompt,
  getQuickPrompt,
  getFullPrompt,
  searchByTag,
  getAllAssetTypes,
  generateCustomPrompt,
} from "./prompt-registry"

export type { RenderPrompt, RenderStyle, AssetType } from "./prompt-registry"
