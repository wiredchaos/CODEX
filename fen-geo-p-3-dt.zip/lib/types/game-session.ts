/**
 * WIRED CHAOS META - Canonical GameSession Interface
 * Registry: UI.PRIMITIVE.GAMEFRAME_V1
 * Namespace: CHAOS OS → Arcade Layer
 *
 * Shared by: Business, Education, ARG/Akashic, NSFW firewalled modes
 */

// ─────────────────────────────────────────────────────────────────────────────
// FIREWALL MODES - Determines routing and content restrictions
// ─────────────────────────────────────────────────────────────────────────────
export type FirewallMode =
  | "BUSINESS" // Credit Repair, Tax, HRM, Regulatory, Supply Chain
  | "EDUCATION" // WCU, NPC Labyrinth, Onboarding
  | "AKASHIC" // ARG, Lore, VRG33589, Vault 33
  | "NSFW_LIGHT" // 789 Afterhours (18+)
  | "NSFW_DARK" // Akira Codex (21+)

// ─────────────────────────────────────────────────────────────────────────────
// PATCH IDENTIFIERS - Maps to specific engine/swarm routing
// ─────────────────────────────────────────────────────────────────────────────
export type PatchIdentifier =
  // Gaming / Arcade
  | "PATCH.GAME.CHAOS_ARCADE_CORE"
  | "GAME.RVP_UNEMPIRE"
  | "GAME.HRM_ARENA"
  | "GAME.CRYPTO_WHISPER"
  // Education
  | "PATCH.EDU.NPC_LABYRINTH"
  | "PATCH.EDU.WCU_ARCADE"
  | "PATCH.EDU.HRM_ONBOARDING_SUITE"
  // Business Suite
  | "PATCH.BIZ.CREDIT_REPAIR_SWARM"
  | "PATCH.BIZ.FINANCE_BOOTCAMP"
  | "PATCH.BIZ.VAULT_DCA_ENGINE"
  | "PATCH.BIZ.NEURA_TAX_SUITE"
  | "PATCH.BIZ.REGULATORY_SWARM"
  | "PATCH.BIZ.ISO_SUPPLY_SWARM"
  // ARG / Akashic
  | "PATCH.ARG.AKASHIC_LAB"
  // NSFW Channels
  | "PATCH.NSFW.789_AFTERHOURS"
  | "PATCH.NSFW.AKIRA_CODEX_DARK"

// ─────────────────────────────────────────────────────────────────────────────
// LEDGER / CHAIN INTEGRATION
// ─────────────────────────────────────────────────────────────────────────────
export type LedgerType = "DOGE" | "XRPL" | "XLM" | "ETH" | "BTC" | "HELIUM" | "NONE"

// ─────────────────────────────────────────────────────────────────────────────
// GAME SESSION - Core data model shared across all patches
// ─────────────────────────────────────────────────────────────────────────────
export interface GameSession {
  // Identity
  id: string
  patch: PatchIdentifier
  firewall: FirewallMode

  // Player State
  playerId: string
  playerName: string
  xp: number
  level: number

  // Current Scene
  scene: GameScene

  // Available Choices
  choices: GameChoice[]

  // Side Panel Variables (context-dependent)
  variables: Record<string, GameVariable>

  // Event Log
  logs: GameLogEntry[]

  // Ledger Integration (optional)
  ledger?: {
    type: LedgerType
    walletAddress?: string
    balance?: number
    transactions?: LedgerTransaction[]
  }

  // Metadata
  createdAt: number
  updatedAt: number
  seasonYear?: number
}

// ─────────────────────────────────────────────────────────────────────────────
// GAME SCENE - The current narrative/scenario state
// ─────────────────────────────────────────────────────────────────────────────
export interface GameScene {
  id: string
  title: string
  narrative: string
  imageUrl?: string
  tags?: string[]

  // Scene-specific metadata
  metadata?: {
    jurisdiction?: string // For regulatory/tax scenes
    riskLevel?: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL"
    timeline?: string // For historical/lore scenes
    factionAlignment?: string // For NPC/ARG scenes
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// GAME CHOICE - Player action options
// ─────────────────────────────────────────────────────────────────────────────
export interface GameChoice {
  id: string
  label: string
  description?: string

  // Visual
  icon?: string
  variant?: "default" | "destructive" | "secondary" | "outline"
  disabled?: boolean

  // Consequences (preview)
  preview?: {
    xpChange?: number
    riskDelta?: number
    outcomeHint?: string
  }

  // NSFW-specific (only in NSFW firewall modes)
  nsfw?: {
    consentRequired?: boolean
    boundaryTag?: string
    safeWord?: string
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// GAME VARIABLE - Side panel state tracking
// ─────────────────────────────────────────────────────────────────────────────
export interface GameVariable {
  key: string
  label: string
  value: string | number | boolean
  type: "text" | "number" | "percentage" | "currency" | "badge" | "progress"

  // Display options
  icon?: string
  color?: string
  max?: number // For progress bars
}

// ─────────────────────────────────────────────────────────────────────────────
// GAME LOG ENTRY - Event history
// ─────────────────────────────────────────────────────────────────────────────
export interface GameLogEntry {
  id: string
  message: string
  timestamp: number
  type:
    | "SYSTEM"
    | "CHOICE"
    | "OUTCOME"
    | "XP_GAIN"
    | "LEVEL_UP"
    | "ALLIANCE"
    | "ATTACK"
    | "DEFENSE"
    | "CLAIM"
    | "TRANSACTION"
    | "REGULATORY"
    | "LORE"
    | "WARNING"
    | "NSFW_BOUNDARY"

  metadata?: Record<string, unknown>
}

// ─────────────────────────────────────────────────────────────────────────────
// LEDGER TRANSACTION - Chain/wallet activity
// ─────────────────────────────────────────────────────────────────────────────
export interface LedgerTransaction {
  id: string
  type: "DEPOSIT" | "WITHDRAWAL" | "REWARD" | "FEE" | "SWAP"
  amount: number
  timestamp: number
  status: "PENDING" | "CONFIRMED" | "FAILED"
  txHash?: string
}

// ─────────────────────────────────────────────────────────────────────────────
// API INTERFACES - For engine routing
// ─────────────────────────────────────────────────────────────────────────────
export interface GameSessionCreateRequest {
  patch: PatchIdentifier
  playerId: string
  playerName: string
  initialVariables?: Record<string, GameVariable>
}

export interface GameChoiceRequest {
  sessionId: string
  choiceId: string
  playerId: string
}

export interface GameSessionResponse {
  session: GameSession
  error?: string
}

// ─────────────────────────────────────────────────────────────────────────────
// THEME CONFIGURATION - Per-patch visual overrides
// ─────────────────────────────────────────────────────────────────────────────
export interface GameFrameTheme {
  patch: PatchIdentifier

  // Colors (CSS custom property overrides)
  primaryColor?: string
  accentColor?: string
  backgroundColor?: string

  // Branding
  logoUrl?: string
  headerTitle?: string

  // Layout
  showLedgerPanel?: boolean
  showXPBar?: boolean
  logMaxEntries?: number
}

// ─────────────────────────────────────────────────────────────────────────────
// DEFAULT THEMES - Pre-configured per patch category
// ─────────────────────────────────────────────────────────────────────────────
export const DEFAULT_THEMES: Partial<Record<PatchIdentifier, Partial<GameFrameTheme>>> = {
  "GAME.RVP_UNEMPIRE": {
    primaryColor: "oklch(0.76 0.18 106)",
    headerTitle: "Unholy Unroman Unempire",
    showXPBar: true,
  },
  "PATCH.BIZ.CREDIT_REPAIR_SWARM": {
    primaryColor: "oklch(0.65 0.15 160)",
    headerTitle: "Credit Repair Simulator",
    showLedgerPanel: false,
  },
  "PATCH.EDU.NPC_LABYRINTH": {
    primaryColor: "oklch(0.70 0.20 280)",
    headerTitle: "World-Building Labyrinth",
    showXPBar: true,
  },
  "PATCH.ARG.AKASHIC_LAB": {
    primaryColor: "oklch(0.55 0.25 300)",
    headerTitle: "Akashic Records",
    showLedgerPanel: false,
  },
}
