/**
 * CREATOR CODEX PROMPT LOADER
 *
 * Auto-inject render prompts into template generation workflows.
 * Integrates with WIRED CHAOS RENDER PROMPT REGISTRY.
 */

import promptPluginConfig from "./prompt-plugin.json"
import { getRenderPrompt, getQuickPrompt, type AssetType } from "../render/prompt-registry"

// ============================================================================
// LOADER CONFIGURATION
// ============================================================================

export const CODEX_CONFIG = promptPluginConfig.wdc_prompt_registry

// ============================================================================
// AUTO-INJECTION ENGINE
// ============================================================================

export interface TemplateContext {
  templateType: string
  assetType?: AssetType
  customPalette?: Record<string, string>
  style?: "quick" | "full"
}

export interface InjectedPrompt {
  prompt: string
  palette: Record<string, string>
  style: string
  effects: string[]
}

/**
 * Auto-inject render prompt based on template context
 */
export function injectPrompt(context: TemplateContext): InjectedPrompt {
  const { templateType, assetType, style = "full" } = context

  // Map template type to asset type if not explicitly provided
  const resolvedAssetType = assetType || resolveAssetType(templateType)

  if (!resolvedAssetType) {
    throw new Error(`Cannot resolve asset type for template: ${templateType}`)
  }

  const prompt = style === "quick" ? getQuickPrompt(resolvedAssetType) : getRenderPrompt(resolvedAssetType).prompt

  return {
    prompt,
    palette: context.customPalette || CODEX_CONFIG.core_palette,
    style: CODEX_CONFIG.auto_inject.default_style,
    effects: CODEX_CONFIG.auto_inject.effects,
  }
}

/**
 * Resolve template type to asset type
 */
function resolveAssetType(templateType: string): AssetType | null {
  const mapping: Record<string, AssetType> = {
    cover: "COVER",
    funnel: "FUNNEL_OVERVIEW",
    freebie: "FREEBIE_ENTRY",
    ebook: "EBOOK",
    journal: "JOURNAL_TOOLKIT",
    builder: "BUILDERS_KIT",
    entity: "ENTITY_PACK",
    visuals: "VISUAL_OPTIONS",
    rush: "RUSH_MODE",
    tracking: "CONFIRMATION_TRACKING",
    delivery: "DELIVERY",
  }

  return mapping[templateType.toLowerCase()] || null
}

/**
 * Batch inject prompts for multiple templates
 */
export function batchInjectPrompts(contexts: TemplateContext[]): InjectedPrompt[] {
  return contexts.map(injectPrompt)
}

/**
 * Check if auto-injection is enabled
 */
export function isAutoInjectEnabled(): boolean {
  return CODEX_CONFIG.auto_inject.enabled
}

/**
 * Get supported template types
 */
export function getSupportedTemplates(): string[] {
  return Object.keys(CODEX_CONFIG.templates)
}
