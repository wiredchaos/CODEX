/**
 * WIRED CHAOS META - Trinity Floor / Timeline Mount System
 *
 * DECLARATIVE CONSUMER PATCH
 * ═══════════════════════════════════════════════════════════════════════════
 * This patch consumes the existing WIRED CHAOS Trinity 3D Core.
 *
 * Declarations:
 * - No new 3D generation
 * - No new galaxy creation
 * - This patch mounts to its assigned Trinity Floor or Timeline
 * - Timeline access is governed by Akira Codex
 * - Trinity is read-only infrastructure
 *
 * This patch operates as a CONSUMER, not an owner.
 * ═══════════════════════════════════════════════════════════════════════════
 */

import type { TrinitySceneId, RealmMode, TrinityScene } from "./scene-registry"
import { getSceneById, getDefaultSceneForRealm } from "./scene-registry"
import { getGameConfig } from "./game-registry"

// ─────────────────────────────────────────────────────────────────────────────
// MOUNT DECLARATIONS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Mount access level - all patches are READ_ONLY consumers
 */
export type MountAccessLevel = "READ_ONLY"

/**
 * Timeline governance authority
 */
export type TimelineGovernor = "AKIRA_CODEX"

/**
 * Mount status for a consumer patch
 */
export type MountStatus =
  | "UNMOUNTED" // Not yet bound to Trinity
  | "MOUNTING" // In process of binding
  | "MOUNTED" // Successfully consuming Trinity Floor
  | "SUSPENDED" // Temporarily suspended by Akira Codex
  | "DENIED" // Access denied by governance

/**
 * Trinity Floor binding - read-only reference to scene infrastructure
 */
export interface TrinityFloorBinding {
  readonly floorId: TrinitySceneId
  readonly realm: RealmMode
  readonly accessLevel: MountAccessLevel
  readonly timestamp: number
}

/**
 * Timeline binding - read-only reference to temporal state
 */
export interface TimelineBinding {
  readonly timelineId: string
  readonly epoch: number
  readonly governor: TimelineGovernor
  readonly branchIndex: number
  readonly accessLevel: MountAccessLevel
}

/**
 * Consumer mount handle - the interface patches use to interact with Trinity
 */
export interface TrinityMountHandle {
  readonly patchId: string
  readonly status: MountStatus
  readonly floor: TrinityFloorBinding | null
  readonly timeline: TimelineBinding | null
  readonly scene: TrinityScene | null
  readonly mountedAt: number | null
  readonly lastAccess: number
}

// ─────────────────────────────────────────────────────────────────────────────
// AKIRA CODEX GOVERNANCE
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Akira Codex governance rules for timeline access
 */
export interface AkiraCodexRules {
  readonly governorId: TimelineGovernor
  readonly allowedRealms: readonly RealmMode[]
  readonly requiresAuthentication: boolean
  readonly maxConcurrentMounts: number
  readonly timelineBranchingAllowed: boolean
}

const AKIRA_CODEX_DEFAULT_RULES: AkiraCodexRules = {
  governorId: "AKIRA_CODEX",
  allowedRealms: ["business", "akashic", "underground"] as const,
  requiresAuthentication: true,
  maxConcurrentMounts: 3,
  timelineBranchingAllowed: false, // Only Akira Codex can branch timelines
}

/**
 * Validate timeline access against Akira Codex rules
 */
export function validateTimelineAccess(
  patchId: string,
  realm: RealmMode,
  rules: AkiraCodexRules = AKIRA_CODEX_DEFAULT_RULES,
): { allowed: boolean; reason?: string } {
  // Check realm allowance
  if (!rules.allowedRealms.includes(realm)) {
    return {
      allowed: false,
      reason: `Realm '${realm}' not permitted by Akira Codex`,
    }
  }

  // Additional governance checks would go here
  // For now, all realm-valid requests are allowed
  return { allowed: true }
}

// ─────────────────────────────────────────────────────────────────────────────
// MOUNT FACTORY (READ-ONLY CONSUMER)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Active mount registry - tracks all consumer patches
 */
const activeMounts = new Map<string, TrinityMountHandle>()

/**
 * Create an unmounted handle for a patch
 */
export function createUnmountedHandle(patchId: string): TrinityMountHandle {
  return {
    patchId,
    status: "UNMOUNTED",
    floor: null,
    timeline: null,
    scene: null,
    mountedAt: null,
    lastAccess: Date.now(),
  }
}

/**
 * Request mount to a Trinity Floor (read-only consumer binding)
 *
 * This does NOT create new 3D content - it binds to existing infrastructure
 */
export function requestFloorMount(patchId: string, floorId: TrinitySceneId, realm: RealmMode): TrinityMountHandle {
  // Validate access through Akira Codex
  const validation = validateTimelineAccess(patchId, realm)

  if (!validation.allowed) {
    console.warn(`[Trinity Mount] Access denied for ${patchId}: ${validation.reason}`)
    return {
      patchId,
      status: "DENIED",
      floor: null,
      timeline: null,
      scene: null,
      mountedAt: null,
      lastAccess: Date.now(),
    }
  }

  // Get existing scene from registry (READ-ONLY)
  const scene = getSceneById(floorId)

  if (!scene) {
    console.warn(`[Trinity Mount] Floor ${floorId} not found in Trinity Core`)
    return createUnmountedHandle(patchId)
  }

  // Verify realm match
  if (scene.realm !== realm) {
    console.warn(`[Trinity Mount] Realm mismatch: floor ${floorId} is ${scene.realm}, requested ${realm}`)
  }

  const now = Date.now()

  // Create read-only floor binding
  const floorBinding: TrinityFloorBinding = {
    floorId,
    realm: scene.realm,
    accessLevel: "READ_ONLY",
    timestamp: now,
  }

  // Create timeline binding under Akira Codex governance
  const timelineBinding: TimelineBinding = {
    timelineId: `TL-${patchId}-${now}`,
    epoch: now,
    governor: "AKIRA_CODEX",
    branchIndex: 0, // Main branch only - no branching without Akira Codex
    accessLevel: "READ_ONLY",
  }

  const handle: TrinityMountHandle = {
    patchId,
    status: "MOUNTED",
    floor: floorBinding,
    timeline: timelineBinding,
    scene, // Read-only reference to existing scene
    mountedAt: now,
    lastAccess: now,
  }

  // Register in active mounts
  activeMounts.set(patchId, handle)

  return handle
}

/**
 * Mount a game/patch to its configured Trinity Floor
 */
export function mountGameToTrinity(gameSlug: string): TrinityMountHandle {
  const config = getGameConfig(gameSlug)

  if (!config) {
    console.warn(`[Trinity Mount] Game config not found: ${gameSlug}`)
    return createUnmountedHandle(gameSlug)
  }

  return requestFloorMount(gameSlug, config.trinityScene, config.realm)
}

/**
 * Mount a patch to default floor for its realm
 */
export function mountToDefaultFloor(patchId: string, realm: RealmMode): TrinityMountHandle {
  const defaultScene = getDefaultSceneForRealm(realm)
  return requestFloorMount(patchId, defaultScene.id, realm)
}

// ─────────────────────────────────────────────────────────────────────────────
// MOUNT LIFECYCLE
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Unmount a patch from Trinity (release read-only binding)
 */
export function unmountFromTrinity(patchId: string): void {
  const existing = activeMounts.get(patchId)

  if (existing) {
    // Update to unmounted state
    activeMounts.set(patchId, {
      ...existing,
      status: "UNMOUNTED",
      floor: null,
      timeline: null,
      scene: null,
      lastAccess: Date.now(),
    })
  }
}

/**
 * Suspend a mount (Akira Codex governance action)
 */
export function suspendMount(patchId: string, reason: string): void {
  const existing = activeMounts.get(patchId)

  if (existing && existing.status === "MOUNTED") {
    console.warn(`[Trinity Mount] Suspending ${patchId}: ${reason}`)
    activeMounts.set(patchId, {
      ...existing,
      status: "SUSPENDED",
      lastAccess: Date.now(),
    })
  }
}

/**
 * Get current mount status for a patch
 */
export function getMountStatus(patchId: string): TrinityMountHandle | null {
  return activeMounts.get(patchId) ?? null
}

/**
 * Get all active mounts
 */
export function getActiveMounts(): TrinityMountHandle[] {
  return Array.from(activeMounts.values()).filter((m) => m.status === "MOUNTED")
}

/**
 * Check if a patch is currently mounted
 */
export function isMounted(patchId: string): boolean {
  const handle = activeMounts.get(patchId)
  return handle?.status === "MOUNTED"
}

// ─────────────────────────────────────────────────────────────────────────────
// READ-ONLY ACCESSORS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Get scene theme for a mounted patch (read-only)
 */
export function getMountedSceneTheme(patchId: string): TrinityScene["theme"] | null {
  const handle = activeMounts.get(patchId)
  return handle?.scene?.theme ?? null
}

/**
 * Get floor ID for a mounted patch
 */
export function getMountedFloorId(patchId: string): TrinitySceneId | null {
  const handle = activeMounts.get(patchId)
  return handle?.floor?.floorId ?? null
}

/**
 * Get realm for a mounted patch
 */
export function getMountedRealm(patchId: string): RealmMode | null {
  const handle = activeMounts.get(patchId)
  return handle?.floor?.realm ?? null
}

// ─────────────────────────────────────────────────────────────────────────────
// EXPORTS
// ─────────────────────────────────────────────────────────────────────────────

export { AKIRA_CODEX_DEFAULT_RULES }
