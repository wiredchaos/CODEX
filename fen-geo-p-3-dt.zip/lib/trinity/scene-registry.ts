/**
 * WIRED CHAOS META - Trinity Reality Model
 * Scene Registry for 3D environments
 *
 * Realms:
 *   - BUSINESS → Neuralis (calm, classroom, control rooms)
 *   - AKASHIC  → Echo (observation decks, Vault 33, VRG33589)
 *   - UNDERGROUND → Chaosphere (arcades, alleys, NSFW corridors)
 */

export type RealmMode = "business" | "akashic" | "underground"

export type TrinitySceneId =
  // Neuralis - Business/Education realm
  | "neuralis-hub"
  | "neuralis-classroom"
  | "neuralis-control-room"
  // Chaosphere - Underground/Gaming realm
  | "chaosphere-arena"
  | "chaosphere-arcade"
  | "chaosphere-trench"
  | "chaosphere-afterhours"
  // Echo - Akashic/Lore realm
  | "echo-observation"
  | "echo-vault33"
  | "echo-589"

export type SceneKind = "spline" | "tripod3d" | "video" | "css"

export interface TrinityScene {
  id: TrinitySceneId
  realm: RealmMode
  label: string
  kind: SceneKind
  src: string
  cameraHint?: string
  // Theme colors for HUD overlay
  theme: {
    primary: string
    accent: string
    background: string
    foreground: string
    muted: string
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// TRINITY SCENE DEFINITIONS
// ─────────────────────────────────────────────────────────────────────────────
export const TRINITY_SCENES: TrinityScene[] = [
  // ═══════════════════════════════════════════════════════════════════════════
  // NEURALIS - Business/Education Realm
  // Deep blue-grey, cyan, soft violet
  // ═══════════════════════════════════════════════════════════════════════════
  {
    id: "neuralis-hub",
    realm: "business",
    label: "Neuralis Hub",
    kind: "css",
    src: "neuralis-hub",
    theme: {
      primary: "oklch(0.70 0.15 220)", // cyan-blue
      accent: "oklch(0.65 0.12 280)", // soft violet
      background: "oklch(0.15 0.02 240)", // deep blue-grey
      foreground: "oklch(0.95 0.01 240)",
      muted: "oklch(0.45 0.05 240)",
    },
  },
  {
    id: "neuralis-classroom",
    realm: "business",
    label: "Neuralis Classroom",
    kind: "css",
    src: "neuralis-classroom",
    theme: {
      primary: "oklch(0.68 0.14 200)",
      accent: "oklch(0.60 0.10 260)",
      background: "oklch(0.12 0.02 220)",
      foreground: "oklch(0.95 0.01 220)",
      muted: "oklch(0.50 0.04 220)",
    },
  },
  {
    id: "neuralis-control-room",
    realm: "business",
    label: "Neuralis Control Room",
    kind: "css",
    src: "neuralis-control-room",
    theme: {
      primary: "oklch(0.65 0.18 190)",
      accent: "oklch(0.55 0.15 160)",
      background: "oklch(0.10 0.03 200)",
      foreground: "oklch(0.95 0.01 200)",
      muted: "oklch(0.40 0.05 200)",
    },
  },

  // ═══════════════════════════════════════════════════════════════════════════
  // CHAOSPHERE - Underground/Gaming Realm
  // Near black, ruby, fuchsia
  // ═══════════════════════════════════════════════════════════════════════════
  {
    id: "chaosphere-arena",
    realm: "underground",
    label: "Chaosphere Arena",
    kind: "css",
    src: "chaosphere-arena",
    theme: {
      primary: "oklch(0.60 0.25 0)", // ruby red
      accent: "oklch(0.65 0.30 330)", // fuchsia
      background: "oklch(0.08 0.02 350)", // near black with red tint
      foreground: "oklch(0.95 0.02 350)",
      muted: "oklch(0.40 0.08 350)",
    },
  },
  {
    id: "chaosphere-arcade",
    realm: "underground",
    label: "Neuro Node Arcade",
    kind: "css",
    src: "chaosphere-arcade",
    theme: {
      primary: "oklch(0.70 0.28 330)", // hot pink
      accent: "oklch(0.55 0.22 280)", // purple
      background: "oklch(0.06 0.03 300)", // void black with purple tint
      foreground: "oklch(0.95 0.02 300)",
      muted: "oklch(0.45 0.10 300)",
    },
  },
  {
    id: "chaosphere-trench",
    realm: "underground",
    label: "VectoR TrencH",
    kind: "css",
    src: "chaosphere-trench",
    theme: {
      primary: "oklch(0.55 0.30 15)", // blood red
      accent: "oklch(0.75 0.25 60)", // amber warning
      background: "oklch(0.05 0.02 20)",
      foreground: "oklch(0.90 0.03 20)",
      muted: "oklch(0.35 0.08 20)",
    },
  },
  {
    id: "chaosphere-afterhours",
    realm: "underground",
    label: "789 Afterhours",
    kind: "css",
    src: "chaosphere-afterhours",
    theme: {
      primary: "oklch(0.65 0.25 340)", // pink
      accent: "oklch(0.50 0.20 320)", // deep magenta
      background: "oklch(0.04 0.03 330)",
      foreground: "oklch(0.92 0.02 330)",
      muted: "oklch(0.38 0.10 330)",
    },
  },

  // ═══════════════════════════════════════════════════════════════════════════
  // ECHO - Akashic/Lore Realm
  // Void black, glowing violet/magenta
  // ═══════════════════════════════════════════════════════════════════════════
  {
    id: "echo-observation",
    realm: "akashic",
    label: "Echo Observation Deck",
    kind: "css",
    src: "echo-observation",
    theme: {
      primary: "oklch(0.60 0.25 290)", // violet
      accent: "oklch(0.55 0.30 320)", // magenta
      background: "oklch(0.03 0.02 290)", // void black
      foreground: "oklch(0.90 0.03 290)",
      muted: "oklch(0.35 0.12 290)",
    },
  },
  {
    id: "echo-vault33",
    realm: "akashic",
    label: "Vault 33",
    kind: "css",
    src: "echo-vault33",
    theme: {
      primary: "oklch(0.50 0.20 270)", // deep purple
      accent: "oklch(0.60 0.28 300)", // bright magenta
      background: "oklch(0.02 0.02 280)",
      foreground: "oklch(0.88 0.04 280)",
      muted: "oklch(0.32 0.10 280)",
    },
  },
  {
    id: "echo-589",
    realm: "akashic",
    label: "VRG33589 Chamber",
    kind: "css",
    src: "echo-589",
    theme: {
      primary: "oklch(0.55 0.22 260)",
      accent: "oklch(0.70 0.30 310)",
      background: "oklch(0.01 0.01 270)",
      foreground: "oklch(0.85 0.05 270)",
      muted: "oklch(0.30 0.08 270)",
    },
  },
]

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────────────────────
export function getSceneById(id: TrinitySceneId): TrinityScene | undefined {
  return TRINITY_SCENES.find((s) => s.id === id)
}

export function getScenesByRealm(realm: RealmMode): TrinityScene[] {
  return TRINITY_SCENES.filter((s) => s.realm === realm)
}

export function getDefaultSceneForRealm(realm: RealmMode): TrinityScene {
  const scenes = getScenesByRealm(realm)
  return scenes[0]
}
