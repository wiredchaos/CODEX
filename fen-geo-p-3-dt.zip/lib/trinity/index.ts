/**
 * WIRED CHAOS META - Trinity Module Exports
 *
 * Public API for Trinity 3D Core consumption
 */

// Scene Registry (read-only infrastructure)
export {
  type RealmMode,
  type TrinitySceneId,
  type SceneKind,
  type TrinityScene,
  TRINITY_SCENES,
  getSceneById,
  getScenesByRealm,
  getDefaultSceneForRealm,
} from "./scene-registry"

// Game Registry (patch configurations)
export {
  type GameConfig,
  GAMES,
  getGameConfig,
  getGamesByRealm,
  getGamesByFirewall,
} from "./game-registry"

// Mount System (consumer bindings)
export {
  // Types
  type MountAccessLevel,
  type TimelineGovernor,
  type MountStatus,
  type TrinityFloorBinding,
  type TimelineBinding,
  type TrinityMountHandle,
  type AkiraCodexRules,
  // Governance
  AKIRA_CODEX_DEFAULT_RULES,
  validateTimelineAccess,
  // Mount operations
  createUnmountedHandle,
  requestFloorMount,
  mountGameToTrinity,
  mountToDefaultFloor,
  unmountFromTrinity,
  suspendMount,
  // Accessors
  getMountStatus,
  getActiveMounts,
  isMounted,
  getMountedSceneTheme,
  getMountedFloorId,
  getMountedRealm,
} from "./mount-system"
