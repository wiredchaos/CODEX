/**
 * WIRED CHAOS META - Game/Patch Registry
 * Binds games to realm + scene + template + agents
 */

import type { RealmMode, TrinitySceneId } from "./scene-registry"
import type { FirewallMode } from "@/lib/types/game-session"

export interface GameConfig {
  slug: string
  title: string
  description: string
  realm: RealmMode
  firewall: FirewallMode
  trinityScene: TrinitySceneId
  template: "GameFrame_v1"
  agents: string[]
  // Initial player setup
  initialXP?: number
  initialLevel?: number
}

// ─────────────────────────────────────────────────────────────────────────────
// GAME CONFIGURATIONS
// ─────────────────────────────────────────────────────────────────────────────
export const GAMES: GameConfig[] = [
  // ═══════════════════════════════════════════════════════════════════════════
  // UNDERGROUND / GAMING
  // ═══════════════════════════════════════════════════════════════════════════
  {
    slug: "rvp-unempire",
    title: "RVP Crownfall Protocol",
    description: "Geopolitical conquest simulation",
    realm: "underground",
    firewall: "EDUCATION",
    trinityScene: "chaosphere-arcade",
    template: "GameFrame_v1",
    agents: ["RVP_GENERAL", "XP_CORE", "DOGE_VAULT"],
  },
  {
    slug: "vector-trench",
    title: "VectoR TrencH",
    description: "High-intensity trading arena",
    realm: "underground",
    firewall: "BUSINESS",
    trinityScene: "chaosphere-trench",
    template: "GameFrame_v1",
    agents: ["TRENCH_ENGINE", "CRYPTO_WHISPER"],
  },
  {
    slug: "crypto-whisper",
    title: "Crypto Whisper",
    description: "Trading sentiment simulator",
    realm: "underground",
    firewall: "BUSINESS",
    trinityScene: "chaosphere-arcade",
    template: "GameFrame_v1",
    agents: ["CRYPTO_WHISPER", "MARKET_SWARM"],
  },

  // ═══════════════════════════════════════════════════════════════════════════
  // BUSINESS / EDUCATION
  // ═══════════════════════════════════════════════════════════════════════════
  {
    slug: "credit-repair-sim",
    title: "Credit Repair Scenario Lab",
    description: "Learn credit repair strategies through simulation",
    realm: "business",
    firewall: "BUSINESS",
    trinityScene: "neuralis-classroom",
    template: "GameFrame_v1",
    agents: ["CREDIT_SWARM", "NEURA_TAX"],
  },
  {
    slug: "finance-bootcamp",
    title: "Financial Advisor Sim",
    description: "Tiered financial decision training",
    realm: "business",
    firewall: "EDUCATION",
    trinityScene: "neuralis-hub",
    template: "GameFrame_v1",
    agents: ["FINANCE_ENGINE", "DCA_SWARM"],
  },
  {
    slug: "vault-dca",
    title: "BTC/XRP/Helium Vault DCA",
    description: "Vault allocation and mining simulation",
    realm: "business",
    firewall: "BUSINESS",
    trinityScene: "neuralis-control-room",
    template: "GameFrame_v1",
    agents: ["VAULT_DCA_ENGINE", "HELIUM_TRACKER"],
  },
  {
    slug: "neura-tax",
    title: "NEURA Tax Training",
    description: "Tax compliance and entity structuring",
    realm: "business",
    firewall: "BUSINESS",
    trinityScene: "neuralis-classroom",
    template: "GameFrame_v1",
    agents: ["NEURA_TAX", "REGULATORY_SWARM"],
  },
  {
    slug: "regulatory-swarm",
    title: "Regulatory Impact Simulator",
    description: "Policy impact training and mitigation",
    realm: "business",
    firewall: "BUSINESS",
    trinityScene: "neuralis-control-room",
    template: "GameFrame_v1",
    agents: ["REGULATORY_SWARM", "COMPLIANCE_ENGINE"],
  },
  {
    slug: "brics-dispatch",
    title: "BRICS Belt Road Dispatch",
    description: "Global supply chain simulation",
    realm: "business",
    firewall: "BUSINESS",
    trinityScene: "neuralis-control-room",
    template: "GameFrame_v1",
    agents: ["ISO_SUPPLY_SWARM", "XLM_TRACKER"],
  },
  {
    slug: "hrm-arena",
    title: "HRM Training Arena",
    description: "HR scenarios and conflict resolution",
    realm: "business",
    firewall: "EDUCATION",
    trinityScene: "neuralis-hub",
    template: "GameFrame_v1",
    agents: ["HRM_ENGINE", "EMOTIONAL_IQ"],
  },

  // ═══════════════════════════════════════════════════════════════════════════
  // EDUCATION / NPC LABYRINTH
  // ═══════════════════════════════════════════════════════════════════════════
  {
    slug: "npc-labyrinth",
    title: "NPC World-Building Labyrinth",
    description: "Build worlds through learning steps",
    realm: "business",
    firewall: "EDUCATION",
    trinityScene: "neuralis-classroom",
    template: "GameFrame_v1",
    agents: ["NPC_ENGINE", "LORE_BUILDER"],
  },
  {
    slug: "wcu-arcade",
    title: "WIRED CHAOS University Arcade",
    description: "AI literacy and Web3 training modules",
    realm: "underground",
    firewall: "EDUCATION",
    trinityScene: "chaosphere-arcade",
    template: "GameFrame_v1",
    agents: ["WCU_ENGINE", "CRYPTO_LITERACY"],
  },

  // ═══════════════════════════════════════════════════════════════════════════
  // AKASHIC / ARG
  // ═══════════════════════════════════════════════════════════════════════════
  {
    slug: "vault33-codex",
    title: "Vault 33 Codex Excavation",
    description: "Akashic lore exploration",
    realm: "akashic",
    firewall: "AKASHIC",
    trinityScene: "echo-vault33",
    template: "GameFrame_v1",
    agents: ["AKASHIC_SWARM", "589_ENGINE"],
  },
  {
    slug: "vrg33589",
    title: "VRG33589 Chamber",
    description: "Deep lore and timeline puzzles",
    realm: "akashic",
    firewall: "AKASHIC",
    trinityScene: "echo-589",
    template: "GameFrame_v1",
    agents: ["589_ENGINE", "WRAITH_LORDS"],
  },
  {
    slug: "echo-observation",
    title: "Echo Observation Deck",
    description: "Whale events and reality viewing",
    realm: "akashic",
    firewall: "AKASHIC",
    trinityScene: "echo-observation",
    template: "GameFrame_v1",
    agents: ["ECHO_SWARM", "NETERU_ENGINE"],
  },

  // ═══════════════════════════════════════════════════════════════════════════
  // NSFW (Firewalled)
  // ═══════════════════════════════════════════════════════════════════════════
  {
    slug: "789-afterhours",
    title: "789 Afterhours",
    description: "18+ light content channel",
    realm: "underground",
    firewall: "NSFW_LIGHT",
    trinityScene: "chaosphere-afterhours",
    template: "GameFrame_v1",
    agents: ["NSFW_LIGHT_ENGINE", "CONSENT_GUARD"],
  },
]

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────────────────────
export function getGameConfig(slug: string): GameConfig | undefined {
  return GAMES.find((g) => g.slug === slug)
}

export function getGamesByRealm(realm: RealmMode): GameConfig[] {
  return GAMES.filter((g) => g.realm === realm)
}

export function getGamesByFirewall(firewall: FirewallMode): GameConfig[] {
  return GAMES.filter((g) => g.firewall === firewall)
}
