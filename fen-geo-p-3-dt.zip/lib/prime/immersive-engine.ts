/**
 * WIRED CHAOS META — Immersive Engine
 * Implements the 5-layer immersive output contract from PRIME DIRECTIVE v1.1
 */

import type {
  ImmersiveOutput,
  Realm,
  ExperienceMode,
  DecisionOption,
  PrimeDirectiveSession,
  ControlCommand,
  AgentContext,
} from "./types"
import { REALM_TO_HEMISPHERE, getAgentForContext } from "./agent-registry"

// ─────────────────────────────────────────────────────────────────────────────
// SESSION FACTORY
// ─────────────────────────────────────────────────────────────────────────────

export function createPrimeSession(
  realm: Realm,
  mode: ExperienceMode = "OVERWORLD",
  nsfwAllowed = false,
): PrimeDirectiveSession {
  return {
    id: `pd-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
    version: "1.1",
    realm,
    mode,
    hemisphere: REALM_TO_HEMISPHERE[realm],
    nsfwAllowed,
    activeAgent: null,
    history: [],
    createdAt: Date.now(),
    updatedAt: Date.now(),
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// IMMERSIVE OUTPUT BUILDER
// ─────────────────────────────────────────────────────────────────────────────

export interface ImmersiveOutputBuilder {
  realm: Realm
  mode: ExperienceMode
  build(): ImmersiveOutput
  setEnvironment(description: string, opts?: { atmosphere?: string; lighting?: string; soundscape?: string }): this
  setKinetic(description: string, opts?: { motion?: string; sensation?: string; forces?: string }): this
  setNarrative(whatIsHappening: string, why?: string): this
  addDecisionOption(option: DecisionOption): this
  setDecisionStakes(stakes: string): this
  setSignal(description: string, opts?: { symbolism?: string[]; patterns?: string[]; metaThread?: string }): this
}

export function createImmersiveOutput(realm: Realm, mode: ExperienceMode): ImmersiveOutputBuilder {
  const output: ImmersiveOutput = {
    realm,
    mode,
    environment: { description: "" },
    kinetic: { description: "" },
    narrative: { description: "", whatIsHappening: "" },
    decision: { options: [] },
    signal: { description: "" },
  }

  const builder: ImmersiveOutputBuilder = {
    realm,
    mode,

    build() {
      // Validate required layers
      if (!output.environment.description) {
        throw new Error("Environment layer is required")
      }
      if (!output.narrative.whatIsHappening) {
        throw new Error("Narrative layer is required")
      }
      return { ...output }
    },

    setEnvironment(description, opts) {
      output.environment = { description, ...opts }
      return this
    },

    setKinetic(description, opts) {
      output.kinetic = { description, ...opts }
      return this
    },

    setNarrative(whatIsHappening, why) {
      output.narrative = {
        description: whatIsHappening,
        whatIsHappening,
        why,
      }
      return this
    },

    addDecisionOption(option) {
      output.decision.options.push(option)
      return this
    },

    setDecisionStakes(stakes) {
      output.decision.stakes = stakes
      return this
    },

    setSignal(description, opts) {
      output.signal = { description, ...opts }
      return this
    },
  }

  return builder
}

// ─────────────────────────────────────────────────────────────────────────────
// CONTROL PHRASE PARSER
// ─────────────────────────────────────────────────────────────────────────────

export function parseControlPhrase(input: string): ControlCommand | null {
  const normalized = input.trim().toUpperCase()

  if (normalized.includes("ENTER IMMERSION")) {
    return { phrase: "ENTER IMMERSION" }
  }

  if (normalized.includes("PM LEAD MODE")) {
    return { phrase: "PM LEAD MODE" }
  }

  // Realm switching
  const realmMatches = normalized.match(/(?:SWITCH TO|ENTER|GO TO)\s*(BUSINESS|AKASHIC|UNDERGROUND)/i)
  if (realmMatches) {
    return {
      phrase: "SWITCH_REALM",
      targetRealm: realmMatches[1].toUpperCase() as Realm,
    }
  }

  return null
}

// ─────────────────────────────────────────────────────────────────────────────
// SESSION STATE TRANSITIONS
// ─────────────────────────────────────────────────────────────────────────────

export function switchRealm(session: PrimeDirectiveSession, targetRealm: Realm): PrimeDirectiveSession {
  return {
    ...session,
    realm: targetRealm,
    hemisphere: REALM_TO_HEMISPHERE[targetRealm],
    mode: "OVERWORLD", // Reset to overworld on realm switch
    updatedAt: Date.now(),
  }
}

export function switchMode(session: PrimeDirectiveSession, targetMode: ExperienceMode): PrimeDirectiveSession {
  // Validate NSFW mode
  if (targetMode === "NSFW" && !session.nsfwAllowed) {
    throw new Error("NSFW mode not allowed in current session")
  }

  // NSFW only valid in UNDERGROUND
  if (targetMode === "NSFW" && session.realm !== "UNDERGROUND") {
    throw new Error("NSFW mode only available in UNDERGROUND realm")
  }

  return {
    ...session,
    mode: targetMode,
    updatedAt: Date.now(),
  }
}

export function addOutputToHistory(session: PrimeDirectiveSession, output: ImmersiveOutput): PrimeDirectiveSession {
  return {
    ...session,
    history: [...session.history, output],
    updatedAt: Date.now(),
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// CONTEXT BUILDER
// ─────────────────────────────────────────────────────────────────────────────

export function buildAgentContext(session: PrimeDirectiveSession): AgentContext {
  const firewalls: ("BUSINESS" | "AKASHIC" | "NSFW" | "SYSTEM")[] = []

  switch (session.realm) {
    case "BUSINESS":
      firewalls.push("BUSINESS")
      break
    case "AKASHIC":
      firewalls.push("AKASHIC")
      break
    case "UNDERGROUND":
      firewalls.push("SYSTEM")
      if (session.nsfwAllowed) {
        firewalls.push("NSFW")
      }
      break
  }

  return {
    realm: session.realm,
    mode: session.mode,
    nsfwAllowed: session.nsfwAllowed,
    activeFirewalls: firewalls,
    hemisphere: session.hemisphere,
    sessionId: session.id,
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// EXPORTS
// ─────────────────────────────────────────────────────────────────────────────

export { getAgentForContext }
