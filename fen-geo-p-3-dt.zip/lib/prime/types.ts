/**
 * WIRED CHAOS META — PRIME DIRECTIVE v1.1
 * TypeScript Contracts for Immersive Engine
 *
 * This file implements the behavioral specification from /prime/PD-Developer.md
 */

// ─────────────────────────────────────────────────────────────────────────────
// REALM AND FIREWALL TYPES
// ─────────────────────────────────────────────────────────────────────────────

export type Realm = "BUSINESS" | "AKASHIC" | "UNDERGROUND"

export type TrinityHemisphere = "NEURALIS" | "ECHO" | "CHAOSPHERE"

export type FirewallType = "BUSINESS" | "AKASHIC" | "NSFW" | "SYSTEM"

// ─────────────────────────────────────────────────────────────────────────────
// EXPERIENCE MODES
// ─────────────────────────────────────────────────────────────────────────────

export type ExperienceMode =
  | "OVERWORLD" // walking/navigation scenes
  | "SCENARIO" // GameFrame-style scene → choices → consequences
  | "NPC" // focused dialogue with a specific personality
  | "SIMULATION" // system behavior (DCA, dispatch, regulation, credit)
  | "STORY" // cinematic narrative, drama, and character arcs
  | "UNDERGROUND" // Neuro Node, 33.3 FM, club/arcade
  | "NSFW" // only when explicitly requested

// ─────────────────────────────────────────────────────────────────────────────
// IMMERSIVE OUTPUT CONTRACT (5 LAYERS)
// ─────────────────────────────────────────────────────────────────────────────

export interface EnvironmentLayer {
  description: string
  atmosphere?: string
  lighting?: string
  soundscape?: string
  layout?: string
}

export interface KineticLayer {
  description: string
  motion?: string
  sensation?: string
  forces?: string
}

export interface NarrativeLayer {
  description: string
  whatIsHappening: string
  why?: string
}

export interface DecisionOption {
  id: string
  label: string
  hint?: string
  variant?: "default" | "destructive" | "secondary" | "outline"
  disabled?: boolean
}

export interface DecisionLayer {
  options: DecisionOption[]
  timeConstraint?: string
  stakes?: string
}

export interface SignalLayer {
  description: string
  symbolism?: string[]
  patterns?: string[]
  metaThread?: string
}

export interface ImmersiveOutput {
  realm: Realm
  mode: ExperienceMode
  environment: EnvironmentLayer
  kinetic: KineticLayer
  narrative: NarrativeLayer
  decision: DecisionLayer
  signal: SignalLayer
}

// ─────────────────────────────────────────────────────────────────────────────
// AGENT CONTEXT (for routing)
// ─────────────────────────────────────────────────────────────────────────────

export interface AgentContext {
  realm: Realm
  mode: ExperienceMode
  nsfwAllowed: boolean
  activeFirewalls: FirewallType[]
  hemisphere: TrinityHemisphere
  sessionId?: string
}

// ─────────────────────────────────────────────────────────────────────────────
// AGENT IDENTIFIERS
// ─────────────────────────────────────────────────────────────────────────────

export type AgentId =
  | "BUSINESS_SWARM_GENERAL"
  | "AKASHIC_ORACLE"
  | "UNDERGROUND_HOST"
  | "NPC_LABYRINTH_GM"
  | "TRINITY_ARCADE_NAVIGATOR"
  | "DISPATCH_GENERAL"
  | "NSFW_EMISSARY"
  | "REGULATORY_SWARM"
  | "VAULT_GENERAL"
  | "NARRATIVE_DIRECTOR"
  | "PANTHEON_ARBITER"

// ─────────────────────────────────────────────────────────────────────────────
// AGENT RULESET
// ─────────────────────────────────────────────────────────────────────────────

export interface AgentRuleset {
  id: AgentId
  name: string
  realm: Realm | "ANY"
  hemisphere: TrinityHemisphere | "ANY"
  firewalls: FirewallType[]
  tone: string[]
  focus: string[]
  constraints: string[]
}

// ─────────────────────────────────────────────────────────────────────────────
// CONTROL PHRASES
// ─────────────────────────────────────────────────────────────────────────────

export type ControlPhrase = "ENTER IMMERSION" | "PM LEAD MODE" | "SWITCH_REALM"

export interface ControlCommand {
  phrase: ControlPhrase
  targetRealm?: Realm
  targetMode?: ExperienceMode
}

// ─────────────────────────────────────────────────────────────────────────────
// SESSION STATE
// ─────────────────────────────────────────────────────────────────────────────

export interface PrimeDirectiveSession {
  id: string
  version: "1.1" | "2.0"
  realm: Realm
  mode: ExperienceMode
  hemisphere: TrinityHemisphere
  nsfwAllowed: boolean
  activeAgent: AgentId | null
  history: ImmersiveOutput[]
  createdAt: number
  updatedAt: number
}

// ─────────────────────────────────────────────────────────────────────────────
// v2.0 EXTENSIONS (DRAFT)
// ─────────────────────────────────────────────────────────────────────────────

export type CameraMode = "FIRST_PERSON" | "THIRD_CLOSE" | "THIRD_WIDE" | "OVERHEAD" | "OVER_SHOULDER"

export type EmotionalTone = "CALM" | "TENSE" | "EUPHORIC" | "SOMBER" | "NEUTRAL"

export interface ImmersiveOutputV2 extends ImmersiveOutput {
  cameraMode?: CameraMode
  emotionalTone?: EmotionalTone
  pacing?: {
    beatsPerScene: number
    cadence: "PUNCHY" | "CONTEMPLATIVE" | "BALANCED"
  }
  temporalLayer?: {
    pastEchoes?: string[]
    presentState: string
    potentialFutures?: string[]
  }
}
