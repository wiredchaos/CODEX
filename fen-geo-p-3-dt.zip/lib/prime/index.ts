/**
 * WIRED CHAOS META — PRIME DIRECTIVE v1.1
 * Main Export
 */

// Types
export type {
  Realm,
  TrinityHemisphere,
  FirewallType,
  ExperienceMode,
  EnvironmentLayer,
  KineticLayer,
  NarrativeLayer,
  DecisionOption,
  DecisionLayer,
  SignalLayer,
  ImmersiveOutput,
  AgentContext,
  AgentId,
  AgentRuleset,
  ControlPhrase,
  ControlCommand,
  PrimeDirectiveSession,
  CameraMode,
  EmotionalTone,
  ImmersiveOutputV2,
} from "./types"

// Agent Registry
export {
  AGENT_RULESETS,
  REALM_TO_HEMISPHERE,
  getAgentForContext,
  getAgentById,
  getAgentsForRealm,
} from "./agent-registry"

// Immersive Engine
export {
  createPrimeSession,
  createImmersiveOutput,
  parseControlPhrase,
  switchRealm,
  switchMode,
  addOutputToHistory,
  buildAgentContext,
} from "./immersive-engine"
