# WIRED CHAOS RENDER PROMPT QUICK CARD v1.0

**Fast reference for manual rendering. Copy → Paste → Render.**

---

## 🎨 Brand Palette

| Token | Hex | Use |
|-------|-----|-----|
| WIRED Black | `#0D0D0D` | Base/Background |
| Chaos Red | `#FF1A1A` | Accent/Action |
| Neon Cyan | `#00FFF7` | Primary/Glow |
| Signal White | `#FFFFFF` | Text/Labels |
| Glitch Purple | `#A020F0` | Optional FX |

---

## ⚡ Quick Prompts

### Cover Notes
```
Motherboard #0D0D0D + cyan circuits #00FFF7 + red paw #FF1A1A
```

### Funnel Overview
```
Subway map #0D0D0D + cyan lines #00FFF7 + red nodes #FF1A1A
```

### Freebie Entry
```
CRT monitor #0D0D0D + cyan screen #00FFF7 + red paw glow #FF1A1A
```

### eBook
```
Floating book + cyan edges #00FFF7 + red bookmark #FF1A1A
```

### Journal + Toolkit
```
Notebook #0D0D0D + cyan circuits #00FFF7 + red pen #FF1A1A
```

### Builder's Kit
```
Workstation #0D0D0D + cyan monitors #00FFF7 + red UI #FF1A1A
```

### Entity Pack
```
Circuit tree + cyan trunk #00FFF7 + red nodes #FF1A1A
```

### Visual Options
```
Split screen + 2D white #FFFFFF + 3D deck cyan/red
```

### Rush Mode
```
Cyber clock #0D0D0D + red hands #FF1A1A + cyan circuits #00FFF7
```

### Confirmation & Tracking
```
Progress bar #0D0D0D + cyan nodes #00FFF7 + red active #FF1A1A
```

### Delivery
```
Download box #0D0D0D + cyan arrows #00FFF7 + red paw #FF1A1A
```

---

## 📋 Usage Notes

- All prompts default to **3D Octane render** style
- Add `cinematic lighting` for dramatic effect
- Add `glitch grain` for cyberpunk texture
- Optional purple (`#A020F0`) for edge glow / rim light / haze
- Base formula: **Dark base + Cyan primary + Red accent + White text**

---

**Integrated with:** Trinity 3D Engine, Creator Codex, WCU, CHAOS OS  
**Firewall:** BUSINESS | **Hemisphere:** NEURALIS  
**Version:** 1.0 | **Status:** CANON
