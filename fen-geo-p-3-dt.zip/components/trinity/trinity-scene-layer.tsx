/**
 * WIRED CHAOS META - Trinity Scene Layer
 * Renders 3D/video backgrounds based on scene registry
 */

"use client"

import { useMemo } from "react"
import { TRINITY_SCENES, type TrinitySceneId, type RealmMode } from "@/lib/trinity/scene-registry"
import { cn } from "@/lib/utils"

interface TrinitySceneLayerProps {
  sceneId: TrinitySceneId
  realm: RealmMode
  className?: string
}

// ─────────────────────────────────────────────────────────────────────────────
// CSS-BASED ANIMATED BACKGROUNDS
// These provide immersive environments without external dependencies
// ─────────────────────────────────────────────────────────────────────────────
function CSSBackground({ sceneId, realm }: { sceneId: TrinitySceneId; realm: RealmMode }) {
  const scene = TRINITY_SCENES.find((s) => s.id === sceneId)
  const realmStyles = useMemo(() => {
    if (!scene) return null

    switch (realm) {
      case "business":
        // Neuralis: Deep blue-grey, cyan pulses, soft violet accents
        return {
          background: `
            radial-gradient(ellipse at 20% 80%, ${scene.theme.primary}15 0%, transparent 50%),
            radial-gradient(ellipse at 80% 20%, ${scene.theme.accent}10 0%, transparent 40%),
            radial-gradient(ellipse at 50% 50%, ${scene.theme.muted}08 0%, transparent 60%),
            linear-gradient(180deg, ${scene.theme.background} 0%, oklch(0.08 0.02 240) 100%)
          `,
          gridOpacity: 0.08,
          particleColor: scene.theme.primary,
        }
      case "underground":
        // Chaosphere: Near black, ruby/fuchsia pulses, intense energy
        return {
          background: `
            radial-gradient(ellipse at 30% 70%, ${scene.theme.primary}20 0%, transparent 45%),
            radial-gradient(ellipse at 70% 30%, ${scene.theme.accent}18 0%, transparent 40%),
            radial-gradient(circle at 50% 100%, ${scene.theme.primary}25 0%, transparent 35%),
            linear-gradient(180deg, ${scene.theme.background} 0%, oklch(0.02 0.02 350) 100%)
          `,
          gridOpacity: 0.12,
          particleColor: scene.theme.accent,
        }
      case "akashic":
        // Echo: Void black, glowing violet/magenta, ethereal
        return {
          background: `
            radial-gradient(ellipse at 50% 0%, ${scene.theme.accent}12 0%, transparent 50%),
            radial-gradient(ellipse at 20% 60%, ${scene.theme.primary}10 0%, transparent 40%),
            radial-gradient(ellipse at 80% 80%, ${scene.theme.accent}08 0%, transparent 35%),
            linear-gradient(180deg, oklch(0.01 0.01 280) 0%, ${scene.theme.background} 100%)
          `,
          gridOpacity: 0.05,
          particleColor: scene.theme.accent,
        }
      default:
        return null
    }
  }, [realm, sceneId])

  if (!realmStyles) return null

  return (
    <div className="absolute inset-0 overflow-hidden">
      {/* Base gradient layer */}
      <div className="absolute inset-0" style={{ background: realmStyles.background }} />

      {/* Animated grid overlay */}
      <div
        className="absolute inset-0 trinity-grid"
        style={{
          opacity: realmStyles.gridOpacity,
          backgroundImage: `
            linear-gradient(${scene?.theme.primary}30 1px, transparent 1px),
            linear-gradient(90deg, ${scene?.theme.primary}30 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Floating particles */}
      <div className="absolute inset-0 pointer-events-none">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="trinity-particle absolute rounded-full"
            style={{
              width: `${Math.random() * 4 + 2}px`,
              height: `${Math.random() * 4 + 2}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              backgroundColor: realmStyles.particleColor,
              opacity: Math.random() * 0.5 + 0.2,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${Math.random() * 10 + 10}s`,
            }}
          />
        ))}
      </div>

      {/* Realm-specific ambient effects */}
      {realm === "underground" && (
        <div
          className="absolute inset-0 trinity-pulse"
          style={{
            background: `radial-gradient(circle at 50% 80%, ${scene?.theme.primary}10 0%, transparent 50%)`,
          }}
        />
      )}
      {realm === "akashic" && (
        <div
          className="absolute inset-0 trinity-glow"
          style={{
            background: `radial-gradient(ellipse at 50% 20%, ${scene?.theme.accent}08 0%, transparent 60%)`,
          }}
        />
      )}

      {/* Scanline effect for underground */}
      {realm === "underground" && (
        <div className="absolute inset-0 trinity-scanlines opacity-[0.03] pointer-events-none" />
      )}
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN COMPONENT
// ─────────────────────────────────────────────────────────────────────────────
export function TrinitySceneLayer({ sceneId, realm, className }: TrinitySceneLayerProps) {
  const scene = TRINITY_SCENES.find((s) => s.id === sceneId)

  if (!scene) {
    console.warn(`[v0] Trinity scene not found: ${sceneId}`)
    return <div className={cn("absolute inset-0 bg-background", className)} />
  }

  switch (scene.kind) {
    case "video":
      return (
        <div className={cn("absolute inset-0", className)}>
          <video className="h-full w-full object-cover" autoPlay loop muted playsInline src={scene.src} />
          {/* Overlay for readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-black/60" />
        </div>
      )

    case "spline":
    case "tripod3d":
      return (
        <div className={cn("absolute inset-0", className)}>
          <iframe
            src={scene.src}
            className="h-full w-full border-0"
            allow="fullscreen; xr-spatial-tracking; gyroscope; accelerometer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent pointer-events-none" />
        </div>
      )

    case "css":
    default:
      return (
        <div className={cn("absolute inset-0", className)}>
          <CSSBackground sceneId={sceneId} realm={realm} />
        </div>
      )
  }
}
