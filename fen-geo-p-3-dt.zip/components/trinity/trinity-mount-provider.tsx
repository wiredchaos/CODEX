/**
 * WIRED CHAOS META - Trinity Mount Provider
 *
 * Context provider for Trinity Floor/Timeline consumer bindings
 *
 * DECLARATIVE: This provider establishes read-only connections
 * to existing Trinity infrastructure. No 3D generation occurs.
 */

"use client"

import type React from "react"

import { createContext, useContext, useMemo, type ReactNode } from "react"
import { useTrinityMount, type UseTrinityMountOptions } from "@/hooks/use-trinity-mount"
import type { TrinityMountHandle, MountStatus } from "@/lib/trinity/mount-system"
import type { TrinityScene } from "@/lib/trinity/scene-registry"

interface TrinityMountContextValue {
  handle: TrinityMountHandle | null
  status: MountStatus
  scene: TrinityScene | null
  theme: TrinityScene["theme"] | null
  isMounted: boolean
  mount: () => void
  unmount: () => void
}

const TrinityMountContext = createContext<TrinityMountContextValue | null>(null)

interface TrinityMountProviderProps extends UseTrinityMountOptions {
  children: ReactNode
}

export function TrinityMountProvider({ children, ...mountOptions }: TrinityMountProviderProps) {
  const mountState = useTrinityMount(mountOptions)

  const value = useMemo(
    () => mountState,
    [mountState], // Updated to include the entire mountState object
  )

  return <TrinityMountContext.Provider value={value}>{children}</TrinityMountContext.Provider>
}

/**
 * Hook to access Trinity mount context
 * Must be used within TrinityMountProvider
 */
export function useTrinityMountContext(): TrinityMountContextValue {
  const context = useContext(TrinityMountContext)

  if (!context) {
    throw new Error("useTrinityMountContext must be used within a TrinityMountProvider")
  }

  return context
}

/**
 * HOC to wrap components with Trinity mount
 */
export function withTrinityMount<P extends object>(
  Component: React.ComponentType<P>,
  mountOptions: UseTrinityMountOptions,
) {
  return function WrappedComponent(props: P) {
    return (
      <TrinityMountProvider {...mountOptions}>
        <Component {...props} />
      </TrinityMountProvider>
    )
  }
}
