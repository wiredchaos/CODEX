/**
 * WIRED CHAOS META - GameFrame Module Exports
 * Registry: UI.PRIMITIVE.GAMEFRAME_V1
 */

export { GameFrameV1, default } from "./game-frame-v1"
export * from "@/lib/types/game-session"
