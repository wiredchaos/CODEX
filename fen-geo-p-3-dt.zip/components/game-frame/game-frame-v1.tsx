/**
 * WIRED CHAOS META - GameFrame_v1 Canonical Component
 * Registry: UI.PRIMITIVE.GAMEFRAME_V1
 *
 * A reusable layout for "Read scenario → Make choice → See outcomes/logs"
 * Used across: Arcade, NPC, WCU, Business Sims, ARG, NSFW channels
 */

"use client"

import type React from "react"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Progress } from "@/components/ui/progress"
import {
  Crown,
  Swords,
  Shield,
  Users,
  Zap,
  AlertTriangle,
  CheckCircle,
  Clock,
  TrendingUp,
  Wallet,
  ScrollText,
} from "lucide-react"
import type { GameSession, GameChoice, GameLogEntry, GameVariable, GameFrameTheme } from "@/lib/types/game-session"
import { cn } from "@/lib/utils"

// ─────────────────────────────────────────────────────────────────────────────
// PROPS INTERFACE
// ─────────────────────────────────────────────────────────────────────────────
interface GameFrameV1Props {
  session: GameSession
  theme?: Partial<GameFrameTheme>
  onChoiceSelect: (choiceId: string) => void
  onBack?: () => void
  isLoading?: boolean
  className?: string
}

// ─────────────────────────────────────────────────────────────────────────────
// LOG TYPE ICONS
// ─────────────────────────────────────────────────────────────────────────────
const LOG_ICONS: Record<GameLogEntry["type"], React.ReactNode> = {
  SYSTEM: <ScrollText className="w-4 h-4 text-muted-foreground" />,
  CHOICE: <CheckCircle className="w-4 h-4 text-primary" />,
  OUTCOME: <Zap className="w-4 h-4 text-chart-1" />,
  XP_GAIN: <TrendingUp className="w-4 h-4 text-green-500" />,
  LEVEL_UP: <Crown className="w-4 h-4 text-yellow-500" />,
  ALLIANCE: <Users className="w-4 h-4 text-blue-500" />,
  ATTACK: <Swords className="w-4 h-4 text-red-500" />,
  DEFENSE: <Shield className="w-4 h-4 text-orange-500" />,
  CLAIM: <CheckCircle className="w-4 h-4 text-green-500" />,
  TRANSACTION: <Wallet className="w-4 h-4 text-cyan-500" />,
  REGULATORY: <AlertTriangle className="w-4 h-4 text-yellow-500" />,
  LORE: <ScrollText className="w-4 h-4 text-purple-500" />,
  WARNING: <AlertTriangle className="w-4 h-4 text-destructive" />,
  NSFW_BOUNDARY: <Shield className="w-4 h-4 text-pink-500" />,
}

// ─────────────────────────────────────────────────────────────────────────────
// VARIABLE RENDERER
// ─────────────────────────────────────────────────────────────────────────────
function VariableDisplay({ variable }: { variable: GameVariable }) {
  switch (variable.type) {
    case "progress":
      return (
        <div className="space-y-1">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">{variable.label}</span>
            <span>
              {variable.value}
              {variable.max ? `/${variable.max}` : ""}
            </span>
          </div>
          <Progress
            value={typeof variable.value === "number" ? (variable.value / (variable.max || 100)) * 100 : 0}
            className="h-2"
          />
        </div>
      )
    case "percentage":
      return (
        <div className="flex justify-between items-center">
          <span className="text-muted-foreground text-sm">{variable.label}</span>
          <Badge variant="secondary">{variable.value}%</Badge>
        </div>
      )
    case "currency":
      return (
        <div className="flex justify-between items-center">
          <span className="text-muted-foreground text-sm">{variable.label}</span>
          <span className="font-mono font-semibold">${Number(variable.value).toLocaleString()}</span>
        </div>
      )
    case "badge":
      return (
        <div className="flex justify-between items-center">
          <span className="text-muted-foreground text-sm">{variable.label}</span>
          <Badge style={{ backgroundColor: variable.color }}>{String(variable.value)}</Badge>
        </div>
      )
    default:
      return (
        <div className="flex justify-between items-center">
          <span className="text-muted-foreground text-sm">{variable.label}</span>
          <span className="font-medium">{String(variable.value)}</span>
        </div>
      )
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN COMPONENT
// ─────────────────────────────────────────────────────────────────────────────
export function GameFrameV1({
  session,
  theme,
  onChoiceSelect,
  onBack,
  isLoading = false,
  className,
}: GameFrameV1Props) {
  const [selectedChoice, setSelectedChoice] = useState<string | null>(null)

  const handleChoiceClick = (choice: GameChoice) => {
    if (choice.disabled || isLoading) return
    setSelectedChoice(choice.id)
    onChoiceSelect(choice.id)
  }

  const showLedgerPanel = theme?.showLedgerPanel !== false && session.ledger
  const showXPBar = theme?.showXPBar !== false

  return (
    <div className={cn("flex flex-col lg:flex-row gap-6 w-full", className)}>
      {/* ─────────────────────────────────────────────────────────────────────── */}
      {/* MAIN PANEL: Scene + Choices */}
      {/* ─────────────────────────────────────────────────────────────────────── */}
      <div className="flex-1 space-y-6">
        {/* XP Bar */}
        {showXPBar && (
          <Card className="p-4 bg-card/50">
            <div className="flex items-center gap-4">
              <Badge variant="outline" className="gap-1">
                <Crown className="w-4 h-4" />
                Level {session.level}
              </Badge>
              <div className="flex-1">
                <Progress value={session.xp % 100} className="h-2" />
              </div>
              <span className="text-sm text-muted-foreground font-mono">{session.xp} XP</span>
            </div>
          </Card>
        )}

        {/* Scene Card */}
        <Card className="overflow-hidden">
          {session.scene.imageUrl && (
            <div className="relative h-48 md:h-64 bg-muted">
              <img
                src={session.scene.imageUrl || "/placeholder.svg"}
                alt={session.scene.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent" />
            </div>
          )}
          <div className="p-6 space-y-4">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h2 className="text-2xl font-bold text-balance">{session.scene.title}</h2>
                {session.scene.tags && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {session.scene.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
              {session.scene.metadata?.riskLevel && (
                <Badge variant={session.scene.metadata.riskLevel === "CRITICAL" ? "destructive" : "outline"}>
                  {session.scene.metadata.riskLevel} Risk
                </Badge>
              )}
            </div>
            <p className="text-muted-foreground leading-relaxed text-pretty">{session.scene.narrative}</p>
            {session.scene.metadata?.jurisdiction && (
              <p className="text-xs text-muted-foreground">Jurisdiction: {session.scene.metadata.jurisdiction}</p>
            )}
          </div>
        </Card>

        {/* Choices */}
        <div className="space-y-3">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Zap className="w-5 h-5 text-primary" />
            Your Options
          </h3>
          <div className="grid gap-3">
            {session.choices.map((choice) => (
              <Button
                key={choice.id}
                variant={choice.variant || "outline"}
                className={cn(
                  "w-full justify-start h-auto py-4 px-5 text-left",
                  selectedChoice === choice.id && "ring-2 ring-primary",
                  choice.disabled && "opacity-50 cursor-not-allowed",
                )}
                onClick={() => handleChoiceClick(choice)}
                disabled={choice.disabled || isLoading}
              >
                <div className="space-y-1">
                  <span className="font-medium">{choice.label}</span>
                  {choice.description && <p className="text-xs text-muted-foreground">{choice.description}</p>}
                  {choice.preview && (
                    <div className="flex gap-2 mt-2">
                      {choice.preview.xpChange && (
                        <Badge variant="secondary" className="text-xs">
                          {choice.preview.xpChange > 0 ? "+" : ""}
                          {choice.preview.xpChange} XP
                        </Badge>
                      )}
                      {choice.preview.outcomeHint && (
                        <span className="text-xs text-muted-foreground italic">{choice.preview.outcomeHint}</span>
                      )}
                    </div>
                  )}
                </div>
              </Button>
            ))}
          </div>
        </div>
      </div>

      {/* ─────────────────────────────────────────────────────────────────────── */}
      {/* SIDE PANEL: Variables + Ledger + Log */}
      {/* ─────────────────────────────────────────────────────────────────────── */}
      <div className="w-full lg:w-80 space-y-4">
        {/* Variables Panel */}
        {Object.keys(session.variables).length > 0 && (
          <Card className="p-4 space-y-3">
            <h4 className="font-semibold text-sm uppercase tracking-wide text-muted-foreground">Status</h4>
            <div className="space-y-3">
              {Object.values(session.variables).map((variable) => (
                <VariableDisplay key={variable.key} variable={variable} />
              ))}
            </div>
          </Card>
        )}

        {/* Ledger Panel */}
        {showLedgerPanel && session.ledger && (
          <Card className="p-4 space-y-3">
            <h4 className="font-semibold text-sm uppercase tracking-wide text-muted-foreground flex items-center gap-2">
              <Wallet className="w-4 h-4" />
              {session.ledger.type} Wallet
            </h4>
            <div className="space-y-2">
              {session.ledger.balance !== undefined && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground text-sm">Balance</span>
                  <span className="font-mono font-semibold">{session.ledger.balance.toLocaleString()}</span>
                </div>
              )}
              {session.ledger.walletAddress && (
                <p className="text-xs text-muted-foreground font-mono truncate">{session.ledger.walletAddress}</p>
              )}
            </div>
          </Card>
        )}

        {/* Event Log */}
        <Card className="p-4">
          <h4 className="font-semibold text-sm uppercase tracking-wide text-muted-foreground mb-3 flex items-center gap-2">
            <Clock className="w-4 h-4" />
            Event Log
          </h4>
          <ScrollArea className="h-64">
            <div className="space-y-2 pr-4">
              {session.logs.slice(0, theme?.logMaxEntries || 20).map((log) => (
                <div
                  key={log.id}
                  className="flex items-start gap-2 text-sm py-2 border-b border-border/50 last:border-0"
                >
                  {LOG_ICONS[log.type]}
                  <div className="flex-1 min-w-0">
                    <p className="text-foreground">{log.message}</p>
                    <p className="text-xs text-muted-foreground">{new Date(log.timestamp).toLocaleTimeString()}</p>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </Card>
      </div>
    </div>
  )
}

export default GameFrameV1
