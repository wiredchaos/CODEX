/**
 * WIRED CHAOS META - Trinity Mount Hook
 *
 * React hook for consumer patches to bind to Trinity Floors
 *
 * DECLARATIVE: This hook consumes existing Trinity infrastructure.
 * It does NOT create new 3D content or galaxies.
 */

"use client"

import { useState, useEffect, useCallback, useMemo } from "react"
import type { TrinitySceneId, RealmMode, TrinityScene } from "@/lib/trinity/scene-registry"
import type { TrinityMountHandle, MountStatus } from "@/lib/trinity/mount-system"
import {
  requestFloorMount,
  mountGameToTrinity,
  mountToDefaultFloor,
  unmountFromTrinity,
  getMountStatus,
  getMountedSceneTheme,
} from "@/lib/trinity/mount-system"

interface UseTrinityMountOptions {
  /** Patch identifier */
  patchId: string
  /** Game slug to auto-mount (optional) */
  gameSlug?: string
  /** Specific floor to mount (optional) */
  floorId?: TrinitySceneId
  /** Realm for default floor mount (optional) */
  realm?: RealmMode
  /** Auto-mount on hook initialization */
  autoMount?: boolean
}

interface UseTrinityMountReturn {
  /** Current mount handle (read-only) */
  handle: TrinityMountHandle | null
  /** Current mount status */
  status: MountStatus
  /** Mounted scene (read-only reference) */
  scene: TrinityScene | null
  /** Scene theme colors */
  theme: TrinityScene["theme"] | null
  /** Is patch currently mounted */
  isMounted: boolean
  /** Mount to Trinity Floor */
  mount: () => void
  /** Unmount from Trinity */
  unmount: () => void
}

export function useTrinityMount(options: UseTrinityMountOptions): UseTrinityMountReturn {
  const { patchId, gameSlug, floorId, realm, autoMount = true } = options

  const [handle, setHandle] = useState<TrinityMountHandle | null>(null)

  // Mount function
  const mount = useCallback(() => {
    let newHandle: TrinityMountHandle

    if (gameSlug) {
      // Mount via game configuration
      newHandle = mountGameToTrinity(gameSlug)
    } else if (floorId && realm) {
      // Mount to specific floor
      newHandle = requestFloorMount(patchId, floorId, realm)
    } else if (realm) {
      // Mount to default floor for realm
      newHandle = mountToDefaultFloor(patchId, realm)
    } else {
      // Cannot mount without configuration
      console.warn(`[useTrinityMount] Cannot mount ${patchId}: missing gameSlug, floorId, or realm`)
      return
    }

    setHandle(newHandle)
  }, [patchId, gameSlug, floorId, realm])

  // Unmount function
  const unmount = useCallback(() => {
    unmountFromTrinity(patchId)
    setHandle(getMountStatus(patchId))
  }, [patchId])

  // Auto-mount on initialization
  useEffect(() => {
    if (autoMount) {
      mount()
    }

    // Cleanup on unmount
    return () => {
      unmountFromTrinity(patchId)
    }
  }, [autoMount, mount, patchId])

  // Derived values
  const status = handle?.status ?? "UNMOUNTED"
  const scene = handle?.scene ?? null
  const theme = useMemo(() => getMountedSceneTheme(patchId), [patchId, handle])
  const isMounted = status === "MOUNTED"

  return {
    handle,
    status,
    scene,
    theme,
    isMounted,
    mount,
    unmount,
  }
}

/**
 * Simple hook to get mount status only (no auto-mount)
 */
export function useTrinityMountStatus(patchId: string): MountStatus {
  const [status, setStatus] = useState<MountStatus>("UNMOUNTED")

  useEffect(() => {
    const handle = getMountStatus(patchId)
    setStatus(handle?.status ?? "UNMOUNTED")
  }, [patchId])

  return status
}
