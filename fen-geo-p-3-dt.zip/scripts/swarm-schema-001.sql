-- WIRED CHAOS META — SWARM ASSET SCHEMA v1
-- Idempotent migration for Swarm Assets and Namespace Management
-- Safe for re-runs; checks existence before creating objects

-- Create swarm_assets table if it doesn't exist
CREATE TABLE IF NOT EXISTS swarm_assets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    namespace TEXT NOT NULL,
    asset_type TEXT NOT NULL,
    asset_key TEXT NOT NULL,
    metadata JSONB DEFAULT '{}'::jsonb,
    ledger TEXT,
    chain_ref TEXT,
    firewall TEXT CHECK (firewall IN ('BUSINESS', 'AKASHIC', 'NSFW', 'SYSTEM')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(namespace, asset_key)
);

-- Create index on namespace with idempotency guard
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_class c
        JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE c.relname = 'idx_swarm_assets_namespace'
          AND n.nspname = 'public'
    ) THEN
        CREATE INDEX idx_swarm_assets_namespace
            ON swarm_assets (namespace);
    END IF;
END$$;

-- Create index on asset_type with idempotency guard
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_class c
        JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE c.relname = 'idx_swarm_assets_type'
          AND n.nspname = 'public'
    ) THEN
        CREATE INDEX idx_swarm_assets_type
            ON swarm_assets (asset_type);
    END IF;
END$$;

-- Create index on firewall with idempotency guard
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_class c
        JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE c.relname = 'idx_swarm_assets_firewall'
          AND n.nspname = 'public'
    ) THEN
        CREATE INDEX idx_swarm_assets_firewall
            ON swarm_assets (firewall);
    END IF;
END$$;

-- Create updated_at trigger function if it doesn't exist
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_trigger
        WHERE tgname = 'update_swarm_assets_updated_at'
    ) THEN
        CREATE TRIGGER update_swarm_assets_updated_at
            BEFORE UPDATE ON swarm_assets
            FOR EACH ROW
            EXECUTE FUNCTION update_updated_at_column();
    END IF;
END$$;

-- Comment on table
COMMENT ON TABLE swarm_assets IS 'WIRED CHAOS META Swarm Asset Registry - stores all agent-managed assets across Business, Akashic, and Underground realms';
