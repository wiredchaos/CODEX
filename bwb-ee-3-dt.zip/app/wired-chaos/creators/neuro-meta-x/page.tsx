"use client"

import Link from "next/link"
import { Eye, Radio, Book, Film, Gamepad2, ExternalLink } from "lucide-react"
import { StudioHeader } from "@/components/studio-header"

export default function NeuroMetaXPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <StudioHeader />

      <main className="pt-24 pb-16">
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4">
            {/* Breadcrumb */}
            <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground mb-8">
              <Link href="/wired-chaos" className="hover:text-primary transition-colors">
                WIRED CHAOS
              </Link>
              <span>/</span>
              <Link href="/wired-chaos/creators" className="hover:text-primary transition-colors">
                CREATORS
              </Link>
              <span>/</span>
              <span className="text-primary">NEURO META X</span>
            </div>

            {/* Profile Header */}
            <div className="relative bg-card border border-border p-8 md:p-12 mb-8">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(245,158,11,0.05)_0%,transparent_50%)]" />

              <div className="relative flex flex-col md:flex-row gap-8 items-start">
                <div className="w-32 h-32 bg-primary/10 border-2 border-primary flex items-center justify-center shrink-0">
                  <Eye className="w-16 h-16 text-primary animate-pulse" />
                </div>

                <div className="flex-1">
                  <div className="flex items-center gap-4 mb-4">
                    <h1 className="text-4xl font-bold text-primary">NEURO META X</h1>
                    <span className="text-xs bg-accent/20 text-accent px-3 py-1 border border-accent/30">
                      VERIFIED ARCHITECT
                    </span>
                  </div>

                  <p className="text-lg text-muted-foreground mb-6 max-w-2xl">
                    Primary Architect of the Neteru Universe. Weaving ancient frequencies into modern transmissions. The
                    Echo begins here.
                  </p>

                  <div className="flex flex-wrap gap-3 mb-6">
                    <span className="text-sm border border-primary/30 px-4 py-2 text-primary">CHAOS PRODUCTIONS</span>
                    <span className="text-sm border border-accent/30 px-4 py-2 text-accent">NETERU STUDIOS</span>
                    <span className="text-sm border border-destructive/30 px-4 py-2 text-destructive">VRG33589</span>
                  </div>

                  <div className="flex gap-4">
                    <Link
                      href="/789ott/creators/neuro-meta-x"
                      className="text-sm text-muted-foreground hover:text-primary transition-colors flex items-center gap-2"
                    >
                      <ExternalLink className="w-4 h-4" />
                      View on 789OTT
                    </Link>
                  </div>
                </div>

                <div className="bg-background border border-border p-6 w-full md:w-auto">
                  <div className="text-xs text-muted-foreground mb-2">PROFILE ID</div>
                  <div className="text-2xl font-mono text-primary mb-4">VRG33589</div>

                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <div className="text-xl font-bold text-primary">5</div>
                      <div className="text-xs text-muted-foreground">TRANSMISSIONS</div>
                    </div>
                    <div>
                      <div className="text-xl font-bold text-accent">33</div>
                      <div className="text-xs text-muted-foreground">ECHO LEVEL</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Works Grid */}
            <div className="grid md:grid-cols-2 gap-6 mb-12">
              <div className="bg-card border border-border p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Book className="w-6 h-6 text-primary" />
                  <h2 className="text-lg font-bold">LITERARY WORKS</h2>
                </div>
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-primary rounded-full" />
                    The Neteru Chronicles
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-primary rounded-full" />
                    Veil of Time
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-primary rounded-full" />
                    Operation Ancestry
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-primary rounded-full" />
                    The Dark Nexus Files
                  </li>
                </ul>
              </div>

              <div className="bg-card border border-border p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Film className="w-6 h-6 text-destructive" />
                  <h2 className="text-lg font-bold">FILM / VIDEO</h2>
                </div>
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-destructive rounded-full" />
                    NTRU-001: The Artifact Pulse
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-destructive rounded-full" />
                    NTRU-002: Nilotic Frequency
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-destructive rounded-full" />
                    NTRU-003: The Dark Nexus
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-destructive rounded-full" />
                    NTRU-004: Veil of Time Collapse
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-destructive rounded-full" />
                    NTRU-005: Operation Ancestry
                  </li>
                </ul>
              </div>

              <div className="bg-card border border-border p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Gamepad2 className="w-6 h-6 text-accent" />
                  <h2 className="text-lg font-bold">INTERACTIVE</h2>
                </div>
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-accent rounded-full" />
                    Echo Engineers Cipher Hunt
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-accent rounded-full" />
                    VRG33589 Whitelist Protocol
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-accent rounded-full" />
                    Neteru Genesis Experience
                  </li>
                </ul>
              </div>

              <div className="bg-card border border-border p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Radio className="w-6 h-6 text-primary" />
                  <h2 className="text-lg font-bold">BROADCAST</h2>
                </div>
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-primary rounded-full" />
                    Barbed Wire Broadcast
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-primary rounded-full" />
                    Signal Intercept Archives
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-primary rounded-full" />
                    Akashic Transmissions
                  </li>
                </ul>
              </div>
            </div>

            {/* CTA Section */}
            <div className="bg-primary/5 border border-primary/30 p-8 text-center">
              <h3 className="text-xl font-bold mb-4">ENTER THE ECHO</h3>
              <p className="text-muted-foreground mb-6 max-w-lg mx-auto">
                Begin your journey through the Neteru Universe. Discover the transmissions. Find the fragments. Earn
                your place among the Echo Engineers.
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Link
                  href="/neteru-studios"
                  className="bg-primary text-background px-6 py-3 font-bold tracking-wide hover:bg-primary/90 transition-colors"
                >
                  VIEW TRANSMISSIONS
                </Link>
                <Link
                  href="/neteru-studios/whitelist"
                  className="border border-primary/50 text-primary px-6 py-3 font-bold tracking-wide hover:bg-primary/10 transition-colors"
                >
                  WHITELIST PORTAL
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="py-8 border-t border-border">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-xs text-muted-foreground font-mono">
            NEURO META X | CHAOS PRODUCTIONS | NETERU STUDIOS | WIRED CHAOS META HUB
          </p>
        </div>
      </footer>
    </div>
  )
}
