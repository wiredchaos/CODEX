"use client"

import Link from "next/link"
import { Zap, Radio, Eye, Cpu, Network, Fingerprint, Lock } from "lucide-react"
import { StudioHeader } from "@/components/studio-header"
import { TrinityStatus } from "@/components/trinity-status"

export default function WiredChaosHub() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <StudioHeader />

      <main className="pt-24 pb-16">
        {/* Hero Section */}
        <section className="relative py-20 overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(245,158,11,0.08)_0%,transparent_70%)]" />
          <div className="absolute inset-0 opacity-10">
            <div
              className="absolute inset-0"
              style={{
                backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M30 0L30 60M0 30L60 30' stroke='%23F59E0B' strokeWidth='0.5' fill='none'/%3E%3C/svg%3E")`,
                backgroundSize: "60px 60px",
              }}
            />
          </div>

          <div className="max-w-7xl mx-auto px-4 text-center relative z-10">
            <div className="inline-flex items-center gap-2 text-xs font-mono text-accent mb-6 border border-accent/30 px-4 py-2">
              <Zap className="w-3 h-3" />
              <span>META HUB ONLINE</span>
            </div>

            <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-6">
              <span className="text-primary">WIRED</span> <span className="text-foreground">CHAOS</span>
            </h1>

            <p className="text-muted-foreground text-lg max-w-2xl mx-auto mb-8">
              The orchestration layer connecting all nodes of the Neteru Universe. Where creators converge, signals
              transmit, and the Echo never fades.
            </p>

            <div className="flex flex-wrap justify-center gap-4">
              <Link
                href="/wired-chaos/creators"
                className="bg-primary text-background px-6 py-3 font-bold tracking-wide hover:bg-primary/90 transition-colors"
              >
                EXPLORE CREATORS
              </Link>
              <Link
                href="/neteru-studios"
                className="border border-primary/50 text-primary px-6 py-3 font-bold tracking-wide hover:bg-primary/10 transition-colors"
              >
                ECHO ENGINEERS
              </Link>
            </div>
          </div>
        </section>

        {/* Trinity Mount Status */}
        <section className="py-8 border-y border-border bg-background/50">
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex items-center gap-2 mb-4">
              <Lock className="w-4 h-4 text-primary" />
              <span className="text-sm font-bold tracking-wide">TRINITY 3D CORE</span>
              <span className="text-xs text-muted-foreground ml-2">READ-ONLY INFRASTRUCTURE</span>
            </div>
            <TrinityStatus />
          </div>
        </section>

        {/* Stats Grid */}
        <section className="py-16 border-b border-border">
          <div className="max-w-7xl mx-auto px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {[
                { label: "ACTIVE NODES", value: "33", icon: Network },
                { label: "CREATORS", value: "7", icon: Fingerprint },
                { label: "TRANSMISSIONS", value: "589", icon: Radio },
                { label: "SIGNAL STRENGTH", value: "99.9%", icon: Zap },
              ].map((stat) => (
                <div key={stat.label} className="text-center">
                  <stat.icon className="w-6 h-6 text-primary mx-auto mb-2" />
                  <div className="text-3xl font-bold text-primary mb-1">{stat.value}</div>
                  <div className="text-xs text-muted-foreground tracking-widest">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Featured Creator */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-2xl font-bold tracking-wide mb-2">FEATURED ARCHITECT</h2>
              <div className="w-16 h-px bg-primary mx-auto" />
            </div>

            <Link href="/wired-chaos/creators/neuro-meta-x" className="block group">
              <div className="relative bg-card border border-border p-8 md:p-12 hover:border-primary/50 transition-colors">
                <div className="absolute top-4 right-4 flex items-center gap-2 text-xs font-mono">
                  <span className="w-2 h-2 bg-accent rounded-full animate-pulse" />
                  <span className="text-accent">VERIFIED</span>
                </div>

                <div className="flex flex-col md:flex-row gap-8 items-center">
                  <div className="w-32 h-32 bg-primary/10 border border-primary/30 flex items-center justify-center">
                    <Eye className="w-16 h-16 text-primary" />
                  </div>

                  <div className="flex-1 text-center md:text-left">
                    <h3 className="text-3xl font-bold text-primary mb-2 group-hover:animate-pulse">NEURO META X</h3>
                    <p className="text-muted-foreground mb-4">
                      Primary Architect of the Neteru Universe. Author, Artist, Echo Engineer.
                    </p>
                    <div className="flex flex-wrap gap-2 justify-center md:justify-start">
                      <span className="text-xs border border-primary/30 px-3 py-1 text-primary">CHAOS PRODUCTIONS</span>
                      <span className="text-xs border border-accent/30 px-3 py-1 text-accent">ECHO ENGINEERS</span>
                      <span className="text-xs border border-destructive/30 px-3 py-1 text-destructive">VRG33589</span>
                    </div>
                  </div>

                  <div className="text-right hidden md:block">
                    <div className="text-xs text-muted-foreground mb-1">PROFILE ID</div>
                    <div className="text-xl font-mono text-primary">VRG33589</div>
                  </div>
                </div>
              </div>
            </Link>
          </div>
        </section>

        {/* Network Nodes */}
        <section className="py-16 bg-card/50 border-y border-border">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-xl font-bold tracking-wide mb-8 text-center">CONNECTED NODES</h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Link
                href="/neteru-studios"
                className="group p-6 border border-border hover:border-primary/50 transition-colors bg-background"
              >
                <Cpu className="w-8 h-8 text-primary mb-4" />
                <h3 className="font-bold text-lg mb-2 group-hover:text-primary transition-colors">ECHO ENGINEERS</h3>
                <p className="text-sm text-muted-foreground">Film, game, and cinematic production engine</p>
              </Link>

              <Link
                href="/789ott"
                className="group p-6 border border-border hover:border-primary/50 transition-colors bg-background"
              >
                <Radio className="w-8 h-8 text-destructive mb-4" />
                <h3 className="font-bold text-lg mb-2 group-hover:text-primary transition-colors">789OTT</h3>
                <p className="text-sm text-muted-foreground">Streaming distribution and broadcast network</p>
              </Link>

              <Link
                href="/neteru-studios/barbed-wire-broadcast"
                className="group p-6 border border-border hover:border-primary/50 transition-colors bg-background"
              >
                <Zap className="w-8 h-8 text-accent mb-4" />
                <h3 className="font-bold text-lg mb-2 group-hover:text-primary transition-colors">
                  BARBED WIRE BROADCAST
                </h3>
                <p className="text-sm text-muted-foreground">Underground news and signal transmission</p>
              </Link>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="py-8 border-t border-border">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-xs text-muted-foreground font-mono">
            WIRED CHAOS META HUB | NEURO META X | CHAOS PRODUCTIONS
          </p>
          <p className="text-xs text-muted-foreground/50 font-mono mt-2">
            TRINITY FLOOR 33 | AKIRA CODEX GOVERNED | CONSUMER MODE
          </p>
        </div>
      </footer>
    </div>
  )
}
