import { StudioHeader } from "@/components/studio-header"
import { ClueTracker } from "@/components/clue-tracker"
import { BarbedWireTicker } from "@/components/barbed-wire-ticker"
import Link from "next/link"
import { Eye, ChevronRight, AlertTriangle, Tv } from "lucide-react"

export default function CluesPage() {
  return (
    <main className="min-h-screen bg-background">
      <StudioHeader />

      {/* Hero Section */}
      <section className="relative pt-24 pb-12 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,_var(--tw-gradient-stops))] from-accent/10 via-background to-background" />

        <div className="relative max-w-4xl mx-auto px-4">
          <div className="flex items-center gap-3 mb-6">
            <Eye className="w-8 h-8 text-accent" />
            <span className="text-xs font-mono text-accent border border-accent/30 px-3 py-1">ARG SYSTEM ACTIVE</span>
          </div>

          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4 tracking-tight">
            CLUE TRACKING DASHBOARD
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl mb-6 leading-relaxed">
            Seven hidden fragments scattered across five transmissions. Each fragment is a piece of the cipher. Track
            your progress. Decode the Echo.
          </p>

          {/* Info Cards */}
          <div className="grid sm:grid-cols-3 gap-4 mt-8">
            <div className="bg-card border border-border p-4">
              <div className="text-3xl font-bold text-primary font-mono mb-1">7</div>
              <div className="text-sm text-muted-foreground">Total Clues</div>
            </div>
            <div className="bg-card border border-border p-4">
              <div className="text-3xl font-bold text-accent font-mono mb-1">5</div>
              <div className="text-sm text-muted-foreground">Video Sources</div>
            </div>
            <div className="bg-card border border-border p-4">
              <div className="text-3xl font-bold text-foreground font-mono mb-1">1</div>
              <div className="text-sm text-muted-foreground">Final Key</div>
            </div>
          </div>
        </div>
      </section>

      <BarbedWireTicker />

      {/* Main Content */}
      <section className="py-12 px-4">
        <div className="max-w-4xl mx-auto">
          {/* Warning Banner */}
          <div className="bg-destructive/10 border border-destructive/30 p-4 mb-8 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="text-foreground font-bold text-sm mb-1">PATH WARNING</h4>
              <p className="text-sm text-muted-foreground">
                Your journey shapes the cipher. Tracking discovered fragments reveals their secrets. For the purest
                experience, watch all transmissions first.
              </p>
            </div>
          </div>

          {/* Clue Tracker Component */}
          <ClueTracker />

          {/* CTAs */}
          <div className="mt-12 flex flex-wrap gap-4 justify-center">
            <Link
              href="/neteru-studios"
              className="flex items-center gap-2 border border-border px-6 py-3 text-foreground font-mono text-sm hover:border-primary/50 transition-all"
            >
              <Tv className="w-4 h-4" />
              WATCH TRANSMISSIONS
            </Link>
            <Link
              href="/neteru-studios/whitelist"
              className="flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 font-mono text-sm hover:bg-primary/90 transition-all"
            >
              SUBMIT WL KEY
              <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-4 mt-12">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-muted-foreground text-sm font-mono">© ECHO ENGINEERS | NTRU</div>
          <div className="text-xs text-muted-foreground font-mono">THE ECHO REMEMBERS THOSE WHO SEEK</div>
        </div>
      </footer>
    </main>
  )
}
