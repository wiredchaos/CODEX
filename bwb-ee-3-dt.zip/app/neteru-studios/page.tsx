import { StudioHeader } from "@/components/studio-header"
import { VideoCard } from "@/components/video-card"
import { GlitchText } from "@/components/glitch-text"
import { BarbedWireTicker } from "@/components/barbed-wire-ticker"
import { EnvironmentRenderer } from "@/components/environment-renderer"
import Link from "next/link"
import { Radio, ChevronRight, Tv, Eye, Lock } from "lucide-react"

const videos = [
  {
    id: 1,
    title: "The Artifact Pulse",
    description:
      "Malachai's descent into the subterranean temple and first clash with shadow agents. The artifact awakens.",
    clueType: "Visible Cipher",
    clueStatus: "not-found" as const,
    thumbnail: "/dark-underground-temple-ancient-artifact-glowing-c.jpg",
    duration: "12:33",
    reference: "Out of Sequence NA",
  },
  {
    id: 2,
    title: "Nilotic Frequency",
    description: "The Marzain-infused Nilotic lineages revealed. Their cosmic inheritance cannot be denied.",
    clueType: "Glitch Frame Glyph",
    clueStatus: "not-found" as const,
    thumbnail: "/ancient-egyptian-nile-cosmic-stars-dna-helix-cyber.jpg",
    duration: "15:47",
    reference: "Nilotic & Marzain Arc",
  },
  {
    id: 3,
    title: "The Dark Nexus",
    description: "DUMBs beneath 33 Thomas Street. Genetic harvesting of Neteru bloodlines exposed.",
    clueType: "Audio Waveform Metadata",
    clueStatus: "not-found" as const,
    thumbnail: "/dark-underground-bunker-surveillance-technology-si.jpg",
    duration: "18:22",
    reference: "Dark Nexus of 33 Thomas Street",
  },
  {
    id: 4,
    title: "Veil of Time Collapse",
    description: "BC/AD fabrication exposed. CERN's mimicry of ancient alchemy. The Marzain temporal sabotage.",
    clueType: "Semi-Hidden Timestamp",
    clueStatus: "not-found" as const,
    thumbnail: "/cern-particle-collider-time-distortion-ancient-sym.jpg",
    duration: "21:09",
    reference: "The Veil of Time",
  },
  {
    id: 5,
    title: "Operation Ancestry",
    description: "Modern DNA surveillance connected to ancient cosmic bloodline hunts. They know who you are.",
    clueType: "Deep-Hidden Geometry Code",
    clueStatus: "not-found" as const,
    thumbnail: "/dna-helix-surveillance-technology-ancient-geometry.jpg",
    duration: "16:55",
    reference: "Operation Ancestry",
  },
]

export default function StudiosPage() {
  return (
    <main className="min-h-screen bg-background">
      <StudioHeader />

      <section className="pt-20">
        <EnvironmentRenderer patchId="ECHO_ENGINEERS_VRG33589" kind="lobby" />
      </section>

      {/* Hero Section */}
      <section className="relative py-16 overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-background to-background" />
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0wIDBoNDB2NDBoLTQweiIvPjxwYXRoIGQ9Ik00MCAyMGgtNDBNMjAgNDB2LTQwIiBzdHJva2U9IiNmZmYiIHN0cm9rZS1vcGFjaXR5PSIuMSIvPjwvZz48L3N2Zz4=')]" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4">
          <div className="max-w-4xl">
            <div className="flex flex-wrap gap-3 mb-6">
              <span className="text-xs font-mono text-primary border border-primary/30 px-3 py-1 bg-primary/10">
                VRG33589
              </span>
              <span className="text-xs font-mono text-foreground border border-primary/50 px-3 py-1">NEURO META X</span>
              <span className="text-xs font-mono text-muted-foreground border border-border px-3 py-1">
                CHAOS PRODUCTIONS
              </span>
              <span className="text-xs font-mono text-muted-foreground border border-border px-3 py-1">
                ECHO ENGINEERS
              </span>
            </div>

            <h1 className="text-5xl md:text-7xl font-bold text-foreground mb-4 tracking-tight">
              <GlitchText text="ECHO ENGINEERS" />
            </h1>
            <p className="text-xl md:text-2xl text-primary font-mono mb-2">VIDEO CONTENT SYSTEM</p>
            <p className="text-sm font-mono text-muted-foreground mb-6">
              CREATED BY <span className="text-accent">NEURO META X</span> | PROFILE:{" "}
              <span className="text-primary">VRG33589</span>
            </p>
            <p className="text-muted-foreground text-lg max-w-2xl mb-8 leading-relaxed">
              Five transmissions from the Echo Engineers. Hidden frequencies. Encrypted signals. Seven fragments
              scattered across the void. Can you decode the message?
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap gap-4">
              <Link
                href="/neteru-studios/barbed-wire-broadcast"
                className="flex items-center gap-2 bg-destructive/10 border border-destructive/50 px-6 py-3 text-destructive hover:bg-destructive/20 transition-all group"
              >
                <Radio className="w-4 h-4 animate-pulse" />
                <span className="font-mono text-sm">BARBED WIRE BROADCAST</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link
                href="/neteru-studios/clues"
                className="flex items-center gap-2 bg-secondary border border-border px-6 py-3 text-foreground hover:border-primary/50 transition-all group"
              >
                <Eye className="w-4 h-4" />
                <span className="font-mono text-sm">TRACK CLUES</span>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Barbed Wire Ticker */}
      <BarbedWireTicker />

      {/* Video Gallery Section */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-2 flex items-center gap-3">
                <Tv className="w-6 h-6 text-primary" />
                TRANSMISSIONS
              </h2>
              <p className="text-muted-foreground font-mono text-sm">5 videos • 7 embedded WL clues • 1 key</p>
            </div>
            <div className="hidden md:flex items-center gap-2 text-muted-foreground text-sm font-mono">
              <Lock className="w-4 h-4" />
              <span>0/7 CLUES FOUND</span>
            </div>
          </div>

          {/* Video Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {videos.map((video) => (
              <VideoCard key={video.id} {...video} />
            ))}
          </div>
        </div>
      </section>

      {/* WL Key Info */}
      <section className="py-16 px-4 bg-card/50">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 text-xs font-mono text-primary border border-primary/30 px-4 py-2 mb-6">
            <span className="w-2 h-2 bg-primary rounded-full animate-pulse" />
            ECHO PROTOCOL ACTIVE
          </div>
          <h2 className="text-3xl font-bold text-foreground mb-4">THE CIPHER AWAITS</h2>
          <div className="bg-background border border-destructive/30 p-6 rounded-sm mb-6">
            <p className="text-destructive font-mono text-sm mb-2">/// ENCRYPTED TRANSMISSION ///</p>
            <div className="h-16 flex items-center justify-center">
              <div className="flex gap-2">
                {Array.from({ length: 7 }).map((_, i) => (
                  <div
                    key={i}
                    className="w-8 h-8 border border-primary/30 bg-primary/5 flex items-center justify-center"
                  >
                    <span className="text-primary/50 text-xs font-mono">?</span>
                  </div>
                ))}
              </div>
            </div>
            <p className="text-muted-foreground text-xs mt-4 font-mono">
              SEVEN FRAGMENTS | ONE KEY | THE ECHO REMEMBERS
            </p>
          </div>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            The fragments are scattered. Each transmission holds a piece. Only those who watch, listen, and see beyond
            the surface will decode the final key.
          </p>
          <Link
            href="/neteru-studios/whitelist"
            className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-8 py-4 font-mono text-sm hover:bg-primary/90 transition-all"
          >
            SUBMIT YOUR KEY
            <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-muted-foreground text-sm font-mono">
            © ECHO ENGINEERS | NTRU | <span className="text-primary">VRG33589</span>
          </div>
          <div className="flex items-center gap-6">
            <span className="text-xs text-primary font-mono">ARTIST: NEURO META X</span>
            <span className="text-xs text-muted-foreground font-mono">CHAOS PRODUCTIONS</span>
            <span className="text-xs text-muted-foreground font-mono">ECHO ENGINEERS</span>
          </div>
        </div>
      </footer>
    </main>
  )
}
