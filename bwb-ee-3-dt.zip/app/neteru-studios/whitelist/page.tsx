import { StudioHeader } from "@/components/studio-header"
import { WLSubmissionForm } from "@/components/wl-submission-form"
import { BarbedWireTicker } from "@/components/barbed-wire-ticker"
import Link from "next/link"
import { Shield, Eye, ChevronRight, User, Fingerprint } from "lucide-react"

export default function WhitelistPage() {
  return (
    <main className="min-h-screen bg-background">
      <StudioHeader />

      {/* Hero Section */}
      <section className="relative pt-24 pb-12 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-primary/10 via-background to-background" />

        <div className="relative max-w-4xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="inline-flex items-center gap-2 text-xs font-mono text-primary border border-primary/30 px-4 py-2 bg-primary/10">
              <Fingerprint className="w-3 h-3" />
              VRG33589
            </div>
            <div className="inline-flex items-center gap-2 text-xs font-mono text-accent border border-accent/30 px-4 py-2">
              <User className="w-3 h-3" />
              NEURO META X
            </div>
          </div>

          <div className="inline-flex items-center gap-2 text-xs font-mono text-primary border border-primary/30 px-4 py-2 mb-6">
            <span className="w-2 h-2 bg-primary rounded-full animate-pulse" />
            WL PORTAL ACTIVE
          </div>

          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-2 tracking-tight">VRG33589 WHITELIST</h1>
          <p className="text-sm font-mono text-muted-foreground mb-4">ECHO ENGINEERS</p>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto mb-6 leading-relaxed">
            The cipher is complete only when all seven fragments are found. The Echo recognizes those who see beyond the
            surface. Enter your decoded key.
          </p>

          {/* Protocol Info */}
          <div className="inline-flex items-center gap-6 text-sm font-mono text-muted-foreground">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-primary" />
              <span>NTRU PROTOCOL</span>
            </div>
            <div className="w-px h-4 bg-border" />
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4 text-accent" />
              <span>7 CLUES REQUIRED</span>
            </div>
          </div>
        </div>
      </section>

      <BarbedWireTicker />

      {/* Main Content */}
      <section className="py-12 px-4">
        <div className="max-w-xl mx-auto">
          <div className="bg-primary/5 border border-primary/30 p-6 mb-8">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-16 h-16 bg-primary/20 border border-primary/50 flex items-center justify-center">
                <span className="font-mono text-primary font-bold text-xl">VRG</span>
              </div>
              <div>
                <h3 className="text-foreground font-bold text-lg">VRG33589</h3>
                <p className="text-sm text-muted-foreground font-mono">ARTIST & AUTHOR: NEURO META X</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-xs font-mono text-accent">CHAOS PRODUCTIONS</span>
                  <span className="text-xs text-muted-foreground">|</span>
                  <span className="text-xs font-mono text-accent">ECHO ENGINEERS</span>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-primary/20">
              <div className="text-center">
                <p className="text-2xl font-bold text-primary font-mono">EE</p>
                <p className="text-xs text-muted-foreground">ENGINEERS</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-accent font-mono">5</p>
                <p className="text-xs text-muted-foreground">TRANSMISSIONS</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-foreground font-mono">7</p>
                <p className="text-xs text-muted-foreground">WL CLUES</p>
              </div>
            </div>
          </div>

          {/* Instructions */}
          <div className="bg-card/50 border border-border p-6 mb-8">
            <h3 className="text-foreground font-bold mb-4">CIPHER SUBMISSION</h3>
            <ol className="space-y-3 text-sm text-muted-foreground">
              <li className="flex items-start gap-3">
                <span className="flex-shrink-0 w-6 h-6 bg-primary/20 text-primary font-mono text-xs flex items-center justify-center">
                  1
                </span>
                <span>Watch the five transmissions and discover the hidden fragments</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="flex-shrink-0 w-6 h-6 bg-primary/20 text-primary font-mono text-xs flex items-center justify-center">
                  2
                </span>
                <span>Decode the pattern—each fragment connects to form the cipher</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="flex-shrink-0 w-6 h-6 bg-primary/20 text-primary font-mono text-xs flex items-center justify-center">
                  3
                </span>
                <span>Submit your deciphered key for Echo validation</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="flex-shrink-0 w-6 h-6 bg-primary/20 text-primary font-mono text-xs flex items-center justify-center">
                  4
                </span>
                <span>Upon validation, register your identity to enter the Echo</span>
              </li>
            </ol>
          </div>

          {/* Submission Form */}
          <WLSubmissionForm />

          {/* Help Links */}
          <div className="mt-12 flex flex-wrap gap-4 justify-center">
            <Link
              href="/neteru-studios/clues"
              className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              <Eye className="w-4 h-4" />
              Track your discovered fragments
              <ChevronRight className="w-3 h-3" />
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-4 mt-12">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-muted-foreground text-sm font-mono">© ECHO ENGINEERS | VRG33589 | NTRU</div>
          <div className="flex items-center gap-4">
            <span className="text-xs text-primary font-mono">NEURO META X</span>
            <span className="text-xs text-muted-foreground font-mono">THE LEDGER REMEMBERS</span>
          </div>
        </div>
      </footer>
    </main>
  )
}
