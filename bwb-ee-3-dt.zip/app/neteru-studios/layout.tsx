import type React from "react"
import { EchoTerminal } from "@/components/echo-terminal"

export default function NeteruStudiosLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <>
      {children}
      <EchoTerminal />
    </>
  )
}
