import { StudioHeader } from "@/components/studio-header"
import { NewsBroadcastCard } from "@/components/news-broadcast-card"
import { BarbedWireTicker } from "@/components/barbed-wire-ticker"
import { Radio, Tv, AlertTriangle, Signal, Archive, ChevronRight, Volume2 } from "lucide-react"
import Link from "next/link"

const broadcasts = [
  {
    id: 1,
    title: "BREAKING: Shadow Council Meeting Intercepted at 33 Thomas Street",
    category: "BREAKING" as const,
    description:
      "Encrypted transmissions reveal coordinated efforts to suppress Neteru bloodline research. Full decoded transcript incoming.",
    timestamp: "3:33 AM EST",
    thumbnail: "/dark-government-building-surveillance-night-cyberp.jpg",
    duration: "08:47",
    isLive: true,
  },
  {
    id: 2,
    title: "CLASSIFIED: Operation Ancestry Documents Leaked",
    category: "CLASSIFIED" as const,
    description:
      "Internal memos expose DNA surveillance program targeting specific genetic markers. The hunt for cosmic bloodlines continues.",
    timestamp: "12:00 PM EST",
    thumbnail: "/classified-documents-dna-helix-conspiracy-dark.jpg",
    duration: "14:22",
  },
  {
    id: 3,
    title: "SIGNAL INTERCEPT: Marzain Frequency Detected Over Pacific",
    category: "SIGNAL" as const,
    description:
      "Unknown signal pattern matches ancient Marzain communication protocols. Temporal anomalies reported in surrounding waters.",
    timestamp: "06:15 AM PST",
    thumbnail: "/ocean-waves-radar-signal-mysterious-dark.jpg",
    duration: "11:33",
  },
  {
    id: 4,
    title: "ARCHIVE: The Veil of Time - Original BC/AD Fabrication Evidence",
    category: "ARCHIVE" as const,
    description:
      "Historical documents proving the chronological manipulation. How CERN continues the ancient alchemical deception.",
    timestamp: "ARCHIVED",
    thumbnail: "/ancient-manuscripts-time-symbols-mysterious.jpg",
    duration: "22:15",
  },
  {
    id: 5,
    title: "BREAKING: Nilotic Frequency Activation Reported Globally",
    category: "BREAKING" as const,
    description:
      "Multiple witnesses report strange phenomena. Those with Nilotic heritage experiencing unexplained awareness shifts.",
    timestamp: "NOW",
    thumbnail: "/global-map-energy-waves-aurora-mysterious.jpg",
    duration: "09:58",
    isLive: true,
  },
  {
    id: 6,
    title: "CLASSIFIED: DUMB Network Expansion Under Major Cities",
    category: "CLASSIFIED" as const,
    description:
      "Deep Underground Military Bases extend beneath civilian infrastructure. New tunneling activity detected.",
    timestamp: "2:22 AM CST",
    thumbnail: "/underground-tunnel-bunker-military-dark-mysterious.jpg",
    duration: "17:44",
  },
]

export default function BarbedWireBroadcastPage() {
  return (
    <main className="min-h-screen bg-background">
      <StudioHeader />

      {/* Breaking Banner */}
      <div className="pt-20 bg-destructive/5 border-b border-destructive/20">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-4">
          <div className="flex items-center gap-2 text-destructive animate-pulse">
            <Radio className="w-5 h-5" />
            <span className="font-mono text-sm font-bold">LIVE BROADCAST</span>
          </div>
          <div className="h-4 w-px bg-destructive/30" />
          <span className="text-sm text-muted-foreground font-mono">Signal Strength: 78.9%</span>
        </div>
      </div>

      {/* Hero Section */}
      <section className="relative py-12 overflow-hidden border-b border-border">
        {/* Background Effects */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-destructive/10 via-background to-background" />

        {/* Barbed Wire Pattern Overlay */}
        <div className="absolute inset-0 opacity-5">
          <svg className="w-full h-full" preserveAspectRatio="none">
            <pattern id="barbedHero" x="0" y="0" width="60" height="30" patternUnits="userSpaceOnUse">
              <path
                d="M0 15 L15 15 L20 10 L25 15 L35 15 L40 20 L45 15 L60 15"
                stroke="currentColor"
                fill="none"
                strokeWidth="2"
                className="text-destructive"
              />
              <circle cx="20" cy="10" r="2" fill="currentColor" className="text-destructive" />
              <circle cx="40" cy="20" r="2" fill="currentColor" className="text-destructive" />
            </pattern>
            <rect width="100%" height="100%" fill="url(#barbedHero)" />
          </svg>
        </div>

        <div className="relative max-w-7xl mx-auto px-4">
          <div className="max-w-4xl">
            {/* Logo/Brand */}
            <div className="flex items-center gap-4 mb-6">
              <div className="relative">
                <div className="w-16 h-16 bg-destructive/20 border-2 border-destructive flex items-center justify-center">
                  <Radio className="w-8 h-8 text-destructive" />
                </div>
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-destructive rounded-full animate-pulse" />
              </div>
              <div>
                <h1 className="text-4xl md:text-5xl font-bold text-foreground tracking-tight">BARBED WIRE</h1>
                <p className="text-xl text-destructive font-mono">BROADCAST</p>
              </div>
            </div>

            <p className="text-muted-foreground text-lg max-w-2xl mb-6 leading-relaxed">
              Unfiltered transmissions from beyond the veil. News they don't want you to see. Signals intercepted.
              Truths decoded. The wire remembers.
            </p>

            {/* Stats Bar */}
            <div className="flex flex-wrap gap-6 text-sm font-mono">
              <div className="flex items-center gap-2 text-destructive">
                <AlertTriangle className="w-4 h-4" />
                <span>2 LIVE BROADCASTS</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Signal className="w-4 h-4" />
                <span>6 ACTIVE SIGNALS</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Archive className="w-4 h-4" />
                <span>47 ARCHIVED</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Ticker */}
      <BarbedWireTicker />

      {/* Featured Live Broadcast */}
      <section className="py-12 px-4 bg-card/30">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-3 h-3 bg-destructive rounded-full animate-pulse" />
            <h2 className="text-lg font-bold text-foreground font-mono">FEATURED BROADCAST</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-6 bg-background border border-destructive/30 p-6">
            <div className="relative aspect-video bg-muted overflow-hidden">
              <img
                src="/news-broadcast-studio-dark-cyberpunk-surveillance.jpg"
                alt="Live Broadcast"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
              <div className="absolute top-4 left-4 flex items-center gap-2 bg-destructive px-3 py-1">
                <Radio className="w-3 h-3 animate-pulse" />
                <span className="text-xs font-mono font-bold text-destructive-foreground">LIVE NOW</span>
              </div>
              <div className="absolute bottom-4 left-4 right-4">
                <div className="flex items-center gap-2 text-foreground">
                  <Volume2 className="w-4 h-4" />
                  <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden">
                    <div className="h-full w-2/3 bg-destructive" />
                  </div>
                </div>
              </div>
            </div>
            <div className="flex flex-col justify-center">
              <span className="text-destructive font-mono text-sm mb-2">/// PRIORITY TRANSMISSION ///</span>
              <h3 className="text-2xl font-bold text-foreground mb-4">The Echo Engineers: Live Decryption Session</h3>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                Join our analysts as they decode the latest intercepted transmissions from 33 Thomas Street. Real-time
                cipher breaking. Classified frequency analysis. The truth unfolds live.
              </p>
              <button className="self-start flex items-center gap-2 bg-destructive text-destructive-foreground px-6 py-3 font-mono text-sm hover:bg-destructive/90 transition-all">
                <Tv className="w-4 h-4" />
                WATCH NOW
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Broadcast Grid */}
      <section className="py-12 px-4">
        <div className="max-w-7xl mx-auto">
          {/* Section Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-2">ALL BROADCASTS</h2>
              <p className="text-muted-foreground font-mono text-sm">
                Intercepted signals • Decoded transmissions • Archived evidence
              </p>
            </div>
            {/* Filter Tabs */}
            <div className="hidden md:flex items-center gap-2">
              <button className="px-4 py-2 text-xs font-mono bg-destructive/10 text-destructive border border-destructive/30">
                ALL
              </button>
              <button className="px-4 py-2 text-xs font-mono text-muted-foreground border border-border hover:border-destructive/30 transition-colors">
                LIVE
              </button>
              <button className="px-4 py-2 text-xs font-mono text-muted-foreground border border-border hover:border-destructive/30 transition-colors">
                CLASSIFIED
              </button>
              <button className="px-4 py-2 text-xs font-mono text-muted-foreground border border-border hover:border-destructive/30 transition-colors">
                ARCHIVE
              </button>
            </div>
          </div>

          {/* Broadcast Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {broadcasts.map((broadcast) => (
              <NewsBroadcastCard key={broadcast.id} {...broadcast} />
            ))}
          </div>

          {/* Load More */}
          <div className="mt-12 text-center">
            <button className="inline-flex items-center gap-2 border border-border px-8 py-3 text-muted-foreground font-mono text-sm hover:border-destructive/50 hover:text-foreground transition-all">
              LOAD MORE BROADCASTS
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 bg-destructive/5 border-t border-destructive/20">
        <div className="max-w-4xl mx-auto text-center">
          <AlertTriangle className="w-12 h-12 text-destructive mx-auto mb-4" />
          <h2 className="text-3xl font-bold text-foreground mb-4">BECOME A SOURCE</h2>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            Have evidence? Intercepted transmissions? The Barbed Wire Broadcast network accepts encrypted submissions.
            Your identity stays protected.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link
              href="/neteru-studios/whitelist"
              className="inline-flex items-center gap-2 bg-destructive text-destructive-foreground px-8 py-4 font-mono text-sm hover:bg-destructive/90 transition-all"
            >
              SUBMIT INTEL
              <ChevronRight className="w-4 h-4" />
            </Link>
            <Link
              href="/neteru-studios"
              className="inline-flex items-center gap-2 border border-border px-8 py-4 text-foreground font-mono text-sm hover:border-destructive/50 transition-all"
            >
              BACK TO ECHO ENGINEERS
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Radio className="w-5 h-5 text-destructive" />
            <span className="text-muted-foreground text-sm font-mono">BARBED WIRE BROADCAST | ECHO ENGINEERS</span>
          </div>
          <div className="text-xs text-muted-foreground font-mono">
            THE WIRE REMEMBERS | SIGNAL FREQUENCY: NTRU.33 MHz
          </div>
        </div>
      </footer>
    </main>
  )
}
