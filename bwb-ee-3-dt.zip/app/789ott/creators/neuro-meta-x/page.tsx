"use client"

import Link from "next/link"
import { Tv, Play, Clock, Calendar, ExternalLink } from "lucide-react"
import { StudioHeader } from "@/components/studio-header"

const transmissions = [
  {
    id: "ntru-001",
    title: "The Artifact Pulse",
    duration: "4:33",
    released: "2025",
    status: "AVAILABLE",
  },
  {
    id: "ntru-002",
    title: "Nilotic Frequency",
    duration: "5:17",
    released: "2025",
    status: "AVAILABLE",
  },
  {
    id: "ntru-003",
    title: "The Dark Nexus",
    duration: "6:02",
    released: "2025",
    status: "AVAILABLE",
  },
  {
    id: "ntru-004",
    title: "Veil of Time Collapse",
    duration: "5:49",
    released: "2025",
    status: "AVAILABLE",
  },
  {
    id: "ntru-005",
    title: "Operation Ancestry",
    duration: "7:21",
    released: "2025",
    status: "AVAILABLE",
  },
]

export default function OTTNeuroMetaXPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <StudioHeader />

      <main className="pt-24 pb-16">
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4">
            {/* Breadcrumb */}
            <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground mb-8">
              <Link href="/789ott" className="hover:text-destructive transition-colors">
                789OTT
              </Link>
              <span>/</span>
              <Link href="/789ott/creators" className="hover:text-destructive transition-colors">
                CREATORS
              </Link>
              <span>/</span>
              <span className="text-destructive">NEURO META X</span>
            </div>

            {/* Profile Header */}
            <div className="relative bg-card border border-border p-8 md:p-12 mb-8">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(239,68,68,0.05)_0%,transparent_50%)]" />

              <div className="relative flex flex-col md:flex-row gap-8 items-start">
                <div className="w-32 h-32 bg-destructive/10 border-2 border-destructive flex items-center justify-center shrink-0">
                  <Tv className="w-16 h-16 text-destructive animate-pulse" />
                </div>

                <div className="flex-1">
                  <div className="flex items-center gap-4 mb-4">
                    <h1 className="text-4xl font-bold text-destructive">NEURO META X</h1>
                    <span className="text-xs bg-accent/20 text-accent px-3 py-1 border border-accent/30">
                      VERIFIED CREATOR
                    </span>
                  </div>

                  <p className="text-lg text-muted-foreground mb-6 max-w-2xl">
                    Primary content architect for 789OTT. Original transmissions from the Neteru Universe. Streaming
                    direct to your signal.
                  </p>

                  <div className="flex flex-wrap gap-3 mb-6">
                    <span className="text-sm border border-destructive/30 px-4 py-2 text-destructive">
                      CHAOS PRODUCTIONS
                    </span>
                    <span className="text-sm border border-primary/30 px-4 py-2 text-primary">NETERU STUDIOS</span>
                    <span className="text-sm border border-accent/30 px-4 py-2 text-accent">VRG33589</span>
                  </div>

                  <div className="flex gap-4">
                    <Link
                      href="/wired-chaos/creators/neuro-meta-x"
                      className="text-sm text-muted-foreground hover:text-destructive transition-colors flex items-center gap-2"
                    >
                      <ExternalLink className="w-4 h-4" />
                      View on WIRED CHAOS
                    </Link>
                  </div>
                </div>

                <div className="bg-background border border-border p-6 w-full md:w-auto">
                  <div className="text-xs text-muted-foreground mb-2">CREATOR ID</div>
                  <div className="text-2xl font-mono text-destructive mb-4">VRG33589</div>

                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <div className="text-xl font-bold text-destructive">5</div>
                      <div className="text-xs text-muted-foreground">TRANSMISSIONS</div>
                    </div>
                    <div>
                      <div className="text-xl font-bold text-accent">29+</div>
                      <div className="text-xs text-muted-foreground">MINUTES</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Transmissions */}
            <div className="mb-12">
              <h2 className="text-xl font-bold tracking-wide mb-6 flex items-center gap-3">
                <Play className="w-5 h-5 text-destructive" />
                TRANSMISSIONS
              </h2>

              <div className="space-y-4">
                {transmissions.map((tx, index) => (
                  <Link
                    key={tx.id}
                    href="/neteru-studios"
                    className="group flex items-center gap-4 bg-card border border-border p-4 hover:border-destructive/50 transition-all"
                  >
                    <div className="w-12 h-12 bg-destructive/10 border border-destructive/30 flex items-center justify-center shrink-0">
                      <span className="text-destructive font-mono text-sm">{String(index + 1).padStart(2, "0")}</span>
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs text-destructive font-mono">{tx.id.toUpperCase()}</span>
                        <span className="text-xs bg-accent/20 text-accent px-2 py-0.5">{tx.status}</span>
                      </div>
                      <h3 className="font-bold group-hover:text-destructive transition-colors">{tx.title}</h3>
                    </div>

                    <div className="hidden md:flex items-center gap-6 text-sm text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        {tx.duration}
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        {tx.released}
                      </div>
                    </div>

                    <Play className="w-5 h-5 text-muted-foreground group-hover:text-destructive transition-colors" />
                  </Link>
                ))}
              </div>
            </div>

            {/* CTA */}
            <div className="bg-destructive/5 border border-destructive/30 p-8 text-center">
              <h3 className="text-xl font-bold mb-4">TUNE INTO THE SIGNAL</h3>
              <p className="text-muted-foreground mb-6 max-w-lg mx-auto">
                Access all transmissions from NEURO META X. Uncover the hidden frequencies. Join the Echo Engineers
                network.
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Link
                  href="/neteru-studios"
                  className="bg-destructive text-white px-6 py-3 font-bold tracking-wide hover:bg-destructive/90 transition-colors"
                >
                  WATCH NOW
                </Link>
                <Link
                  href="/neteru-studios/whitelist"
                  className="border border-destructive/50 text-destructive px-6 py-3 font-bold tracking-wide hover:bg-destructive/10 transition-colors"
                >
                  JOIN WHITELIST
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="py-8 border-t border-border">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-xs text-muted-foreground font-mono">
            NEURO META X | 789OTT | NETERU STUDIOS | WIRED CHAOS META HUB
          </p>
        </div>
      </footer>
    </div>
  )
}
