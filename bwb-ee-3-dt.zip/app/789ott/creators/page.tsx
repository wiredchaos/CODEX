"use client"

import Link from "next/link"
import { Tv, ArrowRight } from "lucide-react"
import { StudioHeader } from "@/components/studio-header"

const creators = [
  {
    id: "neuro-meta-x",
    name: "NEURO META X",
    role: "Primary Content Architect",
    profileId: "VRG33589",
    productions: ["CHAOS PRODUCTIONS", "NETERU STUDIOS"],
    status: "STREAMING",
    contentHours: "29+",
    verified: true,
  },
]

export default function OTTCreatorsPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <StudioHeader />

      <main className="pt-24 pb-16">
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4">
            {/* Breadcrumb */}
            <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground mb-8">
              <Link href="/789ott" className="hover:text-destructive transition-colors">
                789OTT
              </Link>
              <span>/</span>
              <span className="text-destructive">CREATORS</span>
            </div>

            <h1 className="text-4xl font-bold tracking-tight mb-4">
              <span className="text-destructive">CONTENT</span> CREATORS
            </h1>
            <p className="text-muted-foreground max-w-2xl mb-12">
              The architects behind the transmissions. Original content. Unfiltered narratives. Direct signal delivery.
            </p>

            {/* Creator Grid */}
            <div className="grid gap-6">
              {creators.map((creator) => (
                <Link
                  key={creator.id}
                  href={`/789ott/creators/${creator.id}`}
                  className="group relative bg-card border border-border p-6 md:p-8 hover:border-destructive/50 transition-all"
                >
                  <div className="flex flex-col md:flex-row gap-6 items-start md:items-center">
                    <div className="w-20 h-20 bg-destructive/10 border border-destructive/30 flex items-center justify-center shrink-0">
                      <Tv className="w-10 h-10 text-destructive" />
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h2 className="text-2xl font-bold text-destructive group-hover:animate-pulse">
                          {creator.name}
                        </h2>
                        {creator.verified && (
                          <span className="text-xs bg-accent/20 text-accent px-2 py-0.5 border border-accent/30">
                            VERIFIED
                          </span>
                        )}
                      </div>

                      <p className="text-muted-foreground mb-3">{creator.role}</p>

                      <div className="flex flex-wrap gap-2">
                        {creator.productions.map((prod) => (
                          <span key={prod} className="text-xs border border-border px-2 py-1 text-muted-foreground">
                            {prod}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center gap-8">
                      <div className="text-center hidden md:block">
                        <div className="text-2xl font-bold text-destructive">{creator.contentHours}</div>
                        <div className="text-xs text-muted-foreground">CONTENT HOURS</div>
                      </div>

                      <div className="text-right hidden md:block">
                        <div className="text-xs text-muted-foreground mb-1">PROFILE ID</div>
                        <div className="font-mono text-destructive">{creator.profileId}</div>
                      </div>

                      <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-destructive group-hover:translate-x-1 transition-all" />
                    </div>
                  </div>

                  {/* Status Indicator */}
                  <div className="absolute top-4 right-4 flex items-center gap-2 text-xs font-mono">
                    <span className="w-2 h-2 bg-destructive rounded-full animate-pulse" />
                    <span className="text-destructive">{creator.status}</span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}
