"use client"

import Link from "next/link"
import { Play, Tv, Film, Users, Zap, Radio } from "lucide-react"
import { StudioHeader } from "@/components/studio-header"

export default function OTTHub() {
  const featuredContent = [
    {
      id: "ntru-001",
      title: "The Artifact Pulse",
      creator: "NEURO META X",
      type: "TRANSMISSION",
      duration: "4:33",
    },
    {
      id: "ntru-002",
      title: "Nilotic Frequency",
      creator: "NEURO META X",
      type: "TRANSMISSION",
      duration: "5:17",
    },
    {
      id: "ntru-003",
      title: "The Dark Nexus",
      creator: "NEURO META X",
      type: "TRANSMISSION",
      duration: "6:02",
    },
  ]

  return (
    <div className="min-h-screen bg-background text-foreground">
      <StudioHeader />

      <main className="pt-24 pb-16">
        {/* Hero Section */}
        <section className="relative py-20 overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(239,68,68,0.1)_0%,transparent_50%)]" />

          <div className="max-w-7xl mx-auto px-4 text-center relative z-10">
            <div className="inline-flex items-center gap-2 text-xs font-mono text-destructive mb-6 border border-destructive/30 px-4 py-2">
              <Radio className="w-3 h-3 animate-pulse" />
              <span>STREAMING NOW</span>
            </div>

            <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-2">
              <span className="text-destructive">789</span>
              <span className="text-foreground">OTT</span>
            </h1>
            <p className="text-sm font-mono text-muted-foreground mb-6">OVER-THE-TOP TRANSMISSION NETWORK</p>

            <p className="text-muted-foreground text-lg max-w-2xl mx-auto mb-8">
              The streaming arm of the Neteru Universe. Original content. Creator-driven narratives. Unfiltered
              transmissions direct to your signal receiver.
            </p>

            <div className="flex flex-wrap justify-center gap-4">
              <Link
                href="/789ott/creators"
                className="bg-destructive text-white px-6 py-3 font-bold tracking-wide hover:bg-destructive/90 transition-colors flex items-center gap-2"
              >
                <Users className="w-4 h-4" />
                BROWSE CREATORS
              </Link>
              <Link
                href="/neteru-studios"
                className="border border-destructive/50 text-destructive px-6 py-3 font-bold tracking-wide hover:bg-destructive/10 transition-colors flex items-center gap-2"
              >
                <Film className="w-4 h-4" />
                NETERU STUDIOS
              </Link>
            </div>
          </div>
        </section>

        {/* Stats */}
        <section className="py-12 border-y border-border bg-card/30">
          <div className="max-w-7xl mx-auto px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
              {[
                { label: "CHANNELS", value: "7", icon: Tv },
                { label: "CREATORS", value: "33", icon: Users },
                { label: "HOURS CONTENT", value: "589+", icon: Film },
                { label: "SIGNAL UPTIME", value: "99.9%", icon: Zap },
              ].map((stat) => (
                <div key={stat.label}>
                  <stat.icon className="w-5 h-5 text-destructive mx-auto mb-2" />
                  <div className="text-2xl font-bold text-destructive">{stat.value}</div>
                  <div className="text-xs text-muted-foreground tracking-widest">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Featured Content */}
        <section className="py-16">
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-xl font-bold tracking-wide">FEATURED TRANSMISSIONS</h2>
              <Link href="/neteru-studios" className="text-sm text-destructive hover:underline">
                VIEW ALL
              </Link>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              {featuredContent.map((item) => (
                <Link
                  key={item.id}
                  href="/neteru-studios"
                  className="group bg-card border border-border hover:border-destructive/50 transition-all"
                >
                  <div className="aspect-video bg-gradient-to-br from-destructive/20 to-background relative overflow-hidden">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Play className="w-12 h-12 text-destructive opacity-50 group-hover:opacity-100 group-hover:scale-110 transition-all" />
                    </div>
                    <div className="absolute top-2 left-2 text-xs bg-destructive text-white px-2 py-1">{item.type}</div>
                    <div className="absolute bottom-2 right-2 text-xs bg-background/80 px-2 py-1 font-mono">
                      {item.duration}
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold mb-1 group-hover:text-destructive transition-colors">{item.title}</h3>
                    <p className="text-sm text-muted-foreground">{item.creator}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Featured Creator */}
        <section className="py-16 bg-card/50 border-y border-border">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-xl font-bold tracking-wide mb-8 text-center">FEATURED CREATOR</h2>

            <Link href="/789ott/creators/neuro-meta-x" className="block group">
              <div className="bg-background border border-border p-8 hover:border-destructive/50 transition-colors max-w-3xl mx-auto">
                <div className="flex flex-col md:flex-row gap-6 items-center text-center md:text-left">
                  <div className="w-24 h-24 bg-destructive/10 border border-destructive/30 flex items-center justify-center shrink-0">
                    <Tv className="w-12 h-12 text-destructive" />
                  </div>

                  <div className="flex-1">
                    <h3 className="text-2xl font-bold text-destructive mb-2 group-hover:animate-pulse">NEURO META X</h3>
                    <p className="text-muted-foreground mb-3">
                      Primary content architect. 5 transmissions. VRG33589 verified.
                    </p>
                    <div className="flex flex-wrap gap-2 justify-center md:justify-start">
                      <span className="text-xs border border-destructive/30 px-2 py-1 text-destructive">
                        CHAOS PRODUCTIONS
                      </span>
                      <span className="text-xs border border-primary/30 px-2 py-1 text-primary">NETERU STUDIOS</span>
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="py-8 border-t border-border">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-xs text-muted-foreground font-mono">
            789OTT | NETERU STUDIOS | CHAOS PRODUCTIONS | WIRED CHAOS META HUB
          </p>
        </div>
      </footer>
    </div>
  )
}
