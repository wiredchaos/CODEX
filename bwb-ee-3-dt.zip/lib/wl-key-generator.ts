/**
 * WL Key Generation System
 * Generates unique whitelist keys for each user based on gameplay data
 */

export interface GameplayData {
  cluesFound: number[]
  discoveryTimestamps: number[]
  discoveryOrder: number[]
  sessionStartTime: number
  userInteractionPatterns: {
    videoWatches: number
    pageVisits: number
    clueAttempts: number
  }
}

export interface KeySegment {
  id: number
  baseValue: string
  generateVariant: (data: GameplayData) => string
}

// Define key segments with variation logic
const keySegments: KeySegment[] = [
  {
    id: 1,
    baseValue: "589",
    generateVariant: (data: GameplayData) => {
      // Varies based on discovery time
      const hourCode = new Date(data.discoveryTimestamps[0] || Date.now()).getHours()
      return `${500 + hourCode}${9}`
    },
  },
  {
    id: 2,
    baseValue: "BEYOND_THE_VEIL",
    generateVariant: (data: GameplayData) => {
      const phrases = [
        "BEYOND_THE_VEIL",
        "OUTSIDE_YOUR_ASSIGNMENT",
        "THROUGH_THE_ECHO",
        "BREAK_THE_PATTERN",
        "SEE_THE_SIGNAL",
      ]
      // Select based on discovery order pattern
      const patternSum = data.discoveryOrder.reduce((a, b) => a + b, 0)
      return phrases[patternSum % phrases.length]
    },
  },
  {
    id: 3,
    baseValue: "33.9N-118.2W",
    generateVariant: (data: GameplayData) => {
      // Generate coordinates based on user's interaction pattern
      const lat = 30 + (data.userInteractionPatterns.videoWatches % 10)
      const lon = 110 + (data.userInteractionPatterns.pageVisits % 20)
      return `${lat}.${data.cluesFound.length}N-${lon}.${data.userInteractionPatterns.clueAttempts % 10}W`
    },
  },
  {
    id: 4,
    baseValue: "NTRU",
    generateVariant: (data: GameplayData) => {
      const tokens = ["NTRU", "ECHO", "VRGE", "META", "NETU"]
      // Based on session timing
      const sessionMinutes = Math.floor((Date.now() - data.sessionStartTime) / 60000)
      return tokens[sessionMinutes % tokens.length]
    },
  },
  {
    id: 5,
    baseValue: "3:33",
    generateVariant: (data: GameplayData) => {
      // Time-based variation
      const now = new Date(data.discoveryTimestamps[4] || Date.now())
      const hour = now.getHours() % 12 || 12
      const minute = now.getMinutes()
      return `${hour}:${minute.toString().padStart(2, "0")}`
    },
  },
  {
    id: 6,
    baseValue: "THE_LEDGER_REMEMBERS",
    generateVariant: (data: GameplayData) => {
      const phrases = [
        "THE_LEDGER_REMEMBERS",
        "THE_ECHO_KNOWS",
        "THE_MATRIX_RECALLS",
        "THE_SIGNAL_ENDURES",
        "THE_PATTERN_HOLDS",
      ]
      // Based on total clues found
      return phrases[data.cluesFound.length % phrases.length]
    },
  },
  {
    id: 7,
    baseValue: "33",
    generateVariant: (data: GameplayData) => {
      // Final seal varies by completion order
      const orderSum = data.discoveryOrder.reduce((a, b) => a + b, 0)
      const sealNumbers = [33, 77, 99, 111, 222]
      return sealNumbers[orderSum % sealNumbers.length].toString()
    },
  },
]

/**
 * Generate a unique WL key for the user based on their gameplay
 */
export function generatePersonalizedWLKey(gameplayData: GameplayData): string {
  const segments = keySegments.map((segment) => segment.generateVariant(gameplayData))
  return segments.join("-")
}

/**
 * Store gameplay data in localStorage
 */
export function saveGameplayData(data: GameplayData): void {
  if (typeof window !== "undefined") {
    localStorage.setItem("vrg33589_gameplay", JSON.stringify(data))
  }
}

/**
 * Retrieve gameplay data from localStorage
 */
export function loadGameplayData(): GameplayData | null {
  if (typeof window === "undefined") return null

  const stored = localStorage.getItem("vrg33589_gameplay")
  if (!stored) {
    // Initialize new gameplay session
    const newData: GameplayData = {
      cluesFound: [],
      discoveryTimestamps: [],
      discoveryOrder: [],
      sessionStartTime: Date.now(),
      userInteractionPatterns: {
        videoWatches: 0,
        pageVisits: 0,
        clueAttempts: 0,
      },
    }
    saveGameplayData(newData)
    return newData
  }

  return JSON.parse(stored)
}

/**
 * Update gameplay data when a clue is found
 */
export function recordClueDiscovery(clueId: number): GameplayData {
  const data = loadGameplayData() || {
    cluesFound: [],
    discoveryTimestamps: [],
    discoveryOrder: [],
    sessionStartTime: Date.now(),
    userInteractionPatterns: { videoWatches: 0, pageVisits: 0, clueAttempts: 0 },
  }

  if (!data.cluesFound.includes(clueId)) {
    data.cluesFound.push(clueId)
    data.discoveryTimestamps.push(Date.now())
    data.discoveryOrder.push(clueId)
  }

  saveGameplayData(data)
  return data
}

/**
 * Track user interactions
 */
export function trackInteraction(type: "video" | "page" | "clue"): void {
  const data = loadGameplayData()
  if (!data) return

  if (type === "video") data.userInteractionPatterns.videoWatches++
  if (type === "page") data.userInteractionPatterns.pageVisits++
  if (type === "clue") data.userInteractionPatterns.clueAttempts++

  saveGameplayData(data)
}

/**
 * Get user's current progress percentage
 */
export function getProgressPercentage(): number {
  const data = loadGameplayData()
  if (!data) return 0
  return Math.round((data.cluesFound.length / 7) * 100)
}
