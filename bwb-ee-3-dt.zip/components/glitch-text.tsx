"use client"

import { useEffect, useState } from "react"

interface GlitchTextProps {
  text: string
  className?: string
}

export function GlitchText({ text, className = "" }: GlitchTextProps) {
  const [isGlitching, setIsGlitching] = useState(false)

  useEffect(() => {
    const interval = setInterval(() => {
      setIsGlitching(true)
      setTimeout(() => setIsGlitching(false), 200)
    }, 4000)

    return () => clearInterval(interval)
  }, [])

  return (
    <span className={`relative inline-block ${className}`}>
      <span className={isGlitching ? "glitch-text" : ""}>{text}</span>
      {isGlitching && (
        <>
          <span
            className="absolute top-0 left-0 text-primary/80 clip-glitch-1"
            style={{ transform: "translate(-2px, -1px)" }}
            aria-hidden="true"
          >
            {text}
          </span>
          <span
            className="absolute top-0 left-0 text-accent/80 clip-glitch-2"
            style={{ transform: "translate(2px, 1px)" }}
            aria-hidden="true"
          >
            {text}
          </span>
        </>
      )}
    </span>
  )
}
