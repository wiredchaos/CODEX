"use client"

export function BarbedWireTicker() {
  const headlines = [
    "/// SIGNAL BREACH DETECTED AT 33.9N-118.2W ///",
    "/// ECHO ENGINEERS TRANSMISSION INCOMING ///",
    "/// THE LEDGER REMEMBERS ///",
    "/// VEIL OF TIME COLLAPSE IMMINENT ///",
    "/// NTRU PROTOCOL ACTIVATED ///",
    "/// OUTSIDE YOUR ASSIGNMENT ///",
    "/// DARK NEXUS FREQUENCIES DETECTED ///",
    "/// OPERATION ANCESTRY: CLASSIFIED ///",
  ]

  return (
    <div className="relative overflow-hidden bg-destructive/10 border-y border-destructive/30 py-2">
      {/* Barbed Wire Pattern */}
      <div className="absolute inset-0 opacity-10">
        <svg className="w-full h-full" preserveAspectRatio="none">
          <pattern id="barbed" x="0" y="0" width="40" height="20" patternUnits="userSpaceOnUse">
            <path
              d="M0 10 L10 10 L15 5 L20 10 L30 10 L35 15 L40 10"
              stroke="currentColor"
              fill="none"
              strokeWidth="1"
              className="text-destructive"
            />
          </pattern>
          <rect width="100%" height="100%" fill="url(#barbed)" />
        </svg>
      </div>

      {/* Scrolling Text */}
      <div className="flex animate-[barbed-scroll_30s_linear_infinite]" style={{ width: "max-content" }}>
        {[...headlines, ...headlines].map((headline, i) => (
          <span key={i} className="text-destructive font-mono text-sm px-8 whitespace-nowrap">
            {headline}
          </span>
        ))}
      </div>
    </div>
  )
}
