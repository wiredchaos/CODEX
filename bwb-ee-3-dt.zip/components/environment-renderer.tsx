"use client"

/**
 * ENVIRONMENT RENDERER (TRINITY CONSUMER)
 *
 * This component CONSUMES the WIRED CHAOS Trinity 3D Core.
 * It does NOT generate 3D content or create timelines.
 *
 * CONSTRAINTS:
 * - Read-only Trinity Core
 * - Respects Akira Codex gating
 * - Uses hotspots + HUD supplied by core
 * - Business data stays firewalled
 * - Falls back to video if 3D not permitted
 */

import { useEffect, useState } from "react"
import {
  TRINITY_HOTSPOTS,
  validateConsumerMount,
  getAuthorizedRenderMode,
  type TrinityKind,
  type RenderMode,
} from "@/lib/trinity-mount"
import { Eye, Lock, Radio, Tv, AlertTriangle } from "lucide-react"
import Link from "next/link"

interface EnvironmentRendererProps {
  patchId: string
  kind: TrinityKind
}

export function EnvironmentRenderer({ patchId, kind }: EnvironmentRendererProps) {
  const [mounted, setMounted] = useState(false)
  const [renderMode, setRenderMode] = useState<RenderMode>("VIDEO_FALLBACK")
  const [validationStatus, setValidationStatus] = useState<{ valid: boolean; reason: string } | null>(null)
  const [activeHotspot, setActiveHotspot] = useState<string | null>(null)

  useEffect(() => {
    // Validate consumer mount on initialization
    const validation = validateConsumerMount()
    setValidationStatus(validation)

    if (validation.valid) {
      // Get authorized render mode (will be VIDEO_FALLBACK since 3D prohibited)
      const mode = getAuthorizedRenderMode()
      setRenderMode(mode)
      setMounted(true)
    }
  }, [])

  if (!validationStatus?.valid) {
    return (
      <div className="w-full h-96 bg-destructive/10 border border-destructive/50 flex items-center justify-center">
        <div className="text-center">
          <AlertTriangle className="w-12 h-12 text-destructive mx-auto mb-4" />
          <p className="text-destructive font-mono text-sm">MOUNT VALIDATION FAILED</p>
          <p className="text-muted-foreground text-xs mt-2">{validationStatus?.reason}</p>
        </div>
      </div>
    )
  }

  const hotspotLinks: Record<string, string> = {
    hs_transmissions: "/neteru-studios",
    hs_barbed_wire: "/neteru-studios/barbed-wire-broadcast",
    hs_clues: "/neteru-studios/clues",
    hs_whitelist: "/neteru-studios/whitelist",
  }

  const hotspotIcons: Record<string, typeof Eye> = {
    hs_transmissions: Tv,
    hs_barbed_wire: Radio,
    hs_clues: Eye,
    hs_whitelist: Lock,
  }

  return (
    <div className="relative w-full aspect-video bg-background overflow-hidden border border-primary/20">
      {/* Trinity Mount Status HUD */}
      <div className="absolute top-4 left-4 z-20">
        <div className="bg-background/90 border border-primary/30 px-3 py-2 font-mono text-xs">
          <div className="flex items-center gap-2 text-primary mb-1">
            <span className="w-2 h-2 bg-accent rounded-full animate-pulse" />
            TRINITY MOUNT ACTIVE
          </div>
          <div className="text-muted-foreground space-y-0.5">
            <p>PATCH: {patchId}</p>
            <p>KIND: {kind.toUpperCase()}</p>
            <p>MODE: {renderMode}</p>
            <p>CORE: READ_ONLY</p>
          </div>
        </div>
      </div>

      {/* Akira Codex Gating Badge */}
      <div className="absolute top-4 right-4 z-20">
        <div className="bg-background/90 border border-accent/30 px-3 py-2 font-mono text-xs">
          <div className="flex items-center gap-2 text-accent">
            <Lock className="w-3 h-3" />
            AKIRA CODEX
          </div>
        </div>
      </div>

      {/* Video Fallback Layer (3D not permitted) */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background/80 to-background">
        {/* Simulated cinematic environment via CSS */}
        <div className="absolute inset-0 overflow-hidden">
          {/* Grid floor effect */}
          <div
            className="absolute inset-0 opacity-20"
            style={{
              backgroundImage: `
                linear-gradient(to right, rgba(245, 158, 11, 0.1) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(245, 158, 11, 0.1) 1px, transparent 1px)
              `,
              backgroundSize: "40px 40px",
              transform: "perspective(500px) rotateX(60deg)",
              transformOrigin: "center top",
            }}
          />

          {/* Ambient glow */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />

          {/* Scanline overlay */}
          <div
            className="absolute inset-0 pointer-events-none opacity-30"
            style={{
              backgroundImage:
                "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.3) 2px, rgba(0,0,0,0.3) 4px)",
            }}
          />
        </div>

        {/* VRG33589 Center Element */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center z-10">
          <div className="text-6xl md:text-8xl font-bold text-primary/20 tracking-widest">VRG33589</div>
          <div className="text-sm font-mono text-muted-foreground mt-2">ECHO ENGINEERS LOBBY</div>
        </div>
      </div>

      {/* Trinity Hotspots (supplied by core) */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20">
        <div className="flex items-center gap-4">
          {TRINITY_HOTSPOTS.map((hotspot) => {
            const Icon = hotspotIcons[hotspot.id] || Eye
            const href = hotspotLinks[hotspot.id] || "#"

            return (
              <Link
                key={hotspot.id}
                href={href}
                className={`
                  group relative flex flex-col items-center gap-2 p-3 
                  bg-background/80 border transition-all
                  ${
                    activeHotspot === hotspot.id
                      ? "border-primary bg-primary/10"
                      : "border-border hover:border-primary/50"
                  }
                  ${hotspot.gated ? "opacity-70" : ""}
                `}
                onMouseEnter={() => setActiveHotspot(hotspot.id)}
                onMouseLeave={() => setActiveHotspot(null)}
              >
                <Icon className={`w-5 h-5 ${hotspot.gated ? "text-muted-foreground" : "text-primary"}`} />
                <span className="text-xs font-mono text-foreground whitespace-nowrap">{hotspot.label}</span>
                {hotspot.gated && <Lock className="absolute -top-1 -right-1 w-3 h-3 text-accent" />}

                {/* Hotspot tooltip */}
                <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                  <div className="bg-background border border-primary/30 px-2 py-1 text-xs font-mono whitespace-nowrap">
                    <span className="text-muted-foreground">TIMELINE: </span>
                    <span className="text-primary">{hotspot.targetTimeline}</span>
                  </div>
                </div>
              </Link>
            )
          })}
        </div>
      </div>

      {/* Consumer Mode Footer */}
      <div className="absolute bottom-2 left-2 z-20">
        <span className="text-xs font-mono text-muted-foreground/50">CONSUMER MODE | TRINITY 3D CORE | READ-ONLY</span>
      </div>

      {/* Business Firewall Indicator */}
      <div className="absolute bottom-2 right-2 z-20">
        <span className="text-xs font-mono text-accent/50">BUSINESS DATA FIREWALLED</span>
      </div>
    </div>
  )
}
