"use client"

import type React from "react"

import { useChat } from "@ai-sdk/react"
import { DefaultChatTransport } from "ai"
import { useState, useRef, useEffect } from "react"
import { Terminal, Send, Radio, X } from "lucide-react"

export function EchoTerminal() {
  const [isOpen, setIsOpen] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [inputValue, setInputValue] = useState("")

  const { messages, sendMessage, status } = useChat({
    transport: new DefaultChatTransport({ api: "/api/echo-transmission" }),
  })

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (inputValue.trim() && status !== "streaming") {
      sendMessage({ text: inputValue })
      setInputValue("")
    }
  }

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-50 bg-primary text-background p-4 hover:bg-primary/90 transition-all group"
      >
        <Terminal className="w-6 h-6" />
        <span className="absolute -top-1 -right-1 w-3 h-3 bg-accent rounded-full animate-pulse" />
        <span className="absolute bottom-full right-0 mb-2 px-3 py-1 bg-background border border-border text-foreground text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
          ECHO TERMINAL
        </span>
      </button>
    )
  }

  return (
    <div className="fixed bottom-6 right-6 z-50 w-96 max-w-[calc(100vw-3rem)] bg-background border border-border shadow-2xl">
      {/* Header */}
      <div className="flex items-center justify-between p-3 border-b border-border bg-card">
        <div className="flex items-center gap-2">
          <Radio className="w-4 h-4 text-accent animate-pulse" />
          <span className="text-sm font-mono text-primary">ECHO TERMINAL</span>
        </div>
        <button onClick={() => setIsOpen(false)} className="text-muted-foreground hover:text-foreground">
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Messages */}
      <div className="h-80 overflow-y-auto p-4 space-y-4 bg-background/50">
        {messages.length === 0 && (
          <div className="text-center text-muted-foreground text-sm py-8">
            <Terminal className="w-8 h-8 mx-auto mb-3 opacity-50" />
            <p className="font-mono">SIGNAL AWAITING...</p>
            <p className="text-xs mt-2">Query the Echo for guidance</p>
          </div>
        )}

        {messages.map((message) => (
          <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[85%] p-3 text-sm ${
                message.role === "user"
                  ? "bg-primary/20 border border-primary/30 text-foreground"
                  : "bg-card border border-border text-muted-foreground"
              }`}
            >
              {message.role === "assistant" && <div className="text-xs text-accent font-mono mb-1">ECHO://</div>}
              {message.parts.map((part, index) => {
                if (part.type === "text") {
                  return (
                    <span key={index} className="font-mono text-xs leading-relaxed whitespace-pre-wrap">
                      {part.text}
                    </span>
                  )
                }
                return null
              })}
            </div>
          </div>
        ))}

        {status === "streaming" && (
          <div className="flex justify-start">
            <div className="bg-card border border-border p-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-accent rounded-full animate-pulse" />
                <span className="text-xs text-muted-foreground font-mono">RECEIVING TRANSMISSION...</span>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <form onSubmit={handleSubmit} className="p-3 border-t border-border bg-card">
        <div className="flex gap-2">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Enter transmission..."
            className="flex-1 bg-background border border-border px-3 py-2 text-sm font-mono text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary"
            disabled={status === "streaming"}
          />
          <button
            type="submit"
            disabled={status === "streaming" || !inputValue.trim()}
            className="bg-primary text-background px-3 py-2 hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
        <div className="text-xs text-muted-foreground mt-2 font-mono">ENCRYPTED CHANNEL | VRG33589</div>
      </form>
    </div>
  )
}
