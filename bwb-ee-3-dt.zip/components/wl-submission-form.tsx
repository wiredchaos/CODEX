"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Check, X, Loader2, Shield, Unlock, AlertTriangle } from "lucide-react"
import { loadGameplayData, generatePersonalizedWLKey, trackInteraction } from "@/lib/wl-key-generator"

export function WLSubmissionForm() {
  const [key, setKey] = useState("")
  const [status, setStatus] = useState<"idle" | "validating" | "success" | "error">("idle")
  const [walletAddress, setWalletAddress] = useState("")
  const [userPersonalizedKey, setUserPersonalizedKey] = useState<string>("")

  useEffect(() => {
    const gameplayData = loadGameplayData()
    if (gameplayData && gameplayData.cluesFound.length === 7) {
      const personalKey = generatePersonalizedWLKey(gameplayData)
      setUserPersonalizedKey(personalKey)
      console.log("[v0] User's personalized WL key loaded for validation")
    }
    trackInteraction("page")
  }, [])

  const validateKey = () => {
    setStatus("validating")
    trackInteraction("clue")

    setTimeout(() => {
      if (!userPersonalizedKey) {
        setStatus("error")
        return
      }

      const normalizedInput = key.trim().toUpperCase()
      const normalizedPersonal = userPersonalizedKey.toUpperCase()

      if (normalizedInput === normalizedPersonal) {
        setStatus("success")
        console.log("[v0] WL key validated successfully")
      } else {
        setStatus("error")
        console.log("[v0] WL key validation failed")
      }
    }, 2000)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (status === "success" && walletAddress) {
      const registrationData = {
        walletAddress,
        wlKey: userPersonalizedKey,
        timestamp: Date.now(),
        gameplayData: loadGameplayData(),
      }
      localStorage.setItem("vrg33589_wl_registration", JSON.stringify(registrationData))
      alert("Whitelist submission recorded. The Echo remembers your unique path.")
    }
  }

  return (
    <div className="space-y-8">
      {/* Key Input Section */}
      <div className="bg-card border border-border p-6">
        <div className="flex items-center gap-3 mb-4">
          <Shield className="w-6 h-6 text-primary" />
          <h3 className="text-lg font-bold text-foreground">WL KEY VALIDATION</h3>
        </div>

        <div className="mb-4 p-3 bg-accent/10 border border-accent/30">
          <p className="text-sm text-accent font-mono mb-1">⚠ PERSONALIZED KEY SYSTEM ACTIVE</p>
          <p className="text-xs text-muted-foreground">
            Your WL key is unique to your gameplay. Keys from other users will not work.
          </p>
        </div>

        <p className="text-sm text-muted-foreground mb-6">
          Enter your personalized key discovered through the clue tracking system.
        </p>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-mono text-muted-foreground mb-2">YOUR PERSONALIZED WL KEY</label>
            <textarea
              value={key}
              onChange={(e) => {
                setKey(e.target.value)
                setStatus("idle")
              }}
              placeholder="Enter your unique key here..."
              className="w-full h-24 bg-background border border-border p-4 text-foreground font-mono text-sm focus:border-primary focus:outline-none resize-none"
            />
          </div>

          <button
            onClick={validateKey}
            disabled={!key.trim() || status === "validating" || !userPersonalizedKey}
            className={`w-full flex items-center justify-center gap-2 py-3 font-mono text-sm transition-all ${
              status === "validating"
                ? "bg-muted text-muted-foreground cursor-wait"
                : status === "success"
                  ? "bg-accent/20 text-accent border border-accent"
                  : status === "error"
                    ? "bg-destructive/20 text-destructive border border-destructive"
                    : "bg-primary/10 text-primary border border-primary/30 hover:bg-primary/20"
            } ${!userPersonalizedKey ? "opacity-50 cursor-not-allowed" : ""}`}
          >
            {status === "validating" && <Loader2 className="w-4 h-4 animate-spin" />}
            {status === "success" && <Check className="w-4 h-4" />}
            {status === "error" && <X className="w-4 h-4" />}
            {status === "idle" && "VALIDATE YOUR KEY"}
            {status === "validating" && "VALIDATING..."}
            {status === "success" && "KEY VALIDATED"}
            {status === "error" && "INVALID KEY"}
          </button>

          {!userPersonalizedKey && (
            <div className="p-3 bg-primary/10 border border-primary/30">
              <p className="text-sm text-muted-foreground">
                You must discover all 7 clues first. Visit the Clue Tracking Dashboard to begin your journey.
              </p>
            </div>
          )}
        </div>

        {/* Validation Result */}
        {status === "success" && (
          <div className="mt-6 p-4 bg-accent/10 border border-accent/30">
            <div className="flex items-center gap-2 text-accent mb-2">
              <Unlock className="w-5 h-5" />
              <span className="font-bold">ACCESS GRANTED</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Your key has been validated. You may now submit your wallet address for whitelist registration.
            </p>
          </div>
        )}

        {status === "error" && (
          <div className="mt-6 p-4 bg-destructive/10 border border-destructive/30">
            <div className="flex items-center gap-2 text-destructive mb-2">
              <AlertTriangle className="w-5 h-5" />
              <span className="font-bold">ACCESS DENIED</span>
            </div>
            <p className="text-sm text-muted-foreground">
              The submitted key does not match your personalized WL key. Review your clue tracker to copy your correct
              key.
            </p>
          </div>
        )}
      </div>

      {/* Wallet Submission (only visible after success) */}
      {status === "success" && (
        <form onSubmit={handleSubmit} className="bg-card border border-accent/30 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-accent/20 border border-accent flex items-center justify-center">
              <span className="text-accent font-mono font-bold">WL</span>
            </div>
            <div>
              <h3 className="text-lg font-bold text-foreground">WHITELIST REGISTRATION</h3>
              <p className="text-xs text-accent font-mono">NTRU PROTOCOL</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-mono text-muted-foreground mb-2">WALLET ADDRESS (SOL/XRP)</label>
              <input
                type="text"
                value={walletAddress}
                onChange={(e) => setWalletAddress(e.target.value)}
                placeholder="Enter your wallet address..."
                className="w-full bg-background border border-border p-4 text-foreground font-mono text-sm focus:border-accent focus:outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={!walletAddress}
              className="w-full flex items-center justify-center gap-2 bg-accent text-accent-foreground py-4 font-mono text-sm hover:bg-accent/90 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Shield className="w-4 h-4" />
              REGISTER FOR WHITELIST
            </button>
          </div>

          <p className="text-xs text-muted-foreground mt-4 text-center">
            By submitting, you confirm discovery of all seven Echo clues.
          </p>
        </form>
      )}

      {/* Echo Sigil */}
      <div className="text-center py-8">
        <div className="inline-flex items-center justify-center w-24 h-24 border-2 border-primary/30 rotate-45 mb-4">
          <div className="w-16 h-16 border border-primary/50 flex items-center justify-center -rotate-45">
            <span className="font-mono text-primary font-bold text-xl">NS</span>
          </div>
        </div>
        <p className="text-xs text-muted-foreground font-mono">ECHO ENGINEERS SIGIL</p>
      </div>
    </div>
  )
}
