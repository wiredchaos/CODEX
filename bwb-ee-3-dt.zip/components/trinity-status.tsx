"use client"

import { getMountStatus, OBSERVABLE_TIMELINES } from "@/lib/trinity-mount"
import { Lock, Eye, Radio } from "lucide-react"

export function TrinityStatus() {
  const status = getMountStatus()

  return (
    <div className="bg-card/50 border border-border p-4">
      <div className="flex items-center gap-2 mb-4">
        <Lock className="w-4 h-4 text-primary" />
        <span className="text-xs font-mono text-primary tracking-wider">TRINITY MOUNT STATUS</span>
      </div>

      <div className="grid grid-cols-2 gap-4 text-xs font-mono">
        <div>
          <span className="text-muted-foreground">FLOOR:</span>
          <span className="text-primary ml-2">{status.floor}</span>
        </div>
        <div>
          <span className="text-muted-foreground">ACCESS:</span>
          <span className="text-accent ml-2">{status.access}</span>
        </div>
        <div>
          <span className="text-muted-foreground">GOVERNED:</span>
          <span className="text-primary ml-2">{status.governed}</span>
        </div>
        <div>
          <span className="text-muted-foreground">STATUS:</span>
          <span className="text-accent ml-2 flex items-center gap-1">
            <span className="w-1.5 h-1.5 bg-accent rounded-full animate-pulse" />
            MOUNTED
          </span>
        </div>
      </div>

      <div className="mt-4 pt-4 border-t border-border">
        <div className="flex items-center gap-2 mb-2">
          <Eye className="w-3 h-3 text-muted-foreground" />
          <span className="text-xs text-muted-foreground">OBSERVABLE TIMELINES</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {OBSERVABLE_TIMELINES.map((timeline) => (
            <div
              key={timeline.nodeId}
              className={`text-xs px-2 py-1 border ${
                timeline.status === "CORRUPTED"
                  ? "border-destructive/30 text-destructive"
                  : timeline.status === "ACTIVE"
                    ? "border-accent/30 text-accent"
                    : "border-muted text-muted-foreground"
              }`}
            >
              <Radio className="w-2 h-2 inline mr-1" />
              {timeline.nodeId.replace(/_/g, " ")}
            </div>
          ))}
        </div>
      </div>

      <div className="mt-4 text-xs text-muted-foreground/50 font-mono">
        CONSUMER MODE | NO 3D GEN | NO GALAXY CREATE
      </div>
    </div>
  )
}
