"use client"

import { useState } from "react"
import { Play, Lock, Unlock } from "lucide-react"

interface VideoCardProps {
  id: number
  title: string
  description: string
  clueType: string
  clueStatus: "found" | "not-found"
  thumbnail: string
  duration: string
  reference: string
}

export function VideoCard({
  id,
  title,
  description,
  clueType,
  clueStatus,
  thumbnail,
  duration,
  reference,
}: VideoCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <div
      className="group relative bg-card border border-border rounded-sm overflow-hidden cursor-pointer"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Thumbnail */}
      <div className="relative aspect-video overflow-hidden">
        <img
          src={thumbnail || "/placeholder.svg"}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />

        {/* Overlay */}
        <div className="absolute inset-0 bg-background/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="w-16 h-16 rounded-full bg-primary/20 border border-primary flex items-center justify-center pulse-glow">
            <Play className="w-8 h-8 text-primary ml-1" />
          </div>
        </div>

        {/* Duration Badge */}
        <div className="absolute bottom-2 right-2 bg-background/90 px-2 py-1 text-xs font-mono text-foreground">
          {duration}
        </div>

        {/* Episode Number */}
        <div className="absolute top-2 left-2 bg-primary/90 px-3 py-1 text-xs font-mono text-primary-foreground font-bold">
          EP.{String(id).padStart(2, "0")}
        </div>

        {/* Glitch Effect on Hover */}
        {isHovered && (
          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute inset-0 bg-primary/10 mix-blend-overlay" />
            <div
              className="absolute top-1/4 left-0 right-0 h-px bg-primary/50"
              style={{ transform: "translateY(2px)" }}
            />
            <div
              className="absolute top-2/3 left-0 right-0 h-px bg-accent/50"
              style={{ transform: "translateY(-1px)" }}
            />
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-4">
        <h3 className="text-foreground font-bold text-lg mb-2 tracking-wide group-hover:text-primary transition-colors">
          {title}
        </h3>
        <p className="text-muted-foreground text-sm mb-4 line-clamp-2">{description}</p>

        {/* Clue Status */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {clueStatus === "found" ? (
              <Unlock className="w-4 h-4 text-accent" />
            ) : (
              <Lock className="w-4 h-4 text-muted-foreground" />
            )}
            <span className={`text-xs font-mono ${clueStatus === "found" ? "text-accent" : "text-muted-foreground"}`}>
              CLUE: {clueStatus.toUpperCase()}
            </span>
          </div>
          <span className="text-xs text-muted-foreground font-mono">{clueType}</span>
        </div>

        {/* Reference Tag */}
        <div className="mt-3 pt-3 border-t border-border">
          <span className="text-xs text-primary/70 font-mono">REF: {reference}</span>
        </div>
      </div>
    </div>
  )
}
