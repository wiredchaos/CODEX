"use client"

import { useState, useEffect } from "react"
import { Eye, EyeOff, Check, Lock, Unlock, Copy, CheckCheck } from "lucide-react"
import {
  loadGameplayData,
  recordClueDiscovery,
  trackInteraction,
  generatePersonalizedWLKey,
} from "@/lib/wl-key-generator"

interface Clue {
  id: number
  segment: string
  description: string
  videoReference: string
  clueType: string
  found: boolean
}

const initialClues: Clue[] = [
  {
    id: 1,
    segment: "589",
    description: "The Time Matrix breach number - hidden in The Artifact Pulse opening sequence",
    videoReference: "EP.01 - The Artifact Pulse",
    clueType: "Visible Cipher",
    found: false,
  },
  {
    id: 2,
    segment: "OUTSIDE_YOUR_ASSIGNMENT",
    description: "Echo command phrase - flashes during Nilotic Frequency glitch frames",
    videoReference: "EP.02 - Nilotic Frequency",
    clueType: "Glitch Frame Glyph",
    found: false,
  },
  {
    id: 3,
    segment: "33.9N-118.2W",
    description: "Geographic coordinates - encoded in Dark Nexus audio waveform",
    videoReference: "EP.03 - The Dark Nexus",
    clueType: "Audio Waveform Metadata",
    found: false,
  },
  {
    id: 4,
    segment: "NTRU",
    description: "Protocol identifier - appears in semi-hidden timestamp overlay",
    videoReference: "EP.04 - Veil of Time Collapse",
    clueType: "Semi-Hidden Timestamp",
    found: false,
  },
  {
    id: 5,
    segment: "3:33",
    description: "The sacred time marker - embedded in background geometry",
    videoReference: "EP.04 - Veil of Time Collapse",
    clueType: "Geometry Code",
    found: false,
  },
  {
    id: 6,
    segment: "THE_LEDGER_REMEMBERS",
    description: "Final echo phrase - deep-hidden in Operation Ancestry visuals",
    videoReference: "EP.05 - Operation Ancestry",
    clueType: "Deep-Hidden Geometry",
    found: false,
  },
  {
    id: 7,
    segment: "33",
    description: "The closing seal - appears in final frame sequence",
    videoReference: "EP.05 - Operation Ancestry",
    clueType: "Final Frame Code",
    found: false,
  },
]

export function ClueTracker() {
  const [clues, setClues] = useState<Clue[]>(initialClues)
  const [showKey, setShowKey] = useState(false)
  const [copied, setCopied] = useState(false)
  const [personalizedKey, setPersonalizedKey] = useState<string>("")

  useEffect(() => {
    const gameplayData = loadGameplayData()
    if (gameplayData) {
      setClues((prev) =>
        prev.map((c) => ({
          ...c,
          found: gameplayData.cluesFound.includes(c.id),
        })),
      )

      if (gameplayData.cluesFound.length === 7) {
        const key = generatePersonalizedWLKey(gameplayData)
        setPersonalizedKey(key)
      }
    }
    trackInteraction("page")
  }, [])

  const foundCount = clues.filter((c) => c.found).length
  const progress = (foundCount / clues.length) * 100

  const toggleClue = (id: number) => {
    setClues((prev) => prev.map((c) => (c.id === id ? { ...c, found: !c.found } : c)))
    const gameplayData = recordClueDiscovery(id)
    trackInteraction("clue")

    if (gameplayData.cluesFound.length === 7) {
      const key = generatePersonalizedWLKey(gameplayData)
      setPersonalizedKey(key)
      console.log("[v0] Generated personalized WL key:", key)
    }
  }

  const displayKey = personalizedKey || "COMPLETE_ALL_CLUES_TO_REVEAL"

  const copyKey = () => {
    if (!personalizedKey) return
    navigator.clipboard.writeText(personalizedKey)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="space-y-8">
      <div className="bg-card border border-border p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-bold text-foreground mb-1">WL ELIGIBILITY PROGRESS</h3>
            <p className="text-sm text-muted-foreground font-mono">{foundCount}/7 clues discovered</p>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold text-primary font-mono">{Math.round(progress)}%</div>
            <div className="text-xs text-muted-foreground">COMPLETION</div>
          </div>
        </div>
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <div className="h-full bg-primary transition-all duration-500 ease-out" style={{ width: `${progress}%` }} />
        </div>
        {foundCount === 7 && personalizedKey && (
          <div className="mt-4 p-3 bg-accent/10 border border-accent/30">
            <p className="text-sm text-accent font-mono">
              ✓ PERSONALIZED WL KEY GENERATED - Your unique key is ready below
            </p>
          </div>
        )}
      </div>

      <div className="space-y-4">
        {clues.map((clue, index) => (
          <div
            key={clue.id}
            className={`bg-card border transition-all duration-300 ${
              clue.found ? "border-accent/50 bg-accent/5" : "border-border hover:border-primary/30"
            }`}
          >
            <div className="p-4">
              <div className="flex items-start gap-4">
                <button
                  onClick={() => toggleClue(clue.id)}
                  className={`flex-shrink-0 w-10 h-10 flex items-center justify-center border transition-all ${
                    clue.found
                      ? "bg-accent/20 border-accent text-accent"
                      : "bg-muted border-border text-muted-foreground hover:border-primary/50"
                  }`}
                >
                  {clue.found ? <Check className="w-5 h-5" /> : <span className="font-mono text-sm">{index + 1}</span>}
                </button>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    {clue.found ? (
                      <Unlock className="w-4 h-4 text-accent" />
                    ) : (
                      <Lock className="w-4 h-4 text-muted-foreground" />
                    )}
                    <span
                      className={`text-xs font-mono px-2 py-0.5 ${
                        clue.found ? "bg-accent/20 text-accent" : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {clue.clueType.toUpperCase()}
                    </span>
                  </div>

                  <div className={`font-mono text-lg mb-2 ${clue.found ? "text-accent" : "text-foreground"}`}>
                    {clue.found ? clue.segment : "■".repeat(clue.segment.length)}
                  </div>

                  <p className="text-sm text-muted-foreground mb-2">{clue.description}</p>

                  <div className="text-xs text-primary/70 font-mono">SOURCE: {clue.videoReference}</div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-card border border-border p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-foreground">YOUR PERSONALIZED WL KEY</h3>
          <button
            onClick={() => setShowKey(!showKey)}
            disabled={!personalizedKey}
            className={`flex items-center gap-2 text-sm transition-colors ${
              personalizedKey
                ? "text-muted-foreground hover:text-foreground"
                : "text-muted-foreground/50 cursor-not-allowed"
            }`}
          >
            {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            {showKey ? "HIDE" : "REVEAL"}
          </button>
        </div>

        {!personalizedKey && (
          <div className="mb-4 p-3 bg-primary/10 border border-primary/30">
            <p className="text-sm text-muted-foreground">
              Your unique WL key will be generated when all 7 clues are discovered. Each user receives a different key
              based on gameplay.
            </p>
          </div>
        )}

        <div className="bg-background border border-border p-4 rounded-sm mb-4">
          <code className={`font-mono text-sm break-all ${showKey ? "text-primary" : "text-muted-foreground"}`}>
            {showKey ? displayKey : "●".repeat(60)}
          </code>
        </div>

        <button
          onClick={copyKey}
          disabled={!showKey || !personalizedKey}
          className={`flex items-center gap-2 px-4 py-2 text-sm font-mono transition-all ${
            showKey && personalizedKey
              ? "bg-primary/10 text-primary border border-primary/30 hover:bg-primary/20"
              : "bg-muted text-muted-foreground cursor-not-allowed"
          }`}
        >
          {copied ? <CheckCheck className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          {copied ? "COPIED" : "COPY YOUR KEY"}
        </button>
      </div>
    </div>
  )
}
