"use client"

import Link from "next/link"
import { useState } from "react"
import { Menu, X, Radio, Fingerprint, ChevronDown, Tv, Zap } from "lucide-react"

export function StudioHeader() {
  const [isOpen, setIsOpen] = useState(false)
  const [showCreatorMenu, setShowCreatorMenu] = useState(false)

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link href="/neteru-studios" className="flex items-center gap-3 group">
            <div className="relative w-12 h-12 flex items-center justify-center overflow-hidden">
              <div className="absolute inset-0 bg-primary/20 rounded-sm rotate-45 group-hover:rotate-[135deg] transition-transform duration-500" />
              <div className="absolute inset-0 bg-gradient-to-r from-primary/0 via-primary/30 to-primary/0 animate-pulse" />
              <Fingerprint className="w-6 h-6 text-primary relative z-10 animate-pulse" />
            </div>
            <div className="hidden sm:flex flex-col">
              <div className="text-primary font-bold tracking-[0.3em] text-lg relative overflow-hidden">
                <span className="inline-block animate-[glitch_3s_infinite]">VRG33589</span>
                <span className="absolute inset-0 text-accent/50 animate-[glitch_3s_infinite_0.1s] clip-path-inset-top">
                  VRG33589
                </span>
              </div>
              <div className="text-muted-foreground text-xs tracking-widest">ECHO ENGINEERS</div>
            </div>
          </Link>

          <div className="hidden lg:flex items-center gap-4">
            <div className="relative">
              <button
                onClick={() => setShowCreatorMenu(!showCreatorMenu)}
                className="flex items-center gap-2 text-xs font-mono text-muted-foreground hover:text-primary transition-colors"
              >
                <span>ARTIST:</span>
                <span className="text-accent border border-accent/30 px-2 py-1 flex items-center gap-1">
                  NEURO META X
                  <ChevronDown className="w-3 h-3" />
                </span>
              </button>

              {showCreatorMenu && (
                <div className="absolute top-full right-0 mt-2 w-64 bg-background border border-border shadow-xl z-50">
                  <div className="p-2 border-b border-border">
                    <span className="text-xs text-muted-foreground font-mono">CREATOR PROFILES</span>
                  </div>
                  <Link
                    href="/wired-chaos/creators/neuro-meta-x"
                    onClick={() => setShowCreatorMenu(false)}
                    className="flex items-center gap-3 p-3 hover:bg-primary/10 transition-colors"
                  >
                    <Zap className="w-4 h-4 text-primary" />
                    <div>
                      <div className="text-sm font-bold text-primary">WIRED CHAOS</div>
                      <div className="text-xs text-muted-foreground">Meta Hub Profile</div>
                    </div>
                  </Link>
                  <Link
                    href="/789ott/creators/neuro-meta-x"
                    onClick={() => setShowCreatorMenu(false)}
                    className="flex items-center gap-3 p-3 hover:bg-destructive/10 transition-colors"
                  >
                    <Tv className="w-4 h-4 text-destructive" />
                    <div>
                      <div className="text-sm font-bold text-destructive">789OTT</div>
                      <div className="text-xs text-muted-foreground">Streaming Profile</div>
                    </div>
                  </Link>
                  <div className="p-2 border-t border-border">
                    <Link
                      href="/wired-chaos"
                      onClick={() => setShowCreatorMenu(false)}
                      className="text-xs text-muted-foreground hover:text-primary transition-colors"
                    >
                      View All Nodes
                    </Link>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            <Link
              href="/neteru-studios"
              className="text-sm text-muted-foreground hover:text-primary transition-colors tracking-wide"
            >
              TRANSMISSIONS
            </Link>
            <Link
              href="/neteru-studios/barbed-wire-broadcast"
              className="text-sm text-muted-foreground hover:text-primary transition-colors tracking-wide flex items-center gap-2"
            >
              <Radio className="w-3 h-3 text-destructive animate-pulse" />
              BARBED WIRE
            </Link>
            <Link
              href="/neteru-studios/clues"
              className="text-sm text-muted-foreground hover:text-primary transition-colors tracking-wide"
            >
              CIPHER HUNT
            </Link>
            <Link
              href="/neteru-studios/whitelist"
              className="text-sm bg-primary/10 border border-primary/30 px-4 py-2 text-primary hover:bg-primary/20 transition-all tracking-wide"
            >
              VRG33589 WL
            </Link>
          </nav>

          {/* Mobile Menu Button */}
          <button onClick={() => setIsOpen(!isOpen)} className="md:hidden text-foreground p-2">
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Nav */}
        {isOpen && (
          <nav className="md:hidden mt-4 pb-4 flex flex-col gap-4 border-t border-border pt-4">
            <div className="text-xs font-mono text-muted-foreground pb-2 border-b border-border">
              <span className="text-primary font-bold tracking-widest">VRG33589</span> | ARTIST:{" "}
              <span className="text-accent">NEURO META X</span>
            </div>

            <div className="flex flex-col gap-2 pb-4 border-b border-border">
              <span className="text-xs text-muted-foreground">CREATOR PROFILES:</span>
              <Link
                href="/wired-chaos/creators/neuro-meta-x"
                className="text-sm text-primary hover:underline flex items-center gap-2"
                onClick={() => setIsOpen(false)}
              >
                <Zap className="w-3 h-3" />
                WIRED CHAOS
              </Link>
              <Link
                href="/789ott/creators/neuro-meta-x"
                className="text-sm text-destructive hover:underline flex items-center gap-2"
                onClick={() => setIsOpen(false)}
              >
                <Tv className="w-3 h-3" />
                789OTT
              </Link>
            </div>

            <Link
              href="/neteru-studios"
              className="text-sm text-muted-foreground hover:text-primary transition-colors tracking-wide"
              onClick={() => setIsOpen(false)}
            >
              TRANSMISSIONS
            </Link>
            <Link
              href="/neteru-studios/barbed-wire-broadcast"
              className="text-sm text-muted-foreground hover:text-primary transition-colors tracking-wide flex items-center gap-2"
              onClick={() => setIsOpen(false)}
            >
              <Radio className="w-3 h-3 text-destructive animate-pulse" />
              BARBED WIRE BROADCAST
            </Link>
            <Link
              href="/neteru-studios/clues"
              className="text-sm text-muted-foreground hover:text-primary transition-colors tracking-wide"
              onClick={() => setIsOpen(false)}
            >
              CIPHER HUNT
            </Link>
            <Link
              href="/neteru-studios/whitelist"
              className="text-sm bg-primary/10 border border-primary/30 px-4 py-2 text-primary hover:bg-primary/20 transition-all tracking-wide text-center"
              onClick={() => setIsOpen(false)}
            >
              VRG33589 WHITELIST
            </Link>
          </nav>
        )}
      </div>

      <style jsx>{`
        @keyframes glitch {
          0%,
          90%,
          100% {
            transform: translate(0);
          }
          92% {
            transform: translate(-2px, 1px);
          }
          94% {
            transform: translate(2px, -1px);
          }
          96% {
            transform: translate(-1px, 2px);
          }
          98% {
            transform: translate(1px, -2px);
          }
        }
        .clip-path-inset-top {
          clip-path: inset(0 0 50% 0);
        }
      `}</style>
    </header>
  )
}
