"use client"

import { useState } from "react"
import { Play, Radio, AlertTriangle, Clock, Eye } from "lucide-react"

interface NewsBroadcastCardProps {
  id: number
  title: string
  category: "BREAKING" | "CLASSIFIED" | "SIGNAL" | "ARCHIVE"
  description: string
  timestamp: string
  thumbnail: string
  duration: string
  isLive?: boolean
}

export function NewsBroadcastCard({
  id,
  title,
  category,
  description,
  timestamp,
  thumbnail,
  duration,
  isLive = false,
}: NewsBroadcastCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  const categoryColors = {
    BREAKING: "bg-destructive text-destructive-foreground",
    CLASSIFIED: "bg-primary text-primary-foreground",
    SIGNAL: "bg-accent text-accent-foreground",
    ARCHIVE: "bg-muted text-muted-foreground",
  }

  return (
    <article
      className="group relative bg-card border border-border overflow-hidden cursor-pointer hover:border-destructive/50 transition-all duration-300"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Live Indicator */}
      {isLive && (
        <div className="absolute top-3 right-3 z-20 flex items-center gap-2 bg-destructive px-3 py-1">
          <Radio className="w-3 h-3 animate-pulse" />
          <span className="text-xs font-mono font-bold text-destructive-foreground">LIVE</span>
        </div>
      )}

      {/* Thumbnail */}
      <div className="relative aspect-video overflow-hidden">
        <img
          src={thumbnail || "/placeholder.svg"}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />

        {/* Scanline Effect */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-destructive/5 to-background/80 pointer-events-none" />

        {/* Static Noise Overlay */}
        {isHovered && (
          <div
            className="absolute inset-0 opacity-20 mix-blend-overlay pointer-events-none"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`,
            }}
          />
        )}

        {/* Play Button */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="w-14 h-14 bg-destructive/90 flex items-center justify-center">
            <Play className="w-6 h-6 text-destructive-foreground ml-1" />
          </div>
        </div>

        {/* Duration */}
        <div className="absolute bottom-2 right-2 bg-background/90 px-2 py-1 text-xs font-mono text-foreground flex items-center gap-1">
          <Clock className="w-3 h-3" />
          {duration}
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {/* Category & Timestamp */}
        <div className="flex items-center justify-between mb-3">
          <span className={`text-xs font-mono font-bold px-2 py-1 ${categoryColors[category]}`}>{category}</span>
          <span className="text-xs text-muted-foreground font-mono">{timestamp}</span>
        </div>

        {/* Title */}
        <h3 className="text-foreground font-bold text-lg mb-2 group-hover:text-destructive transition-colors line-clamp-2">
          {title}
        </h3>

        {/* Description */}
        <p className="text-muted-foreground text-sm line-clamp-2 mb-3">{description}</p>

        {/* Footer */}
        <div className="flex items-center gap-4 text-xs text-muted-foreground font-mono pt-3 border-t border-border">
          <div className="flex items-center gap-1">
            <Eye className="w-3 h-3" />
            <span>BROADCAST #{String(id).padStart(3, "0")}</span>
          </div>
          <div className="flex items-center gap-1">
            <AlertTriangle className="w-3 h-3 text-destructive" />
            <span>UNVERIFIED</span>
          </div>
        </div>
      </div>
    </article>
  )
}
